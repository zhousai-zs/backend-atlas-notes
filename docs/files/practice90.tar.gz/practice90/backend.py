#!/usr/bin/env python3
"""异构延迟实例：每个连接读一行请求，sleep 固定延迟后回复实例名。"""
import argparse, socketserver, time, threading

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--delay-ms", type=float, default=5)
    a = ap.parse_args()
    active = [0]; lock = threading.Lock()

    class H(socketserver.StreamRequestHandler):
        def handle(self):
            for line in self.rfile:
                with lock: active[0] += 1
                # 模拟成本：同时处理的请求越多越慢（简单的 CPU 争用模型）
                time.sleep(a.delay_ms / 1000 * (1 + 0.1 * (active[0] - 1)))
                with lock: active[0] -= 1
                self.wfile.write(f"{a.name}\n".encode()); self.wfile.flush()

    class S(socketserver.ThreadingTCPServer):
        allow_reuse_address = True; daemon_threads = True
    try:
        srv = S(("127.0.0.1", a.port), H)
    except OSError as e:
        print(f"bind failed: {e}", flush=True); raise SystemExit(2)
    print(f"LISTEN {a.name} :{a.port} delay={a.delay_ms}ms", flush=True)
    srv.serve_forever()

if __name__ == "__main__":
    main()
