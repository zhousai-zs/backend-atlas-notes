#!/usr/bin/env bash
# practice90：异构延迟实例上比较 rr / least / p2c，并验证摘除端点不丢在途调用
set -u
cd "$(dirname "$0")"
python3 backend.py --name A --port 18090 --delay-ms 5  > a.log 2>&1 & PA=$!
python3 backend.py --name B --port 18091 --delay-ms 5  > b.log 2>&1 & PB=$!
python3 backend.py --name C --port 18092 --delay-ms 40 > c.log 2>&1 & PC=$!
trap 'kill $PA $PB $PC 2>/dev/null' EXIT
sleep 0.8
fail=0
for p in rr least p2c; do python3 lb.py --policy $p > $p.json; echo "$p: $(cat $p.json)"; done
python3 lb.py --policy least --remove-at 600 > remove.json; echo "remove: $(cat remove.json)"
python3 backend.py --name X --port 18090 > dup.log 2>&1; rc=$?
python3 - "$rc" <<'PY' || fail=1
import json, sys
r = {p: json.load(open(f"{p}.json")) for p in ("rr", "least", "p2c")}
rm = json.load(open("remove.json")); rc = int(sys.argv[1]); ok = True
def check(cond, msg):
    global ok; print(("PASS " if cond else "FAIL ") + msg); ok &= cond
for p, x in r.items():
    check(x["errors"] == 0, f"{p} errors=0")
    check(all("count" in v and "p99_ms" in v for v in x["per_instance"].values()), f"{p} 报告含每实例负载与p99")
rrC = r["rr"]["per_instance"]["C"]["count"]; lC = r["least"]["per_instance"]["C"]["count"]
check(abs(rrC - 400) <= 5, f"rr 平均分配，慢实例 C 仍拿到 ~1/3 ({rrC})")
check(lC < rrC * 0.6, f"least 让慢实例 C 少拿流量 ({lC} < {rrC}*0.6)")
check(r["least"]["p99_ms"] < r["rr"]["p99_ms"], f"least p99 {r['least']['p99_ms']} < rr p99 {r['rr']['p99_ms']}")
check(r["p2c"]["per_instance"]["C"]["count"] < rrC, "p2c 也减少慢实例流量")
check(rm["errors"] == 0, "摘除端点过程中 errors=0")
check(rm["removed"]["inflight_after_drain"] == 0, f"被摘除端点在途 {rm['removed']['inflight_at_remove']} 全部完成，剩余 0")
total = sum(v["count"] for v in rm["per_instance"].values())
check(total == 1200, f"摘除后全部 1200 请求都完成 ({total})")
check(rc == 2, f"端口占用时 rc=2 (rc={rc})")
sys.exit(0 if ok else 1)
PY
[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
