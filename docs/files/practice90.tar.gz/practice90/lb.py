#!/usr/bin/env python3
"""客户端负载均衡压测：rr / least / p2c，报告每实例负载与 p99，并演示运行中摘除端点不丢在途调用。"""
import argparse, json, random, socket, threading, time

class Endpoint:
    def __init__(self, name, port):
        self.name, self.port = name, port
        self.inflight = 0; self.count = 0; self.lat = []
        self.lock = threading.Lock(); self.local = threading.local()
    def conn(self):  # 每个线程对每个端点一条长连接，请求级选择
        c = getattr(self.local, "c", None)
        if c is None:
            s = socket.create_connection(("127.0.0.1", self.port), timeout=5)
            c = self.local.c = (s, s.makefile("rb"))
        return c

class Balancer:
    def __init__(self, eps, policy):
        self.snapshot = tuple(eps)  # 不可变快照，更新时整体替换（copy-on-write）
        self.policy = policy; self.rr = 0; self.lock = threading.Lock()
    def pick(self):
        eps = self.snapshot
        if not eps: raise RuntimeError("UNAVAILABLE: no endpoints")
        if self.policy == "rr":
            with self.lock:
                self.rr += 1; return eps[self.rr % len(eps)]
        if self.policy == "least":
            return min(eps, key=lambda e: (e.inflight, random.random()))
        a, b = random.sample(eps, 2) if len(eps) > 1 else (eps[0], eps[0])
        return a if a.inflight <= b.inflight else b
    def remove(self, name):
        self.snapshot = tuple(e for e in self.snapshot if e.name != name)

def call(bal):
    ep = bal.pick()
    with ep.lock: ep.inflight += 1
    t0 = time.perf_counter()
    try:
        s, f = ep.conn(); s.sendall(b"req\n")
        if f.readline().strip().decode() != ep.name: raise RuntimeError("bad reply")
    finally:
        with ep.lock:
            ep.inflight -= 1; ep.count += 1
            ep.lat.append((time.perf_counter() - t0) * 1000)

def p99(xs):
    xs = sorted(xs); return xs[int(len(xs) * 0.99) - 1] if xs else 0.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", choices=["rr", "least", "p2c"], default="rr")
    ap.add_argument("--endpoints", default="A:18090,B:18091,C:18092")
    ap.add_argument("--requests", type=int, default=1200)
    ap.add_argument("--concurrency", type=int, default=12)
    ap.add_argument("--remove-at", type=int, default=0, help="完成多少请求后摘除最后一个端点")
    a = ap.parse_args()
    eps = [Endpoint(n, int(p)) for n, p in (x.split(":") for x in a.endpoints.split(","))]
    bal = Balancer(eps, a.policy)
    done = [0]; errors = [0]; lk = threading.Lock(); removed = {}
    def worker():
        while True:
            with lk:
                if done[0] >= a.requests: return
                done[0] += 1; n = done[0]
                if a.remove_at and n == a.remove_at and not removed:
                    victim = eps[-1]; bal.remove(victim.name)
                    removed.update(name=victim.name, inflight_at_remove=victim.inflight)
            try: call(bal)
            except Exception as e:
                with lk: errors[0] += 1
    t0 = time.time()
    ts = [threading.Thread(target=worker) for _ in range(a.concurrency)]
    [t.start() for t in ts]; [t.join() for t in ts]
    alllat = [x for e in eps for x in e.lat]
    rep = {"policy": a.policy, "elapsed_s": round(time.time() - t0, 2), "errors": errors[0],
           "p99_ms": round(p99(alllat), 1),
           "per_instance": {e.name: {"count": e.count, "p99_ms": round(p99(e.lat), 1),
                                     "inflight_left": e.inflight} for e in eps}}
    if removed:
        v = next(e for e in eps if e.name == removed["name"])
        removed["inflight_after_drain"] = v.inflight; rep["removed"] = removed
    print(json.dumps(rep, ensure_ascii=False))

if __name__ == "__main__":
    main()
