// 第22课实践：异步回调持有连接 + 循环引用修复 + weak_ptr.lock 失败
#include <cstdio>
#include <functional>
#include <memory>
#include <queue>
#include <string>

static int g_conn_alive = 0;      // 存活的 Connection 数
static int g_session_alive = 0;   // 存活的 Session 数

// 模拟事件循环：回调先入队，稍后统一执行（像 epoll 回调 / RPC 回包）
std::queue<std::function<void()>> g_loop;
void run_loop() { while (!g_loop.empty()) { auto f = std::move(g_loop.front()); g_loop.pop(); f(); } }

struct Connection : std::enable_shared_from_this<Connection> {
    int fd;
    explicit Connection(int f) : fd(f) { ++g_conn_alive; }
    ~Connection() { --g_conn_alive; std::printf("  [conn %d] destroyed\n", fd); }

    // 错误写法：捕获裸 this，回调执行时对象可能已析构
    void async_read_bad(int* out) { g_loop.push([this, out] { *out = fd; }); }
    // 正确写法：捕获 shared_from_this()，回调持有一份所有权
    void async_read_good(int* out) {
        auto self = shared_from_this();
        g_loop.push([self, out] { *out = self->fd; });
    }
};

// 循环引用版本：Session 持有 Connection，Connection 又强持有 Session
struct SessionCycle;
struct ConnCycle { std::shared_ptr<SessionCycle> session; ConnCycle(){++g_conn_alive;} ~ConnCycle(){--g_conn_alive;} };
struct SessionCycle { std::shared_ptr<ConnCycle> conn; SessionCycle(){++g_session_alive;} ~SessionCycle(){--g_session_alive;} };

// 修复版本：反向边改成 weak_ptr
struct SessionFixed;
struct ConnFixed { std::weak_ptr<SessionFixed> session; ConnFixed(){++g_conn_alive;} ~ConnFixed(){--g_conn_alive;} };
struct SessionFixed { std::shared_ptr<ConnFixed> conn; SessionFixed(){++g_session_alive;} ~SessionFixed(){--g_session_alive;} };

int failures = 0;
#define CHECK(c, msg) do { if (c) std::printf("PASS %s\n", msg); else { std::printf("FAIL %s\n", msg); ++failures; } } while (0)

int main(int argc, char** argv) {
    bool run_bad = argc > 1 && std::string(argv[1]) == "bad";

    // 1) 异步回调持有连接：外部引用全部释放后，回调仍能安全访问
    {
        int got = -1;
        {
            auto c = std::make_shared<Connection>(7);
            c->async_read_good(&got);
            CHECK(c.use_count() == 2, "回调捕获 self 后 use_count==2");
        } // 外部 shared_ptr 已释放
        CHECK(g_conn_alive == 1, "回调未执行前连接仍存活");
        run_loop();
        CHECK(got == 7 && g_conn_alive == 0, "回调执行完后连接才析构");
    }

    // 1b) 演示提前析构：裸 this（仅在 ./conn bad 时运行，ASan 会报 heap-use-after-free）
    if (run_bad) {
        int got = -1;
        { auto c = std::make_shared<Connection>(8); c->async_read_bad(&got); }
        run_loop();
        std::printf("bad got=%d\n", got);
    }

    // 2) 循环引用：两个 shared_ptr 互指，离开作用域也不析构（故意泄漏）
    {
        auto s = std::make_shared<SessionCycle>();
        s->conn = std::make_shared<ConnCycle>();
        s->conn->session = s;
        CHECK(s.use_count() == 2, "循环引用时 session use_count==2");
    }
    CHECK(g_session_alive == 1 && g_conn_alive == 1, "循环引用：离开作用域后仍未析构（泄漏）");
    g_session_alive = g_conn_alive = 0; // 重置计数，泄漏对象留给 LSan 报告之外处理

    // 3) weak_ptr 修复
    std::weak_ptr<SessionFixed> observer;
    {
        auto s = std::make_shared<SessionFixed>();
        s->conn = std::make_shared<ConnFixed>();
        s->conn->session = s;
        observer = s;
        CHECK(s.use_count() == 1, "weak_ptr 不增加强引用计数");
        auto locked = s->conn->session.lock();
        CHECK(locked != nullptr, "对象存活时 lock() 成功");
    }
    CHECK(g_session_alive == 0 && g_conn_alive == 0, "改为 weak_ptr 后正常析构");
    CHECK(observer.expired() && observer.lock() == nullptr, "对象释放后 lock() 返回空");

    // 4) 自定义删除器：管理 FILE*
    {
        int closed = 0;
        {
            auto closer = [&closed](FILE* f) { if (f) { std::fclose(f); ++closed; } };
            std::unique_ptr<FILE, decltype(closer)> fp(std::fopen("/dev/null", "w"), closer);
            CHECK(fp != nullptr, "unique_ptr+删除器打开文件");
        }
        CHECK(closed == 1, "离开作用域自动调用删除器 fclose");
    }

    std::printf(failures ? "SOME_TESTS_FAILED\n" : "ALL_TESTS_PASSED\n");
    return failures ? 1 : 0;
}
