#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
g++ -std=c++17 -O0 -g -fsanitize=address -fno-omit-frame-pointer conn.cpp -o conn || exit 1
echo "== 正常路径（循环引用部分是故意泄漏，关闭 LSan）=="
ASAN_OPTIONS=detect_leaks=0 ./conn || exit 1
echo "== 循环引用泄漏检测：LSan 应报告 leak =="
if ASAN_OPTIONS=detect_leaks=1 ./conn 2>&1 | grep -q "detected memory leaks"; then echo "PASS LSan 检出循环引用泄漏"; else echo "FAIL LSan 未检出泄漏"; exit 1; fi
echo "== 裸 this 回调：ASan 应报告 heap-use-after-free =="
if ASAN_OPTIONS=detect_leaks=0 ./conn bad 2>&1 | grep -q "heap-use-after-free"; then echo "PASS 裸 this 导致 use-after-free"; else echo "FAIL 未检出 use-after-free"; exit 1; fi
echo "ALL_CHECKS_PASSED"
