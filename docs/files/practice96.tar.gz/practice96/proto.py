"""教学RPC帧格式：16字节头 + JSON body
magic 2B 'RP' | version 1B | type 1B | req_id 8B | body_len 4B（网络序）"""
import json, struct

HDR = struct.Struct('!2sBBQI')   # 2+1+1+8+4 = 16
MAGIC, VERSION = b'RP', 1
T_REQ, T_RESP, T_ERR = 0, 1, 2
MAX_BODY = 1 << 20               # 1MB 协议上限

# 错误码（错误模型：传输层 / 协议层 / 应用层）
E_METHOD_NOT_FOUND = 'METHOD_NOT_FOUND'
E_INTERNAL = 'INTERNAL'
E_BAD_MAGIC = 'BAD_MAGIC'
E_BAD_VERSION = 'BAD_VERSION'
E_FRAME_TOO_LARGE = 'FRAME_TOO_LARGE'
E_BAD_BODY = 'BAD_BODY'

class ProtocolError(Exception):
    def __init__(self, code, msg=''):
        super().__init__(f'{code}: {msg}'); self.code = code

def encode(ftype, req_id, obj):
    body = json.dumps(obj, separators=(',', ':')).encode()
    return HDR.pack(MAGIC, VERSION, ftype, req_id, len(body)) + body

async def read_frame(reader, max_body=MAX_BODY, check=True):
    """读满头 -> 校验 -> 读满 body。check=False 是 naive 版本：什么都信。"""
    hdr = await reader.readexactly(HDR.size)
    magic, ver, ftype, req_id, blen = HDR.unpack(hdr)
    if check:
        if magic != MAGIC: raise ProtocolError(E_BAD_MAGIC, repr(magic))
        if ver != VERSION: raise ProtocolError(E_BAD_VERSION, str(ver))
        if blen > max_body: raise ProtocolError(E_FRAME_TOO_LARGE, str(blen))
    body = await reader.readexactly(blen)
    try:
        obj = json.loads(body)
    except ValueError:
        if check: raise ProtocolError(E_BAD_BODY, 'not json')
        raise
    return ftype, req_id, obj
