"""教学RPC服务端。用法: python3 server.py PORT naive|safe"""
import asyncio, random, sys, os
from proto import *

MAX_INFLIGHT = 64          # 每连接最大在途请求（safe）
stats = {'peak_inflight': 0}

async def get_read_count(p):          # 教学假设：计数服务
    await asyncio.sleep(random.uniform(0, 0.02))   # 随机延迟 -> 乱序完成
    return {'article_id': p['article_id'], 'read_count': p['article_id'] * 7}
async def echo(p):  return p
async def slow(p):
    await asyncio.sleep(p.get('delay', 0.3)); return {'slow': p.get('tag')}
async def boom(p):  raise RuntimeError('handler bug')
async def stats_m(p): return dict(stats)

REGISTRY = {'get_read_count': get_read_count, 'echo': echo, 'slow': slow,
            'boom': boom, 'stats': stats_m}

async def handle_conn(reader, writer, mode):
    safe = mode == 'safe'
    sem = asyncio.Semaphore(MAX_INFLIGHT)
    inflight = 0
    tasks = set()
    wlock = asyncio.Lock()

    async def send(b):
        async with wlock:
            writer.write(b); await writer.drain()

    async def run(req_id, obj):
        nonlocal inflight
        inflight += 1; stats['peak_inflight'] = max(stats['peak_inflight'], inflight)
        try:
            m = obj.get('method')
            if m == '_close_conn':                 # 测试钩子：模拟对端断连
                await asyncio.sleep(0.05); writer.transport.abort(); return
            h = REGISTRY.get(m)
            if h is None:
                await send(encode(T_ERR, req_id, {'code': E_METHOD_NOT_FOUND, 'msg': m})); return
            if safe:
                try:
                    res = await h(obj.get('params', {}))
                except Exception as e:             # handler 异常 -> INTERNAL，不拖垮连接
                    await send(encode(T_ERR, req_id, {'code': E_INTERNAL, 'msg': type(e).__name__})); return
            else:
                try:
                    res = await h(obj.get('params', {}))
                except Exception:                  # naive：异常直接把整条连接搞挂
                    writer.transport.abort(); return
            await send(encode(T_RESP, req_id, {'result': res}))
        except (ConnectionError, OSError):
            pass
        finally:
            inflight -= 1
            if safe: sem.release()

    try:
        while True:
            if safe: await sem.acquire()          # 在途满了就先不读 -> 背压给对端
            try:
                ftype, req_id, obj = await read_frame(reader, check=safe)
            except ProtocolError as e:            # 协议错误：帧边界已不可信，回错误后关闭
                await send(encode(T_ERR, 0, {'code': e.code, 'msg': str(e)}))
                break
            t = asyncio.create_task(run(req_id, obj)); tasks.add(t); t.add_done_callback(tasks.discard)
    except (asyncio.IncompleteReadError, ConnectionError, ValueError):
        pass
    finally:
        try: writer.close()
        except Exception: pass

async def main():
    port, mode = int(sys.argv[1]), sys.argv[2]
    srv = await asyncio.start_server(lambda r, w: handle_conn(r, w, mode), '127.0.0.1', port)
    print('READY', mode, port, flush=True)
    async with srv: await srv.serve_forever()

if __name__ == '__main__':
    asyncio.run(main())
