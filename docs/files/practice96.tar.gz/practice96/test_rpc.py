"""对照实验：naive vs safe。用法: python3 test_rpc.py SAFE_PORT NAIVE_PORT"""
import asyncio, socket, struct, sys, time, json
from proto import *
from client import SafeClient, NaiveClient, RpcError, RpcTimeout, ConnectionClosed

SAFE, NAIVE = int(sys.argv[1]), int(sys.argv[2])
R = {}; FAIL = []
def check(name, cond):
    print(('PASS ' if cond else 'FAIL ') + name, flush=True)
    if not cond: FAIL.append(name)

async def burst(cls, port, n=5000, conc=200):
    """一条连接上 n 个并发请求（最多 conc 个在途），统计错配/丢失/重复"""
    c = cls(); await c.connect(port)
    sem = asyncio.Semaphore(conc); got = {}; mism = 0; errs = 0; peak = 0
    async def one(aid):
        nonlocal mism, errs, peak
        async with sem:
            peak = max(peak, len(c.pending) + 1)
            try:
                r = await c.call('get_read_count', {'article_id': aid}, timeout=3)
                got[aid] = got.get(aid, 0) + 1
                if r['article_id'] != aid or r['read_count'] != aid * 7: mism += 1
            except Exception: errs += 1
    t0 = time.perf_counter()
    await asyncio.gather(*(one(i) for i in range(1, n + 1)))
    dt = time.perf_counter() - t0
    left = len(c.pending); await c.close()
    return dict(n=n, mismatch=mism, errors=errs, answered=len(got),
                dup=sum(v - 1 for v in got.values()), pending_after=left,
                peak_pending=peak, secs=round(dt, 2))

async def t_timeout(cls, port):
    """10 个 slow(300ms) 以 100ms 超时；超时后立即并发 20 个 echo"""
    c = cls(); await c.connect(port)
    async def s(i):
        try: await c.call('slow', {'delay': 0.3, 'tag': i}, timeout=0.1); return 'ok'
        except RpcTimeout: return 'timeout'
    res = await asyncio.gather(*(s(i) for i in range(10)))
    pend_after_timeout = len(c.pending)
    async def e(i):
        try:
            r = await c.call('echo', {'i': i}, timeout=1)
            return 'ok' if r == {'i': i} else 'wrong'
        except RpcTimeout: return 'timeout'
        except Exception: return 'error'
    er = await asyncio.gather(*(e(i) for i in range(20)))
    await asyncio.sleep(0.4)
    out = dict(slow_timeouts=res.count('timeout'), pending_after_timeout=pend_after_timeout,
               echo_ok=er.count('ok'), echo_wrong=er.count('wrong'), echo_timeout=er.count('timeout'),
               pending_final=len(c.pending), late=c.stat['late_or_unknown'])
    await c.close(); return out

async def t_disconnect(cls, port):
    """20 个 slow(2s) 在途时，服务端断开连接；看等待者多久被唤醒"""
    c = cls(); await c.connect(port)
    t0 = time.perf_counter()
    calls = [asyncio.create_task(c.call('slow', {'delay': 2}, timeout=None)) for _ in range(20)]
    await asyncio.sleep(0.01)
    c.writer.write(encode(T_REQ, 999999, {'method': '_close_conn'}))
    done, notdone = await asyncio.wait(calls, timeout=1.0)
    woke = [time.perf_counter() - t0 for _ in done]
    kinds = [type(t.exception()).__name__ for t in done]
    for t in notdone: t.cancel()
    after = None
    try: await c.call('echo', {}, timeout=0.5); after = 'ok'
    except ConnectionClosed: after = 'ConnectionClosed'
    except Exception as e: after = type(e).__name__
    return dict(woken=len(done), hung_after_1s=len(notdone),
                closed_errors=kinds.count('ConnectionClosed'),
                pending_after=len(c.pending), new_call=after)

def raw(port, payload, wait=1.0):
    """发畸形帧，返回 (服务端回的错误码, 连接是否被服务端关闭, 耗时ms)"""
    s = socket.create_connection(('127.0.0.1', port)); s.settimeout(wait)
    t0 = time.perf_counter(); s.sendall(payload)
    buf = b''; closed = False
    try:
        while True:
            d = s.recv(65536)
            if not d: closed = True; break
            buf += d
    except socket.timeout: pass
    ms = round((time.perf_counter() - t0) * 1000, 1); s.close()
    code = None
    if len(buf) >= 16:
        _, _, _, _, bl = HDR.unpack(buf[:16]); code = json.loads(buf[16:16 + bl])['code']
    return code, closed, ms

async def t_handler_fault(cls, port):
    """同一连接：1 个 boom（handler 抛异常）+ 1 个未注册方法 + 10 个 echo"""
    c = cls(); await c.connect(port)
    async def call(m, p):
        try: return ('ok', await c.call(m, p, timeout=1))
        except RpcError as e: return ('rpcerr', e.code)
        except Exception as e: return ('fail', type(e).__name__)
    jobs = [call('boom', {}), call('no_such', {})] + [call('slow', {'delay': 0.05, 'tag': i}) for i in range(10)]
    r = await asyncio.gather(*jobs)
    await c.close()
    return dict(boom=r[0], unknown=r[1], echo_ok=sum(1 for x in r[2:] if x[0] == 'ok'))

async def main():
    print('== 1. 单连接并发 5000 请求（服务端随机延迟 -> 乱序回包）')
    R['burst_naive'] = await burst(NaiveClient, NAIVE); print('naive', R['burst_naive'])
    R['burst_safe'] = await burst(SafeClient, SAFE);   print('safe ', R['burst_safe'])
    b = R['burst_safe']
    check('naive FIFO 匹配出现错配', R['burst_naive']['mismatch'] > 0)
    check('safe 不丢不重不错配', b['mismatch'] == 0 and b['errors'] == 0 and b['answered'] == b['n'] and b['dup'] == 0)
    check('safe pending 有界(<=200)且结束归零', b['peak_pending'] <= 200 and b['pending_after'] == 0)

    print('== 2. 超时后晚到响应')
    R['to_naive'] = await t_timeout(NaiveClient, NAIVE); print('naive', R['to_naive'])
    R['to_safe'] = await t_timeout(SafeClient, SAFE);   print('safe ', R['to_safe'])
    check('naive 超时不清理 -> 后续 echo 被误投/超时', R['to_naive']['echo_ok'] < 20)
    check('safe 超时即删 pending，echo 全对，晚到响应被丢弃计数',
          R['to_safe']['pending_after_timeout'] == 0 and R['to_safe']['echo_ok'] == 20
          and R['to_safe']['late'] == 10 and R['to_safe']['pending_final'] == 0)

    print('== 3. 在途请求时连接断开')
    R['dc_naive'] = await t_disconnect(NaiveClient, NAIVE); print('naive', R['dc_naive'])
    R['dc_safe'] = await t_disconnect(SafeClient, SAFE);   print('safe ', R['dc_safe'])
    check('naive 断连后等待者挂起', R['dc_naive']['hung_after_1s'] == 20)
    check('safe 断连 fail_all：20 个全部 ConnectionClosed、pending 归零、新调用快速失败',
          R['dc_safe']['closed_errors'] == 20 and R['dc_safe']['pending_after'] == 0
          and R['dc_safe']['new_call'] == 'ConnectionClosed')

    print('== 4. 畸形帧')
    huge = HDR.pack(MAGIC, VERSION, T_REQ, 1, 0x7FFFFFFF)
    bad = HDR.pack(b'GE', VERSION, T_REQ, 1, 5) + b'hello'
    badver = HDR.pack(MAGIC, 9, T_REQ, 1, 2) + b'{}'
    for name, port in (('naive', NAIVE), ('safe', SAFE)):
        R[f'mal_{name}'] = {'huge_len': raw(port, huge), 'bad_magic': raw(port, bad), 'bad_version': raw(port, badver)}
        print(name, R[f'mal_{name}'])
    m = R['mal_safe']
    check('safe 超长 body_len -> FRAME_TOO_LARGE 并关闭', m['huge_len'][:2] == ('FRAME_TOO_LARGE', True))
    check('safe 错 magic -> BAD_MAGIC 并关闭', m['bad_magic'][:2] == ('BAD_MAGIC', True))
    check('safe 错版本 -> BAD_VERSION 并关闭', m['bad_version'][:2] == ('BAD_VERSION', True))
    check('naive 超长 body_len 连接被挂住 1s 无回应', R['mal_naive']['huge_len'][:2] == (None, False))
    c = SafeClient(); await c.connect(SAFE)
    check('safe 畸形帧后服务仍正常', (await c.call('echo', {'x': 1})) == {'x': 1}); await c.close()

    print('== 5. handler 异常与未注册方法')
    R['hf_naive'] = await t_handler_fault(NaiveClient, NAIVE); print('naive', R['hf_naive'])
    R['hf_safe'] = await t_handler_fault(SafeClient, SAFE);   print('safe ', R['hf_safe'])
    s = R['hf_safe']
    check('safe boom->INTERNAL, 未注册->METHOD_NOT_FOUND, 同连接 10 个调用全部成功',
          s['boom'] == ('rpcerr', 'INTERNAL') and s['unknown'] == ('rpcerr', 'METHOD_NOT_FOUND') and s['echo_ok'] == 10)
    check('naive handler 异常拖垮整条连接', R['hf_naive']['echo_ok'] < 10)

    print('== 6. 服务端每连接在途上限（背压）')
    c = SafeClient(); await c.connect(SAFE)
    await asyncio.gather(*(c.call('slow', {'delay': 0.2}, timeout=5) for _ in range(300)))
    st = await c.call('stats', {}); await c.close()
    print('safe server peak_inflight', st['peak_inflight'])
    check('safe 服务端每连接在途 <= 64', st['peak_inflight'] <= 64)

    json.dump(R, open('results.json', 'w'), ensure_ascii=False, indent=1)
    print('ALL_CHECKS_PASSED' if not FAIL else f'FAILED: {FAIL}')
    sys.exit(1 if FAIL else 0)

asyncio.run(main())
