#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
SP=${SP:-19601}; NP=${NP:-19602}
python3 server.py $SP safe  > safe.log 2>&1 & S1=$!
python3 server.py $NP naive > naive.log 2>&1 & S2=$!
trap 'kill $S1 $S2 2>/dev/null' EXIT
for i in $(seq 50); do grep -q READY safe.log && grep -q READY naive.log && break; sleep 0.1; done
python3 test_rpc.py $SP $NP
