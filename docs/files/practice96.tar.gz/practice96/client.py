"""教学RPC客户端：SafeClient（req_id 匹配）与 NaiveClient（FIFO 匹配）"""
import asyncio, collections, itertools
from proto import *

class RpcError(Exception):
    def __init__(self, code, msg=''):
        super().__init__(f'{code}: {msg}'); self.code = code
class ConnectionClosed(Exception): pass
class RpcTimeout(Exception): pass

class SafeClient:
    def __init__(self):
        self.pending = {}                 # req_id -> Future
        self.ids = itertools.count(1)     # 连接内单调递增，0 保留给连接级错误
        self.closed = None
        self.stat = collections.Counter()

    async def connect(self, port):
        self.reader, self.writer = await asyncio.open_connection('127.0.0.1', port)
        self.reader_task = asyncio.create_task(self._read_loop())

    async def call(self, method, params=None, timeout=1.0):
        if self.closed: raise ConnectionClosed(self.closed)
        rid = next(self.ids)
        fut = asyncio.get_running_loop().create_future()
        self.pending[rid] = fut                       # 先登记再发送
        self.writer.write(encode(T_REQ, rid, {'method': method, 'params': params or {}}))
        try:
            await self.writer.drain()
            return await asyncio.wait_for(asyncio.shield(fut), timeout)
        except asyncio.TimeoutError:
            self.stat['timeout'] += 1
            raise RpcTimeout(f'{method} rid={rid}') from None
        finally:
            self.pending.pop(rid, None)               # 无论成功/超时/断连都删除 -> 有界

    async def _read_loop(self):
        reason = 'EOF'
        try:
            while True:
                ftype, rid, obj = await read_frame(self.reader)
                fut = self.pending.pop(rid, None)     # pop：只完成一次
                if fut is None or fut.done():
                    self.stat['late_or_unknown'] += 1  # 晚到/未知/重复响应：丢弃并计数
                    continue
                if ftype == T_RESP: fut.set_result(obj['result'])
                else: fut.set_exception(RpcError(obj['code'], obj.get('msg', '')))
        except (asyncio.IncompleteReadError, ConnectionError, ProtocolError) as e:
            reason = type(e).__name__
        finally:
            self._fail_all(reason)

    def _fail_all(self, reason):
        self.closed = reason
        for rid, fut in list(self.pending.items()):
            if not fut.done(): fut.set_exception(ConnectionClosed(reason))
        self.pending.clear()

    async def close(self):
        self.writer.close(); self.reader_task.cancel()


class NaiveClient:
    """常见错误写法：假设响应按发送顺序回来；超时不清理；断连不通知。"""
    def __init__(self):
        self.queue = collections.deque()
        self.stat = collections.Counter()

    async def connect(self, port):
        self.reader, self.writer = await asyncio.open_connection('127.0.0.1', port)
        self.reader_task = asyncio.create_task(self._read_loop())

    @property
    def pending(self): return self.queue

    async def call(self, method, params=None, timeout=1.0):
        fut = asyncio.get_running_loop().create_future()
        self.queue.append(fut)
        self.writer.write(encode(T_REQ, 0, {'method': method, 'params': params or {}}))
        await self.writer.drain()
        try:
            return await asyncio.wait_for(asyncio.shield(fut), timeout)
        except asyncio.TimeoutError:
            raise RpcTimeout(method) from None       # 不从队列里删

    async def _read_loop(self):
        try:
            while True:
                ftype, _rid, obj = await read_frame(self.reader, check=False)
                fut = self.queue.popleft()           # FIFO：最早的请求拿走这个响应
                if fut.done(): continue
                if ftype == T_RESP: fut.set_result(obj['result'])
                else: fut.set_exception(RpcError(obj['code']))
        except Exception:
            pass                                     # 断连：静默退出，等待者无人唤醒

    async def close(self):
        self.writer.close(); self.reader_task.cancel()
