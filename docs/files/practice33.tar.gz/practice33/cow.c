// fork 后父子各自修改变量：地址相同，值互不影响（写时复制）
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
int counter = 100;
int main(void) {
    pid_t pid = fork();
    if (pid == 0) { counter += 1; printf("child  pid=%d ppid=%d &counter=%p counter=%d\n", getpid(), getppid(), (void*)&counter, counter); return 0; }
    waitpid(pid, NULL, 0);
    printf("parent pid=%d          &counter=%p counter=%d\n", getpid(), (void*)&counter, counter);
    return 0;
}
