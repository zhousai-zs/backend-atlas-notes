// 反例：父进程不 wait，子进程退出后成为僵尸
#include <stdio.h>
#include <unistd.h>
int main(void) {
    pid_t pid = fork();
    if (pid == 0) _exit(0);
    printf("child=%d\n", pid); fflush(stdout);
    sleep(2);   // 这段时间里 ps 能看到 <defunct>
    return 0;
}
