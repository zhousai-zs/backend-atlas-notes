// 小型命令启动器：每个参数是一条命令（用空格分词），并发启动，收集退出码，回收所有子进程
#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAXARGS 32

int main(int argc, char *argv[]) {
    if (argc < 2) { fprintf(stderr, "usage: %s \"cmd args\" ...\n", argv[0]); return 2; }
    int n = argc - 1, failed = 0;
    pid_t pids[64];
    for (int i = 0; i < n; i++) {
        char *buf = strdup(argv[i + 1]);
        char *args[MAXARGS]; int k = 0;
        for (char *t = strtok(buf, " "); t && k < MAXARGS - 1; t = strtok(NULL, " ")) args[k++] = t;
        args[k] = NULL;
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
            execvp(args[0], args);
            // 只有 exec 失败才会走到这里：成功时进程映像已被替换
            fprintf(stderr, "exec %s: %s\n", args[0], strerror(errno));
            _exit(127);   // 用 _exit，避免刷新从父进程继承的 stdio 缓冲
        }
        pids[i] = pid;
        printf("started [%d] pid=%d: %s\n", i, pid, argv[i + 1]);
        fflush(stdout);
        free(buf);
    }
    int reaped = 0;
    for (;;) {
        int st;
        pid_t pid = waitpid(-1, &st, 0);
        if (pid < 0) {
            if (errno == EINTR) continue;
            if (errno == ECHILD) break;     // 已无子进程
            perror("waitpid"); return 1;
        }
        int idx = -1;
        for (int i = 0; i < n; i++) if (pids[i] == pid) idx = i;
        reaped++;
        if (WIFEXITED(st)) {
            printf("reaped [%d] pid=%d exit=%d\n", idx, pid, WEXITSTATUS(st));
            if (WEXITSTATUS(st) != 0) failed++;
        } else if (WIFSIGNALED(st)) {
            printf("reaped [%d] pid=%d signal=%d\n", idx, pid, WTERMSIG(st));
            failed++;
        }
    }
    printf("summary: started=%d reaped=%d failed=%d\n", n, reaped, failed);
    return failed ? 1 : 0;
}
