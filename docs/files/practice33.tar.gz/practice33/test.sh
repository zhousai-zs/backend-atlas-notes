#!/bin/bash
set -u
cd "$(dirname "$0")"
gcc -Wall -Wextra -O1 -o launcher launcher.c && gcc -Wall -o zombie zombie.c && gcc -Wall -o cow cow.c || exit 1
ok=1
echo "== 1. 写时复制 =="; ./cow
echo "== 2. 启动器：成功/失败/找不到命令/被信号杀 =="
./launcher "true" "ls /no/such/path" "no_such_cmd_xyz" "sleep 0.2" "sh -c kill\$IFS-9\$IFS\$\$" > out.txt 2>err.txt; rc=$?
cat out.txt err.txt
grep -q "summary: started=5 reaped=5" out.txt || { echo "FAIL reap"; ok=0; }
grep -q "exit=2" out.txt && grep -q "exit=127" out.txt || { echo "FAIL 127"; ok=0; }
grep -q "signal=9" out.txt || { echo "FAIL signal"; ok=0; }
[ $rc -eq 1 ] || { echo "FAIL rc=$rc"; ok=0; }
echo "== 3. 启动器跑完后无僵尸 =="
./launcher "sleep 0.3" "sleep 0.3" & L=$!
sleep 0.1; echo "运行中子进程:"; ps -o pid,ppid,stat,cmd --ppid $L
wait $L
z=$(ps -eo ppid,stat | awk -v p=$L '$1==p && $2 ~ /Z/' | wc -l); echo "zombies of launcher: $z"; [ $z -eq 0 ] || ok=0
echo "== 4. 反例：不 wait 产生僵尸 =="
./zombie > z.txt & Z=$!; sleep 0.5
ps -o pid,ppid,stat,cmd --ppid $Z | tee zps.txt
grep -q "defunct" zps.txt || { echo "FAIL zombie demo"; ok=0; }
wait $Z
echo "== 5. strace 看 exec 成功不返回 =="
if command -v strace >/dev/null; then strace -f -e trace=execve,clone,wait4,exit_group ./launcher "true" 2>&1 | tail -n 8; else echo "(无 strace，跳过)"; fi
[ $ok -eq 1 ] && echo ALL_CHECKS_PASSED || echo SOME_CHECKS_FAILED
