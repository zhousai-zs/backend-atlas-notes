#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["engine"]=="bwrap" and not r["is_docker"] and not r["is_gvisor"] and not r["used_sudo"]
assert "tool_not_allowed:curl" in r["denied_tool"]
assert "path_outside_workspace" in r["denied_path"]
assert r["os_blocks_direct_secret"]["ok"] is False
assert r["os_blocks_escaping_symlink"]["leaked_token"] is False
assert r["os_blocks_shadow_symlink"]["leaked"] is False
assert r["memory_limit"]["reason"]=="memory_limit" and r["memory_limit"]["returncode"] != 137
assert r["cpu_limit"]["reason"]=="cpu_limit" and r["cpu_limit"]["returncode"] in (24, 152)
assert r["nproc_limit"]["reason"]=="nproc_limit"
assert r["timeout_cleanup"]["workspace_destroyed"] and r["timeout_cleanup"]["orphans"]==[]
assert r["uncovered"]
print("POSTCHECK_OK")
PY
