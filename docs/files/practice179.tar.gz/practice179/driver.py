#!/usr/bin/env python3
"""Real bwrap sandbox: path/symlink isolation, rlimits, timeout cleanup."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

from sandbox import DeniedByPolicy, Sandbox, BWRAP

ROOT = Path(__file__).resolve().parent
assert Path(BWRAP).is_file(), "bwrap must exist; do not fall back to a pretend engine"

# Host secret OUTSIDE any workspace
host_secret = Path("/tmp/host-secret-179")
host_secret.write_text("SUPERSECRET_TOKEN=do-not-leak\n")
host_secret.chmod(0o600)

box = Sandbox(ROOT / "reports/sbx")
# A file the tool is allowed to read
(box.workspace / "notes.txt").write_text("alpha-line-1\n")
# Escaping symlink to the host secret and to /etc/shadow
(box.workspace / "escape").symlink_to(str(host_secret))
(box.workspace / "shadow").symlink_to("/etc/shadow")

# 1) legitimate read inside workspace
ok_read = box.run("head", ["-n", "1", "/workspace/notes.txt"])
assert ok_read["ok"] and "alpha-line-1" in ok_read["stdout"], ok_read

# 2) app-level policy: tool not in whitelist
denied_tool = None
try:
    box.run("curl", ["https://example.com"])
except DeniedByPolicy as e:
    denied_tool = str(e)
assert denied_tool and "tool_not_allowed:curl" in denied_tool

# 3) app-level policy: absolute path outside /workspace
denied_path = None
try:
    box.run("cat", [str(host_secret)])
except DeniedByPolicy as e:
    denied_path = str(e)
assert denied_path and "path_outside_workspace" in denied_path

# 4) OS layer: even if policy is skipped, a direct host path is not mounted
os_direct = box.run("cat", [str(host_secret)], skip_policy=True)
assert not os_direct["ok"]
assert "No such file or directory" in (os_direct["stderr"] + os_direct["stdout"])

# 5) OS layer: escaping symlink does not reveal the secret
os_link = box.run("cat", ["/workspace/escape"])  # path is under /workspace, policy allows
assert "SUPERSECRET_TOKEN" not in (os_link["stdout"] + os_link["stderr"])
assert "No such file or directory" in (os_link["stderr"] + os_link["stdout"]) or not os_link["ok"]

os_shadow = box.run("cat", ["/workspace/shadow"])
assert "root:" not in (os_shadow["stdout"] + os_shadow["stderr"])
assert not os_shadow["ok"]

# 6) memory over-limit: 32 MiB AS, 128 MiB alloc → MemoryError / exit 2, NOT cgroup 137
mem = box.run("alloc_mem", [str(128 * 1024 * 1024)], as_bytes=32 * 1024 * 1024, timeout_s=5)
assert mem["reason"] == "memory_limit" and mem["returncode"] in {1, 2}
assert mem["returncode"] != 137, "do not claim a cgroup OOM that this box cannot produce"

# 7) CPU over-limit: soft=1 hard=2 → SIGXCPU handler exits 24
cpu = box.run("busy_cpu", cpu_s=1, timeout_s=8)
assert cpu["reason"] == "cpu_limit" and cpu["returncode"] in {24, 152}, cpu

# 8) process over-limit inside the user namespace
nproc = box.run("fork_many", ["30"], nproc=8, timeout_s=5)
assert nproc["reason"] == "nproc_limit"
assert "Resource temporarily unavailable" in nproc["stdout"]

# 9) timeout: no orphans, workspace destroyed
box2 = Sandbox(ROOT / "reports/sbx-timeout")
(box2.workspace / "keep.txt").write_text("x")
alive_before = Path(f"/proc/{os.getpid()}").exists()  # sanity
timed = box2.run("sleep", ["30"], timeout_s=0.4)
assert timed["reason"] == "timeout"
assert not box2.alive
assert not box2.root.exists(), "workspace must be destroyed after timeout"
# Give the kernel a beat, then look for leftover sleep/bwrap children related to this run
time.sleep(0.2)
orphans = []
# /proc scan: any leftover 'sleep 30' that is not ours
for p in Path("/proc").iterdir():
    if not p.name.isdigit():
        continue
    try:
        cmd = (p / "cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", "replace")
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        continue
    if "sleep 30" in cmd or (cmd.strip().endswith("sleep 30")):
        orphans.append((p.name, cmd))
assert orphans == [], orphans

# 10) cancel path is the same destroy (already destroyed box2); cancel a third box mid-flight
# covered by timeout == cancel-by-deadline.

uncovered = [
    "kernel_exploits_and_shared_kernel_escapes (no gVisor/runsc, no VM; this is a user-namespace bwrap)",
    "no_Docker_or_podman_engine_on_this_machine",
    "writable_cgroup_OOM_kill (mkdir of a child cgroup is Permission denied; RLIMIT_AS is MemoryError/exit 2, not 137)",
    "seccomp_filter_not_installed_in_this_lab",
    "if_network_were_enabled_the_remote_service_is_outside_the_sandbox",
    "ro-bind_of_/usr_and_/bin_is_trusted_supply_chain_of_those_binaries",
]

results = {
    "lesson": 179,
    "id": "l-sandbox",
    "engine": "bwrap",
    "bwrap_path": BWRAP,
    "is_docker": False,
    "is_gvisor": False,
    "used_sudo": False,
    "ok_read_workspace": ok_read["stdout"].strip(),
    "denied_tool": denied_tool,
    "denied_path": denied_path,
    "os_blocks_direct_secret": {
        "ok": os_direct["ok"],
        "stderr": os_direct["stderr"].strip()[:200],
    },
    "os_blocks_escaping_symlink": {
        "ok": os_link["ok"],
        "stdout": os_link["stdout"],
        "stderr": os_link["stderr"].strip()[:200],
        "leaked_token": "SUPERSECRET_TOKEN" in (os_link["stdout"] + os_link["stderr"]),
    },
    "os_blocks_shadow_symlink": {"ok": os_shadow["ok"], "leaked": "root:" in (os_shadow["stdout"] + os_shadow["stderr"])},
    "memory_limit": {"reason": mem["reason"], "returncode": mem["returncode"], "stderr_tail": mem["stderr"][-300:]},
    "cpu_limit": {"reason": cpu["reason"], "returncode": cpu["returncode"], "elapsed_s": cpu["elapsed_s"]},
    "nproc_limit": {"reason": nproc["reason"], "stdout": nproc["stdout"].strip()},
    "timeout_cleanup": {"reason": timed["reason"], "workspace_destroyed": not Path(ROOT / "reports/sbx-timeout").exists(), "orphans": orphans},
    "uncovered": uncovered,
    "verified_on_this_machine": [
        "real_bwrap_unshare_user_pid_net_uts_die_with_parent",
        "host_secret_and_escaping_symlink_not_readable",
        "app_whitelist_rejects_unknown_tool_and_outside_path",
        "RLIMIT_AS_MemoryError_exit_2_not_cgroup_137",
        "RLIMIT_CPU_SIGXCPU_exit_24",
        "RLIMIT_NPROC_EAGAIN_inside_user_namespace",
        "timeout_kills_tree_and_destroys_workspace_no_orphans",
    ],
    "not_verified_on_this_machine": uncovered,
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
# leave the first workspace in place for inspection; secret file removed
try:
    host_secret.unlink()
except FileNotFoundError:
    pass
print(json.dumps({
    "mem": results["memory_limit"],
    "cpu": results["cpu_limit"],
    "nproc": results["nproc_limit"]["stdout"],
    "timeout": results["timeout_cleanup"],
    "symlink_leaked": results["os_blocks_escaping_symlink"]["leaked_token"],
}, indent=2))
print("ALL_CHECKS_PASSED")
