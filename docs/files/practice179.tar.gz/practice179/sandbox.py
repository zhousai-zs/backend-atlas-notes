"""Tool sandbox based on a real bubblewrap (bwrap) process, not a Docker/gVisor mock.

This machine has /usr/bin/bwrap but no docker, podman, gVisor/runsc, or
writable cgroup tree (mkdir of a child cgroup is Permission denied; we do
not claim a cgroup OOM of 137). Memory pressure is enforced with RLIMIT_AS
and surfaces as Python MemoryError (exit 2). CPU uses RLIMIT_CPU (SIGXCPU,
exit 24 when soft < hard). Process count uses RLIMIT_NPROC inside a fresh
user namespace (EAGAIN).

Layers:
  1. App-level whitelist of tools and of paths under the workspace.
  2. OS-level bwrap: bind only the workspace (rw) plus a minimal ro /usr,/bin,/lib;
     tmpfs on /tmp and /home; no /etc; --unshare-user/pid/net/uts; --die-with-parent.

Uncovered (stated, not tested): kernel exploits, shared-kernel escapes,
missing seccomp profile, gVisor/VM isolation, writable cgroups, and any
network call we might later allow — the remote service is outside the box.
"""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

BWRAP = "/usr/bin/bwrap"
ALLOWED_TOOLS = {"echo", "head", "python3", "busy_cpu", "alloc_mem", "fork_many", "sleep", "cat"}


class DeniedByPolicy(Exception):
    pass


class Sandbox:
    def __init__(self, root: Path):
        self.root = Path(root)
        if self.root.exists():
            shutil.rmtree(self.root)
        self.root.mkdir(parents=True)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        self.alive = True

    def destroy(self):
        self.alive = False
        if self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)

    def _policy(self, tool: str, args: list[str]):
        if tool not in ALLOWED_TOOLS:
            raise DeniedByPolicy(f"tool_not_allowed:{tool}")
        for a in args:
            if a.startswith("-"):
                continue
            # Absolute paths must stay under /workspace (the in-sandbox mount of self.workspace).
            if a.startswith("/") and not a.startswith("/workspace"):
                raise DeniedByPolicy(f"path_outside_workspace:{a}")

    def _bwrap_cmd(self, inner: list[str]) -> list[str]:
        return [
            BWRAP,
            "--die-with-parent",
            "--unshare-user",
            "--unshare-pid",
            "--unshare-net",
            "--unshare-uts",
            "--unshare-cgroup-try",
            "--hostname", "sandbox",
            "--uid", "1000",
            "--gid", "1000",
            "--ro-bind", "/usr", "/usr",
            "--ro-bind", "/bin", "/bin",
            "--ro-bind", "/lib", "/lib",
            "--ro-bind-try", "/lib64", "/lib64",
            "--proc", "/proc",
            "--dev", "/dev",
            "--tmpfs", "/tmp",
            "--tmpfs", "/home",
            "--bind", str(self.workspace), "/workspace",
            "--chdir", "/workspace",
            "--clearenv",
            "--setenv", "PATH", "/usr/bin:/bin",
            "--setenv", "HOME", "/tmp",
            "--setenv", "LANG", "C",
            "--setenv", "PYTHONDONTWRITEBYTECODE", "1",
            "--",
            *inner,
        ]

    def run(
        self,
        tool: str,
        args: list[str] | None = None,
        *,
        timeout_s: float = 8.0,
        as_bytes: int | None = None,
        cpu_s: int | None = None,
        nproc: int | None = None,
        skip_policy: bool = False,
    ) -> dict:
        """Run one tool. skip_policy=True is only used to demonstrate the OS layer
        after an app-level whitelist has been mistakenly bypassed."""
        args = list(args or [])
        if not skip_policy:
            self._policy(tool, args)
        if not self.alive:
            return {"ok": False, "reason": "workspace_destroyed", "returncode": None}

        limiter = self.workspace / ".limiter.py"
        limiter.write_text(
            "import os, sys, resource, signal\n"
            "as_bytes = int(os.environ.get('SBX_AS') or '0')\n"
            "cpu_s = int(os.environ.get('SBX_CPU') or '0')\n"
            "nproc = int(os.environ.get('SBX_NPROC') or '0')\n"
            "if as_bytes:\n"
            "    resource.setrlimit(resource.RLIMIT_AS, (as_bytes, as_bytes))\n"
            "if cpu_s:\n"
            "    signal.signal(signal.SIGXCPU, lambda s,f: sys.exit(24))\n"
            "    resource.setrlimit(resource.RLIMIT_CPU, (cpu_s, cpu_s + 1))\n"
            "if nproc:\n"
            "    resource.setrlimit(resource.RLIMIT_NPROC, (nproc, nproc))\n"
            "os.execvp(sys.argv[1], sys.argv[1:])\n"
        )
        inner = ["/usr/bin/python3", "/workspace/.limiter.py"]
        if tool == "python3":
            inner += ["/usr/bin/python3", *args]
        elif tool == "echo":
            inner += ["/bin/echo", *args]
        elif tool == "head":
            inner += ["/usr/bin/head", *args]
        elif tool == "cat":
            inner += ["/bin/cat", *args]
        elif tool == "sleep":
            inner += ["/bin/sleep", *args]
        elif tool == "busy_cpu":
            inner += ["/usr/bin/python3", "-c", "import signal,sys\nsignal.signal(signal.SIGXCPU, lambda s,f: sys.exit(24))\nx=0\nwhile True:\n x += 1"]
        elif tool == "alloc_mem":
            nbytes = int(args[0]) if args else 256 * 1024 * 1024
            inner += ["/usr/bin/python3", "-c", f"bytearray({nbytes}); print('ALLOC_OK')"]
        elif tool == "fork_many":
            n = int(args[0]) if args else 30
            inner += [
                "/usr/bin/python3",
                "-c",
                "import os,sys\n"
                f"ok=0\nfail=''\n"
                f"for i in range({n}):\n"
                "    try:\n"
                "        p=os.fork()\n"
                "        if p==0:\n"
                "            import time; time.sleep(2); os._exit(0)\n"
                "        ok += 1\n"
                "    except OSError as e:\n"
                "        fail=str(e); break\n"
                "print('forked', ok, 'fail', fail)\n"
                "sys.exit(3 if fail else 1)\n",
            ]
        else:
            # Unknown tools already rejected by policy; keep a fallback for skip_policy demos.
            inner += [tool, *args]

        env = os.environ.copy()
        # These are read by the limiter inside the sandbox; pass them as bwrap --setenv instead.
        cmd = self._bwrap_cmd(inner)
        # Inject SBX_* after --clearenv by inserting setenv flags before the final --
        dash = cmd.index("--")
        extra = []
        if as_bytes:
            extra += ["--setenv", "SBX_AS", str(as_bytes)]
        if cpu_s:
            extra += ["--setenv", "SBX_CPU", str(cpu_s)]
        if nproc:
            extra += ["--setenv", "SBX_NPROC", str(nproc)]
        cmd = cmd[:dash] + extra + cmd[dash:]

        t0 = time.monotonic()
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError as e:
            return {"ok": False, "reason": f"bwrap_missing:{e}", "returncode": None}

        reason = "ok"
        try:
            out, err = proc.communicate(timeout=timeout_s)
            rc = proc.returncode
        except subprocess.TimeoutExpired:
            # Kill the bwrap process; --die-with-parent + pid ns should reap children.
            proc.kill()
            try:
                out, err = proc.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                out, err = proc.communicate()
            rc = proc.returncode
            reason = "timeout"
            # Destroy workspace after timeout/cancel so nothing is reused.
            self.destroy()
        elapsed = time.monotonic() - t0

        if reason == "ok":
            if rc == 2 or "MemoryError" in (err or "") or "MemoryError" in (out or ""):
                reason = "memory_limit"
            elif rc in {24, 152}:  # 24 = handler; 152 = 128+SIGXCPU if exec reset the handler
                reason = "cpu_limit"
            elif rc == 137:
                reason = "killed_sigkill"
            elif tool == "fork_many" and "Resource temporarily unavailable" in (out or ""):
                reason = "nproc_limit"
            elif rc != 0:
                reason = f"exit_{rc}"

        return {
            "ok": rc == 0 and reason == "ok",
            "returncode": rc,
            "reason": reason,
            "stdout": out or "",
            "stderr": err or "",
            "elapsed_s": round(elapsed, 3),
            "pid": proc.pid,
        }
