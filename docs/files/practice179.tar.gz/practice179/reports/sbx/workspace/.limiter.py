import os, sys, resource, signal
as_bytes = int(os.environ.get('SBX_AS') or '0')
cpu_s = int(os.environ.get('SBX_CPU') or '0')
nproc = int(os.environ.get('SBX_NPROC') or '0')
if as_bytes:
    resource.setrlimit(resource.RLIMIT_AS, (as_bytes, as_bytes))
if cpu_s:
    signal.signal(signal.SIGXCPU, lambda s,f: sys.exit(24))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_s, cpu_s + 1))
if nproc:
    resource.setrlimit(resource.RLIMIT_NPROC, (nproc, nproc))
os.execvp(sys.argv[1], sys.argv[1:])
