# 实践 179：工具沙箱与权限隔离

在解压后的 `practice179/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv 与 /usr/bin/bwrap
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

真实 bubblewrap 用户/pid/net 命名空间。本机无 Docker/gVisor，也没有可写 cgroup。不要用 sudo。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
