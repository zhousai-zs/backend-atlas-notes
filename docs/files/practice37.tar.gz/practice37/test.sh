#!/bin/bash
set -u
cd "$(dirname "$0")"
gcc -O2 -Wall -fsanitize=address,undefined -o atomic_write atomic_write.c || exit 1
gcc -O2 -o naive_write naive_write.c || exit 1
ok=1; D=$(mktemp -d); F=$D/app.conf
OLD='{"version":1,"timeout_ms":200,"backends":["10.0.0.1","10.0.0.2"]}'
NEW='{"version":2,"timeout_ms":300,"backends":["10.0.0.1","10.0.0.2","10.0.0.3"]}'
check() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got [$2] want [$3]"; ok=0; fi; }
printf '%s' "$OLD" > $F
./atomic_write $F "$NEW" 1; check "crash_mid_write_keeps_old" "$(cat $F)" "$OLD"
./atomic_write $F "$NEW" 2; check "crash_before_rename_keeps_old" "$(cat $F)" "$OLD"
./atomic_write $F "$NEW" 0; check "normal_replace_new" "$(cat $F)" "$NEW"
rm -f $D/*.tmp.*
# 并发读者：反复读，只应看到完整旧版或完整新版
printf '%s' "$OLD" > $F
( for i in $(seq 1 300); do ./atomic_write $F "$([ $((i%2)) = 0 ] && echo "$OLD" | tr -d '\n' || echo "$NEW" | tr -d '\n')" 0; done ) &
bad=0; for i in $(seq 1 3000); do c=$(cat $F 2>/dev/null); [ "$c" = "$OLD" ] || [ "$c" = "$NEW" ] || bad=$((bad+1)); done; wait
check "reader_never_sees_partial" "$bad" "0"
# 反例
printf '%s' "$OLD" > $F
./naive_write $F "$NEW" 1
c=$(cat $F); if [ "$c" != "$OLD" ] && [ "$c" != "$NEW" ]; then echo "PASS naive_truncate_leaves_half_config (len=${#c})"; else echo "FAIL naive"; ok=0; fi
# strace 看系统调用顺序
if command -v strace >/dev/null; then
  gcc -O2 -o aw_plain atomic_write.c
  seq=$(strace -f -e trace=openat,write,fsync,rename,close ./aw_plain $F "$NEW" 0 2>&1 | grep -oE '^(openat|write|fsync|rename)' | grep -v '^openat$' | tr '\n' ' ')
  echo "strace sequence: $seq"
  echo "$seq" | grep -q 'write fsync rename fsync' && echo "PASS syscall_order" || { echo "FAIL syscall_order"; ok=0; }
fi
grep -E '^(Dirty|Writeback):' /proc/meminfo
rm -rf $D
[ $ok = 1 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
