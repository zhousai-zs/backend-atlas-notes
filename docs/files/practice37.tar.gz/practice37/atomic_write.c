// 原子替换配置文件：写临时文件 -> fsync -> rename -> fsync 目录
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int write_all(int fd, const char *p, size_t n) {
    while (n > 0) {
        ssize_t w = write(fd, p, n);
        if (w < 0) { if (errno == EINTR) continue; return -1; }
        p += w; n -= (size_t)w;
    }
    return 0;
}

// crash_at: 0=不崩溃, 1=写一半后崩溃, 2=fsync后rename前崩溃
int atomic_write(const char *path, const char *data, size_t len, int crash_at) {
    char tmp[4096], dirbuf[4096];
    snprintf(tmp, sizeof tmp, "%s.tmp.%d", path, getpid());
    int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
    if (fd < 0) return -1;
    if (crash_at == 1) { write_all(fd, data, len / 2); _exit(9); }
    if (write_all(fd, data, len) < 0 || fsync(fd) < 0) { close(fd); unlink(tmp); return -1; }
    if (close(fd) < 0) { unlink(tmp); return -1; }
    if (crash_at == 2) _exit(9);
    if (rename(tmp, path) < 0) { unlink(tmp); return -1; }
    snprintf(dirbuf, sizeof dirbuf, "%s", path);
    int dfd = open(dirname(dirbuf), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (dfd < 0) return -1;
    int r = fsync(dfd);
    close(dfd);
    return r;
}

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: %s path content crash_at\n", argv[0]); return 2; }
    if (atomic_write(argv[1], argv[2], strlen(argv[2]), atoi(argv[3])) < 0) { perror("atomic_write"); return 1; }
    return 0;
}
