// 反例：直接 O_TRUNC 覆盖原文件，写一半崩溃
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc, char **argv) {
    int fd = open(argv[1], O_WRONLY | O_TRUNC);
    size_t n = strlen(argv[2]);
    write(fd, argv[2], atoi(argv[3]) ? n / 2 : n);
    if (atoi(argv[3])) _exit(9);
    close(fd); return 0;
}
