#!/usr/bin/env python3
"""Teaching NumaEngine — not Redis, not a real profiler/NUMA product,
not a network service, and not a host numactl / perf / g++ /
/sys/devices/system/node measurement.

A Python 3 standard-library, virtual-clock model of a memory-dense
benchmark on a teaching two-node machine. The named source
(checked on 2026-11-14) is:

* Linux man-pages — numa(7), at
  https://man7.org/linux/man-pages/man7/numa.7.html
  (Linux man-pages 6.19, page date 2026-02-08). NUMA refers to
  multiprocessor systems whose memory is divided into multiple
  memory nodes. "The access time of a memory node depends on the
  relative locations of the accessing CPU and the accessed node."
  Normally each CPU has a local memory node that is faster than
  memory local to another CPU. The page does not use the phrase
  "first touch", does not define MPOL_* modes, and does not give
  bandwidth or latency numbers. It names set_mempolicy(2),
  mbind(2), get_mempolicy(2), migrate_pages(2), move_pages(2),
  numa(3), cpuset(7), and numactl(8), and notes the interfaces
  exist only if the kernel was built with CONFIG_NUMA.

Follow-through pages named by numa(7), also read on 2026-11-14:

* set_mempolicy(2) states that the thread policy "is applied only
  when a new page is allocated for the thread. For anonymous
  memory this is when the page is first touched by the thread."
  MPOL_DEFAULT falls back to the system default, which is "local
  allocation"—allocate memory on the node of the CPU that
  triggered the allocation. MPOL_BIND restricts allocation to the
  given nodes.

* numa(3) (numactl project) adds that on a NUMA architecture some
  memory areas have different latency or bandwidth than others,
  and that the default policy is local allocation. numa_bind()
  binds both CPU and memory; numa_run_on_node() runs the task on
  one node and "will not migrate to CPUs of other nodes until the
  node affinity is reset."

* numactl(8) separates --cpunodebind/--physcpubind (where the
  process may run) from --membind/--localalloc (where memory may
  be allocated). --touch enforces policy early; the default is to
  apply policy "when an applications maps and accesses a page."

This engine does not call host numactl, does not read
/sys/devices/system/node for its bandwidth or latency numbers,
and does not run a wall-clock STREAM-style benchmark. Times are
teaching virtual-clock values, not production RTT.
"""
from __future__ import annotations

from typing import Any


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"

MEASURE_S = 30.00
MEASURE_NS = 30_000_000_000
LINE_BYTES = 64
WORKSET_MIB = 256
# Teaching access costs (virtual ns per 64-byte line). Not host
# measurements, not ACPI SLIT values from this box, and not
# numbers printed in numa(7).
LOCAL_LAT_NS = 100
REMOTE_LAT_NS = 200

# Teaching topology — 教学假设, not this host (this box is 1 node).
TEACHING_NODES = 2
NODE_CPUS = {0: [0, 1, 2, 3], 1: [4, 5, 6, 7]}
ALL_CPUS = [0, 1, 2, 3, 4, 5, 6, 7]
HOST_NUMA_NODES = 1
HOST_SOCKETS = 1
HOST_CPUS = 8
HOST_UNAME_R = "6.12.113+"


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def node_of_cpu(cpu: int) -> int:
    for node, cpus in NODE_CPUS.items():
        if cpu in cpus:
            return node
    raise KeyError(cpu)


def access_lat_ns(cpu: int, page_node: int) -> int:
    return LOCAL_LAT_NS if node_of_cpu(cpu) == page_node else REMOTE_LAT_NS


def bandwidth_mb_s(lat_ns: float) -> float:
    """Teaching MB/s (10^6 bytes/s) for one thread scanning LINE_BYTES every lat_ns."""
    accesses = MEASURE_NS / lat_ns
    return ts(accesses * LINE_BYTES / MEASURE_S / 1_000_000, 2)


class NumaEngine:
    """Teaching model of local vs remote memory-dense runs."""

    def topology(self) -> dict[str, Any]:
        return {
            "teaching_nodes": TEACHING_NODES,
            "node_cpus": {str(k): list(v) for k, v in NODE_CPUS.items()},
            "all_cpus": list(ALL_CPUS),
            "topology_is_teaching_declaration": True,
            "host_numa_nodes": HOST_NUMA_NODES,
            "host_sockets": HOST_SOCKETS,
            "host_cpus": HOST_CPUS,
            "host_uname_r": HOST_UNAME_R,
            "host_numactl_invoked": False,
            "host_sysfs_node_used_for_results": False,
            "host_perf_invoked": False,
            "host_gxx_invoked": False,
        }

    def _run(
        self,
        name: str,
        threads: list[dict[str, Any]],
        *,
        mem_policy: str,
        eligible_cpus: list[int],
    ) -> dict[str, Any]:
        # Each thread scans the same teaching workset independently
        # for MEASURE_S (open-loop, virtual clock). Per-thread
        # bandwidths add; this additivity is a teaching assumption,
        # not a measured memory-controller limit.
        per: list[dict[str, Any]] = []
        total_mb_s = 0.0
        lat_sum = 0.0
        local_n = 0
        for th in threads:
            cpu = th["cpu"]
            page_node = th["page_node"]
            first_touch_cpu = th["first_touch_cpu"]
            lat = access_lat_ns(cpu, page_node)
            bw = bandwidth_mb_s(lat)
            is_local = node_of_cpu(cpu) == page_node
            if is_local:
                local_n += 1
            total_mb_s += bw
            lat_sum += lat
            per.append({
                "cpu": cpu,
                "thread_node": node_of_cpu(cpu),
                "first_touch_cpu": first_touch_cpu,
                "first_touch_node": node_of_cpu(first_touch_cpu),
                "page_node": page_node,
                "access": "local" if is_local else "remote",
                "latency_ns": lat,
                "bandwidth_mb_s": bw,
            })
        n = len(threads)
        return {
            "name": name,
            "n_threads": n,
            "mem_policy": mem_policy,
            "threads": per,
            "thread_cpus": [t["cpu"] for t in per],
            "thread_nodes": [t["thread_node"] for t in per],
            "page_nodes": [t["page_node"] for t in per],
            "mean_latency_ns": ts(lat_sum / n, 2),
            "bandwidth_mb_s": ts(total_mb_s, 2),
            "n_local_threads": local_n,
            "n_remote_threads": n - local_n,
            "eligible_cpus": list(eligible_cpus),
            "n_eligible_cpus": len(eligible_cpus),
            "workset_mib": WORKSET_MIB,
            "line_bytes": LINE_BYTES,
            "measure_s": MEASURE_S,
            "times_are_teaching_virtual_clock": True,
        }

    def compare(self) -> dict[str, Any]:
        topo = self.topology()
        same = self._run(
            "same_node",
            [{"cpu": 0, "page_node": 0, "first_touch_cpu": 0}],
            mem_policy="MPOL_DEFAULT/local allocation, first touch on node 0",
            eligible_cpus=[0],
        )
        cross = self._run(
            "cross_node",
            [{"cpu": 4, "page_node": 0, "first_touch_cpu": 0}],
            mem_policy="MPOL_DEFAULT already applied at first touch on node 0",
            eligible_cpus=[4],
        )
        # Acceptance: pinning the worker to node 0 does not move
        # pages that were first touched on node 1.
        pin_only = self._run(
            "pin_thread_only",
            [{"cpu": 0, "page_node": 1, "first_touch_cpu": 4}],
            mem_policy="thread pinned after first touch; pages stay on node 1",
            eligible_cpus=[0],
        )
        # CPU + memory policy set before first touch (numactl
        # --cpunodebind=0 --membind=0, then touch).
        pin_and_mem = self._run(
            "pin_and_membind",
            [{"cpu": 0, "page_node": 0, "first_touch_cpu": 0}],
            mem_policy="MPOL_BIND node 0, first touch after bind",
            eligible_cpus=[0],
        )
        two_local = self._run(
            "two_threads_same_node",
            [
                {"cpu": 0, "page_node": 0, "first_touch_cpu": 0},
                {"cpu": 1, "page_node": 0, "first_touch_cpu": 0},
            ],
            mem_policy="MPOL_DEFAULT, first touch on node 0, both threads on node 0",
            eligible_cpus=[0, 1, 2, 3],
        )
        two_unaware = self._run(
            "two_threads_ignore_topology",
            [
                {"cpu": 0, "page_node": 0, "first_touch_cpu": 0},
                {"cpu": 4, "page_node": 0, "first_touch_cpu": 0},
            ],
            mem_policy="MPOL_DEFAULT, first touch on node 0, threads split across nodes",
            eligible_cpus=list(ALL_CPUS),
        )
        unbound_flex = len(ALL_CPUS)
        bound_flex = pin_and_mem["n_eligible_cpus"]
        return {
            "process": PROCESS,
            "key": KEY_TITLE,
            "title": TITLE_V1,
            "measure_s": MEASURE_S,
            "local_lat_ns": LOCAL_LAT_NS,
            "remote_lat_ns": REMOTE_LAT_NS,
            "topology": topo,
            "same_node": same,
            "cross_node": cross,
            "pin_thread_only": pin_only,
            "pin_and_membind": pin_and_mem,
            "two_threads_same_node": two_local,
            "two_threads_ignore_topology": two_unaware,
            "reports_topology_and_thread_placement": (
                topo["teaching_nodes"] == 2
                and same["thread_cpus"] == [0]
                and cross["thread_cpus"] == [4]
                and pin_only["page_nodes"] == [1]
            ),
            "pinned_thread_does_not_imply_local_memory": (
                pin_only["threads"][0]["access"] == "remote"
                and pin_only["bandwidth_mb_s"] == cross["bandwidth_mb_s"]
                and pin_and_mem["threads"][0]["access"] == "local"
            ),
            "same_node_beats_cross": (
                same["bandwidth_mb_s"] > cross["bandwidth_mb_s"]
                and same["mean_latency_ns"] < cross["mean_latency_ns"]
            ),
            "binding_improves_locality": (
                pin_and_mem["threads"][0]["access"] == "local"
                and pin_and_mem["bandwidth_mb_s"] == same["bandwidth_mb_s"]
            ),
            "binding_reduces_scheduler_flexibility": bound_flex < unbound_flex,
            "more_threads_without_topology_scales_worse": (
                two_unaware["bandwidth_mb_s"] < two_local["bandwidth_mb_s"]
            ),
        }
