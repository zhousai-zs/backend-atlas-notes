#!/usr/bin/env python3
"""Acceptance checks for the lesson 136 teaching NUMA experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "NumaEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["local_lat_ns"] == 100 and r["remote_lat_ns"] == 200
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_numa_product"]
    assert r["not_host_numactl"] and r["not_host_sysfs_node"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]

    topo = r["topology"]
    assert topo["teaching_nodes"] == 2
    assert topo["node_cpus"] == {"0": [0, 1, 2, 3], "1": [4, 5, 6, 7]}
    assert topo["topology_is_teaching_declaration"] is True
    assert topo["host_numa_nodes"] == 1 and topo["host_sockets"] == 1
    assert topo["host_cpus"] == 8 and topo["host_uname_r"] == "6.12.113+"
    assert topo["host_numactl_invoked"] is False
    assert topo["host_sysfs_node_used_for_results"] is False

    same, cross = r["same_node"], r["cross_node"]
    assert same["bandwidth_mb_s"] == 640.0 and same["mean_latency_ns"] == 100.0
    assert same["thread_cpus"] == [0] and same["page_nodes"] == [0]
    assert same["threads"][0]["access"] == "local"
    assert cross["bandwidth_mb_s"] == 320.0 and cross["mean_latency_ns"] == 200.0
    assert cross["thread_cpus"] == [4] and cross["page_nodes"] == [0]
    assert cross["threads"][0]["access"] == "remote"
    assert same["bandwidth_mb_s"] > cross["bandwidth_mb_s"]

    pin = r["pin_thread_only"]
    assert pin["thread_cpus"] == [0] and pin["page_nodes"] == [1]
    assert pin["threads"][0]["first_touch_cpu"] == 4
    assert pin["threads"][0]["access"] == "remote"
    assert pin["bandwidth_mb_s"] == 320.0
    assert r["acceptance_pinned_thread_not_local_memory"]

    bound = r["pin_and_membind"]
    assert bound["threads"][0]["access"] == "local"
    assert bound["bandwidth_mb_s"] == 640.0
    assert bound["n_eligible_cpus"] == 1
    assert r["tradeoff_bind_locality_vs_flexibility"]

    two_l, two_u = r["two_threads_same_node"], r["two_threads_ignore_topology"]
    assert two_l["bandwidth_mb_s"] == 1280.0 and two_l["mean_latency_ns"] == 100.0
    assert two_l["thread_cpus"] == [0, 1] and two_l["n_local_threads"] == 2
    assert two_u["bandwidth_mb_s"] == 960.0 and two_u["mean_latency_ns"] == 150.0
    assert two_u["thread_cpus"] == [0, 4]
    assert two_u["n_local_threads"] == 1 and two_u["n_remote_threads"] == 1
    assert two_u["bandwidth_mb_s"] < two_l["bandwidth_mb_s"]
    assert r["pitfall_threads_without_topology"]

    assert r["acceptance_reports_topology_and_placement"]
    flags = r["flags"]
    assert flags["reports_topology_and_thread_placement"]
    assert flags["pinned_thread_does_not_imply_local_memory"]
    assert flags["same_node_beats_cross"]
    assert flags["binding_improves_locality"]
    assert flags["binding_reduces_scheduler_flexibility"]
    assert flags["more_threads_without_topology_scales_worse"]


if __name__ == "__main__":
    main()
