#!/usr/bin/env python3
"""Run the lesson 136 teaching NUMA experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1, NumaEngine


def run() -> dict[str, Any]:
    eng = NumaEngine()
    cmp = eng.compare()
    return {
        "engine": "NumaEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "measure_s": MEASURE_S,
        "local_lat_ns": cmp["local_lat_ns"],
        "remote_lat_ns": cmp["remote_lat_ns"],
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_numa_product": True,
        "not_host_numactl": True,
        "not_host_sysfs_node": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "topology": cmp["topology"],
        "same_node": cmp["same_node"],
        "cross_node": cmp["cross_node"],
        "pin_thread_only": cmp["pin_thread_only"],
        "pin_and_membind": cmp["pin_and_membind"],
        "two_threads_same_node": cmp["two_threads_same_node"],
        "two_threads_ignore_topology": cmp["two_threads_ignore_topology"],
        "flags": {
            "reports_topology_and_thread_placement": cmp["reports_topology_and_thread_placement"],
            "pinned_thread_does_not_imply_local_memory": cmp["pinned_thread_does_not_imply_local_memory"],
            "same_node_beats_cross": cmp["same_node_beats_cross"],
            "binding_improves_locality": cmp["binding_improves_locality"],
            "binding_reduces_scheduler_flexibility": cmp["binding_reduces_scheduler_flexibility"],
            "more_threads_without_topology_scales_worse": cmp["more_threads_without_topology_scales_worse"],
        },
        "acceptance_pinned_thread_not_local_memory": cmp["pinned_thread_does_not_imply_local_memory"],
        "acceptance_reports_topology_and_placement": cmp["reports_topology_and_thread_placement"],
        "pitfall_threads_without_topology": cmp["more_threads_without_topology_scales_worse"],
        "tradeoff_bind_locality_vs_flexibility": (
            cmp["binding_improves_locality"]
            and cmp["binding_reduces_scheduler_flexibility"]
        ),
    }


if __name__ == "__main__":
    run()
