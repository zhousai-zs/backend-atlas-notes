#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 test_numa.py
echo ALL_CHECKS_PASSED
