// fdlab.c: dup/fork 共享偏移、独立 open 不共享、FD_CLOEXEC 与 fd 复用误关闭
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static off_t pos(int fd) { return lseek(fd, 0, SEEK_CUR); }

int main(void) {
    const char *path = "/tmp/fdlab.txt";
    int w = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0644);
    write(w, "0123456789", 10); close(w);

    // 1) dup：两个 fd 指向同一个 open file description，共享偏移
    int a = open(path, O_RDONLY);
    int b = dup(a);
    char buf[4] = {0};
    read(a, buf, 3);
    printf("dup: a=%d b=%d read via a -> pos(a)=%ld pos(b)=%ld\n", a, b, (long)pos(a), (long)pos(b));

    // 2) 两次独立 open：各自一个 open file description，偏移独立
    int c = open(path, O_RDONLY);
    printf("open twice: pos(c)=%ld (独立)\n", (long)pos(c));

    // 3) fork：子进程继承 fd 表副本，但指向同一个 description
    pid_t p = fork();
    if (p == 0) { read(a, buf, 3); _exit(0); }
    waitpid(p, NULL, 0);
    printf("fork: child read 3 -> parent pos(a)=%ld\n", (long)pos(a));

    // 4) FD_CLOEXEC：exec 后是否泄漏到子进程
    int leak = open(path, O_RDONLY);               // 无 CLOEXEC
    int safe = open(path, O_RDONLY | O_CLOEXEC);   // 原子设置 CLOEXEC
    printf("leak=%d safe=%d\n", leak, safe);
    fflush(stdout);
    p = fork();
    if (p == 0) {
        char cmd[128];
        snprintf(cmd, sizeof cmd, "for f in %d %d; do [ -e /proc/self/fd/$f ] && echo child_has_fd=$f || echo child_no_fd=$f; done", leak, safe);
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(127);
    }
    waitpid(p, NULL, 0);

    // 5) fd 复用导致误关闭：close 后数字立刻被新 open 复用
    int conn = open(path, O_RDONLY);
    int stale = conn;               // 某个回调里保存的旧整数
    close(conn);
    int newconn = open("/dev/null", O_RDONLY);
    printf("reuse: old=%d new=%d same_number=%s\n", stale, newconn, stale == newconn ? "yes" : "no");
    close(stale);                   // 二次 close 误关了新连接
    if (fcntl(newconn, F_GETFD) == -1) printf("reuse: newconn closed by mistake (EBADF)\n");
    return 0;
}
