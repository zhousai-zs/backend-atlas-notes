#!/bin/bash
set -e
cd "$(dirname "$0")"
gcc -Wall -O0 -g -fsanitize=address,undefined fdlab.c -o fdlab
g++ -std=c++17 -Wall -g -fsanitize=address,undefined owned_fd.cpp -o owned_fd
out=$(./fdlab); echo "$out"
echo "$out" | grep -q "pos(a)=3 pos(b)=3"
echo "$out" | grep -q "pos(c)=0"
echo "$out" | grep -q "parent pos(a)=6"
leak=$(echo "$out" | sed -n 's/^leak=\([0-9]*\) safe=\([0-9]*\)/\1/p'); safe=$(echo "$out" | sed -n 's/^leak=\([0-9]*\) safe=\([0-9]*\)/\2/p')
echo "$out" | grep -q "child_has_fd=$leak"
echo "$out" | grep -q "child_no_fd=$safe"
echo "$out" | grep -q "same_number=yes"
echo "$out" | grep -q "closed by mistake"
./owned_fd
echo ALL_CHECKS_PASSED
