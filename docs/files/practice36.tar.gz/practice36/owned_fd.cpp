// owned_fd.cpp: RAII 所有权包装，只能移动不能拷贝，保证只 close 一次
#include <fcntl.h>
#include <unistd.h>
#include <cstdio>
#include <utility>
static int closes = 0;
class OwnedFd {
    int fd_ = -1;
public:
    explicit OwnedFd(int fd) : fd_(fd) {}
    OwnedFd(const OwnedFd&) = delete;
    OwnedFd& operator=(const OwnedFd&) = delete;
    OwnedFd(OwnedFd&& o) noexcept : fd_(std::exchange(o.fd_, -1)) {}
    OwnedFd& operator=(OwnedFd&& o) noexcept { if (this != &o) { reset(); fd_ = std::exchange(o.fd_, -1); } return *this; }
    ~OwnedFd() { reset(); }
    int get() const { return fd_; }
    int release() { return std::exchange(fd_, -1); }
    void reset() { if (fd_ >= 0) { ::close(fd_); ++closes; fd_ = -1; } }
};
int main() {
    {
        OwnedFd a(::open("/dev/null", O_RDONLY | O_CLOEXEC));
        OwnedFd b = std::move(a);        // 所有权转移，a 变 -1
        OwnedFd c(::open("/dev/null", O_RDONLY | O_CLOEXEC));
        c = std::move(b);                // c 原来的 fd 先关掉
        std::printf("a=%d b=%d c>=0:%d\n", a.get(), b.get(), c.get() >= 0);
    }
    std::printf("closes=%d (期望 2，每个 fd 恰好一次)\n", closes);
    return closes == 2 ? 0 : 1;
}
