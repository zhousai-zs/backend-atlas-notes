#!/usr/bin/env python3
"""Checks for lesson 116 practice. Prints ALL_CHECKS_PASSED on success."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import TITLE_V1, TITLE_V2, TITLE_V3

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def _write_and_load() -> dict:
    data = run()
    RESULTS.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return json.loads(RESULTS.read_text(encoding="utf-8"))


def main() -> None:
    data = _write_and_load()
    assert data["engine"] == "RsmEngine"
    assert data["not_redis"] is True
    assert data["not_a_network_service"] is True
    assert data["not_full_raft"] is True
    assert data["not_paxos"] is True
    assert data["not_jepsen"] is True
    assert data["no_leader_election"] is True
    assert data["majority"] == 2
    assert data["local_step_s"] == 0.01
    assert data["replicate_delay_s"] == 0.08
    assert data["slow_follower_delay_s"] == 0.16

    det = data["deterministic_replay"]
    assert det["checksums_equal"] is True
    assert det["r1"]["checksum"] == det["r2"]["checksum"] == det["checksum"]
    assert det["title"] == TITLE_V2
    assert det["views"] == "2"
    assert det["log_len"] == 5
    assert det["log_bytes"] == 458
    assert det["r1"]["applied_count"] == 5

    unlogged = data["unlogged_inputs"]
    u = unlogged["unlogged"]
    assert u["time_differs"] is True
    assert u["token_differs"] is True
    assert u["checksums_equal"] is False
    assert u["r1"]["published_at"] == "0.04"
    assert u["r2"]["published_at"] == "0.14"
    assert u["r1"]["token"] == "tok_144272510"
    assert u["r2"]["token"] == "tok_926756583"
    fixed = unlogged["logged_concrete_values"]
    assert fixed["checksums_equal"] is True
    assert fixed["sampled_published_at"] == "0.04"
    assert fixed["sampled_token"] == "tok_144272510"
    assert fixed["r1"]["checksum"] == fixed["r2"]["checksum"]
    assert data["acceptance_random_and_time_must_be_logged_inputs"] is True

    stages = data["stages"]
    assert stages["inv_s"] == 0.0
    assert stages["ret_s"] == 0.1
    assert stages["latency_s"] == 0.1
    assert stages["log_index"] == 1
    a = stages["after_append"]
    assert a["now"] == 0.01
    assert a["replicated_on"] == ["s1"]
    assert a["committed"] is False
    assert a["applied_on"] == []
    assert a["servers"]["s1"]["title"] == TITLE_V1
    m = stages["after_majority"]
    assert m["now"] == 0.09
    assert m["replicated_on"] == ["s1", "s2"]
    assert m["committed"] is True
    assert m["applied_on"] == ["s1"]
    assert m["servers"]["s1"]["title"] == TITLE_V2
    assert m["servers"]["s2"]["title"] == TITLE_V1
    r = stages["after_commit_return"]
    assert r["now"] == 0.1
    assert r["applied_on"] == ["s1"]
    assert r["servers"]["s3"]["title"] == TITLE_V1
    s3e = stages["after_s3_has_entry"]
    assert s3e["now"] == 0.17
    assert s3e["replicated_on"] == ["s1", "s2", "s3"]
    assert s3e["applied_on"] == ["s1"]
    assert s3e["servers"]["s3"]["title"] == TITLE_V1
    s2a = stages["after_s2_applies"]
    assert s2a["now"] == 0.18
    assert s2a["applied_on"] == ["s1", "s2"]
    s3a = stages["after_s3_applies"]
    assert s3a["now"] == 0.26
    assert s3a["applied_on"] == ["s1", "s2", "s3"]
    assert s3a["servers"]["s3"]["title"] == TITLE_V2
    assert stages["get_s1"]["result"] == TITLE_V2
    assert stages["get_s1"]["inv_s"] == 0.26
    assert stages["get_s1"]["ret_s"] == 0.28
    assert stages["get_s3"]["result"] == TITLE_V2
    assert stages["get_s3"]["inv_s"] == 0.28
    assert stages["get_s3"]["ret_s"] == 0.3
    assert data["acceptance_distinguish_replicated_committed_applied"] is True

    crash = data["crash_and_recover"]
    ok = crash["committed_then_crash"]
    assert ok["title_restored"] is True
    assert ok["checksum_matches"] is True
    assert ok["reapplied"] == 1
    assert ok["recovered"]["kv"]["article:01:title"] == TITLE_V2
    assert ok["recovered"]["kv"]["article:01:views"] == "0"
    lost = crash["uncommitted_then_crash"]
    assert lost["after_append"]["committed"] is False
    assert lost["after_append"]["applied_on"] == []
    assert lost["title_still_initial"] is True
    assert lost["uncommitted_still_in_log"] is True
    assert lost["not_applied"] is True
    assert lost["recovered"]["kv"]["article:01:title"] == TITLE_V1
    assert lost["recovered"]["reapplied"] == 0

    snap = data["snapshot_and_replay"]
    assert snap["full_log_len"] == 5
    assert snap["suffix_len"] == 2
    assert snap["suffix_indexes"] == [4, 5]
    assert snap["snapshot"]["last_included_index"] == 3
    assert snap["checksums_equal"] is True
    assert snap["checksum"] == det["checksum"]
    assert snap["title"] == TITLE_V2
    assert snap["views"] == "2"
    assert snap["full_log_bytes"] == 458
    assert snap["snapshot_bytes"] == 211
    assert snap["suffix_bytes"] == 154
    assert snap["snapshot_plus_suffix_bytes"] == 365
    assert snap["snapshot_plus_suffix"]["applied_count"] == 2

    pit = data["pitfall_replication_thread"]
    after = pit["naive"]["after"]
    assert after["has_replication_thread"] is True
    assert after["has_consensus"] is False
    assert after["logs_conflict"] is True
    assert after["checksums_equal"] is False
    assert after["nodes"]["n1"]["title"] == TITLE_V2
    assert after["nodes"]["n2"]["title"] == TITLE_V3
    assert after["nodes"]["n1"]["commit_index"] == 0
    assert pit["naive"]["n1_append_s"] == 0.01
    assert pit["naive"]["n2_append_s"] == 0.02
    assert after["now"] == 0.1
    assert pit["with_rsm"]["w1"]["ret_s"] == 0.1
    assert pit["with_rsm"]["w2"]["ret_s"] == 0.2
    assert pit["with_rsm"]["w2"]["log_index"] == 2
    assert pit["with_rsm"]["final_title"] == TITLE_V3
    assert pit["with_rsm"]["checksums_equal"] is True
    assert data["pitfall_replication_thread_is_not_consensus"] is True

    cost = data["tradeoff_cost"]
    assert cost["network_copy_bytes"] == 916
    assert cost["snapshot_saves_bytes_vs_full_log"] == 93
    assert cost["committed_state_restored_after_crash"] is True
    assert data["tradeoff_log_replication_costs_network_and_persist_for_recovery"] is True

    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
