#!/usr/bin/env python3
"""Run the lesson 116 replicated-state-machine experiments and record observations."""
from __future__ import annotations

import json
from pathlib import Path
from random import Random
from typing import Any

from engine import (
    KEY_PUBLISHED,
    KEY_TITLE,
    KEY_TOKEN,
    KEY_VIEWS,
    LOCAL_STEP_S,
    REPLICATE_DELAY_S,
    SLOW_FOLLOWER_DELAY_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    Clock,
    LogEntry,
    NaiveReplicator,
    RsmEngine,
    Snapshot,
    TERM,
    apply_command,
    kv_checksum,
    replay,
)


def _cmd(op: str, key: str, value: str | None = None) -> dict[str, Any]:
    c: dict[str, Any] = {"op": op, "key": key}
    if value is not None:
        c["value"] = value
    return c


def _entries(commands: list[dict[str, Any]]) -> list[LogEntry]:
    return [LogEntry(index=i + 1, term=TERM, command=c) for i, c in enumerate(commands)]


DETERMINISTIC_COMMANDS = [
    _cmd("SET", KEY_TITLE, TITLE_V1),
    _cmd("SET", KEY_VIEWS, "0"),
    _cmd("SET", KEY_TITLE, TITLE_V2),
    _cmd("INCR", KEY_VIEWS),
    _cmd("INCR", KEY_VIEWS),
]


def deterministic_replay() -> dict[str, Any]:
    """Replay the same command log onto two fresh replicas and compare checksums."""
    entries = _entries(DETERMINISTIC_COMMANDS)
    r1 = replay(entries)
    r2 = replay(entries)
    log_bytes = sum(e.encoded_size() for e in entries)
    return {
        "commands": DETERMINISTIC_COMMANDS,
        "log_len": len(entries),
        "log_bytes": log_bytes,
        "r1": {"kv": r1["kv"], "checksum": r1["checksum"], "applied_count": r1["applied_count"]},
        "r2": {"kv": r2["kv"], "checksum": r2["checksum"], "applied_count": r2["applied_count"]},
        "checksums_equal": r1["checksum"] == r2["checksum"],
        "title": r1["kv"][KEY_TITLE],
        "views": r1["kv"][KEY_VIEWS],
        "checksum": r1["checksum"],
    }


def unlogged_inputs() -> dict[str, Any]:
    """Random and current time used at apply time, not recorded in the command."""
    prefix = [
        _cmd("SET", KEY_TITLE, TITLE_V1),
        _cmd("SET", KEY_VIEWS, "0"),
        _cmd("SET", KEY_TITLE, TITLE_V2),
        _cmd("SET_NOW", KEY_PUBLISHED),
        _cmd("SET_RAND", KEY_TOKEN),
    ]
    entries = _entries(prefix)
    clock_a = Clock(0.0)
    clock_b = Clock(0.10)
    r1 = replay(entries, clock=clock_a, rng=Random(1), apply_step_s=LOCAL_STEP_S)
    r2 = replay(entries, clock=clock_b, rng=Random(2), apply_step_s=LOCAL_STEP_S)
    diverged = r1["checksum"] != r2["checksum"]

    # Leader samples time and random once, writes concrete values into the log.
    sampled_time = r1["kv"][KEY_PUBLISHED]
    sampled_token = r1["kv"][KEY_TOKEN]
    fixed = [
        _cmd("SET", KEY_TITLE, TITLE_V1),
        _cmd("SET", KEY_VIEWS, "0"),
        _cmd("SET", KEY_TITLE, TITLE_V2),
        _cmd("SET", KEY_PUBLISHED, sampled_time),
        _cmd("SET", KEY_TOKEN, sampled_token),
    ]
    fixed_entries = _entries(fixed)
    f1 = replay(fixed_entries, clock=Clock(0.0), rng=Random(1), apply_step_s=LOCAL_STEP_S)
    f2 = replay(fixed_entries, clock=Clock(0.10), rng=Random(2), apply_step_s=LOCAL_STEP_S)
    return {
        "unlogged": {
            "r1": {
                "kv": r1["kv"],
                "checksum": r1["checksum"],
                "clock_start": 0.0,
                "published_at": r1["kv"][KEY_PUBLISHED],
                "token": r1["kv"][KEY_TOKEN],
            },
            "r2": {
                "kv": r2["kv"],
                "checksum": r2["checksum"],
                "clock_start": 0.10,
                "published_at": r2["kv"][KEY_PUBLISHED],
                "token": r2["kv"][KEY_TOKEN],
            },
            "checksums_equal": not diverged,
            "time_differs": r1["kv"][KEY_PUBLISHED] != r2["kv"][KEY_PUBLISHED],
            "token_differs": r1["kv"][KEY_TOKEN] != r2["kv"][KEY_TOKEN],
        },
        "logged_concrete_values": {
            "sampled_published_at": sampled_time,
            "sampled_token": sampled_token,
            "r1": {"kv": f1["kv"], "checksum": f1["checksum"]},
            "r2": {"kv": f2["kv"], "checksum": f2["checksum"]},
            "checksums_equal": f1["checksum"] == f2["checksum"],
            "checksum": f1["checksum"],
        },
        "acceptance_random_and_time_must_be_logged_inputs": bool(
            diverged
            and r1["kv"][KEY_PUBLISHED] != r2["kv"][KEY_PUBLISHED]
            and r1["kv"][KEY_TOKEN] != r2["kv"][KEY_TOKEN]
            and f1["checksum"] == f2["checksum"]
            and f1["kv"][KEY_PUBLISHED] == sampled_time
            and f1["kv"][KEY_TOKEN] == sampled_token
        ),
    }


def stages_replicated_committed_applied() -> dict[str, Any]:
    """Walk one SET through append, majority copy, commit, apply, and catch-up."""
    clock = Clock()
    eng = RsmEngine(clock, initial={KEY_TITLE: TITLE_V1, KEY_VIEWS: "0"})
    before = eng.inspect(index=1)
    # Index 1 does not exist yet; record the starting state separately.
    start = {
        "now": clock.now(),
        "title": TITLE_V1,
        "s1": eng.inspect(index=0)["servers"]["s1"],
        "leader_commit_index": 0,
        "leader_last_applied": 0,
    }

    inv = clock.now()
    entry = eng.append_on_leader(_cmd("SET", KEY_TITLE, TITLE_V2))
    after_append = eng.inspect(index=entry.index)

    eng.pump(until=REPLICATE_DELAY_S + LOCAL_STEP_S)  # s2 receives at 0.09
    after_majority = eng.inspect(index=entry.index)
    # Local step after majority: the client-visible apply/return, if not already applied.
    if eng.leader().commit_index >= entry.index:
        if clock.now() == REPLICATE_DELAY_S + LOCAL_STEP_S:
            clock.advance(LOCAL_STEP_S)
        # If apply already happened inside pump when s2 acked, last_applied is 1
        # and the extra local_step models the leader returning to the client.
    after_commit_return = eng.inspect(index=entry.index)
    eng.notify_commit()
    ret = clock.now()

    eng.pump(until=SLOW_FOLLOWER_DELAY_S + LOCAL_STEP_S)  # s3 receives first AE at 0.17
    after_s3_has_entry = eng.inspect(index=entry.index)

    eng.pump(until=ret + REPLICATE_DELAY_S)  # s2 heartbeat at return+0.08
    after_s2_applies = eng.inspect(index=entry.index)

    eng.pump(until=ret + SLOW_FOLLOWER_DELAY_S)  # s3 heartbeat at return+0.16
    after_s3_applies = eng.inspect(index=entry.index)

    get_s1 = eng.get(KEY_TITLE, "s1")
    get_s3 = eng.get(KEY_TITLE, "s3")

    return {
        "local_step_s": LOCAL_STEP_S,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "slow_follower_delay_s": SLOW_FOLLOWER_DELAY_S,
        "majority": eng.majority,
        "inv_s": inv,
        "ret_s": ret,
        "latency_s": round(ret - inv, 10),
        "log_index": entry.index,
        "start": start,
        "after_append": after_append,
        "after_majority": after_majority,
        "after_commit_return": after_commit_return,
        "after_s3_has_entry": after_s3_has_entry,
        "after_s2_applies": after_s2_applies,
        "after_s3_applies": after_s3_applies,
        "get_s1": get_s1.as_dict(),
        "get_s3": get_s3.as_dict(),
        "acceptance_distinguish_replicated_committed_applied": bool(
            after_append["replicated_on"] == ["s1"]
            and after_append["committed"] is False
            and after_append["applied_on"] == []
            and after_append["servers"]["s1"]["title"] == TITLE_V1
            and after_majority["replicated_on"] == ["s1", "s2"]
            and after_majority["committed"] is True
            and after_commit_return["applied_on"] == ["s1"]
            and after_commit_return["servers"]["s1"]["title"] == TITLE_V2
            and after_commit_return["servers"]["s2"]["title"] == TITLE_V1
            and after_commit_return["servers"]["s3"]["title"] == TITLE_V1
            and after_s3_has_entry["replicated_on"] == ["s1", "s2", "s3"]
            and after_s3_has_entry["applied_on"] == ["s1"]
            and after_s2_applies["applied_on"] == ["s1", "s2"]
            and after_s3_applies["applied_on"] == ["s1", "s2", "s3"]
            and after_s3_applies["servers"]["s3"]["title"] == TITLE_V2
        ),
    }


def crash_and_recover() -> dict[str, Any]:
    """Committed entries are recovered from the log; uncommitted ones are not applied."""
    # Case A: crash after commit+apply, recover by replaying the committed log.
    clock = Clock()
    eng = RsmEngine(clock, initial={KEY_TITLE: TITLE_V1, KEY_VIEWS: "0"})
    op = eng.set(KEY_TITLE, TITLE_V2)
    eng.pump(until=clock.now() + SLOW_FOLLOWER_DELAY_S)
    before_crash = {
        "title": eng.leader().kv.get(KEY_TITLE),
        "checksum": kv_checksum(eng.leader().kv),
        "commit_index": eng.leader().commit_index,
        "last_applied": eng.leader().last_applied,
        "log_index": op.log_index,
        "status": op.status,
        "ret_s": op.ret_s,
    }
    eng.crash("s1")
    recovered = eng.recover("s1")

    # Case B: append only, no majority yet, recover without applying uncommitted suffix.
    clock2 = Clock()
    eng2 = RsmEngine(clock2, initial={KEY_TITLE: TITLE_V1, KEY_VIEWS: "0"})
    entry = eng2.append_on_leader(_cmd("SET", KEY_TITLE, TITLE_V2))
    after_append = eng2.inspect(index=entry.index)
    eng2.crash("s1")
    recovered_uncommitted = eng2.recover("s1")
    # persist_uncommitted default True: log still has the entry, but commitIndex=0 so not applied.
    return {
        "committed_then_crash": {
            "before": before_crash,
            "recovered": recovered,
            "title_restored": recovered["kv"].get(KEY_TITLE) == TITLE_V2,
            "checksum_matches": recovered["checksum"] == before_crash["checksum"],
            "reapplied": recovered["reapplied"],
        },
        "uncommitted_then_crash": {
            "after_append": {
                "now": after_append["now"],
                "replicated_on": after_append["replicated_on"],
                "committed": after_append["committed"],
                "applied_on": after_append["applied_on"],
                "title_s1": after_append["servers"]["s1"]["title"],
                "last_log_index": after_append["servers"]["s1"]["last_log_index"],
            },
            "recovered": recovered_uncommitted,
            "title_still_initial": recovered_uncommitted["kv"].get(KEY_TITLE) is None
            or recovered_uncommitted["kv"].get(KEY_TITLE) == TITLE_V1,
            "uncommitted_still_in_log": recovered_uncommitted["last_log_index"] >= entry.index,
            "not_applied": recovered_uncommitted["last_applied"] < entry.index,
        },
    }


def snapshot_and_replay() -> dict[str, Any]:
    """Snapshot at index 3, discard the prefix, replay suffix onto a second replica."""
    entries = _entries(DETERMINISTIC_COMMANDS)
    full = replay(entries)
    # State after the first three commands is the snapshot contents.
    prefix = replay(entries[:3])
    snap = Snapshot(
        last_included_index=3,
        last_included_term=TERM,
        kv=dict(prefix["kv"]),
    )
    from_snap = replay(entries, snapshot=snap)
    # Two fresh replicas: one full replay, one snapshot + suffix.
    r_full = replay(entries)
    r_snap = replay(entries[3:], snapshot=snap)  # entries 4 and 5; replay() also accepts all and skips <= 3
    # Use the skip path too for an explicit two-replica comparison.
    r_snap_all = replay(entries, snapshot=snap)
    suffix = entries[3:]
    full_bytes = sum(e.encoded_size() for e in entries)
    suffix_bytes = sum(e.encoded_size() for e in suffix)
    snap_bytes = snap.encoded_size()
    return {
        "full_log_len": len(entries),
        "snapshot": snap.as_dict(),
        "suffix_len": len(suffix),
        "suffix_indexes": [e.index for e in suffix],
        "full_replay": {"kv": full["kv"], "checksum": full["checksum"]},
        "snapshot_plus_suffix": {"kv": from_snap["kv"], "checksum": from_snap["checksum"], "applied_count": from_snap["applied_count"]},
        "r_full_checksum": r_full["checksum"],
        "r_snap_checksum": r_snap["checksum"],
        "r_snap_all_checksum": r_snap_all["checksum"],
        "checksums_equal": full["checksum"] == from_snap["checksum"] == r_snap["checksum"] == r_snap_all["checksum"],
        "checksum": full["checksum"],
        "title": full["kv"][KEY_TITLE],
        "views": full["kv"][KEY_VIEWS],
        "full_log_bytes": full_bytes,
        "snapshot_bytes": snap_bytes,
        "suffix_bytes": suffix_bytes,
        "snapshot_plus_suffix_bytes": snap_bytes + suffix_bytes,
    }


def pitfall_replication_thread() -> dict[str, Any]:
    """Two writers, a copy thread, no majority commit: logs conflict, checksums diverge."""
    clock = Clock()
    naive = NaiveReplicator(clock)
    naive.append_local("n1", _cmd("SET", KEY_TITLE, TITLE_V2))
    at_n1 = clock.now()
    naive.append_local("n2", _cmd("SET", KEY_TITLE, TITLE_V3))
    at_n2 = clock.now()
    before_copy = naive.inspect()
    naive.pump(until=at_n1 + REPLICATE_DELAY_S)
    after_first_copy = naive.inspect()
    naive.pump(until=at_n2 + REPLICATE_DELAY_S)
    after = naive.inspect()

    # Contrast: a real (teaching) RSM with a single leader puts both writes in one order.
    clock_r = Clock()
    rsm = RsmEngine(clock_r, initial={KEY_TITLE: TITLE_V1, KEY_VIEWS: "0"})
    w1 = rsm.set(KEY_TITLE, TITLE_V2, process="editor")
    w2 = rsm.set(KEY_TITLE, TITLE_V3, process="hotfix")
    rsm.pump(until=clock_r.now() + SLOW_FOLLOWER_DELAY_S)
    contrast = rsm.inspect(index=w2.log_index)
    checksums = {sid: contrast["servers"][sid]["checksum"] for sid in ("s1", "s2", "s3")}
    return {
        "naive": {
            "n1_append_s": at_n1,
            "n2_append_s": at_n2,
            "before_copy": before_copy,
            "after_first_copy": after_first_copy,
            "after": after,
            "has_replication_thread": True,
            "has_consensus": False,
        },
        "with_rsm": {
            "w1": w1.as_dict(),
            "w2": w2.as_dict(),
            "final": contrast,
            "checksums": checksums,
            "checksums_equal": len(set(checksums.values())) == 1,
            "final_title": contrast["servers"]["s1"]["title"],
        },
        "pitfall_replication_thread_is_not_consensus": bool(
            after["has_replication_thread"]
            and after["has_consensus"] is False
            and after["logs_conflict"]
            and after["checksums_equal"] is False
            and after["nodes"]["n1"]["title"] == TITLE_V2
            and after["nodes"]["n2"]["title"] == TITLE_V3
            and after["nodes"]["n1"]["commit_index"] == 0
            and len(set(checksums.values())) == 1
            and contrast["servers"]["s1"]["title"] == TITLE_V3
        ),
    }


def tradeoff_cost() -> dict[str, Any]:
    """Log replication costs network and persistence; it buys crash recovery."""
    det = deterministic_replay()
    snap = snapshot_and_replay()
    rec = crash_and_recover()
    # Replicating a 5-entry log to two followers: two extra copies of the bytes.
    followers = 2
    network_bytes = det["log_bytes"] * followers
    return {
        "log_len": det["log_len"],
        "log_bytes": det["log_bytes"],
        "followers": followers,
        "network_copy_bytes": network_bytes,
        "full_log_bytes": snap["full_log_bytes"],
        "snapshot_plus_suffix_bytes": snap["snapshot_plus_suffix_bytes"],
        "snapshot_saves_bytes_vs_full_log": snap["full_log_bytes"] - snap["snapshot_plus_suffix_bytes"],
        "committed_state_restored_after_crash": rec["committed_then_crash"]["title_restored"],
        "tradeoff_log_replication_costs_network_and_persist_for_recovery": True,
    }


def run() -> dict[str, Any]:
    det = deterministic_replay()
    unlogged = unlogged_inputs()
    stages = stages_replicated_committed_applied()
    crash = crash_and_recover()
    snap = snapshot_and_replay()
    pitfall = pitfall_replication_thread()
    cost = tradeoff_cost()
    data = {
        "engine": "RsmEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_full_raft": True,
        "not_paxos": True,
        "not_jepsen": True,
        "no_leader_election": True,
        "key_title": KEY_TITLE,
        "key_views": KEY_VIEWS,
        "key_published": KEY_PUBLISHED,
        "key_token": KEY_TOKEN,
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "title_v3": TITLE_V3,
        "local_step_s": LOCAL_STEP_S,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "slow_follower_delay_s": SLOW_FOLLOWER_DELAY_S,
        "majority": 2,
        "servers": ["s1", "s2", "s3"],
        "leader": "s1",
        "deterministic_replay": det,
        "unlogged_inputs": unlogged,
        "stages": stages,
        "crash_and_recover": crash,
        "snapshot_and_replay": snap,
        "pitfall_replication_thread": pitfall,
        "tradeoff_cost": cost,
        "acceptance_random_and_time_must_be_logged_inputs": unlogged[
            "acceptance_random_and_time_must_be_logged_inputs"
        ],
        "acceptance_distinguish_replicated_committed_applied": stages[
            "acceptance_distinguish_replicated_committed_applied"
        ],
        "pitfall_replication_thread_is_not_consensus": pitfall[
            "pitfall_replication_thread_is_not_consensus"
        ],
        "tradeoff_log_replication_costs_network_and_persist_for_recovery": cost[
            "tradeoff_log_replication_costs_network_and_persist_for_recovery"
        ],
    }
    return data


def main() -> None:
    data = run()
    out = Path(__file__).resolve().parent / "results.json"
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
