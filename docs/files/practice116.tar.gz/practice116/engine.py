#!/usr/bin/env python3
"""Teaching RsmEngine — not Redis, not a network service, not a full Raft.

A Python 3 standard-library model of a small replicated state machine:
an in-memory KV, a command log, and three servers that apply the same
commands in the same order. The engine can append deterministic
commands, copy them to followers, mark a majority-replicated prefix
committed, apply committed entries to the KV, take a snapshot, and
replay the log onto two fresh replicas to compare checksums.

This is not Redis, not redis-py, and not a network server. There is no
TCP, no real message loss, and no leader election (that is the next
lesson). It is not a complete Raft, Paxos, or Jepsen implementation.
The Clock is a virtual clock so experiments are repeatable. One server
is a designated leader; followers do not vote. Definitions of the
replicated state machine, committed vs applied entries, and snapshots
follow Ongaro & Ousterhout, "In Search of an Understandable Consensus
Algorithm (Extended Version)", checked on 2026-11-13.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from random import Random
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
KEY_VIEWS = "article:01:views"
KEY_PUBLISHED = "article:01:published_at"
KEY_TOKEN = "article:01:token"
LOCAL_STEP_S = 0.01
REPLICATE_DELAY_S = 0.08
SLOW_FOLLOWER_DELAY_S = 0.16
TERM = 1


def kv_checksum(kv: dict[str, str]) -> str:
    """Stable SHA-256 over a canonical encoding of the KV map."""
    body = "".join(f"{k}\t{v}\n" for k, v in sorted(kv.items()))
    return sha256(body.encode("utf-8")).hexdigest()


def apply_command(
    kv: dict[str, str],
    command: dict[str, Any],
    *,
    clock: Optional["Clock"] = None,
    rng: Optional[Random] = None,
) -> None:
    """Apply one command to a KV map. SET_NOW / SET_RAND read unlogged inputs."""
    op = command["op"]
    key = command["key"]
    if op == "SET":
        kv[key] = str(command["value"])
    elif op == "INCR":
        kv[key] = str(int(kv.get(key, "0")) + 1)
    elif op == "SET_NOW":
        if clock is None:
            raise ValueError("SET_NOW requires a clock")
        kv[key] = f"{clock.now():.2f}"
    elif op == "SET_RAND":
        if rng is None:
            raise ValueError("SET_RAND requires an rng")
        kv[key] = f"tok_{rng.randrange(1, 10**9)}"
    else:
        raise ValueError(f"unknown op: {op}")


def replay(
    entries: list["LogEntry"],
    *,
    initial: Optional[dict[str, str]] = None,
    snapshot: Optional["Snapshot"] = None,
    clock: Optional["Clock"] = None,
    rng: Optional[Random] = None,
    apply_step_s: float = 0.0,
) -> dict[str, Any]:
    """Replay a log (optionally after a snapshot) and return kv plus checksum."""
    if snapshot is not None:
        kv = dict(snapshot.kv)
        next_index = snapshot.last_included_index + 1
    else:
        kv = dict(initial or {})
        next_index = 1
    applied = 0
    for entry in entries:
        if entry.index < next_index:
            continue
        if entry.index != next_index:
            raise ValueError(f"log hole: expected {next_index}, got {entry.index}")
        if clock is not None and apply_step_s:
            clock.advance(apply_step_s)
        apply_command(kv, entry.command, clock=clock, rng=rng)
        next_index += 1
        applied += 1
    return {
        "kv": dict(kv),
        "checksum": kv_checksum(kv),
        "applied_count": applied,
        "last_applied": next_index - 1,
    }


class Clock:
    """A virtual clock tests can freeze and advance. Not a shared wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t = round(self.t + float(seconds), 10)

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class LogEntry:
    index: int
    term: int
    command: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {"index": self.index, "term": self.term, "command": dict(self.command)}

    def encoded_size(self) -> int:
        return len(repr(self.as_dict()).encode("utf-8"))


@dataclass
class Snapshot:
    last_included_index: int
    last_included_term: int
    kv: dict[str, str]

    @property
    def checksum(self) -> str:
        return kv_checksum(self.kv)

    def as_dict(self) -> dict[str, Any]:
        return {
            "last_included_index": self.last_included_index,
            "last_included_term": self.last_included_term,
            "kv": dict(self.kv),
            "checksum": self.checksum,
            "encoded_size": self.encoded_size(),
        }

    def encoded_size(self) -> int:
        payload = {
            "last_included_index": self.last_included_index,
            "last_included_term": self.last_included_term,
            "kv": dict(self.kv),
            "checksum": self.checksum,
        }
        return len(repr(payload).encode("utf-8"))


@dataclass
class RecordedOp:
    op_id: str
    process: str
    kind: str
    key: str
    server_id: str
    arg: Optional[str] = None
    result: Optional[str] = None
    status: str = "ok"
    inv_s: float = 0.0
    ret_s: float = 0.0
    log_index: Optional[int] = None
    note: Optional[str] = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "op_id": self.op_id,
            "process": self.process,
            "kind": self.kind,
            "key": self.key,
            "server_id": self.server_id,
            "arg": self.arg,
            "result": self.result,
            "status": self.status,
            "inv_s": self.inv_s,
            "ret_s": self.ret_s,
            "log_index": self.log_index,
            "note": self.note,
        }


@dataclass
class Server:
    server_id: str
    log: list[LogEntry] = field(default_factory=list)
    kv: dict[str, str] = field(default_factory=dict)
    commit_index: int = 0
    last_applied: int = 0
    match_index: dict[str, int] = field(default_factory=dict)
    snapshot: Optional[Snapshot] = None
    down: bool = False

    def last_log_index(self) -> int:
        return self.log[-1].index if self.log else (
            self.snapshot.last_included_index if self.snapshot else 0
        )

    def last_log_term(self) -> int:
        if self.log:
            return self.log[-1].term
        if self.snapshot:
            return self.snapshot.last_included_term
        return 0

    def entry_at(self, index: int) -> Optional[LogEntry]:
        for entry in self.log:
            if entry.index == index:
                return entry
        return None

    def has_index(self, index: int) -> bool:
        if self.snapshot and index <= self.snapshot.last_included_index:
            return True
        return self.entry_at(index) is not None


@dataclass
class PendingMessage:
    deliver_at: float
    kind: str
    src: str
    dst: str
    entries: list[LogEntry] = field(default_factory=list)
    leader_commit: int = 0
    match_index: int = 0


class RsmEngine:
    """Three-server teaching RSM with a designated leader and a command log.

    Delays are one-way: when a follower receives an AppendEntries, the
    leader's match_index is updated in the same instant. That is a
    documented simplification, not a network RTT. Majority is 2.
    """

    def __init__(
        self,
        clock: Clock,
        leader: str = "s1",
        server_ids: tuple[str, ...] = ("s1", "s2", "s3"),
        delays: Optional[dict[str, float]] = None,
        initial: Optional[dict[str, str]] = None,
        local_step_s: float = LOCAL_STEP_S,
    ) -> None:
        self.clock = clock
        self.leader_id = leader
        self.server_ids = tuple(server_ids)
        self.local_step_s = float(local_step_s)
        self.majority = len(self.server_ids) // 2 + 1
        self.delays = dict(delays or {
            "s1": 0.0,
            "s2": REPLICATE_DELAY_S,
            "s3": SLOW_FOLLOWER_DELAY_S,
        })
        start = dict(initial) if initial is not None else {}
        # A non-empty starting KV is recorded as a snapshot at index 0 so
        # crash recovery can rebuild the same state from snapshot plus log,
        # instead of silently dropping keys that were never logged.
        initial_snap = (
            Snapshot(last_included_index=0, last_included_term=0, kv=dict(start))
            if start else None
        )
        self.servers: dict[str, Server] = {}
        for sid in self.server_ids:
            srv = Server(server_id=sid, kv=dict(start), snapshot=initial_snap)
            srv.match_index = {other: 0 for other in self.server_ids}
            srv.match_index[sid] = 0
            self.servers[sid] = srv
        self.pending: list[PendingMessage] = []
        self._op_seq = 0
        self.ops: list[RecordedOp] = []

    def leader(self) -> Server:
        return self.servers[self.leader_id]

    def _next_op_id(self, prefix: str) -> str:
        self._op_seq += 1
        return f"{prefix}{self._op_seq}"

    def pump(self, until: Optional[float] = None) -> int:
        """Deliver messages whose deliver_at is <= until (default: now)."""
        deadline = self.clock.now() if until is None else float(until)
        delivered = 0
        while True:
            due = [m for m in self.pending if m.deliver_at <= deadline + 1e-12]
            if not due:
                break
            due.sort(key=lambda m: (m.deliver_at, m.kind, m.dst))
            msg = due[0]
            self.pending.remove(msg)
            self.clock.wait_until(msg.deliver_at)
            self._deliver(msg)
            delivered += 1
        self.clock.wait_until(deadline)
        return delivered

    def _deliver(self, msg: PendingMessage) -> None:
        src = self.servers[msg.src]
        dst = self.servers[msg.dst]
        if dst.down or src.down:
            return
        if msg.kind == "append_entries":
            for entry in msg.entries:
                if dst.entry_at(entry.index) is None:
                    if dst.snapshot and entry.index <= dst.snapshot.last_included_index:
                        continue
                    dst.log.append(LogEntry(entry.index, entry.term, dict(entry.command)))
                    dst.log.sort(key=lambda e: e.index)
            if msg.leader_commit > dst.commit_index:
                dst.commit_index = min(msg.leader_commit, dst.last_log_index())
                self._apply_committed(dst)
            # Idealized same-instant ack: leader records match_index now.
            if not src.down:
                src.match_index[dst.server_id] = dst.last_log_index()
                self._maybe_commit_leader()
        elif msg.kind == "heartbeat":
            if msg.leader_commit > dst.commit_index:
                dst.commit_index = min(msg.leader_commit, dst.last_log_index())
                self._apply_committed(dst)

    def _maybe_commit_leader(self) -> bool:
        ldr = self.leader()
        if ldr.down:
            return False
        last = ldr.last_log_index()
        changed = False
        for n in range(ldr.commit_index + 1, last + 1):
            stored = sum(1 for sid in self.server_ids if self.servers[sid].has_index(n) and not self.servers[sid].down)
            # Use match_index as well, in case has_index is true but we count majority via copies.
            if stored >= self.majority:
                ldr.commit_index = n
                changed = True
            else:
                break
        if changed:
            self._apply_committed(ldr)
        return changed

    def _apply_committed(self, srv: Server) -> int:
        applied = 0
        while srv.commit_index > srv.last_applied:
            nxt = srv.last_applied + 1
            if srv.snapshot and nxt <= srv.snapshot.last_included_index:
                srv.last_applied = srv.snapshot.last_included_index
                continue
            entry = srv.entry_at(nxt)
            if entry is None:
                break
            apply_command(srv.kv, entry.command)
            srv.last_applied = nxt
            applied += 1
        return applied

    def _send_append_entries(self, dst: str, entries: list[LogEntry], leader_commit: int) -> None:
        delay = float(self.delays.get(dst, REPLICATE_DELAY_S))
        self.pending.append(
            PendingMessage(
                deliver_at=round(self.clock.now() + delay, 10),
                kind="append_entries",
                src=self.leader_id,
                dst=dst,
                entries=[LogEntry(e.index, e.term, dict(e.command)) for e in entries],
                leader_commit=leader_commit,
            )
        )

    def _send_heartbeat(self, dst: str) -> None:
        delay = float(self.delays.get(dst, REPLICATE_DELAY_S))
        self.pending.append(
            PendingMessage(
                deliver_at=round(self.clock.now() + delay, 10),
                kind="heartbeat",
                src=self.leader_id,
                dst=dst,
                leader_commit=self.leader().commit_index,
            )
        )

    def append_on_leader(self, command: dict[str, Any]) -> LogEntry:
        """Append one command to the leader log and ship it to followers. No wait."""
        ldr = self.leader()
        if ldr.down:
            raise RuntimeError("leader is down")
        self.clock.advance(self.local_step_s)
        index = ldr.last_log_index() + 1
        entry = LogEntry(index=index, term=TERM, command=dict(command))
        ldr.log.append(entry)
        ldr.match_index[ldr.server_id] = index
        for sid in self.server_ids:
            if sid == self.leader_id:
                continue
            self._send_append_entries(sid, [entry], ldr.commit_index)
        return entry

    def wait_for_commit(self, index: int) -> bool:
        """Advance time as messages arrive until index is committed on the leader."""
        if self.leader().commit_index >= index:
            self.clock.advance(self.local_step_s)
            return True
        events = sorted({m.deliver_at for m in self.pending})
        for t in events:
            self.pump(until=t)
            if self.leader().commit_index >= index:
                self.clock.advance(self.local_step_s)
                return True
        return self.leader().commit_index >= index

    def notify_commit(self) -> None:
        """Tell followers the new commitIndex (one-way heartbeat)."""
        for sid in self.server_ids:
            if sid == self.leader_id:
                continue
            self._send_heartbeat(sid)

    def propose(self, command: dict[str, Any], *, process: str = "client", op_id: Optional[str] = None) -> RecordedOp:
        """Client write on the leader: append, wait for majority, apply, return."""
        inv = self.clock.now()
        key = str(command.get("key", ""))
        arg = command.get("value")
        kind = str(command["op"])
        entry = self.append_on_leader(command)
        committed = self.wait_for_commit(entry.index)
        status = "ok" if committed else "rejected"
        note = None if committed else "not_committed"
        if committed:
            self.notify_commit()
        result = self.leader().kv.get(key) if committed else None
        op = RecordedOp(
            op_id=op_id or self._next_op_id("w"),
            process=process,
            kind=kind,
            key=key,
            server_id=self.leader_id,
            arg=None if arg is None else str(arg),
            result=result,
            status=status,
            inv_s=inv,
            ret_s=self.clock.now(),
            log_index=entry.index,
            note=note,
        )
        self.ops.append(op)
        return op

    def set(self, key: str, value: str, **kwargs: Any) -> RecordedOp:
        return self.propose({"op": "SET", "key": key, "value": value}, **kwargs)

    def incr(self, key: str, **kwargs: Any) -> RecordedOp:
        return self.propose({"op": "INCR", "key": key}, **kwargs)

    def get(self, key: str, server_id: Optional[str] = None, *, process: str = "client") -> RecordedOp:
        inv = self.clock.now()
        sid = server_id or self.leader_id
        self.clock.advance(self.local_step_s)
        # Allow a read that spans a small local step, matching earlier lessons.
        self.clock.advance(self.local_step_s)
        srv = self.servers[sid]
        result = srv.kv.get(key)
        op = RecordedOp(
            op_id=self._next_op_id("r"),
            process=process,
            kind="GET",
            key=key,
            server_id=sid,
            result=result,
            status="ok",
            inv_s=inv,
            ret_s=self.clock.now(),
            note=None if result is not None else "missing",
        )
        self.ops.append(op)
        return op

    def crash(self, server_id: str) -> None:
        self.servers[server_id].down = True

    def recover(self, server_id: str, *, persist_uncommitted: bool = True) -> dict[str, Any]:
        """Restart a server from its durable log and commitIndex.

        KV and lastApplied are treated as volatile and rebuilt by replaying
        committed entries. Uncommitted suffix stays in the log if
        persist_uncommitted is true (Raft persists log entries before they
        commit) but is not applied.
        """
        srv = self.servers[server_id]
        durable_log = list(srv.log)
        durable_commit = srv.commit_index
        durable_snap = srv.snapshot
        if not persist_uncommitted:
            durable_log = [e for e in durable_log if e.index <= durable_commit]
        if durable_snap is not None:
            kv = dict(durable_snap.kv)
            last_applied = durable_snap.last_included_index
        else:
            kv = {}
            last_applied = 0
        srv.down = False
        srv.log = durable_log
        srv.commit_index = durable_commit
        srv.snapshot = durable_snap
        srv.kv = kv
        srv.last_applied = last_applied
        applied = self._apply_committed(srv)
        return {
            "server_id": server_id,
            "reapplied": applied,
            "commit_index": srv.commit_index,
            "last_applied": srv.last_applied,
            "last_log_index": srv.last_log_index(),
            "kv": dict(srv.kv),
            "checksum": kv_checksum(srv.kv),
        }

    def take_snapshot(self, server_id: Optional[str] = None) -> Snapshot:
        srv = self.servers[server_id or self.leader_id]
        if srv.last_applied <= 0:
            raise RuntimeError("nothing applied to snapshot")
        entry = srv.entry_at(srv.last_applied)
        term = entry.term if entry is not None else (
            srv.snapshot.last_included_term if srv.snapshot else TERM
        )
        snap = Snapshot(
            last_included_index=srv.last_applied,
            last_included_term=term,
            kv=dict(srv.kv),
        )
        srv.snapshot = snap
        srv.log = [e for e in srv.log if e.index > snap.last_included_index]
        return snap

    def inspect(self, index: Optional[int] = None) -> dict[str, Any]:
        idx = self.leader().last_log_index() if index is None else int(index)
        replicated_on = [sid for sid in self.server_ids if self.servers[sid].has_index(idx) and not self.servers[sid].down]
        applied_on = [sid for sid in self.server_ids if self.servers[sid].last_applied >= idx and not self.servers[sid].down]
        committed_on = [sid for sid in self.server_ids if self.servers[sid].commit_index >= idx and not self.servers[sid].down]
        servers = {}
        for sid in self.server_ids:
            srv = self.servers[sid]
            servers[sid] = {
                "down": srv.down,
                "last_log_index": srv.last_log_index(),
                "commit_index": srv.commit_index,
                "last_applied": srv.last_applied,
                "title": srv.kv.get(KEY_TITLE),
                "views": srv.kv.get(KEY_VIEWS),
                "checksum": kv_checksum(srv.kv),
                "log_len": len(srv.log),
                "snapshot_index": None if srv.snapshot is None else srv.snapshot.last_included_index,
            }
        ldr = self.leader()
        return {
            "now": self.clock.now(),
            "index": idx,
            "replicated_on": replicated_on,
            "committed": ldr.commit_index >= idx,
            "leader_commit_index": ldr.commit_index,
            "leader_last_applied": ldr.last_applied,
            "committed_on": committed_on,
            "applied_on": applied_on,
            "replicated_count": len(replicated_on),
            "applied_count": len(applied_on),
            "majority": self.majority,
            "servers": servers,
        }

    def log_bytes(self, server_id: Optional[str] = None) -> int:
        srv = self.servers[server_id or self.leader_id]
        return sum(e.encoded_size() for e in srv.log)


class NaiveReplicator:
    """A copy thread without a leader, majority commit, or single log order.

    Each node accepts writes, applies them immediately, and a background
    copy thread later ships entries by index. Same-index conflicts are
    kept, not merged. This is the pitfall: a replication thread is not
    consensus.
    """

    def __init__(self, clock: Clock, delay_s: float = REPLICATE_DELAY_S) -> None:
        self.clock = clock
        self.delay_s = float(delay_s)
        self.nodes: dict[str, Server] = {
            "n1": Server(server_id="n1"),
            "n2": Server(server_id="n2"),
        }
        self.pending: list[PendingMessage] = []
        self.conflicts: list[dict[str, Any]] = []

    def append_local(self, node_id: str, command: dict[str, Any]) -> LogEntry:
        self.clock.advance(LOCAL_STEP_S)
        node = self.nodes[node_id]
        index = node.last_log_index() + 1
        entry = LogEntry(index=index, term=TERM, command=dict(command))
        node.log.append(entry)
        apply_command(node.kv, entry.command)
        node.last_applied = index
        # There is no commitIndex in this design; the thread only copies.
        node.commit_index = 0
        other = "n2" if node_id == "n1" else "n1"
        self.pending.append(
            PendingMessage(
                deliver_at=round(self.clock.now() + self.delay_s, 10),
                kind="copy",
                src=node_id,
                dst=other,
                entries=[LogEntry(entry.index, entry.term, dict(entry.command))],
            )
        )
        return entry

    def pump(self, until: Optional[float] = None) -> int:
        deadline = self.clock.now() if until is None else float(until)
        delivered = 0
        while True:
            due = [m for m in self.pending if m.deliver_at <= deadline + 1e-12]
            if not due:
                break
            due.sort(key=lambda m: (m.deliver_at, m.dst))
            msg = due[0]
            self.pending.remove(msg)
            self.clock.wait_until(msg.deliver_at)
            dst = self.nodes[msg.dst]
            for entry in msg.entries:
                existing = dst.entry_at(entry.index)
                if existing is None:
                    dst.log.append(LogEntry(entry.index, entry.term, dict(entry.command)))
                    dst.log.sort(key=lambda e: e.index)
                    # Do not apply a copied entry automatically if the node
                    # already applied a different local command at any index;
                    # only apply if this index has not been applied.
                    if dst.last_applied < entry.index and dst.last_applied + 1 == entry.index:
                        apply_command(dst.kv, entry.command)
                        dst.last_applied = entry.index
                elif existing.command != entry.command:
                    self.conflicts.append(
                        {
                            "index": entry.index,
                            "dst": dst.server_id,
                            "local": dict(existing.command),
                            "incoming": dict(entry.command),
                            "at": self.clock.now(),
                        }
                    )
            delivered += 1
        self.clock.wait_until(deadline)
        return delivered

    def inspect(self) -> dict[str, Any]:
        out = {"now": self.clock.now(), "conflicts": list(self.conflicts), "nodes": {}}
        checksums = []
        for sid, node in self.nodes.items():
            cs = kv_checksum(node.kv)
            checksums.append(cs)
            out["nodes"][sid] = {
                "title": node.kv.get(KEY_TITLE),
                "last_log_index": node.last_log_index(),
                "last_applied": node.last_applied,
                "commit_index": node.commit_index,
                "checksum": cs,
                "log": [e.as_dict() for e in node.log],
            }
        out["checksums_equal"] = len(set(checksums)) == 1
        out["has_replication_thread"] = True
        out["has_consensus"] = False
        out["logs_conflict"] = bool(self.conflicts)
        return out
