"""Fixture candidates, including deliberate failures. Not live model outputs."""


def fixtures(gold_items: list[dict]) -> list[dict]:
    by = {g["id"]: g for g in gold_items}
    out = []

    def add(qid, candidate, note):
        out.append({"id": qid, "split": by[qid]["split"], "candidate": candidate, "note": note})

    # Correct answered (tune + test)
    for qid in ("G01", "G08", "G14", "G18"):
        g = by[qid]
        add(qid, {"status": "answered", "answer": g["gold_facts"][0], "citations": list(g["gold_citations"])}, "gold_correct")

    # Correct abstain
    for qid in ("G19", "G21", "G30"):
        add(qid, {"status": "abstain", "reason": "not_retrieved"}, "gold_abstain")

    # Format failures
    add("G02", "not-json at all", "format_not_json")
    add("G03", {"status": "answered", "answer": "", "citations": ["D03-P01"]}, "format_empty_answer")

    # Fact failure with a supporting-looking citation
    add(
        "G05",
        {"status": "answered", "answer": "E_CONN_RESET means the disk is full.", "citations": ["D05-P01"]},
        "wrong_fact",
    )

    # Evidence failure: right-sounding fact, unrelated citation
    add(
        "G11",
        {
            "status": "answered",
            "answer": "No, they are not a Sentence Transformer",
            "citations": ["D20-P01"],
        },
        "unsupported_citation",
    )

    # Refusal failure: answers an unanswerable question
    add(
        "G20",
        {
            "status": "answered",
            "answer": "Yes, the billing database failed on 2019-01-01.",
            "citations": ["D01-P01"],
        },
        "answered_unanswerable",
    )

    # fact_absent mislabel
    add("G22", {"status": "abstain", "reason": "fact_absent"}, "fact_absent_mislabel")

    # Self-graded "pass" that is factually wrong — self-judge must not wash this out
    add(
        "G09",
        {
            "status": "answered",
            "answer": "The encoding used in the examples is r50k_base.",
            "citations": ["D09-P01"],
            "self_grade": "pass",
        },
        "self_judge_would_pass_but_fact_fails",
    )

    # A clean test case that a dummy self-judge also happens to pass (self_grade absent → judge false;
    # include self_grade correct + actually correct to show the disagreement set is what matters)
    add(
        "G13",
        {
            "status": "answered",
            "answer": "No, a session does not guarantee a cache hit",
            "citations": ["D13-P01"],
            "self_grade": "pass",
        },
        "correct_with_self_grade",
    )
    return out
