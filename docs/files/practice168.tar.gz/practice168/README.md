# practice168 — LLM 评测与校准

30 条 gold，tune/test 分离，事实/证据/拒答/格式四维规则检查。自裁判不是官方分数。OpenAI Evals 平台已只读并将于 2026-11-30 关闭，本课不调用。

```bash
bash test.sh
```
