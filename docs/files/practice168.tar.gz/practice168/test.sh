#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["gold_n"]==30 and r["split"]["disjoint"]
assert r["is_live_model"] is False and r["is_live_openai_evals"] is False
assert r["openai_evals_platform"]["start_new_work_here"] is False
assert r["openai_evals_platform"]["became_read_only"]=="2026-10-31"
assert r["openai_evals_platform"]["scheduled_shutdown"]=="2026-11-30"
assert Path("reports/error_cases.json").exists() and r["error_case_ids"]
assert r["self_judge_invalid"]["used_as_official_grade"] is False
assert r["self_judge_invalid"]["disagreement_ids"]
print("POSTCHECK_OK")
PY
