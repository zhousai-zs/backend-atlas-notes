#!/usr/bin/env python3
"""Gold-set evaluation. Local graders only; OpenAI Evals is not called."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from candidates import fixtures
from graders import grade, self_judge_accepts

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

gold = json.loads((ROOT / "gold/qas.json").read_text())
items = gold["items"]
assert len(items) == 30
splits = Counter(x["split"] for x in items)
assert splits["tune"] >= 10 and splits["test"] >= 10
# Leak guard: no test id is in the tune slice used to inspect failures
tune_ids = {x["id"] for x in items if x["split"] == "tune"}
test_ids = {x["id"] for x in items if x["split"] == "test"}
assert tune_ids.isdisjoint(test_ids)

cands = fixtures(items)
gold_by = {g["id"]: g for g in items}

rows = []
error_cases = []
for c in cands:
    g = gold_by[c["id"]]
    gr = grade(g, c["candidate"])
    sj = self_judge_accepts(c["candidate"])
    rec = {
        "id": c["id"],
        "split": c["split"],
        "note": c["note"],
        "ok": gr.ok,
        "fact": gr.fact,
        "evidence": gr.evidence,
        "refusal": gr.refusal,
        "format": gr.fmt,
        "errors": gr.errors,
        "self_judge": sj,
        "self_judge_disagrees_with_gold": sj and not gr.ok,
    }
    rows.append(rec)
    if not gr.ok:
        error_cases.append(rec)

# Expected: the planted failures are caught; planted passes succeed.
expect_fail = {
    "format_not_json",
    "format_empty_answer",
    "wrong_fact",
    "unsupported_citation",
    "answered_unanswerable",
    "fact_absent_mislabel",
    "self_judge_would_pass_but_fact_fails",
}
expect_pass = {"gold_correct", "gold_abstain", "correct_with_self_grade"}
by_note = {r["note"]: r for r in rows}
for n in expect_fail:
    assert by_note[n]["ok"] is False, (n, by_note[n])
for n in expect_pass:
    assert by_note[n]["ok"] is True, (n, by_note[n])

sj_bad = [r for r in rows if r["self_judge_disagrees_with_gold"]]
assert any(r["note"] == "self_judge_would_pass_but_fact_fails" for r in sj_bad)
assert by_note["self_judge_would_pass_but_fact_fails"]["self_judge"] is True
assert by_note["self_judge_would_pass_but_fact_fails"]["fact"] is False

# Persist error cases (the point of the gold set is to inspect them, not hide them).
(REPORTS / "error_cases.json").write_text(json.dumps(error_cases, indent=2, ensure_ascii=False) + "\n")

# Metrics reported separately on tune and test (no test leakage into a 'tuning' loop here;
# this driver does not change any threshold based on test rows).
def metric(split: str | None) -> dict:
    xs = rows if split is None else [r for r in rows if r["split"] == split]
    n = len(xs)
    return {
        "n_candidates": n,
        "pass": sum(1 for r in xs if r["ok"]),
        "fact_fail": sum(1 for r in xs if not r["fact"]),
        "evidence_fail": sum(1 for r in xs if not r["evidence"]),
        "refusal_fail": sum(1 for r in xs if not r["refusal"]),
        "format_fail": sum(1 for r in xs if not r["format"]),
    }

results = {
    "lesson": 168,
    "id": "k-evaluation",
    "is_live_model": False,
    "is_live_openai_evals": False,
    "candidates_are_fixtures": True,
    "gold_n": 30,
    "split": {"tune": splits["tune"], "test": splits["test"], "disjoint": True},
    "metrics_all_candidates": metric(None),
    "metrics_tune": metric("tune"),
    "metrics_test": metric("test"),
    "error_cases_path": "reports/error_cases.json",
    "error_case_ids": [r["id"] for r in error_cases],
    "self_judge_invalid": {
        "used_as_official_grade": False,
        "disagreement_ids": [r["id"] for r in sj_bad],
        "note": "A candidate with self_grade=pass still failed the fact grader. Dummy self-judgment is not an official metric.",
    },
    "openai_evals_platform": {
        "page": "https://platform.openai.com/docs/guides/evals",
        "fetched_utc": "2026-11-15T15:12:34Z",
        "last_modified_utc": "2026-11-14T09:17:20Z",
        "became_read_only": "2026-10-31",
        "scheduled_shutdown": "2026-11-30",
        "today": "2026-11-15",
        "start_new_work_here": False,
        "suggested_alternative": "Datasets / a local gold set (this practice)",
    },
    "rows": rows,
    "verified_on_this_machine": [
        "local_gold_graders_on_30_qas_with_tune_test_split",
        "error_cases_persisted",
        "dummy_self_judge_rejected_as_official_grade",
    ],
    "not_verified_on_this_machine": [
        "live_model_eval_scores",
        "OpenAI_Evals_platform_run",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(
    {
        "split": results["split"],
        "metrics": results["metrics_all_candidates"],
        "error_case_ids": results["error_case_ids"],
        "self_judge_disagreements": results["self_judge_invalid"]["disagreement_ids"],
    },
    indent=2,
))
print("ALL_CHECKS_PASSED")
