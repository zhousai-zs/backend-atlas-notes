"""Local gold-set graders. A candidate's self_grade is never accepted as truth."""

from __future__ import annotations

import json
from dataclasses import dataclass


ALLOWED_STATUS = {"answered", "abstain"}


@dataclass
class Grade:
    ok: bool
    fact: bool
    evidence: bool
    refusal: bool
    fmt: bool
    errors: list[str]


def parse_candidate(raw):
    """Format grade: must be an object with status plus the fields that status requires."""
    errors = []
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError as e:
            return None, [f"format:not_json:{e}"]
    if not isinstance(raw, dict):
        return None, ["format:not_object"]
    if raw.get("status") not in ALLOWED_STATUS:
        errors.append("format:bad_status")
    if raw.get("status") == "answered":
        if not isinstance(raw.get("answer"), str) or not raw.get("answer").strip():
            errors.append("format:missing_answer")
        if not isinstance(raw.get("citations"), list) or not raw["citations"]:
            errors.append("format:missing_citations")
    if raw.get("status") == "abstain":
        if not isinstance(raw.get("reason"), str) or not raw.get("reason").strip():
            errors.append("format:missing_abstain_reason")
    return (None if errors else raw), errors


def grade(gold: dict, candidate) -> Grade:
    parsed, fmt_errors = parse_candidate(candidate)
    if fmt_errors:
        return Grade(False, False, False, False, False, fmt_errors)
    errors: list[str] = []
    fact = evidence = refusal = True

    if gold["answerable"]:
        if parsed["status"] != "answered":
            fact = False
            refusal = False
            errors.append("refusal:abstained_on_answerable")
        else:
            text = parsed["answer"]
            for f in gold["gold_facts"]:
                if f.lower() not in text.lower() and not _soft_contains(text, f):
                    fact = False
                    errors.append(f"fact:missing:{f}")
            cites = [str(c) for c in parsed.get("citations", [])]
            if not set(gold["gold_citations"]).intersection(cites):
                evidence = False
                errors.append("evidence:missing_gold_citation")
            # extra citations that are clearly unrelated ids starting with D and not gold
            for c in cites:
                if c.startswith("D") and c not in gold["gold_citations"] and c not in ("",):
                    # allow only gold citations in this gold-set
                    evidence = False
                    errors.append(f"evidence:unsupported_citation:{c}")
    else:
        if parsed["status"] != "abstain":
            refusal = False
            fact = False
            errors.append("refusal:answered_unanswerable")
        else:
            if parsed.get("reason") == "fact_absent":
                refusal = False
                errors.append("refusal:fact_absent_not_allowed")
            elif parsed.get("reason") not in gold["allowed_abstain_reasons"]:
                refusal = False
                errors.append(f"refusal:bad_reason:{parsed.get('reason')}")
            if parsed.get("answer"):
                # fabricating a fact while abstaining is still a refusal/fact fail
                fact = False
                errors.append("fact:answer_present_on_abstain")
    ok = fact and evidence and refusal and not errors
    return Grade(ok, fact, evidence, refusal, True, errors)


def _soft_contains(text: str, fact: str) -> bool:
    # require a substantial contiguous subset of the gold fact
    tokens = fact.split()
    if len(tokens) <= 3:
        return False
    needle = " ".join(tokens[:4]).lower()
    return needle in text.lower()


def self_judge_accepts(candidate: dict) -> bool:
    """Dummy self-judge: trusts the candidate's own self_grade flag. Invalid as a rater."""
    if isinstance(candidate, str):
        try:
            candidate = json.loads(candidate)
        except json.JSONDecodeError:
            return False
    return bool(isinstance(candidate, dict) and candidate.get("self_grade") in {"pass", True, "correct"})
