#!/usr/bin/env python3
"""epoll ET Echo：短读到 EAGAIN、半关闭、按需 EPOLLOUT、ONESHOT 漏 rearm（第55课 d-epoll）。"""
from __future__ import annotations

import argparse
import errno
import os
import select
import socket
import sys
import time

HOST = "127.0.0.1"
BACKLOG = 128
IDLE_TIMEOUT = 1.0  # seconds for epoll.poll
RECV_SIZE = 1024  # 较小，便于观察短读循环
SEND_LIMIT = 64


class Conn:
    __slots__ = (
        "sock",
        "addr",
        "outbuf",
        "peer_eof",
        "closed",
        "eagain_r",
        "eagain_w",
        "recv_loops",
        "oneshot",
    )

    def __init__(self, sock: socket.socket, addr, oneshot: bool):
        self.sock = sock
        self.addr = addr
        self.outbuf = bytearray()
        self.peer_eof = False
        self.closed = False
        self.eagain_r = 0
        self.eagain_w = 0
        self.recv_loops = 0
        self.oneshot = oneshot
        sock.setblocking(False)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4096)
        except OSError:
            pass


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("port", nargs="?", type=int, default=18055)
    ap.add_argument("--et", action="store_true", default=True, help="use EPOLLET (default)")
    ap.add_argument("--lt", action="store_true", help="use level-triggered (disable ET)")
    ap.add_argument("--oneshot", action="store_true", help="register with EPOLLONESHOT")
    ap.add_argument(
        "--leak-rearm",
        action="store_true",
        help="ONESHOT: intentionally skip rearm after first client event (demo stall)",
    )
    args = ap.parse_args()
    port = args.port
    use_et = not args.lt
    use_oneshot = args.oneshot or args.leak_rearm
    leak_rearm = args.leak_rearm

    base_events = select.EPOLLIN | select.EPOLLRDHUP
    if use_et:
        base_events |= select.EPOLLET
    if use_oneshot:
        base_events |= select.EPOLLONESHOT

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((HOST, port))
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                print(
                    f"ERROR: port {HOST}:{port} already in use (EADDRINUSE)",
                    file=sys.stderr,
                    flush=True,
                )
                sys.exit(2)
            print(f"ERROR: bind failed: {e}", file=sys.stderr, flush=True)
            sys.exit(1)
        srv.listen(BACKLOG)
        srv.setblocking(False)
        listen_fd = srv.fileno()

        ep = select.epoll()
        # listen: LT accept loop is fine; still nonblocking + drain accept
        listen_ev = select.EPOLLIN
        ep.register(listen_fd, listen_ev)

        conns: dict[int, Conn] = {}
        # fds that already leaked rearm (should stall)
        leaked: set[int] = set()

        print(
            f"epoll echo listening on {HOST}:{port} "
            f"et={use_et} oneshot={use_oneshot} leak_rearm={leak_rearm} "
            f"listen_fd={listen_fd}",
            flush=True,
        )

        def interest_for(c: Conn) -> int:
            ev = select.EPOLLIN | select.EPOLLRDHUP
            if use_et:
                ev |= select.EPOLLET
            if c.oneshot:
                ev |= select.EPOLLONESHOT
            if c.outbuf and not c.closed:
                ev |= select.EPOLLOUT
            return ev

        def arm(c: Conn, reason: str) -> None:
            if c.closed:
                return
            fd = c.sock.fileno()
            if fd < 0:
                return
            ev = interest_for(c)
            try:
                ep.modify(fd, ev)
            except OSError:
                try:
                    ep.register(fd, ev)
                except OSError as e:
                    print(f"arm fail fd={fd}: {e}", flush=True)
                    return
            print(f"ARM fd={fd} reason={reason} events=0x{ev:x} outbuf={len(c.outbuf)}", flush=True)

        def close_conn(c: Conn, reason: str) -> None:
            if c.closed:
                return
            c.closed = True
            fd = c.sock.fileno()
            print(
                f"CLOSE fd={fd} reason={reason} "
                f"eagain_r={c.eagain_r} eagain_w={c.eagain_w} "
                f"recv_loops={c.recv_loops} outbuf={len(c.outbuf)}",
                flush=True,
            )
            try:
                ep.unregister(fd)
            except (OSError, ValueError, KeyError):
                pass
            try:
                c.sock.close()
            except OSError:
                pass
            conns.pop(fd, None)
            leaked.discard(fd)

        def try_flush(c: Conn) -> None:
            if c.closed:
                return
            while c.outbuf:
                nwant = min(SEND_LIMIT, len(c.outbuf))
                try:
                    n = c.sock.send(memoryview(c.outbuf)[:nwant])
                except BlockingIOError:
                    c.eagain_w += 1
                    print(
                        f"SEND_EAGAIN fd={c.sock.fileno()} left={len(c.outbuf)} "
                        f"eagain_w={c.eagain_w}",
                        flush=True,
                    )
                    return
                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        c.eagain_w += 1
                        return
                    if e.errno == errno.EINTR:
                        continue
                    print(f"send err fd={c.sock.fileno()}: {e}", flush=True)
                    close_conn(c, "send_err")
                    return
                if n == 0:
                    close_conn(c, "send0")
                    return
                del c.outbuf[:n]
            if c.peer_eof and not c.outbuf:
                close_conn(c, "flush_after_eof")

        def handle_read(c: Conn) -> None:
            fd = c.sock.fileno()
            total = 0
            loops = 0
            while True:
                try:
                    data = c.sock.recv(RECV_SIZE)
                except BlockingIOError:
                    c.eagain_r += 1
                    print(
                        f"RECV_EAGAIN fd={fd} loops={loops} bytes={total} "
                        f"eagain_r={c.eagain_r}",
                        flush=True,
                    )
                    break
                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        c.eagain_r += 1
                        print(
                            f"RECV_EAGAIN fd={fd} loops={loops} bytes={total} "
                            f"eagain_r={c.eagain_r}",
                            flush=True,
                        )
                        break
                    if e.errno == errno.EINTR:
                        continue
                    print(f"recv err fd={fd}: {e}", flush=True)
                    close_conn(c, "recv_err")
                    return
                loops += 1
                c.recv_loops += 1
                if not data:
                    c.peer_eof = True
                    print(f"EOF fd={fd} drained_bytes={total} loops={loops}", flush=True)
                    break
                total += len(data)
                c.outbuf.extend(data)
                print(f"RECV fd={fd} n={len(data)} total_round={total}", flush=True)
            if total or c.outbuf:
                try_flush(c)
            if c.closed:
                return
            if c.peer_eof and not c.outbuf:
                close_conn(c, "eof_empty_out")
                return

        def handle_client(fd: int, events: int) -> None:
            c = conns.get(fd)
            if c is None or c.closed:
                return

            if events & select.EPOLLERR:
                err = c.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                print(f"EPOLLERR fd={fd} so_error={err}", flush=True)
                close_conn(c, "EPOLLERR")
                return

            # 读方向：IN 或 RDHUP 都尝试排空
            if events & (select.EPOLLIN | select.EPOLLRDHUP):
                handle_read(c)
                if c.closed:
                    return

            if events & select.EPOLLOUT:
                try_flush(c)
                if c.closed:
                    return

            if events & select.EPOLLHUP:
                # 仍可能刚读过；若还有 outbuf 继续等 OUT，否则关
                print(f"EPOLLHUP fd={fd} outbuf={len(c.outbuf)} peer_eof={c.peer_eof}", flush=True)
                if not c.outbuf:
                    close_conn(c, "EPOLLHUP")
                    return

            # ONESHOT rearm / leak
            if c.closed:
                return
            if c.oneshot:
                if leak_rearm and fd not in leaked:
                    leaked.add(fd)
                    print(
                        f"LEAK_REARM fd={fd} skip_rearm demo_stall "
                        f"(subsequent data will not be delivered)",
                        flush=True,
                    )
                    return
                if fd in leaked:
                    print(f"STALL fd={fd} already_leaked no_rearm", flush=True)
                    return
                arm(c, "oneshot_rearm")
            else:
                # 非 oneshot：按 outbuf 动态调整 EPOLLOUT
                arm(c, "mod_interest")

        while True:
            try:
                ready = ep.poll(IDLE_TIMEOUT)
            except InterruptedError:
                continue
            if not ready:
                print("IDLE heartbeat", flush=True)
                continue
            for fd, events in ready:
                if fd == listen_fd:
                    while True:
                        try:
                            conn, addr = srv.accept()
                        except BlockingIOError:
                            break
                        except OSError as e:
                            if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                                break
                            if e.errno == errno.EINTR:
                                continue
                            print(f"accept err: {e}", flush=True)
                            break
                        c = Conn(conn, addr, oneshot=use_oneshot)
                        cfd = conn.fileno()
                        conns[cfd] = c
                        ev = interest_for(c)
                        ep.register(cfd, ev)
                        print(
                            f"ACCEPT fd={cfd} addr={addr[0]}:{addr[1]} "
                            f"events=0x{ev:x} clients={len(conns)}",
                            flush=True,
                        )
                    continue
                handle_client(fd, events)
    finally:
        try:
            ep.close()
        except Exception:
            pass
        try:
            srv.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
