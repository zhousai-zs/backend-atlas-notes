#!/usr/bin/env bash
# Backend Atlas 第55课：epoll ET Echo、短读到 EAGAIN、半关闭、慢读、ONESHOT 漏 rearm、EADDRINUSE
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18055
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2
rm -f /tmp/epoll55-*.log /tmp/epoll55-*.out

python3 server.py "$PORT" --et > /tmp/epoll55-srv.log 2>&1 &
SRV=$!
cleanup(){
  kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
  fuser -k ${PORT}/tcp 2>/dev/null || true
  pkill -f "practice55/client.py" 2>/dev/null || true
  pkill -f "server.py $PORT" 2>/dev/null || true
}
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/epoll55-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

SSOUT=$(ss -ltnp "sport = :$PORT" 2>/dev/null || ss -ltnp | grep ":$PORT" || true)
echo "$SSOUT" | head -3
echo "$SSOUT" | grep -q ":$PORT" && ok "ss 可见 TCP 监听 :$PORT" || bad "ss 未见 TCP :$PORT"

# --- 1) 分片发送 echo 拼回 ---
PAYLOAD="hello-epoll-et-fragmented-payload-XXXX"
python3 client.py --port "$PORT" --payload "$PAYLOAD" --chunk 5 --chunk-delay 0.02 \
  --expect "$PAYLOAD" --timeout 8 > /tmp/epoll55-frag.out 2>&1
FRC=$?
cat /tmp/epoll55-frag.out
if [ "$FRC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/epoll55-frag.out; then
  ok "分片发送 echo 拼回完整 payload"
else
  bad "分片 echo 失败 rc=$FRC"
fi

# 断言服务端出现短读循环到 EAGAIN（ET 排空）
if grep -q "RECV_EAGAIN" /tmp/epoll55-srv.log; then
  ok "ET 读路径出现 RECV_EAGAIN（排空到 EAGAIN）"
else
  # 数据很小时可能一次读完就 EOF/关；再用大 payload 刺激
  BIG=$(python3 -c "print('B'*8000)")
  python3 client.py --port "$PORT" --payload "$BIG" --chunk 100 --chunk-delay 0.001 \
    --expect "$BIG" --timeout 10 > /tmp/epoll55-big.out 2>&1
  BRC=$?
  if [ "$BRC" -eq 0 ] && grep -q "RECV_EAGAIN\|RECV fd=" /tmp/epoll55-srv.log; then
    if grep -q "RECV_EAGAIN" /tmp/epoll55-srv.log; then
      ok "大 payload 后出现 RECV_EAGAIN"
    else
      # 仍无 EAGAIN：至少多次 RECV
      RCNT=$(grep -c "RECV fd=" /tmp/epoll55-srv.log || true)
      if [ "${RCNT:-0}" -ge 2 ]; then
        ok "多次 RECV 短读循环可见 (count=$RCNT)；本轮未挤出 EAGAIN 也算可观察短读"
      else
        bad "未见 RECV_EAGAIN 且 RECV 次数不足"
      fi
    fi
  else
    bad "大 payload echo 失败或无 RECV 日志 rc=$BRC"
  fi
fi

# --- 2) 半关闭：shutdown WR 后仍完整回显 ---
HS="half-close-payload-55"
python3 client.py --port "$PORT" --payload "$HS" --shutdown-wr \
  --expect "$HS" --timeout 8 > /tmp/epoll55-half.out 2>&1
HRC=$?
cat /tmp/epoll55-half.out
echo "---- half-close server log ----"
grep -E "RECV fd=|EOF fd=|CLOSE fd=|RDHUP|EPOLLHUP" /tmp/epoll55-srv.log | tail -20
if [ "$HRC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/epoll55-half.out; then
  ok "半关闭：shutdown(WR) 后仍收到完整 echo"
else
  bad "半关闭 echo 失败 rc=$HRC"
fi
if grep -qE "EOF fd=|PEER" /tmp/epoll55-srv.log; then
  ok "半关闭路径服务端观察到 EOF/读尽"
else
  bad "半关闭路径未见 EOF 日志"
fi

# --- 3) 慢读客户端：不丢不截断 ---
SLOW="slow-client-echo-data-ABCDEFG-0123456789"
python3 client.py --port "$PORT" --payload "$SLOW" --expect "$SLOW" \
  --slow-read 0.05 --recv-size 8 --timeout 12 > /tmp/epoll55-slow.out 2>&1
SRC=$?
cat /tmp/epoll55-slow.out
if [ "$SRC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/epoll55-slow.out; then
  ok "慢读客户端完整收到 echo（无截断）"
else
  bad "慢读客户端失败 rc=$SRC"
fi

# 若慢读触发了发送侧 EAGAIN / EPOLLOUT 路径，记一条加分观察
if grep -q "SEND_EAGAIN\|ARM fd=.*outbuf=" /tmp/epoll55-srv.log; then
  ok "观察到 SEND_EAGAIN 或按需 ARM（EPOLLOUT 状态机有活动）"
else
  ok "慢读未强制挤出 SEND_EAGAIN（环境差异可接受；echo 已完整）"
fi

# --- 4) IDLE heartbeat ---
sleep 1.2
if grep -q "IDLE heartbeat" /tmp/epoll55-srv.log; then
  ok "空闲出现 IDLE heartbeat"
else
  bad "未见 IDLE heartbeat"
fi

# --- 5) ONESHOT 漏 rearm 停滞故障 ---
kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.3

python3 server.py "$PORT" --et --oneshot --leak-rearm > /tmp/epoll55-leak.log 2>&1 &
SRV=$!
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "leak server failed:"; cat /tmp/epoll55-leak.log; bad "leak-rearm 服务启动失败"
else
  ok "leak-rearm 服务已启动"

  # 第一次发送：会被处理，然后 leak rearm
  python3 client.py --port "$PORT" --payload "first-shot" --expect "first-shot" \
    --timeout 5 --hold 0.2 > /tmp/epoll55-leak1.out 2>&1 &
  L1=$!
  # 用独立连接更清晰：先一条连接触发 leak，再同连接无法继续——
  # 我们的 leak 在第一次事件后跳过 rearm；同连接后续数据应停滞。
  # 这里用一个长持有连接：先发 first，再发 second。
  wait $L1 || true

  python3 - "$PORT" <<'PY' > /tmp/epoll55-stall.out 2>&1
import socket, sys, time, select
port=int(sys.argv[1])
s=socket.socket(); s.settimeout(2); s.connect(("127.0.0.1", port))
s.sendall(b"aaa-first")
# 读走 echo
deadline=time.time()+3
got=b""
while time.time()<deadline and b"aaa-first" not in got:
    try:
        got += s.recv(64)
    except socket.timeout:
        break
print("FIRST_GOT", got)
time.sleep(0.3)
# 此时服务应已 LEAK_REARM；再发不应被处理/回显
s.sendall(b"bbb-second-should-stall")
s.settimeout(1.5)
stalled=b""
try:
    while True:
        chunk=s.recv(64)
        if not chunk:
            break
        stalled += chunk
except socket.timeout:
    pass
print("SECOND_GOT", stalled)
if b"bbb-second" in stalled:
    print("STALL_FAIL got second echo unexpectedly")
    sys.exit(1)
print("STALL_OK no second echo")
s.close()
PY
  STRC=$?
  cat /tmp/epoll55-stall.out
  echo "---- leak server log ----"
  grep -E "LEAK_REARM|STALL|ACCEPT|RECV |ARM " /tmp/epoll55-leak.log | tail -30
  if [ "$STRC" -eq 0 ] && grep -q "STALL_OK" /tmp/epoll55-stall.out && grep -q "LEAK_REARM" /tmp/epoll55-leak.log; then
    ok "ONESHOT 漏 rearm：后续数据停滞（故障可复现）"
  else
    bad "ONESHOT 漏 rearm 演示失败 rc=$STRC"
  fi
fi

# --- 6) EADDRINUSE rc=2 ---
python3 server.py "$PORT" --et > /tmp/epoll55-bind2.out 2>&1
BRC=$?
cat /tmp/epoll55-bind2.out
if [ "$BRC" -eq 2 ] && grep -q "EADDRINUSE" /tmp/epoll55-bind2.out; then
  ok "二次 bind 同端口 EADDRINUSE 退出码 2"
else
  bad "EADDRINUSE 检查失败 rc=$BRC"
fi

echo "==== server log tail (et) ===="
tail -40 /tmp/epoll55-srv.log

if [ "$fail" -eq 0 ]; then
  echo "ALL_CHECKS_PASSED"
  exit 0
else
  echo "SOME_CHECKS_FAILED"
  exit 1
fi
