#!/usr/bin/env python3
"""epoll Echo 客户端：分片发送、慢读、半关闭、期望回显。"""
from __future__ import annotations

import argparse
import socket
import sys
import time


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=18055)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--payload", default="")
    ap.add_argument("--expect", default="")
    ap.add_argument("--timeout", type=float, default=8.0)
    ap.add_argument("--chunk", type=int, default=0, help="send in chunks of N bytes")
    ap.add_argument("--chunk-delay", type=float, default=0.05)
    ap.add_argument("--slow-read", type=float, default=0.0, help="sleep between recv calls")
    ap.add_argument("--recv-size", type=int, default=16)
    ap.add_argument("--shutdown-wr", action="store_true", help="shutdown write after send")
    ap.add_argument("--hold", type=float, default=0.0, help="keep connection open N seconds")
    args = ap.parse_args()

    s = socket.socket()
    s.settimeout(args.timeout)
    s.connect((args.host, args.port))
    print(f"CONNECTED {args.host}:{args.port}", flush=True)

    data = args.payload.encode() if args.payload else b""
    if data:
        if args.chunk and args.chunk > 0:
            for i in range(0, len(data), args.chunk):
                part = data[i : i + args.chunk]
                s.sendall(part)
                print(f"SENT_CHUNK n={len(part)}", flush=True)
                time.sleep(args.chunk_delay)
        else:
            s.sendall(data)
            print(f"SENT n={len(data)}", flush=True)

    if args.shutdown_wr:
        s.shutdown(socket.SHUT_WR)
        print("SHUTDOWN_WR", flush=True)

    buf = bytearray()
    deadline = time.time() + args.timeout
    expect = args.expect.encode() if args.expect else b""

    while time.time() < deadline:
        if expect and expect in buf:
            print(f"GOT_EXPECT ok bytes={len(buf)}", flush=True)
            print(buf.decode(errors="replace"), flush=True)
            break
        remain = deadline - time.time()
        if remain <= 0:
            break
        s.settimeout(min(1.0, remain))
        try:
            chunk = s.recv(args.recv_size)
        except socket.timeout:
            if args.hold > 0:
                continue
            if not expect:
                break
            continue
        except OSError as e:
            print(f"RECV_ERR {e}", flush=True)
            break
        if not chunk:
            print(f"PEER_EOF got_bytes={len(buf)}", flush=True)
            break
        buf.extend(chunk)
        print(f"RECV_CLIENT n={len(chunk)} total={len(buf)}", flush=True)
        if args.slow_read > 0:
            time.sleep(args.slow_read)
    else:
        if expect and expect not in buf:
            print(f"TIMEOUT expect={args.expect!r} got={bytes(buf)!r}", flush=True)
            s.close()
            sys.exit(1)

    if expect and expect not in buf:
        print(f"MISS expect={args.expect!r} got={bytes(buf)!r}", flush=True)
        s.close()
        sys.exit(1)

    if args.hold > 0:
        time.sleep(args.hold)

    s.close()
    print("CLIENT_DONE", flush=True)


if __name__ == "__main__":
    main()
