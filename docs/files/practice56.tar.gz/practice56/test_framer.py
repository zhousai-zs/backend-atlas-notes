#!/usr/bin/env python3
"""Fuzz / random-chunk tests for length-prefix Framer."""
from __future__ import annotations

import os
import random
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from framer import Framer, ProtocolError, encode, encode_many, MAX_FRAME, HDR_SIZE


def random_chunks(blob: bytes, max_chunk: int, rng: random.Random):
    i = 0
    n = len(blob)
    while i < n:
        size = rng.randint(1, max_chunk)
        yield blob[i : i + size]
        i += size


def roundtrip(msgs, seed: int, max_chunk: int = 9) -> None:
    rng = random.Random(seed)
    fr = Framer()
    got = []
    for chunk in random_chunks(encode_many(msgs), max_chunk, rng):
        got.extend(fr.feed(chunk))
    assert got == list(msgs), (seed, got, msgs)
    assert fr.pending() == 0 and fr.body_len is None


def gen_msgs(rng: random.Random):
    n = rng.randint(0, 20)
    out = []
    for _ in range(n):
        ln = rng.randint(0, 200)
        out.append(bytes(rng.getrandbits(8) for _ in range(ln)))
    return out


def test_random_seeds():
    for seed in range(1000):
        rng = random.Random(seed)
        roundtrip(gen_msgs(rng), seed=seed, max_chunk=rng.randint(1, 17))
    print("PASS random_seeds 1000")


def test_single_byte_chunks():
    msgs = [b"", b"a", b"hello", b"x" * 50, bytes(range(256))]
    roundtrip(msgs, seed=42, max_chunk=1)
    print("PASS single_byte_chunks")


def test_whole_blob():
    msgs = [b"one", b"two", b""]
    fr = Framer()
    got = fr.feed(encode_many(msgs))
    assert got == msgs
    print("PASS whole_blob")


def test_half_header_wait():
    fr = Framer()
    assert fr.feed(b"\x00\x00\x00") == []
    assert fr.pending() == 3
    # complete header length=2 + body b'AB'
    got = fr.feed(b"\x02AB")
    assert got == [b"AB"]
    print("PASS half_header_wait")


def test_half_body_wait():
    fr = Framer()
    assert fr.feed(struct.pack("!I", 5) + b"xy") == []
    got = fr.feed(b"zab")
    # length=5 body should be xyzab — we fed xy then zab
    assert got == [b"xyzab"]
    print("PASS half_body_wait")


def test_oversize_immediate():
    fr = Framer()
    bad = struct.pack("!I", MAX_FRAME + 1)
    try:
        fr.feed(bad)
        raise AssertionError("expected ProtocolError")
    except ProtocolError as e:
        assert "too large" in str(e)
    print("PASS oversize_immediate")


def test_u32_max_immediate():
    fr = Framer()
    try:
        fr.feed(struct.pack("!I", 0xFFFFFFFF))
        raise AssertionError("expected ProtocolError")
    except ProtocolError:
        pass
    print("PASS u32_max_immediate")


def test_legal_then_oversize():
    fr = Framer()
    blob = encode(b"ok") + struct.pack("!I", MAX_FRAME + 1)
    try:
        # may yield 'ok' then raise on next header
        out = fr.feed(blob)
        # if implementation raises after yielding, catch below
        raise AssertionError(f"expected ProtocolError after {out}")
    except ProtocolError:
        # ensure we at least could parse the first frame in a split feed
        fr2 = Framer()
        assert fr2.feed(encode(b"ok")) == [b"ok"]
        try:
            fr2.feed(struct.pack("!I", MAX_FRAME + 1))
            raise AssertionError("expected ProtocolError")
        except ProtocolError:
            pass
    print("PASS legal_then_oversize")


def test_network_endian_256():
    # 256 -> 00 00 01 00
    assert encode(b"x" * 256)[:4] == b"\x00\x00\x01\x00"
    print("PASS network_endian_256")


def main():
    test_network_endian_256()
    test_whole_blob()
    test_half_header_wait()
    test_half_body_wait()
    test_single_byte_chunks()
    test_oversize_immediate()
    test_u32_max_immediate()
    test_legal_then_oversize()
    test_random_seeds()
    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
