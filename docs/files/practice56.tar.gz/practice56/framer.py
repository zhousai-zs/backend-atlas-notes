#!/usr/bin/env python3
"""Length-prefixed message framing with incremental parser."""
from __future__ import annotations

import struct
from typing import List, Optional

HDR_SIZE = 4
MAX_FRAME = 1 << 20  # 1 MiB


class ProtocolError(ValueError):
    """Illegal or oversized frame length."""


def encode(msg: bytes) -> bytes:
    if len(msg) > MAX_FRAME:
        raise ProtocolError(f"encode length {len(msg)} > MAX_FRAME")
    return struct.pack("!I", len(msg)) + msg


def encode_many(msgs) -> bytes:
    return b"".join(encode(m) for m in msgs)


class Framer:
    """Incremental length-prefix parser (network-endian u32 + body)."""

    def __init__(self, max_frame: int = MAX_FRAME):
        self.buf = bytearray()
        self.body_len: Optional[int] = None
        self.max_frame = max_frame

    def feed(self, data: bytes) -> List[bytes]:
        if data:
            self.buf.extend(data)
        out: List[bytes] = []
        while True:
            if self.body_len is None:
                if len(self.buf) < HDR_SIZE:
                    break
                (length,) = struct.unpack("!I", self.buf[:HDR_SIZE])
                if length > self.max_frame:
                    raise ProtocolError(
                        f"frame too large: {length} > {self.max_frame}"
                    )
                self.body_len = length
            total = HDR_SIZE + self.body_len
            if len(self.buf) < total:
                break
            payload = bytes(self.buf[HDR_SIZE:total])
            del self.buf[:total]
            self.body_len = None
            out.append(payload)
        return out

    def pending(self) -> int:
        return len(self.buf)
