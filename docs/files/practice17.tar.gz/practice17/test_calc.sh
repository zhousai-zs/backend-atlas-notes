#!/usr/bin/env bash
# practice17 验收：带参数校验的命令行计算器
set -euo pipefail
cd "$(dirname "$0")"

CXX="${CXX:-g++}"
FLAGS=(-std=c++17 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror)

echo "[1] 严格警告编译..."
"$CXX" "${FLAGS[@]}" -o calc calc.cpp

pass=0
fail=0

check_out() {
  local desc="$1"
  local want="$2"
  shift 2
  local got rc=0
  got="$(./calc "$@" 2>/dev/null)" || rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "FAIL: $desc — 期望成功，实际 exit=$rc"
    fail=$((fail + 1))
    return
  fi
  if [[ "$got" != "$want" ]]; then
    echo "FAIL: $desc — 期望 '$want'，得到 '$got'"
    fail=$((fail + 1))
    return
  fi
  echo "OK: $desc"
  pass=$((pass + 1))
}

check_out_approx() {
  local desc="$1"
  local want_prefix="$2"
  shift 2
  local got rc=0
  got="$(./calc "$@" 2>/dev/null)" || rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "FAIL: $desc — 期望成功，实际 exit=$rc"
    fail=$((fail + 1))
    return
  fi
  case "$got" in
    ${want_prefix}*) echo "OK: $desc ($got)"; pass=$((pass + 1)) ;;
    *) echo "FAIL: $desc — 期望前缀 '$want_prefix'，得到 '$got'"; fail=$((fail + 1)) ;;
  esac
}

check_err() {
  local desc="$1"
  shift
  local rc=0
  local err
  err="$(./calc "$@" 2>&1 >/dev/null)" || rc=$?
  if [[ $rc -eq 0 ]]; then
    echo "FAIL: $desc — 期望失败，却成功了"
    fail=$((fail + 1))
    return
  fi
  if [[ -z "$err" ]]; then
    echo "FAIL: $desc — 失败但无错误信息"
    fail=$((fail + 1))
    return
  fi
  echo "OK: $desc (exit=$rc)"
  pass=$((pass + 1))
}

echo "[2] 功能与校验用例..."
check_out "加法" "7" 3 + 4
check_out "减法" "7" 10 - 3
check_out "乘法" "10" 2.5 "*" 4
check_out_approx "除法" "3.333" 10 / 3
check_out "负数左操作数" "-1" -3 + 2
check_out "整数乘法" "12" 3 "*" 4

check_err "参数不足" 1 +
check_err "参数过多" 1 + 2 + 3
check_err "非法运算符" 1 x 2
check_err "除零" 10 / 0
check_err "非数字左" abc + 2
check_err "非数字右" 1 + xyz

echo "[3] 汇总 pass=$pass fail=$fail"
if [[ "$fail" -eq 0 && "$pass" -ge 10 ]]; then
  echo "ALL_TESTS_PASSED"
  exit 0
fi
echo "SOME_TESTS_FAILED"
exit 1
