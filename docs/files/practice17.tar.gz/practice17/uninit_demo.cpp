// 演示：局部变量定义并不总会零初始化（节点 pitfalls）
// 编译查看警告: g++ -std=c++17 -Wall -Wextra -Wuninitialized -O1 -c uninit_demo.cpp
// 注意：未定义行为，切勿在生产代码中依赖未初始化值。

#include <iostream>

int maybe_bad(bool use) {
    int x;  // 未初始化的局部变量
    if (use) {
        x = 42;
    }
    // 若 use==false，读取 x 是未定义行为；-Wuninitialized 常能抓住
    return x;
}

int good(bool use) {
    int x = 0;  // 显式初始化
    if (use) {
        x = 42;
    }
    return x;
}

int main() {
    std::cout << "good(false)=" << good(false) << '\n';
    // 下面一行在开启优化+警告时可能报警；故意保留供对照学习
    // std::cout << "maybe_bad(false)=" << maybe_bad(false) << '\n';
    std::cout << "见注释：局部变量定义并不总会零初始化。\n";
    return 0;
}
