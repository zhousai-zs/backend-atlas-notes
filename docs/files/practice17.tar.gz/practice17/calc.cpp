// practice17: 带参数校验的命令行计算器
// 用法: ./calc <数> <运算符> <数>
// 例: ./calc 3 + 4
// 编译: g++ -std=c++17 -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror -o calc calc.cpp

#include <cstdlib>
#include <iostream>
#include <string>
#include <cctype>

namespace {

void print_usage(const char* prog) {
    std::cerr << "用法: " << prog << " <数> <运算符> <数>\n"
              << "支持运算符: + - * /\n"
              << "例: " << prog << " 3 + 4\n";
}

bool is_number(const std::string& s) {
    if (s.empty()) {
        return false;
    }
    std::size_t i = 0;
    if (s[0] == '+' || s[0] == '-') {
        if (s.size() == 1) {
            return false;
        }
        i = 1;
    }
    bool seen_digit = false;
    bool seen_dot = false;
    for (; i < s.size(); ++i) {
        const unsigned char ch = static_cast<unsigned char>(s[i]);
        if (std::isdigit(ch)) {
            seen_digit = true;
            continue;
        }
        if (ch == '.' && !seen_dot) {
            seen_dot = true;
            continue;
        }
        return false;
    }
    return seen_digit;
}

}  // namespace

int main(int argc, char* argv[]) {
    // 局部变量一律显式初始化（见节点 pitfalls）
    int exit_code = 0;

    if (argc != 4) {
        std::cerr << "错误: 参数个数不正确（需要 3 个操作参数）。\n";
        print_usage(argv[0]);
        return 1;
    }

    const std::string left_s(argv[1]);
    const std::string op(argv[2]);
    const std::string right_s(argv[3]);

    if (!is_number(left_s) || !is_number(right_s)) {
        std::cerr << "错误: 操作数必须是数字（整数或小数）。\n";
        print_usage(argv[0]);
        return 1;
    }

    if (op != "+" && op != "-" && op != "*" && op != "/") {
        std::cerr << "错误: 非法运算符 '" << op << "'（仅支持 + - * /）。\n";
        print_usage(argv[0]);
        return 1;
    }

    // 用 double 做运算，避免整数除法意外截断；转换用显式路径，避免窄化警告
    const double a = std::strtod(left_s.c_str(), nullptr);
    const double b = std::strtod(right_s.c_str(), nullptr);

    double result = 0.0;

    if (op == "+") {
        result = a + b;
    } else if (op == "-") {
        result = a - b;
    } else if (op == "*") {
        result = a * b;
    } else {  // "/"
        if (b == 0.0) {
            std::cerr << "错误: 除零。\n";
            return 1;
        }
        result = a / b;
    }

    // 输出：整数结果尽量无小数点，否则打印小数
    // 用显式比较，避免依赖浮点格式细节时的窄化
    const double as_int = static_cast<double>(static_cast<long long>(result));
    if (result == as_int && result >= static_cast<double>(-9223372036854775807LL - 1) &&
        result <= static_cast<double>(9223372036854775807LL)) {
        std::cout << static_cast<long long>(result) << '\n';
    } else {
        std::cout << result << '\n';
    }

    return exit_code;
}
