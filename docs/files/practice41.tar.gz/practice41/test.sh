#!/bin/bash
# Backend Atlas 第41课实践验证：可运行 vs 阻塞、nice 权重、线程池大小与亲和性
set -u; cd "$(dirname "$0")"; fail=0
gcc -O1 -Wall -pthread -o pool pool.c && gcc -O1 -o state state.c || exit 1
ok(){ echo "PASS: $1"; }; bad(){ echo "FAIL: $1"; fail=1; }
f(){ awk -v k="$2:" '$1==k{print $2}' /proc/$1/status; }
echo "nproc=$(nproc)  cgroup cpu.max=$(cat /sys/fs/cgroup/cpu.max 2>/dev/null || echo 无)"
# 1) 阻塞：睡眠进程处于 S，几乎全是自愿切换，跑队列等待很小
./state sleep 3000 & S=$!
# 2) 可运行排队：3 个自旋进程挤在 CPU0 上，处于 R，非自愿切换多，等待时间大
for i in 1 2 3; do taskset -c 0 ./state spin 3000 & done; sleep 1.5
P=$(pgrep -f 'state spin' | head -1)
echo "sleep 进程: stat=$(ps -o stat= -p $S) vol=$(f $S voluntary_ctxt_switches) nonvol=$(f $S nonvoluntary_ctxt_switches) schedstat=$(cat /proc/$S/schedstat)"
echo "spin  进程: stat=$(ps -o stat= -p $P) vol=$(f $P voluntary_ctxt_switches) nonvol=$(f $P nonvoluntary_ctxt_switches) schedstat=$(cat /proc/$P/schedstat)"
read sr sw _ < /proc/$S/schedstat; read pr pw _ < /proc/$P/schedstat
sv=$(f $S voluntary_ctxt_switches); sn=$(f $S nonvoluntary_ctxt_switches); pn=$(f $P nonvoluntary_ctxt_switches)
[ $sv -gt $((sn*10)) ] && ok "阻塞进程以自愿切换为主 ($sv vs $sn)，CPU 只用了 $((sr/1000000))ms" || bad "sleep vol=$sv nonvol=$sn"
[ $pw -gt $((pr/2)) ] && [ $pn -gt 10 ] && ok "可运行排队：运行 $((pr/1000000))ms 却在队列里等了 $((pw/1000000))ms，非自愿切换 $pn" || bad "spin run=$pr wait=$pw nonvol=$pn"
wait
# 3) nice：同一核上 nice 0 vs nice 10，CPU 时间比接近权重比 1024:110≈9.3
taskset -c 1 ./state spin 3000 & A=$!; taskset -c 1 nice -n 10 ./state spin 3000 & B=$!; sleep 1.5
read ar _ < /proc/$A/schedstat; read br _ < /proc/$B/schedstat; wait
ratio=$(awk -v a=$ar -v b=$br 'BEGIN{printf "%.1f", a/b}')
awk -v r=$ratio 'BEGIN{exit !(r>5 && r<15)}' && ok "nice0:nice10 CPU 时间比 $ratio（权重比≈9.3，不是“优先级高就独占”）" || bad "ratio=$ratio"
# 4) 线程池：大小与亲和性
echo "--- 线程池（每任务 200us CPU，到达率约 80% 容量）---"
for cfg in "$(nproc) none" "$(( $(nproc)*8 )) none" "$(nproc) spread" "$(nproc) one"; do ./pool $cfg 4000 200 | tee -a pool.log; done
p99(){ grep "threads=$1 aff=$2 " pool.log | tail -1 | sed 's/.*p99=\([0-9]*\)us.*/\1/'; }
N=$(nproc); a=$(p99 $N none); b=$(p99 $((N*8)) none); c=$(p99 $N one)
[ $b -gt $a ] && ok "线程数 ${N}→$((N*8))：p99 ${a}us→${b}us 变差" || bad "p99 $a vs $b"
[ $c -gt $((a*10)) ] && ok "全部绑到 CPU0：p99 ${c}us，绑核失去调度弹性" || bad "one p99=$c"
rm -f pool.log
[ $fail = 0 ] && echo ALL_CHECKS_PASSED
