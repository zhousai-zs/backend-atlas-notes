// 线程池压测：./pool <线程数> <亲和性: none|one|spread> <任务数> <每任务自旋us>
// 输出 吞吐、p50/p99（入队到完成）、自愿/非自愿切换、跑队列等待
#define _GNU_SOURCE
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <unistd.h>
static long now_ns(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000000000L+t.tv_nsec;}
typedef struct{long enq;} task_t;
static task_t *q; static int qh,qt,qn,done_prod; static long *lat; static int nlat;
static pthread_mutex_t mu=PTHREAD_MUTEX_INITIALIZER; static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static int spin_us; static char *aff; static int ncpu;
static long waitns_total; 
static void spin(int us){long e=now_ns()+us*1000L;while(now_ns()<e);}
static long rq_wait_ns(void){ // /proc/thread-self/schedstat 第二个字段：在运行队列上等待的纳秒
  FILE*f=fopen("/proc/thread-self/schedstat","r");long a=0,b=0;if(f){if(fscanf(f,"%ld %ld",&a,&b)!=2)b=0;fclose(f);}return b;}
static void *worker(void *arg){
  long id=(long)arg;
  if(strcmp(aff,"none")){cpu_set_t s;CPU_ZERO(&s);CPU_SET(strcmp(aff,"one")?id%ncpu:0,&s);pthread_setaffinity_np(pthread_self(),sizeof s,&s);}
  for(;;){
    pthread_mutex_lock(&mu);
    while(qh==qt&&!done_prod)pthread_cond_wait(&cv,&mu);
    if(qh==qt&&done_prod){pthread_mutex_unlock(&mu);break;}
    task_t t=q[qh++];pthread_mutex_unlock(&mu);
    spin(spin_us);
    long l=now_ns()-t.enq;
    pthread_mutex_lock(&mu);lat[nlat++]=l;pthread_mutex_unlock(&mu);
  }
  long w=rq_wait_ns();pthread_mutex_lock(&mu);waitns_total+=w;pthread_mutex_unlock(&mu);
  return 0;}
static int cmp(const void*a,const void*b){long x=*(long*)a,y=*(long*)b;return x<y?-1:x>y;}
int main(int c,char**v){
  int nt=atoi(v[1]);aff=v[2];qn=atoi(v[3]);spin_us=atoi(v[4]);ncpu=sysconf(_SC_NPROCESSORS_ONLN);
  q=calloc(qn,sizeof*q);lat=calloc(qn,sizeof*lat);
  pthread_t th[nt];for(long i=0;i<nt;i++)pthread_create(&th[i],0,worker,(void*)i);
  struct rusage r0;getrusage(RUSAGE_SELF,&r0);
  long t0=now_ns();
  // 生产者按固定速率投递：每个间隔投递一批，模拟请求到达
  int batch=ncpu*2;
  for(int i=0;i<qn;i+=batch){
    pthread_mutex_lock(&mu);
    for(int j=i;j<i+batch&&j<qn;j++){q[qt].enq=now_ns();qt++;}
    pthread_cond_broadcast(&cv);pthread_mutex_unlock(&mu);
    long e=now_ns()+(long)spin_us*1000*batch/ncpu*10/8; // 到达速率≈80% 的 CPU 容量
    while(now_ns()<e)usleep(50);
  }
  pthread_mutex_lock(&mu);done_prod=1;pthread_cond_broadcast(&cv);pthread_mutex_unlock(&mu);
  for(int i=0;i<nt;i++)pthread_join(th[i],0);
  long t1=now_ns();struct rusage r1;getrusage(RUSAGE_SELF,&r1);
  qsort(lat,nlat,sizeof*lat,cmp);
  double sec=(t1-t0)/1e9;
  printf("threads=%d aff=%s tasks=%d thr=%.0f/s p50=%.0fus p99=%.0fus vcsw=%ld nvcsw=%ld rqwait_avg=%.1fms\n",
    nt,aff,nlat,nlat/sec,lat[nlat/2]/1e3,lat[nlat*99/100]/1e3,
    r1.ru_nvcsw-r0.ru_nvcsw,r1.ru_nivcsw-r0.ru_nivcsw,waitns_total/1e6/nt);
}
