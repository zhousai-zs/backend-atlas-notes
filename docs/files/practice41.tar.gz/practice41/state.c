// 阻塞 vs 可运行：./state sleep|spin 毫秒
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static long ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000L+t.tv_nsec/1000000;}
int main(int c,char**v){long e=ms()+atol(v[2]);
 if(!strcmp(v[1],"sleep"))while(ms()<e)usleep(1000); else {volatile long x=0;while(ms()<e)x++;}
 return 0;}
