#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ${1:-} != --logged ]]; then
 set +e
 bash "$0" --logged 2>&1 | tee run.log
 status=${PIPESTATUS[0]}
 if [[ -d /workspace/atlas/gen148 && "$PWD" == /workspace/atlas/lessons/practice148 ]]; then cp run.log /workspace/atlas/gen148/run.log; fi
 exit "$status"
fi
mkdir -p build reports
if command -v g++ >/dev/null; then cxx=(g++); target=()
elif command -v clang++ >/dev/null; then cxx=(clang++); target=()
else cxx=(./tools/zig-c++); target=(-target x86_64-linux-gnu); fi
if command -v gdb >/dev/null; then gdb=$(command -v gdb)
elif [[ -n ${ATLAS_GDB:-} && -x ${ATLAS_GDB} ]]; then gdb=$ATLAS_GDB
elif [[ -x /workspace/atlas/gen148/bin/gdb ]]; then gdb=/workspace/atlas/gen148/bin/gdb
else echo 'ERROR: gdb is required; install gdb or set ATLAS_GDB' >&2; exit 1; fi
command -v readelf >/dev/null || { echo 'ERROR: readelf required' >&2; exit 1; }
printf 'Compiler: '; "${cxx[@]}" --version | head -1
printf 'Debugger: '; "$gdb" --version | head -1
printf 'RLIMIT_CORE hard: '; ulimit -Hc
for opt in 0 2; do
 "${cxx[@]}" "${target[@]}" -std=c++17 -g -O"$opt" -fno-sanitize=all -pthread -Wl,--build-id=sha1 service.cpp -o "build/service-O$opt"
done
set +e
(ulimit -c 0; ./build/service-O0) > reports/direct.txt 2>&1
crash_status=$?
set -e
printf 'Direct crash exit: %s\n' "$crash_status"
[[ $crash_status -eq 139 ]] || { echo 'ERROR: expected SIGSEGV exit 139'; exit 1; }
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
core=$scratch/crash.core
"$gdb" -q -nx -batch build/service-O0 -ex 'set pagination off' -ex run -ex 'thread apply all bt' -ex 'frame 1' -ex 'info locals' -ex "generate-core-file $core" > reports/live.txt 2>&1
cat reports/live.txt
[[ -s $core ]] && grep -q 'received signal SIGSEGV' reports/live.txt && grep -q 'selected = 0x0' reports/live.txt
"$gdb" -q -nx -batch build/service-O0 "$core" -ex 'set pagination off' -ex bt -ex 'frame 1' -ex 'info locals' > reports/core.txt 2>&1
cat reports/core.txt
grep -q 'render (item=0x0)' reports/core.txt
"$gdb" -q -nx -batch build/service-O2 "$core" -ex bt > reports/mismatch.txt 2>&1
cat reports/mismatch.txt
grep -qi "core file may not match" reports/mismatch.txt
readelf -n build/service-O0 > reports/elf-o0.txt
readelf -n build/service-O2 > reports/elf-o2.txt
python3 extract_ids.py "$core" > reports/core-build-ids.txt
id0=$(awk '/Build ID:/ {print $3; exit}' reports/elf-o0.txt)
id2=$(awk '/Build ID:/ {print $3; exit}' reports/elf-o2.txt)
cat reports/core-build-ids.txt
[[ -n $id0 && -n $id2 && $id0 != "$id2" ]]
grep -q "$id0" reports/core-build-ids.txt
if grep -q "$id2" reports/core-build-ids.txt; then echo 'ERROR: mismatch ID present in core'; exit 1; fi
printf 'O0 Build ID: %s\nO2 Build ID: %s\n' "$id0" "$id2"
for opt in 0 2; do
 "$gdb" -q -nx -batch "build/service-O$opt" -ex 'set pagination off' -ex 'break service.cpp:19' -ex run -ex 'print transient' -ex 'info registers' -ex 'disassemble /m optimized' > "reports/opt-O$opt.txt" 2>&1
 cat "reports/opt-O$opt.txt"
 grep -q 'Breakpoint 1, optimized' "reports/opt-O$opt.txt"
done
python3 - "$id0" "$id2" "$gdb" <<'PY'
import json,sys
with open('results.json','w') as f:
 json.dump({'core_generation':'gdb generate-core-file','signal':'SIGSEGV','direct_crash_exit':139,'o0_build_id':sys.argv[1],'o2_build_id':sys.argv[2],'core_contains_o0_build_id':True,'core_contains_o2_build_id':False,'gdb':sys.argv[3], 'reports':['live.txt','core.txt','mismatch.txt','core-build-ids.txt','opt-O0.txt','opt-O2.txt']},f,indent=2); f.write('\n')
PY
echo ALL_CHECKS_PASSED
