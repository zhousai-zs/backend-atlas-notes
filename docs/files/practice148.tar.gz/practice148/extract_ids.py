import struct, subprocess, sys, tempfile
with open(sys.argv[1], 'rb') as f:
 h=f.read(64)
 if h[:6]!=b'\x7fELF\x02\x01': raise SystemExit('ELF64 little-endian core required')
 phoff=struct.unpack_from('<Q',h,32)[0]; entsize,count=struct.unpack_from('<HH',h,54)
 for i in range(count):
  f.seek(phoff+i*entsize); p=f.read(entsize)
  typ,=struct.unpack_from('<I',p); off,addr=struct.unpack_from('<QQ',p,8); size,=struct.unpack_from('<Q',p,32)
  if typ!=1 or size<64: continue
  f.seek(off); data=f.read(min(size,65536))
  if data[:4]!=b'\x7fELF': continue
  with tempfile.NamedTemporaryFile() as t:
   t.write(data); t.flush(); result=subprocess.run(['readelf','-n',t.name],capture_output=True,text=True)
  for line in result.stdout.splitlines():
   if 'Build ID:' in line: print(f'mapped ELF at {addr:#x}: {line.strip()}')
