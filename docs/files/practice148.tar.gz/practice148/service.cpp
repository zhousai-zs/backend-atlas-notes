#include <pthread.h>
#include <unistd.h>
#include <cstdlib>

struct Item { int score; };
__attribute__((noinline)) void render(Item* item) {
    volatile int result = item->score;
    (void)result;
}
__attribute__((noinline)) void process() {
    Item valid{42};
    Item* selected = &valid;
    selected = nullptr; // 教学假设：错误的筛选逻辑覆盖了指针
    render(selected);
}
void* worker(void*) { process(); return nullptr; }
__attribute__((noinline)) int optimized(int input) {
    int transient = input * 7;
    asm volatile("" : : "r"(input) : "memory");
    return input + 1;
}
int main() {
    volatile int value = optimized(5);
    (void)value;
    pthread_t thread;
    if (pthread_create(&thread, nullptr, worker, nullptr)) return 2;
    pthread_join(thread, nullptr);
}
