#include <cstdint>
#include <cstdio>

int main() {
    const std::uint8_t* data = nullptr;
    std::printf("about to dereference nullptr\n");
    return static_cast<int>(*data);
}
