#pragma once

#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>

namespace wx {

class ByteBuffer {
public:
    explicit ByteBuffer(std::size_t size) : data_(size) {}

    ByteBuffer(std::initializer_list<std::uint8_t> init) : data_(init) {}

    std::size_t size() const noexcept { return data_.size(); }

    bool empty() const noexcept { return data_.empty(); }

    std::uint8_t& at(std::size_t index) {
        check(index);
        return data_[index];
    }

    const std::uint8_t& at(std::size_t index) const {
        check(index);
        return data_[index];
    }

    std::uint8_t* data() noexcept { return data_.data(); }

    const std::uint8_t* data() const noexcept { return data_.data(); }

private:
    void check(std::size_t index) const {
        if (index >= data_.size()) {
            throw std::out_of_range("ByteBuffer::at index " +
                                    std::to_string(index) + " >= size " +
                                    std::to_string(data_.size()));
        }
    }

    std::vector<std::uint8_t> data_;
};

class ByteView {
public:
    ByteView(const std::uint8_t* data, std::size_t size) noexcept
        : data_(data), size_(size) {}

    explicit ByteView(const ByteBuffer& buffer) noexcept
        : data_(buffer.data()), size_(buffer.size()) {}

    std::size_t size() const noexcept { return size_; }

    const std::uint8_t& at(std::size_t index) const {
        if (index >= size_) {
            throw std::out_of_range("ByteView::at index " +
                                    std::to_string(index) + " >= size " +
                                    std::to_string(size_));
        }
        return data_[index];
    }

    const std::uint8_t* data() const noexcept { return data_; }

private:
    const std::uint8_t* data_;
    std::size_t size_;
};

}
