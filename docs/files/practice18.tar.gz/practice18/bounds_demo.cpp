#include "byte_buffer.hpp"

#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

int failures = 0;

void check(bool condition, const std::string& name) {
    if (condition) {
        std::cout << "[PASS] " << name << '\n';
    } else {
        ++failures;
        std::cout << "[FAIL] " << name << '\n';
    }
}

template <typename Fn>
void check_throws_out_of_range(Fn fn, const std::string& name) {
    try {
        fn();
        check(false, name + " (no exception thrown)");
    } catch (const std::out_of_range&) {
        check(true, name);
    } catch (const std::exception& e) {
        check(false, name + " (wrong exception: " + e.what() + ")");
    }
}

void test_read_write() {
    wx::ByteBuffer buffer{0x10, 0x20, 0x30, 0x40};
    check(buffer.size() == 4, "size is 4");
    check(buffer.at(0) == 0x10, "at(0) reads first byte");
    buffer.at(0) = 0xFF;
    check(buffer.at(0) == 0xFF, "at(0) writes first byte");
    check(buffer.at(3) == 0x40, "at(3) reads last byte");
}

void test_bounds() {
    wx::ByteBuffer buffer{0x01, 0x02, 0x03};
    check_throws_out_of_range([&] { (void)buffer.at(3); }, "at(3) rejects one-past-end");
    check_throws_out_of_range([&] { (void)buffer.at(100); }, "at(100) rejects far index");
    check_throws_out_of_range([&] { buffer.at(3) = 0xAA; }, "at(3) write rejects");
}

void test_const_and_pointer_forms() {
    wx::ByteBuffer buffer{0x01, 0x02};
    const wx::ByteBuffer& const_buffer = buffer;

    check(const_buffer.at(0) == 0x01, "const buffer can read through const at()");

    const std::uint8_t* pointer_to_const = const_buffer.data();
    check(pointer_to_const[1] == 0x02, "pointer-to-const reads second byte");
    pointer_to_const = buffer.data();
    check(pointer_to_const[0] == 0x01, "pointer-to-const itself can be rebound");

    std::uint8_t* const const_pointer = buffer.data();
    const_pointer[0] = 0x0A;
    check(buffer.at(0) == 0x0A, "const pointer can modify the pointee");

    const std::uint8_t* const const_pointer_to_const = buffer.data();
    check(const_pointer_to_const[0] == 0x0A, "const pointer-to-const can read");
}

void test_non_owning_view() {
    wx::ByteBuffer buffer{0xDE, 0xAD, 0xBE, 0xEF};
    wx::ByteView view(buffer);
    check(view.size() == 4, "view keeps size");
    check(view.at(2) == 0xBE, "view reads through non-owning pointer");
    check_throws_out_of_range([&] { (void)view.at(4); }, "view rejects out-of-range read");
}

}

int main() {
    test_read_write();
    test_bounds();
    test_const_and_pointer_forms();
    test_non_owning_view();

    if (failures != 0) {
        std::cout << failures << " test(s) failed\n";
        return 1;
    }
    std::cout << "all tests passed\n";
    return 0;
}
