#include <cstdint>
#include <cstdio>
#include <string>

namespace {

const std::string& local_greeting() {
    std::string local = "hello from a local string";
    return local;
}

int heap_reference_case() {
    std::uint8_t* payload = new std::uint8_t[4]{0x01, 0x02, 0x03, 0x04};
    std::uint8_t& second = payload[1];
    delete[] payload;
    return static_cast<int>(second);
}

int stack_scope_case() {
    std::uint8_t* second = nullptr;
    {
        std::uint8_t frame[4] = {0x0A, 0x0B, 0x0C, 0x0D};
        second = &frame[1];
    }
    return static_cast<int>(*second);
}

}

int main(int argc, char** argv) {
    const std::string mode = argc > 1 ? argv[1] : "heap";

    if (mode == "heap") {
        std::printf("read through dangling heap reference: %d\n", heap_reference_case());
        return 0;
    }
    if (mode == "stack") {
        std::printf("read through dangling stack pointer: %d\n", stack_scope_case());
        return 0;
    }
    if (mode == "return") {
        const std::string& greeting = local_greeting();
        std::printf("read through returned local reference: %s\n", greeting.c_str());
        return 0;
    }

    std::fprintf(stderr, "usage: %s [heap|stack|return]\n", argv[0]);
    return 2;
}
