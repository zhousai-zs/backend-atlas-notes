#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

CXX="${CXX:-g++}"
STD=(-std=c++17)
WARN=(-Wall -Wextra -Wpedantic)
ASAN=(-fsanitize=address -fno-omit-frame-pointer -g -O0)
TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

echo "== 1. build and run bounds-checked buffer tests =="
"$CXX" "${STD[@]}" "${WARN[@]}" -Werror -g -O1 \
    bounds_demo.cpp -o "$TMPDIR/bounds_demo"
"$TMPDIR/bounds_demo"

echo
echo "== 2. build dangling-reference demo with ASan =="
"$CXX" "${STD[@]}" "${WARN[@]}" "${ASAN[@]}" \
    dangling_ref.cpp -o "$TMPDIR/dangling_ref"

run_asan_case() {
    local mode="$1"
    local expect="$2"
    local log="$TMPDIR/${mode}.log"
    set +e
    "$TMPDIR/dangling_ref" "$mode" >"$log" 2>&1
    local status=$?
    set -e
    echo "-- case: $mode (exit=$status) --"
    if [ "$status" -eq 0 ]; then
        echo "[FAIL] expected AddressSanitizer to abort, but process exited 0"
        return 1
    fi
    if ! grep -q "$expect" "$log"; then
        echo "[FAIL] expected '$expect' in ASan report"
        sed -n '1,25p' "$log"
        return 1
    fi
    grep -m1 "ERROR: AddressSanitizer" "$log"
    echo "[PASS] ASan reported $expect"
}

echo
run_asan_case heap "heap-use-after-free"
run_asan_case stack "stack-use-after-scope"

echo
echo "all practice18 checks passed"
