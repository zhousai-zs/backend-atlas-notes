# practice18：边界检查缓冲区与悬垂引用

对应课程：`18-b-pointer.md`（节点 `b-pointer`，指针、引用与借用边界）。

## 目录

| 文件 | 作用 |
|------|------|
| `byte_buffer.hpp` | `wx::ByteBuffer`（拥有字节）与 `wx::ByteView`（非拥有视图），`at()` 做边界检查 |
| `bounds_demo.cpp` | 边界、`const`、非拥有视图的断言式测试 |
| `dangling_ref.cpp` | 三种悬垂引用/悬垂指针场景，供 ASan 定位 |
| `null_demo.cpp` | 空指针解引用，观察 ASan 的 `SEGV on unknown address 0x0` 报告 |
| `test.sh` | 一键编译、运行测试并检查 ASan 报告 |

## 一键运行

```bash
cd /workspace/atlas/lessons/practice18
chmod +x test.sh
./test.sh
```

要求：Linux + `g++`（支持 `-std=c++17` 与 `-fsanitize=address`）。

## 手动编译运行

### 1. 边界检查缓冲区

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O1 \
    bounds_demo.cpp -o bounds_demo
./bounds_demo
```

预期最后一行：`all tests passed`。

`ByteBuffer::at()` 在索引 `>= size()` 时抛出 `std::out_of_range`；`const` 版本返回
`const std::uint8_t&`，因此常量缓冲区只能读。`ByteView` 只保存指针和长度，不拥有数据，
调用者必须保证底层缓冲区在视图使用期间存活。

### 2. 用 ASan 定位悬垂引用

```bash
g++ -std=c++17 -Wall -Wextra -g -O0 \
    -fsanitize=address -fno-omit-frame-pointer \
    dangling_ref.cpp -o dangling_ref

./dangling_ref heap
./dangling_ref stack
./dangling_ref return
```

`-O0` 是为了让“释放后再读”的代码保持原样；开启优化后，未定义行为可能被编译器重排或删掉，
ASan 就未必能在同一位置报错。

- `heap`：引用绑定到 `new[]` 出来的字节，`delete[]` 后继续读，ASan 报
  `heap-use-after-free`，并在报告里给出释放点和读取点的调用栈。
- `stack`：指针指向块作用域内数组元素，离开作用域后解引用，ASan 报
  `stack-use-after-scope`。
- `return`：函数返回局部 `std::string` 的引用。编译器会给出
  `-Wreturn-local-addr` 警告；这类 use-after-return 在 GCC 的 ASan 下不保证被拦截，
  可能读到垃圾、崩溃或“看起来正常”，因此**不要依赖运行期工具兜底，必须在代码评审阶段拒绝**。

### 3. 空指针解引用

```bash
g++ -std=c++17 -g -fsanitize=address -fno-omit-frame-pointer \
    null_demo.cpp -o null_demo
./null_demo
```

预期报告包含 `SEGV on unknown address 0x000000000000`，`0x0` 就是空地址。

ASan 报告里重点看三样东西：

1. `ERROR: AddressSanitizer: ...` 说明错误类别（越界、use-after-free、use-after-scope）。
2. `READ of size N` 与 `#0/#1/...` 调用栈说明“哪一行在访问”。
3. `freed by thread T0 here` / `located in stack of thread T0` 说明对象原本在哪里、何时失效。

## 正确做法

- 返回对象本身（按值返回，依赖 RVO/移动），或返回由调用者拥有的容器/智能指针。
- 需要“借用”时，把生命周期契约写进接口名、注释或类型（例如明确的 `ByteView` 只在下一次
  修改缓冲区前有效），并让拥有者在借用期间保持存活。
- 不要因为“指针非空”就认为对象还活着；判断有效性要靠所有权与生命周期设计，而不是 `p != nullptr`。
