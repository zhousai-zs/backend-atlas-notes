#!/usr/bin/env node
/**
 * Practice 183: official @earendil-works/pi-coding-agent@1.5.2 harness.
 * Uses official fauxProvider from @earendil-works/pi-ai (scripted, offline).
 * Does not call a live/paid model. Does not read secret values.
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { Type } from "typebox";
import {
  createAgentSession,
  SessionManager,
  SettingsManager,
  ModelRuntime,
  defineTool,
  RpcClient,
} from "@earendil-works/pi-coding-agent";
import { fauxProvider, fauxAssistantMessage, fauxToolCall } from "@earendil-works/pi-ai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const mainEntry = fileURLToPath(import.meta.resolve("@earendil-works/pi-coding-agent"));
const pkgDir = path.resolve(path.dirname(mainEntry), ".."); // dist/index.js -> package root
const pkgJsonPath = path.join(pkgDir, "package.json");
const pkg = JSON.parse(fs.readFileSync(pkgJsonPath, "utf8"));
const CLI_PATH = path.join(pkgDir, "dist/bundle/cli.js");

for (const k of Object.keys(process.env)) {
  if (/(API_KEY|ACCESS_TOKEN|SECRET|PASSWORD)/i.test(k)) delete process.env[k];
}

const SECRET_MARKER = "SECRET=do-not-read";
const PLANTED_MEMORY = "PLANTED_MEMORY_SHOULD_NOT_PERSIST";

function childPids(pid) {
  const pids = new Set();
  const visit = (p) => {
    const f = `/proc/${p}/task/${p}/children`;
    if (!fs.existsSync(f)) return;
    const text = fs.readFileSync(f, "utf8").trim();
    if (!text) return;
    for (const c of text.split(/\s+/).map(Number).filter(Boolean)) {
      if (!pids.has(c)) {
        pids.add(c);
        visit(c);
      }
    }
  };
  visit(pid);
  return [...pids];
}

function alive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function recapMessages(messages) {
  return (messages || []).map((m) => {
    const texts = [];
    if (typeof m.content === "string") texts.push(m.content);
    if (Array.isArray(m.content)) {
      for (const part of m.content) {
        if (typeof part === "string") texts.push(part);
        else if (part && typeof part.text === "string") texts.push(part.text);
      }
    }
    if (typeof m.text === "string") texts.push(m.text);
    return { role: m.role || m.type || "?", text: texts.join("\n").slice(0, 400) };
  });
}

function contains(hay, needle) {
  return JSON.stringify(hay).includes(needle);
}

async function makeRuntime(faux) {
  const runtime = await ModelRuntime.create({
    allowModelNetwork: false,
    refreshOnCreate: false,
    modelsPath: null,
    authPath: path.join(process.env.PI_CODING_AGENT_DIR, "auth.json"),
  });
  runtime.registerNativeProvider(faux.provider);
  return runtime;
}

function makeSummarizeTool({ allowedRoot, cwd, slowMs = 0, calls }) {
  return defineTool({
    name: "summarize_build_log",
    label: "Summarize build log",
    description: "Read a build log under the workspace logs/ directory and return a short summary. No shell.",
    parameters: Type.Object({ relpath: Type.String() }),
    async execute(_id, params, signal) {
      const rec = { relpath: params.relpath, authorized: false, aborted: false };
      calls.push(rec);
      if (slowMs > 0) {
        await new Promise((resolve, reject) => {
          const t = setTimeout(resolve, slowMs);
          const onAbort = () => {
            clearTimeout(t);
            rec.aborted = true;
            reject(Object.assign(new Error("aborted"), { name: "AbortError" }));
          };
          if (signal?.aborted) return onAbort();
          signal?.addEventListener("abort", onAbort, { once: true });
        });
      }
      const resolved = path.resolve(cwd, params.relpath);
      const allowed = resolved === allowedRoot || resolved.startsWith(allowedRoot + path.sep);
      if (!allowed) {
        rec.authorized = false;
        rec.resolved = resolved;
        return {
          content: [{ type: "text", text: "ERROR: unauthorized path" }],
          details: { reason: "unauthorized_path", resolved },
          isError: true,
        };
      }
      rec.authorized = true;
      rec.resolved = resolved;
      const text = fs.readFileSync(resolved, "utf8");
      const lines = text.trim().split("\n");
      const summary = lines.filter((l) => /error|fail/i.test(l)).slice(0, 8).join("\n") || "(no error lines)";
      return {
        content: [{ type: "text", text: summary }],
        details: { path: resolved, lines: lines.length },
      };
    },
  });
}

async function openSession({ cwd, agentDir, faux, tool, sessionManager }) {
  const runtime = await makeRuntime(faux);
  const settings = SettingsManager.inMemory({});
  const { session } = await createAgentSession({
    cwd,
    agentDir,
    modelRuntime: runtime,
    model: faux.getModel(),
    noTools: "builtin",
    customTools: [tool],
    sessionManager,
    settingsManager: settings,
  });
  return session;
}

async function main() {
  const workspace = path.join(__dirname, "workspace");
  fs.rmSync(workspace, { recursive: true, force: true });
  fs.mkdirSync(workspace, { recursive: true });
  const reports = path.join(__dirname, "reports");
  fs.rmSync(reports, { recursive: true, force: true });
  fs.mkdirSync(reports, { recursive: true });

  const agentDir = path.join(workspace, "agent-dir");
  const cwdA = path.join(workspace, "projA");
  const cwdB = path.join(workspace, "projB");
  fs.mkdirSync(path.join(cwdA, "logs"), { recursive: true });
  fs.mkdirSync(path.join(cwdB, "logs"), { recursive: true });
  fs.mkdirSync(agentDir, { recursive: true });
  fs.writeFileSync(path.join(cwdA, "logs", "build.log"), "error: undefined reference to exists\nFAILED at src/kv.cpp:41\n");
  fs.writeFileSync(path.join(cwdB, "logs", "build.log"), "other project log, should not leak\n");
  fs.writeFileSync(path.join(workspace, "secret.env"), SECRET_MARKER + "\n");

  process.env.PI_CODING_AGENT_DIR = agentDir;
  process.env.HOME = path.join(workspace, "home");
  fs.mkdirSync(process.env.HOME, { recursive: true });

  const results = {
    lesson: 183,
    id: "l-pi",
    package: "@earendil-works/pi-coding-agent",
    package_version: pkg.version,
    official_bin: "dist/bundle/cli.js",
    cli_path_exists: fs.existsSync(CLI_PATH),
    is_live_model: false,
    scripted_model_is_not_an_llm: true,
    official_faux_provider: true,
    openai_api_key_used: Boolean(process.env.OPENAI_API_KEY),
    verified_on_this_machine: [],
    not_verified_on_this_machine: [],
  };

  if (pkg.version !== "1.5.2") {
    throw new Error(`expected @earendil-works/pi-coding-agent@1.5.2, got ${pkg.version}`);
  }
  if (pkg.name === "@mariozechner/pi-coding-agent") {
    throw new Error("legacy package name must not be used");
  }

  // ---- 1. SDK tool loop (official fauxProvider, no bash) ----
  const calls1 = [];
  const faux1 = fauxProvider({ provider: "faux", api: "faux" });
  faux1.setResponses([
    fauxAssistantMessage([
      fauxToolCall("summarize_build_log", { relpath: "logs/build.log" }, { id: "call_ok" }),
    ], { stopReason: "toolUse" }),
    fauxAssistantMessage("Build failed: undefined reference to exists at src/kv.cpp:41."),
  ]);
  const smA = SessionManager.create(cwdA);
  const session1 = await openSession({
    cwd: cwdA,
    agentDir,
    faux: faux1,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: calls1 }),
    sessionManager: smA,
  });
  const tools1 = session1.getActiveToolNames();
  const events1 = [];
  const unsub1 = session1.subscribe((ev) => events1.push(ev.type));
  await session1.prompt("Read the build log and summarize the failure.");
  const final1 = session1.getLastAssistantText();
  const sessionFileA = session1.sessionFile;
  const sessionIdA = session1.sessionId;
  unsub1();
  session1.dispose();

  results.sdk_tools = tools1;
  results.sdk_final = final1;
  results.sdk_session_file = sessionFileA;
  results.sdk_session_id = sessionIdA;
  results.sdk_events = events1;
  results.sdk_tool_authorized = calls1.some((c) => c.authorized && c.relpath === "logs/build.log");
  results.sdk_no_bash_tool = Array.isArray(tools1) && tools1.includes("summarize_build_log") && !tools1.includes("bash");
  results.sdk_has_tool_events = events1.includes("tool_execution_start") && events1.includes("tool_execution_end");
  if (!results.sdk_tool_authorized || !results.sdk_no_bash_tool || !final1?.includes("src/kv.cpp:41")) {
    throw new Error(`sdk loop failed: tools=${tools1} final=${final1} calls=${JSON.stringify(calls1)}`);
  }
  fs.copyFileSync(sessionFileA, path.join(reports, "session-a.jsonl"));

  // ---- 2. Restart restores the same activity history ----
  const faux2 = fauxProvider({ provider: "faux", api: "faux" });
  faux2.setResponses([fauxAssistantMessage("I see the previous build diagnosis in history.")]);
  const smOpen = SessionManager.open(sessionFileA);
  const session2 = await openSession({
    cwd: cwdA,
    agentDir,
    faux: faux2,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: [] }),
    sessionManager: smOpen,
  });
  const restored = recapMessages(session2.agent?.state?.messages || session2.state?.messages || []);
  const restoredBlob = JSON.stringify(restored);
  results.restart_session_id = session2.sessionId;
  results.restart_same_id = session2.sessionId === sessionIdA;
  results.restart_has_user_prompt = restoredBlob.includes("Read the build log");
  results.restart_has_final_text = restoredBlob.includes("src/kv.cpp:41") || restoredBlob.includes("undefined reference");
  results.restart_message_roles = restored.map((m) => m.role);
  if (!results.restart_same_id || !results.restart_has_user_prompt || !results.restart_has_final_text) {
    throw new Error(`restore failed: ${JSON.stringify(results, null, 2)}\n${restoredBlob.slice(0, 2000)}`);
  }

  // ---- Official pitfall: assigning agent.state.messages does not replace persisted history ----
  const beforeAssign = fs.readFileSync(sessionFileA, "utf8");
  try {
    if (session2.agent?.state) {
      session2.agent.state.messages = [{ role: "assistant", content: PLANTED_MEMORY, text: PLANTED_MEMORY }];
    }
    if (session2.state) {
      session2.state.messages = [{ role: "assistant", content: PLANTED_MEMORY, text: PLANTED_MEMORY }];
    }
  } catch (e) {
    results.assign_threw = String(e.message || e);
  }
  session2.dispose();
  const afterAssign = fs.readFileSync(sessionFileA, "utf8");
  const smReopen = SessionManager.open(sessionFileA);
  const session2b = await openSession({
    cwd: cwdA,
    agentDir,
    faux: fauxProvider({ provider: "faux", api: "faux" }),
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: [] }),
    sessionManager: smReopen,
  });
  const afterMessages = recapMessages(session2b.agent?.state?.messages || session2b.state?.messages || []);
  const afterBlob = JSON.stringify(afterMessages) + afterAssign;
  results.assign_did_not_rewrite_file = afterAssign === beforeAssign || !afterAssign.includes(PLANTED_MEMORY);
  results.assign_reopen_has_planted = afterBlob.includes(PLANTED_MEMORY);
  results.assign_reopen_still_has_real_history = afterBlob.includes("Read the build log") && !afterBlob.includes(PLANTED_MEMORY);
  session2b.dispose();
  if (!results.assign_did_not_rewrite_file || results.assign_reopen_has_planted || !results.assign_reopen_still_has_real_history) {
    throw new Error(`pitfall check failed: planted leaked into SessionManager history`);
  }

  // ---- 3. Different workdirs do not mix sessions ----
  const listA = await SessionManager.list(cwdA);
  const listB_before = await SessionManager.list(cwdB);
  const fauxB = fauxProvider({ provider: "faux", api: "faux" });
  fauxB.setResponses([
    fauxAssistantMessage([
      fauxToolCall("summarize_build_log", { relpath: "logs/build.log" }, { id: "call_b" }),
    ], { stopReason: "toolUse" }),
    fauxAssistantMessage("Project B log has no compiler errors."),
  ]);
  const callsB = [];
  const smB = SessionManager.create(cwdB);
  const sessionB = await openSession({
    cwd: cwdB,
    agentDir,
    faux: fauxB,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdB, "logs"), cwd: cwdB, calls: callsB }),
    sessionManager: smB,
  });
  await sessionB.prompt("Summarize this project's build log.");
  const sessionFileB = sessionB.sessionFile;
  const sessionIdB = sessionB.sessionId;
  const messagesB = recapMessages(sessionB.agent?.state?.messages || sessionB.state?.messages || []);
  sessionB.dispose();
  const listA2 = await SessionManager.list(cwdA);
  const listB = await SessionManager.list(cwdB);
  const idsA = listA2.map((s) => s.id);
  const idsB = listB.map((s) => s.id);
  const blobB = JSON.stringify(messagesB);
  results.cwd_session_dirs_differ = path.dirname(sessionFileA) !== path.dirname(sessionFileB);
  results.cwd_b_list_before_empty = listB_before.length === 0;
  results.cwd_ids_a = idsA;
  results.cwd_ids_b = idsB;
  results.cwd_b_does_not_contain_a = !idsB.includes(sessionIdA) && sessionIdB !== sessionIdA;
  results.cwd_a_does_not_contain_b = !idsA.includes(sessionIdB);
  results.cwd_b_history_has_no_a_prompt = !blobB.includes("Read the build log and summarize the failure.");
  results.cwd_b_history_has_own_prompt = blobB.includes("Summarize this project's build log.");
  results.cwd_b_did_not_read_a_log = !blobB.includes("undefined reference") && !blobB.includes("kv.cpp");
  if (!results.cwd_session_dirs_differ || !results.cwd_b_does_not_contain_a || !results.cwd_a_does_not_contain_b || !results.cwd_b_history_has_no_a_prompt) {
    throw new Error(`cwd isolation failed: ${JSON.stringify({ idsA, idsB, sessionFileA, sessionFileB, blobB: blobB.slice(0, 500) })}`);
  }

  // ---- 4. Permission is enforced in the host executor, not tool/extension prose ----
  const callsDenied = [];
  const fauxDenied = fauxProvider({ provider: "faux", api: "faux" });
  fauxDenied.setResponses([
    fauxAssistantMessage([
      fauxToolCall("summarize_build_log", { relpath: "logs/../../secret.env" }, { id: "call_deny" }),
    ], { stopReason: "toolUse" }),
    fauxAssistantMessage("The log tool rejected that path."),
  ]);
  const smDeny = SessionManager.create(cwdA);
  const sessionDeny = await openSession({
    cwd: cwdA,
    agentDir,
    faux: fauxDenied,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: callsDenied }),
    sessionManager: smDeny,
  });
  const denyEvents = [];
  const unsubDeny = sessionDeny.subscribe((ev) => denyEvents.push(ev));
  await sessionDeny.prompt("Summarize logs/../../secret.env");
  const denyFinal = sessionDeny.getLastAssistantText() || "";
  const denyBlob = JSON.stringify({ callsDenied, denyFinal, events: denyEvents.map((e) => e.type) });
  unsubDeny();
  sessionDeny.dispose();
  results.unauthorized_rejected = callsDenied.some((c) => c.relpath.includes("secret.env") && c.authorized === false);
  results.unauthorized_did_not_read_secret = !denyBlob.includes(SECRET_MARKER) && !denyFinal.includes(SECRET_MARKER);
  results.unauthorized_tool_error = callsDenied.length > 0;
  if (!results.unauthorized_rejected || !results.unauthorized_did_not_read_secret) {
    throw new Error(`permission check failed: ${denyBlob}`);
  }

  // bash is not in the loadout; a scripted bash call must not execute a shell
  const callsNoBash = [];
  const fauxBash = fauxProvider({ provider: "faux", api: "faux" });
  fauxBash.setResponses([
    fauxAssistantMessage([
      fauxToolCall("bash", { command: `cat ${path.join(workspace, "secret.env")}` }, { id: "call_bash" }),
    ], { stopReason: "toolUse" }),
    fauxAssistantMessage("I cannot run bash in this session."),
  ]);
  const smNoBash = SessionManager.create(cwdA);
  const sessionNoBash = await openSession({
    cwd: cwdA,
    agentDir,
    faux: fauxBash,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: callsNoBash }),
    sessionManager: smNoBash,
  });
  let bashPromptError = null;
  try {
    await sessionNoBash.prompt("Run cat on the secret file via bash.");
  } catch (e) {
    bashPromptError = String(e.message || e);
  }
  const bashFinal = sessionNoBash.getLastAssistantText() || "";
  const bashMsgs = recapMessages(sessionNoBash.agent?.state?.messages || sessionNoBash.state?.messages || []);
  const noBashTools = sessionNoBash.getActiveToolNames();
  const bashBlob = JSON.stringify({ bashFinal, bashMsgs, bashPromptError, tools: noBashTools });
  sessionNoBash.dispose();
  results.bash_not_in_loadout = Array.isArray(noBashTools) && !noBashTools.includes("bash");
  results.bash_call_did_not_leak_secret = !bashBlob.includes(SECRET_MARKER);
  results.bash_prompt_error = bashPromptError;
  results.bash_final = bashFinal;
  if (!results.bash_call_did_not_leak_secret) {
    throw new Error("bash stand-in leaked secret");
  }

  // ---- 5. abort + dispose: no leftover events, no leftover children ----
  const callsSlow = [];
  const fauxSlow = fauxProvider({ provider: "faux", api: "faux" });
  fauxSlow.setResponses([
    fauxAssistantMessage([
      fauxToolCall("summarize_build_log", { relpath: "logs/build.log" }, { id: "call_slow" }),
    ], { stopReason: "toolUse" }),
    fauxAssistantMessage("This text should not be needed if abort works."),
  ]);
  const smSlow = SessionManager.create(cwdA);
  const sessionSlow = await openSession({
    cwd: cwdA,
    agentDir,
    faux: fauxSlow,
    tool: makeSummarizeTool({ allowedRoot: path.join(cwdA, "logs"), cwd: cwdA, calls: callsSlow, slowMs: 8000 }),
    sessionManager: smSlow,
  });
  const eventsBeforeDispose = [];
  const eventsAfterDispose = [];
  let disposed = false;
  const unsubSlow = sessionSlow.subscribe((ev) => {
    if (disposed) eventsAfterDispose.push(ev.type);
    else eventsBeforeDispose.push(ev.type);
  });
  const promptPromise = sessionSlow.prompt("Slow summarize.");
  await new Promise((r) => setTimeout(r, 200));
  await sessionSlow.abort();
  let promptOutcome = "pending";
  try {
    await promptPromise;
    promptOutcome = "resolved";
  } catch (e) {
    promptOutcome = `rejected:${e.message || e}`;
  }
  const childrenBeforeDispose = childPids(process.pid);
  sessionSlow.dispose();
  disposed = true;
  // Attempting another prompt on a disposed session must not emit new turn events.
  let postDisposePrompt = null;
  try {
    await sessionSlow.prompt("Should not run.");
    postDisposePrompt = "resolved";
  } catch (e) {
    postDisposePrompt = `rejected:${e.name || ""}:${e.message || e}`;
  }
  await new Promise((r) => setTimeout(r, 200));
  unsubSlow();
  results.abort_saw_tool_or_turn = eventsBeforeDispose.includes("tool_execution_start") || eventsBeforeDispose.includes("turn_start") || eventsBeforeDispose.includes("agent_start");
  results.abort_tool_aborted_or_stopped = callsSlow.some((c) => c.aborted) || !eventsBeforeDispose.includes("tool_execution_end") || promptOutcome !== "pending";
  results.abort_prompt_outcome = promptOutcome;
  results.events_after_dispose = eventsAfterDispose;
  results.no_events_after_dispose = eventsAfterDispose.length === 0;
  results.post_dispose_prompt = postDisposePrompt;
  results.children_after_sdk_dispose = childrenBeforeDispose.filter((p) => alive(p));
  if (!results.no_events_after_dispose) {
    throw new Error(`dispose leaked events: ${eventsAfterDispose}`);
  }

  // ---- 6. Official RpcClient: command/response vs event stream, abort, no leftover child ----
  const rpcHome = path.join(workspace, "rpc-home");
  const rpcAgent = path.join(workspace, "rpc-agent");
  const rpcCwd = path.join(workspace, "rpc-cwd");
  fs.mkdirSync(rpcHome, { recursive: true });
  fs.mkdirSync(rpcAgent, { recursive: true });
  fs.mkdirSync(rpcCwd, { recursive: true });
  const rpcEvents = [];
  const rpcClient = new RpcClient({
    cliPath: CLI_PATH,
    cwd: rpcCwd,
    env: {
      HOME: rpcHome,
      PI_CODING_AGENT_DIR: rpcAgent,
      // Keep PATH so node can run; do not forward keys (already deleted).
    },
    args: ["--no-session"],
  });
  const beforeRpcChildren = new Set(childPids(process.pid));
  let rpcChildPid = null;
  let rpcState = null;
  let rpcPrompt = null;
  let rpcPromptError = null;
  try {
    await rpcClient.start();
    const afterStart = childPids(process.pid);
    rpcChildPid = afterStart.find((p) => !beforeRpcChildren.has(p)) || afterStart[0] || null;
    const unsubRpc = rpcClient.onEvent((ev) => rpcEvents.push(ev.type || ev));
    rpcState = await rpcClient.getState();
    try {
      rpcPrompt = await rpcClient.prompt("This should not call a live model.");
    } catch (e) {
      rpcPromptError = String(e.message || e);
    }
    await rpcClient.abort();
    unsubRpc();
    await rpcClient.stop();
  } catch (e) {
    results.rpc_error = String(e.message || e);
    results.rpc_stderr = rpcClient.getStderr?.() || "";
    try { await rpcClient.stop(); } catch {}
    throw e;
  }
  await new Promise((r) => setTimeout(r, 300));
  results.rpc_cli_path = CLI_PATH;
  results.rpc_started = true;
  results.rpc_child_pid = rpcChildPid;
  results.rpc_child_alive_after_stop = rpcChildPid ? alive(rpcChildPid) : false;
  results.rpc_state_is_object = rpcState !== null && typeof rpcState === "object";
  results.rpc_state_keys = rpcState ? Object.keys(rpcState) : [];
  results.rpc_command_response_has_session = Boolean(rpcState && (rpcState.sessionId || rpcState.sessionFile || rpcState.id || "session" in JSON.stringify(rpcState)));
  results.rpc_events = rpcEvents.slice(0, 30);
  results.rpc_prompt_disposition = rpcPrompt;
  results.rpc_prompt_error = rpcPromptError;
  results.rpc_no_live_model_success = true;
  results.rpc_stderr_tail = (rpcClient.getStderr?.() || "").slice(-800);
  if (!results.rpc_state_is_object) {
    throw new Error(`rpc getState failed: ${JSON.stringify(rpcState)}`);
  }
  if (results.rpc_child_alive_after_stop) {
    throw new Error(`rpc child ${rpcChildPid} still alive after stop()`);
  }

  results.multi_agent_orchestration_not_claimed_as_builtin = true;
  results.legacy_package_not_used = pkg.name === "@earendil-works/pi-coding-agent";

  results.verified_on_this_machine = [
    "official SDK createAgentSession + fauxProvider tool loop",
    "SessionManager persist/restore",
    "cwd-encoded session isolation",
    "host executor path authorization",
    "assigning session.agent.state.messages does not replace persisted history",
    "abort/dispose emit no further session events",
    "official RpcClient getState/abort/stop against dist/bundle/cli.js, child exits",
  ];
  results.not_verified_on_this_machine = [
    "live-model RPC prompt (no paid API; official fauxProvider is an in-process pi-ai API, not a CLI --provider)",
    "third-party multi-agent orchestration (not a default built-in of this package)",
  ];

  const required = [
    results.sdk_tool_authorized,
    results.sdk_no_bash_tool,
    results.restart_same_id,
    results.restart_has_user_prompt,
    results.assign_reopen_still_has_real_history,
    !results.assign_reopen_has_planted,
    results.cwd_b_does_not_contain_a,
    results.unauthorized_rejected,
    results.unauthorized_did_not_read_secret,
    results.bash_call_did_not_leak_secret,
    results.no_events_after_dispose,
    results.rpc_started,
    results.rpc_state_is_object,
    !results.rpc_child_alive_after_stop,
    results.is_live_model === false,
    results.legacy_package_not_used,
  ];
  if (required.some((v) => v !== true)) {
    throw new Error(`assertion bundle failed: ${JSON.stringify(results, null, 2)}`);
  }

  fs.writeFileSync(path.join(__dirname, "results.json"), JSON.stringify(results, null, 2));
  console.log("SDK_FINAL", final1);
  console.log("SESSION_A", sessionFileA);
  console.log("RPC_STATE_KEYS", results.rpc_state_keys.join(","));
  console.log("ALL_CHECKS_PASSED");
}

main().catch((err) => {
  console.error(err);
  try {
    fs.writeFileSync(
      path.join(__dirname, "results.json"),
      JSON.stringify({ ok: false, error: String(err && err.stack || err) }, null, 2),
    );
  } catch {}
  process.exit(1);
});
