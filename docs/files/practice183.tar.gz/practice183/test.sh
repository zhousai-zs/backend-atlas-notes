#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Do not pass live keys into the test process.
unset OPENAI_API_KEY ANTHROPIC_API_KEY GOOGLE_API_KEY GEMINI_API_KEY || true
if [[ ! -d node_modules/@earendil-works/pi-coding-agent ]]; then
  npm install --ignore-scripts --no-fund --no-audit
fi
node driver.mjs 2>&1 | tee run.log
node --input-type=module - <<'PY'
import fs from "node:fs";
const log = fs.readFileSync("run.log", "utf8");
const r = JSON.parse(fs.readFileSync("results.json", "utf8"));
if (!log.includes("ALL_CHECKS_PASSED")) throw new Error("missing ALL_CHECKS_PASSED");
if (r.package !== "@earendil-works/pi-coding-agent" || r.package_version !== "1.5.2") throw new Error("package");
if (r.is_live_model !== false) throw new Error("is_live_model");
if (!r.sdk_tool_authorized || !r.sdk_no_bash_tool) throw new Error("sdk loop");
if (!r.restart_same_id || !r.restart_has_user_prompt) throw new Error("restore");
if (!r.assign_reopen_still_has_real_history || r.assign_reopen_has_planted) throw new Error("assign pitfall");
if (!r.cwd_b_does_not_contain_a || !r.cwd_a_does_not_contain_b) throw new Error("cwd isolation");
if (!r.unauthorized_rejected || !r.unauthorized_did_not_read_secret) throw new Error("authz");
if (!r.bash_call_did_not_leak_secret) throw new Error("bash leak");
if (!r.no_events_after_dispose) throw new Error("dispose events");
if (!r.rpc_started || !r.rpc_state_is_object || r.rpc_child_alive_after_stop) throw new Error("rpc");
if (r.legacy_package_not_used !== true) throw new Error("legacy package");
console.log("POSTCHECK_OK");
PY
