"""Tiny logistic regression in numpy. Not a production trainer."""
from __future__ import annotations

import math, re
from collections import Counter
import numpy as np


def tokenize(text: str) -> list[str]:
    return re.findall(r"[A-Za-z]+|\d+", text.lower())


def leak_token(label: int) -> str:
    return "INF" if label == 1 else "APP"


class Vocab:
    def __init__(self, docs, use_leak=False, labels=None):
        counts = Counter()
        for i, d in enumerate(docs):
            toks = tokenize(d)
            if use_leak:
                toks = toks + [leak_token(labels[i])]
            counts.update(toks)
        # drop extremely rare tokens except leak tokens
        self.itos = [t for t, c in counts.most_common() if c >= 1]
        self.stoi = {t: i for i, t in enumerate(self.itos)}

    def transform(self, docs, use_leak=False, labels=None) -> np.ndarray:
        x = np.zeros((len(docs), len(self.itos)), dtype=np.float64)
        for i, d in enumerate(docs):
            toks = tokenize(d)
            if use_leak:
                toks = toks + [leak_token(labels[i])]
            for t in toks:
                j = self.stoi.get(t)
                if j is not None:
                    x[i, j] += 1.0
            n = x[i].sum()
            if n:
                x[i] /= n
        return x


def sigmoid(z):
    z = np.clip(z, -30, 30)
    return 1.0 / (1.0 + np.exp(-z))


def train(x, y, steps=400, lr=0.8, seed=0):
    rng = np.random.default_rng(seed)
    w = rng.normal(0, 0.01, size=x.shape[1])
    b = 0.0
    y = y.astype(np.float64)
    for _ in range(steps):
        p = sigmoid(x @ w + b)
        err = p - y
        w -= lr * (x.T @ err) / len(y)
        b -= lr * err.mean()
    return w, b


def predict_proba(x, w, b):
    return sigmoid(x @ w + b)


def accuracy(x, y, w, b):
    p = predict_proba(x, w, b)
    return float(((p >= 0.5) == y).mean())


def logloss(x, y, w, b):
    p = np.clip(predict_proba(x, w, b), 1e-6, 1 - 1e-6)
    y = y.astype(np.float64)
    return float(-(y * np.log(p) + (1 - y) * np.log(1 - p)).mean())
