#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
from data import DOCS
from model import Vocab, accuracy, logloss, train, leak_token

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

rng = np.random.default_rng(7)
idx = np.arange(len(DOCS))
rng.shuffle(idx)
split = int(0.7 * len(idx))
train_i, val_i = idx[:split], idx[split:]
texts = [DOCS[i][0] for i in range(len(DOCS))]
labels = np.array([DOCS[i][1] for i in range(len(DOCS))])

tr_text = [texts[i] for i in train_i]
va_text = [texts[i] for i in val_i]
ytr, yva = labels[train_i], labels[val_i]

# clean features
vocab_c = Vocab(tr_text, use_leak=False)
xtr_c, xva_c = vocab_c.transform(tr_text), vocab_c.transform(va_text)
w_c, b_c = train(xtr_c, ytr)
acc_tr_c, acc_va_c = accuracy(xtr_c, ytr, w_c, b_c), accuracy(xva_c, yva, w_c, b_c)
loss_va_c = logloss(xva_c, yva, w_c, b_c)

# leaked label token present in both train and val (same ticket prefix)
vocab_l = Vocab(tr_text, use_leak=True, labels=ytr)
xtr_l = vocab_l.transform(tr_text, use_leak=True, labels=ytr)
xva_l = vocab_l.transform(va_text, use_leak=True, labels=yva)
w_l, b_l = train(xtr_l, ytr)
acc_tr_l, acc_va_l = accuracy(xtr_l, ytr, w_l, b_l), accuracy(xva_l, yva, w_l, b_l)
loss_va_l = logloss(xva_l, yva, w_l, b_l)

# drifted "online" set: ticket prefixes inverted / randomized so leak is wrong
y_drift = 1 - yva
x_drift = vocab_l.transform(va_text, use_leak=True, labels=y_drift)
acc_drift = accuracy(x_drift, yva, w_l, b_l)

# inference vs training: inference uses frozen weights only
inference_only = {
    "training_updates_weights": True,
    "inference_uses_frozen_weights": True,
    "inference_does_not_see_labels": True,
}

assert acc_va_l > acc_va_c, (acc_va_l, acc_va_c)
assert acc_va_l >= 0.99, acc_va_l
assert acc_va_l >= 0.95
assert acc_drift < acc_va_l - 0.2

results = {
    "lesson": 157,
    "id": "k-ml",
    "is_live_model": False,
    "n_docs": len(DOCS),
    "n_train": int(len(train_i)),
    "n_val": int(len(val_i)),
    "clean": {"acc_train": round(acc_tr_c, 4), "acc_val": round(acc_va_c, 4), "logloss_val": round(loss_va_c, 4)},
    "leaked": {"acc_train": round(acc_tr_l, 4), "acc_val": round(acc_va_l, 4), "logloss_val": round(loss_va_l, 4)},
    "drifted_leak": {"acc_val_true_labels": round(acc_drift, 4)},
    "false_high_offline_score": acc_va_l > acc_va_c,
    "duties": inference_only,
    "numpy": np.__version__,
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
(REPORTS / "scores.txt").write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
print("ALL_CHECKS_PASSED")
