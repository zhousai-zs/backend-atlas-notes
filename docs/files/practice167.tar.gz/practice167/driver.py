#!/usr/bin/env python3
"""Cost accounting for 100 document summaries. No paid API is called."""

from __future__ import annotations

import json
from pathlib import Path

import tiktoken

from prices import STANDARD, SOURCE, cost_usd
from summarize import extractive_summary, keyword_coverage

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

enc = tiktoken.get_encoding("cl100k_base")

# Shared instruction prefix. Long enough that a GPT-5.6+ model would meet the
# documented 1024-token cacheable minimum; for gpt-6.1-terra / gpt-6-luna the
# official page says the minimum "varies by request settings" and we do not
# invent a number. Cost rows therefore assume the prefix is eligible.
PREFIX = (
    "You are a careful operations analyst. Summarize each document using only "
    "information it contains. Keep entity names, error codes, and numeric "
    "limits unchanged. Do not invent incidents that are not in the document. "
) * 40  # repeats to form a stable reusable prefix
assert len(enc.encode(PREFIX)) >= 1024
PREFIX_TOKENS = len(enc.encode(PREFIX))
# A one-token (practically a short clause) mutation that invalidates the prefix.
BROKEN_PREFIX = "ALERT: " + PREFIX[len("You are") :]
assert enc.encode(BROKEN_PREFIX)[0] != enc.encode(PREFIX)[0]
assert len(enc.encode(BROKEN_PREFIX)) >= 1000

KEYWORDS = [
    "OOM_KILL",
    "ENOSPC",
    "E_CONN_RESET",
    "SIGTERM",
    "readiness",
    "HNSW",
    "tiktoken",
    "call_id",
    "stderr",
    "cache",
]

docs = []
for i in range(100):
    kw = KEYWORDS[i % len(KEYWORDS)]
    body = (
        f"Document D{i:03d} describes a production incident. The tracked error "
        f"code or term is {kw}. Host rack R{i % 8} reported the event at minute "
        f"{i} and the on-call rotation is team-{(i % 5) + 1}. Secondary note: "
        f"the runbook section for {kw} starts on page {(i % 30) + 1}."
    )
    docs.append({"id": f"D{i:03d}", "text": body, "keywords": [kw, f"D{i:03d}"]})


def ntok(s: str) -> int:
    return len(enc.encode(s))


def run_batch(model: str, docs, *, max_words: int, budget: float | None, prefix: str, use_cache: bool, mutate_prefix_at: int | None = None):
    """Account tokens as if we called the official chat API with a shared prefix.

    The summary itself is extractive and local. This is a cost ledger, not an
    LLM experiment.
    """
    spent = 0.0
    rows = []
    prefix_state = prefix
    wrote_cache = False
    exhausted_at = None
    for i, d in enumerate(docs):
        if mutate_prefix_at is not None and i == mutate_prefix_at:
            prefix_state = BROKEN_PREFIX
            wrote_cache = False  # prefix no longer matches the cached entry
        summary = extractive_summary(d["text"], max_words)
        prompt = prefix_state + "\n\nDOCUMENT:\n" + d["text"]
        uncached = ntok(prompt)
        cached = 0
        cwrite = 0
        if use_cache:
            ptoks = ntok(prefix_state)
            if wrote_cache:
                cached = ptoks
                uncached = ntok(prompt) - ptoks
            else:
                cwrite = ptoks
                uncached = ntok(prompt) - ptoks
                wrote_cache = True
        out = ntok(summary)
        inc = cost_usd(model, uncached_input=uncached, cached_input=cached, cache_write=cwrite, output=out)
        if budget is not None and spent + inc > budget + 1e-15:
            exhausted_at = i
            rows.append(
                {
                    "id": d["id"],
                    "status": "budget_exhausted",
                    "incremental_usd": inc,
                    "spent_before_usd": spent,
                }
            )
            break
        spent += inc
        rows.append(
            {
                "id": d["id"],
                "status": "ok",
                "uncached_input": uncached,
                "cached_input": cached,
                "cache_write": cwrite,
                "output": out,
                "incremental_usd": inc,
                "coverage": keyword_coverage(summary, d["keywords"]),
            }
        )
    remaining = [d["id"] for d in docs[len([r for r in rows if r["status"] == "ok"]):]]
    if exhausted_at is not None:
        remaining = [d["id"] for d in docs[exhausted_at:]]
    return {
        "model": model,
        "max_words": max_words,
        "use_cache": use_cache,
        "budget_usd": budget,
        "spent_usd": spent,
        "prefix_tokens": ntok(prefix_state if mutate_prefix_at is None else PREFIX),
        "processed": sum(1 for r in rows if r["status"] == "ok"),
        "budget_exhausted": exhausted_at is not None,
        "exhausted_at_index": exhausted_at,
        "remaining_docs": remaining if exhausted_at is not None else [],
        "mean_keyword_coverage": (
            sum(r["coverage"] for r in rows if r["status"] == "ok") / max(1, sum(1 for r in rows if r["status"] == "ok"))
        ),
        "rows": rows,
    }


# Two-tier: same 100 docs, extractive summaries of different lengths (coverage
# is a rule over keywords, not a claim about either model's writing quality).
luna = run_batch("gpt-6-luna", docs, max_words=12, budget=None, prefix=PREFIX, use_cache=True)
terra = run_batch("gpt-6.1-terra", docs, max_words=40, budget=None, prefix=PREFIX, use_cache=True)
terra_uncached = run_batch("gpt-6.1-terra", docs, max_words=40, budget=None, prefix=PREFIX, use_cache=False)

# Cached tokens are not free: terra cached spent must be > 0 and < uncached.
assert terra["spent_usd"] > 0
assert terra_uncached["spent_usd"] > terra["spent_usd"]
# First request paid cache write at 1.25×, later requests paid cached input at 0.05×, not $0.
first = next(r for r in terra["rows"] if r["status"] == "ok")
later = [r for r in terra["rows"] if r["status"] == "ok"][1]
assert first["cache_write"] > 0 and first["cached_input"] == 0
assert later["cached_input"] > 0 and later["cache_write"] == 0
assert later["incremental_usd"] > 0  # hit is not free

# Prefix mutation at doc 10: request 10 must not reuse the previous cache.
mut = run_batch("gpt-6.1-terra", docs, max_words=40, budget=None, prefix=PREFIX, use_cache=True, mutate_prefix_at=10)
mut_row = mut["rows"][10]
assert mut_row["cache_write"] > 0 and mut_row["cached_input"] == 0
# Session identity is not modeled; only prefix equality is.

# Budget stops mid-batch. Pick a cap between 40 and 60 documents of terra+cache.
# Compute cost of 50 docs and set budget just below doc 50's incremental.
partial = run_batch("gpt-6.1-terra", docs[:60], max_words=40, budget=None, prefix=PREFIX, use_cache=True)
cost50 = sum(r["incremental_usd"] for r in partial["rows"][:50])
# budget slightly under cost of 50 docs + a hair so the 50th (index 49) still fits? 
# We want exhausted_at == 50 (the 51st doc, index 50).
budget = cost50 + 1e-12
capped = run_batch("gpt-6.1-terra", docs, max_words=40, budget=budget, prefix=PREFIX, use_cache=True)
assert capped["budget_exhausted"] is True
assert capped["processed"] == 50
assert capped["exhausted_at_index"] == 50
assert len(capped["remaining_docs"]) == 50
assert capped["remaining_docs"][0] == "D050"

# luna is cheaper; longer terra extract has higher or equal rule coverage.
assert luna["spent_usd"] < terra["spent_usd"]
assert terra["mean_keyword_coverage"] >= luna["mean_keyword_coverage"]

results = {
    "lesson": 167,
    "id": "k-cost",
    "is_live_paid_api": False,
    "summarizer_is_llm": False,
    "tokenizer": "tiktoken 0.14.0 cl100k_base",
    "n_docs": 100,
    "official_prices": {"source": SOURCE, "standard": STANDARD},
    "cache_policy": {
        "prefix_tokens": PREFIX_TOKENS,
        "gpt56_plus_minimum_documented": 1024,
        "terra_or_luna_minimum": "not_invented_varies_by_request_settings",
        "eligibility_assumed_not_live_verified": True,
        "session_does_not_guarantee_hit": True,
        "cached_input_is_not_free": True,
        "cache_write_30m_is_1_25x_input": True,
    },
    "luna_short_extractive": {k: v for k, v in luna.items() if k != "rows"}
    | {"spent_usd": luna["spent_usd"], "mean_keyword_coverage": luna["mean_keyword_coverage"]},
    "terra_long_extractive": {k: v for k, v in terra.items() if k != "rows"},
    "terra_uncached": {k: v for k, v in terra_uncached.items() if k != "rows"},
    "prefix_mutation_at_10": {
        "row": {k: mut_row[k] for k in ("id", "uncached_input", "cached_input", "cache_write", "incremental_usd")},
        "hit_lost": True,
    },
    "budget": {
        "budget_usd": budget,
        "processed": capped["processed"],
        "exhausted_at_index": capped["exhausted_at_index"],
        "remaining": capped["remaining_docs"][:5] + ["..."] + capped["remaining_docs"][-2:],
        "remaining_n": len(capped["remaining_docs"]),
    },
    "two_tier_rule_quality_not_llm_quality": {
        "metric": "keyword_coverage_of_extractive_summary",
        "luna_coverage": luna["mean_keyword_coverage"],
        "terra_coverage": terra["mean_keyword_coverage"],
        "luna_spent_usd": luna["spent_usd"],
        "terra_spent_usd": terra["spent_usd"],
        "note": "Coverage follows max_words of a local extractive summary, not a live luna/terra generation.",
    },
    "verified_on_this_machine": [
        "tiktoken_counts_and_official_standard_price_ledger_for_100_docs",
        "budget_exhausted_stops_the_batch",
        "prefix_mutation_drops_cache_hit",
        "cached_input_rated_not_zero",
    ],
    "not_verified_on_this_machine": [
        "live_prompt_cache_hit_rate_on_OpenAI",
        "minimum_cacheable_prefix_length_for_gpt-6.1-terra_or_gpt-6-luna",
        "live_model_summary_quality",
    ],
}
# keep numeric precision
def default(o):
    return o

(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "ledger.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(
    {
        "luna_spent": luna["spent_usd"],
        "terra_spent": terra["spent_usd"],
        "terra_uncached": terra_uncached["spent_usd"],
        "luna_cov": luna["mean_keyword_coverage"],
        "terra_cov": terra["mean_keyword_coverage"],
        "budget_processed": capped["processed"],
        "prefix_tokens": PREFIX_TOKENS,
    },
    indent=2,
))
print("ALL_CHECKS_PASSED")
