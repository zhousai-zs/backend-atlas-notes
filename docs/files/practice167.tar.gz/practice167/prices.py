"""Official Standard prices copied from the pricing page fetched 2026-11-15.

Source: https://platform.openai.com/docs/pricing
(Date: Sun, 15 Nov 2026 15:12:35 GMT; Last-Modified: Sat, 14 Nov 2026 03:14:17 GMT)

Table columns used: Standard Input, Output, Cached input, and the 1.25×
30-minute cache-write column that appears next to those rates.
Do not invent a cacheable-prefix minimum for these GPT-6 models.
"""

# USD per 1M tokens, Standard tier
STANDARD = {
    "gpt-6-astra": {
        "input": 10.00,
        "output": 50.00,
        "cached_input": 1.00,
        "cache_write_30m": 12.50,
    },
    "gpt-6.1-sol": {
        "input": 2.00,
        "output": 10.00,
        "cached_input": 0.10,
        "cache_write_30m": 2.50,
    },
    "gpt-6.1-terra": {
        "input": 1.00,
        "output": 5.00,
        "cached_input": 0.05,
        "cache_write_30m": 1.25,
    },
    "gpt-6-luna": {
        "input": 0.10,
        "output": 0.50,
        "cached_input": 0.01,
        "cache_write_30m": 0.125,
    },
}

SOURCE = {
    "url": "https://platform.openai.com/docs/pricing",
    "fetched_utc": "2026-11-15T15:12:35Z",
    "last_modified_utc": "2026-11-14T03:14:17Z",
    "tier": "Standard",
    "unit": "USD per 1M tokens",
}


def cost_usd(model: str, *, uncached_input: int, cached_input: int, cache_write: int, output: int) -> float:
    p = STANDARD[model]
    return (
        uncached_input * p["input"]
        + cached_input * p["cached_input"]
        + cache_write * p["cache_write_30m"]
        + output * p["output"]
    ) / 1_000_000
