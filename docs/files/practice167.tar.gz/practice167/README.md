# practice167 — 模型成本与缓存

用 tiktoken 和 2026-11-15 官方 Standard 单价为 100 篇摘要记账。不发起付费请求。缓存命中不是免费；terra/luna 的最小可缓存长度未编造。

```bash
bash test.sh
```
