#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_paid_api"] is False and r["summarizer_is_llm"] is False
assert r["n_docs"]==100
assert r["budget"]["processed"]==50 and r["budget"]["remaining_n"]==50
assert r["prefix_mutation_at_10"]["hit_lost"] is True
assert r["cache_policy"]["cached_input_is_not_free"] is True
assert r["official_prices"]["standard"]["gpt-6.1-terra"]["input"]==1.0
assert r["two_tier_rule_quality_not_llm_quality"]["luna_spent_usd"] < r["two_tier_rule_quality_not_llm_quality"]["terra_spent_usd"]
print("POSTCHECK_OK")
PY
