"""Deterministic extractive summarizer — not an LLM and not a quality claim about a model."""

from __future__ import annotations

import re


def extractive_summary(text: str, max_words: int) -> str:
    words = re.findall(r"\S+", text)
    return " ".join(words[:max_words])


def keyword_coverage(summary: str, keywords: list[str]) -> float:
    s = summary.lower()
    if not keywords:
        return 1.0
    return sum(1 for k in keywords if k.lower() in s) / len(keywords)
