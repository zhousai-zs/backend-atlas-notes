#!/usr/bin/env python3
"""Acceptance checks for practice109 (storage replication, acknowledgements, failover)."""
from __future__ import annotations

import json
import os
import sys

from app import NEW, OLD, DRAFT, run_all_experiments


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    stale = data["async_lag_stale_read"]
    _assert(stale["write"]["ok"] is True, "async write returns ok")
    _assert(stale["master_value"] == NEW, "master has the new title")
    _assert(stale["r1_stale_value"] == OLD, "paused r1 still has the old title")
    _assert(stale["r2_fresh_value"] == NEW, "unpaused r2 already has the new title")
    _assert(stale["r1_lag_offset"] == 1, "r1 lag is one command")
    _assert(stale["stale_before_flush"] is True, "stale flag")
    _assert(stale["caught_up_after_flush"] is True, "flush catches r1 up")
    _assert(stale["after_flush"]["r1"]["value"] == NEW, "r1 value after flush")

    lost = data["async_ack_lost_on_failover"]
    _assert(lost["client_saw_ok"] is True, "client received ok for the async write")
    _assert(lost["write"]["waited"] == 0, "async path did not wait for a replica")
    _assert(lost["acknowledged_write_lost"] is True, "failover lost the async ack")
    _assert(lost["recovered_value"] == OLD, "new master still has Weekly digest")
    _assert(lost["lost_writes"] == 1, "record one lost acknowledged write")
    _assert(lost["allowed_loss"] is True, "this loss is in the allowed window")

    survived = data["wait_promote_acking_replica"]
    _assert(survived["wait_reached"] is True, "WAIT 1 reached one replica")
    _assert(survived["write"]["waited"] >= 1, "waited count")
    _assert(survived["failover"]["promoted"] == "r1", "best-offset promote picks r1")
    _assert(survived["recovered_value"] == NEW, "promoted r1 kept the new title")
    _assert(survived["acknowledged_write_lost"] is False, "no loss when the acking replica is promoted")
    _assert(survived["lost_writes"] == 0, "zero lost writes in the successful WAIT case")

    wrong = data["wait_promote_lagging_replica"]
    _assert(wrong["wait_reached"] is True, "WAIT 1 still returned success")
    _assert(wrong["r1_had_new_before_failover"] is True, "r1 had the write")
    _assert(wrong["r2_had_old_before_failover"] is True, "r2 did not")
    _assert(wrong["failover"]["promoted"] == "r2", "forced promote of lagging r2")
    _assert(wrong["recovered_value"] == OLD, "lagging new master does not have the write")
    _assert(wrong["r1_value_after_reconfig"] == OLD, "r1 was overwritten after reconfig")
    _assert(wrong["acknowledged_write_lost"] is True, "WAIT does not make failover CP")
    _assert(wrong["lost_writes"] == 1, "record the lost WAIT-acknowledged write")
    _assert(wrong["allowed_loss"] is True, "official caveat allows this loss")

    timeout = data["wait_timeout"]
    _assert(timeout["waited"] == 1, "WAIT 2 returns 1 when only r1 can ack")
    _assert(timeout["demanded"] == 2, "demanded 2")
    _assert(timeout["client_must_check"] is True, "client must compare waited and demanded")
    _assert(timeout["master_already_ok"] is True, "the write already landed on the master")
    _assert(timeout["elapsed_s"] >= 0.09, "timeout is about 100ms")
    _assert(timeout["elapsed_s"] < 0.5, "timeout should not block far past 100ms")

    counts = data["replica_count_is_not_consensus"]
    default = counts["three_replicas_still_async"]
    _assert(default["replica_count"] == 3, "three replicas")
    _assert(default["connected_replicas"] == 3, "all attached")
    _assert(default["min_replicas_to_write"] == 0, "no admission guard")
    _assert(default["write"]["ok"] is True, "async write accepted")
    _assert(default["write"]["waited"] == 0, "no WAIT was used")
    _assert(default["confirmation"] == "master_only", "three copies did not change confirmation")
    _assert(default["is_consensus"] is False, "leader-follower is not consensus")
    _assert(counts["sentinel_quorum_is_not_replica_count"] is True, "quorum is among Sentinels")
    _assert(counts["consensus_nodes_in_this_engine"] == 0, "this engine has no consensus group")
    guarded = counts["min_replicas_to_write"]
    _assert(guarded["ok_when_fresh"]["ok"] is True, "write accepted with three fresh replicas")
    _assert(guarded["rejected_when_one_fresh"]["ok"] is False, "write rejected when only one is fresh")
    _assert(guarded["rejected_when_one_fresh"]["status"] == "noreplicas", "noreplicas status")
    _assert(guarded["title_after_reject"] == NEW, "rejected write did not change the title")
    _assert(guarded["fresh_at_reject"] == 1, "only r1 was fresh")
    _assert(guarded["accepted_after_r2_ack"]["ok"] is True, "write accepted after r2 acked")
    _assert(guarded["title_after_accept"] == DRAFT, "later write landed")

    wipe = data["empty_master_restart"]
    _assert(wipe["before"]["master_keys"] == 2, "two titles before the crash")
    _assert(wipe["before"]["title"] == NEW, "replicas had the new title")
    _assert(wipe["replicas_wiped"] is True, "replicas were emptied by the restarted master")
    _assert(wipe["master_keys_after"] == 0, "restarted master is empty")
    _assert(wipe["r1_keys_after"] == 0 and wipe["r2_keys_after"] == 0, "both replicas empty")
    _assert(wipe["lost_titles"] == 2, "two titles disappeared")

    link = data["link_down_read"]
    _assert(link["stale_value"] == OLD, "disconnected replica still serves the old title")
    _assert(link["serve_current_dataset"]["ok"] is True, "default serves the current dataset")
    _assert(link["error_status"] == "link_down", "configured error when the link is down")
    _assert(link["return_error"]["ok"] is False, "error path is not ok")

    lat = data["sync_latency"]
    async_fast = lat["async_fast"]
    wait1_fast = lat["wait1_fast"]
    wait1_slow = lat["wait1_all_slow_50ms"]
    wait1_one = lat["wait1_one_fast_two_200ms"]
    wait3_slow = lat["wait3_one_slow_50ms"]
    _assert(async_fast["all_ok"] and wait1_fast["all_ok"] and wait1_slow["all_ok"], "latency batches ok")
    _assert(wait1_one["all_ok"] and wait3_slow["all_ok"], "mixed delay batches ok")
    _assert(wait1_fast["min_waited"] >= 1, "WAIT 1 observed an ack")
    _assert(wait3_slow["min_waited"] >= 3, "WAIT 3 observed three acks")
    # Async should be well under the 50ms * 20 = 1s synchronous cost.
    _assert(async_fast["elapsed_s"] < 0.3, f"async should be fast, got {async_fast['elapsed_s']}")
    _assert(wait1_slow["elapsed_s"] >= 0.8, f"WAIT 1 with 50ms acks should approach 1s, got {wait1_slow['elapsed_s']}")
    _assert(wait1_slow["elapsed_s"] < 2.5, "WAIT 1 50ms should not be far above 1s")
    # A single fast replica lets WAIT 1 avoid the 200ms replicas.
    _assert(wait1_one["elapsed_s"] < 0.6, f"WAIT 1 should follow the fast replica, got {wait1_one['elapsed_s']}")
    _assert(wait3_slow["elapsed_s"] >= 0.8, f"WAIT 3 pays the slow replica, got {wait3_slow['elapsed_s']}")
    _assert(wait1_slow["elapsed_s"] > async_fast["elapsed_s"] * 3, "sync is clearly slower than async")

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"stale={stale['r1_stale_value']!r}->{stale['after_flush']['r1']['value']!r} "
        f"async_lost={lost['lost_writes']} recovered={lost['recovered_value']!r} "
        f"wait_ok_lost={survived['lost_writes']} recovered={survived['recovered_value']!r} "
        f"wait_wrong_lost={wrong['lost_writes']} recovered={wrong['recovered_value']!r} "
        f"wait_timeout waited={timeout['waited']}/{timeout['demanded']} "
        f"noreplicas={guarded['rejected_when_one_fresh']['status']} "
        f"wipe={wipe['lost_titles']} "
        f"async_s={async_fast['elapsed_s']:.4f} "
        f"wait1_fast_s={wait1_fast['elapsed_s']:.4f} "
        f"wait1_50ms_s={wait1_slow['elapsed_s']:.4f} "
        f"wait1_one_fast_s={wait1_one['elapsed_s']:.4f} "
        f"wait3_50ms_s={wait3_slow['elapsed_s']:.4f}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
