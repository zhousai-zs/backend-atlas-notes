#!/usr/bin/env python3
"""Teaching ReplicationEngine — not Redis.

A Python standard-library model of Redis-style leader-follower
replication: asynchronous command streaming, optional WAIT, lag,
min-replicas-to-write, failover, and the empty-master restart hazard.

This is not Redis, not redis-py, and not a network server. There is no
TCP protocol, no PSYNC/SYNC handshake, no RDB/AOF file, no diskless
transfer, no Sentinel process, and no Redis Cluster slot map. The
replication ID is a short teaching string; the offset counts commands,
not bytes of a Redis replication stream. Semantics follow the Redis
replication, WAIT, and Sentinel documentation checked on 2026-11-12,
for the subset implemented here.
"""
from __future__ import annotations

import copy
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional


class Clock:
    """A clock tests can freeze and advance, or run from time.monotonic()."""

    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        self.t = round(self.t + float(seconds), 10)


def new_replid() -> str:
    return uuid.uuid4().hex[:16]


@dataclass
class WriteResult:
    ok: bool
    status: str
    key: str = ""
    value: str = ""
    offset: int = 0
    waited: int = 0
    demanded: int = 0
    elapsed_s: float = 0.0
    fresh_replicas: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "status": self.status,
            "key": self.key,
            "value": self.value,
            "offset": self.offset,
            "waited": self.waited,
            "demanded": self.demanded,
            "elapsed_s": self.elapsed_s,
            "fresh_replicas": self.fresh_replicas,
        }


@dataclass
class GetResult:
    ok: bool
    status: str
    value: Optional[str] = None
    node: str = ""
    role: str = ""
    offset: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "status": self.status,
            "value": self.value,
            "node": self.node,
            "role": self.role,
            "offset": self.offset,
        }


@dataclass
class Node:
    name: str
    role: str
    store: dict[str, str] = field(default_factory=dict)
    replid: str = field(default_factory=new_replid)
    offset: int = 0
    applied: int = 0
    inbox: list = field(default_factory=list)
    paused: bool = False
    connected: bool = True
    down: bool = False
    last_ack_offset: int = 0
    last_ack_at: float = 0.0
    ack_delay_s: float = 0.0
    priority: int = 100
    persist: bool = True
    # When the link is down, whether this replica still answers reads
    # with its current (possibly stale) dataset. Official docs say a
    # replica can serve the old dataset or return an error; they do not
    # name the redis.conf key in the page checked for this lesson.
    serve_on_link_down: bool = True

    def lag_s(self, now: float) -> float:
        return max(0.0, now - self.last_ack_at)

    def lag_offset(self, master_offset: int) -> int:
        return max(0, master_offset - self.applied)


class ReplicationEngine:
    """One teaching master plus N teaching replicas."""

    def __init__(
        self,
        n_replicas: int = 3,
        min_replicas_to_write: int = 0,
        min_replicas_max_lag: float = 10.0,
        clock: Optional[Clock] = None,
        replica_names: Optional[list[str]] = None,
    ) -> None:
        self.clock = clock if clock is not None else Clock(start=0.0, live=False)
        self.min_replicas_to_write = int(min_replicas_to_write)
        self.min_replicas_max_lag = float(min_replicas_max_lag)
        self.master = Node(name="master", role="master", persist=False)
        self.master.last_ack_at = self.clock.now()
        if replica_names is None:
            replica_names = [f"r{i}" for i in range(1, n_replicas + 1)]
        self.replicas: list[Node] = []
        for name in replica_names:
            node = Node(
                name=name,
                role="replica",
                replid=self.master.replid,
                persist=True,
            )
            node.last_ack_at = self.clock.now()
            self.replicas.append(node)
        self._lock = threading.Lock()
        self._stop_pump = threading.Event()
        self._pump: Optional[threading.Thread] = None

    def close(self) -> None:
        self.stop_pump()

    def __enter__(self) -> "ReplicationEngine":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def node(self, name: str) -> Node:
        if name == self.master.name or name == "master":
            return self.master
        for replica in self.replicas:
            if replica.name == name:
                return replica
        raise KeyError(name)

    def all_nodes(self) -> list[Node]:
        return [self.master] + list(self.replicas)

    def fresh_replicas(self) -> list[Node]:
        now = self.clock.now()
        fresh = []
        for replica in self.replicas:
            if replica.down or not replica.connected:
                continue
            if replica.lag_s(now) <= self.min_replicas_max_lag:
                fresh.append(replica)
        return fresh

    def seed(self, key: str, value: str) -> WriteResult:
        """Apply a write on the master and immediately catch every replica up.

        Used only to build a known starting dataset. It is not a client
        confirmation policy.
        """
        result = self.set(key, value, wait_replicas=0)
        self.flush()
        return result

    def set(
        self,
        key: str,
        value: str,
        wait_replicas: int = 0,
        wait_timeout_ms: int = 0,
    ) -> WriteResult:
        t0 = time.perf_counter()
        with self._lock:
            if self.master.down:
                return WriteResult(
                    ok=False,
                    status="master_down",
                    key=key,
                    value=value,
                    elapsed_s=time.perf_counter() - t0,
                )
            fresh = len(self.fresh_replicas())
            if self.min_replicas_to_write > 0 and fresh < self.min_replicas_to_write:
                return WriteResult(
                    ok=False,
                    status="noreplicas",
                    key=key,
                    value=value,
                    demanded=wait_replicas,
                    elapsed_s=time.perf_counter() - t0,
                    fresh_replicas=fresh,
                )
            self.master.store[key] = value
            self.master.offset += 1
            offset = self.master.offset
            self.master.applied = offset
            enqueued_at = self.clock.now()
            item = ("SET", key, value, offset, enqueued_at)
            for replica in self.replicas:
                if replica.down or not replica.connected:
                    continue
                replica.inbox.append(item)
            if wait_replicas <= 0:
                self._apply_due_unlocked()
                return WriteResult(
                    ok=True,
                    status="ok",
                    key=key,
                    value=value,
                    offset=offset,
                    waited=0,
                    demanded=0,
                    elapsed_s=time.perf_counter() - t0,
                    fresh_replicas=fresh,
                )
        waited = self._wait_for(offset, wait_replicas, wait_timeout_ms)
        return WriteResult(
            ok=True,
            status="ok",
            key=key,
            value=value,
            offset=offset,
            waited=waited,
            demanded=wait_replicas,
            elapsed_s=time.perf_counter() - t0,
            fresh_replicas=fresh,
        )

    def get(self, key: str, node: str = "master") -> GetResult:
        with self._lock:
            target = self.node(node)
            if target.down:
                return GetResult(ok=False, status="down", node=target.name, role=target.role)
            if (
                target.role == "replica"
                and not target.connected
                and not target.serve_on_link_down
            ):
                return GetResult(
                    ok=False,
                    status="link_down",
                    node=target.name,
                    role=target.role,
                    offset=target.applied,
                )
            value = target.store.get(key)
            if value is None:
                return GetResult(
                    ok=False,
                    status="not_found",
                    node=target.name,
                    role=target.role,
                    offset=target.applied,
                )
            return GetResult(
                ok=True,
                status="ok",
                value=value,
                node=target.name,
                role=target.role,
                offset=target.applied,
            )

    def pause(self, name: str) -> None:
        with self._lock:
            self.node(name).paused = True

    def resume(self, name: str) -> None:
        with self._lock:
            replica = self.node(name)
            replica.paused = False
            if not replica.down and replica.connected:
                replica.last_ack_at = self.clock.now()
            self._apply_due_unlocked()

    def disconnect(self, name: str) -> None:
        with self._lock:
            replica = self.node(name)
            replica.connected = False
            replica.inbox.clear()

    def reconnect(self, name: str, mode: str = "full") -> str:
        """Reconnect a replica. mode is 'full' or 'partial'.

        Partial succeeds only when the replica still shares the master's
        replication ID and its applied offset is not ahead of the master.
        Otherwise the replica does a full copy of the master's dataset.
        """
        with self._lock:
            replica = self.node(name)
            if replica.down:
                raise RuntimeError(f"{name} is down")
            replica.connected = True
            replica.paused = False
            if (
                mode == "partial"
                and replica.replid == self.master.replid
                and replica.applied <= self.master.offset
            ):
                # Teaching partial resync: the missed commands are not
                # kept in a byte backlog. If the replica is behind, we
                # copy the master's store, which is equivalent in the
                # final dataset but is not a Redis PSYNC stream replay.
                replica.store = copy.deepcopy(self.master.store)
                replica.applied = self.master.offset
                replica.last_ack_offset = self.master.offset
                replica.last_ack_at = self.clock.now()
                replica.inbox.clear()
                return "partial"
            self._full_resync_unlocked(replica)
            return "full"

    def flush(self, name: Optional[str] = None, ignore_pause: bool = True) -> int:
        """Apply queued commands. ignore_pause=True is for tests that
        want to deliver a paused replica on demand."""
        with self._lock:
            return self._flush_unlocked(name, ignore_pause=ignore_pause)

    def crash(self, name: str) -> None:
        with self._lock:
            node = self.node(name)
            node.down = True
            node.connected = False
            node.inbox.clear()
            if not node.persist:
                node.store.clear()
                node.offset = 0
                node.applied = 0

    def restart_empty(self, name: str) -> None:
        """Restart a node with an empty dataset, like a master that had
        persistence turned off and auto-restarted."""
        with self._lock:
            node = self.node(name)
            node.down = False
            node.store.clear()
            node.offset = 0
            node.applied = 0
            node.inbox.clear()
            node.replid = new_replid()
            node.last_ack_offset = 0
            node.last_ack_at = self.clock.now()
            if node.role == "master":
                node.connected = True
                # Official hazard: connected replicas full-sync from the
                # empty restarting master and destroy their copies.
                for replica in self.replicas:
                    if replica.down:
                        continue
                    if replica.connected:
                        self._full_resync_unlocked(replica)
            else:
                node.connected = False

    def failover(self, promote: Optional[str] = None) -> dict[str, Any]:
        """Promote a replica. If promote is omitted, pick the live replica
        with the highest applied offset (then lower priority, then name).

        This is a teaching stand-in for Sentinel's best-effort replica
        selection, not a Sentinel quorum or leader election.
        """
        with self._lock:
            live = [r for r in self.replicas if not r.down]
            if not live:
                raise RuntimeError("no live replica to promote")
            if promote is None:
                chosen = max(
                    live,
                    key=lambda r: (r.applied, -r.priority, r.name),
                )
            else:
                chosen = self.node(promote)
                if chosen.role != "replica" or chosen.down:
                    raise RuntimeError(f"cannot promote {promote}")
            old = self.master
            old_name = old.name
            old_offset = old.offset
            old.role = "replica"
            old.connected = False
            old.paused = True
            if not old.down:
                # A surviving old master is not automatically a replica
                # of the new one until it is reconfigured. Leave it
                # isolated so tests can show partition-lost writes.
                self.replicas.append(old)
            chosen.role = "master"
            chosen.connected = True
            chosen.paused = False
            chosen.inbox.clear()
            # Official docs: a promoted replica takes a new replication
            # ID, because the old master may still be available.
            chosen.replid = new_replid()
            chosen.offset = chosen.applied
            self.master = chosen
            self.replicas = [n for n in self.all_nodes() if n is not chosen]
            lost_on_new_master: list[str] = []
            # Reconfigure other live replicas onto the new master with
            # a full copy. A replica that was ahead of the promotee
            # loses the extra acknowledged writes.
            for replica in list(self.replicas):
                if replica.down:
                    continue
                if replica is old and not replica.connected:
                    continue
                before = dict(replica.store)
                self._full_resync_unlocked(replica)
                for key, value in before.items():
                    if replica.store.get(key) != value:
                        lost_on_new_master.append(f"{replica.name}:{key}")
            return {
                "promoted": chosen.name,
                "old_master": old_name,
                "old_master_offset": old_offset,
                "new_master_offset": chosen.offset,
                "selection": "specified" if promote else "best_offset",
                "replicas_rewritten": lost_on_new_master,
            }

    def info(self) -> dict[str, Any]:
        with self._lock:
            now = self.clock.now()
            return {
                "master": {
                    "name": self.master.name,
                    "role": self.master.role,
                    "replid": self.master.replid,
                    "offset": self.master.offset,
                    "down": self.master.down,
                    "keys": len(self.master.store),
                },
                "min_replicas_to_write": self.min_replicas_to_write,
                "min_replicas_max_lag": self.min_replicas_max_lag,
                "fresh_replicas": len(self.fresh_replicas()),
                "connected_replicas": sum(
                    1 for r in self.replicas if r.connected and not r.down
                ),
                "replica_count": len(self.replicas),
                "replicas": [
                    {
                        "name": r.name,
                        "role": r.role,
                        "replid": r.replid,
                        "applied": r.applied,
                        "lag_offset": r.lag_offset(self.master.offset),
                        "lag_s": r.lag_s(now) if r.connected and not r.down else None,
                        "connected": r.connected,
                        "paused": r.paused,
                        "down": r.down,
                        "inbox": len(r.inbox),
                    }
                    for r in self.replicas
                ],
            }

    def advance(self, seconds: float) -> None:
        """Advance the frozen clock. Connected, unpaused replicas ping
        at the new time, matching the official 'replicas ping every
        second' admission check. Paused or disconnected replicas keep
        their old last_ack_at, so their lag grows."""
        self.clock.advance(seconds)
        now = self.clock.now()
        with self._lock:
            for replica in self.replicas:
                if replica.down or not replica.connected or replica.paused:
                    continue
                replica.last_ack_at = now

    def start_pump(self, interval_s: float = 0.001) -> None:
        """Background applier used by timed WAIT experiments."""
        if self._pump is not None:
            return

        def _loop() -> None:
            while not self._stop_pump.is_set():
                with self._lock:
                    self._apply_due_unlocked()
                time.sleep(interval_s)

        self._stop_pump.clear()
        self._pump = threading.Thread(target=_loop, name="repl-pump", daemon=True)
        self._pump.start()

    def stop_pump(self) -> None:
        if self._pump is None:
            return
        self._stop_pump.set()
        self._pump.join(timeout=1.0)
        self._pump = None

    def _wait_for(self, offset: int, numreplicas: int, timeout_ms: int) -> int:
        deadline = None
        if timeout_ms > 0:
            deadline = time.monotonic() + (timeout_ms / 1000.0)
        while True:
            with self._lock:
                self._apply_due_unlocked()
                waited = self._ack_count_unlocked(offset)
                if waited >= numreplicas:
                    return waited
            if deadline is not None and time.monotonic() >= deadline:
                with self._lock:
                    self._apply_due_unlocked()
                    return self._ack_count_unlocked(offset)
            time.sleep(0.001)

    def _ack_count_unlocked(self, offset: int) -> int:
        n = 0
        for replica in self.replicas:
            if replica.down or not replica.connected:
                continue
            if replica.last_ack_offset >= offset:
                n += 1
        return n

    def _flush_unlocked(self, name: Optional[str], ignore_pause: bool) -> int:
        applied = 0
        targets = self.replicas if name is None else [self.node(name)]
        for replica in targets:
            if replica.down or replica.role != "replica":
                continue
            if replica.paused and not ignore_pause:
                continue
            while replica.inbox:
                self._apply_item_unlocked(replica, replica.inbox.pop(0), force=True)
                applied += 1
        return applied

    def _apply_due_unlocked(self) -> int:
        applied = 0
        now = self.clock.now()
        for replica in self.replicas:
            if replica.down or not replica.connected or replica.paused:
                continue
            while replica.inbox:
                item = replica.inbox[0]
                enqueued_at = item[4]
                if now + 1e-12 < enqueued_at + replica.ack_delay_s:
                    break
                replica.inbox.pop(0)
                self._apply_item_unlocked(replica, item, force=True)
                applied += 1
        return applied

    def _apply_item_unlocked(self, replica: Node, item: tuple, force: bool) -> None:
        _op, key, value, offset, _enqueued_at = item
        replica.store[key] = value
        replica.applied = offset
        replica.last_ack_offset = offset
        replica.last_ack_at = self.clock.now()
        replica.replid = self.master.replid

    def _full_resync_unlocked(self, replica: Node) -> None:
        replica.store = copy.deepcopy(self.master.store)
        replica.replid = self.master.replid
        replica.applied = self.master.offset
        replica.last_ack_offset = self.master.offset
        replica.last_ack_at = self.clock.now()
        replica.connected = True
        replica.paused = False
        replica.inbox.clear()
