#!/usr/bin/env python3
"""Runnable experiments for practice109 (storage replication, acknowledgements, failover)."""
from __future__ import annotations

import time
from typing import Any

from engine import Clock, ReplicationEngine

KEY = "article:01:title"
OLD = "Weekly digest"
NEW = "Weekly digest (revised)"
DRAFT = "unpublished draft"


def _values(engine: ReplicationEngine, key: str = KEY) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for node in engine.all_nodes():
        got = engine.get(key, node.name)
        out[node.name] = {
            "status": got.status,
            "value": got.value,
            "role": got.role,
            "ok": got.ok,
            "offset": got.offset,
        }
    return out


def experiment_async_lag_stale_read() -> dict[str, Any]:
    """Pause a replica, write on the master, read both sides."""
    with ReplicationEngine(n_replicas=3) as engine:
        engine.seed(KEY, OLD)
        engine.pause("r1")
        write = engine.set(KEY, NEW, wait_replicas=0)
        after_write = _values(engine)
        master_val = engine.get(KEY, "master").value
        r1_val = engine.get(KEY, "r1").value
        r2_val = engine.get(KEY, "r2").value
        info = engine.info()
        r1_lag = next(r for r in info["replicas"] if r["name"] == "r1")
        engine.flush("r1")
        after_flush = _values(engine)
        return {
            "setup": "1 master + 3 replicas, r1 paused, async SET, then flush r1",
            "write": write.as_dict(),
            "after_write": after_write,
            "master_value": master_val,
            "r1_stale_value": r1_val,
            "r2_fresh_value": r2_val,
            "r1_lag_offset": r1_lag["lag_offset"],
            "after_flush": after_flush,
            "stale_before_flush": r1_val == OLD and master_val == NEW,
            "caught_up_after_flush": after_flush["r1"]["value"] == NEW,
        }


def experiment_async_ack_lost_on_failover() -> dict[str, Any]:
    """Async SET returns ok on the master; crash the master before any
    replica applies; failover keeps the old title."""
    with ReplicationEngine(n_replicas=3) as engine:
        engine.seed(KEY, OLD)
        for name in ("r1", "r2", "r3"):
            engine.pause(name)
        write = engine.set(KEY, NEW, wait_replicas=0)
        before = _values(engine)
        engine.crash("master")
        failover = engine.failover()  # best offset: all replicas still at OLD
        after = _values(engine)
        new_master = failover["promoted"]
        recovered = engine.get(KEY, new_master).value
        return {
            "setup": "pause all replicas, async SET returns ok, crash master, promote best offset",
            "write": write.as_dict(),
            "client_saw_ok": write.ok and write.status == "ok",
            "before_crash": before,
            "failover": failover,
            "after_failover": after,
            "recovered_value": recovered,
            "acknowledged_write_lost": recovered != NEW,
            "lost_writes": 1 if recovered != NEW else 0,
            "allowed_loss": True,
        }


def experiment_wait_promote_acking_replica() -> dict[str, Any]:
    """WAIT 1 succeeds on r1; crash the master; promote r1; the write survives."""
    with ReplicationEngine(n_replicas=3) as engine:
        engine.seed(KEY, OLD)
        engine.pause("r2")
        engine.pause("r3")
        write = engine.set(KEY, NEW, wait_replicas=1, wait_timeout_ms=1000)
        before = _values(engine)
        engine.crash("master")
        failover = engine.failover()  # r1 has the higher offset
        after = _values(engine)
        recovered = engine.get(KEY, failover["promoted"]).value
        return {
            "setup": "r2 and r3 paused, SET + WAIT 1, crash master, promote best offset (r1)",
            "write": write.as_dict(),
            "wait_reached": write.waited >= 1,
            "before_crash": before,
            "failover": failover,
            "after_failover": after,
            "recovered_value": recovered,
            "acknowledged_write_lost": recovered != NEW,
            "lost_writes": 1 if recovered != NEW else 0,
        }


def experiment_wait_promote_lagging_replica() -> dict[str, Any]:
    """WAIT 1 succeeds on r1, but a specified failover promotes lagging r2.

    Official WAIT docs: Sentinel/Cluster make a best-effort attempt to
    promote a replica that received the write; it is still possible to
    lose a write that was synchronously replicated to multiple replicas.
    This teaching case forces the unsuccessful attempt.
    """
    with ReplicationEngine(n_replicas=3) as engine:
        engine.seed(KEY, OLD)
        engine.pause("r2")
        engine.pause("r3")
        write = engine.set(KEY, NEW, wait_replicas=1, wait_timeout_ms=1000)
        before = _values(engine)
        r1_had_new = engine.get(KEY, "r1").value == NEW
        r2_had_old = engine.get(KEY, "r2").value == OLD
        engine.crash("master")
        failover = engine.failover(promote="r2")
        after = _values(engine)
        recovered = engine.get(KEY, failover["promoted"]).value
        # r1 is reconfigured from the new master and also loses NEW.
        r1_after = engine.get(KEY, "r1").value
        return {
            "setup": "r2 and r3 paused, SET + WAIT 1 (r1 acked), crash master, force-promote r2",
            "write": write.as_dict(),
            "wait_reached": write.waited >= 1,
            "before_crash": before,
            "r1_had_new_before_failover": r1_had_new,
            "r2_had_old_before_failover": r2_had_old,
            "failover": failover,
            "after_failover": after,
            "recovered_value": recovered,
            "r1_value_after_reconfig": r1_after,
            "acknowledged_write_lost": recovered != NEW,
            "lost_writes": 1 if recovered != NEW else 0,
            "allowed_loss": True,
        }


def experiment_wait_timeout() -> dict[str, Any]:
    """WAIT 2 with only one caught-up replica times out and returns 1."""
    with ReplicationEngine(n_replicas=3) as engine:
        engine.seed(KEY, OLD)
        engine.pause("r2")
        engine.pause("r3")
        write = engine.set(KEY, NEW, wait_replicas=2, wait_timeout_ms=100)
        return {
            "setup": "only r1 can ack, WAIT 2 timeout 100ms",
            "write": write.as_dict(),
            "waited": write.waited,
            "demanded": write.demanded,
            "client_must_check": write.waited < write.demanded,
            "master_already_ok": write.ok and engine.get(KEY, "master").value == NEW,
            "elapsed_s": write.elapsed_s,
        }


def experiment_min_replicas_and_count_is_not_consensus() -> dict[str, Any]:
    """Three attached replicas do not change confirmation by themselves.
    min-replicas-to-write is a best-effort admission check, not consensus."""
    with ReplicationEngine(n_replicas=3, min_replicas_to_write=0, min_replicas_max_lag=2.0) as engine:
        engine.seed(KEY, OLD)
        info_default = engine.info()
        async_write = engine.set(KEY, NEW, wait_replicas=0)
        # Confirmation stayed on the master even though 3 replicas exist.
        default = {
            "replica_count": info_default["replica_count"],
            "connected_replicas": info_default["connected_replicas"],
            "min_replicas_to_write": info_default["min_replicas_to_write"],
            "write": async_write.as_dict(),
            "confirmation": "master_only",
            "is_consensus": False,
        }

    with ReplicationEngine(n_replicas=3, min_replicas_to_write=2, min_replicas_max_lag=2.0) as engine:
        engine.seed(KEY, OLD)
        ok_when_fresh = engine.set(KEY, NEW, wait_replicas=0)
        engine.pause("r2")
        engine.pause("r3")
        engine.advance(2.1)
        rejected = engine.set(KEY, DRAFT, wait_replicas=0)
        still = engine.get(KEY, "master").value
        info_rejected = engine.info()
        engine.resume("r2")
        engine.flush("r2")
        # r2 just acked, r3 is still stale; fresh should be 2 (r1+r2).
        accepted = engine.set(KEY, DRAFT, wait_replicas=0)
        after = engine.get(KEY, "master").value
        guarded = {
            "min_replicas_to_write": 2,
            "min_replicas_max_lag": 2.0,
            "ok_when_fresh": ok_when_fresh.as_dict(),
            "rejected_when_one_fresh": rejected.as_dict(),
            "title_after_reject": still,
            "fresh_at_reject": info_rejected["fresh_replicas"],
            "accepted_after_r2_ack": accepted.as_dict(),
            "title_after_accept": after,
            "note": (
                "min-replicas-to-write only checks that N replicas recently "
                "pinged; it does not wait for this write to reach them. "
                "Official docs call it a best-effort safety mechanism with "
                "a remaining window for data loss."
            ),
        }
    return {
        "three_replicas_still_async": default,
        "min_replicas_to_write": guarded,
        "sentinel_quorum_is_not_replica_count": True,
        "consensus_nodes_in_this_engine": 0,
    }


def experiment_empty_master_restart() -> dict[str, Any]:
    """Official hazard: master with persistence off auto-restarts empty,
    connected replicas full-sync and wipe their copies."""
    with ReplicationEngine(n_replicas=2, replica_names=["r1", "r2"]) as engine:
        engine.seed(KEY, NEW)
        engine.seed("article:02:title", "Product update")
        before = {
            "master_keys": len(engine.master.store),
            "r1_keys": len(engine.node("r1").store),
            "r2_keys": len(engine.node("r2").store),
            "title": engine.get(KEY, "r1").value,
        }
        engine.crash("master")
        # Persistence was off: restart empty while replicas stay connected.
        engine.restart_empty("master")
        after = _values(engine)
        return {
            "setup": "master persist=off, two replicas have 2 titles, crash + empty restart, replicas still attached",
            "before": before,
            "after": after,
            "master_keys_after": len(engine.master.store),
            "r1_keys_after": len(engine.node("r1").store),
            "r2_keys_after": len(engine.node("r2").store),
            "replicas_wiped": after["r1"]["status"] == "not_found" and after["r2"]["status"] == "not_found",
            "lost_titles": 2,
        }


def experiment_link_down_read() -> dict[str, Any]:
    """A replica whose link is down can still serve its current dataset,
    or refuse the read if configured to return an error."""
    with ReplicationEngine(n_replicas=2) as engine:
        engine.seed(KEY, OLD)
        engine.pause("r1")
        engine.set(KEY, NEW)
        engine.disconnect("r1")
        stale_ok = engine.get(KEY, "r1")
        engine.node("r1").serve_on_link_down = False
        stale_err = engine.get(KEY, "r1")
        return {
            "setup": "r1 paused then disconnected after a master write it did not apply",
            "serve_current_dataset": stale_ok.as_dict(),
            "return_error": stale_err.as_dict(),
            "stale_value": stale_ok.value,
            "error_status": stale_err.status,
        }


def _latency_batch(wait_replicas: int, delays: dict[str, float], n: int = 20) -> dict[str, Any]:
    clock = Clock(start=0.0, live=True)
    with ReplicationEngine(n_replicas=3, clock=clock) as engine:
        for name, delay in delays.items():
            engine.node(name).ack_delay_s = delay
        engine.seed(KEY, OLD)
        engine.start_pump(interval_s=0.001)
        t0 = time.perf_counter()
        writes = []
        for i in range(n):
            wr = engine.set(KEY, f"{NEW}:{i}", wait_replicas=wait_replicas, wait_timeout_ms=2000)
            writes.append(wr.as_dict())
        elapsed = time.perf_counter() - t0
        engine.stop_pump()
        engine.flush()
        waited = [w["waited"] for w in writes]
        return {
            "n": n,
            "wait_replicas": wait_replicas,
            "ack_delay_s": delays,
            "elapsed_s": elapsed,
            "ops_per_s": (n / elapsed) if elapsed > 0 else 0.0,
            "mean_write_s": elapsed / n,
            "min_waited": min(waited) if waited else 0,
            "max_waited": max(waited) if waited else 0,
            "all_ok": all(w["ok"] for w in writes),
        }


def experiment_sync_latency() -> dict[str, Any]:
    """Synchronous WAIT pays the replica delay; a single slow replica
    stalls WAIT 3 but not WAIT 1 when another replica is fast."""
    async_fast = _latency_batch(0, {"r1": 0.0, "r2": 0.0, "r3": 0.0})
    wait1_fast = _latency_batch(1, {"r1": 0.0, "r2": 0.0, "r3": 0.0})
    wait1_all_slow = _latency_batch(1, {"r1": 0.05, "r2": 0.05, "r3": 0.05})
    wait1_one_fast = _latency_batch(1, {"r1": 0.0, "r2": 0.20, "r3": 0.20})
    wait3_one_slow = _latency_batch(3, {"r1": 0.0, "r2": 0.0, "r3": 0.05})
    return {
        "n": 20,
        "async_fast": async_fast,
        "wait1_fast": wait1_fast,
        "wait1_all_slow_50ms": wait1_all_slow,
        "wait1_one_fast_two_200ms": wait1_one_fast,
        "wait3_one_slow_50ms": wait3_one_slow,
    }


def run_all_experiments() -> dict[str, Any]:
    return {
        "async_lag_stale_read": experiment_async_lag_stale_read(),
        "async_ack_lost_on_failover": experiment_async_ack_lost_on_failover(),
        "wait_promote_acking_replica": experiment_wait_promote_acking_replica(),
        "wait_promote_lagging_replica": experiment_wait_promote_lagging_replica(),
        "wait_timeout": experiment_wait_timeout(),
        "replica_count_is_not_consensus": experiment_min_replicas_and_count_is_not_consensus(),
        "empty_master_restart": experiment_empty_master_restart(),
        "link_down_read": experiment_link_down_read(),
        "sync_latency": experiment_sync_latency(),
    }


if __name__ == "__main__":
    import json

    data = run_all_experiments()
    print(json.dumps(list(data.keys()), ensure_ascii=False))
