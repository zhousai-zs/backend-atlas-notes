#include "../strong_types.h"
using namespace std::chrono_literals;
int main() { send_request(UserId(7), Bytes(1), 1s, Bytes(2)); } // 把用户ID当请求ID
