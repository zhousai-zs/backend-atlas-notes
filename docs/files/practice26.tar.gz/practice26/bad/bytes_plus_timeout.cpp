#include "../strong_types.h"
using namespace std::chrono_literals;
int main() { auto x = Bytes(1) + 1s; (void)x; } // 字节 + 时间
