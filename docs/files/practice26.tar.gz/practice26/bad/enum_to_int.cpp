#include "../strong_types.h"
int main() { int code = Status::Ok; (void)code; } // enum class 不隐式转 int
