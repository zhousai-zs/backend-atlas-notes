#include "../strong_types.h"
using namespace std::chrono_literals;
int main() { auto id = RequestId(1); send_request(id, 3s, Bytes(100), Bytes(1024)); } // 参数顺序写错
