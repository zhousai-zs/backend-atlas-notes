#include "../strong_types.h"
int main() { send_request(RequestId(1), 100, 3000, 1024); } // 裸整数，单位不明
