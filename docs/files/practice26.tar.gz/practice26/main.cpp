#include "strong_types.h"
#include <cassert>
#include <cstdio>
using namespace std::chrono_literals;
int main() {
    auto id = parse_request_id("12345");
    assert(id.value() == 12345);
    assert(send_request(id, Bytes(100), 3s, Bytes(1024)) == Status::Ok);      // 3s 自动换成 3000ms
    assert(send_request(id, Bytes(2048), 500ms, Bytes(1024)) == Status::TooLarge);
    assert(send_request(id, Bytes(1), 0ms, Bytes(1024)) == Status::Timeout);
    assert((Bytes(1) + Bytes(2)).value() == 3);
    bool threw = false;
    try { parse_request_id("12a"); } catch (const std::invalid_argument&) { threw = true; }
    assert(threw);
    std::printf("ALL_TESTS_PASSED\n");
}
