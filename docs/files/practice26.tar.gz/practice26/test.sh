#!/bin/bash
set -u
cd "$(dirname "$0")"
CXX="g++ -std=c++17 -Wall -Wextra"
$CXX -fsanitize=address,undefined main.cpp -o main && ./main || { echo "FAIL: main"; exit 1; }
for f in bad/*.cpp; do
  if $CXX -fsyntax-only "$f" 2>/dev/null; then echo "FAIL: $f 竟然能编译"; exit 1; fi
  echo "OK: $f 编译被拒"
done
echo "ALL_CHECKS_PASSED"
