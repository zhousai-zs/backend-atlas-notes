#pragma once
#include <chrono>
#include <cstdint>
#include <string>
#include <stdexcept>

// 超时：直接复用 std::chrono，单位换算由类型系统负责
using Timeout = std::chrono::milliseconds;

// 字节数：强类型包装，explicit 构造，只允许同类加减
class Bytes {
public:
    constexpr explicit Bytes(std::uint64_t n) : n_(n) {}
    constexpr std::uint64_t value() const { return n_; }
    friend constexpr Bytes operator+(Bytes a, Bytes b) { return Bytes(a.n_ + b.n_); }
    friend constexpr bool operator<(Bytes a, Bytes b) { return a.n_ < b.n_; }
private:
    std::uint64_t n_;
};

// 用 Tag 区分的 ID：RequestId 与 UserId 底层都是 uint64，但互不兼容
template <class Tag>
class Id {
public:
    constexpr explicit Id(std::uint64_t v) : v_(v) {}
    constexpr std::uint64_t value() const { return v_; }
    friend constexpr bool operator==(Id a, Id b) { return a.v_ == b.v_; }
private:
    std::uint64_t v_;
};
struct RequestTag {};
struct UserTag {};
using RequestId = Id<RequestTag>;
using UserId = Id<UserTag>;

// 边界处：从外部字符串解析，必须显式校验
inline RequestId parse_request_id(const std::string& s) {
    if (s.empty() || s.size() > 20) throw std::invalid_argument("bad request id");
    for (char c : s) if (c < '0' || c > '9') throw std::invalid_argument("bad request id");
    return RequestId(std::stoull(s));
}

enum class Status : std::uint8_t { Ok = 0, Timeout = 1, TooLarge = 2 };

// 接口：参数类型各不相同，调用方无法传错位置
inline Status send_request(RequestId id, Bytes body, Timeout timeout, Bytes limit) {
    (void)id;
    if (limit < body) return Status::TooLarge;
    if (timeout <= Timeout(0)) return Status::Timeout;
    return Status::Ok;
}
