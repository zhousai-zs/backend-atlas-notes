#pragma once

#include "types.h"

#include <cstdint>
#include <string>

RequestBudget parse_budget(std::string id,
                           std::int64_t timeout_ms,
                           std::uint64_t max_body_bytes);
