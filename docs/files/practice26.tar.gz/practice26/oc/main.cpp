#include "api.h"
#include "parse.h"

#include <exception>
#include <iostream>

int main() {
    try {
        RequestBudget budget = parse_budget("req-20261102-001", 0, 4096);
        handle_request(budget.id, budget.timeout, budget.max_body);
    } catch (const std::exception& e) {
        std::cerr << "bad request: " << e.what() << '\n';
        return 1;
    }
}
