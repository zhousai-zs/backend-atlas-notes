#pragma once

#include <cstdint>
#include <stdexcept>
#include <string>
#include <utility>

class Milliseconds {
public:
    explicit constexpr Milliseconds(std::int64_t value) noexcept
        : value_(value) {}

    constexpr std::int64_t count() const noexcept { return value_; }

private:
    std::int64_t value_;
};

class Bytes {
public:
    explicit constexpr Bytes(std::uint64_t value) noexcept
        : value_(value) {}

    constexpr std::uint64_t count() const noexcept { return value_; }

private:
    std::uint64_t value_;
};

class RequestId {
public:
    explicit RequestId(std::string value)
        : value_(std::move(value)) {
        if (value_.empty()) {
            throw std::invalid_argument("request id must not be empty");
        }
    }

    const std::string& str() const noexcept { return value_; }

private:
    std::string value_;
};

struct RequestBudget {
    RequestId id;
    Milliseconds timeout;
    Bytes max_body;
};
