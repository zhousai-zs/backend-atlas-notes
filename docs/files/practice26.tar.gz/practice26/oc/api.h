#pragma once

#include "types.h"

void handle_request(const RequestId& id, Milliseconds timeout, Bytes max_body);
