#include "parse.h"

#include <stdexcept>
#include <utility>

RequestBudget parse_budget(std::string id,
                           std::int64_t timeout_ms,
                           std::uint64_t max_body_bytes) {
    if (timeout_ms <= 0 || timeout_ms > 60'000) {
        throw std::invalid_argument("timeout out of range");
    }
    if (max_body_bytes == 0 || max_body_bytes > 8 * 1024 * 1024) {
        throw std::invalid_argument("body size out of range");
    }
    return RequestBudget{
        RequestId{std::move(id)},
        Milliseconds{timeout_ms},
        Bytes{max_body_bytes}
    };
}
