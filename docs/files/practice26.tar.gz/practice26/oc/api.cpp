#include "api.h"

#include <iostream>

void handle_request(const RequestId& id, Milliseconds timeout, Bytes max_body) {
    std::cout << "request_id=" << id.str()
              << " timeout_ms=" << timeout.count()
              << " max_body_bytes=" << max_body.count() << '\n';
}
