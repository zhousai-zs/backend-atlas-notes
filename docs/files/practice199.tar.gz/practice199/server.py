"""One OS process per teaching replica, so a 'failed machine' is a killed process."""
from __future__ import annotations

import os
import socket
import time
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import Process


def _handle(conn, spin: int):
    try:
        data = conn.recv(64)
        s = 0
        for i in range(spin):
            s += i & 7
        conn.sendall(b"v" if data else b"v")
        _ = s
    finally:
        conn.close()


def replica_main(port: int, spin: int, workers: int) -> None:
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port))
    s.listen(128)
    s.settimeout(0.2)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        while True:
            try:
                c, _ = s.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            ex.submit(_handle, c, spin)
    s.close()


def start_replica(port: int, spin: int = 12000, workers: int = 2) -> Process:
    p = Process(target=replica_main, args=(port, spin, workers), daemon=True)
    p.start()
    # wait until accepting
    t0 = time.time()
    while time.time() - t0 < 3:
        try:
            c = socket.create_connection(("127.0.0.1", port), timeout=0.2)
            c.close()
            return p
        except OSError:
            time.sleep(0.02)
    raise RuntimeError(f"replica on {port} did not start")


def stop_replica(p: Process) -> None:
    if p.is_alive():
        p.terminate()
        p.join(timeout=2)
        if p.is_alive():
            p.kill()
            p.join(timeout=2)


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def measure_qps(ports: list[int], seconds: float = 1.0, readers: int = 16) -> dict:
    n = {"ok": 0, "err": 0}
    stop_at = time.perf_counter() + seconds

    def loop(i0: int):
        i = i0
        while time.perf_counter() < stop_at:
            port = ports[i % len(ports)]
            i += 1
            try:
                s = socket.create_connection(("127.0.0.1", port), timeout=0.5)
                s.sendall(b"g")
                s.recv(8)
                s.close()
                n["ok"] += 1
            except OSError:
                n["err"] += 1

    with ThreadPoolExecutor(max_workers=readers) as ex:
        futs = [ex.submit(loop, i) for i in range(readers)]
        for f in futs:
            f.result()
    return {"ops": n["ok"], "errors": n["err"], "seconds": seconds, "qps": n["ok"] / seconds, "replicas": len(ports)}
