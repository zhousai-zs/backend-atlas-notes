#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["report"]["measured_n1_qps"] < r["report"]["measured_3_replica_qps"]
assert r["report"]["relative_error"] is not None
assert r["report"]["cost"]["includes_replication_and_backup"]
assert r["failed"]==[]
print("POSTCHECK_OK")
PY
