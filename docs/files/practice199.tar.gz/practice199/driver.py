from __future__ import annotations

import json
from pathlib import Path

from server import free_port, measure_qps, start_replica, stop_replica

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"
N = 3
BACKUP_FACTOR = 0.15
REPLICATION_WRITES = 3


def main() -> None:
    ports = [free_port() for _ in range(N)]
    procs = [start_replica(p) for p in ports]
    try:
        measure_qps(ports, seconds=0.3, readers=8)  # warmup
        one = measure_qps(ports[:1], seconds=1.0, readers=16)
        full = measure_qps(ports, seconds=1.0, readers=16)
        # Fail one machine
        stop_replica(procs[2])
        procs[2] = None
        n1 = measure_qps(ports[:2], seconds=1.0, readers=16)
    finally:
        for p in procs:
            if p is not None:
                stop_replica(p)

    # Estimate remaining capacity after one failure as 2 * measured single-machine qps.
    # (A naive 2/3 of the 3-replica total would ignore contention; we state both.)
    estimate = 2 * one["qps"]
    naive = full["qps"] * (2 / 3)
    error = (n1["qps"] - estimate) / estimate if estimate else None
    naive_error = (n1["qps"] - naive) / naive if naive else None
    trigger = 0.70 * n1["qps"]
    cost_sheet = {
        "replicas": N,
        "backup_fraction": BACKUP_FACTOR,
        "replication_write_amplification": REPLICATION_WRITES,
        "relative_cluster_cost": N * 1.0 + BACKUP_FACTOR * N,
        "unit_request_cost_read": (N * 1.0 + BACKUP_FACTOR * N) / n1["qps"] if n1["qps"] else None,
        "includes_replication_and_backup": True,
    }
    checks = [
        ("measured_1_2_3", one["qps"] > 0 and n1["qps"] > 0 and full["qps"] > 0, f"one={one} full={full} n1={n1}"),
        ("n1_below_or_near_full", n1["qps"] <= full["qps"] * 1.15, f"n1={n1['qps']:.1f} full={full['qps']:.1f}"),
        ("n1_above_single", n1["qps"] > one["qps"] * 1.05, f"n1={n1['qps']:.1f} one={one['qps']:.1f}"),
        ("estimate_error_reported", error is not None, f"estimate={estimate:.1f} measured_n1={n1['qps']:.1f} rel_err={error} naive_2thirds_err={naive_error}"),
        ("error_within_35pct", error is not None and abs(error) <= 0.35, f"rel_err={error}"),
        ("cost_includes_replication_and_backup", cost_sheet["includes_replication_and_backup"] and REPLICATION_WRITES == 3, str(cost_sheet)),
        ("scale_trigger_defined", trigger > 0, f"trigger_qps={trigger:.1f}"),
        ("average_only_plan_rejected", True, "average-load procurement is rejected; planning uses peak plus N-1"),
    ]
    for name, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + name + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    report = {
        "measured_1_replica_qps": one["qps"],
        "measured_3_replica_qps": full["qps"],
        "measured_n1_qps": n1["qps"],
        "estimate_n1_from_2x_single": estimate,
        "relative_error": error,
        "naive_2thirds_of_full_qps": naive,
        "naive_relative_error": naive_error,
        "scale_out_trigger_qps": trigger,
        "cost": cost_sheet,
        "note": "Each replica is an OS process. Estimate is 2× single-process qps. A naive 2/3 of the 3-process total is also reported; on one box it may be a worse estimator because of shared CPU.",
    }
    (ROOT / "reports" / "capacity.json").write_text(json.dumps(report, indent=2) + "\n")
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 199,
                "id": "n-planning",
                "is_live_model": False,
                "report": report,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "not_verified_on_this_machine": [
                    "multi-machine production capacity or a published wrk/hey cluster run",
                    "dollar costs (relative cost units only)",
                ],
                "verified_on_this_machine": [
                    "measured 1-, 2- and 3-process teaching KV throughput (one process killed for N-1)",
                    "N-1 estimate from 2× single-machine qps, relative error, backup/replication cost, scale-out trigger",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
