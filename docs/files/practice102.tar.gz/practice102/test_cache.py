#!/usr/bin/env python3
"""Acceptance checks for the g-cache teaching lab."""
from __future__ import annotations

import json
import os
import sys

from app import (
    AVALANCHE_TTL_S,
    CONCURRENT,
    JITTER_S,
    NEGATIVE_TTL_S,
    TTL_S,
    run_all_experiments,
)

HERE = os.path.dirname(os.path.abspath(__file__))

CACHE_ASIDE = "https://redis.io/docs/latest/develop/use-cases/cache-aside/"
CACHE_ASIDE_PY = "https://redis.io/docs/latest/develop/use-cases/cache-aside/redis-py/"
CSC_INTRO = "https://redis.io/docs/latest/develop/clients/client-side-caching/"
CSC_REF = "https://redis.io/docs/latest/develop/reference/client-side-caching/"
NODE_CSC = "https://redis.io/docs/latest/develop/use/client-side-caching/"


def main() -> int:
    data = run_all_experiments()
    data.update(
        {
            "python": sys.version.split()[0],
            "cache_aside_doc": CACHE_ASIDE,
            "cache_aside_py_doc": CACHE_ASIDE_PY,
            "csc_intro_doc": CSC_INTRO,
            "csc_ref_doc": CSC_REF,
            "node_resource_url": NODE_CSC,
            "node_resource_status": "404 on 2026-11-11; content lives at csc_intro_doc / csc_ref_doc",
            "docs_checked": "2026-11-11",
        }
    )

    _assert_ttl(data["cache_aside_and_ttl"])
    _assert_stampede(data["stampede"])
    _assert_avalanche(data["avalanche"])
    _assert_negative(data["negative_cache"])
    _assert_races(data["update_races"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

    ttl = data["cache_aside_and_ttl"]
    st = data["stampede"]
    av = data["avalanche"]
    neg = data["negative_cache"]
    race = data["update_races"]
    sw = ttl["stale_window"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"ttl_hit_loads={ttl['after_hit']['loads']} "
        f"expire_loads={ttl['after_expire']['loads']} "
        f"invalidate_title={ttl['after_invalidate']['cached_title']!r} "
        f"max_stale={sw['declared_max_stale_s']} "
        f"crash_stale={sw['title_while_waiting']!r}/{sw['stale_lasted_s']}s "
        f"stampede_naive={st['naive']['loads']} stampede_safe={st['safe']['loads']} "
        f"avalanche_naive_peak={av['naive']['peak_loads']} "
        f"avalanche_safe_peak={av['safe']['peak_loads']} "
        f"jitter_span={av['safe']['expire_span_s']} "
        f"neg_naive={neg['naive']['after_burst']['loads']}+{neg['naive']['after_extra']['loads']} "
        f"neg_safe_burst={neg['safe']['after_burst']['loads']} "
        f"neg_safe_extra={neg['safe']['after_extra']['loads']} "
        f"neg_after_ttl={neg['safe']['after_negative_ttl']['loads_after_expire']} "
        f"race_naive_later={race['naive_stale_fill']['later_title']!r} "
        f"race_safe_later={race['safe_generation_guard']['later_title']!r} "
        f"aborted={race['safe_generation_guard']['stale_fills_aborted']} "
        f"double_del_stale={race['delayed_double_delete']['later_title']!r}"
    )
    return 0


def _assert_ttl(data: dict) -> None:
    assert data["after_miss"]["loads"] == 1, data["after_miss"]
    assert data["after_miss"]["title"] == "Weekly digest"
    assert data["after_hit"]["loads"] == 1, data["after_hit"]
    assert data["after_hit"]["hits"] >= 1
    assert data["after_expire"]["loads"] == 2, data["after_expire"]
    inv = data["after_invalidate"]
    assert inv["remaining_after_del"] == -2.0
    assert inv["cached_title"] == "Weekly digest (revised)"
    assert inv["db_title"] == inv["cached_title"]
    assert inv["loads"] == 3
    sw = data["stale_window"]
    assert sw["declared_max_stale_s"] == TTL_S + JITTER_S
    assert sw["title_while_waiting"] == "Old headline"
    assert sw["title_after_expire"] == "New headline"
    assert sw["within_declared_bound"] is True
    assert sw["stale_lasted_s"] == sw["remaining_at_crash_s"]
    assert sw["loads_while_waiting"] == 1
    assert sw["loads_after_expire"] == 2


def _assert_stampede(data: dict) -> None:
    naive, safe = data["naive"], data["safe"]
    assert naive["concurrent"] == CONCURRENT
    assert naive["loads"] == CONCURRENT, naive
    assert safe["loads"] == 1, safe
    assert naive["unique_titles"] == ["Weekly digest"]
    assert safe["unique_titles"] == ["Weekly digest"]


def _assert_avalanche(data: dict) -> None:
    naive, safe = data["naive"], data["safe"]
    assert naive["peak_loads"] == naive["articles"] == 200, naive
    assert naive["expire_span_s"] == 0.0
    assert safe["jitter_s"] == JITTER_S
    assert safe["expire_min_s"] < AVALANCHE_TTL_S < safe["expire_max_s"]
    assert safe["expire_span_s"] > 0.2
    assert safe["peak_loads"] < 80, safe
    assert safe["peak_loads"] < naive["peak_loads"] / 2


def _assert_negative(data: dict) -> None:
    naive, safe = data["naive"], data["safe"]
    assert naive["after_burst"]["loads"] == 50, naive
    assert naive["after_burst"]["all_none"] is True
    assert naive["after_extra"]["loads"] == 70
    assert safe["after_burst"]["loads"] == 1, safe
    assert safe["after_burst"]["all_none"] is True
    assert safe["after_burst"]["negative_cached"] is True
    assert safe["after_extra"]["loads"] == 1
    exp = safe["after_negative_ttl"]
    assert exp["loads_on_first"] == 1
    assert exp["loads_mid_window"] == 1
    assert exp["loads_after_expire"] == 2


def _assert_races(data: dict) -> None:
    naive = data["naive_stale_fill"]
    assert naive["loader_saw"] == "draft v1"
    assert naive["updated_to"] == "published v2"
    assert naive["db_title"] == "published v2"
    assert naive["later_title"] == "draft v1"
    assert naive["stale_after"] is True

    safe = data["safe_generation_guard"]
    assert safe["loader_saw"] == "draft v1"
    assert safe["updated_to"] == "published v2"
    assert safe["db_title"] == "published v2"
    assert safe["later_title"] == "published v2"
    assert safe["stale_after"] is False
    assert safe["stale_fills_aborted"] == 1

    ddd = data["delayed_double_delete"]
    assert ddd["loader_saw"] == "draft v1"
    assert ddd["updated_to"] == "published v2"
    assert ddd["db_title"] == "published v2"
    assert ddd["later_title"] == "draft v1"
    assert ddd["stale_after_second_delete"] is True


if __name__ == "__main__":
    sys.exit(main())
