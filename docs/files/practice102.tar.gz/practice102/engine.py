#!/usr/bin/env python3
"""Teaching CacheEngine — not Redis.

A Python standard-library model of a cache-aside layer in front of a
primary article store. It demonstrates TTL, request coalescing
(singleflight), expiration jitter, negative caching, and a generation
guard that refuses to fill a key after it has been invalidated.

This is not Redis, not redis-py, and not a network cache service.
The cache-aside read/invalidate/TTL semantics follow the Redis
cache-aside documentation checked on 2026-11-11, for the subset
implemented here. Client-side tracking, Lua locks, hash field updates,
and eviction policies are not modeled.
"""
from __future__ import annotations

import copy
import random
import threading
import time
from typing import Any, Callable, Optional


class Clock:
    """A clock tests can freeze and advance, or run from time.monotonic()."""

    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        self.t += float(seconds)


class ArticleDB:
    """In-memory primary store with an optional per-read delay."""

    def __init__(self, load_s: float = 0.0) -> None:
        self.load_s = float(load_s)
        self._rows: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self.loads = 0
        self.updates = 0
        self.before_return: Optional[Callable[[str, Optional[dict[str, Any]]], None]] = None

    def reset_counters(self) -> None:
        with self._lock:
            self.loads = 0
            self.updates = 0

    def seed(self, article_id: str, title: str, status: str = "published") -> dict[str, Any]:
        row = {
            "id": str(article_id),
            "title": title,
            "status": status,
            "version": 1,
        }
        with self._lock:
            self._rows[str(article_id)] = row
            return copy.deepcopy(row)

    def get(self, article_id: str) -> Optional[dict[str, Any]]:
        article_id = str(article_id)
        if self.load_s > 0:
            time.sleep(self.load_s)
        with self._lock:
            self.loads += 1
            row = self._rows.get(article_id)
            out = copy.deepcopy(row) if row is not None else None
        hook = self.before_return
        if hook is not None:
            hook(article_id, out)
        return out

    def update(self, article_id: str, **fields: Any) -> dict[str, Any]:
        article_id = str(article_id)
        with self._lock:
            if article_id not in self._rows:
                raise KeyError(article_id)
            self.updates += 1
            row = self._rows[article_id]
            row.update(fields)
            row["version"] = int(row.get("version", 1)) + 1
            return copy.deepcopy(row)

    def snapshot(self, article_id: str) -> Optional[dict[str, Any]]:
        with self._lock:
            row = self._rows.get(str(article_id))
            return copy.deepcopy(row) if row is not None else None


class CacheHit:
    __slots__ = ("found", "value", "negative", "ttl")

    def __init__(self, found: bool, value: Any = None, negative: bool = False, ttl: int = -2) -> None:
        self.found = found
        self.value = value
        self.negative = negative
        self.ttl = ttl


class _Entry:
    __slots__ = ("value", "expire_at", "negative")

    def __init__(self, value: Any, expire_at: Optional[float], negative: bool) -> None:
        self.value = value
        self.expire_at = expire_at
        self.negative = negative


class CacheStore:
    """In-memory keyspace with per-key TTL and a generation counter."""

    def __init__(self, clock: Clock) -> None:
        self._clock = clock
        self._keys: dict[str, _Entry] = {}
        self._gen: dict[str, int] = {}
        self._lock = threading.Lock()
        self.hits = 0
        self.misses = 0
        self.sets = 0
        self.deletes = 0

    def reset_stats(self) -> None:
        with self._lock:
            self.hits = 0
            self.misses = 0
            self.sets = 0
            self.deletes = 0

    def now(self) -> float:
        return self._clock.now()

    def generation(self, key: str) -> int:
        with self._lock:
            return self._gen.get(key, 0)

    def _expire_unlocked(self, key: str) -> None:
        ent = self._keys.get(key)
        if ent is None:
            return
        if ent.expire_at is not None and self._clock.now() >= ent.expire_at:
            del self._keys[key]

    def get(self, key: str) -> CacheHit:
        with self._lock:
            self._expire_unlocked(key)
            ent = self._keys.get(key)
            if ent is None:
                self.misses += 1
                return CacheHit(False, ttl=-2)
            self.hits += 1
            ttl = -1 if ent.expire_at is None else max(0, int(ent.expire_at - self._clock.now()))
            # Keep a fractional remaining time as well via a richer ttl_s below.
            return CacheHit(True, copy.deepcopy(ent.value), ent.negative, ttl=ttl)

    def remaining(self, key: str) -> float:
        """Remaining TTL in seconds. -2 missing, -1 no expire."""
        with self._lock:
            self._expire_unlocked(key)
            ent = self._keys.get(key)
            if ent is None:
                return -2.0
            if ent.expire_at is None:
                return -1.0
            return max(0.0, ent.expire_at - self._clock.now())

    def expire_at(self, key: str) -> Optional[float]:
        with self._lock:
            self._expire_unlocked(key)
            ent = self._keys.get(key)
            return None if ent is None else ent.expire_at

    def set(self, key: str, value: Any, ttl_s: Optional[float], negative: bool = False) -> None:
        expire_at = None if ttl_s is None else self._clock.now() + float(ttl_s)
        with self._lock:
            self._keys[key] = _Entry(copy.deepcopy(value), expire_at, negative)
            self.sets += 1

    def set_if_generation(self, key: str, value: Any, ttl_s: Optional[float], expected_gen: int, negative: bool = False) -> bool:
        expire_at = None if ttl_s is None else self._clock.now() + float(ttl_s)
        with self._lock:
            current = self._gen.get(key, 0)
            if current != expected_gen:
                return False
            self._keys[key] = _Entry(copy.deepcopy(value), expire_at, negative)
            self.sets += 1
            return True

    def delete(self, key: str) -> bool:
        with self._lock:
            existed = key in self._keys
            self._keys.pop(key, None)
            self.deletes += 1
            return existed

    def invalidate(self, key: str) -> int:
        """Delete the key and bump its generation so in-flight fills abort."""
        with self._lock:
            self._keys.pop(key, None)
            self.deletes += 1
            nxt = self._gen.get(key, 0) + 1
            self._gen[key] = nxt
            return nxt

    def size(self) -> int:
        with self._lock:
            now = self._clock.now()
            for k in list(self._keys):
                ent = self._keys[k]
                if ent.expire_at is not None and now >= ent.expire_at:
                    del self._keys[k]
            return len(self._keys)


class CacheAside:
    """cache-aside helper. The safe flag turns on coalescing, jitter, negative cache, and the generation guard."""

    def __init__(
        self,
        db: ArticleDB,
        cache: CacheStore,
        ttl_s: float,
        jitter_s: float = 0.0,
        singleflight: bool = False,
        negative_ttl_s: Optional[float] = None,
        generation_guard: bool = False,
        rng: Optional[random.Random] = None,
    ) -> None:
        self.db = db
        self.cache = cache
        self.ttl_s = float(ttl_s)
        self.jitter_s = float(jitter_s)
        self.singleflight = bool(singleflight)
        self.negative_ttl_s = None if negative_ttl_s is None else float(negative_ttl_s)
        self.generation_guard = bool(generation_guard)
        self.rng = rng or random.Random()
        self._sf_lock = threading.Lock()
        self._inflight: dict[str, dict[str, Any]] = {}
        self.stale_fills_aborted = 0
        self.after_load: Optional[Callable[[str, Optional[dict[str, Any]]], None]] = None

    def key(self, article_id: str) -> str:
        return f"cache:article:{article_id}"

    def max_ttl_s(self) -> float:
        return self.ttl_s + self.jitter_s

    def choose_ttl(self, negative: bool = False) -> float:
        base = self.negative_ttl_s if negative and self.negative_ttl_s is not None else self.ttl_s
        if self.jitter_s <= 0:
            return base
        delta = self.rng.uniform(-self.jitter_s, self.jitter_s)
        return max(0.001, base + delta)

    def get(self, article_id: str) -> Optional[dict[str, Any]]:
        key = self.key(article_id)
        hit = self.cache.get(key)
        if hit.found:
            return hit.value
        if self.singleflight:
            return self._load_singleflight(article_id, key)
        return self._load_and_fill(article_id, key)

    def update(self, article_id: str, **fields: Any) -> dict[str, Any]:
        row = self.db.update(article_id, **fields)
        self.cache.invalidate(self.key(article_id))
        return row

    def update_db_only(self, article_id: str, **fields: Any) -> dict[str, Any]:
        """Simulate a writer that updated the primary and crashed before invalidation."""
        return self.db.update(article_id, **fields)

    def delayed_double_delete(self, article_id: str, delay_s: float, **fields: Any) -> dict[str, Any]:
        """Update the primary, delete, wait, delete again. Not a consistency proof."""
        row = self.db.update(article_id, **fields)
        key = self.key(article_id)
        self.cache.delete(key)
        if delay_s > 0:
            time.sleep(delay_s)
        self.cache.delete(key)
        return row

    def _load_singleflight(self, article_id: str, key: str) -> Optional[dict[str, Any]]:
        with self._sf_lock:
            slot = self._inflight.get(key)
            if slot is None:
                slot = {"event": threading.Event(), "result": None, "error": None, "leader": True}
                self._inflight[key] = slot
                leader = True
            else:
                leader = False
        if not leader:
            if not slot["event"].wait(timeout=10):
                raise TimeoutError(f"singleflight wait expired for {key}")
            if slot["error"] is not None:
                raise slot["error"]
            return slot["result"]
        try:
            result = self._load_and_fill(article_id, key)
            slot["result"] = result
            return result
        except Exception as exc:
            slot["error"] = exc
            raise
        finally:
            with self._sf_lock:
                if self._inflight.get(key) is slot:
                    del self._inflight[key]
            slot["event"].set()

    def _load_and_fill(self, article_id: str, key: str) -> Optional[dict[str, Any]]:
        expected_gen = self.cache.generation(key)
        row = self.db.get(article_id)
        hook = self.after_load
        if hook is not None:
            hook(article_id, row)
        negative = row is None
        ttl = self.choose_ttl(negative=negative)
        if negative and self.negative_ttl_s is None:
            return None
        if self.generation_guard:
            ok = self.cache.set_if_generation(key, row, ttl, expected_gen, negative=negative)
            if not ok:
                self.stale_fills_aborted += 1
            return row
        self.cache.set(key, row, ttl, negative=negative)
        return row
