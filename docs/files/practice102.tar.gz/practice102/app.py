#!/usr/bin/env python3
"""Runnable experiments for the g-cache teaching lab."""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional

from engine import ArticleDB, CacheAside, CacheStore, Clock

CONCURRENT = 200
ARTICLE_COUNT = 200
TTL_S = 2.0
JITTER_S = 0.2
NEGATIVE_TTL_S = 0.4
LOAD_S = 0.05
AVALANCHE_TTL_S = 1.0
AVALANCHE_STEP_S = 0.05
RACE_LOAD_S = 0.05
DOUBLE_DELETE_DELAY_S = 0.05


def _round(x: float, ndigits: int = 4) -> float:
    return round(float(x), ndigits)


def _layer(
    *,
    safe: bool,
    clock: Clock,
    load_s: float = 0.0,
    ttl_s: float = TTL_S,
    jitter_s: float = 0.0,
    negative_ttl_s: Optional[float] = None,
    seed: int = 42,
) -> tuple[ArticleDB, CacheStore, CacheAside]:
    db = ArticleDB(load_s=load_s)
    cache = CacheStore(clock)
    layer = CacheAside(
        db,
        cache,
        ttl_s=ttl_s,
        jitter_s=jitter_s if safe else 0.0,
        singleflight=safe,
        negative_ttl_s=negative_ttl_s if safe else None,
        generation_guard=safe,
        rng=__import__("random").Random(seed),
    )
    return db, cache, layer


def cache_aside_and_ttl() -> dict[str, Any]:
    clock = Clock(start=0.0, live=False)
    db, cache, layer = _layer(safe=True, clock=clock, load_s=0.0, ttl_s=TTL_S, jitter_s=0.0)
    db.seed("42", "Weekly digest", status="published")

    first = layer.get("42")
    after_miss = {
        "title": first["title"] if first else None,
        "loads": db.loads,
        "hit_after": cache.hits,
        "miss_after": cache.misses,
        "remaining_s": _round(cache.remaining(layer.key("42"))),
    }
    second = layer.get("42")
    after_hit = {
        "title": second["title"] if second else None,
        "loads": db.loads,
        "hits": cache.hits,
        "misses": cache.misses,
        "remaining_s": _round(cache.remaining(layer.key("42"))),
    }
    clock.advance(TTL_S)
    third = layer.get("42")
    after_expire = {
        "title": third["title"] if third else None,
        "loads": db.loads,
        "remaining_s": _round(cache.remaining(layer.key("42"))),
        "expired_ttl_was": -2,
    }

    layer.update("42", title="Weekly digest (revised)", status="published")
    remaining_right_after_update = cache.remaining(layer.key("42"))
    fourth = layer.get("42")
    after_invalidate = {
        "db_title": db.snapshot("42")["title"],
        "cached_title": fourth["title"] if fourth else None,
        "loads": db.loads,
        "remaining_after_del": remaining_right_after_update,
    }

    # Writer updates the primary and crashes before DEL. Readers stay stale until TTL.
    clock2 = Clock(start=0.0, live=False)
    db2, cache2, layer2 = _layer(safe=True, clock=clock2, load_s=0.0, ttl_s=TTL_S, jitter_s=JITTER_S)
    db2.seed("7", "Old headline")
    layer2.get("7")
    ttl_at_fill = cache2.remaining(layer2.key("7"))
    clock2.advance(0.3)
    remaining_at_crash = cache2.remaining(layer2.key("7"))
    layer2.update_db_only("7", title="New headline")
    stale = layer2.get("7")
    loads_while_waiting = db2.loads
    clock2.advance(remaining_at_crash)
    fresh = layer2.get("7")
    stale_window = {
        "ttl_s": TTL_S,
        "jitter_s": JITTER_S,
        "declared_max_stale_s": _round(layer2.max_ttl_s()),
        "ttl_at_fill_s": _round(ttl_at_fill),
        "remaining_at_crash_s": _round(remaining_at_crash),
        "title_while_waiting": stale["title"] if stale else None,
        "loads_while_waiting": loads_while_waiting,
        "title_after_expire": fresh["title"] if fresh else None,
        "loads_after_expire": db2.loads,
        "stale_lasted_s": _round(remaining_at_crash),
        "within_declared_bound": remaining_at_crash <= layer2.max_ttl_s() + 1e-9,
    }
    return {
        "ttl_s": TTL_S,
        "after_miss": after_miss,
        "after_hit": after_hit,
        "after_expire": after_expire,
        "after_invalidate": after_invalidate,
        "stale_window": stale_window,
    }


def _burst_get(layer: CacheAside, article_id: str, n: int) -> list[Optional[dict[str, Any]]]:
    out: list[Optional[dict[str, Any]]] = [None] * n
    barrier = threading.Barrier(n)

    def worker(i: int) -> None:
        barrier.wait(timeout=10)
        out[i] = layer.get(article_id)

    with ThreadPoolExecutor(max_workers=n) as pool:
        futs = [pool.submit(worker, i) for i in range(n)]
        for f in as_completed(futs):
            f.result()
    return out


def stampede() -> dict[str, Any]:
    def run(safe: bool) -> dict[str, Any]:
        clock = Clock(start=0.0, live=True)
        db, cache, layer = _layer(
            safe=safe,
            clock=clock,
            load_s=LOAD_S,
            ttl_s=TTL_S,
            jitter_s=0.0,
        )
        db.seed("42", "Weekly digest")
        # Warm the cache, then expire it by deleting so every request misses together.
        layer.get("42")
        cache.delete(layer.key("42"))
        db.reset_counters()
        cache.reset_stats()
        t0 = time.perf_counter()
        rows = _burst_get(layer, "42", CONCURRENT)
        elapsed = time.perf_counter() - t0
        titles = {r["title"] if r else None for r in rows}
        return {
            "concurrent": CONCURRENT,
            "loads": db.loads,
            "unique_titles": sorted(titles),
            "elapsed_s": _round(elapsed),
            "hits": cache.hits,
            "misses": cache.misses,
            "stale_fills_aborted": layer.stale_fills_aborted,
        }

    naive = run(False)
    safe = run(True)
    return {"naive": naive, "safe": safe, "load_s": LOAD_S}


def avalanche() -> dict[str, Any]:
    def run(safe: bool) -> dict[str, Any]:
        clock = Clock(start=0.0, live=False)
        jitter = JITTER_S if safe else 0.0
        db, cache, layer = _layer(
            safe=safe,
            clock=clock,
            load_s=0.0,
            ttl_s=AVALANCHE_TTL_S,
            jitter_s=jitter,
            seed=42,
        )
        ids = [str(i) for i in range(ARTICLE_COUNT)]
        for i in ids:
            db.seed(i, f"Article {i}")
            layer.get(i)
        db.reset_counters()

        expire_times = [cache.expire_at(layer.key(i)) or 0.0 for i in ids]
        # Walk time in fixed steps and issue a get for every article at each step.
        step = AVALANCHE_STEP_S
        horizon = AVALANCHE_TTL_S + jitter + step
        steps: list[dict[str, Any]] = []
        peak = 0
        peak_t = 0.0
        t = 0.0
        while t < horizon - 1e-12:
            clock.advance(step)
            t = _round(clock.now(), 4)
            before = db.loads
            for i in ids:
                layer.get(i)
            loads = db.loads - before
            steps.append({"t": t, "loads": loads})
            if loads > peak:
                peak = loads
                peak_t = t

        # Also report expiration histogram in the same buckets (before reload).
        # expire_times were captured before the walk.
        buckets: dict[str, int] = {}
        for exp in expire_times:
            bucket = round((int(exp / step) * step) + step, 4)  # first step at which now >= expire
            buckets[f"{bucket:.2f}"] = buckets.get(f"{bucket:.2f}", 0) + 1

        return {
            "articles": ARTICLE_COUNT,
            "ttl_s": AVALANCHE_TTL_S,
            "jitter_s": jitter,
            "step_s": step,
            "expire_min_s": _round(min(expire_times)),
            "expire_max_s": _round(max(expire_times)),
            "expire_span_s": _round(max(expire_times) - min(expire_times)),
            "peak_loads": peak,
            "peak_t": peak_t,
            "total_reloads": db.loads,
            "steps_with_loads": [s for s in steps if s["loads"] > 0],
            "expire_buckets": dict(sorted(buckets.items(), key=lambda kv: float(kv[0]))),
        }

    naive = run(False)
    safe = run(True)
    return {"naive": naive, "safe": safe}


def negative_cache() -> dict[str, Any]:
    def run(safe: bool) -> dict[str, Any]:
        clock = Clock(start=0.0, live=True)
        db, cache, layer = _layer(
            safe=safe,
            clock=clock,
            load_s=LOAD_S,
            ttl_s=TTL_S,
            jitter_s=0.0,
            negative_ttl_s=NEGATIVE_TTL_S if safe else None,
        )
        # 50 concurrent reads of a missing id.
        burst_n = 50
        db.reset_counters()
        rows = _burst_get(layer, "999", burst_n)
        after_burst = {
            "requests": burst_n,
            "loads": db.loads,
            "all_none": all(r is None for r in rows),
            "negative_cached": cache.get(layer.key("999")).found and cache.get(layer.key("999")).negative,
            "remaining_s": _round(cache.remaining(layer.key("999"))),
        }
        # 20 more sequential reads while the (possible) negative entry is still live.
        extra = 20
        for _ in range(extra):
            layer.get("999")
        after_extra = {
            "extra_requests": extra,
            "loads": db.loads,
        }
        return {"after_burst": after_burst, "after_extra": after_extra, "negative_ttl_s": NEGATIVE_TTL_S if safe else None}

    naive = run(False)
    safe = run(True)
    # Frozen-clock expiry of a negative entry on the safe path.
    clock = Clock(start=0.0, live=False)
    db, cache, layer = _layer(
        safe=True,
        clock=clock,
        load_s=0.0,
        ttl_s=TTL_S,
        jitter_s=0.0,
        negative_ttl_s=NEGATIVE_TTL_S,
    )
    layer.get("999")
    loads_on_first = db.loads
    clock.advance(NEGATIVE_TTL_S / 2)
    layer.get("999")
    loads_mid = db.loads
    clock.advance(NEGATIVE_TTL_S / 2)
    remaining = cache.remaining(layer.key("999"))
    layer.get("999")
    loads_after = db.loads
    safe["after_negative_ttl"] = {
        "loads_on_first": loads_on_first,
        "loads_mid_window": loads_mid,
        "remaining_at_boundary": remaining,
        "loads_after_expire": loads_after,
    }
    return {"naive": naive, "safe": safe, "burst": 50, "extra": 20}


def update_races() -> dict[str, Any]:
    def stale_fill(safe: bool) -> dict[str, Any]:
        clock = Clock(start=0.0, live=True)
        db, cache, layer = _layer(
            safe=safe,
            clock=clock,
            load_s=RACE_LOAD_S,
            ttl_s=TTL_S,
            jitter_s=0.0,
        )
        db.seed("42", "draft v1", status="draft")
        loaded = threading.Event()
        resume = threading.Event()

        def hook(_article_id: str, _row: Optional[dict[str, Any]]) -> None:
            loaded.set()
            if not resume.wait(timeout=5):
                raise TimeoutError("stale-fill resume timed out")

        db.before_return = hook
        result: dict[str, Any] = {}

        def reader() -> None:
            result["loader_saw"] = layer.get("42")

        t = threading.Thread(target=reader)
        t.start()
        if not loaded.wait(timeout=5):
            raise TimeoutError("loader did not reach primary")
        db.before_return = None
        updated = layer.update("42", title="published v2", status="published")
        resume.set()
        t.join(timeout=5)
        # A later reader: naive has been planted with v1; safe refused the fill.
        later = layer.get("42")
        db_now = db.snapshot("42")
        return {
            "loader_saw": (result.get("loader_saw") or {}).get("title"),
            "updated_to": updated["title"],
            "later_title": (later or {}).get("title"),
            "db_title": (db_now or {}).get("title"),
            "stale_after": later is not None and later["title"] != db_now["title"],
            "stale_fills_aborted": layer.stale_fills_aborted,
            "loads": db.loads,
        }

    def delayed_double_delete() -> dict[str, Any]:
        """Second DEL happens, then the in-flight loader writes v1. Still stale."""
        clock = Clock(start=0.0, live=True)
        # Intentionally naive: no generation guard, no singleflight.
        db, cache, layer = _layer(
            safe=False,
            clock=clock,
            load_s=0.0,
            ttl_s=TTL_S,
            jitter_s=0.0,
        )
        db.seed("42", "draft v1", status="draft")
        loaded = threading.Event()
        resume = threading.Event()

        def hook(_article_id: str, _row: Optional[dict[str, Any]]) -> None:
            loaded.set()
            if not resume.wait(timeout=5):
                raise TimeoutError("double-delete resume timed out")

        layer.after_load = hook
        result: dict[str, Any] = {}

        def reader() -> None:
            result["loader_saw"] = layer.get("42")

        t = threading.Thread(target=reader)
        t.start()
        if not loaded.wait(timeout=5):
            raise TimeoutError("loader did not finish primary read")
        # Writer: update, DEL, wait, DEL again. The delayed second delete
        # runs to completion *before* the loader is allowed to SET.
        updated = layer.delayed_double_delete(
            "42", DOUBLE_DELETE_DELAY_S, title="published v2", status="published"
        )
        resume.set()
        t.join(timeout=5)
        later = layer.get("42")
        db_now = db.snapshot("42")
        return {
            "delay_s": DOUBLE_DELETE_DELAY_S,
            "loader_saw": (result.get("loader_saw") or {}).get("title"),
            "updated_to": updated["title"],
            "later_title": (later or {}).get("title"),
            "db_title": (db_now or {}).get("title"),
            "stale_after_second_delete": later is not None and later["title"] != db_now["title"],
            "loads": db.loads,
        }

    return {
        "naive_stale_fill": stale_fill(False),
        "safe_generation_guard": stale_fill(True),
        "delayed_double_delete": delayed_double_delete(),
    }


def run_all_experiments() -> dict[str, Any]:
    return {
        "model": "teaching CacheEngine (not Redis)",
        "ttl_s": TTL_S,
        "jitter_s": JITTER_S,
        "negative_ttl_s": NEGATIVE_TTL_S,
        "load_s": LOAD_S,
        "concurrent": CONCURRENT,
        "article_count": ARTICLE_COUNT,
        "cache_aside_and_ttl": cache_aside_and_ttl(),
        "stampede": stampede(),
        "avalanche": avalanche(),
        "negative_cache": negative_cache(),
        "update_races": update_races(),
    }


if __name__ == "__main__":
    data = run_all_experiments()
    stamp = data["stampede"]
    ava = data["avalanche"]
    print(
        "stampede "
        f"naive={stamp['naive']['loads']} safe={stamp['safe']['loads']}"
    )
    print(
        "avalanche "
        f"naive_peak={ava['naive']['peak_loads']} safe_peak={ava['safe']['peak_loads']} "
        f"span={ava['safe']['expire_span_s']}"
    )
