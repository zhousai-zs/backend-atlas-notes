#!/usr/bin/env python3
"""Contract oracle for the length-prefixed frame. Not a C++ fuzzer run."""
from __future__ import annotations

def contract_accepts(buf: bytes) -> bool:
    if len(buf) < 2:
        return False
    n = (buf[0] << 8) | buf[1]
    return len(buf) >= 2 + n

def contract_payload(buf: bytes) -> bytes | None:
    if not contract_accepts(buf):
        return None
    n = (buf[0] << 8) | buf[1]
    return buf[2:2+n]
