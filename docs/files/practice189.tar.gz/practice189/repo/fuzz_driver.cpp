// Compiled, deterministic mutation driver. This is NOT LLVM libFuzzer.
// It calls the same LLVMFuzzerTestOneInput entry the official harness uses.
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size);

static int g_inputs = 0;

static void feed(const uint8_t *data, size_t size) {
  g_inputs++;
  LLVMFuzzerTestOneInput(data, size);
}

static void feed_vec(const std::vector<uint8_t>& v) { feed(v.data(), v.size()); }

static std::vector<uint8_t> read_all(const fs::path& p) {
  std::ifstream in(p, std::ios::binary);
  return std::vector<uint8_t>((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
}

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cerr << "usage: fuzz_driver CORPUS_DIR\n";
    return 2;
  }
  const fs::path corpus(argv[1]);
  std::vector<std::vector<uint8_t>> seeds;
  if (fs::is_regular_file(corpus)) {
    seeds.push_back(read_all(corpus));
  } else {
    for (const auto& ent : fs::directory_iterator(corpus)) {
      if (ent.is_regular_file()) seeds.push_back(read_all(ent.path()));
    }
  }
  if (seeds.empty()) {
    std::cerr << "no seeds\n";
    return 2;
  }
  for (const auto& s : seeds) {
    feed_vec(s);
    // Deterministic mutations of each seed (reproducible, not libFuzzer coverage).
    if (!s.empty()) {
      auto flip = s;
      flip[0] ^= 0xff;
      feed_vec(flip);
      auto last = s;
      last.back() ^= 0x01;
      feed_vec(last);
    }
    if (s.size() >= 2) {
      auto claim_big = s;
      claim_big[0] = 0x00;
      claim_big[1] = 0x40;  // claim 64 payload bytes regardless of actual size
      feed_vec(claim_big);
    }
    auto truncated = s;
    if (truncated.size() > 1) {
      truncated.resize(truncated.size() - 1);
      feed_vec(truncated);
    }
    std::vector<uint8_t> empty;
    feed_vec(empty);
    std::vector<uint8_t> header_only{0x00, 0x10};
    feed_vec(header_only);
  }
  std::cout << "inputs=" << g_inputs << " seeds=" << seeds.size() << "\n";
  return 0;
}
