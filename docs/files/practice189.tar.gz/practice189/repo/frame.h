#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

// Length-prefixed frame: 2-byte big-endian length, then exactly N payload bytes.
// Contract: if the buffer is shorter than 2+N bytes, parse must fail and must
// not read past the input. This is a teaching parser, not a production codec.

struct Frame {
  std::vector<uint8_t> payload;
};

inline bool parse_frame(const uint8_t* data, size_t size, Frame* out, char* err, size_t errlen) {
  if (size < 2) {
    std::snprintf(err, errlen, "truncated header");
    return false;
  }
  uint16_t n = (uint16_t(data[0]) << 8) | data[1];
  // BUG: the implementation trusts n without checking size >= 2+n, then memcpy.
  // A contract-based test / fuzzer should catch this; tests must not use the
  // implementation's own (wrong) output as the oracle.
  if (/* intended check is: size < static_cast<size_t>(2 + n) */ false) {
    std::snprintf(err, errlen, "truncated payload");
    return false;
  }
  out->payload.assign(data + 2, data + 2 + n);
  return true;
}
