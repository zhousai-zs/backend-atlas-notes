// libFuzzer entry written by the (scripted) agent. Requires Clang with
// -fsanitize=fuzzer,address. This file is the harness; it is not itself a passing run.
#include "frame.h"
#include <cstddef>
#include <cstdint>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
  Frame fr;
  char err[64];
  // The contract, not the implementation, is the oracle: if we accept a frame,
  // the declared length must fit in the input.
  bool ok = parse_frame(data, size, &fr, err, sizeof(err));
  if (ok) {
    if (size < 2) return 0;
    uint16_t n = (uint16_t(data[0]) << 8) | data[1];
    if (size < static_cast<size_t>(2 + n)) {
      // Implementation accepted a truncated frame: this is a contract violation.
      __builtin_trap();
    }
    if (fr.payload.size() != n) {
      __builtin_trap();
    }
  }
  return 0;
}
