#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["contract_rejects_seed"] and r["buggy_impl_would_overread"]
assert r["harness_has_llvmfuzzer_entry"] and r["harness_uses_contract_trap"]
assert Path(r["seed_path"]).is_file()
if not r["libfuzzer_ran"]:
    assert any("libFuzzer" in x for x in r["not_verified_on_this_machine"])
print("POSTCHECK_OK")
PY
