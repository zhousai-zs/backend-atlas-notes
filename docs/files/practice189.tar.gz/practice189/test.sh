#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:$PWD/tools:${PATH:-}"
unset OPENAI_API_KEY || true
./tools/zig-c++ --version | head -3
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["contract_rejects_seed"] and r["harness_has_llvmfuzzer_entry"]
assert r["asan_caught_truncated_seed"] and r["fixed_seed_clean"] and r["fixed_campaign_clean"]
assert r["libfuzzer_link_attempted"] is True
if not r["libfuzzer_linked"]:
    assert r["driver_is_not_libfuzzer"] is True
    assert any("libFuzzer" in x for x in r["not_verified_on_this_machine"])
print("POSTCHECK_OK")
PY
