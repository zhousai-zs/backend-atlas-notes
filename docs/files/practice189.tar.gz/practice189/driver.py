#!/usr/bin/env python3
"""Agent-authored libFuzzer harness + contract oracle for a length-prefixed frame.

Tests do not use the current (buggy) implementation output as the sole oracle.
The documented libFuzzer command is invoked if the toolchain exists; otherwise
the miss is recorded. A crashing seed is saved for regression.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "repo"))
from contract_test import contract_accepts, contract_payload  # noqa: E402

WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
shutil.copytree(ROOT / "repo", WORK / "repo")
shutil.copytree(ROOT / "corpus", WORK / "corpus")

seed = (ROOT / "corpus/truncated_len16.bin").read_bytes()
assert seed == b"\x00\x10A"
assert contract_accepts(seed) is False
assert contract_payload(seed) is None

# A well-formed frame is accepted by the contract.
good = bytes([0x00, 0x02, 0x61, 0x62])
assert contract_accepts(good) is True and contract_payload(good) == b"ab"

# Demonstrate that using the implementation as an oracle would be wrong:
# we emulate the buggy C++ parse in Python to show it *accepts* the truncated seed.
def buggy_parse(buf: bytes) -> bytes | None:
    if len(buf) < 2:
        return None
    n = (buf[0] << 8) | buf[1]
    # same bug: no bounds check (Python will raise if we slice blindly past? actually slice is safe)
    # emulate C++ memcpy past the buffer by recording that it *would* read 2+n bytes.
    return {"accepted": True, "would_read": 2 + n, "available": len(buf)}

buggy = buggy_parse(seed)
assert buggy["accepted"] is True and buggy["would_read"] > buggy["available"]
# The test oracle is the contract, so this seed is a failing input, not a "passing" one.

# Save the seed as a regression corpus entry (already in corpus/).
seed_path = WORK / "corpus/truncated_len16.bin"

# Invoke the official-style libFuzzer build/run if clang++ exists.
clangxx = shutil.which("clang++")
fuzz_run = {"which_clangxx": clangxx, "ran": False, "returncode": None, "stdout_tail": "", "stderr_tail": "", "argv": None}
if clangxx:
    out = WORK / "fuzz_frame"
    argv = [clangxx, "-std=c++17", "-fsanitize=fuzzer,address", "-I", str(WORK / "repo"), str(WORK / "repo/fuzz_frame.cpp"), "-o", str(out)]
    p = subprocess.run(argv, text=True, capture_output=True, timeout=60)
    fuzz_run["argv"] = argv
    if p.returncode == 0:
        p2 = subprocess.run([str(out), str(WORK / "corpus"), "-runs=100"], text=True, capture_output=True, timeout=60)
        fuzz_run.update({"ran": True, "returncode": p2.returncode, "stdout_tail": (p2.stdout or "")[-2000:], "stderr_tail": (p2.stderr or "")[-2000:]})
    else:
        fuzz_run.update({"ran": False, "returncode": p.returncode, "stdout_tail": (p.stdout or "")[-2000:], "stderr_tail": (p.stderr or "")[-2000:], "compile_failed": True})

harness = (ROOT / "repo/fuzz_frame.cpp").read_text(encoding="utf-8")
results = {
    "lesson": 189,
    "id": "m-tests",
    "is_live_model": False,
    "scripted_agent_is_not_an_llm": True,
    "oracle": "protocol contract (length prefix must fit), not the implementation output",
    "seed_path": "corpus/truncated_len16.bin",
    "seed_hex": seed.hex(),
    "contract_rejects_seed": contract_accepts(seed) is False,
    "buggy_impl_would_overread": buggy["would_read"] > buggy["available"],
    "harness_has_llvmfuzzer_entry": "LLVMFuzzerTestOneInput" in harness,
    "harness_uses_contract_trap": "__builtin_trap" in harness and "size < static_cast<size_t>(2 + n)" in harness,
    "fuzz": fuzz_run,
    "libfuzzer_ran": bool(fuzz_run["ran"]),
    "verified_on_this_machine": [
        "contract oracle rejects the truncated seed",
        "buggy parser would read past the input",
        "libFuzzer harness source with LLVMFuzzerTestOneInput is present and uses the contract as the oracle",
        "seed saved under corpus/truncated_len16.bin",
    ],
    "not_verified_on_this_machine": [],
}
if not fuzz_run["ran"]:
    results["not_verified_on_this_machine"].append(
        "libFuzzer compile and run (clang++ with -fsanitize=fuzzer not available or compile failed; the harness and seed are still provided for reproduction)"
    )

if not (results["contract_rejects_seed"] and results["buggy_impl_would_overread"] and results["harness_has_llvmfuzzer_entry"]):
    raise SystemExit("189 checks failed")

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
(REPORTS / "seed.hex").write_text(seed.hex())
print("SEED", seed.hex())
print("CONTRACT_REJECTS", results["contract_rejects_seed"])
print("FUZZ", fuzz_run)
print("ALL_CHECKS_PASSED")
