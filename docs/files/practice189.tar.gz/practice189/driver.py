#!/usr/bin/env python3
"""Revise 189: compile the frame parser and catch the length bug with ASan.

zig c++ -fsanitize=fuzzer is attempted and recorded. If it cannot link LLVM
libFuzzer, a compiled deterministic mutation driver (not libFuzzer) is used.
The same seed must fail on the buggy parser and pass after the bounds check.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
CMVENVbin = Path("/workspace/atlas/cmvenv/bin")
os.environ["PATH"] = f"{CMVENVbin}:{ROOT / 'tools'}:{os.environ.get('PATH', '')}"
os.environ["CXX"] = str(ROOT / "tools/zig-c++")
os.environ["CC"] = str(ROOT / "tools/zig-cc")
os.environ.setdefault("ZIG_LOCAL_CACHE_DIR", str(ROOT / ".zig-cache"))
os.environ.setdefault("ZIG_GLOBAL_CACHE_DIR", str(ROOT / ".zig-cache"))

sys.path.insert(0, str(ROOT / "repo"))
from contract_test import contract_accepts, contract_payload  # noqa: E402

WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
shutil.copytree(ROOT / "repo", WORK / "repo")
shutil.copytree(ROOT / "corpus", WORK / "corpus")
REPO = WORK / "repo"
CXX = os.environ["CXX"]
ASAN = "/usr/lib/x86_64-linux-gnu/libasan.so.8"
FLAGS = ["-std=c++17", "-g", "-O1", "-fno-omit-frame-pointer", "-target", "x86_64-linux-gnu", "-I", str(REPO)]

def which(name: str) -> str:
    p = shutil.which(name)
    if not p:
        raise FileNotFoundError(f"{name} not found after inventory of PATH={os.environ['PATH']}")
    return p

def run(argv, env=None, timeout=180, cwd=None) -> subprocess.CompletedProcess:
    return subprocess.run(argv, cwd=cwd or ROOT, text=True, capture_output=True, timeout=timeout, env=env)

py = str(CMVENVbin / "python")
zig_ver = run([py, "-m", "ziglang", "version"]).stdout.strip()
cxx_ver = "\n".join(run([CXX, "--version"]).stdout.splitlines()[:3])

seed = (ROOT / "corpus/truncated_len16.bin").read_bytes()
assert seed == b"\x00\x10A"
assert contract_accepts(seed) is False
assert contract_payload(seed) is None
good = bytes([0x00, 0x02, 0x61, 0x62])
assert contract_accepts(good) is True and contract_payload(good) == b"ab"

# Attempt official-style libFuzzer link (expected to fail with this zig port).
fuzz_bin = WORK / "fuzz_libfuzzer"
fuzz_attempt = run([CXX, *FLAGS, "-fsanitize=fuzzer,address", str(REPO / "fuzz_frame.cpp"), ASAN, "-o", str(fuzz_bin)])
(REPORTS / "libfuzzer-link.txt").write_text((fuzz_attempt.stdout or "") + (fuzz_attempt.stderr or ""), encoding="utf-8")
libfuzzer_linked = fuzz_attempt.returncode == 0 and fuzz_bin.exists()

# Compiled mutation driver + ASan (NOT libFuzzer).
driver_bad = WORK / "fuzz_driver_bad"
link_driver = run([
    CXX, *FLAGS, "-fsanitize=address",
    str(REPO / "fuzz_frame.cpp"), str(REPO / "fuzz_driver.cpp"),
    ASAN, "-o", str(driver_bad),
])
(REPORTS / "driver-link-bad.txt").write_text((link_driver.stdout or "") + (link_driver.stderr or ""), encoding="utf-8")
if link_driver.returncode != 0:
    raise SystemExit(f"mutation driver failed to link:\n{link_driver.stderr}")

env_asan = {**os.environ, "ASAN_OPTIONS": "detect_leaks=0:halt_on_error=1:abort_on_error=1"}
# First: just the truncated seed as a single file, so the catch is reproducible.
seed_run = run([str(driver_bad), str(WORK / "corpus/truncated_len16.bin")], env=env_asan)
(REPORTS / "driver-bad-seed.txt").write_text((seed_run.stdout or "") + (seed_run.stderr or ""), encoding="utf-8")
seed_log = (REPORTS / "driver-bad-seed.txt").read_text(encoding="utf-8")
caught = seed_run.returncode != 0 and (
    "ERROR: AddressSanitizer" in seed_log or "heap-buffer-overflow" in seed_log
    or "stack-buffer-overflow" in seed_log or "SEGV" in seed_log or "trap" in seed_log.lower()
    or seed_run.returncode < 0  # signal
)
# Also run the mutation campaign on the whole corpus (should also trip).
camp = run([str(driver_bad), str(WORK / "corpus")], env=env_asan)
(REPORTS / "driver-bad-corpus.txt").write_text((camp.stdout or "") + (camp.stderr or ""), encoding="utf-8")
if not caught:
    raise SystemExit(f"compiled driver+ASan did not catch the truncated seed:\n{seed_log}")

# Fix the bounds check in the working copy.
frame = (REPO / "frame.h").read_text(encoding="utf-8")
frame = frame.replace(
    "if (/* intended check is: size < static_cast<size_t>(2 + n) */ false)",
    "if (size < static_cast<size_t>(2) + static_cast<size_t>(n))",
)
(REPO / "frame.h").write_text(frame, encoding="utf-8")
if "if (size < static_cast<size_t>(2) + static_cast<size_t>(n))" not in (REPO / "frame.h").read_text():
    raise SystemExit("failed to apply the bounds-check fix")

driver_ok = WORK / "fuzz_driver_fixed"
link_ok = run([
    CXX, *FLAGS, "-fsanitize=address",
    str(REPO / "fuzz_frame.cpp"), str(REPO / "fuzz_driver.cpp"),
    ASAN, "-o", str(driver_ok),
])
if link_ok.returncode != 0:
    raise SystemExit(f"fixed driver failed to link:\n{link_ok.stderr}")
fixed_seed = run([str(driver_ok), str(WORK / "corpus/truncated_len16.bin")], env=env_asan)
(REPORTS / "driver-fixed-seed.txt").write_text((fixed_seed.stdout or "") + (fixed_seed.stderr or ""), encoding="utf-8")
fixed_log = (REPORTS / "driver-fixed-seed.txt").read_text(encoding="utf-8")
if fixed_seed.returncode != 0 or "ERROR: AddressSanitizer" in fixed_log:
    raise SystemExit(f"fixed parser still fails the seed under ASan:\n{fixed_log}")
fixed_camp = run([str(driver_ok), str(WORK / "corpus")], env=env_asan)
(REPORTS / "driver-fixed-corpus.txt").write_text((fixed_camp.stdout or "") + (fixed_camp.stderr or ""), encoding="utf-8")
camp_log = (REPORTS / "driver-fixed-corpus.txt").read_text(encoding="utf-8")
if fixed_camp.returncode != 0 or "ERROR: AddressSanitizer" in camp_log:
    raise SystemExit(f"fixed parser still fails the mutation campaign:\n{camp_log}")

harness = (ROOT / "repo/fuzz_frame.cpp").read_text(encoding="utf-8")
results = {
    "lesson": 189,
    "id": "m-tests",
    "is_live_model": False,
    "scripted_agent_is_not_an_llm": True,
    "toolchain": {
        "cxx": CXX,
        "ziglang": zig_ver,
        "cxx_version_head": cxx_ver,
        "libasan": ASAN,
        "inventoried_before_claiming_missing": True,
    },
    "oracle": "protocol contract (length prefix must fit), not the implementation output",
    "seed_path": "corpus/truncated_len16.bin",
    "seed_hex": seed.hex(),
    "contract_rejects_seed": True,
    "harness_has_llvmfuzzer_entry": "LLVMFuzzerTestOneInput" in harness,
    "libfuzzer_link_attempted": True,
    "libfuzzer_linked": libfuzzer_linked,
    "is_libfuzzer": bool(libfuzzer_linked),
    "compiled_mutation_driver_used": True,
    "driver_is_not_libfuzzer": not libfuzzer_linked,
    "asan_caught_truncated_seed": caught,
    "asan_bad_returncode": seed_run.returncode,
    "fixed_seed_clean": True,
    "fixed_campaign_clean": True,
    "verified_on_this_machine": [
        "contract oracle rejects corpus/truncated_len16.bin",
        "compiled ASan mutation driver (not libFuzzer) caught the over-read on that seed",
        "after adding the 2+n bounds check, the same seed and mutation campaign ran clean under ASan",
    ],
    "not_verified_on_this_machine": [],
}
if libfuzzer_linked:
    results["verified_on_this_machine"].append("zig c++ -fsanitize=fuzzer linked on this machine")
else:
    results["not_verified_on_this_machine"].append(
        "LLVM libFuzzer / zig c++ -fsanitize=fuzzer did not link (see reports/libfuzzer-link.txt); "
        "the catching tool is a compiled deterministic mutation driver plus ASan, which is not libFuzzer"
    )

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("LIBFUZZER_LINKED", libfuzzer_linked)
print("ASAN_CAUGHT", caught, "rc", seed_run.returncode)
print("FIXED_CLEAN", True)
print("ALL_CHECKS_PASSED")
