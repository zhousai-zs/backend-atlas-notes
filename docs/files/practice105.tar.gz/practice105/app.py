#!/usr/bin/env python3
"""Experiments for lesson 105: write-ahead log and crash recovery."""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import threading
import time
from typing import Any

from engine import (
    Crash,
    WALEngine,
    apply_records,
    forged_tail_record,
    parse_naive,
    parse_safe,
    recover_image,
)


N_SEED = 10
N_ACK = 20
N_GROUP = 200
N_THREADS = 4
DOCS_CHECKED = "2026-11-12"
ROCKSDB_DOCS = (
    "https://github.com/facebook/rocksdb/wiki/Write-Ahead-Log-%28WAL%29"
    " (301 -> https://github.com/meta/rocksdb/wiki/Write-Ahead-Log-%28WAL%29, 200); "
    "https://github.com/facebook/rocksdb/wiki/Write-Ahead-Log-File-Format"
    " (301 -> wiki/Write-Ahead-Log-File-Format, 200); "
    "https://github.com/facebook/rocksdb/wiki/WAL-Recovery-Modes"
    " (301 -> wiki/WAL-Recovery-Modes, 200); "
    "https://github.com/facebook/rocksdb/wiki/WAL-Performance"
    " (301 -> wiki/WAL-Performance, 200)"
)


def _fresh(prefix: str, **kwargs: Any) -> tuple[str, WALEngine]:
    data_dir = tempfile.mkdtemp(prefix=f"practice105-{prefix}-")
    return data_dir, WALEngine(data_dir, **kwargs)


def _cleanup(paths: list[str]) -> None:
    for path in paths:
        shutil.rmtree(path, ignore_errors=True)


def _seed(engine: WALEngine, n: int = N_SEED, prefix: str = "article") -> None:
    for i in range(1, n + 1):
        engine.set(f"{prefix}:{i:02d}:title", f"draft-{i:02d}")


def experiment_commit_point() -> dict[str, Any]:
    """Log order and commit point: WAL first, then memtable; crash at each stage."""
    dirs: list[str] = []
    out: dict[str, Any] = {"seed": N_SEED}
    try:
        stages = [
            "before_write",
            "partial_header",
            "partial_payload",
            "written_not_fsynced",
            "fsynced_not_applied",
        ]
        for stage in stages:
            data_dir, engine = _fresh(f"commit-{stage}", sync=True)
            dirs.append(data_dir)
            _seed(engine)
            acked_before = list(engine.acked)
            crashed = False
            try:
                engine.set("article:11:title", "published-11", crash_after=stage)
            except Crash as exc:
                crashed = True
                assert exc.stage == stage
            # Power loss: only the durable image survives.
            image = engine.crash(kind="power_loss")
            recovered = engine.recover(image["image"], parser="safe")
            has_11 = "article:11:title" in recovered["data"]
            out[stage] = {
                "crashed": crashed,
                "acked_before": len(acked_before),
                "acked_after_attempt": len(engine.acked),
                "recovered_keys": recovered["keys"],
                "has_article_11": has_11,
                "article_11": recovered["data"].get("article:11:title"),
                "truncated": recovered["truncated"],
                "reason": recovered["reason"],
                "records": recovered["records"],
            }

        # Anti-pattern: apply memtable first, then fail before the log is written.
        # The client was already told "ok", but recovery cannot find the write.
        data_dir, engine = _fresh("apply-first", sync=True)
        dirs.append(data_dir)
        _seed(engine)
        engine.memtable["article:11:title"] = "published-11"
        engine.acked.append(engine.seq + 1)  # lied about the commit
        image = engine.crash(kind="power_loss")
        recovered = engine.recover(image["image"], parser="safe")
        out["apply_first_then_crash"] = {
            "acked": True,
            "memtable_had_11_before_crash": "article:11:title" in image["memtable_before"],
            "recovered_has_11": "article:11:title" in recovered["data"],
            "lost_acked": "article:11:title" not in recovered["data"],
            "recovered_keys": recovered["keys"],
        }
        return out
    finally:
        _cleanup(dirs)


def experiment_truncation() -> dict[str, Any]:
    """Length + checksum: a torn or checksum-failed tail is not a valid commit."""
    dirs: list[str] = []
    try:
        out: dict[str, Any] = {}

        # Partial header / partial payload at the tail.
        for stage in ("partial_header", "partial_payload"):
            data_dir, engine = _fresh(f"trunc-{stage}", sync=True)
            dirs.append(data_dir)
            _seed(engine)
            try:
                engine.set("article:11:title", "published-11", crash_after=stage)
            except Crash:
                pass
            image = engine.crash(kind="power_loss")
            safe = recover_image(image["image"], parser="safe")
            naive = recover_image(image["image"], parser="naive")
            out[stage] = {
                "safe_records": safe["records"],
                "safe_truncated": safe["truncated"],
                "safe_reason": safe["reason"],
                "safe_has_11": "article:11:title" in safe["data"],
                "safe_tail_bytes": safe["tail_bytes"],
                "naive_records": naive["records"],
                "naive_truncated": naive["truncated"],
                "naive_has_11": "article:11:title" in naive["data"],
                "image_bytes": safe["image_bytes"],
            }

        # Forged tail: a complete-looking record with a wrong checksum.
        data_dir, engine = _fresh("trunc-forged", sync=True)
        dirs.append(data_dir)
        _seed(engine)
        engine.wal.write(forged_tail_record("article:forged:title", "pwned-title"))
        engine.wal.fsync()
        image = engine.wal.durable_bytes()
        safe = recover_image(image, parser="safe")
        naive = recover_image(image, parser="naive")
        out["forged_checksum"] = {
            "safe_records": safe["records"],
            "safe_truncated": safe["truncated"],
            "safe_reason": safe["reason"],
            "safe_has_forged": "article:forged:title" in safe["data"],
            "naive_records": naive["records"],
            "naive_truncated": naive["truncated"],
            "naive_has_forged": "article:forged:title" in naive["data"],
            "naive_forged_value": naive["data"].get("article:forged:title"),
            "image_bytes": len(image),
            "tail_bytes_safe": safe["tail_bytes"],
        }

        # Mid-file corruption followed by a valid record: safe parser stops
        # (point-in-time), and does not skip ahead to accept the later record.
        data_dir, engine = _fresh("trunc-mid", sync=True)
        dirs.append(data_dir)
        for i in range(1, 6):
            engine.set(f"article:{i:02d}:title", f"draft-{i:02d}")
        # Inject a bad record in the middle, then a valid later write directly
        # onto the durable image so both are "on disk".
        engine.wal.write(forged_tail_record("article:xx:title", "junk"))
        rec_later = __import__("engine").encode_record(1, 99, "article:99:title", "later-ok")
        engine.wal.write(rec_later)
        engine.wal.fsync()
        image = engine.wal.durable_bytes()
        safe = recover_image(image, parser="safe")
        naive = recover_image(image, parser="naive")
        out["midfile_then_valid"] = {
            "safe_records": safe["records"],
            "safe_truncated": safe["truncated"],
            "safe_reason": safe["reason"],
            "safe_has_99": "article:99:title" in safe["data"],
            "safe_max_article": max(
                (int(k.split(":")[1]) for k in safe["data"] if k.startswith("article:") and k.split(":")[1].isdigit()),
                default=0,
            ),
            "naive_has_xx": "article:xx:title" in naive["data"],
            "naive_has_99": "article:99:title" in naive["data"],
            "naive_records": naive["records"],
        }
        return out
    finally:
        _cleanup(dirs)


def experiment_ack_vs_fsync() -> dict[str, Any]:
    """Write confirmation must match the fsync policy."""
    dirs: list[str] = []
    out: dict[str, Any] = {"n": N_ACK}
    try:
        cases = [
            ("sync_true_power_loss", True, "power_loss"),
            ("sync_false_power_loss", False, "power_loss"),
            ("sync_false_process_kill", False, "process_kill"),
            ("sync_true_process_kill", True, "process_kill"),
        ]
        for name, sync, kind in cases:
            data_dir, engine = _fresh(name, sync=sync)
            dirs.append(data_dir)
            acked = 0
            durable_acked = 0
            for i in range(1, N_ACK + 1):
                ack = engine.set(f"article:{i:02d}:title", f"title-{i:02d}")
                acked += 1
                if ack.durable:
                    durable_acked += 1
            image = engine.crash(kind=kind)
            recovered = engine.recover(image["image"], parser="safe")
            lost = acked - recovered["records"]
            out[name] = {
                "sync": sync,
                "crash": kind,
                "acked": acked,
                "durable_acked": durable_acked,
                "recovered": recovered["records"],
                "lost_acked": lost,
                "truncated": recovered["truncated"],
            }
        return out
    finally:
        _cleanup(dirs)


def experiment_idempotent_replay() -> dict[str, Any]:
    """Replaying the same log twice, and INCR vs absolute SET against a snapshot."""
    dirs: list[str] = []
    try:
        data_dir, engine = _fresh("replay-set", sync=True)
        dirs.append(data_dir)
        engine.set("article:42:title", "v1")
        engine.set("article:42:title", "v2")
        engine.set("article:42:title", "Weekly digest (revised)")
        engine.delete("article:00:title")  # deleting a missing key is fine
        blob = engine.wal.durable_bytes()
        first = recover_image(blob, parser="safe")
        second = recover_image(blob, parser="safe")
        # Replay onto the already-recovered state (second pass over the same log).
        again = apply_records(parse_safe(blob)["records"], start=first["data"])

        # After a checkpoint, only post-checkpoint records stay in the "new" WAL
        # segment. If the increment was already applied into a newer in-memory
        # snapshot, replaying a naive INCR record doubles the count. Logging
        # the absolute SET does not.
        from engine import parse_safe as _parse_safe

        def _tail_after(blob: bytes, seq_le: int) -> bytes:
            parsed = _parse_safe(blob)
            # Rebuild a log that contains only records with seq > seq_le.
            from engine import encode_record, OP_SET, OP_DEL, OP_INCR
            opmap = {"SET": OP_SET, "DEL": OP_DEL, "INCR": OP_INCR}
            out = bytearray()
            for rec in parsed["records"]:
                if rec["seq"] > seq_le:
                    out.extend(encode_record(opmap[rec["op"]], rec["seq"], rec["key"], rec["value"]))
            return bytes(out)

        data_dir2, eng_naive = _fresh("replay-incr-naive", sync=True)
        dirs.append(data_dir2)
        eng_naive.set("article:42:reads", "5")
        chk_seq = eng_naive.seq
        chk_snap = eng_naive.snapshot()  # 5, checkpoint
        eng_naive.incr("article:42:reads", 1, as_set=False)  # memtable now 6
        applied_snap = eng_naive.snapshot()  # 6, not yet a new checkpoint
        tail = _tail_after(eng_naive.wal.durable_bytes(), chk_seq)
        # Correct recovery: checkpoint 5 + tail INCR -> 6
        naive_correct = recover_image(tail, parser="safe", snapshot=chk_snap)
        # Bug: replay tail onto a snapshot that already applied the INCR.
        naive_double = recover_image(tail, parser="safe", snapshot=applied_snap)
        # Safe skip: ignore records with seq <= the applied snapshot seq.
        naive_skip = recover_image(
            tail, parser="safe", snapshot=applied_snap, skip_seq_le=eng_naive.seq
        )

        data_dir3, eng_safe = _fresh("replay-incr-set", sync=True)
        dirs.append(data_dir3)
        eng_safe.set("article:42:reads", "5")
        chk2_seq = eng_safe.seq
        chk2_snap = eng_safe.snapshot()
        eng_safe.incr("article:42:reads", 1, as_set=True)  # logs SET 6
        applied2 = eng_safe.snapshot()
        tail2 = _tail_after(eng_safe.wal.durable_bytes(), chk2_seq)
        safe_from_chk = recover_image(tail2, parser="safe", snapshot=chk2_snap)
        # Replaying SET 6 onto a snapshot that is already 6 stays 6.
        safe_on_applied = recover_image(tail2, parser="safe", snapshot=applied2)
        return {
            "set_versions": {
                "records": first["records"],
                "first_value": first["data"].get("article:42:title"),
                "second_value": second["data"].get("article:42:title"),
                "replayed_again_value": again.get("article:42:title"),
                "missing_delete_ok": "article:00:title" not in first["data"],
            },
            "naive_incr_on_snapshot": {
                "checkpoint_value": chk_snap.get("article:42:reads"),
                "applied_snapshot_value": applied_snap.get("article:42:reads"),
                "log_records": naive_double["records"],
                "correct_from_checkpoint": naive_correct["data"].get("article:42:reads"),
                "recovered_value": naive_double["data"].get("article:42:reads"),
                "double_counted": naive_double["data"].get("article:42:reads") == "7",
                "skip_seq_value": naive_skip["data"].get("article:42:reads"),
            },
            "safe_incr_as_set": {
                "checkpoint_value": chk2_snap.get("article:42:reads"),
                "applied_snapshot_value": applied2.get("article:42:reads"),
                "log_records": safe_on_applied["records"],
                "from_checkpoint": safe_from_chk["data"].get("article:42:reads"),
                "recovered_value": safe_on_applied["data"].get("article:42:reads"),
                "checkpoint_seq": chk2_seq,
            },
        }
    finally:
        _cleanup(dirs)


def experiment_group_commit() -> dict[str, Any]:
    """Per-write fsync vs opportunistic group commit, with real fsync."""
    dirs: list[str] = []
    out: dict[str, Any] = {"n": N_GROUP, "threads": N_THREADS}
    try:
        for name, grouped in (("per_write", False), ("group", True)):
            data_dir, engine = _fresh(
                f"group-{name}",
                sync=True,
                group_commit=grouped,
                real_fsync=True,
            )
            dirs.append(data_dir)
            per_thread = N_GROUP // N_THREADS
            errors: list[str] = []

            def worker(tid: int) -> None:
                try:
                    for i in range(per_thread):
                        engine.set(f"t{tid}:k:{i}", f"v-{tid}-{i}")
                except Exception as exc:  # noqa: BLE001
                    errors.append(str(exc))

            t0 = time.perf_counter()
            threads = [threading.Thread(target=worker, args=(t,)) for t in range(N_THREADS)]
            for th in threads:
                th.start()
            for th in threads:
                th.join()
            elapsed = time.perf_counter() - t0
            if errors:
                raise RuntimeError(f"{name} errors: {errors[:3]}")
            image = engine.crash(kind="power_loss")
            recovered = engine.recover(image["image"], parser="safe")
            out[name] = {
                "elapsed_s": round(elapsed, 6),
                "per_write_ms": round(elapsed / N_GROUP * 1000, 4),
                "fsync_count": engine.wal.fsync_count,
                "fsync_s": round(engine.wal.fsync_s, 6),
                "recovered": recovered["records"],
                "lost": N_GROUP - recovered["records"],
                "group_batches": engine.group_batches,
                "group_max": engine.group_max,
                "ops_per_s": round(N_GROUP / elapsed, 1) if elapsed else 0.0,
            }
        pw = out["per_write"]
        gc = out["group"]
        out["fsync_ratio"] = round(pw["fsync_count"] / max(1, gc["fsync_count"]), 2)
        out["time_ratio"] = round(pw["elapsed_s"] / gc["elapsed_s"], 2) if gc["elapsed_s"] else 0.0
        return out
    finally:
        _cleanup(dirs)


def run_all_experiments() -> dict[str, Any]:
    return {
        "commit_point": experiment_commit_point(),
        "truncation": experiment_truncation(),
        "ack_vs_fsync": experiment_ack_vs_fsync(),
        "idempotent_replay": experiment_idempotent_replay(),
        "group_commit": experiment_group_commit(),
        "python": "{}.{}.{}".format(*sys.version_info[:3]),
        "rocksdb_docs": ROCKSDB_DOCS,
        "docs_checked": DOCS_CHECKED,
    }


def main() -> None:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(json.dumps({k: data[k] for k in data if k not in {"python", "rocksdb_docs"}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
