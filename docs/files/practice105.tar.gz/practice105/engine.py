#!/usr/bin/env python3
"""Teaching WALEngine — not RocksDB.

A Python standard-library model of a length-plus-checksum KV write-ahead
log: records are appended before the memtable is updated, recovery
identifies complete records, truncates a torn or checksum-failed tail,
and replays idempotently.

This is not RocksDB, not Redis, and not a network server. The log-before-
apply order, the meaning of WriteOptions.sync, group commit, and the
idea of tolerating a corrupted tail follow the RocksDB WAL wiki pages
checked on 2026-11-12, for the subset implemented here. This engine does
not implement RocksDB's 32 KiB block framing, FIRST/MIDDLE/LAST
fragments, recyclable log numbers, column families, MANIFEST, SST
flush, WAL compression, or the four WALRecoveryMode enum values as a
drop-in replica.
"""
from __future__ import annotations

import binascii
import os
import struct
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional


OP_SET = 1
OP_DEL = 2
OP_INCR = 3  # naive increment; replay is not idempotent against a snapshot

# Teaching record (not the RocksDB log format):
#   body_len: uint32  # length of (crc32 + payload)
#   crc32:    uint32  # CRC-32 of payload
#   payload:  op:uint8  seq:uint64  key_len:uint16  key  val_len:uint32  value
HEADER_LEN = 4
CRC_LEN = 4


class Crash(Exception):
    """Raised when a crash is injected at a named write stage."""

    def __init__(self, stage: str) -> None:
        super().__init__(stage)
        self.stage = stage


class Clock:
    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        self.t = round(self.t + float(seconds), 10)


class DurableFile:
    """A file with an explicit page cache and a durable image.

    write() goes to the OS page cache. fsync() commits that cache to the
    durable image (the bytes that survive a machine/power crash). A
    process-only kill leaves the page cache in place. This is a teaching
    model of fsync, not a claim about one filesystem.
    """

    def __init__(self, path: str, real_fsync: bool = False) -> None:
        self.path = path
        self.real_fsync = bool(real_fsync)
        self.durable = bytearray()
        self.cache = bytearray()
        self.fsync_count = 0
        self.fsync_s = 0.0
        self.write_count = 0
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        if self.real_fsync:
            # Start from a fresh file so repeated runs don't append twice.
            open(self.path, "wb").close()

    def write(self, data: bytes) -> None:
        if not data:
            return
        self.cache.extend(data)
        self.write_count += 1
        if self.real_fsync:
            with open(self.path, "ab") as fh:
                fh.write(data)

    def fsync(self) -> None:
        t0 = time.perf_counter()
        if self.cache:
            self.durable.extend(self.cache)
            self.cache.clear()
        if self.real_fsync:
            directory = os.path.dirname(self.path) or "."
            os.makedirs(directory, exist_ok=True)
            with open(self.path, "ab") as fh:
                fh.flush()
                os.fsync(fh.fileno())
        self.fsync_s += time.perf_counter() - t0
        self.fsync_count += 1

    def power_loss(self) -> None:
        self.cache = bytearray()

    def process_kill(self) -> None:
        # Kernel page cache survives a process-only kill.
        pass

    def durable_bytes(self) -> bytes:
        return bytes(self.durable)

    def cached_bytes(self) -> bytes:
        return bytes(self.durable) + bytes(self.cache)

    def size_durable(self) -> int:
        return len(self.durable)

    def size_cached(self) -> int:
        return len(self.durable) + len(self.cache)


def encode_record(op: int, seq: int, key: str, value: str = "") -> bytes:
    key_b = key.encode("utf-8")
    val_b = value.encode("utf-8") if op != OP_DEL else b""
    payload = (
        struct.pack("!BQH", op, int(seq), len(key_b))
        + key_b
        + struct.pack("!I", len(val_b))
        + val_b
    )
    crc = binascii.crc32(payload) & 0xFFFFFFFF
    body = struct.pack("!I", crc) + payload
    return struct.pack("!I", len(body)) + body


def decode_payload(payload: bytes) -> dict[str, Any]:
    op, seq, key_len = struct.unpack_from("!BQH", payload, 0)
    off = 11
    key = payload[off : off + key_len].decode("utf-8")
    off += key_len
    (val_len,) = struct.unpack_from("!I", payload, off)
    off += 4
    value = payload[off : off + val_len].decode("utf-8")
    name = {OP_SET: "SET", OP_DEL: "DEL", OP_INCR: "INCR"}.get(op, f"OP{op}")
    return {"op": name, "op_code": op, "seq": seq, "key": key, "value": value}


def parse_safe(blob: bytes) -> dict[str, Any]:
    """Parse complete, checksum-valid records. A short or bad tail is truncated.

    A checksum mismatch or a length that overruns the file is treated as a
    corrupted tail: the record is not accepted as a commit, and scanning
    stops (teaching analogue of tolerating a torn tail, not mid-file skip).
    """
    records: list[dict[str, Any]] = []
    off = 0
    truncated = False
    reason = ""
    n = len(blob)
    while off < n:
        remaining = n - off
        if remaining < HEADER_LEN:
            truncated = True
            reason = "short_header"
            break
        (body_len,) = struct.unpack_from("!I", blob, off)
        if body_len < CRC_LEN or remaining < HEADER_LEN + body_len:
            truncated = True
            reason = "short_body"
            break
        (crc_stored,) = struct.unpack_from("!I", blob, off + HEADER_LEN)
        payload = blob[off + HEADER_LEN + CRC_LEN : off + HEADER_LEN + body_len]
        crc = binascii.crc32(payload) & 0xFFFFFFFF
        if crc != crc_stored:
            truncated = True
            reason = "bad_checksum"
            break
        try:
            records.append(decode_payload(payload))
        except (struct.error, UnicodeDecodeError, ValueError):
            truncated = True
            reason = "bad_payload"
            break
        off += HEADER_LEN + body_len
    return {
        "records": records,
        "truncated": truncated,
        "reason": reason,
        "consumed": off,
        "tail_bytes": n - off,
    }


def parse_naive(blob: bytes) -> dict[str, Any]:
    """Trust the length field and skip the checksum.

    A torn tail whose length happens to cover leftover bytes, or a
    complete-looking record with a wrong checksum, is accepted as a
    commit. This is the unsafe reader the lab contrasts with parse_safe.
    """
    records: list[dict[str, Any]] = []
    off = 0
    truncated = False
    reason = ""
    n = len(blob)
    while off < n:
        remaining = n - off
        if remaining < HEADER_LEN:
            truncated = True
            reason = "short_header"
            break
        (body_len,) = struct.unpack_from("!I", blob, off)
        if body_len < CRC_LEN or remaining < HEADER_LEN + body_len:
            truncated = True
            reason = "short_body"
            break
        payload = blob[off + HEADER_LEN + CRC_LEN : off + HEADER_LEN + body_len]
        try:
            records.append(decode_payload(payload))
        except (struct.error, UnicodeDecodeError, ValueError):
            truncated = True
            reason = "bad_payload"
            break
        off += HEADER_LEN + body_len
    return {
        "records": records,
        "truncated": truncated,
        "reason": reason,
        "consumed": off,
        "tail_bytes": n - off,
    }


def forged_tail_record(key: str, value: str) -> bytes:
    """A length-framed record with a deliberately wrong checksum."""
    rec = encode_record(OP_SET, 999999, key, value)
    body_len = struct.unpack("!I", rec[:4])[0]
    # Flip the checksum (bytes 4:8) so a safe reader must reject it.
    bad_crc = struct.pack("!I", 0xDEADBEEF)
    return rec[:4] + bad_crc + rec[8:]


def apply_records(
    records: list[dict[str, Any]],
    start: Optional[dict[str, str]] = None,
    skip_seq_le: int = 0,
) -> dict[str, str]:
    """Replay records onto a starting snapshot. SET/DEL are last-write-wins.

    INCR adds int(value) to the current integer (or 0). If the snapshot
    already included that INCR and skip_seq_le does not cover it, the
    count is applied again — the non-idempotent case the lab shows.
    Records with seq <= skip_seq_le are skipped (safe replay past a checkpoint).
    """
    data: dict[str, str] = dict(start or {})
    for rec in records:
        if rec["seq"] <= skip_seq_le:
            continue
        if rec["op_code"] == OP_SET:
            data[rec["key"]] = rec["value"]
        elif rec["op_code"] == OP_DEL:
            data.pop(rec["key"], None)
        elif rec["op_code"] == OP_INCR:
            cur = int(data.get(rec["key"], "0") or "0")
            data[rec["key"]] = str(cur + int(rec["value"] or "1"))
    return data


@dataclass
class Ack:
    ok: bool
    seq: int
    durable: bool
    status: str


class WALEngine:
    """In-process teaching KV with a length-plus-checksum WAL."""

    def __init__(
        self,
        data_dir: str,
        sync: bool = True,
        group_commit: bool = False,
        real_fsync: bool = False,
        clock: Optional[Clock] = None,
    ) -> None:
        os.makedirs(data_dir, exist_ok=True)
        self.data_dir = data_dir
        self.sync = bool(sync)
        self.group_commit = bool(group_commit)
        self.clock = clock or Clock()
        self.wal = DurableFile(os.path.join(data_dir, "wal.log"), real_fsync=real_fsync)
        self.memtable: dict[str, str] = {}
        self.seq = 0
        self.lock = threading.Lock()
        self.acked: list[int] = []
        # Group-commit state (opportunistic: combine writers already waiting).
        self._pending: list[dict[str, Any]] = []
        self._leader_busy = False
        self.group_batches = 0
        self.group_max = 0

    # -- write path -----------------------------------------------------

    def set(self, key: str, value: str, crash_after: Optional[str] = None) -> Ack:
        return self._write(OP_SET, key, value, crash_after=crash_after)

    def delete(self, key: str, crash_after: Optional[str] = None) -> Ack:
        return self._write(OP_DEL, key, "", crash_after=crash_after)

    def incr(self, key: str, delta: int = 1, as_set: bool = True) -> Ack:
        """Atomic increment.

        If as_set is True (safe), the WAL records the resulting absolute
        SET, so replay is idempotent. If as_set is False (naive), the WAL
        records an INCR, which double-counts when replayed on a snapshot
        that already included it.
        """
        with self.lock:
            cur = int(self.memtable.get(key, "0") or "0")
            new = cur + int(delta)
            if as_set:
                rec = self._append(OP_SET, key, str(new), crash_after=None)
                self.memtable[key] = str(new)
                return rec
            rec = self._append(OP_INCR, key, str(delta), crash_after=None)
            self.memtable[key] = str(new)
            return rec

    def get(self, key: str) -> Optional[str]:
        with self.lock:
            return self.memtable.get(key)

    def _write(self, op: int, key: str, value: str, crash_after: Optional[str]) -> Ack:
        if self.group_commit and crash_after is None:
            return self._grouped_write(op, key, value)
        with self.lock:
            return self._append(op, key, value, crash_after=crash_after)

    def _append(self, op: int, key: str, value: str, crash_after: Optional[str]) -> Ack:
        self.seq += 1
        seq = self.seq
        rec = encode_record(op, seq, key, value)
        if crash_after == "before_write":
            self.seq -= 1  # the record never left the process
            raise Crash(crash_after)
        if crash_after == "partial_header":
            self.wal.write(rec[:2])
            self.wal.fsync()  # torn bytes reached the medium
            raise Crash(crash_after)
        if crash_after == "partial_payload":
            # Length + a few body bytes, not a complete record.
            cut = HEADER_LEN + max(2, (len(rec) - HEADER_LEN) // 3)
            self.wal.write(rec[:cut])
            self.wal.fsync()
            raise Crash(crash_after)
        self.wal.write(rec)
        if crash_after == "written_not_fsynced":
            raise Crash(crash_after)
        durable = False
        if self.sync:
            self.wal.fsync()
            durable = True
        if crash_after == "fsynced_not_applied":
            raise Crash(crash_after)
        self._apply(op, key, value)
        self.acked.append(seq)
        return Ack(ok=True, seq=seq, durable=durable, status="ok")

    def _apply(self, op: int, key: str, value: str) -> None:
        if op == OP_SET:
            self.memtable[key] = value
        elif op == OP_DEL:
            self.memtable.pop(key, None)
        elif op == OP_INCR:
            cur = int(self.memtable.get(key, "0") or "0")
            self.memtable[key] = str(cur + int(value or "1"))

    def _grouped_write(self, op: int, key: str, value: str) -> Ack:
        """Opportunistic group commit: one fsync for writers already waiting.

        Matches the RocksDB idea that concurrent sync writes may share one
        WAL write and one fsync, without proactively delaying to grow a
        batch.
        """
        event = threading.Event()
        slot: dict[str, Any] = {"op": op, "key": key, "value": value, "event": event, "ack": None, "err": None}
        with self.lock:
            self._pending.append(slot)
            am_leader = not self._leader_busy
            if am_leader:
                self._leader_busy = True
        if am_leader:
            self._drain_group()
        event.wait()
        if slot["err"] is not None:
            raise slot["err"]
        return slot["ack"]

    def _drain_group(self) -> None:
        while True:
            with self.lock:
                batch = self._pending
                self._pending = []
                if not batch:
                    self._leader_busy = False
                    return
            # Encode and write the whole group, then one fsync if sync=True.
            recs: list[tuple[dict[str, Any], int, bytes]] = []
            with self.lock:
                for slot in batch:
                    self.seq += 1
                    seq = self.seq
                    recs.append((slot, seq, encode_record(slot["op"], seq, slot["key"], slot["value"])))
            for slot, seq, raw in recs:
                self.wal.write(raw)
            durable = False
            if self.sync:
                self.wal.fsync()
                durable = True
            with self.lock:
                for slot, seq, raw in recs:
                    self._apply(slot["op"], slot["key"], slot["value"])
                    self.acked.append(seq)
                    slot["ack"] = Ack(ok=True, seq=seq, durable=durable, status="ok")
            self.group_batches += 1
            self.group_max = max(self.group_max, len(batch))
            for slot, seq, raw in recs:
                slot["event"].set()

    # -- crash and recovery --------------------------------------------

    def crash(self, kind: str = "power_loss") -> dict[str, Any]:
        if kind == "power_loss":
            self.wal.power_loss()
            image = self.wal.durable_bytes()
        elif kind == "process_kill":
            self.wal.process_kill()
            image = self.wal.cached_bytes()
        else:
            raise ValueError(f"unknown crash kind: {kind}")
        # Process memory is gone either way.
        mem_copy = dict(self.memtable)
        self.memtable = {}
        return {
            "kind": kind,
            "image": image,
            "memtable_before": mem_copy,
            "seq_before": self.seq,
            "acked": list(self.acked),
        }

    def recover(
        self,
        image: Optional[bytes] = None,
        parser: str = "safe",
        snapshot: Optional[dict[str, str]] = None,
        skip_seq_le: int = 0,
    ) -> dict[str, Any]:
        t0 = time.perf_counter()
        blob = self.wal.durable_bytes() if image is None else image
        parsed = parse_safe(blob) if parser == "safe" else parse_naive(blob)
        data = apply_records(parsed["records"], start=snapshot, skip_seq_le=skip_seq_le)
        self.memtable = dict(data)
        if parsed["records"]:
            self.seq = max(self.seq, max(r["seq"] for r in parsed["records"]))
        rto = time.perf_counter() - t0
        return {
            "parser": parser,
            "records": len(parsed["records"]),
            "truncated": parsed["truncated"],
            "reason": parsed["reason"],
            "consumed": parsed["consumed"],
            "tail_bytes": parsed["tail_bytes"],
            "keys": len(data),
            "data": data,
            "rto_s": round(rto, 6),
            "image_bytes": len(blob),
        }

    def snapshot(self) -> dict[str, str]:
        with self.lock:
            return dict(self.memtable)


def recover_image(
    image: bytes,
    parser: str = "safe",
    snapshot: Optional[dict[str, str]] = None,
    skip_seq_le: int = 0,
) -> dict[str, Any]:
    parsed = parse_safe(image) if parser == "safe" else parse_naive(image)
    data = apply_records(parsed["records"], start=snapshot, skip_seq_le=skip_seq_le)
    return {
        "parser": parser,
        "records": len(parsed["records"]),
        "truncated": parsed["truncated"],
        "reason": parsed["reason"],
        "consumed": parsed["consumed"],
        "tail_bytes": parsed["tail_bytes"],
        "keys": len(data),
        "data": data,
        "image_bytes": len(image),
    }
