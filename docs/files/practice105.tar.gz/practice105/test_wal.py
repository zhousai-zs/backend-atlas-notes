#!/usr/bin/env python3
"""Acceptance checks for practice105 (WALEngine)."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert_commit(data["commit_point"])
    _assert_trunc(data["truncation"])
    _assert_ack(data["ack_vs_fsync"])
    _assert_replay(data["idempotent_replay"])
    _assert_group(data["group_commit"])

    c = data["commit_point"]
    t = data["truncation"]
    a = data["ack_vs_fsync"]
    r = data["idempotent_replay"]
    g = data["group_commit"]
    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"before_write_11={c['before_write']['has_article_11']} "
        f"partial_header_11={c['partial_header']['has_article_11']} "
        f"partial_payload_11={c['partial_payload']['has_article_11']} "
        f"written_not_fsynced_11={c['written_not_fsynced']['has_article_11']} "
        f"fsynced_not_applied_11={c['fsynced_not_applied']['has_article_11']} "
        f"apply_first_lost={c['apply_first_then_crash']['lost_acked']} "
        f"forged_safe={t['forged_checksum']['safe_has_forged']} "
        f"forged_naive={t['forged_checksum']['naive_has_forged']} "
        f"naive_forged_value={t['forged_checksum']['naive_forged_value']} "
        f"mid_safe_99={t['midfile_then_valid']['safe_has_99']} "
        f"sync_true_pl_lost={a['sync_true_power_loss']['lost_acked']} "
        f"sync_false_pl_lost={a['sync_false_power_loss']['lost_acked']} "
        f"sync_false_kill_lost={a['sync_false_process_kill']['lost_acked']} "
        f"title={r['set_versions']['first_value']} "
        f"naive_incr={r['naive_incr_on_snapshot']['recovered_value']} "
        f"skip={r['naive_incr_on_snapshot']['skip_seq_value']} "
        f"safe_incr={r['safe_incr_as_set']['recovered_value']} "
        f"per_fsync={g['per_write']['fsync_count']} "
        f"group_fsync={g['group']['fsync_count']} "
        f"per_s={g['per_write']['elapsed_s']} "
        f"group_s={g['group']['elapsed_s']} "
        f"per_ops={g['per_write']['ops_per_s']} "
        f"group_ops={g['group']['ops_per_s']}"
    )
    return 0


def _assert_commit(c: dict) -> None:
    assert c["before_write"]["has_article_11"] is False
    assert c["before_write"]["recovered_keys"] == c["seed"]
    assert c["partial_header"]["has_article_11"] is False
    assert c["partial_header"]["truncated"] is True
    assert c["partial_payload"]["has_article_11"] is False
    assert c["partial_payload"]["truncated"] is True
    assert c["written_not_fsynced"]["has_article_11"] is False
    assert c["fsynced_not_applied"]["has_article_11"] is True
    assert c["fsynced_not_applied"]["article_11"] == "published-11"
    assert c["fsynced_not_applied"]["acked_after_attempt"] == c["seed"]
    assert c["apply_first_then_crash"]["lost_acked"] is True
    assert c["apply_first_then_crash"]["recovered_has_11"] is False


def _assert_trunc(t: dict) -> None:
    for stage in ("partial_header", "partial_payload"):
        assert t[stage]["safe_has_11"] is False
        assert t[stage]["safe_truncated"] is True
        assert t[stage]["safe_records"] == 10
    f = t["forged_checksum"]
    assert f["safe_has_forged"] is False
    assert f["safe_truncated"] is True
    assert f["safe_reason"] == "bad_checksum"
    assert f["safe_records"] == 10
    assert f["naive_has_forged"] is True
    assert f["naive_forged_value"] == "pwned-title"
    m = t["midfile_then_valid"]
    assert m["safe_has_99"] is False
    assert m["safe_reason"] == "bad_checksum"
    assert m["safe_records"] == 5
    assert m["naive_has_xx"] is True
    assert m["naive_has_99"] is True


def _assert_ack(a: dict) -> None:
    n = a["n"]
    assert a["sync_true_power_loss"]["acked"] == n
    assert a["sync_true_power_loss"]["durable_acked"] == n
    assert a["sync_true_power_loss"]["recovered"] == n
    assert a["sync_true_power_loss"]["lost_acked"] == 0
    assert a["sync_false_power_loss"]["acked"] == n
    assert a["sync_false_power_loss"]["durable_acked"] == 0
    assert a["sync_false_power_loss"]["recovered"] == 0
    assert a["sync_false_power_loss"]["lost_acked"] == n
    assert a["sync_false_process_kill"]["acked"] == n
    assert a["sync_false_process_kill"]["recovered"] == n
    assert a["sync_false_process_kill"]["lost_acked"] == 0
    assert a["sync_true_process_kill"]["lost_acked"] == 0
    assert a["sync_true_process_kill"]["recovered"] == n


def _assert_replay(r: dict) -> None:
    s = r["set_versions"]
    assert s["first_value"] == "Weekly digest (revised)"
    assert s["second_value"] == "Weekly digest (revised)"
    assert s["replayed_again_value"] == "Weekly digest (revised)"
    assert s["missing_delete_ok"] is True
    n = r["naive_incr_on_snapshot"]
    assert n["checkpoint_value"] == "5"
    assert n["applied_snapshot_value"] == "6"
    assert n["correct_from_checkpoint"] == "6"
    assert n["recovered_value"] == "7"
    assert n["double_counted"] is True
    assert n["skip_seq_value"] == "6"
    s2 = r["safe_incr_as_set"]
    assert s2["checkpoint_value"] == "5"
    assert s2["applied_snapshot_value"] == "6"
    assert s2["from_checkpoint"] == "6"
    assert s2["recovered_value"] == "6"


def _assert_group(g: dict) -> None:
    assert g["n"] == 200
    assert g["threads"] == 4
    assert g["per_write"]["recovered"] == 200
    assert g["per_write"]["lost"] == 0
    assert g["per_write"]["fsync_count"] == 200
    assert g["group"]["recovered"] == 200
    assert g["group"]["lost"] == 0
    assert g["group"]["fsync_count"] >= 1
    assert g["group"]["fsync_count"] < g["per_write"]["fsync_count"]
    assert g["group"]["group_batches"] >= 1
    # Group commit should not be slower by a wide margin; usually faster.
    # Don't assert a hard speedup: machine load varies. Do require fewer fsyncs.
    assert g["fsync_ratio"] > 1.0


if __name__ == "__main__":
    sys.exit(main())
