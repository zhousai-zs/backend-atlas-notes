#!/usr/bin/env python3
"""Acceptance checks for the lesson 120 sharding experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert r["engine"] == "ShardMigrationEngine" and r["not_redis"] and r["not_a_network_service"]
    m = r["migrations"]
    for mode in ("dual_write", "change_log"):
        x = m[mode]
        v = x["verify"]
        assert v["total_key_count_ok"] and v["versions_ok"], (mode, v)
        assert v["missing_keys"] == 0 and v["wrong_version_keys"] == 0 and v["keys_on_non_owners"] == 0
        assert v["expected_keys"] > x["keys_before"]          # inserts happened
        assert v["route_version"] == 2
        assert x["owners_after"][str(r["params"]["migrated_shard"])] == "n4"
        assert x["shard_keys_on_src_after"] == 0
        assert x["stats"]["reads_missing"] == 0 and x["stats"]["reads_stale"] == 0
        assert x["stats"]["stale_route_redirects"] > 0
        assert "cutover_window_s" in x["migration"]
    assert m["dual_write"]["stats"]["forwards"] > 0
    assert len(m["change_log"]["migration"]["catchup_rounds"]) >= 1
    assert (m["dual_write"]["latency_shard_during_migration"]["p50_s"]
            > m["dual_write"]["latency_shard_before_migration"]["p50_s"])
    fo, ct = m["flip_only"], m["copy_then_flip"]
    assert not fo["verify"]["total_key_count_ok"] and fo["verify"]["missing_keys"] > 0
    assert fo["stats"]["reads_missing"] > 0
    assert not ct["verify"]["versions_ok"] and ct["lost_acked_writes"] > 0
    hk = r["hotkey"]
    assert hk["vnodes_improve_key_balance"] and hk["vnodes_do_not_remove_hotspot"]
    assert hk["adding_node_does_not_remove_hotspot"] and hk["split_reduces_hotspot"]
    rh = r["range_vs_hash"]
    assert rh["scan_shards_range"] == 1 and rh["scan_shards_hash"] > 1
    assert rh["insert_max_share_range"] == 1.0 and rh["insert_max_share_hash"] < 0.5
    rs = r["redis_slot_check"]
    assert rs["crc16_123456789_hex"] == rs["spec_expected_hex"]
    assert rs["slot_user1000_name"] == rs["slot_user1000_surname"]
    for k in ("acceptance_total_keys_and_versions_ok", "acceptance_consistent_hash_does_not_remove_hot_key",
              "pitfall_flip_only_loses_data", "pitfall_copy_without_catchup_loses_writes",
              "tradeoff_range_scan_vs_hash_balance"):
        assert r[k] is True, k
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
