#!/usr/bin/env python3
"""Run the lesson 120 sharding / online-migration experiments."""
from __future__ import annotations

from collections import Counter
from random import Random
from typing import Any

from engine import (
    COPY_BATCH, COPY_BATCH_COST_S, CONFIG_UPDATE_S, FORWARD_DELAY_S, N_SHARDS, N_SLOTS,
    REPLAY_COST_S, RETRY_BACKOFF_S, RPC_DELAY_S, SLOTS_PER_SHARD,
    ConsistentHashRing, ShardMigrationEngine, crc16_xmodem, key_shard, key_slot, title_key, ts,
)

NODES = ["n1", "n2", "n3", "n4"]
N_KEYS = 4000
SHARD = 0
LOAD = dict(t0=0.0, t1=0.6, write_every_s=0.001, insert_ratio=0.1,
            hot_shard=SHARD, hot_shard_ratio=0.3, read_every_s=0.002)
MIGRATE_AT = 0.1
RUN_UNTIL = 1.0


def run_migration(mode: str) -> dict[str, Any]:
    eng = ShardMigrationEngine(NODES, N_KEYS, seed=120)
    before_owner = dict(eng.config.owner)
    keys_before = len(eng.acked)
    shard_keys_before = len(eng.nodes[before_owner[SHARD]].keys_in_shard(SHARD))
    clients = [eng.new_client() for _ in range(4)]
    eng.start_load(clients, **LOAD)
    eng.migrate(SHARD, "n4", MIGRATE_AT, mode)
    eng.run(RUN_UNTIL)
    m = dict(eng.migration)
    v = eng.verify()
    cut_t0 = m.get("freeze_t", m.get("flip_t", MIGRATE_AT))
    res = {
        "mode": mode,
        "owners_before": {str(k): v_ for k, v_ in before_owner.items()},
        "owners_after": {str(k): v_ for k, v_ in eng.config.owner.items()},
        "keys_before": keys_before,
        "shard_keys_before": shard_keys_before,
        "migration": m,
        "stats": dict(eng.stats),
        "verify": v,
        "shard_keys_on_dst_after": len(eng.nodes["n4"].keys_in_shard(SHARD)),
        "shard_keys_on_src_after": len(eng.nodes[before_owner[SHARD]].keys_in_shard(SHARD)),
        "latency_shard_before_migration": eng.latency_summary(SHARD, 0.0, MIGRATE_AT),
        "latency_shard_during_migration": eng.latency_summary(SHARD, MIGRATE_AT, cut_t0),
        "latency_other_shards_during_migration": eng.latency_summary(None, MIGRATE_AT, cut_t0),
        "lost_acked_writes": v["missing_keys"] + v["wrong_version_keys"],
        "route_events": [e for e in eng.events],
    }
    # Redirect counts are only meaningful relative to the route flip
    return res


def run_hotkey() -> dict[str, Any]:
    keys = [title_key(i) for i in range(N_KEYS)]
    hot = title_key(42)
    rng = Random(120)
    accesses = [hot if rng.random() < 0.5 else keys[rng.randrange(N_KEYS)] for _ in range(10000)]
    out: dict[str, Any] = {"hot_key": hot, "hot_access_ratio_target": 0.5,
                           "hot_accesses": sum(1 for a in accesses if a == hot),
                           "total_accesses": len(accesses), "by_vnodes": {}}
    for vn in (1, 16, 128):
        ring = ConsistentHashRing(["n1", "n2", "n3", "n4"], vn)
        kc = Counter(ring.lookup(k) for k in keys)
        ac = Counter(ring.lookup(a) for a in accesses)
        out["by_vnodes"][str(vn)] = {
            "key_counts": dict(sorted(kc.items())),
            "key_max_share": round(max(kc.values()) / N_KEYS, 4),
            "access_counts": dict(sorted(ac.items())),
            "access_max_share": round(max(ac.values()) / len(accesses), 4),
            "hot_key_node": ring.lookup(hot),
        }
    ring = ConsistentHashRing(["n1", "n2", "n3", "n4"], 128)
    ring.add("n5")
    kc = Counter(ring.lookup(k) for k in keys)
    ac = Counter(ring.lookup(a) for a in accesses)
    out["add_n5_vnodes128"] = {
        "key_max_share": round(max(kc.values()) / N_KEYS, 4),
        "access_counts": dict(sorted(ac.items())),
        "access_max_share": round(max(ac.values()) / len(accesses), 4),
        "hot_key_node": ring.lookup(hot),
        "hot_node_access_share": round(ac[ring.lookup(hot)] / len(accesses), 4),
    }
    # Teaching mitigation: split the hot key into N sub-keys read at random.
    ring = ConsistentHashRing(["n1", "n2", "n3", "n4"], 128)
    for n_sub in (8, 32):
        rng2 = Random(7)
        split = [f"{hot}#{rng2.randrange(n_sub)}" if a == hot else a for a in accesses]
        ac = Counter(ring.lookup(a) for a in split)
        sub_nodes = Counter(ring.lookup(f"{hot}#{i}") for i in range(n_sub))
        out[f"split_hot_key_{n_sub}"] = {
            "sub_keys": n_sub,
            "sub_keys_per_node": dict(sorted(sub_nodes.items())),
            "access_counts": dict(sorted(ac.items())),
            "access_max_share": round(max(ac.values()) / len(accesses), 4),
        }
    v1 = out["by_vnodes"]["1"]; v128 = out["by_vnodes"]["128"]
    out["vnodes_improve_key_balance"] = v128["key_max_share"] < v1["key_max_share"]
    out["vnodes_do_not_remove_hotspot"] = v128["access_max_share"] >= 0.5
    out["adding_node_does_not_remove_hotspot"] = out["add_n5_vnodes128"]["hot_node_access_share"] >= 0.5
    out["split_reduces_hotspot"] = out["split_hot_key_32"]["access_max_share"] < out["split_hot_key_8"]["access_max_share"] < v128["access_max_share"]
    return out


def run_range_vs_hash() -> dict[str, Any]:
    n_shards = N_SHARDS
    width = N_KEYS // n_shards  # 500 ids per range shard
    range_shard = lambda i: min(i // width, n_shards - 1)
    hash_shard = lambda i: key_shard(title_key(i))
    scan = range(1000, 1100)
    new_ids = range(N_KEYS, N_KEYS + 400)
    keys_hash = Counter(hash_shard(i) for i in range(N_KEYS))
    ins_range = Counter(range_shard(i) for i in new_ids)
    ins_hash = Counter(hash_shard(i) for i in new_ids)
    return {
        "range_width_ids": width,
        "scan_ids": [1000, 1099],
        "scan_shards_range": len({range_shard(i) for i in scan}),
        "scan_shards_hash": len({hash_shard(i) for i in scan}),
        "hash_key_counts": {str(k): v for k, v in sorted(keys_hash.items())},
        "hash_key_max_share": round(max(keys_hash.values()) / N_KEYS, 4),
        "insert_ids": [N_KEYS, N_KEYS + 399],
        "insert_max_share_range": round(max(ins_range.values()) / 400, 4),
        "insert_shards_range": len(ins_range),
        "insert_max_share_hash": round(max(ins_hash.values()) / 400, 4),
        "insert_shards_hash": len(ins_hash),
    }


def run_redis_slot_check() -> dict[str, Any]:
    return {
        "crc16_123456789_hex": format(crc16_xmodem(b"123456789"), "04X"),
        "spec_expected_hex": "31C3",
        "slot_user1000_name": key_slot("{user:1000}.name"),
        "slot_user1000_surname": key_slot("{user:1000}.surname"),
        "slot_article_42_title": key_slot(title_key(42)),
        "shard_article_42_title": key_shard(title_key(42)),
        "n_slots": N_SLOTS, "n_shards": N_SHARDS, "slots_per_shard": SLOTS_PER_SHARD,
    }


def run() -> dict[str, Any]:
    modes = {m: run_migration(m) for m in ("dual_write", "change_log", "flip_only", "copy_then_flip")}
    for r in modes.values():
        r.pop("route_events", None)
    hk = run_hotkey()
    rh = run_range_vs_hash()
    rs = run_redis_slot_check()
    dw, cl, fo, ct = (modes[m] for m in ("dual_write", "change_log", "flip_only", "copy_then_flip"))
    return {
        "engine": "ShardMigrationEngine",
        "not_redis": True, "not_redis_py": True, "not_a_network_service": True,
        "virtual_clock": True,
        "params": {
            "nodes": NODES, "n_keys": N_KEYS, "n_shards": N_SHARDS, "migrated_shard": SHARD,
            "load": LOAD, "migrate_at": MIGRATE_AT, "run_until": RUN_UNTIL, "clients": 4,
            "rpc_delay_s": RPC_DELAY_S, "forward_delay_s": FORWARD_DELAY_S,
            "copy_batch": COPY_BATCH, "copy_batch_cost_s": COPY_BATCH_COST_S,
            "replay_cost_s": REPLAY_COST_S, "config_update_s": CONFIG_UPDATE_S,
            "retry_backoff_s": RETRY_BACKOFF_S,
        },
        "migrations": modes,
        "hotkey": hk,
        "range_vs_hash": rh,
        "redis_slot_check": rs,
        "acceptance_total_keys_and_versions_ok": all(
            r["verify"]["total_key_count_ok"] and r["verify"]["versions_ok"] for r in (dw, cl)),
        "acceptance_consistent_hash_does_not_remove_hot_key": hk["vnodes_do_not_remove_hotspot"]
        and hk["adding_node_does_not_remove_hotspot"],
        "pitfall_flip_only_loses_data": not fo["verify"]["total_key_count_ok"],
        "pitfall_copy_without_catchup_loses_writes": not ct["verify"]["versions_ok"],
        "tradeoff_range_scan_vs_hash_balance": rh["scan_shards_range"] < rh["scan_shards_hash"]
        and rh["insert_max_share_hash"] < rh["insert_max_share_range"],
    }
