#!/usr/bin/env python3
"""Teaching ShardMigrationEngine -- not Redis, not redis-py, not a network service.

A Python 3 standard-library model of a sharded KV with a versioned routing
table, used to migrate one shard while a write load keeps running.

* Keys map to a Redis-style hash slot: CRC16-XMODEM(key) & 0x3FFF (with the
  {hash tag} rule), and the 16384 slots are grouped into 8 teaching shards
  of 2048 slots each. Redis Cluster assigns individual slots to masters; the
  8-shard grouping is a teaching simplification.
* A config service holds the authoritative routing table with a monotonically
  increasing route_version. Clients cache a copy; every request carries the
  cached version. A node that does not own the shard answers STALE_ROUTE
  (close in spirit to Redis -MOVED); a frozen shard answers RETRY (close in
  spirit to -TRYAGAIN). This is not the Redis cluster bus, gossip, configEpoch
  or the CLUSTER SETSLOT / MIGRATE / ASKING commands.
* Migration modes: "dual_write" (source applies, then synchronously forwards
  to the target before acking), "change_log" (source appends to a change log,
  catch-up rounds replay it, a short freeze drains the tail), and two broken
  modes used only as pitfall contrasts: "flip_only" (bump the routing table,
  move no data) and "copy_then_flip" (bulk copy, no incremental catch-up).
* Single process, discrete-event simulation on a virtual clock. No TCP, no
  real packet loss, no replication, no failover. Times are teaching numbers,
  not production RTT.
"""
from __future__ import annotations

import hashlib
import heapq
from dataclasses import dataclass, field
from random import Random
from typing import Any, Callable, Optional

N_SLOTS = 16384
N_SHARDS = 8
SLOTS_PER_SHARD = N_SLOTS // N_SHARDS

RPC_DELAY_S = 0.001           # one-way client<->node, teaching value
FORWARD_DELAY_S = 0.001       # one-way source->target forward, teaching value
COPY_BATCH = 50
COPY_BATCH_COST_S = 0.01      # per bulk-copy batch, teaching bandwidth model
REPLAY_COST_S = 0.0002        # per change-log entry replayed
CONFIG_UPDATE_S = 0.001       # time to publish a new route version
RETRY_BACKOFF_S = 0.002
CATCHUP_THRESHOLD = 5


# ---------------------------------------------------------------- CRC16 / slots
def crc16_xmodem(data: bytes) -> int:
    """CRC16 as specified in the Redis Cluster spec (XMODEM, poly 0x1021)."""
    crc = 0
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc


def hash_tag(key: str) -> str:
    s = key.find("{")
    if s != -1:
        e = key.find("}", s + 1)
        if e != -1 and e != s + 1:
            return key[s + 1 : e]
    return key


def key_slot(key: str) -> int:
    return crc16_xmodem(hash_tag(key).encode()) & 0x3FFF


def slot_shard(slot: int) -> int:
    return slot // SLOTS_PER_SHARD


def key_shard(key: str) -> int:
    return slot_shard(key_slot(key))


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 3)


def title_key(i: int) -> str:
    return f"article:{i:05d}:title"


# ---------------------------------------------------------------- cluster model
@dataclass
class RouteTable:
    version: int
    owner: dict[int, str]

    def copy(self) -> "RouteTable":
        return RouteTable(self.version, dict(self.owner))


@dataclass
class Node:
    name: str
    data: dict[str, tuple[str, int]] = field(default_factory=dict)  # key -> (value, version)
    # shard -> "owner" | "migrating_out" | "frozen" | "importing" | "moved"
    shard_state: dict[int, str] = field(default_factory=dict)
    migrate_target: dict[int, str] = field(default_factory=dict)
    change_log: dict[int, list[tuple[str, str, int]]] = field(default_factory=dict)

    def apply_if_newer(self, key: str, value: str, version: int) -> bool:
        cur = self.data.get(key)
        if cur is None or version > cur[1]:
            self.data[key] = (value, version)
            return True
        return False

    def keys_in_shard(self, shard: int) -> list[str]:
        return sorted(k for k in self.data if key_shard(k) == shard)


class ShardMigrationEngine:
    def __init__(self, nodes: list[str], n_keys: int, seed: int = 120) -> None:
        self.t = 0.0
        self._q: list[tuple[float, int, Callable[[], None]]] = []
        self._seq = 0
        self.rng = Random(seed)
        self.nodes = {n: Node(n) for n in nodes}
        initial = [n for n in nodes if n != nodes[-1]] or nodes  # last node starts empty
        owner = {s: initial[s % len(initial)] for s in range(N_SHARDS)}
        self.config = RouteTable(1, owner)
        for s, n in owner.items():
            self.nodes[n].shard_state[s] = "owner"
        # Oracle of acknowledged writes: key -> (value, version)
        self.acked: dict[str, tuple[str, int]] = {}
        for i in range(n_keys):
            k = title_key(i)
            v = ("Weekly digest", 1)
            self.nodes[owner[key_shard(k)]].data[k] = v
            self.acked[k] = v
        self.next_new_id = n_keys
        self.events: list[dict[str, Any]] = []
        self.stats = {
            "writes_issued": 0, "writes_acked": 0, "writes_to_shard": 0,
            "stale_route_redirects": 0, "retry_replies": 0, "route_refreshes": 0,
            "reads_issued": 0, "reads_missing": 0, "reads_stale": 0,
            "forwards": 0, "inserts_acked": 0,
        }
        self.write_latencies: list[tuple[float, float, int]] = []  # (issue_t, latency, shard)
        self.migration: dict[str, Any] = {}

    # ------------------------------------------------------------ scheduler
    def at(self, t: float, fn: Callable[[], None]) -> None:
        self._seq += 1
        heapq.heappush(self._q, (round(t, 9), self._seq, fn))

    def run(self, until: float) -> None:
        while self._q and self._q[0][0] <= until + 1e-12:
            t, _, fn = heapq.heappop(self._q)
            self.t = t
            fn()
        self.t = max(self.t, until)

    def log(self, name: str, **kw: Any) -> None:
        self.events.append({"t": ts(self.t), "event": name, **kw})

    # ------------------------------------------------------------ clients
    def new_client(self) -> dict[str, Any]:
        return {"route": self.config.copy()}

    def client_write(self, client: dict[str, Any], key: str, value: str, issue_t: float,
                     attempt: int = 0, oracle_snapshot: Optional[int] = None) -> None:
        shard = key_shard(key)
        node = client["route"].owner[shard]
        cv = client["route"].version
        self.at(self.t + RPC_DELAY_S,
                lambda: self._node_write(client, node, cv, key, value, issue_t, attempt))

    def _node_write(self, client, node_name, cv, key, value, issue_t, attempt) -> None:
        node = self.nodes[node_name]
        shard = key_shard(key)
        state = node.shard_state.get(shard)
        if state in ("owner", "migrating_out"):
            cur = node.data.get(key)
            version = (cur[1] + 1) if cur else 1
            node.data[key] = (value, version)
            extra = 0.0
            if state == "migrating_out":
                mode = self.migration.get("mode")
                tgt = self.nodes[node.migrate_target[shard]]
                if mode == "dual_write":
                    tgt.apply_if_newer(key, value, version)
                    self.stats["forwards"] += 1
                    extra = 2 * FORWARD_DELAY_S
                elif mode == "change_log":
                    node.change_log[shard].append((key, value, version))
            self.at(self.t + extra + RPC_DELAY_S,
                    lambda: self._write_acked(key, value, version, issue_t, shard))
        elif state == "frozen":
            self.stats["retry_replies"] += 1
            self.at(self.t + RPC_DELAY_S + RETRY_BACKOFF_S,
                    lambda: self.client_write(client, key, value, issue_t, attempt + 1))
        else:
            self.stats["stale_route_redirects"] += 1

            def refresh_and_retry():
                client["route"] = self.config.copy()
                self.stats["route_refreshes"] += 1
                self.client_write(client, key, value, issue_t, attempt + 1)
            self.at(self.t + RPC_DELAY_S, refresh_and_retry)

    def _write_acked(self, key, value, version, issue_t, shard) -> None:
        self.stats["writes_acked"] += 1
        prev = self.acked.get(key)
        if prev is None:
            self.stats["inserts_acked"] += 1
        if prev is None or version >= prev[1]:
            self.acked[key] = (value, version)
        else:
            # version went backwards relative to an earlier ack: record it
            self.acked[key] = (value, version)
            self.stats.setdefault("version_regressions", 0)
            self.stats["version_regressions"] += 1
        self.write_latencies.append((issue_t, self.t - issue_t, shard))

    def client_read(self, client: dict[str, Any], key: str) -> None:
        expect = self.acked.get(key)
        shard = key_shard(key)
        self.stats["reads_issued"] += 1

        def attempt():
            node = self.nodes[client["route"].owner[shard]]
            st = node.shard_state.get(shard)
            if st in ("owner", "migrating_out", "frozen"):
                got = node.data.get(key)
                if got is None:
                    self.stats["reads_missing"] += 1
                elif expect and got[1] < expect[1]:
                    self.stats["reads_stale"] += 1
            else:
                self.stats["stale_route_redirects"] += 1
                client["route"] = self.config.copy()
                self.stats["route_refreshes"] += 1
                self.at(self.t + 2 * RPC_DELAY_S, attempt)
        self.at(self.t + RPC_DELAY_S, attempt)

    # ------------------------------------------------------------ load
    def start_load(self, clients: list[dict[str, Any]], t0: float, t1: float,
                   write_every_s: float, insert_ratio: float, hot_shard: Optional[int] = None,
                   hot_shard_ratio: float = 0.0, read_every_s: Optional[float] = None) -> None:
        n = int(round((t1 - t0) / write_every_s))
        existing = sorted(self.acked)
        shard_keys = [k for k in existing if hot_shard is not None and key_shard(k) == hot_shard]
        for i in range(n):
            t = t0 + i * write_every_s
            c = clients[i % len(clients)]
            r = self.rng.random()
            if r < insert_ratio:
                key = title_key(self.next_new_id)
                self.next_new_id += 1
                value = "Weekly digest"
            else:
                if shard_keys and self.rng.random() < hot_shard_ratio:
                    key = self.rng.choice(shard_keys)
                else:
                    key = self.rng.choice(existing)
                value = self.rng.choice(["Weekly digest (draft)", "Weekly digest (revised)",
                                         "Weekly digest (hotfix)"])
            self.stats["writes_issued"] += 1
            if hot_shard is not None and key_shard(key) == hot_shard:
                self.stats["writes_to_shard"] += 1
            self.at(t, (lambda c=c, key=key, value=value, t=t: self.client_write(c, key, value, t)))
        if read_every_s:
            m = int(round((t1 - t0) / read_every_s))
            for i in range(m):
                t = t0 + i * read_every_s + read_every_s / 2
                c = clients[i % len(clients)]

                def do_read(c=c):
                    keys = list(self.acked)
                    key = keys[self.rng.randrange(len(keys))]
                    self.client_read(c, key)
                self.at(t, do_read)

    # ------------------------------------------------------------ migration
    def migrate(self, shard: int, dst: str, start_t: float, mode: str,
                cleanup_delay_s: float = 0.02) -> None:
        src = self.config.owner[shard]
        self.migration = {"mode": mode, "shard": shard, "src": src, "dst": dst,
                          "start_t": start_t, "route_version_before": self.config.version}
        S, D = self.nodes[src], self.nodes[dst]

        def flip():
            self.config.version += 1
            self.config.owner[shard] = dst
            D.shard_state[shard] = "owner"
            S.shard_state[shard] = "moved"
            self.migration["flip_t"] = ts(self.t)
            self.migration["route_version_after"] = self.config.version
            self.log("route_flip", shard=shard, src=src, dst=dst, version=self.config.version)
            self.at(self.t + cleanup_delay_s, cleanup)

        def cleanup():
            removed = 0
            for k in S.keys_in_shard(shard):
                del S.data[k]
                removed += 1
            S.change_log.pop(shard, None)
            self.migration["cleanup_t"] = ts(self.t)
            self.migration["cleanup_removed"] = removed
            self.log("cleanup", shard=shard, src=src, removed=removed)

        def begin():
            self.log("migration_begin", shard=shard, src=src, dst=dst, mode=mode)
            if mode == "flip_only":
                self.at(self.t + CONFIG_UPDATE_S, flip)
                return
            D.shard_state[shard] = "importing"
            if mode in ("dual_write", "change_log"):
                S.shard_state[shard] = "migrating_out"
                S.migrate_target[shard] = dst
                S.change_log[shard] = []
            snapshot = S.keys_in_shard(shard)
            self.migration["snapshot_keys"] = len(snapshot)
            batches = [snapshot[i:i + COPY_BATCH] for i in range(0, len(snapshot), COPY_BATCH)]
            self.migration["copy_batches"] = len(batches)

            def copy_batch(i: int):
                if i == len(batches):
                    self.migration["copy_done_t"] = ts(self.t)
                    self.log("copy_done", batches=len(batches))
                    after_copy()
                    return
                for k in batches[i]:
                    v = S.data.get(k)
                    if v:
                        D.apply_if_newer(k, v[0], v[1])
                self.at(self.t + COPY_BATCH_COST_S, lambda: copy_batch(i + 1))
            copy_batch(0)

        def after_copy():
            if mode == "copy_then_flip":
                self.at(self.t + CONFIG_UPDATE_S, flip)
            elif mode == "dual_write":
                freeze_and_cut([])
            elif mode == "change_log":
                self.migration["catchup_rounds"] = []
                catchup()

        def replay(entries):
            for k, v, ver in entries:
                D.apply_if_newer(k, v, ver)

        def catchup():
            log_ = S.change_log[shard]
            if len(log_) < CATCHUP_THRESHOLD:
                freeze_and_cut(log_)
                return
            entries = list(log_)
            log_.clear()
            self.migration["catchup_rounds"].append({"t": ts(self.t), "entries": len(entries)})
            self.at(self.t + REPLAY_COST_S * len(entries), lambda: (replay(entries), catchup()))

        def freeze_and_cut(tail):
            S.shard_state[shard] = "frozen"
            self.migration["freeze_t"] = ts(self.t)
            tail = list(tail)
            self.migration["drained_at_freeze"] = len(tail)
            self.log("freeze", shard=shard, tail=len(tail))

            def finish():
                # drain anything appended before freeze
                replay(tail)
                flip()
                self.migration["cutover_window_s"] = ts(self.t - self.migration["freeze_t"])
            self.at(self.t + REPLAY_COST_S * len(tail) + CONFIG_UPDATE_S, finish)

        self.at(start_t, begin)

    # ------------------------------------------------------------ verification
    def verify(self) -> dict[str, Any]:
        cfg = self.config
        total_on_owners = 0
        wrong_version = 0
        missing = 0
        extra = 0
        dup_after_cleanup = 0
        for k, (val, ver) in self.acked.items():
            owner = self.nodes[cfg.owner[key_shard(k)]]
            got = owner.data.get(k)
            if got is None:
                missing += 1
            elif got != (val, ver):
                wrong_version += 1
        for n in self.nodes.values():
            for k in n.data:
                if cfg.owner[key_shard(k)] == n.name:
                    total_on_owners += 1
                    if k not in self.acked:
                        extra += 1
                else:
                    dup_after_cleanup += 1
        return {
            "expected_keys": len(self.acked),
            "keys_on_owners": total_on_owners,
            "missing_keys": missing,
            "wrong_version_keys": wrong_version,
            "extra_keys": extra,
            "keys_on_non_owners": dup_after_cleanup,
            "total_key_count_ok": total_on_owners == len(self.acked) and missing == 0,
            "versions_ok": wrong_version == 0 and missing == 0,
            "route_version": cfg.version,
        }

    def latency_summary(self, shard: Optional[int], t0: float, t1: float) -> dict[str, Any]:
        lat = sorted(l for (it, l, s) in self.write_latencies
                     if t0 <= it < t1 and (shard is None or s == shard))
        if not lat:
            return {"n": 0}
        p = lambda q: lat[min(len(lat) - 1, int(q * len(lat)))]
        return {"n": len(lat), "p50_s": ts(p(0.5)), "p99_s": ts(p(0.99)), "max_s": ts(lat[-1])}


# ---------------------------------------------------------------- hot keys / ring
def md5_int(s: str) -> int:
    return int.from_bytes(hashlib.md5(s.encode()).digest()[:8], "big")


class ConsistentHashRing:
    """Teaching consistent-hash ring with virtual nodes. Not how Redis Cluster routes."""

    def __init__(self, nodes: list[str], vnodes: int) -> None:
        self.vnodes = vnodes
        self.points: list[tuple[int, str]] = []
        for n in nodes:
            self.add(n)

    def add(self, node: str) -> None:
        for i in range(self.vnodes):
            self.points.append((md5_int(f"{node}#vn{i}"), node))
        self.points.sort()

    def lookup(self, key: str) -> str:
        h = md5_int(key)
        lo, hi = 0, len(self.points)
        while lo < hi:
            mid = (lo + hi) // 2
            if self.points[mid][0] < h:
                lo = mid + 1
            else:
                hi = mid
        return self.points[lo % len(self.points)][1]
