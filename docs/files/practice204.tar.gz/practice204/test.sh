#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["failed"]==[]
assert r["good_storage_calls"]==2
assert r["double_retry_storage_calls"]>8
print("POSTCHECK_OK")
PY
