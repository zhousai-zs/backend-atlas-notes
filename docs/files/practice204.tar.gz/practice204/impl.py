from __future__ import annotations

import time
from dataclasses import dataclass, field


DEADLINE = "DEADLINE_EXCEEDED"
UNAVAILABLE = "UNAVAILABLE"
NOT_FOUND = "NOT_FOUND"


@dataclass
class Storage:
    data: dict
    deadline_ms: int = 100
    # If True, storage itself retries internally — the pitfall.
    internal_retries: int = 0
    calls: int = 0
    sleep_ms: int = 0
    fail_unavailable_times: int = 0

    def get(self, key: str, deadline_ms: int | None = None) -> dict:
        cap = self.deadline_ms if deadline_ms is None else min(deadline_ms, self.deadline_ms)
        attempts = 1 + self.internal_retries
        last = None
        for i in range(attempts):
            self.calls += 1
            if self.sleep_ms and self.sleep_ms > cap:
                return {"ok": False, "error": DEADLINE}
            if self.fail_unavailable_times > 0:
                self.fail_unavailable_times -= 1
                last = {"ok": False, "error": UNAVAILABLE}
                continue
            if key not in self.data:
                return {"ok": False, "error": NOT_FOUND}
            return {"ok": True, "value": self.data[key]}
        return last or {"ok": False, "error": UNAVAILABLE}


@dataclass
class Gateway:
    storage: Storage
    retry_unavailable: int = 1  # contract: at most once (2 attempts total)
    retry_deadline: bool = False  # contract: must be False
    calls: int = 0

    def get(self, key: str) -> dict:
        attempts = 1 + (self.retry_unavailable if True else 0)
        # honour contract default
        max_extra = self.retry_unavailable
        tried = 0
        last = None
        while tried <= max_extra:
            tried += 1
            self.calls += 1
            last = self.storage.get(key, deadline_ms=self.storage.deadline_ms)
            if last.get("ok"):
                return last
            err = last.get("error")
            if err == DEADLINE and not self.retry_deadline:
                return last
            if err == NOT_FOUND:
                return last
            if err == UNAVAILABLE and tried <= max_extra:
                continue
            return last
        return last
