from __future__ import annotations

import json
from pathlib import Path

import yaml
from impl import DEADLINE, NOT_FOUND, UNAVAILABLE, Gateway, Storage

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"
CONTRACT = yaml.safe_load((ROOT / "contract" / "gateway-storage-v1.yaml").read_text())


def amplification(storage_internal: int, gateway_retry: int, fail_times: int) -> int:
    st = Storage({"k": "v"}, internal_retries=storage_internal, fail_unavailable_times=fail_times)
    gw = Gateway(st, retry_unavailable=gateway_retry)
    gw.get("k")
    return st.calls


def main() -> None:
    checks = []

    def check(name, ok, detail=""):
        checks.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f" {detail}" if detail else ""))

    # Compatible pair
    st = Storage({"alice/x": "1"}, fail_unavailable_times=1)
    gw = Gateway(st, retry_unavailable=1, retry_deadline=False)
    r = gw.get("alice/x")
    check("compatible_retry_unavailable_once", r.get("ok") is True and st.calls == 2, f"{r} calls={st.calls}")

    st2 = Storage({"alice/x": "1"}, sleep_ms=200)
    gw2 = Gateway(st2, retry_unavailable=1, retry_deadline=False)
    r2 = gw2.get("alice/x")
    check("deadline_not_retried", r2.get("error") == DEADLINE and st2.calls == 1, f"{r2} calls={st2.calls}")

    st3 = Storage({})
    r3 = Gateway(st3).get("missing")
    check("not_found_not_retried", r3.get("error") == NOT_FOUND and st3.calls == 1, str(r3))

    # Error code consistency: storage and contract use the same tokens
    codes = set(CONTRACT["errors"])
    check("error_codes_are_contracted", {DEADLINE, UNAVAILABLE, NOT_FOUND, "UNAUTHENTICATED"} <= codes, str(codes))

    # Double retry pitfall: both sides retry a 3-time outage →  (1+3)*(1+3) style amplification
    good_calls = amplification(storage_internal=0, gateway_retry=1, fail_times=1)
    bad_calls = amplification(storage_internal=3, gateway_retry=3, fail_times=20)
    check("compatible_amplification_small", good_calls == 2, f"calls={good_calls}")
    check("double_retry_detected", bad_calls > 8, f"calls={bad_calls}")
    check("timeout_owners_documented", CONTRACT["timeouts"]["notes"] and CONTRACT["owners"]["storage"] and CONTRACT["owners"]["gateway"], "")

    failed = [n for n, ok, _ in checks if not ok]
    (ROOT / "reports" / "contract-run.json").write_text(json.dumps({
        "good_calls": good_calls, "double_retry_calls": bad_calls
    }, indent=2) + "\n")
    RESULTS.write_text(json.dumps({
        "lesson": 204, "id": "n-collaboration", "is_live_model": False,
        "contract_version": CONTRACT["version"],
        "good_storage_calls": good_calls,
        "double_retry_storage_calls": bad_calls,
        "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        "failed": failed,
        "not_verified_on_this_machine": [
            "a live cross-team on-call rotation or production engagement process",
        ],
        "verified_on_this_machine": [
            "executable contract tests: UNAVAILABLE retried once, DEADLINE/NOT_FOUND not retried",
            "double-retry amplification is detected and rejected as a contract violation",
        ],
    }, ensure_ascii=False, indent=2) + "\n")
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
