#!/usr/bin/env python3
"""Five official token classes + write/read + HTTP/Agent same gate. No paid OAuth."""

from __future__ import annotations

import io
import json
import logging
from pathlib import Path

from starlette.testclient import TestClient

from authorize import log as auth_log
from service import BUSINESS, agent_call, app, dispatch
from tokens import OTHER_RESOURCE, issue, revoke, token_fingerprint

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

buf = io.StringIO()
h = logging.StreamHandler(buf)
h.setFormatter(logging.Formatter("%(message)s"))
auth_log.addHandler(h)

client = TestClient(app)

# Discovery
prm = client.get("/.well-known/oauth-protected-resource").json()
asmeta = client.get("/.well-known/oauth-authorization-server").json()
assert prm["resource"].endswith("/mcp")
assert asmeta["issuer"] in prm["authorization_servers"]
assert client.get("/as/validate-redirect?redirect_uri=http://evil.example/cb").status_code == 400
assert client.get("/as/validate-redirect?redirect_uri=http://127.0.0.1:0/cb").status_code == 200

normal = issue(sub="alice", tenant="tenant-a", scopes=["diagnose:read"])
wrong_aud = issue(sub="alice", tenant="tenant-a", scopes=["diagnose:read"], aud=OTHER_RESOURCE)
expired = issue(sub="alice", tenant="tenant-a", scopes=["diagnose:read"], ttl=-10, jti="expired-1")
missing_scope = issue(sub="alice", tenant="tenant-a", scopes=[])  # no diagnose:read
cross = issue(sub="bob", tenant="tenant-b", scopes=["diagnose:read"])
writer = issue(sub="alice", tenant="tenant-a", scopes=["diagnose:read", "diagnose:write"])

# Confirm pyjwt rejects wrong-aud before we even look at tenant.
BUSINESS["entered"] = 0


def http(token, tool, service):
    return client.post(
        f"/mcp/tools/{tool}",
        json={"service": service},
        headers={"Authorization": f"Bearer {token}"},
    )


# Five official cases via BOTH HTTP and Agent, same reasons.
cases = []

def both(name, token, tool, service, expect_reason, expect_ok):
    r_http = http(token, tool, service)
    body_http = r_http.json()
    body_agent = agent_call(token, tool, service)
    assert body_http["reason"] == body_agent["reason"] == expect_reason, (name, body_http, body_agent)
    assert body_http["ok"] is expect_ok and body_agent["ok"] is expect_ok
    # wrong audience must not enter business
    if expect_reason == "bad_audience":
        assert body_http["business_entered"] is False and body_agent["business_entered"] is False
    cases.append({
        "name": name,
        "http": body_http,
        "agent": body_agent,
        "http_status": r_http.status_code,
        "same_logic": body_http["reason"] == body_agent["reason"] and body_http["ok"] == body_agent["ok"],
    })
    return body_http

entered_before = BUSINESS["entered"]
both("normal", normal.raw, "diagnose", "svc-a", "ok", True)
both("wrong_audience", wrong_aud.raw, "diagnose", "svc-a", "bad_audience", False)
assert BUSINESS["entered"] == entered_before + 2  # http + agent, both allowed
both("expired", expired.raw, "diagnose", "svc-a", "expired", False)
both("missing_scope", missing_scope.raw, "diagnose", "svc-a", "missing_scope", False)
both("cross_tenant", cross.raw, "diagnose", "svc-a", "cross_tenant", False)

# Read-only token cannot write.
write_denied = both("readonly_cannot_write", normal.raw, "mutate_flag", "svc-a", "missing_scope", False)
assert BUSINESS["flag"] == "off"

# Writer can write own tenant, not the other.
both("write_own", writer.raw, "mutate_flag", "svc-a", "ok", True)
both("write_cross_tenant", writer.raw, "mutate_flag", "svc-b", "cross_tenant", False)

# Hidden / unadvertised tool: scripted agent still hits the same server gate.
hidden = dispatch(normal.raw, "drop_table", "svc-a")
assert hidden["ok"] is False and hidden["business_entered"] is False
# missing_scope or unknown — drop_table requires write; read-only is missing_scope
assert hidden["reason"] in {"missing_scope", "unknown_tool"}

# Revocation
rev = issue(sub="alice", tenant="tenant-a", scopes=["diagnose:read"], jti="to-revoke")
revoke("to-revoke")
revoked_body = dispatch(rev.raw, "diagnose", "svc-a")
assert revoked_body["reason"] == "revoked" and revoked_body["business_entered"] is False

# Logs must not contain raw JWTs (three-part eyJ...)
log_text = buf.getvalue()
(REPORTS / "auth.log").write_text(log_text)
for tok in (normal.raw, wrong_aud.raw, expired.raw, writer.raw, rev.raw):
    assert tok not in log_text, "raw token leaked into log"
assert "eyJ" not in log_text
assert "tok_fp=" in log_text

# fingerprints recorded, not raw tokens, in case results
assert all("eyJ" not in json.dumps(c) for c in cases)

results = {
    "lesson": 173,
    "id": "l-mcp-auth",
    "is_live_oauth_login": False,
    "is_live_paid_api": False,
    "token_alg": "RS256",
    "spec": "MCP 2026-07-28 authorization + RFC 8707 audience binding + RFC 9728 PRM",
    "discovery": {"prm_resource": prm["resource"], "issuer": asmeta["issuer"]},
    "five_cases": {c["name"]: {"reason": c["http"]["reason"], "ok": c["http"]["ok"], "business_entered": c["http"]["business_entered"], "same_http_and_agent": c["same_logic"]} for c in cases if c["name"] in {"normal", "wrong_audience", "expired", "missing_scope", "cross_tenant"}},
    "readonly_cannot_write": True,
    "cross_tenant_write_rejected": True,
    "hidden_tool": hidden,
    "revoked": revoked_body["reason"],
    "wrong_audience_entered_business": any(c["http"]["business_entered"] for c in cases if c["name"] == "wrong_audience"),
    "http_and_agent_same_logic": all(c["same_logic"] for c in cases),
    "logs_contain_raw_tokens": False,
    "business_counts": dict(BUSINESS),
    "verified_on_this_machine": [
        "five_token_classes_allow_or_deny_as_specified",
        "wrong_audience_does_not_enter_business",
        "readonly_scope_cannot_write_and_cross_tenant_denied",
        "direct_http_and_scripted_agent_share_authorize",
        "logs_redact_jwts",
    ],
    "not_verified_on_this_machine": [
        "browser_OAuth_21_PKCE_login_against_a_production_AS",
        "Dynamic_Client_Registration_or_Client_ID_Metadata_Documents",
    ],
}
assert results["wrong_audience_entered_business"] is False
assert results["http_and_agent_same_logic"] is True
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "auth.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps({"five": results["five_cases"], "same": results["http_and_agent_same_logic"], "flag": BUSINESS["flag"]}, indent=2))
print("ALL_CHECKS_PASSED")
