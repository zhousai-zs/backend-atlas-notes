"""Local teaching authorization server: mints and validates RS256 access tokens.

This is not a production OAuth 2.1 authorization server and does not run a
browser / PKCE login. It does implement the resource-server checks the MCP
2026-07-28 authorization spec requires of a protected resource: audience
binding, issuer checks, expiry, revocation, and (application-level) scope
plus tenant authorization. Token passthrough of a token minted for another
resource is rejected.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field

import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

ISSUER = "http://127.0.0.1:0/as"
RESOURCE = "http://127.0.0.1:0/mcp"  # this MCP resource's audience
OTHER_RESOURCE = "http://other.example/api"
REDIRECTS_ALLOWED = frozenset({"http://127.0.0.1:0/cb", "http://localhost:0/cb"})

_priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_pub = _priv.public_key()
PUB_PEM = _pub.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)


def jwks() -> dict:
    import json
    from jwt.algorithms import RSAAlgorithm

    key = json.loads(RSAAlgorithm.to_jwk(_pub))
    key.update({"kid": "as-1", "alg": "RS256", "use": "sig"})
    return {"keys": [key]}


def as_metadata() -> dict:
    return {
        "issuer": ISSUER,
        "authorization_endpoint": ISSUER + "/authorize",
        "token_endpoint": ISSUER + "/token",
        "jwks_uri": ISSUER + "/jwks",
        "code_challenge_methods_supported": ["S256"],
        "response_types_supported": ["code"],
    }


def protected_resource_metadata() -> dict:
    # RFC 9728 Protected Resource Metadata — MCP servers MUST implement this.
    return {
        "resource": RESOURCE,
        "authorization_servers": [ISSUER],
        "bearer_methods_supported": ["header"],
        "scopes_supported": ["diagnose:read", "diagnose:write"],
    }


def validate_redirect(uri: str) -> bool:
    return uri in REDIRECTS_ALLOWED


def token_fingerprint(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()[:12]


REVOKED: set[str] = set()


@dataclass
class Issued:
    raw: str
    jti: str
    claims: dict
    fp: str = field(init=False)

    def __post_init__(self):
        self.fp = token_fingerprint(self.raw)


def issue(
    *,
    sub: str,
    tenant: str,
    scopes: list[str],
    aud: str = RESOURCE,
    iss: str = ISSUER,
    ttl: int = 600,
    jti: str | None = None,
    iat: int | None = None,
) -> Issued:
    now = int(time.time()) if iat is None else iat
    jti = jti or f"jti-{sub}-{now}"
    claims = {
        "iss": iss,
        "aud": aud,
        "sub": sub,
        "tid": tenant,
        "scope": " ".join(scopes),
        "iat": now,
        "exp": now + ttl,
        "jti": jti,
        "resource": aud,  # RFC 8707 binding also recorded in a resource claim
    }
    raw = jwt.encode(claims, _priv, algorithm="RS256", headers={"kid": "as-1"})
    return Issued(raw=raw, jti=jti, claims=claims)


def revoke(jti: str) -> None:
    REVOKED.add(jti)
