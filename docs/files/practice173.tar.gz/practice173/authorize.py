"""Single authorization gate used by both direct HTTP and Agent/MCP paths."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

import jwt

from tokens import ISSUER, RESOURCE, REVOKED, PUB_PEM, token_fingerprint, as_metadata, protected_resource_metadata

log = logging.getLogger("practice173.auth")

# Tool -> required scope
TOOL_SCOPES = {
    "diagnose": "diagnose:read",
    "mutate_flag": "diagnose:write",
    "drop_table": "diagnose:write",  # not even advertised; still checked if called
}

# tenant -> services it may read/write
ACL = {
    "tenant-a": {"svc-a", "shared"},
    "tenant-b": {"svc-b", "shared"},
}


def redact(token: str | None) -> str:
    if not token:
        return "<missing>"
    return f"tok_fp={token_fingerprint(token)}"


class RedactingFilter(logging.Filter):
    _jwt = re.compile(r"eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._jwt.sub("[REDACTED_JWT]", str(record.msg))
        if record.args:
            def scrub(v):
                if isinstance(v, str):
                    return self._jwt.sub("[REDACTED_JWT]", v)
                return v
            record.args = tuple(scrub(a) for a in record.args)
        return True


log.addFilter(RedactingFilter())
log.setLevel(logging.INFO)


@dataclass
class Decision:
    allowed: bool
    reason: str
    tool: str
    resource: str
    tenant: str | None = None
    scopes: list[str] = field(default_factory=list)
    subject: str | None = None
    token_fp: str | None = None
    business_entered: bool = False  # set True only by the business handler after allow


def authorize(token: str | None, *, tool: str, service: str, discovered_issuer: str | None = None) -> Decision:
    """Resource-server checks. Wrong audience never reaches a business handler."""
    log.info("authorize tool=%s service=%s token=%s", tool, service, redact(token))
    if not token:
        return Decision(False, "unauthenticated", tool, RESOURCE, token_fp=None)
    try:
        claims = jwt.decode(
            token,
            PUB_PEM,
            algorithms=["RS256"],
            audience=RESOURCE,
            issuer=ISSUER,
            options={"require": ["exp", "iss", "aud", "jti"]},
        )
    except jwt.ExpiredSignatureError:
        return Decision(False, "expired", tool, RESOURCE, token_fp=token_fingerprint(token))
    except jwt.InvalidAudienceError:
        # MUST reject tokens not intended for this resource (MCP auth security considerations).
        return Decision(False, "bad_audience", tool, RESOURCE, token_fp=token_fingerprint(token))
    except jwt.InvalidIssuerError:
        return Decision(False, "bad_issuer", tool, RESOURCE, token_fp=token_fingerprint(token))
    except jwt.InvalidTokenError as e:
        return Decision(False, f"invalid_token:{type(e).__name__}", tool, RESOURCE, token_fp=token_fingerprint(token))

    if discovered_issuer and discovered_issuer != claims["iss"]:
        return Decision(False, "issuer_metadata_mismatch", tool, RESOURCE, token_fp=token_fingerprint(token), subject=claims.get("sub"))

    # Discovery must advertise this issuer.
    advertised = set(protected_resource_metadata()["authorization_servers"])
    if claims["iss"] not in advertised or claims["iss"] != as_metadata()["issuer"]:
        return Decision(False, "issuer_not_in_prm", tool, RESOURCE, token_fp=token_fingerprint(token))

    if claims["jti"] in REVOKED:
        return Decision(False, "revoked", tool, RESOURCE, token_fp=token_fingerprint(token), subject=claims.get("sub"))

    scopes = claims.get("scope", "").split()
    tenant = claims.get("tid")
    need = TOOL_SCOPES.get(tool)
    if need is None:
        return Decision(False, "unknown_tool", tool, RESOURCE, tenant=tenant, scopes=scopes, subject=claims.get("sub"), token_fp=token_fingerprint(token))
    if need not in scopes:
        return Decision(False, "missing_scope", tool, RESOURCE, tenant=tenant, scopes=scopes, subject=claims.get("sub"), token_fp=token_fingerprint(token))

    # Second layer: tenant / resource ACL. Scope alone is not enough.
    allowed_svc = ACL.get(tenant or "", set())
    if service not in allowed_svc:
        return Decision(False, "cross_tenant", tool, RESOURCE, tenant=tenant, scopes=scopes, subject=claims.get("sub"), token_fp=token_fingerprint(token))

    return Decision(True, "ok", tool, RESOURCE, tenant=tenant, scopes=scopes, subject=claims.get("sub"), token_fp=token_fingerprint(token))
