#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json,re
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
five=r["five_cases"]
assert five["normal"]["ok"] is True
for k in ("wrong_audience","expired","missing_scope","cross_tenant"):
    assert five[k]["ok"] is False, k
assert five["wrong_audience"]["business_entered"] is False
assert r["http_and_agent_same_logic"] and r["readonly_cannot_write"]
log=Path("reports/auth.log").read_text()
assert re.search(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", log) is None
assert r["logs_contain_raw_tokens"] is False
print("POSTCHECK_OK")
PY
