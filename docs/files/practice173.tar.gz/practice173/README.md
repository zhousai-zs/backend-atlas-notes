# 实践 173：MCP 授权与信任边界

在解压后的 `practice173/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（PyJWT 2.15.1、cryptography、Starlette、httpx）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

教学用本地 RS256 JWT 与 RFC 9728 发现元数据，不是完整浏览器/PKCE 登录。is_live_oauth_login=false。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
