"""Diagnose MCP + HTTP resource server sharing authorize()."""

from __future__ import annotations

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from authorize import Decision, authorize
from tokens import as_metadata, jwks, protected_resource_metadata, validate_redirect

BUSINESS = {"entered": 0, "diagnoses": 0, "writes": 0, "flag": "off"}


def run_business(dec: Decision, tool: str, service: str) -> dict:
    if not dec.allowed:
        # never enter business on a deny
        return {"ok": False, "reason": dec.reason, "business_entered": False, "service": service, "token_fp": dec.token_fp}
    dec.business_entered = True
    BUSINESS["entered"] += 1
    if tool == "diagnose":
        BUSINESS["diagnoses"] += 1
        return {"ok": True, "reason": "ok", "business_entered": True, "service": service, "reading": f"diag:{service}", "token_fp": dec.token_fp}
    if tool == "mutate_flag":
        BUSINESS["writes"] += 1
        BUSINESS["flag"] = "on"
        return {"ok": True, "reason": "ok", "business_entered": True, "service": service, "flag": BUSINESS["flag"], "token_fp": dec.token_fp}
    return {"ok": False, "reason": "unknown_tool", "business_entered": False, "token_fp": dec.token_fp}


def dispatch(token: str | None, tool: str, service: str) -> dict:
    dec = authorize(token, tool=tool, service=service, discovered_issuer=protected_resource_metadata()["authorization_servers"][0])
    return run_business(dec, tool, service)


async def prm(_req: Request):
    return JSONResponse(protected_resource_metadata())


async def asmeta(_req: Request):
    return JSONResponse(as_metadata())


async def jwks_route(_req: Request):
    return JSONResponse(jwks())


async def redirect_check(req: Request):
    uri = req.query_params.get("redirect_uri", "")
    ok = validate_redirect(uri)
    return JSONResponse({"allowed": ok, "redirect_uri": uri}, status_code=200 if ok else 400)


async def tool_http(req: Request):
    tool = req.path_params["tool"]
    body = await req.json()
    auth = req.headers.get("authorization") or ""
    token = auth[7:].strip() if auth.lower().startswith("bearer ") else None
    result = dispatch(token, tool, body.get("service", ""))
    return JSONResponse(result, status_code=200 if result["ok"] else 403)


def agent_call(token: str | None, tool: str, service: str) -> dict:
    """Scripted Agent path: same dispatch() as HTTP. Not an LLM."""
    return dispatch(token, tool, service)


app = Starlette(
    routes=[
        Route("/.well-known/oauth-protected-resource", prm),
        Route("/.well-known/oauth-authorization-server", asmeta),
        Route("/as/jwks", jwks_route),
        Route("/as/validate-redirect", redirect_check),
        Route("/mcp/tools/{tool}", tool_http, methods=["POST"]),
    ]
)
