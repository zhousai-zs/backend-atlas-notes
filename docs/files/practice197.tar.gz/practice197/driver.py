from __future__ import annotations

import json
from pathlib import Path

from validate import load, validate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def main() -> None:
    req = load(ROOT / "requirements" / "roadside-events.yaml")
    good = validate(req, load(ROOT / "designs" / "good.yaml"))
    bad = validate(req, load(ROOT / "designs" / "bad-cache-first.yaml"))
    (ROOT / "reports" / "good.json").write_text(json.dumps(good, indent=2) + "\n")
    (ROOT / "reports" / "bad.json").write_text(json.dumps(bad, indent=2) + "\n")
    checks = [
        ("good_design_accepted", good["ok"] is True, str(good)),
        ("bad_design_rejected", bad["ok"] is False and any("has_no_requirement" in p for p in bad["problems"]), str(bad["problems"])),
        ("assumptions_have_plans", set(good["assumptions"]) == {"A1", "A2", "A3"}, str(good["assumptions"])),
        ("staleness_and_hotspots_present", "N2" in good["cited_requirements"] and "N3" in good["cited_requirements"], str(good["cited_requirements"])),
        ("unknowns_are_labeled", all(a["id"].startswith("A") for a in req["assumptions"]), ""),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 197,
                "id": "n-requirements",
                "is_live_model": False,
                "good": good,
                "bad": bad,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "not_verified_on_this_machine": [
                    "real traffic measurements for the nationwide roadside network (N1/N2 are labeled assumptions)",
                ],
                "verified_on_this_machine": [
                    "requirement page contains volume, hotspots, staleness, and assumptions with validation plans",
                    "a cache-first design with no requirement links is rejected; the linked design is accepted",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
