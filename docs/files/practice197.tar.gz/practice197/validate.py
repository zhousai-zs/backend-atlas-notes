from __future__ import annotations

import yaml
from pathlib import Path


def load(path: Path):
    return yaml.safe_load(path.read_text())


def validate(req: dict, design: dict) -> dict:
    ids = {x["id"] for x in req["functional"] + req["nonfunctional"]}
    assumption_ids = {x["id"] for x in req["assumptions"]}
    problems = []
    if not req.get("business_goal"):
        problems.append("missing_business_goal")
    for a in req["assumptions"]:
        if not a.get("unknown") or not a.get("validation_plan"):
            problems.append(f"assumption_{a.get('id')}_missing_plan")
    # volume, hotspots, staleness must be present
    kinds = {x["kind"] for x in req["nonfunctional"]}
    for need in ("volume", "traffic", "staleness"):
        if need not in kinds:
            problems.append(f"missing_{need}")
    cited = set()
    for c in design["components"]:
        refs = list(c.get("requires") or [])
        if not refs:
            problems.append(f"component_{c['name']}_has_no_requirement")
        for r in refs:
            if r not in ids:
                problems.append(f"component_{c['name']}_unknown_req_{r}")
            cited.add(r)
    # Every component must have a basis; we also flag a design that only exists as fashion.
    return {
        "ok": not problems,
        "problems": problems,
        "cited_requirements": sorted(cited),
        "uncited_requirements": sorted(ids - cited),
        "assumptions": sorted(assumption_ids),
    }
