#!/usr/bin/env bash
# Local CI stand-in: record toolchain, run Clang/ASan jobs, honor the merge gate.
# This is not a GitHub-hosted runner.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/ci/common.sh"
if [[ -z "$CXX" ]]; then
  echo "No clang++ or zig-c++ wrapper" >&2
  exit 1
fi

bash "$ROOT/ci/toolchain.sh"

gate_fail=0
: > "$ROOT/reports/jobs.txt"

record_job() {
  local name=$1 status=$2
  echo "$name $status" | tee -a "$ROOT/reports/jobs.txt"
  if [[ "$status" != pass && "$status" != unavailable ]]; then
    gate_fail=1
  fi
}

run_binary() {
  local bin=$1 log=$2
  set +e
  ASAN_OPTIONS=abort_on_error=1:detect_leaks=0 "$bin" "theme=dark" >"$log" 2>&1
  local rc=$?
  set -e
  echo "$rc"
}

# Job: clang (or zig c++ clang) unsanitized test, fixed source
compile fixed "$ROOT/build/cache-clang"
rc=$(run_binary "$ROOT/build/cache-clang" "$ROOT/reports/clang-fixed.txt")
if [[ "$rc" == 0 ]] && grep -q "sum=$(expected_sum)" "$ROOT/reports/clang-fixed.txt"; then
  record_job clang_test pass
else
  cp "$ROOT/reports/clang-fixed.txt" "$ROOT/reports/failures/clang-test.txt"
  record_job clang_test fail
fi

# Job: ASan on fixed source must pass
compile fixed "$ROOT/build/cache-asan-fixed" asan
rc=$(run_binary "$ROOT/build/cache-asan-fixed" "$ROOT/reports/asan-fixed.txt")
if [[ "$rc" == 0 ]] && grep -q "sum=$(expected_sum)" "$ROOT/reports/asan-fixed.txt" && ! grep -q "ERROR: AddressSanitizer" "$ROOT/reports/asan-fixed.txt"; then
  record_job clang_asan_fixed pass
else
  cp "$ROOT/reports/asan-fixed.txt" "$ROOT/reports/failures/asan-fixed.txt"
  record_job clang_asan_fixed fail
fi

# Job: ASan on broken source must fail and keep the log (the merge-blocking demonstration)
compile broken "$ROOT/build/cache-asan-broken" asan
rc=$(run_binary "$ROOT/build/cache-asan-broken" "$ROOT/reports/asan-broken.txt")
cp "$ROOT/reports/asan-broken.txt" "$ROOT/reports/failures/asan-broken.txt"
if [[ "$rc" != 0 ]] && grep -q "ERROR: AddressSanitizer: heap-use-after-free" "$ROOT/reports/asan-broken.txt"; then
  record_job clang_asan_broken_detected pass
else
  record_job clang_asan_broken_detected fail
fi

# Job: GCC matrix cell — honest skip if g++ is missing
if [[ "$GCC_PRESENT" == yes ]]; then
  "$GCC" -std=c++17 -g -O1 -fno-omit-frame-pointer -DMODE_FIXED "$ROOT/src/cache.cpp" -o "$ROOT/build/cache-gcc"
  rc=$(run_binary "$ROOT/build/cache-gcc" "$ROOT/reports/gcc-fixed.txt")
  if [[ "$rc" == 0 ]]; then record_job gcc_test pass; else record_job gcc_test fail; fi
else
  echo "gcc_unavailable" | tee "$ROOT/reports/gcc-unavailable.txt"
  record_job gcc_test unavailable
fi

if (( gate_fail )); then
  echo "MERGE_BLOCKED" | tee "$ROOT/reports/gate.txt"
  exit 1
fi
echo "MERGE_ALLOWED_FOR_FIXED_TREE" | tee "$ROOT/reports/gate.txt"
exit 0
