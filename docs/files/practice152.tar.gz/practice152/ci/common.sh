# shared by pipeline jobs; sourced, not executed.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOCK="$ROOT/lock/versions.txt"
# shellcheck disable=SC2034
ZIGLANG_PIN=$(awk -F= '/^ziglang==/{print $NF}' "$LOCK")
mkdir -p "$ROOT/build" "$ROOT/reports" "$ROOT/reports/failures"
CXX=""
GCC=""
GCC_PRESENT=no
ZIG_FALLBACK=0
if command -v clang++ >/dev/null 2>&1; then
  CXX=$(command -v clang++)
elif [[ -x "$ROOT/tools/zig-c++" ]]; then
  CXX="$ROOT/tools/zig-c++"
  ZIG_FALLBACK=1
fi
if command -v g++ >/dev/null 2>&1; then
  GCC=$(command -v g++)
  GCC_PRESENT=yes
fi
TARGET=native
ASAN_LIB=""
CXXFLAGS="-std=c++17 -g -O1 -fno-omit-frame-pointer"
if (( ZIG_FALLBACK )); then
  TARGET=x86_64-linux-gnu
  CXXFLAGS="-target x86_64-linux-gnu $CXXFLAGS"
  ASAN_LIB=$(python3 -c 'import glob; p=sorted(glob.glob("/usr/lib/x86_64-linux-gnu/libasan.so.*")); print(p[0] if p else "")')
fi
compile() {
  local mode=$1 out=$2 sanitize=${3:-}
  local def="-DMODE_FIXED"
  [[ "$mode" == broken ]] && def="-DMODE_BROKEN"
  local extra=()
  if [[ "$sanitize" == asan ]]; then
    extra+=(-fsanitize=address)
    [[ -n "$ASAN_LIB" ]] && extra+=("$ASAN_LIB")
  fi
  # word-split CXXFLAGS intentionally (locked flag list)
  # shellcheck disable=SC2086
  "$CXX" $CXXFLAGS $def "${extra[@]}" "$ROOT/src/cache.cpp" -o "$out"
}
expected_sum() {
  python3 -c 's="theme=dark"; print(sum(s.encode()))'
}
