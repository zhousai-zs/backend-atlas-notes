#!/usr/bin/env bash
# Record pinned toolchain. Do not curl "latest" compilers here.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=common.sh
source "$ROOT/ci/common.sh"
{
  echo "date_beijing=$(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M:%S %Z')"
  echo "python=$(python3 -c 'import sys; print(sys.version.split()[0])')"
  echo "ziglang_pin=$ZIGLANG_PIN"
  if [[ -n "$CXX" ]]; then
    echo "cxx=$CXX"
    echo "cxx_version_begin"
    "$CXX" --version | head -n 3
    echo "cxx_version_end"
  fi
  echo "gcc_present=$GCC_PRESENT"
  if [[ "$GCC_PRESENT" == yes ]]; then
    echo "gcc=$GCC"
    "$GCC" --version | head -n 2
  else
    echo "gcc_status=unavailable"
    echo "gcc_note=g++ not in PATH; this cell is unavailable, not a pass"
  fi
  echo "target=$TARGET"
  echo "asan_runtime=$ASAN_LIB"
  echo "flags=$CXXFLAGS"
  echo "source_sha256"
  (cd "$ROOT" && sha256sum src/cache.cpp ci/pipeline.sh ci/toolchain.sh ci/common.sh tools/zig-c++ lock/versions.txt)
} | tee "$ROOT/reports/toolchain.txt"
