// Teaching cache: MODE=broken leaves a use-after-free; MODE=fixed does not.
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>

struct Slot {
    char* data;
    int len;
};

static Slot g_slot = {nullptr, 0};

void cache_set(const char* s) {
    delete[] g_slot.data;
    g_slot.len = static_cast<int>(std::strlen(s));
    g_slot.data = new char[g_slot.len + 1];
    std::memcpy(g_slot.data, s, static_cast<size_t>(g_slot.len) + 1);
}

int cache_sum() {
#if defined(MODE_BROKEN)
    // Use-after-free: release, then read.
    char* p = g_slot.data;
    delete[] g_slot.data;
    g_slot.data = nullptr;
    int total = 0;
    for (int i = 0; i < g_slot.len; ++i) total += static_cast<unsigned char>(p[i]);
    return total;
#else
    int total = 0;
    if (!g_slot.data) return 0;
    for (int i = 0; i < g_slot.len; ++i) total += static_cast<unsigned char>(g_slot.data[i]);
    return total;
#endif
}

void cache_clear() {
    delete[] g_slot.data;
    g_slot.data = nullptr;
    g_slot.len = 0;
}

int main(int argc, char** argv) {
    const char* value = (argc > 1) ? argv[1] : "theme=dark";
    cache_set(value);
    int sum = cache_sum();
    std::cout << "sum=" << sum << " len=" << g_slot.len << "\n";
    cache_clear();
    return 0;
}
