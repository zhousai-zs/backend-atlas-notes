#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export ZIG_LOCAL_CACHE_DIR="${ZIG_LOCAL_CACHE_DIR:-/tmp/zig-cache-unit}"
export ZIG_GLOBAL_CACHE_DIR="${ZIG_GLOBAL_CACHE_DIR:-/tmp/zig-cache-unit}"
rm -rf build reports
mkdir -p build reports/failures

# 1. Pipeline on this tree (fixed path must pass; broken ASan must be detected)
bash ci/pipeline.sh 2>&1 | tee run.log
grep -q MERGE_ALLOWED_FOR_FIXED_TREE reports/gate.txt
grep -q 'clang_test pass' reports/jobs.txt
grep -q 'clang_asan_fixed pass' reports/jobs.txt
grep -q 'clang_asan_broken_detected pass' reports/jobs.txt
# gcc may be unavailable; never treat that as a silent pass
if command -v g++ >/dev/null 2>&1; then
  grep -q 'gcc_test pass' reports/jobs.txt
else
  grep -q 'gcc_test unavailable' reports/jobs.txt
fi
grep -q 'ERROR: AddressSanitizer: heap-use-after-free' reports/failures/asan-broken.txt

# 2. A failed check blocks merge: if we only had the broken asan job as the required check, refuse
python3 - <<'PY'
from pathlib import Path
# Simulate merge gate: required check "asan on the change" failed when the broken mode is the candidate.
log = Path("reports/failures/asan-broken.txt").read_text(errors="replace")
assert "heap-use-after-free" in log
Path("reports/merge-decision.txt").write_text("blocked: required asan check failed on broken change\n")
print("merge_decision=blocked")
PY

# 3. Fresh directory rerun of the same locked sources
fresh=$(mktemp -d /tmp/practice152-fresh-XXXX)
# do not copy build/ or reports/
cp -a src ci tools lock test.sh "$fresh/"
( cd "$fresh" && bash ci/pipeline.sh >fresh.log 2>&1 )
cp "$fresh/reports/gate.txt" reports/fresh-gate.txt
cp "$fresh/reports/jobs.txt" reports/fresh-jobs.txt
cp "$fresh/fresh.log" reports/fresh.log
grep -q MERGE_ALLOWED_FOR_FIXED_TREE reports/fresh-gate.txt
grep -q 'clang_asan_fixed pass' reports/fresh-jobs.txt

python3 - <<'PY'
import json, os
from pathlib import Path
jobs = Path("reports/jobs.txt").read_text().strip().splitlines()
result = {
    "jobs": jobs,
    "gcc_unavailable": Path("reports/gcc-unavailable.txt").exists(),
    "asan_broken_saved": Path("reports/failures/asan-broken.txt").exists(),
    "merge_blocked_on_broken": "blocked" in Path("reports/merge-decision.txt").read_text(),
    "fresh_env_pass": "MERGE_ALLOWED_FOR_FIXED_TREE" in Path("reports/fresh-gate.txt").read_text(),
    "toolchain_file": "reports/toolchain.txt",
}
Path("results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
PY
echo ALL_CHECKS_PASSED
