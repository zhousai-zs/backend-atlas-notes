#!/usr/bin/env python3
"""网络序整数编解码 + UTF-8 边界安全截断工具。

对应 Backend Atlas 节点 a-encoding 实践：
- 用 struct 的网络字节序（大端 !）编解码整数
- 可选对比小端
- 按最大字节长度安全截断 UTF-8，不截断多字节字符中间
"""
from __future__ import annotations

import struct
from typing import Tuple


# ---------- 网络序整数编解码 ----------

def encode_u32_network(n: int) -> bytes:
    """无符号 32 位整数 → 网络字节序（大端）4 字节。"""
    if not 0 <= n <= 0xFFFFFFFF:
        raise ValueError(f"u32 out of range: {n}")
    return struct.pack("!I", n)


def decode_u32_network(data: bytes) -> int:
    """网络字节序 4 字节 → 无符号 32 位整数。"""
    if len(data) != 4:
        raise ValueError(f"need exactly 4 bytes, got {len(data)}")
    return struct.unpack("!I", data)[0]


def encode_u16_network(n: int) -> bytes:
    """无符号 16 位整数 → 网络字节序（大端）2 字节。"""
    if not 0 <= n <= 0xFFFF:
        raise ValueError(f"u16 out of range: {n}")
    return struct.pack("!H", n)


def decode_u16_network(data: bytes) -> int:
    if len(data) != 2:
        raise ValueError(f"need exactly 2 bytes, got {len(data)}")
    return struct.unpack("!H", data)[0]


def encode_u32_little(n: int) -> bytes:
    """对比用：小端编码同一整数。"""
    if not 0 <= n <= 0xFFFFFFFF:
        raise ValueError(f"u32 out of range: {n}")
    return struct.pack("<I", n)


def host_vs_network_demo(n: int = 0x01020304) -> dict:
    """展示同一整数的大端 / 小端字节布局差异。"""
    be = encode_u32_network(n)
    le = encode_u32_little(n)
    return {
        "value_hex": f"0x{n:08X}",
        "big_endian_bytes": be.hex(" "),
        "little_endian_bytes": le.hex(" "),
        "same_layout": be == le,
    }


# ---------- UTF-8 边界检查 ----------

def utf8_char_len(first_byte: int) -> int:
    """根据首字节判断该 UTF-8 字符占用几个字节。非法首字节返回 0。"""
    if first_byte < 0x80:
        return 1
    if 0xC2 <= first_byte <= 0xDF:
        return 2
    if 0xE0 <= first_byte <= 0xEF:
        return 3
    if 0xF0 <= first_byte <= 0xF4:
        return 4
    return 0  # 续字节或非法


def is_utf8_continuation(b: int) -> bool:
    return 0x80 <= b <= 0xBF


def utf8_safe_truncate(data: bytes, max_bytes: int) -> Tuple[bytes, bool]:
    """按最大字节长度截断，保证不落在多字节字符中间。

    返回 (截断后的 bytes, 是否相对原 data 有删减)。
    只保留完整 UTF-8 字符；不完整尾部或非法序列在边界处丢弃。
    """
    if max_bytes < 0:
        raise ValueError("max_bytes must be >= 0")

    limit = min(len(data), max_bytes)
    i = 0
    last_ok = 0
    while i < limit:
        clen = utf8_char_len(data[i])
        if clen == 0:
            break
        if i + clen > limit:
            break
        if i + clen > len(data):
            break
        ok = True
        for j in range(1, clen):
            if not is_utf8_continuation(data[i + j]):
                ok = False
                break
        if not ok:
            break
        i += clen
        last_ok = i

    out = data[:last_ok]
    return out, out != data


def utf8_incomplete_tail(data: bytes) -> bool:
    """检测字节串末尾是否存在不完整的 UTF-8 多字节序列。"""
    if not data:
        return False
    i = len(data) - 1
    cont = 0
    while i >= 0 and is_utf8_continuation(data[i]):
        cont += 1
        i -= 1
        if cont > 3:
            return True
    if i < 0:
        return cont > 0
    expected = utf8_char_len(data[i])
    if expected == 0:
        return True
    actual = 1 + cont
    return actual < expected


def char_vs_byte_stats(s: str) -> dict:
    """展示「字符数 ≠ 字节数」——中文场景必会踩的坑。"""
    encoded = s.encode("utf-8")
    return {
        "text": s,
        "char_count": len(s),
        "byte_count": len(encoded),
        "hex": encoded.hex(" "),
    }


def _self_check() -> None:
    for n in (0, 1, 0x7F, 0x80, 0x01020304, 0xFFFFFFFF):
        assert decode_u32_network(encode_u32_network(n)) == n
    for n in (0, 1, 0x7FFF, 0x8000, 0xFFFF):
        assert decode_u16_network(encode_u16_network(n)) == n

    demo = host_vs_network_demo(0x01020304)
    assert demo["big_endian_bytes"] == "01 02 03 04"
    assert demo["little_endian_bytes"] == "04 03 02 01"

    stats = char_vs_byte_stats("微信")
    assert stats["char_count"] == 2
    assert stats["byte_count"] == 6

    raw = "微信公众号".encode("utf-8")
    cut4, t4 = utf8_safe_truncate(raw, 4)
    assert t4 and cut4 == "微".encode("utf-8")
    assert utf8_safe_truncate(raw, 3)[0] == "微".encode("utf-8")
    assert utf8_safe_truncate(raw, 2)[0] == b""
    assert utf8_safe_truncate(raw, 6)[0] == "微信".encode("utf-8")
    full, truncated_full = utf8_safe_truncate(raw, 100)
    assert full == raw and not truncated_full

    incomplete = "微".encode("utf-8")[:2]
    assert utf8_incomplete_tail(incomplete) is True
    assert utf8_incomplete_tail("微".encode("utf-8")) is False
    assert utf8_incomplete_tail(b"abc") is False
    # 半截输入即使 max 很大也应丢弃不完整字符
    assert utf8_safe_truncate(incomplete, 10)[0] == b""

    print("ALL_CHECKS_PASSED")
    print("endian_demo:", demo)
    print("char_vs_byte:", stats)
    print("truncate_max4:", cut4.decode("utf-8"), "bytes=", cut4.hex(" "))


if __name__ == "__main__":
    _self_check()
