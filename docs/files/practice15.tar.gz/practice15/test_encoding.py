#!/usr/bin/env python3
"""验收用例：字符数≠字节数；跨端序 round-trip 一致；中文安全截断。"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from encoding_tools import (
    char_vs_byte_stats,
    decode_u16_network,
    decode_u32_network,
    encode_u16_network,
    encode_u32_little,
    encode_u32_network,
    host_vs_network_demo,
    utf8_incomplete_tail,
    utf8_safe_truncate,
)


def test_char_count_ne_byte_count() -> None:
    """验收：能解释字符数不等于字节数。"""
    s = "微信公众号后台"
    st = char_vs_byte_stats(s)
    assert st["char_count"] == 7, st
    assert st["byte_count"] == 21, st  # 每汉字 3 字节 UTF-8
    assert st["char_count"] != st["byte_count"]
    print(f"OK char≠byte: chars={st['char_count']} bytes={st['byte_count']} hex={st['hex']}")


def test_network_order_roundtrip() -> None:
    """验收：跨端序测试结果一致——网络序编解码 round-trip。"""
    samples = [0, 1, 255, 256, 0x01020304, 0xDEADBEEF, 0xFFFFFFFF]
    for n in samples:
        raw = encode_u32_network(n)
        assert len(raw) == 4
        assert decode_u32_network(raw) == n
        # 小端布局必须不同（非对称值）
        if n == 0x01020304:
            assert raw == bytes([0x01, 0x02, 0x03, 0x04])
            assert encode_u32_little(n) == bytes([0x04, 0x03, 0x02, 0x01])
            assert raw != encode_u32_little(n)

    for n in (0, 1, 0xABCD, 0xFFFF):
        assert decode_u16_network(encode_u16_network(n)) == n

    demo = host_vs_network_demo()
    assert demo["big_endian_bytes"] == "01 02 03 04"
    print("OK network-order round-trip + endian contrast:", demo)


def test_utf8_safe_truncate_mid_hanzi() -> None:
    """截断点落在汉字中间时，不得留下半截字节。"""
    text = "你好世界"
    raw = text.encode("utf-8")  # 4 字 × 3 = 12 字节
    # max=5：只能放下「你」(3)，第 2 字会越界
    cut, truncated = utf8_safe_truncate(raw, 5)
    assert truncated
    assert cut == "你".encode("utf-8")
    assert cut.decode("utf-8") == "你"  # 必须能成功解码

    # max=1：连一个汉字都放不下
    cut1, _ = utf8_safe_truncate(raw, 1)
    assert cut1 == b""

    # max=6：两个完整汉字
    cut6, _ = utf8_safe_truncate(raw, 6)
    assert cut6.decode("utf-8") == "你好"

    # 故意半截序列应被检测
    half = "好".encode("utf-8")[:2]
    assert utf8_incomplete_tail(half)
    # 安全截断半截输入 → 空（首字符不完整）
    cut_half, _ = utf8_safe_truncate(half, 10)
    assert cut_half == b""
    print("OK utf8 safe truncate mid-汉字 + incomplete detection")


def main() -> None:
    test_char_count_ne_byte_count()
    test_network_order_roundtrip()
    test_utf8_safe_truncate_mid_hanzi()
    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
