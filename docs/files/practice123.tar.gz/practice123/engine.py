#!/usr/bin/env python3
"""Teaching OverloadKVEngine — not Redis, not a real gateway, not a network service.

A Python 3 standard-library model of a single-node KV with a token bucket,
a concurrency cap, a queue cap, and optional per-tenant buckets. It is used
to observe burst vs sustained rate, the gap between a QPS cap and a
concurrency cap, bounded memory under overload, tenant fairness, and the
trade-off between reject rate and accepted-request latency.

Terms such as per-customer limits, the pitfalls of queries-per-second, and
"accept only what you can process and reject the rest" follow Google SRE
Chapter 21, Handling Overload (checked on 2026-11-14). This engine is not
Google's production stack, not Doorman, not a load balancer, not Envoy,
and not a token-bucket library. There is no TCP, no RPC stack, no CPU
accounting, and no adaptive client-side throttling. The KV is an in-process
dict. Persistence is a teaching dict flush, not a disk or fsync. Clock is
virtual. service_time_s and arrival spacing are teaching delays, not
production RTT. The chapter argues that QPS is often a poor capacity
metric because request cost varies; this engine uses a uniform
service_time_s so rate and work stay proportional on purpose, and the
lesson records that difference.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
SERVICE_TIME_S = 0.10
TOKEN_RATE = 10.0
TOKEN_BURST = 5
DEFAULT_CONCURRENCY = 2
DEFAULT_QUEUE = 4
TENANT_EDITOR = "editor"
TENANT_BATCH = "batch"


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


def percentile(values: list[float], p: float) -> Optional[float]:
    """Nearest-rank percentile; empty list returns None."""
    if not values:
        return None
    xs = sorted(values)
    if p <= 0:
        return xs[0]
    if p >= 100:
        return xs[-1]
    k = int((len(xs) - 1) * (p / 100.0) + 1e-12)
    return xs[k]


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


class TokenBucket:
    """Teaching token bucket: refill `rate` tokens/s, cap at `burst`.

    This is not a production limiter (not Guava, not nginx, not Envoy).
    Tokens are an abstract admission currency, not CPU-seconds.
    """

    def __init__(self, rate: float, burst: float, clock: Clock, initial: Optional[float] = None) -> None:
        if rate < 0 or burst < 0:
            raise ValueError("rate and burst must be >= 0")
        self.rate = float(rate)
        self.burst = float(burst)
        self.clock = clock
        self.tokens = float(burst if initial is None else initial)
        if self.tokens > self.burst:
            self.tokens = self.burst
        self.last_refill = clock.now()

    def refill(self) -> float:
        now = self.clock.now()
        elapsed = now - self.last_refill
        if elapsed > 0 and self.rate > 0:
            self.tokens = min(self.burst, self.tokens + self.rate * elapsed)
            self.last_refill = now
        elif elapsed > 0:
            self.last_refill = now
        return self.tokens

    def allow(self, cost: float = 1.0) -> bool:
        self.refill()
        if self.tokens + 1e-12 >= cost:
            self.tokens -= cost
            return True
        return False

    def snapshot(self) -> dict[str, Any]:
        self.refill()
        return {"rate": self.rate, "burst": self.burst, "tokens": round(self.tokens, 6)}


@dataclass(order=True)
class Completion:
    finish_t: float
    seq: int
    req_id: int = field(compare=False)


@dataclass
class Request:
    req_id: int
    tenant: str
    op: str
    key: str
    arrive_t: float
    start_t: Optional[float] = None
    finish_t: Optional[float] = None
    status: str = "pending"  # pending, running, ok, rejected
    reject_reason: Optional[str] = None

    @property
    def latency(self) -> Optional[float]:
        if self.finish_t is None or self.status != "ok":
            return None
        return self.finish_t - self.arrive_t

    def as_dict(self) -> dict[str, Any]:
        return {
            "req_id": self.req_id,
            "tenant": self.tenant,
            "op": self.op,
            "key": self.key,
            "arrive_t": ts(self.arrive_t),
            "start_t": None if self.start_t is None else ts(self.start_t),
            "finish_t": None if self.finish_t is None else ts(self.finish_t),
            "status": self.status,
            "reject_reason": self.reject_reason,
            "latency": None if self.latency is None else ts(self.latency),
        }


class OverloadKVEngine:
    def __init__(
        self,
        *,
        service_time_s: float = SERVICE_TIME_S,
        max_concurrency: Optional[int] = DEFAULT_CONCURRENCY,
        max_queue: Optional[int] = DEFAULT_QUEUE,
        token_rate: Optional[float] = None,
        token_burst: Optional[float] = None,
        per_tenant_rate: Optional[float] = None,
        per_tenant_burst: Optional[float] = None,
        tenant_buckets: Optional[dict[str, tuple[float, float]]] = None,
        title: str = TITLE_V1,
    ) -> None:
        self.clock = Clock()
        self.service_time_s = float(service_time_s)
        # None means "no cap" (unbounded). 0 would reject everything.
        self.max_concurrency = max_concurrency
        self.max_queue = max_queue
        self.store: dict[str, str] = {KEY_TITLE: title}
        self.flush_count = 0
        self.events: list[dict[str, Any]] = []

        self.global_bucket: Optional[TokenBucket] = None
        if token_rate is not None:
            burst = float(token_burst if token_burst is not None else token_rate)
            self.global_bucket = TokenBucket(float(token_rate), burst, self.clock)

        self.tenant_buckets: dict[str, TokenBucket] = {}
        if tenant_buckets:
            for name, (rate, burst) in tenant_buckets.items():
                self.tenant_buckets[name] = TokenBucket(float(rate), float(burst), self.clock)
        self.per_tenant_rate = per_tenant_rate
        self.per_tenant_burst = per_tenant_burst

        self.inflight: dict[int, Request] = {}
        self.queue: list[Request] = []
        self.completions: list[Completion] = []
        self._seq = 0
        self._req_seq = 0
        self.requests: list[Request] = []

        self.max_queue_depth = 0
        self.max_inflight = 0
        self.max_resident = 0  # queue + inflight, teaching memory proxy

        self._event("init", service_time_s=self.service_time_s, max_concurrency=max_concurrency, max_queue=max_queue)

    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def _flush(self, reason: str) -> None:
        self.flush_count += 1
        self._event("persist_flushed", reason=reason, flush_count=self.flush_count)

    def _bucket_for(self, tenant: str) -> Optional[TokenBucket]:
        if tenant in self.tenant_buckets:
            return self.tenant_buckets[tenant]
        if self.per_tenant_rate is not None:
            burst = float(self.per_tenant_burst if self.per_tenant_burst is not None else self.per_tenant_rate)
            self.tenant_buckets[tenant] = TokenBucket(float(self.per_tenant_rate), burst, self.clock)
            return self.tenant_buckets[tenant]
        return None

    def _track_resident(self) -> None:
        q = len(self.queue)
        n = len(self.inflight)
        if q > self.max_queue_depth:
            self.max_queue_depth = q
        if n > self.max_inflight:
            self.max_inflight = n
        resident = q + n
        if resident > self.max_resident:
            self.max_resident = resident

    def _start(self, req: Request, start_t: float) -> None:
        req.start_t = start_t
        req.status = "running"
        req.finish_t = start_t + self.service_time_s
        self.inflight[req.req_id] = req
        self._seq += 1
        heapq.heappush(self.completions, Completion(req.finish_t, self._seq, req.req_id))
        self._track_resident()
        self._event("started", req_id=req.req_id, tenant=req.tenant, start_t=ts(start_t), finish_t=ts(req.finish_t))

    def _apply(self, req: Request) -> None:
        if req.op == "SET":
            self.store[req.key] = TITLE_V1 if req.key == KEY_TITLE else self.store.get(req.key, "")
            self._flush("kv_set")
        # GET is a read; no flush.

    def _complete_one(self, item: Completion) -> None:
        req = self.inflight.pop(item.req_id, None)
        if req is None:
            return
        self.clock.wait_until(item.finish_t)
        self._apply(req)
        req.status = "ok"
        req.finish_t = item.finish_t
        self._event("completed", req_id=req.req_id, tenant=req.tenant, latency=ts(req.latency or 0.0))
        # Free a slot; start the next queued request at this instant.
        if self.queue:
            nxt = self.queue.pop(0)
            self._start(nxt, item.finish_t)

    def advance(self, t: float) -> None:
        """Complete all work due at or before t, then move the clock to t."""
        while self.completions and self.completions[0].finish_t <= t + 1e-12:
            item = heapq.heappop(self.completions)
            self._complete_one(item)
        if t > self.clock.now():
            self.clock.wait_until(t)
            if self.global_bucket:
                self.global_bucket.refill()
            for b in self.tenant_buckets.values():
                b.refill()

    def drain(self) -> None:
        """Run until the queue and in-flight set are empty."""
        while self.completions or self.queue:
            if self.completions:
                item = heapq.heappop(self.completions)
                self._complete_one(item)
            elif self.queue:
                # Should not happen: a queued request needs a free slot,
                # which only appears on completion. If inflight is empty
                # and queue is not, start one.
                nxt = self.queue.pop(0)
                start = max(self.clock.now(), nxt.arrive_t)
                self._start(nxt, start)

    def arrive(self, tenant: str = TENANT_EDITOR, op: str = "GET", key: str = KEY_TITLE, at: Optional[float] = None) -> Request:
        if at is not None:
            self.advance(at)
        self._req_seq += 1
        req = Request(self._req_seq, tenant, op, key, self.clock.now())
        self.requests.append(req)

        tb = self._bucket_for(tenant)
        if tb is not None and not tb.allow():
            req.status = "rejected"
            req.reject_reason = "token_bucket_tenant"
            req.finish_t = req.arrive_t
            self._event("rejected", req_id=req.req_id, tenant=tenant, reason=req.reject_reason)
            return req
        if self.global_bucket is not None and not self.global_bucket.allow():
            req.status = "rejected"
            req.reject_reason = "token_bucket"
            req.finish_t = req.arrive_t
            self._event("rejected", req_id=req.req_id, tenant=tenant, reason=req.reject_reason)
            return req

        if self.max_concurrency is None or len(self.inflight) < self.max_concurrency:
            self._start(req, req.arrive_t)
            return req
        if self.max_queue is None or len(self.queue) < self.max_queue:
            self.queue.append(req)
            self._track_resident()
            self._event("queued", req_id=req.req_id, tenant=tenant, queue_depth=len(self.queue))
            return req
        req.status = "rejected"
        req.reject_reason = "queue_full"
        req.finish_t = req.arrive_t
        self._event("rejected", req_id=req.req_id, tenant=tenant, reason=req.reject_reason, queue_depth=len(self.queue), inflight=len(self.inflight))
        return req

    def run_arrivals(self, arrivals: list[tuple[float, str, str]]) -> None:
        """arrivals: (time, tenant, op). Sorted if needed. Drain at the end."""
        for t, tenant, op in sorted(arrivals, key=lambda x: x[0]):
            self.arrive(tenant=tenant, op=op, at=t)
        self.drain()

    def stats(self, tenant: Optional[str] = None) -> dict[str, Any]:
        recs = [r for r in self.requests if tenant is None or r.tenant == tenant]
        ok = [r for r in recs if r.status == "ok"]
        rejected = [r for r in recs if r.status == "rejected"]
        lats = [r.latency for r in ok if r.latency is not None]
        by_reason: dict[str, int] = {}
        for r in rejected:
            by_reason[r.reject_reason or "unknown"] = by_reason.get(r.reject_reason or "unknown", 0) + 1
        n = len(recs)
        return {
            "n": n,
            "accepted": len(ok),
            "rejected": len(rejected),
            "reject_rate": (len(rejected) / n) if n else 0.0,
            "accept_rate": (len(ok) / n) if n else 0.0,
            "reject_reasons": by_reason,
            "latency_p50": None if not lats else ts(percentile(lats, 50) or 0.0),
            "latency_p99": None if not lats else ts(percentile(lats, 99) or 0.0),
            "latency_max": None if not lats else ts(max(lats)),
            "latency_min": None if not lats else ts(min(lats)),
            "latency_mean": None if not lats else ts(sum(lats) / len(lats)),
            "max_queue_depth": self.max_queue_depth if tenant is None else None,
            "max_inflight": self.max_inflight if tenant is None else None,
            "max_resident": self.max_resident if tenant is None else None,
            "memory_bounded": (self.max_queue is not None and self.max_queue_depth <= self.max_queue) if tenant is None else None,
            "title": self.store.get(KEY_TITLE),
            "t_end": self.now(),
            "flush_count": self.flush_count,
        }

    def snapshot(self) -> dict[str, Any]:
        return {
            "t": self.now(),
            "title": self.store.get(KEY_TITLE),
            "inflight": len(self.inflight),
            "queue_depth": len(self.queue),
            "global_bucket": None if self.global_bucket is None else self.global_bucket.snapshot(),
            "tenant_buckets": {k: v.snapshot() for k, v in self.tenant_buckets.items()},
            "max_queue_depth": self.max_queue_depth,
            "max_inflight": self.max_inflight,
            "max_resident": self.max_resident,
        }


def arrivals_at_rate(qps: float, duration_s: float, tenant: str = TENANT_EDITOR, op: str = "GET", start: float = 0.0) -> list[tuple[float, str, str]]:
    """Evenly spaced arrivals: n = round(qps * duration), first at `start`."""
    if qps <= 0 or duration_s <= 0:
        return []
    n = int(round(qps * duration_s))
    if n <= 0:
        return []
    interval = 1.0 / qps
    return [(start + i * interval, tenant, op) for i in range(n)]


def arrivals_burst(n: int, at: float = 0.0, tenant: str = TENANT_EDITOR, op: str = "GET") -> list[tuple[float, str, str]]:
    return [(at, tenant, op) for _ in range(n)]
