#!/usr/bin/env python3
"""Run the lesson 123 rate-limit / overload-protection experiments."""
from __future__ import annotations

from typing import Any, Optional

from engine import (
    DEFAULT_CONCURRENCY,
    DEFAULT_QUEUE,
    KEY_TITLE,
    SERVICE_TIME_S,
    TENANT_BATCH,
    TENANT_EDITOR,
    TITLE_V1,
    TOKEN_BURST,
    TOKEN_RATE,
    OverloadKVEngine,
    arrivals_at_rate,
    arrivals_burst,
)


def _latencies(eng: OverloadKVEngine, tenant: Optional[str] = None) -> list[float]:
    return [
        r.latency
        for r in eng.requests
        if r.status == "ok" and r.latency is not None and (tenant is None or r.tenant == tenant)
    ]


def run_token_bucket_burst() -> dict[str, Any]:
    """Burst vs sustained refill. Bucket starts full."""
    eng = OverloadKVEngine(
        service_time_s=SERVICE_TIME_S,
        max_concurrency=None,
        max_queue=None,
        token_rate=TOKEN_RATE,
        token_burst=TOKEN_BURST,
    )
    # 6 requests at t=0: burst is 5, sixth rejected.
    first = []
    for _ in range(6):
        r = eng.arrive(tenant=TENANT_EDITOR, op="GET", at=0.0)
        first.append(r.as_dict())
    tokens_after_burst = eng.snapshot()["global_bucket"]["tokens"]
    # After 0.10s, rate 10/s refills 1 token.
    later_ok = eng.arrive(tenant=TENANT_EDITOR, op="GET", at=0.10)
    tokens_after_refill = eng.snapshot()["global_bucket"]["tokens"]
    # Immediately afterwards, empty again.
    later_rej = eng.arrive(tenant=TENANT_EDITOR, op="GET", at=0.10)
    eng.drain()
    # Status may still be "running" before drain; count admission, not completion.
    accepted_at_zero = sum(1 for r in first if r["status"] != "rejected")
    rejected_at_zero = sum(1 for r in first if r["status"] == "rejected")
    return {
        "token_rate": TOKEN_RATE,
        "token_burst": TOKEN_BURST,
        "service_time_s": SERVICE_TIME_S,
        "at_t0": first,
        "accepted_in_burst": accepted_at_zero,
        "rejected_in_burst": rejected_at_zero,
        "tokens_after_burst": tokens_after_burst,
        "after_0_10_accepted": later_ok.status == "ok",
        "after_0_10_rejected_immediately": later_rej.status == "rejected",
        "tokens_after_refill_admit": tokens_after_refill,
        "burst_allows_short_spike_above_rate": accepted_at_zero == int(TOKEN_BURST) and rejected_at_zero == 1,
        "refill_admits_one_after_0_10": later_ok.status == "ok" and later_rej.status == "rejected",
        "t_end": eng.now(),
        "stats": eng.stats(),
    }


def run_token_bucket_sustained() -> dict[str, Any]:
    """1 second at 10 QPS (matches rate) vs 20 QPS (twice the rate) after the burst is spent."""
    def _run(qps: float) -> dict[str, Any]:
        eng = OverloadKVEngine(
            service_time_s=SERVICE_TIME_S,
            max_concurrency=None,
            max_queue=None,
            token_rate=TOKEN_RATE,
            token_burst=TOKEN_BURST,
        )
        eng.run_arrivals(arrivals_at_rate(qps, 1.0, TENANT_EDITOR, "GET"))
        st = eng.stats()
        return {
            "offer_qps": qps,
            "n": st["n"],
            "accepted": st["accepted"],
            "rejected": st["rejected"],
            "reject_rate": st["reject_rate"],
            "t_end": st["t_end"],
        }

    at_rate = _run(10.0)
    above = _run(20.0)
    return {
        "token_rate": TOKEN_RATE,
        "token_burst": TOKEN_BURST,
        "at_rate": at_rate,
        "twice_rate": above,
        "matches_rate_no_reject": at_rate["rejected"] == 0 and at_rate["accepted"] == 10,
        "above_rate_rejects_after_burst": above["rejected"] > 0 and above["accepted"] < above["n"],
    }


def run_qps_is_not_concurrency() -> dict[str, Any]:
    """Same 10 QPS, three service times: in-flight work changes, admission rate does not."""
    rows = []
    for service in (0.05, 0.50, 1.00):
        eng = OverloadKVEngine(
            service_time_s=service,
            max_concurrency=None,  # no concurrency cap
            max_queue=None,
            token_rate=10.0,
            token_burst=10.0,
        )
        eng.run_arrivals(arrivals_at_rate(10.0, 1.0, TENANT_EDITOR, "GET", start=0.0))
        st = eng.stats()
        rows.append({
            "service_time_s": service,
            "offer_qps": 10.0,
            "n": st["n"],
            "accepted": st["accepted"],
            "rejected": st["rejected"],
            "max_inflight": st["max_inflight"],
            "max_resident": st["max_resident"],
            "latency_max": st["latency_max"],
            "t_end": st["t_end"],
            "littles_law_qps_times_service": round(10.0 * service, 2),
        })
    # Inverse: QPS below a 20/s token rate, but concurrency cap=2 and service=0.50
    # needed inflight = 6 QPS * 0.50 = 3 > cap 2, so extras queue/reject.
    slow = OverloadKVEngine(
        service_time_s=0.50,
        max_concurrency=2,
        max_queue=0,  # no queue: overflow rejects immediately
        token_rate=20.0,
        token_burst=20.0,
    )
    slow.run_arrivals(arrivals_at_rate(6.0, 1.0, TENANT_EDITOR, "GET"))
    slow_st = slow.stats()
    return {
        "same_qps_rows": rows,
        "same_qps_all_accepted": all(r["rejected"] == 0 and r["accepted"] == 10 for r in rows),
        "inflight_grows_with_service_time": (
            rows[0]["max_inflight"] < rows[1]["max_inflight"] < rows[2]["max_inflight"]
        ),
        "qps_cap_unchanged": True,  # all three used token_rate=10 and accepted all 10
        "slow_low_qps": {
            "service_time_s": 0.50,
            "offer_qps": 6.0,
            "token_rate": 20.0,
            "max_concurrency": 2,
            "max_queue": 0,
            **{k: slow_st[k] for k in ("n", "accepted", "rejected", "reject_rate", "max_inflight", "latency_max", "t_end")},
        },
        "low_qps_still_rejects_when_concurrency_saturated": slow_st["rejected"] > 0 and slow_st["max_inflight"] == 2,
        "qps_limit_is_not_concurrency_limit": True,
    }


def _offer_series(*, max_concurrency: Optional[int], max_queue: Optional[int], rates: list[float], duration: float = 1.0) -> list[dict[str, Any]]:
    rows = []
    for qps in rates:
        eng = OverloadKVEngine(
            service_time_s=SERVICE_TIME_S,
            max_concurrency=max_concurrency,
            max_queue=max_queue,
        )
        eng.run_arrivals(arrivals_at_rate(qps, duration, TENANT_EDITOR, "GET"))
        st = eng.stats()
        rows.append({
            "offer_qps": qps,
            "duration_s": duration,
            "capacity_qps": (max_concurrency / SERVICE_TIME_S) if max_concurrency else None,
            "n": st["n"],
            "accepted": st["accepted"],
            "rejected": st["rejected"],
            "reject_rate": st["reject_rate"],
            "latency_p50": st["latency_p50"],
            "latency_p99": st["latency_p99"],
            "latency_max": st["latency_max"],
            "latency_mean": st["latency_mean"],
            "max_queue_depth": st["max_queue_depth"],
            "max_inflight": st["max_inflight"],
            "max_resident": st["max_resident"],
            "memory_bounded": st["memory_bounded"],
            "t_end": st["t_end"],
        })
    return rows


def _ascii_chart(rows: list[dict[str, Any]], title: str) -> str:
    lines = [title, "offer  accept  reject  rej%   p50    p99    max    qmax  resident"]
    for r in rows:
        lines.append(
            f"{r['offer_qps']:5.0f}  {r['accepted']:6d}  {r['rejected']:6d}  {r['reject_rate']*100:5.1f}  "
            f"{r['latency_p50'] or 0:5.2f}  {r['latency_p99'] or 0:5.2f}  {r['latency_max'] or 0:5.2f}  "
            f"{r['max_queue_depth']:4d}  {r['max_resident']:8d}"
        )
    return "\n".join(lines)


def run_overload_curves() -> dict[str, Any]:
    """The official practice: cap concurrency and queue, plot latency and reject rate under overload."""
    rates = [10.0, 20.0, 30.0, 40.0, 50.0]
    capped = _offer_series(max_concurrency=DEFAULT_CONCURRENCY, max_queue=DEFAULT_QUEUE, rates=rates)
    unbounded = _offer_series(max_concurrency=DEFAULT_CONCURRENCY, max_queue=None, rates=rates)
    # Also a same-time burst of 40 against the same caps, as a worst-case memory spike.
    burst_capped = OverloadKVEngine(service_time_s=SERVICE_TIME_S, max_concurrency=2, max_queue=4)
    burst_capped.run_arrivals(arrivals_burst(40, at=0.0, tenant=TENANT_EDITOR, op="GET"))
    burst_unb = OverloadKVEngine(service_time_s=SERVICE_TIME_S, max_concurrency=2, max_queue=None)
    burst_unb.run_arrivals(arrivals_burst(40, at=0.0, tenant=TENANT_EDITOR, op="GET"))
    cap40 = next(r for r in capped if r["offer_qps"] == 40.0)
    unb40 = next(r for r in unbounded if r["offer_qps"] == 40.0)
    cap10 = next(r for r in capped if r["offer_qps"] == 10.0)
    return {
        "service_time_s": SERVICE_TIME_S,
        "max_concurrency": DEFAULT_CONCURRENCY,
        "max_queue": DEFAULT_QUEUE,
        "capacity_qps": DEFAULT_CONCURRENCY / SERVICE_TIME_S,
        "rates": rates,
        "capped": capped,
        "unbounded": unbounded,
        "chart_capped": _ascii_chart(capped, "capped concurrency=2 queue=4, service=0.10, duration=1.0"),
        "chart_unbounded": _ascii_chart(unbounded, "unbounded queue, concurrency=2, service=0.10, duration=1.0"),
        "burst40_capped": burst_capped.stats(),
        "burst40_unbounded": burst_unb.stats(),
        "below_capacity_no_reject": cap10["rejected"] == 0 and cap10["latency_max"] == SERVICE_TIME_S,
        "overload_capped_rejects": cap40["rejected"] > 0,
        "overload_unbounded_zero_reject": unb40["rejected"] == 0,
        "overload_capped_latency_below_unbounded": cap40["latency_max"] < unb40["latency_max"],
        "overload_memory_bounded": all(r["memory_bounded"] and r["max_queue_depth"] <= DEFAULT_QUEUE for r in capped),
        "overload_unbounded_queue_grows": unb40["max_queue_depth"] > DEFAULT_QUEUE,
        "burst_capped_resident_at_cap": burst_capped.max_resident == DEFAULT_CONCURRENCY + DEFAULT_QUEUE,
        "burst_unbounded_resident_all": burst_unb.max_resident == 40 and burst_unb.stats()["rejected"] == 0,
        "rejected_to_keep_accepted_timely": cap40["latency_max"] < unb40["latency_max"] and cap40["rejected"] > 0,
    }


def run_unbounded_queue_pitfall() -> dict[str, Any]:
    """Queue without a cap to chase zero rejects: latency and memory grow."""
    # 40 QPS for 1s against capacity 20/s, unbounded queue.
    unb = OverloadKVEngine(service_time_s=SERVICE_TIME_S, max_concurrency=2, max_queue=None)
    unb.run_arrivals(arrivals_at_rate(40.0, 1.0, TENANT_EDITOR, "GET"))
    cap = OverloadKVEngine(service_time_s=SERVICE_TIME_S, max_concurrency=2, max_queue=4)
    cap.run_arrivals(arrivals_at_rate(40.0, 1.0, TENANT_EDITOR, "GET"))
    us, cs = unb.stats(), cap.stats()
    return {
        "unbounded": us,
        "capped": cs,
        "zero_rejects_unbounded": us["rejected"] == 0,
        "capped_has_rejects": cs["rejected"] > 0,
        "unbounded_slower": us["latency_max"] > cs["latency_max"],
        "unbounded_queue_unbounded": us["max_queue_depth"] > cs["max_queue_depth"],
        "capped_memory_bounded": cs["memory_bounded"] and cs["max_queue_depth"] <= 4,
        "pitfall_queue_without_cap_for_zero_rejects": us["rejected"] == 0 and us["max_queue_depth"] > 4 and us["latency_max"] > cs["latency_max"],
    }


def run_tenant_fairness() -> dict[str, Any]:
    """Batch noisy neighbor vs editor: one shared token bucket vs per-tenant buckets.

    A shared FIFO concurrency/queue cap does not by itself starve a lower-rate
    tenant whose arrivals are evenly spaced. The isolation contrast is a
    shared admission bucket (SRE-style per-customer quota, but here a single
    global bucket) versus a bucket per tenant.
    """
    duration = 1.0
    arrivals = arrivals_at_rate(40.0, duration, TENANT_BATCH, "GET") + arrivals_at_rate(10.0, duration, TENANT_EDITOR, "GET")
    # One shared token bucket: batch arrives more often and consumes most tokens.
    shared = OverloadKVEngine(
        service_time_s=SERVICE_TIME_S,
        max_concurrency=None,
        max_queue=None,
        token_rate=10.0,
        token_burst=5.0,
    )
    shared.run_arrivals(list(arrivals))
    # Per-tenant token buckets: each 10/s, burst 5.
    fair = OverloadKVEngine(
        service_time_s=SERVICE_TIME_S,
        max_concurrency=None,
        max_queue=None,
        per_tenant_rate=10.0,
        per_tenant_burst=5.0,
    )
    fair.run_arrivals(list(arrivals))
    s_ed, s_ba = shared.stats(TENANT_EDITOR), shared.stats(TENANT_BATCH)
    f_ed, f_ba = fair.stats(TENANT_EDITOR), fair.stats(TENANT_BATCH)
    return {
        "editor_offer_qps": 10.0,
        "batch_offer_qps": 40.0,
        "duration_s": duration,
        "shared": {"all": shared.stats(), "editor": s_ed, "batch": s_ba},
        "fair": {"all": fair.stats(), "editor": f_ed, "batch": f_ba},
        "shared_editor_accepted": s_ed["accepted"],
        "shared_batch_accepted": s_ba["accepted"],
        "fair_editor_accepted": f_ed["accepted"],
        "fair_batch_accepted": f_ba["accepted"],
        "shared_editor_starved": s_ed["accepted"] < s_ed["n"] and s_ed["accepted"] < f_ed["accepted"],
        "fair_editor_keeps_more": f_ed["accepted"] > s_ed["accepted"],
        "fair_editor_all_accepted": f_ed["accepted"] == f_ed["n"] and f_ed["rejected"] == 0,
        "fair_batch_still_limited": f_ba["accepted"] < f_ba["n"] and f_ba["rejected"] > 0,
        "tenant_fairness_protects_editor": f_ed["accepted"] == f_ed["n"] and s_ed["accepted"] < f_ed["accepted"],
    }


def run() -> dict[str, Any]:
    burst = run_token_bucket_burst()
    sustained = run_token_bucket_sustained()
    qps = run_qps_is_not_concurrency()
    curves = run_overload_curves()
    pit = run_unbounded_queue_pitfall()
    fair = run_tenant_fairness()
    return {
        "engine": "OverloadKVEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_gateway": True,
        "not_a_limiter_product": True,
        "not_google_sre_production": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "service_time_s": SERVICE_TIME_S,
        "token_bucket_burst": burst,
        "token_bucket_sustained": sustained,
        "qps_is_not_concurrency": qps,
        "overload_curves": curves,
        "unbounded_queue_pitfall": pit,
        "tenant_fairness": fair,
        "acceptance_qps_is_not_concurrency": qps["same_qps_all_accepted"]
        and qps["inflight_grows_with_service_time"]
        and qps["low_qps_still_rejects_when_concurrency_saturated"],
        "acceptance_memory_bounded_under_overload": curves["overload_memory_bounded"]
        and curves["burst_capped_resident_at_cap"]
        and pit["capped_memory_bounded"],
        "practice_overload_latency_and_reject_rate": curves["overload_capped_rejects"]
        and curves["overload_unbounded_zero_reject"]
        and curves["overload_capped_latency_below_unbounded"]
        and curves["below_capacity_no_reject"],
        "pitfall_queue_without_cap_for_zero_rejects": pit["pitfall_queue_without_cap_for_zero_rejects"],
        "tradeoff_reject_to_keep_accepted_timely": curves["rejected_to_keep_accepted_timely"]
        and pit["unbounded_slower"],
        "tenant_fairness_protects_editor": fair["tenant_fairness_protects_editor"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
    print(r["overload_curves"]["chart_capped"])
    print()
    print(r["overload_curves"]["chart_unbounded"])
