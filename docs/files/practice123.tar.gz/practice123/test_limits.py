#!/usr/bin/env python3
"""Acceptance checks for the lesson 123 rate-limit / overload experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import DEFAULT_CONCURRENCY, DEFAULT_QUEUE, KEY_TITLE, SERVICE_TIME_S, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "OverloadKVEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_gateway"] and r["not_a_limiter_product"]
    assert r["not_google_sre_production"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["service_time_s"] == SERVICE_TIME_S == 0.10

    burst = r["token_bucket_burst"]
    assert burst["token_rate"] == 10.0 and burst["token_burst"] == 5
    assert burst["accepted_in_burst"] == 5 and burst["rejected_in_burst"] == 1
    assert burst["tokens_after_burst"] == 0.0
    assert burst["after_0_10_accepted"] and burst["after_0_10_rejected_immediately"]
    assert burst["burst_allows_short_spike_above_rate"]
    assert burst["refill_admits_one_after_0_10"]
    assert burst["stats"]["accepted"] == 6 and burst["stats"]["rejected"] == 2

    sus = r["token_bucket_sustained"]
    assert sus["matches_rate_no_reject"]
    assert sus["at_rate"]["accepted"] == 10 and sus["at_rate"]["rejected"] == 0
    assert sus["twice_rate"]["n"] == 20
    assert sus["twice_rate"]["accepted"] == 14 and sus["twice_rate"]["rejected"] == 6
    assert sus["above_rate_rejects_after_burst"]

    qps = r["qps_is_not_concurrency"]
    rows = qps["same_qps_rows"]
    assert qps["same_qps_all_accepted"]
    assert [row["max_inflight"] for row in rows] == [1, 5, 10]
    assert [row["service_time_s"] for row in rows] == [0.05, 0.50, 1.00]
    assert qps["inflight_grows_with_service_time"]
    slow = qps["slow_low_qps"]
    assert slow["offer_qps"] == 6.0 and slow["token_rate"] == 20.0
    assert slow["accepted"] == 4 and slow["rejected"] == 2 and slow["max_inflight"] == 2
    assert qps["low_qps_still_rejects_when_concurrency_saturated"]

    curves = r["overload_curves"]
    assert curves["max_concurrency"] == DEFAULT_CONCURRENCY == 2
    assert curves["max_queue"] == DEFAULT_QUEUE == 4
    assert curves["capacity_qps"] == 20.0
    cap = {row["offer_qps"]: row for row in curves["capped"]}
    unb = {row["offer_qps"]: row for row in curves["unbounded"]}
    assert cap[10.0]["rejected"] == 0 and cap[10.0]["latency_max"] == 0.10
    assert cap[20.0]["rejected"] == 0 and cap[20.0]["accepted"] == 20
    assert cap[30.0]["accepted"] == 24 and cap[30.0]["rejected"] == 6
    assert cap[30.0]["latency_max"] == 0.30 and cap[30.0]["max_queue_depth"] == 4
    assert cap[40.0]["accepted"] == 24 and cap[40.0]["rejected"] == 16
    assert cap[40.0]["reject_rate"] == 0.4 and cap[40.0]["latency_max"] == 0.30
    assert cap[50.0]["accepted"] == 24 and cap[50.0]["rejected"] == 26
    assert cap[50.0]["max_resident"] == 6
    assert unb[40.0]["rejected"] == 0 and unb[40.0]["accepted"] == 40
    assert unb[40.0]["latency_max"] == 1.05 and unb[40.0]["max_queue_depth"] == 20
    assert unb[50.0]["latency_max"] == 1.54 and unb[50.0]["max_queue_depth"] == 30
    assert curves["below_capacity_no_reject"]
    assert curves["overload_capped_rejects"]
    assert curves["overload_unbounded_zero_reject"]
    assert curves["overload_capped_latency_below_unbounded"]
    assert curves["overload_memory_bounded"]
    bc = curves["burst40_capped"]
    bu = curves["burst40_unbounded"]
    assert bc["accepted"] == 6 and bc["rejected"] == 34 and bc["max_resident"] == 6
    assert bc["latency_max"] == 0.30
    assert bu["accepted"] == 40 and bu["rejected"] == 0 and bu["max_resident"] == 40
    assert bu["latency_max"] == 2.0 and bu["max_queue_depth"] == 38

    pit = r["unbounded_queue_pitfall"]
    assert pit["zero_rejects_unbounded"] and pit["capped_has_rejects"]
    assert pit["unbounded"]["max_queue_depth"] == 20
    assert pit["capped"]["max_queue_depth"] == 4 and pit["capped"]["rejected"] == 16
    assert pit["unbounded"]["latency_max"] == 1.05
    assert pit["capped"]["latency_max"] == 0.30
    assert pit["pitfall_queue_without_cap_for_zero_rejects"]

    fair = r["tenant_fairness"]
    assert fair["shared_editor_accepted"] == 1 and fair["shared_batch_accepted"] == 13
    assert fair["fair_editor_accepted"] == 10 and fair["fair_batch_accepted"] == 14
    assert fair["shared_editor_starved"] and fair["fair_editor_all_accepted"]
    assert fair["fair_batch_still_limited"]
    assert fair["tenant_fairness_protects_editor"]

    assert r["acceptance_qps_is_not_concurrency"]
    assert r["acceptance_memory_bounded_under_overload"]
    assert r["practice_overload_latency_and_reject_rate"]
    assert r["pitfall_queue_without_cap_for_zero_rejects"]
    assert r["tradeoff_reject_to_keep_accepted_timely"]
    assert r["tenant_fairness_protects_editor"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
