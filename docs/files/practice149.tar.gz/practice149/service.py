"""Tiny teaching KV handler with structured request logs."""
from __future__ import annotations

import time
from logger import AsyncLogger


class KVService:
    def __init__(self, logger: AsyncLogger):
        self.logger = logger
        self.store = {"theme": "dark", "retry": "1"}

    def handle(self, op: str, key: str, value: str | None, *, trace_id: str, user: str, token: str) -> dict:
        t0 = time.perf_counter()
        status = "ok"
        if op == "GET":
            found = self.store.get(key)
            result = {"ok": True, "value": found}
            if found is None:
                status = "miss"
        elif op == "SET":
            self.store[key] = value or ""
            result = {"ok": True}
        else:
            status = "bad_request"
            result = {"ok": False}
        latency_ms = round((time.perf_counter() - t0) * 1000, 3)
        outcome = self.logger.emit(
            "INFO",
            "kv.request",
            trace_id=trace_id,
            latency_ms=latency_ms,
            status=status,
            attrs={"op": op, "key": key, "user": user, "token": token},
        )
        result["log"] = outcome
        result["status"] = status
        result["latency_ms"] = latency_ms
        result["trace_id"] = trace_id
        return result
