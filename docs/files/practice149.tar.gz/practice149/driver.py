#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

from logger import SCHEMA, AsyncLogger, BlockingLogger, FileSink
from service import KVService

ROOT = Path(__file__).resolve().parent
(ROOT / "reports").mkdir(exist_ok=True)
results = {}


def load_lines(path: Path):
    if not path.exists() or path.stat().st_size == 0:
        return []
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def main():
    work = Path(tempfile.mkdtemp(prefix="practice149-"))
    log_path = work / "kv.jsonl"

    # 1. happy path schema + redaction
    sink = FileSink(str(log_path))
    logger = AsyncLogger(sink, max_queue=64, enqueue_timeout_s=0.05)
    svc = KVService(logger)
    r1 = svc.handle("SET", "theme", "light", trace_id="4bf92f3577b34da6a3ce929d0e0e4736", user="alice@example.com", token="s3cret-token")
    r2 = svc.handle("GET", "theme", None, trace_id="4bf92f3577b34da6a3ce929d0e0e4736", user="alice@example.com", token="s3cret-token")
    logger.close()
    lines = load_lines(log_path)
    assert r1["ok"] and r2["ok"] and r2["value"] == "light"
    assert len(lines) >= 2
    for rec in lines:
        assert tuple(rec.keys()) == SCHEMA
        attrs = rec["attrs"]
        assert attrs.get("token") == "[REDACTED]"
        assert "s3cret-token" not in json.dumps(rec)
        assert "alice@example.com" not in json.dumps(rec)
        assert rec["trace_id"] == "4bf92f3577b34da6a3ce929d0e0e4736"
        assert rec["event"] == "kv.request"
        assert rec["latency_ms"] is not None
        assert rec["status"] in {"ok", "miss", "bad_request"}
    print(f"schema_ok records={len(lines)} keys={list(lines[0].keys())} token={lines[0]['attrs']['token']} user={lines[0]['attrs']['user']}")
    (ROOT / "reports" / "schema-sample.jsonl").write_text(
        "\n".join(json.dumps(rec, ensure_ascii=False, separators=(",", ":")) for rec in lines) + "\n"
    )
    results["schema_records"] = len(lines)
    results["redacted_token"] = True
    results["user_truncated"] = lines[0]["attrs"]["user"]

    # Retention policy (teaching): keep only the last N records in a file.
    retain_src = work / "retain.jsonl"
    retain_src.write_text(
        "\n".join(json.dumps({"n": i, "event": "old"}) for i in range(5)) + "\n",
        encoding="utf-8",
    )
    keep = 2
    kept = retain_src.read_text(encoding="utf-8").splitlines()[-keep:]
    retain_dst = ROOT / "reports" / "retained.jsonl"
    retain_dst.write_text("\n".join(kept) + "\n")
    results["retention_keep"] = keep
    results["retention_before"] = 5
    results["retention_after"] = len(kept)
    assert len(kept) == keep

    # 2. disk-full: async drop, request still returns
    tiny = FileSink(str(work / "full.jsonl"), quota_bytes=400)
    clog = AsyncLogger(tiny, max_queue=4, enqueue_timeout_s=0.02)
    csvc = KVService(clog)
    t0 = time.perf_counter()
    outcomes = []
    statuses = []
    for i in range(20):
        rec = csvc.handle("GET", "theme", None, trace_id=f"trace-{i:02d}", user="bob", token="x")
        outcomes.append(rec["log"])
        statuses.append(rec["ok"])
    blocked_s = time.perf_counter() - t0
    clog.close()
    assert all(statuses), "requests must complete despite log failures"
    assert blocked_s < 1.0, f"request path blocked too long: {blocked_s}"
    full_lines=len(load_lines(work / "full.jsonl"))
    print(f"disk_full async: written={clog.written} dropped={clog.dropped} errors={clog.errors} file_lines={full_lines} elapsed={blocked_s:.4f}s")
    results["async_file_lines"] = full_lines
    results["async_written"] = clog.written
    results["async_dropped"] = clog.dropped
    results["async_errors"] = clog.errors
    results["async_elapsed_s"] = round(blocked_s, 4)
    assert clog.dropped >= 1

    # 3. anti-pattern: sync logger blocks on disk full
    tiny2 = FileSink(str(work / "sync.jsonl"), quota_bytes=40)
    blog = BlockingLogger(tiny2, block_s=0.15)
    t1 = time.perf_counter()
    blocked_n = 0
    for i in range(8):
        try:
            blog.emit({"event": "kv.request", "i": i, "payload": "x" * 20})
        except OSError:
            blocked_n += 1
    sync_s = time.perf_counter() - t1
    print(f"disk_full sync: written={blog.written} blocked_n={blocked_n} elapsed={sync_s:.4f}s")
    results["sync_written"] = blog.written
    results["sync_blocked_n"] = blocked_n
    results["sync_elapsed_s"] = round(sync_s, 4)
    assert blocked_n >= 1
    assert sync_s > results["async_elapsed_s"]

    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("FAIL:", type(e).__name__, e, file=sys.stderr)
        raise
