"""Teaching structured logger: schema, async drop, redaction. Not a production logger."""
from __future__ import annotations

import json
import os
import queue
import threading
import time
from datetime import datetime, timezone, timedelta

BJ = timezone(timedelta(hours=8))
SCHEMA = ("ts", "severity", "event", "trace_id", "latency_ms", "status", "attrs")
SECRET_KEYS = {"password", "token", "api_key", "secret", "authorization"}
MAX_USER_CHARS = 8


class DiskFull(OSError):
    def __init__(self, path: str):
        super().__init__(28, "No space left on device", path)


class FileSink:
    def __init__(self, path: str, quota_bytes: int | None = None):
        self.path = path
        self.quota_bytes = quota_bytes
        self.written = 0
        self.fail_next = False
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        # start empty
        open(self.path, "w", encoding="utf-8").close()

    def write_line(self, line: str) -> None:
        data = (line + "\n").encode("utf-8")
        if self.fail_next:
            self.fail_next = False
            raise DiskFull(self.path)
        if self.quota_bytes is not None and self.written + len(data) > self.quota_bytes:
            raise DiskFull(self.path)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()
        self.written += len(data)


def redact(attrs: dict) -> dict:
    out = {}
    for k, v in attrs.items():
        lk = str(k).lower()
        if lk in SECRET_KEYS or any(s in lk for s in ("password", "token", "secret")):
            out[k] = "[REDACTED]"
        elif lk in {"email", "user", "username", "user_data", "profile"}:
            s = str(v)
            out[k] = (s[:MAX_USER_CHARS] + "…") if len(s) > MAX_USER_CHARS else s
        else:
            out[k] = v
    return out


class AsyncLogger:
    def __init__(self, sink: FileSink, max_queue: int = 32, enqueue_timeout_s: float = 0.02):
        self.sink = sink
        self.queue: queue.Queue = queue.Queue(maxsize=max_queue)
        self.enqueue_timeout_s = enqueue_timeout_s
        self.dropped = 0
        self.written = 0
        self.errors = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, name="log-writer", daemon=True)
        self._thread.start()

    def emit(self, severity: str, event: str, *, trace_id: str = "", latency_ms=None, status=None, attrs=None) -> str:
        rec = {
            "ts": datetime.now(BJ).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+08:00",
            "severity": severity,
            "event": event,
            "trace_id": trace_id or "",
            "latency_ms": latency_ms,
            "status": status,
            "attrs": redact(attrs or {}),
        }
        # only schema keys
        rec = {k: rec[k] for k in SCHEMA}
        try:
            self.queue.put(rec, timeout=self.enqueue_timeout_s)
            return "enqueued"
        except queue.Full:
            self.dropped += 1
            return "dropped"

    def _run(self):
        while not self._stop.is_set() or not self.queue.empty():
            try:
                rec = self.queue.get(timeout=0.05)
            except queue.Empty:
                continue
            try:
                self.sink.write_line(json.dumps(rec, ensure_ascii=False, separators=(",", ":")))
                self.written += 1
            except OSError:
                self.errors += 1
                self.dropped += 1
            finally:
                self.queue.task_done()

    def close(self, timeout: float = 2.0):
        self._stop.set()
        self._thread.join(timeout=timeout)


class BlockingLogger:
    """Anti-pattern: sync write on the request path; disk-full blocks."""

    def __init__(self, sink: FileSink, block_s: float = 0.3):
        self.sink = sink
        self.block_s = block_s
        self.written = 0

    def emit(self, line_obj: dict) -> None:
        try:
            self.sink.write_line(json.dumps(line_obj, ensure_ascii=False))
            self.written += 1
        except OSError:
            time.sleep(self.block_s)
            raise
