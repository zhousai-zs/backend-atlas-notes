#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec > >(tee run.log) 2>&1
mkdir -p reports build
if command -v g++ >/dev/null 2>&1; then CXX=$(command -v g++); zig=0
elif command -v clang++ >/dev/null 2>&1; then CXX=$(command -v clang++); zig=0
else CXX="$PWD/tools/zig-c++"; zig=1; fi
"$CXX" --version | head -n 3
flags=(-std=c++17 -g -O1 -fno-omit-frame-pointer -pthread)
extra=(); asan=(); ubsan=(); tsan=()
if (( zig )); then
  extra=(-target x86_64-linux-gnu)
  for lib in asan ubsan tsan; do
    path=$(python3 -c 'import glob,sys; p=glob.glob("/usr/lib/x86_64-linux-gnu/lib"+sys.argv[1]+".so.*"); print(sorted(p, key=len)[0] if p else "")' "$lib")
    if [[ -z "$path" ]]; then echo "Missing system lib${lib} runtime"; exit 1; fi
    case "$lib" in asan) asan=("$path");; ubsan) ubsan=("$path");; tsan) tsan=("$path");; esac
  done
fi
printf 'target: '; if (( zig )); then echo x86_64-linux-gnu; else "$CXX" -dumpmachine; fi
set -x
"$CXX" "${extra[@]}" "${flags[@]}" -fsanitize=address cache.cpp "${asan[@]}" -o build/asan
"$CXX" "${extra[@]}" "${flags[@]}" -fsanitize=undefined -fno-sanitize-recover=undefined cache.cpp "${ubsan[@]}" -o build/ubsan
"$CXX" "${extra[@]}" "${flags[@]}" cache.cpp -o build/plain
set +x
export ASAN_OPTIONS=detect_leaks=0
for case in uaf bounds; do
  set +e; ./build/asan "$case" bad >"reports/asan-${case}.txt" 2>&1; rc=$?; set -e
  echo "asan $case bad exit=$rc"; [[ $rc -ne 0 ]]; grep -q "ERROR: AddressSanitizer: heap-" "reports/asan-${case}.txt"
  ./build/asan "$case" fixed >"reports/asan-${case}-fixed.txt" 2>&1
  ! grep -q 'ERROR: AddressSanitizer' "reports/asan-${case}-fixed.txt"
done
set +e; ./build/ubsan overflow bad >reports/ubsan-overflow.txt 2>&1; rc=$?; set -e
echo "ubsan overflow bad exit=$rc"; [[ $rc -ne 0 ]]; grep -q 'signed integer overflow' reports/ubsan-overflow.txt
./build/ubsan overflow fixed >reports/ubsan-overflow-fixed.txt 2>&1
! grep -Eq 'runtime error:|panic:' reports/ubsan-overflow-fixed.txt
# ASan does not check signed overflow. The defect remains present.
./build/asan overflow bad >reports/asan-overflow-control.txt 2>&1
! grep -q 'ERROR: AddressSanitizer' reports/asan-overflow-control.txt
set +e
"$CXX" "${extra[@]}" "${flags[@]}" -fsanitize=thread cache.cpp "${tsan[@]}" -o build/tsan >reports/tsan-build.txt 2>&1
build_rc=$?
if (( build_rc == 0 )); then
  TSAN_OPTIONS=halt_on_error=1 ./build/tsan race bad >reports/tsan-race.txt 2>&1; race_rc=$?
  if grep -q 'WARNING: ThreadSanitizer: data race' reports/tsan-race.txt; then
    TSAN_OPTIONS=halt_on_error=1 ./build/tsan race fixed >reports/tsan-race-fixed.txt 2>&1; fixed_rc=$?
    [[ $race_rc -ne 0 && $fixed_rc -eq 0 ]] || exit 1
    ! grep -q 'WARNING: ThreadSanitizer' reports/tsan-race-fixed.txt || exit 1
    tsan_status=detected
  else
    [[ $race_rc -ne 0 ]] || { echo 'TSan missed race without an error'; exit 1; }
    tsan_status=runtime_unavailable
  fi
else tsan_status=build_unavailable; race_rc=-1; fi
set -e
echo "tsan build exit=$build_rc race exit=$race_rc status=$tsan_status"
python3 - <<'PYTIME'
import json, subprocess, time
result = {}
for variant in ('plain', 'asan'):
    start = time.perf_counter()
    run = subprocess.run([f'./build/{variant}', 'bench', 'fixed'], capture_output=True, text=True, check=True)
    elapsed = time.perf_counter() - start
    assert run.stdout.strip() == 'sum=820000000'
    result[variant] = round(elapsed, 6)
    with open(f'reports/{variant}-bench.txt', 'w') as f: f.write(run.stdout)
with open('reports/timing.json', 'w') as f: json.dump(result, f); f.write('\n')
print('elapsed seconds:', json.dumps(result))
PYTIME
python3 - "$CXX" "$zig" "$tsan_status" "$build_rc" "$race_rc" <<'PY'
import json, sys
cxx,zig,status,build,race=sys.argv[1:]
result={'compiler':cxx,'zig_fallback':bool(int(zig)),'target': 'x86_64-linux-gnu' if int(zig) else 'see run.log', 'asan_uaf':'detected_and_fixed','asan_bounds':'detected_and_fixed','ubsan_overflow':'detected_and_fixed','asan_overflow_control':'no_report_defect_remains','tsan':status,'tsan_build_exit':int(build),'tsan_race_exit':int(race),'elapsed_seconds':json.load(open('reports/timing.json'))}
with open('results.json','w') as f: json.dump(result,f,indent=2); f.write('\n')
print(json.dumps(result,ensure_ascii=False))
PY
echo ALL_CHECKS_PASSED
