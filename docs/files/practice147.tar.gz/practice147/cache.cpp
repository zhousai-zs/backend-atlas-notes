#include <climits>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>

__attribute__((noinline)) int stale(bool fixed) {
    int *entry = new int(42);
    if (fixed) { int value = *entry; delete entry; return value; }
    delete entry;
    return *entry;
}
__attribute__((noinline)) int bounds(bool fixed) {
    char *buf = new char[8]{};
    volatile int index = fixed ? 7 : 8;
    buf[index] = 'x';
    int value = buf[fixed ? 7 : 0];
    delete[] buf;
    return value;
}
__attribute__((noinline)) int overflow(bool fixed) {
    volatile int n = INT_MAX;
    if (fixed) return n - 1;
    return n + 1;
}
int counter = 0;
std::mutex lock;
void increment(bool fixed) {
    for (int i = 0; i < 10000; ++i) {
        if (fixed) { std::lock_guard<std::mutex> guard(lock); ++counter; }
        else ++counter;
    }
}
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    bool fixed = std::strcmp(argv[2], "fixed") == 0;
    if (std::strcmp(argv[1], "uaf") == 0) std::printf("value=%d\n", stale(fixed));
    else if (std::strcmp(argv[1], "bounds") == 0) std::printf("value=%d\n", bounds(fixed));
    else if (std::strcmp(argv[1], "overflow") == 0) std::printf("value=%d\n", overflow(fixed));
    else if (std::strcmp(argv[1], "race") == 0) {
        std::thread a(increment, fixed), b(increment, fixed);
        a.join(); b.join();
        std::printf("counter=%d\n", counter);
        if (fixed && counter != 20000) return 3;
    } else if (std::strcmp(argv[1], "bench") == 0) {
        int *values = new int[1000000]{};
        long long sum = 0;
        for (int j = 0; j < 40; ++j)
            for (int i = 0; i < 1000000; ++i) { values[i] += 1; sum += values[i]; }
        delete[] values;
        std::printf("sum=%lld\n", sum);
    } else return 2;
}
