#!/usr/bin/env python3
"""Run the lesson 135 teaching eBPF experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import (
    BPF_STACK_LIMIT_BYTES,
    DECLARED_PRIVILEGES,
    HOST_UNAME_R,
    KEY_TITLE,
    MEASURE_S,
    N_REQ,
    PERF_RB_PAGES_DEFAULT,
    PROCESS,
    TEACHING_KERNEL,
    TITLE_V1,
    EbpfEngine,
)


def run() -> dict[str, Any]:
    eng = EbpfEngine()
    cmp = eng.compare()
    return {
        "engine": "EbpfEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "measure_s": MEASURE_S,
        "n_req": N_REQ,
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_ebpf_product": True,
        "not_host_bpf": True,
        "not_host_bpftrace": True,
        "not_host_bcc": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "declaration": cmp["declaration"],
        "declared_kernel_version": TEACHING_KERNEL,
        "declared_privileges": DECLARED_PRIVILEGES,
        "host_uname_r": HOST_UNAME_R,
        "workload": cmp["workload"],
        "map_hist": cmp["map_hist"],
        "per_event_printf": cmp["per_event_printf"],
        "verifier": cmp["verifier"],
        "attach": cmp["attach"],
        "perf_rb_pages_default": PERF_RB_PAGES_DEFAULT,
        "bpf_stack_limit_bytes": BPF_STACK_LIMIT_BYTES,
        "flags": {
            "declared_kernel_and_privileges": cmp["declared_kernel_and_privileges"],
            "avoids_per_event_print": cmp["avoids_per_event_print"],
            "not_zero_overhead": cmp["not_zero_overhead"],
            "kprobe_less_stable_than_tracepoint": cmp["kprobe_less_stable_than_tracepoint"],
            "verifier_rejects_unbounded": cmp["verifier_rejects_unbounded"],
            "map_hist_records_all": cmp["map_hist_records_all"],
        },
        "acceptance_declared_kernel_and_privileges": cmp["declared_kernel_and_privileges"],
        "acceptance_avoids_per_event_print": cmp["avoids_per_event_print"],
        "pitfall_not_zero_overhead": cmp["not_zero_overhead"],
        "tradeoff_kprobe_less_stable_than_tracepoint": cmp["kprobe_less_stable_than_tracepoint"],
    }


if __name__ == "__main__":
    run()
