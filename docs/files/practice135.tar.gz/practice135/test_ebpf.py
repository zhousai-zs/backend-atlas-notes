#!/usr/bin/env python3
"""Acceptance checks for the lesson 135 teaching eBPF experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, PROCESS, TEACHING_KERNEL, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "EbpfEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["n_req"] == 30_000
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_ebpf_product"]
    assert r["not_host_bpf"] and r["not_host_bpftrace"] and r["not_host_bcc"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]

    d = r["declaration"]
    assert d["declared_kernel_version"] == TEACHING_KERNEL == "6.8.0-teach"
    assert d["declared_privileges"] == "CAP_BPF, CAP_PERFMON"
    assert d["declaration_is_teaching"] is True
    assert d["host_uname_r"] == "6.12.113+"
    assert d["host_uid"] == 1000
    assert d["host_bpf_program_loaded"] is False
    assert d["host_bpftrace_invoked"] is False
    assert d["host_bcc_invoked"] is False
    assert r["acceptance_declared_kernel_and_privileges"]

    w = r["workload"]
    assert w["throughput_rps"] == 1000.0
    assert w["n_events"] == 66_000
    assert w["syscalls"]["recvfrom"]["n_events"] == 30_000
    assert w["syscalls"]["recvfrom"]["lat_us_counts"] == {8: 27_000, 32: 2_700, 256: 300}
    assert w["syscalls"]["sendto"]["lat_us_counts"] == {4: 30_000}
    assert w["syscalls"]["futex"]["lat_us_counts"] == {128: 6_000}

    h = r["map_hist"]
    assert h["mode"] == "map_hist"
    assert h["n_events_recorded"] == 66_000
    assert h["dropped_events"] == 0
    assert h["lost_map_updates"] == 0
    assert h["drop_share"] == 0.0
    assert h["userspace_records"] == 5
    assert h["overhead_us"] == 66_000
    assert h["hist"]["recvfrom"] == {"[8, 16)": 27_000, "[32, 64)": 2_700, "[256, 512)": 300}
    assert h["hist"]["sendto"] == {"[4, 8)": 30_000}
    assert h["hist"]["futex"] == {"[128, 256)": 6_000}
    assert h["perf_rb_pages"] == 64
    assert r["flags"]["map_hist_records_all"]

    p = r["per_event_printf"]
    assert p["n_events_recorded"] == 33_000
    assert p["dropped_events"] == 33_000
    assert p["drop_share"] == 0.5
    assert p["userspace_records"] == 33_000
    assert p["overhead_us"] == 528_000
    assert p["hist"]["recvfrom"] == {"[8, 16)": 13_500, "[32, 64)": 1_350, "[256, 512)": 150}
    assert p["hist"]["sendto"] == {"[4, 8)": 15_000}
    assert p["hist"]["futex"] == {"[128, 256)": 3_000}
    assert p["printf_is_async_userspace_format"] is True
    assert r["acceptance_avoids_per_event_print"]

    v = r["verifier"]
    assert v["bpf_stack_limit_bytes"] == 512
    assert v["hist_accepted"] and v["unbounded_rejected"] and v["stack_overflow_rejected"]
    names = {pr["name"]: pr for pr in v["programs"]}
    assert names["syscall_latency_hist"]["accepted"] is True
    assert names["unbounded_while"]["accepted"] is False
    assert names["oversized_stack"]["accepted"] is False
    assert names["oversized_stack"]["stack_bytes"] == 600
    assert r["flags"]["verifier_rejects_unbounded"]

    a68 = r["attach"]["on_teaching_6_8"]
    a610 = r["attach"]["on_teaching_6_10"]
    assert a68["kernel"] == "6.8.0-teach" and a68["attach_error"] is False
    assert a68["tracepoints_attached"] and a68["missing_probes"] == []
    assert "kprobe:do_recv_fastpath" in a68["kprobes_attached"]
    assert a610["kernel"] == "6.10.0-teach" and a610["attach_error"] is True
    assert a610["tracepoints_attached"] is True
    assert a610["missing_probes"] == ["kprobe:do_recv_fastpath"]
    assert "kprobe:__x64_sys_recvfrom" in a610["kprobes_attached"]
    assert r["tradeoff_kprobe_less_stable_than_tracepoint"]

    assert r["pitfall_not_zero_overhead"]
    assert r["map_hist"]["overhead_us"] > 0
    assert r["per_event_printf"]["overhead_us"] > r["map_hist"]["overhead_us"]
    flags = r["flags"]
    assert flags["declared_kernel_and_privileges"]
    assert flags["avoids_per_event_print"]
    assert flags["not_zero_overhead"]
    assert flags["kprobe_less_stable_than_tracepoint"]
    assert flags["verifier_rejects_unbounded"]
    assert flags["map_hist_records_all"]


if __name__ == "__main__":
    main()
