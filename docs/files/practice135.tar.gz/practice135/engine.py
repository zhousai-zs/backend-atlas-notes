#!/usr/bin/env python3
"""Teaching EbpfEngine — not Redis, not a real profiler/eBPF product,
not a network service, and not a host bpftrace / BCC / kernel probe run.

A Python 3 standard-library, virtual-clock model of attaching a
bpftrace-style program to a teaching KV (teachkv) and collecting a
syscall-latency histogram. The named source (checked on 2026-11-14) is:

* bpftrace — Language documentation, at
  https://bpftrace.org/docs/release_024/language
  (The bpftrace Language (0.24)). That page defines probe types
  including kprobe/kretprobe ("dynamic instrumentation of kernel
  functions") and tracepoint (static hooks "defined in the kernel
  source and compiled into the kernel binary"). It states that
  "the advantage of tracepoints is that they generally provide a
  more stable interface than kprobes do, they do not depend on the
  existence of a kernel function." Maps are BPF maps, named with
  `@`, living for the lifetime of bpftrace and accessible from
  action blocks and user-space. dropped events are discussed under
  perf_rb_pages: if bpftrace "may not be processing events in the
  ring buffer fast enough", events are dropped. A full map can
  lead to "lost map update events". The only mention of the
  verifier on that page is that BPF supports while loops "as long
  as the verifier can prove they’re bounded and fit within the
  instruction limit." The page does not define CAP_BPF, and it
  does not itself document hist(); it names the Standard Library
  (count(), sum(), and the page /docs/release_024/stdlib), where
  hist(n[, k]) is "a log2 histogram of n using 2^k buckets per
  power of 2, 0 <= k <= 5, defaults to 0." printf() is documented
  there as async, with formatting happening in user space.

This engine does not load a BPF program, does not call host
bpftrace / BCC / bpftool / perf, and does not attach kprobes or
tracepoints to the host kernel. Times are teaching virtual-clock
values, not production RTT, and not CLOCK_BOOTTIME wall-clock
nsecs from the host.
"""
from __future__ import annotations

from typing import Any


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"

MEASURE_S = 30.00
N_REQ = 30_000
# Teaching syscall-latency counts on the title-get path (virtual µs).
RECV_LAT_US = {8: 27_000, 32: 2_700, 256: 300}
SEND_LAT_US = {4: 30_000}
FUTEX_LAT_US = {128: 6_000}
OVERHEAD_MAP_US = 1  # teaching per-event map update, not a host measurement
OVERHEAD_PRINTF_US = 8  # teaching per-event printf path
PRINTF_DRAIN_PER_S = 1_100  # teaching userspace drain; official page gives no rate
TEACHING_KERNEL = "6.8.0-teach"
TEACHING_KERNEL_RENAMED = "6.10.0-teach"
HOST_UNAME_R = "6.12.113+"  # recorded on this box; probes were not attached to it
DECLARED_PRIVILEGES = "CAP_BPF, CAP_PERFMON"
# Official default mentioned by the language page (power of 2).
PERF_RB_PAGES_DEFAULT = 64
BPF_STACK_LIMIT_BYTES = 512  # official Errors section
HIST_K = 0


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def hist_bucket(n: int, k: int = 0) -> tuple[int, int]:
    """bpftrace hist() with 2^k buckets per power of 2 (k default 0).

    For k == 0 and n >= 1 the bucket is [2^floor(log2(n)), 2^(floor(log2(n))+1)).
    n == 0 uses [0, 1), matching the usual bpftrace log2 layout. This engine
    only inserts non-negative teaching latencies.
    """
    if n < 0:
        raise ValueError("teaching hist only models non-negative n")
    if n == 0:
        return (0, 1)
    p = n.bit_length() - 1
    if k == 0:
        return (1 << p, 1 << (p + 1))
    if k < 0 or k > 5:
        raise ValueError("official hist k is 0 <= k <= 5")
    buckets = 1 << k
    span = 1 << p
    step = span // buckets
    if step == 0:
        return (1 << p, 1 << (p + 1))
    idx = (n - span) // step
    lo = span + idx * step
    return (lo, lo + step)


def bucket_label(lo: int, hi: int) -> str:
    return f"[{lo}, {hi})"


def counts_to_hist(counts: dict[int, int], k: int = HIST_K) -> dict[str, int]:
    out: dict[str, int] = {}
    for n, c in counts.items():
        lab = bucket_label(*hist_bucket(n, k))
        out[lab] = out.get(lab, 0) + c
    return dict(sorted(out.items(), key=lambda kv: int(kv[0].split(",")[0][1:])))


def scale_hist(hist: dict[str, int], num: int, den: int) -> dict[str, int]:
    return {k: (v * num) // den for k, v in hist.items()}


def n_events_from(counts: dict[int, int]) -> int:
    return sum(counts.values())


class EbpfEngine:
    """Teaching model of a bpftrace-style syscall latency histogram."""

    def _workload(self) -> dict[str, Any]:
        recv_n = n_events_from(RECV_LAT_US)
        send_n = n_events_from(SEND_LAT_US)
        futex_n = n_events_from(FUTEX_LAT_US)
        n_events = recv_n + send_n + futex_n
        recv_hist = counts_to_hist(RECV_LAT_US)
        send_hist = counts_to_hist(SEND_LAT_US)
        futex_hist = counts_to_hist(FUTEX_LAT_US)
        return {
            "process": PROCESS,
            "key": KEY_TITLE,
            "title": TITLE_V1,
            "measure_s": MEASURE_S,
            "n_req": N_REQ,
            "throughput_rps": ts(N_REQ / MEASURE_S, 2),
            "syscalls": {
                "recvfrom": {
                    "n_events": recv_n,
                    "lat_us_counts": dict(RECV_LAT_US),
                    "hist": recv_hist,
                },
                "sendto": {
                    "n_events": send_n,
                    "lat_us_counts": dict(SEND_LAT_US),
                    "hist": send_hist,
                },
                "futex": {
                    "n_events": futex_n,
                    "lat_us_counts": dict(FUTEX_LAT_US),
                    "hist": futex_hist,
                },
            },
            "n_events": n_events,
            "times_are_teaching_virtual_clock": True,
        }

    def _map_aggregation(self, work: dict[str, Any]) -> dict[str, Any]:
        n = work["n_events"]
        overhead = n * OVERHEAD_MAP_US
        hist = {
            "recvfrom": dict(work["syscalls"]["recvfrom"]["hist"]),
            "sendto": dict(work["syscalls"]["sendto"]["hist"]),
            "futex": dict(work["syscalls"]["futex"]["hist"]),
        }
        n_buckets = sum(len(v) for v in hist.values())
        return {
            "mode": "map_hist",
            "probe": "tracepoint:syscalls:sys_enter_*/sys_exit_*",
            "aggregation": "BPF map hist()",
            "hist_k": HIST_K,
            "n_events": n,
            "n_events_recorded": n,
            "dropped_events": 0,
            "lost_map_updates": 0,
            "drop_share": 0.0,
            "userspace_records": n_buckets,
            "overhead_us": overhead,
            "hist": hist,
            "print_maps_on_exit": True,
            "perf_rb_pages": PERF_RB_PAGES_DEFAULT,
            "times_are_teaching_virtual_clock": True,
        }

    def _printf_per_event(self, work: dict[str, Any]) -> dict[str, Any]:
        n = work["n_events"]
        printed = PRINTF_DRAIN_PER_S * int(MEASURE_S)
        if printed > n:
            printed = n
        dropped = n - printed
        # Teaching model: userspace cannot drain the ring fast enough,
        # so drops are proportional across buckets (official page gives
        # the drop condition, not a drain rate or a drop policy).
        hist = {
            "recvfrom": scale_hist(work["syscalls"]["recvfrom"]["hist"], printed, n),
            "sendto": scale_hist(work["syscalls"]["sendto"]["hist"], printed, n),
            "futex": scale_hist(work["syscalls"]["futex"]["hist"], printed, n),
        }
        return {
            "mode": "per_event_printf",
            "probe": "tracepoint:syscalls:sys_exit_*",
            "aggregation": "userspace printf()",
            "n_events": n,
            "n_events_recorded": printed,
            "dropped_events": dropped,
            "drop_share": share(dropped, n),
            "userspace_records": printed,
            "overhead_us": n * OVERHEAD_PRINTF_US,
            "hist": hist,
            "printf_is_async_userspace_format": True,
            "perf_rb_pages": PERF_RB_PAGES_DEFAULT,
            "teach_drain_per_s": PRINTF_DRAIN_PER_S,
            "times_are_teaching_virtual_clock": True,
        }

    def _verifier(self) -> dict[str, Any]:
        hist_prog = {
            "name": "syscall_latency_hist",
            "has_unbounded_loop": False,
            "stack_bytes": 64,
            "accepted": True,
            "reason": "bounded map update; verifier can prove the program fits",
        }
        unbounded = {
            "name": "unbounded_while",
            "has_unbounded_loop": True,
            "stack_bytes": 16,
            "accepted": False,
            "reason": (
                "verifier cannot prove the while loop is bounded and "
                "fits within the instruction limit"
            ),
        }
        stack = {
            "name": "oversized_stack",
            "has_unbounded_loop": False,
            "stack_bytes": 600,
            "accepted": False,
            "reason": f"BPF stack limit of {BPF_STACK_LIMIT_BYTES} bytes is exceeded",
        }
        return {
            "bpf_stack_limit_bytes": BPF_STACK_LIMIT_BYTES,
            "programs": [hist_prog, unbounded, stack],
            "hist_accepted": True,
            "unbounded_rejected": True,
            "stack_overflow_rejected": True,
        }

    def _attach(self) -> dict[str, Any]:
        # Teaching kernels and symbol names are 教学假设. Tracepoint
        # names follow the public syscalls:* form used in the official
        # examples; do_recv_fastpath is a teaching internal function,
        # not a host-kernel symbol we probed.
        tp = [
            "tracepoint:syscalls:sys_enter_recvfrom",
            "tracepoint:syscalls:sys_exit_recvfrom",
            "tracepoint:syscalls:sys_enter_sendto",
            "tracepoint:syscalls:sys_exit_sendto",
            "tracepoint:syscalls:sys_enter_futex",
            "tracepoint:syscalls:sys_exit_futex",
        ]
        kp_stableish = "kprobe:__x64_sys_recvfrom"
        kp_deep = "kprobe:do_recv_fastpath"

        def result(kernel: str, missing: list[str]) -> dict[str, Any]:
            attached = list(tp) + [kp_stableish]
            if kp_deep not in missing:
                attached.append(kp_deep)
            return {
                "kernel": kernel,
                "kernel_is_teaching_declaration": True,
                "missing_probes_policy": "error",
                "tracepoints": list(tp),
                "tracepoints_attached": True,
                "kprobes_requested": [kp_stableish, kp_deep],
                "kprobes_attached": [k for k in [kp_stableish, kp_deep] if k not in missing],
                "missing_probes": list(missing),
                "attach_error": bool(missing),
            }

        k68 = result(TEACHING_KERNEL, [])
        k610 = result(TEACHING_KERNEL_RENAMED, [kp_deep])
        return {
            "on_teaching_6_8": k68,
            "on_teaching_6_10": k610,
            "kprobe_missing_after_rename": k610["attach_error"],
            "tracepoint_still_attaches_after_rename": k610["tracepoints_attached"],
        }

    def _declaration(self) -> dict[str, Any]:
        return {
            "declared_kernel_version": TEACHING_KERNEL,
            "declared_privileges": DECLARED_PRIVILEGES,
            "declaration_is_teaching": True,
            "host_uname_r": HOST_UNAME_R,
            "host_uid": 1000,
            "host_bpf_program_loaded": False,
            "host_bpftrace_invoked": False,
            "host_bcc_invoked": False,
            "host_perf_invoked": False,
            "host_gxx_invoked": False,
        }

    def compare(self) -> dict[str, Any]:
        work = self._workload()
        mapped = self._map_aggregation(work)
        printed = self._printf_per_event(work)
        ver = self._verifier()
        attach = self._attach()
        decl = self._declaration()
        distinguishes_hold = (
            mapped["dropped_events"] == 0
            and printed["dropped_events"] > 0
            and mapped["n_events_recorded"] == work["n_events"]
        )
        return {
            "workload": work,
            "map_hist": mapped,
            "per_event_printf": printed,
            "verifier": ver,
            "attach": attach,
            "declaration": decl,
            "declared_kernel_and_privileges": (
                bool(decl["declared_kernel_version"])
                and bool(decl["declared_privileges"])
            ),
            "avoids_per_event_print": (
                mapped["dropped_events"] == 0
                and printed["dropped_events"] > mapped["dropped_events"]
                and mapped["userspace_records"] < printed["userspace_records"]
            ),
            "not_zero_overhead": (
                mapped["overhead_us"] > 0 and printed["overhead_us"] > mapped["overhead_us"]
            ),
            "kprobe_less_stable_than_tracepoint": (
                attach["kprobe_missing_after_rename"]
                and attach["tracepoint_still_attaches_after_rename"]
            ),
            "verifier_rejects_unbounded": ver["unbounded_rejected"],
            "map_hist_records_all": distinguishes_hold,
        }
