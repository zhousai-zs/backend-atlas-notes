// 对比普通分配与 monotonic_buffer_resource 处理批次请求的分配次数
#include <cstdio>
#include <cstdlib>
#include <new>
#include <memory_resource>
#include <string>
#include <vector>
#include <stdexcept>

static size_t g_new_calls = 0;  // 统计全局 operator new 次数
void* operator new(std::size_t n) {
    ++g_new_calls;
    if (void* p = std::malloc(n ? n : 1)) return p;
    throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
// pmr 的 new_delete_resource 走带对齐参数的版本，也要统计
void* operator new(std::size_t n, std::align_val_t al) {
    ++g_new_calls;
    std::size_t a = static_cast<std::size_t>(al);
    if (void* p = std::aligned_alloc(a, (n + a - 1) / a * a)) return p;
    throw std::bad_alloc();
}
void operator delete(void* p, std::align_val_t) noexcept { std::free(p); }
void operator delete(void* p, std::size_t, std::align_val_t) noexcept { std::free(p); }

// 一个“请求”：若干字段，模拟解析出的 key/value
static const char* kFields[] = {"openid_oXyz1234567890abcdef", "msg_type_text_and_more_payload",
                                "content_hello_world_long_enough", "create_time_1730534400_xxxxxx"};

size_t run_std(int batch) {
    size_t before = g_new_calls;
    for (int r = 0; r < batch; ++r) {
        std::vector<std::string> req;
        for (auto f : kFields) req.emplace_back(f);  // 长字符串超出 SSO，每个都要堆分配
    }
    return g_new_calls - before;
}

size_t run_pmr(int batch) {
    size_t before = g_new_calls;
    alignas(std::max_align_t) static char buf[64 * 1024];
    for (int r = 0; r < batch; ++r) {
        // 资源先声明，容器后声明：容器先析构，资源最后整体释放
        std::pmr::monotonic_buffer_resource pool(buf, sizeof(buf), std::pmr::null_memory_resource());
        std::pmr::vector<std::pmr::string> req(&pool);
        for (auto f : kFields) req.emplace_back(f);
    }  // 每个请求结束：pool 析构 = 一次性“归还”整块，不逐个 free
    return g_new_calls - before;
}

size_t run_pmr_upstream(int batch) {  // 缓冲太小时向上游(new_delete)回退
    size_t before = g_new_calls;
    char small[64];
    std::pmr::monotonic_buffer_resource pool(small, sizeof(small));  // 默认上游 = new_delete_resource
    for (int r = 0; r < batch; ++r) {
        std::pmr::vector<std::pmr::string> req(&pool);
        for (auto f : kFields) req.emplace_back(f);
    }
    return g_new_calls - before;  // 整个批次共用一个 pool：内存只增不减，直到 pool 析构
}

struct Tracked {  // 用来检查异常路径没有悬垂对象
    static int alive;
    std::pmr::string s;
    explicit Tracked(const char* v, std::pmr::memory_resource* mr) : s(v, mr) {
        if (std::string_view(v) == "BAD") throw std::runtime_error("parse fail");
        ++alive;
    }
    ~Tracked() { --alive; }
};
int Tracked::alive = 0;

bool exception_path() {
    alignas(std::max_align_t) char buf[4096];
    try {
        std::pmr::monotonic_buffer_resource pool(buf, sizeof(buf), std::pmr::null_memory_resource());
        std::pmr::vector<Tracked> v(&pool);
        v.reserve(4);
        v.emplace_back("ok_field_aaaaaaaaaaaaaaaaaaaaaaa", &pool);
        v.emplace_back("ok_field_bbbbbbbbbbbbbbbbbbbbbbb", &pool);
        v.emplace_back("BAD", &pool);  // 构造中途抛异常
    } catch (const std::exception& e) {
        std::printf("caught: %s, alive=%d\n", e.what(), Tracked::alive);
        return Tracked::alive == 0;
    }
    return false;
}

int main() {
    const int N = 1000;
    size_t a = run_std(N), b = run_pmr(N), c = run_pmr_upstream(N);
    std::printf("batch=%d  std::allocator new calls=%zu\n", N, a);
    std::printf("batch=%d  monotonic(stack buf, null upstream) new calls=%zu\n", N, b);
    std::printf("batch=%d  monotonic(64B buf, new_delete upstream) new calls=%zu\n", N, c);
    bool ok = exception_path();
    std::printf("%s\n", (a >= 5u * N && b == 0 && c > 0 && c < a / 10 && ok) ? "ALL_CHECKS_PASSED" : "CHECK_FAILED");
}
