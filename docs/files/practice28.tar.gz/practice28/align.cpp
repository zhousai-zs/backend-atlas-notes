#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstddef>
#include <new>
struct alignas(64) Counter { long v; };  // 过对齐：避免两个计数器落在同一缓存行（伪共享）
int main() {
    std::printf("alignof(int)=%zu alignof(max_align_t)=%zu alignof(Counter)=%zu sizeof(Counter)=%zu\n",
                alignof(int), alignof(std::max_align_t), alignof(Counter), sizeof(Counter));
    Counter* p = new Counter[4];  // C++17：过对齐类型自动走 operator new(size, align_val_t)
    std::printf("new Counter[] addr%%64=%zu\n", (size_t)((uintptr_t)p % 64));
    delete[] p;
    void* q = std::aligned_alloc(64, 256);  // C 风格：大小须是对齐的整数倍
    std::printf("aligned_alloc addr%%64=%zu\n", (size_t)((uintptr_t)q % 64));
    std::free(q);
    alignas(Counter) unsigned char raw[sizeof(Counter)];
    Counter* c = new (raw) Counter{42};  // placement new：只构造，不分配
    std::printf("placement value=%ld\n", c->v);
    c->~Counter();  // 只能手动析构，绝不能 delete c
}
