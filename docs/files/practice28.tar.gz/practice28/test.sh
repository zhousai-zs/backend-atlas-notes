#!/bin/bash
set -e
cd "$(dirname "$0")"
g++ -std=c++17 -O1 -Wall -Wno-mismatched-new-delete -o batch batch.cpp && ./batch
g++ -std=c++17 -O1 -Wall -fsanitize=address,undefined -o align align.cpp && ./align
