#!/usr/bin/env python3
"""Acceptance checks for practice114 (consistency models and linearization points)."""
from __future__ import annotations

import json
import os
import sys

from app import INITIAL, run_all_experiments
from engine import KEY_TITLE, LOCAL_STEP_S, SYNC_DELAY_S, TITLE_V1, TITLE_V2, TITLE_V3


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert(data["title_v1"] == TITLE_V1, "title v1 is Weekly digest")
    _assert(data["title_v2"] == TITLE_V2, "title v2 is Weekly digest (revised)")
    _assert(data["title_v3"] == TITLE_V3, "title v3 is Weekly digest (hotfix)")
    _assert(data["key"] == KEY_TITLE, "key is article:01:title")
    _assert(data["sync_delay_s"] == SYNC_DELAY_S, "sync delay is 0.08s")
    _assert(data["local_step_s"] == LOCAL_STEP_S, "local step is 0.01s")

    h = data["history_and_realtime"]
    _assert(h["set1_inv_s"] == 0.0, "SET starts at 0.00")
    _assert(h["set1_lin_point_s"] == 0.01, "SET linearization point is 0.01")
    _assert(h["set1_ret_s"] == 0.03, "SET returns at 0.03")
    _assert(h["get_overlap_inv_s"] == 0.02, "overlapping GET starts at 0.02")
    _assert(h["get_overlap_lin_point_s"] == 0.03, "overlapping GET lin point is 0.03")
    _assert(h["get_overlap_ret_s"] == 0.04, "overlapping GET returns at 0.04")
    _assert(h["get_overlap_value"] == TITLE_V2, "overlapping GET that waits for the lock sees v2")
    _assert(h["get_after_inv_s"] == 0.05, "GET after SET starts at 0.05")
    _assert(h["get_after_ret_s"] == 0.07, "GET after SET returns at 0.07")
    _assert(h["get_after_value"] == TITLE_V2, "GET after SET returns must see v2")
    _assert(h["set1_precedes_get_after"] is True, "SET real-time precedes the later GET")
    _assert(h["set1_overlaps_get_overlap"] is True, "SET overlaps the mid-flight GET")
    _assert(h["linearizable"] is True, "locked-register concurrent history is linearizable")
    _assert(h["all_lin_points_in_interval"] is True, "every lin point sits in [inv, ret]")
    _assert(["set1", "get_after"] in h["realtime_edges"], "realtime edge set1 -> get_after")
    _assert(["get_overlap", "get_after"] in h["realtime_edges"], "realtime edge get_overlap -> get_after")

    ls = data["lin_point_and_sequential"]
    lock = ls["lock_impl"]
    _assert(lock["get_old_value"] == TITLE_V1, "GET that enters CS first legally returns v1")
    _assert(lock["all_lin_points_in_interval"] is True, "lock lin points stay inside their intervals")
    _assert(lock["history"]["linearizable"] is True, "lock history is linearizable")
    _assert(lock["history"]["sequentially_consistent"] is True, "linearizable implies SC")
    _assert(lock["lin_point_order"] == ["get_old", "set2"], "lin-point order is GET then SET")
    _assert(
        lock["linearization_point"].startswith("the load"),
        "lin point is the load or store while the lock is held",
    )
    get_old = next(op for op in lock["ops"] if op["op_id"] == "get_old")
    set2 = next(op for op in lock["ops"] if op["op_id"] == "set2")
    _assert(get_old["inv_s"] == 0.0 and get_old["lin_point_s"] == 0.02 and get_old["ret_s"] == 0.03, "get_old times")
    _assert(set2["inv_s"] == 0.01 and set2["lin_point_s"] == 0.03 and set2["ret_s"] == 0.04, "set2 times")
    _assert(ls["sc_not_lin_is_not_linearizable"] is True, "stale GET after completed SET is not linearizable")
    _assert(ls["sc_not_lin_is_sequentially_consistent"] is True, "that history is still sequentially consistent")
    _assert(ls["sc_not_lin"]["linearization"] is None, "no linearization exists for the stale post-return GET")
    _assert(ls["sc_not_lin"]["sequential_order"] == ["get_stale", "set_done"], "SC order is GET then SET")
    _assert(ls["same_process_stale_is_neither"] is True, "same-process stale GET is neither SC nor linearizable")
    _assert(ls["sc_not_lin"]["realtime_edges"] == [["set_done", "get_stale"]], "SET precedes the stale GET in real time")

    chk = data["register_checker"]
    _assert(chk["legal_after_write"]["linearizable"] is True, "GET of v2 after SET of v2 is legal")
    _assert(chk["legal_after_write"]["linearization"] == ["w", "r"], "legal order is write then read")
    _assert(chk["stale_after_completed_write"]["linearizable"] is False, "stale read after completed write is illegal")
    _assert(chk["stale_after_completed_write"]["sequentially_consistent"] is True, "that stale read can still be SC")
    _assert(chk["overlapping_read_old_legal"]["linearizable"] is True, "overlapping GET may return the old value")
    _assert(chk["overlapping_read_new_legal"]["linearizable"] is True, "overlapping GET may return the new value")
    _assert(chk["new_then_old"]["linearizable"] is False, "two completed writes then disagreeing later reads is illegal")
    _assert(chk["never_written_value"]["linearizable"] is False, "GET of a never-written title is illegal")
    _assert(chk["legal_cases_linearizable"] is True, "all legal cases pass the checker")
    _assert(chk["illegal_cases_not_linearizable"] is True, "all illegal cases fail the checker")

    vs = data["lin_vs_eventual"]
    ev = vs["eventual_history"]
    _assert(ev["set_inv_s"] == 0.0, "eventual SET starts at 0.00")
    _assert(ev["set_ret_s"] == 0.02, "eventual SET returns at 0.02")
    _assert(ev["r1_at_write_return"] == TITLE_V2, "primary has v2 when SET returns")
    _assert(ev["r2_at_write_return"] == TITLE_V1, "secondary still has v1 when SET returns")
    _assert(ev["get_stale_inv_s"] == 0.03, "stale GET starts at 0.03, after SET returned")
    _assert(ev["get_stale_ret_s"] == 0.05, "stale GET returns at 0.05")
    _assert(ev["get_after_write_before_sync"] == TITLE_V1, "GET to secondary before sync sees v1")
    _assert(ev["linearizable"] is False, "that stale-read history is not linearizable")
    _assert(ev["sync"]["synced_at_s"] == 0.09, "sync happens at 0.01 + 0.08 = 0.09")
    _assert(ev["sync"]["replicas"]["r1"] == TITLE_V2, "after sync r1 is v2")
    _assert(ev["sync"]["replicas"]["r2"] == TITLE_V2, "after sync r2 is v2")
    _assert(ev["get_fresh_inv_s"] == 0.10, "GET after sync starts at 0.10")
    _assert(ev["get_fresh_ret_s"] == 0.12, "GET after sync returns at 0.12")
    _assert(ev["get_after_sync"] == TITLE_V2, "GET after sync sees v2")
    _assert(ev["eventually_converged"] is True, "replicas converge on the last write")

    lin = vs["linearizable_primary_read"]
    _assert(lin["set_ret_s"] == 0.02, "primary-read SET also returns at 0.02")
    _assert(lin["r1_at_write_return"] == TITLE_V2, "primary has v2")
    _assert(lin["r2_at_write_return"] == TITLE_V1, "secondary still lags")
    _assert(lin["replicas_not_identical_at_write_return"] is True, "replicas differ at SET return")
    _assert(lin["get_inv_s"] == 0.03, "primary GET starts at 0.03")
    _assert(lin["get_after_write_from_primary"] == TITLE_V2, "reading the primary sees v2")
    _assert(lin["linearizable"] is True, "client history that only reads the primary is linearizable")
    _assert(lin["pitfall_replicas_need_not_be_identical"] is True, "identical replicas are not the definition")
    _assert(vs["histories_are_distinguishable"] is True, "the two histories disagree on linearizability")

    tr = data["tradeoff_coordination_or_lease"]
    _assert(tr["eventual_write_ret_s"] == 0.02, "local SET returns at 0.02")
    _assert(tr["eventual_any_replica_get_value"] == TITLE_V1, "any-replica GET can be stale")
    _assert(tr["eventual_any_replica_can_be_stale"] is True, "stale any-replica flag")
    _assert(tr["coordinated_write_ret_s"] == 0.10, "SET that waits for sync returns at 0.10")
    _assert(tr["coordinated_replicas_at_return"]["r1"] == TITLE_V2, "coordinated r1 is v2")
    _assert(tr["coordinated_replicas_at_return"]["r2"] == TITLE_V2, "coordinated r2 is v2")
    _assert(tr["coordinated_any_replica_get_value"] == TITLE_V2, "after coordinated SET any replica is fresh")
    _assert(tr["coordinated_write_is_slower"] is True, "coordination delays the SET return")
    _assert(tr["stronger_reads_need_coordination_or_lease"] is True, "tradeoff flag")

    _assert(data["acceptance_distinguish_lin_vs_eventual"] is True, "acceptance: distinguishable histories")
    _assert(data["acceptance_identify_lock_lin_point"] is True, "acceptance: lock linearization point")
    _assert(data["pitfall_replicas_identical_is_not_the_definition"] is True, "pitfall demonstrated")
    _assert(data["tradeoff_stronger_reads_need_coordination_or_lease"] is True, "tradeoff demonstrated")

    # Linearizability is a single-object model; every lin history in this file is also SC.
    for name, hist in (
        ("realtime", h["history"]),
        ("lock", lock["history"]),
        ("legal_after_write", chk["legal_after_write"]),
        ("primary_read", lin["history"]),
    ):
        _assert(hist["lin_implies_sc"] is True, f"{name}: linearizable implies SC")
        if hist["linearizable"]:
            _assert(hist["sequentially_consistent"] is True, f"{name}: lin is SC")

    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
