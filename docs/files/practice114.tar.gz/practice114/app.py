#!/usr/bin/env python3
"""Run the lesson 114 consistency-model experiments and record observations."""
from __future__ import annotations

from typing import Any

from engine import (
    KEY_TITLE,
    LOCAL_STEP_S,
    SYNC_DELAY_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    Clock,
    EventualStore,
    LockedRegister,
    RecordedOp,
    check_history,
    make_op,
)


INITIAL = {KEY_TITLE: TITLE_V1}


def _lin_point_report(ops: list[RecordedOp], register: LockedRegister) -> dict[str, Any]:
    ordered = register.order_by_lin_point(ops)
    hist = check_history(ops, INITIAL)
    order_ids = [op.op_id for op in ordered]
    return {
        "ops": [op.as_dict() for op in ops],
        "lin_point_order": order_ids,
        "all_lin_points_in_interval": register.lin_points_in_interval(ops),
        "order_by_lin_point_is_a_linearization": hist["linearizable"]
        and hist["linearization"] is not None,
        "history": hist,
        "linearization_point": (
            "the load (GET) or store (SET) of the shared slot while the single-machine lock is held"
        ),
    }


def history_and_realtime() -> dict[str, Any]:
    """Record concurrent SET/GET invocation and return times on a locked register."""
    clock = Clock()
    reg = LockedRegister(clock, INITIAL)

    # Editor SET starts first, enters the critical section, then the reader
    # starts a GET that overlaps the SET but must wait for the lock. The GET
    # therefore observes v2. After the SET has returned, a second GET is
    # issued and also observes v2.
    set1 = reg.begin("set1", "editor", "SET", KEY_TITLE, TITLE_V2)
    clock.advance(LOCAL_STEP_S)  # 0.01, lin point of SET
    reg.enter_cs_and_apply("editor")
    clock.advance(LOCAL_STEP_S)  # 0.02
    # Reader starts while the editor still holds the lock / has not returned.
    get_overlap = reg.begin("get_overlap", "reader", "GET", KEY_TITLE)
    clock.advance(LOCAL_STEP_S)  # 0.03
    set1 = reg.leave_cs_and_complete("editor")  # ret 0.03
    # Reader enters CS immediately after the lock is released.
    reg.enter_cs_and_apply("reader")  # lin 0.03
    clock.advance(LOCAL_STEP_S)  # 0.04
    get_overlap = reg.leave_cs_and_complete("reader")  # ret 0.04

    clock.advance(LOCAL_STEP_S)  # 0.05
    get_after = reg.begin("get_after", "reader2", "GET", KEY_TITLE)  # inv 0.05
    clock.advance(LOCAL_STEP_S)  # 0.06
    reg.enter_cs_and_apply("reader2")
    clock.advance(LOCAL_STEP_S)  # 0.07
    get_after = reg.leave_cs_and_complete("reader2")  # ret 0.07

    ops = [set1, get_overlap, get_after]
    hist = check_history(ops, INITIAL)
    return {
        "ops": [op.as_dict() for op in ops],
        "realtime_edges": hist["realtime_edges"],
        "overlapping_pairs": hist["overlapping_pairs"],
        "set1_inv_s": set1.inv_s,
        "set1_lin_point_s": set1.lin_point_s,
        "set1_ret_s": set1.ret_s,
        "get_overlap_inv_s": get_overlap.inv_s,
        "get_overlap_lin_point_s": get_overlap.lin_point_s,
        "get_overlap_ret_s": get_overlap.ret_s,
        "get_overlap_value": get_overlap.result,
        "get_after_inv_s": get_after.inv_s,
        "get_after_lin_point_s": get_after.lin_point_s,
        "get_after_ret_s": get_after.ret_s,
        "get_after_value": get_after.result,
        "set1_precedes_get_after": ["set1", "get_after"] in hist["realtime_edges"],
        "set1_overlaps_get_overlap": ["get_overlap", "set1"] in hist["overlapping_pairs"]
        or ["set1", "get_overlap"] in hist["overlapping_pairs"],
        "history": hist,
        "linearizable": hist["linearizable"],
        "all_lin_points_in_interval": LockedRegister(Clock(), INITIAL).lin_points_in_interval(ops),
    }


def lin_point_and_sequential() -> dict[str, Any]:
    """Lock linearization points, plus a history that is SC but not linearizable."""
    clock = Clock()
    reg = LockedRegister(clock, INITIAL)

    # Overlapping GET that wins the lock first, so it legally returns v1.
    get_old = reg.begin("get_old", "reader", "GET", KEY_TITLE)  # inv 0.00
    clock.advance(LOCAL_STEP_S)  # 0.01
    set2 = reg.begin("set2", "editor", "SET", KEY_TITLE, TITLE_V2)  # inv 0.01
    clock.advance(LOCAL_STEP_S)  # 0.02
    reg.enter_cs_and_apply("reader")  # lin 0.02, returns v1
    clock.advance(LOCAL_STEP_S)  # 0.03
    get_old = reg.leave_cs_and_complete("reader")  # ret 0.03
    reg.enter_cs_and_apply("editor")  # lin 0.03, writes v2
    clock.advance(LOCAL_STEP_S)  # 0.04
    set2 = reg.leave_cs_and_complete("editor")  # ret 0.04

    lock_ops = [get_old, set2]
    lock_report = _lin_point_report(lock_ops, reg)
    lock_report["get_old_value"] = get_old.result
    lock_report["set2_value"] = set2.arg

    # Constructed history: the write has already returned, then another
    # process starts a GET and still observes the initial value. This
    # violates RealTime (hence linearizability) but is sequentially
    # consistent: the two processes have no program-order constraint
    # relating them, so GET then SET is a legal sequential order.
    sc_not_lin_ops = [
        make_op(
            "set_done",
            "editor",
            "SET",
            KEY_TITLE,
            arg=TITLE_V2,
            result="ok",
            inv_s=0.00,
            ret_s=0.02,
        ),
        make_op(
            "get_stale",
            "reader",
            "GET",
            KEY_TITLE,
            result=TITLE_V1,
            inv_s=0.03,
            ret_s=0.05,
        ),
    ]
    sc_not_lin = check_history(sc_not_lin_ops, INITIAL)

    # Same stale GET, but issued by the same process that did the SET.
    # Program order now forces SET before GET, so even sequential
    # consistency rejects it.
    same_proc_ops = [
        make_op(
            "set_done",
            "editor",
            "SET",
            KEY_TITLE,
            arg=TITLE_V2,
            result="ok",
            inv_s=0.00,
            ret_s=0.02,
        ),
        make_op(
            "get_stale",
            "editor",
            "GET",
            KEY_TITLE,
            result=TITLE_V1,
            inv_s=0.03,
            ret_s=0.05,
        ),
    ]
    same_proc = check_history(same_proc_ops, INITIAL)

    return {
        "lock_impl": lock_report,
        "sc_not_lin": {
            **sc_not_lin,
            "reason": (
                "SET completes at 0.02, GET starts at 0.03 and returns the initial "
                "title; RealTime requires the GET to take effect after the SET, "
                "but a sequential order GET then SET is still legal under program order."
            ),
        },
        "same_process_stale_read": same_proc,
        "sc_not_lin_is_sequentially_consistent": sc_not_lin["sequentially_consistent"],
        "sc_not_lin_is_not_linearizable": sc_not_lin["linearizable"] is False,
        "same_process_stale_is_neither": (
            same_proc["linearizable"] is False and same_proc["sequentially_consistent"] is False
        ),
    }


def register_checker() -> dict[str, Any]:
    """Check legal and illegal read/write-register histories."""
    legal_after_write = check_history(
        [
            make_op("w", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.00, ret_s=0.02),
            make_op("r", "reader", "GET", KEY_TITLE, result=TITLE_V2, inv_s=0.03, ret_s=0.05),
        ],
        INITIAL,
    )
    stale_after_completed_write = check_history(
        [
            make_op("w", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.00, ret_s=0.02),
            make_op("r", "reader", "GET", KEY_TITLE, result=TITLE_V1, inv_s=0.03, ret_s=0.05),
        ],
        INITIAL,
    )
    overlapping_read_old_legal = check_history(
        [
            make_op("w", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.01, ret_s=0.04),
            make_op("r", "reader", "GET", KEY_TITLE, result=TITLE_V1, inv_s=0.00, ret_s=0.03),
        ],
        INITIAL,
    )
    overlapping_read_new_legal = check_history(
        [
            make_op("w", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.00, ret_s=0.03),
            make_op("r", "reader", "GET", KEY_TITLE, result=TITLE_V2, inv_s=0.01, ret_s=0.04),
        ],
        INITIAL,
    )
    # Both writes complete before either read starts. The two later reads
    # return different values, so no single last write can explain them.
    new_then_old = check_history(
        [
            make_op("w2", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.00, ret_s=0.02),
            make_op("w3", "editor2", "SET", KEY_TITLE, arg=TITLE_V3, result="ok", inv_s=0.00, ret_s=0.02),
            make_op("r_first", "reader", "GET", KEY_TITLE, result=TITLE_V2, inv_s=0.03, ret_s=0.04),
            make_op("r_second", "reader2", "GET", KEY_TITLE, result=TITLE_V3, inv_s=0.05, ret_s=0.06),
        ],
        INITIAL,
    )
    never_written = check_history(
        [
            make_op("w", "editor", "SET", KEY_TITLE, arg=TITLE_V2, result="ok", inv_s=0.00, ret_s=0.02),
            make_op("r", "reader", "GET", KEY_TITLE, result=TITLE_V3, inv_s=0.03, ret_s=0.05),
        ],
        INITIAL,
    )
    return {
        "legal_after_write": legal_after_write,
        "stale_after_completed_write": stale_after_completed_write,
        "overlapping_read_old_legal": overlapping_read_old_legal,
        "overlapping_read_new_legal": overlapping_read_new_legal,
        "new_then_old": new_then_old,
        "never_written_value": never_written,
        "legal_cases_linearizable": (
            legal_after_write["linearizable"]
            and overlapping_read_old_legal["linearizable"]
            and overlapping_read_new_legal["linearizable"]
        ),
        "illegal_cases_not_linearizable": (
            stale_after_completed_write["linearizable"] is False
            and new_then_old["linearizable"] is False
            and never_written["linearizable"] is False
        ),
    }


def lin_vs_eventual() -> dict[str, Any]:
    """Distinguishable histories: linearizable vs eventually consistent."""
    # Eventual path: SET returns as soon as the primary applies it.
    # A GET to the secondary before sync still sees v1. After sync, GET sees v2.
    ev = EventualStore(Clock(), INITIAL, sync_delay_s=SYNC_DELAY_S)
    ev_set = ev.set_on_primary("set_v2", "editor", KEY_TITLE, TITLE_V2, wait_for_sync=False)
    replicas_at_write_return = ev.snapshot(KEY_TITLE)
    ev.clock.wait_until(0.03)
    ev_get_stale = ev.get_from("get_stale", "reader", KEY_TITLE, "r2")
    ev_sync = ev.sync()
    ev.clock.wait_until(round(ev.clock.now() + LOCAL_STEP_S, 10))
    ev_get_fresh = ev.get_from("get_fresh", "reader", KEY_TITLE, "r2")
    ev_ops = [ev_set, ev_get_stale, ev_get_fresh]
    ev_hist = check_history(ev_ops, INITIAL)

    # Linearizable path with the same lagging secondary: clients only
    # read the primary. The client history is linearizable even though
    # r1 and r2 differ at the moment SET returns.
    lin = EventualStore(Clock(), INITIAL, sync_delay_s=SYNC_DELAY_S)
    lin_set = lin.set_on_primary("set_v2", "editor", KEY_TITLE, TITLE_V2, wait_for_sync=False)
    lin_replicas_at_write_return = lin.snapshot(KEY_TITLE)
    lin.clock.wait_until(0.03)
    lin_get = lin.get_from("get_primary", "reader", KEY_TITLE, "r1")
    lin_ops = [lin_set, lin_get]
    lin_hist = check_history(lin_ops, INITIAL)

    return {
        "sync_delay_s": SYNC_DELAY_S,
        "eventual_history": {
            "ops": [op.as_dict() for op in ev_ops],
            "history": ev_hist,
            "linearizable": ev_hist["linearizable"],
            "sequentially_consistent": ev_hist["sequentially_consistent"],
            "replicas_at_write_return": replicas_at_write_return,
            "r1_at_write_return": replicas_at_write_return["r1"],
            "r2_at_write_return": replicas_at_write_return["r2"],
            "set_inv_s": ev_set.inv_s,
            "set_ret_s": ev_set.ret_s,
            "get_stale_inv_s": ev_get_stale.inv_s,
            "get_stale_ret_s": ev_get_stale.ret_s,
            "get_after_write_before_sync": ev_get_stale.result,
            "sync": ev_sync,
            "get_fresh_inv_s": ev_get_fresh.inv_s,
            "get_fresh_ret_s": ev_get_fresh.ret_s,
            "get_after_sync": ev_get_fresh.result,
            "eventually_converged": (
                ev_sync["replicas"]["r1"] == TITLE_V2
                and ev_sync["replicas"]["r2"] == TITLE_V2
                and ev_get_fresh.result == TITLE_V2
            ),
        },
        "linearizable_primary_read": {
            "ops": [op.as_dict() for op in lin_ops],
            "history": lin_hist,
            "linearizable": lin_hist["linearizable"],
            "replicas_at_write_return": lin_replicas_at_write_return,
            "r1_at_write_return": lin_replicas_at_write_return["r1"],
            "r2_at_write_return": lin_replicas_at_write_return["r2"],
            "replicas_not_identical_at_write_return": (
                lin_replicas_at_write_return["r1"] != lin_replicas_at_write_return["r2"]
            ),
            "set_ret_s": lin_set.ret_s,
            "get_inv_s": lin_get.inv_s,
            "get_ret_s": lin_get.ret_s,
            "get_after_write_from_primary": lin_get.result,
            "pitfall_replicas_need_not_be_identical": (
                lin_replicas_at_write_return["r1"] == TITLE_V2
                and lin_replicas_at_write_return["r2"] == TITLE_V1
                and lin_hist["linearizable"] is True
                and lin_get.result == TITLE_V2
            ),
        },
        "histories_are_distinguishable": (
            ev_hist["linearizable"] is False
            and ev_get_stale.result == TITLE_V1
            and ev_get_fresh.result == TITLE_V2
            and lin_hist["linearizable"] is True
            and lin_get.result == TITLE_V2
        ),
    }


def tradeoff_coordination_or_lease() -> dict[str, Any]:
    """Stronger read semantics pay for coordination or a primary/lease read path."""
    local = EventualStore(Clock(), INITIAL, sync_delay_s=SYNC_DELAY_S)
    local_set = local.set_on_primary(
        "set_local", "editor", KEY_TITLE, TITLE_V2, wait_for_sync=False
    )
    local.clock.wait_until(0.03)
    local_any = local.get_from("get_any", "reader", KEY_TITLE, "r2")

    coord = EventualStore(Clock(), INITIAL, sync_delay_s=SYNC_DELAY_S)
    coord_set = coord.set_on_primary(
        "set_coord", "editor", KEY_TITLE, TITLE_V2, wait_for_sync=True
    )
    coord.clock.wait_until(round(coord_set.ret_s + LOCAL_STEP_S, 10))
    coord_any = coord.get_from("get_any", "reader", KEY_TITLE, "r2")

    return {
        "sync_delay_s": SYNC_DELAY_S,
        "eventual_write_ret_s": local_set.ret_s,
        "eventual_any_replica_get_value": local_any.result,
        "eventual_any_replica_can_be_stale": local_any.result == TITLE_V1,
        "coordinated_write_ret_s": coord_set.ret_s,
        "coordinated_replicas_at_return": coord.snapshot(KEY_TITLE),
        "coordinated_any_replica_get_value": coord_any.result,
        "coordinated_any_replica_is_fresh": coord_any.result == TITLE_V2,
        "coordinated_write_is_slower": coord_set.ret_s > local_set.ret_s,
        "primary_read_avoids_stale": True,
        "any_replica_read_can_be_stale": True,
        "stronger_reads_need_coordination_or_lease": True,
    }


def run_all_experiments() -> dict[str, Any]:
    hist = history_and_realtime()
    lin_seq = lin_point_and_sequential()
    checker = register_checker()
    vs = lin_vs_eventual()
    trade = tradeoff_coordination_or_lease()
    return {
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "title_v3": TITLE_V3,
        "key": KEY_TITLE,
        "sync_delay_s": SYNC_DELAY_S,
        "local_step_s": LOCAL_STEP_S,
        "history_and_realtime": hist,
        "lin_point_and_sequential": lin_seq,
        "register_checker": checker,
        "lin_vs_eventual": vs,
        "tradeoff_coordination_or_lease": trade,
        "acceptance_distinguish_lin_vs_eventual": vs["histories_are_distinguishable"],
        "acceptance_identify_lock_lin_point": (
            lin_seq["lock_impl"]["all_lin_points_in_interval"] is True
            and lin_seq["lock_impl"]["history"]["linearizable"] is True
            and lin_seq["lock_impl"]["linearization_point"].startswith("the load")
        ),
        "pitfall_replicas_identical_is_not_the_definition": vs[
            "linearizable_primary_read"
        ]["pitfall_replicas_need_not_be_identical"],
        "tradeoff_stronger_reads_need_coordination_or_lease": trade[
            "stronger_reads_need_coordination_or_lease"
        ],
    }


if __name__ == "__main__":
    import json
    import os

    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(json.dumps({k: data[k] for k in data if not isinstance(data[k], dict)}, ensure_ascii=False, indent=2))
