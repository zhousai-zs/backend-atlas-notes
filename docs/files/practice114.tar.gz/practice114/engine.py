#!/usr/bin/env python3
"""Teaching ConsistencyEngine — not Redis, not a network, not Jepsen.

A Python 3 standard-library model of a single-key read/write register,
operation histories with invocation and completion times, a
linearizability / sequential-consistency checker, a single-machine
locked register whose linearization point is the load or store inside
the critical section, and a two-replica eventually-synced store used
to produce a stale read after a completed write.

This is not Redis, not redis-py, and not a network server. There is no
TCP, no Jepsen/Knossos, no Raft, and no real wall-clock cluster. The
Clock is a simulation of the imaginary, perfectly synchronized,
globally accessible clock that Jepsen's consistency-models page uses
to define a real-time order; real machines do not share such a clock.
Semantics follow the Jepsen Linearizability and Consistency models
pages checked on 2026-11-13, for the subset implemented here.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Any, Iterator, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
SYNC_DELAY_S = 0.08
LOCAL_STEP_S = 0.01


class Clock:
    """A virtual clock tests can freeze and advance. Not a shared wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t = round(self.t + float(seconds), 10)

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class RecordedOp:
    op_id: str
    process: str
    kind: str  # SET, GET
    key: str
    arg: Optional[str] = None
    result: Optional[str] = None
    inv_s: float = 0.0
    ret_s: float = 0.0
    lin_point_s: Optional[float] = None
    replica_id: Optional[str] = None

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "op_id": self.op_id,
            "process": self.process,
            "kind": self.kind,
            "key": self.key,
            "arg": self.arg,
            "result": self.result,
            "inv_s": self.inv_s,
            "ret_s": self.ret_s,
            "lin_point_s": self.lin_point_s,
            "replica_id": self.replica_id,
        }
        return d


def real_time_precedes(a: RecordedOp, b: RecordedOp) -> bool:
    """A precedes B in real time iff A completes before B is invoked."""
    return a.ret_s < b.inv_s


def realtime_edges(ops: list[RecordedOp]) -> list[list[str]]:
    edges: list[list[str]] = []
    for a, b in itertools.permutations(ops, 2):
        if real_time_precedes(a, b):
            edges.append([a.op_id, b.op_id])
    edges.sort()
    return edges


def overlapping_pairs(ops: list[RecordedOp]) -> list[list[str]]:
    pairs: list[list[str]] = []
    for i, a in enumerate(ops):
        for b in ops[i + 1 :]:
            if not real_time_precedes(a, b) and not real_time_precedes(b, a):
                pairs.append(sorted([a.op_id, b.op_id]))
    pairs.sort()
    return pairs


def _respects_realtime(order: tuple[RecordedOp, ...]) -> bool:
    for i, later in enumerate(order):
        for earlier in order[:i]:
            if real_time_precedes(later, earlier):
                return False
    return True


def _respects_program_order(order: tuple[RecordedOp, ...]) -> bool:
    last_index: dict[str, int] = {}
    for i, op in enumerate(order):
        prev = last_index.get(op.process)
        if prev is not None:
            # Same process must appear in invocation order (single-threaded).
            if order[prev].inv_s > op.inv_s:
                return False
        last_index[op.process] = i
    return True


def _register_legal(order: tuple[RecordedOp, ...], initial: dict[str, str]) -> bool:
    state = dict(initial)
    for op in order:
        if op.kind == "SET":
            if op.arg is None:
                return False
            state[op.key] = op.arg
        elif op.kind == "GET":
            expected = state.get(op.key)
            if op.result != expected:
                return False
        else:
            return False
    return True


def _orders(
    ops: list[RecordedOp],
    predicate,
) -> Iterator[tuple[RecordedOp, ...]]:
    for perm in itertools.permutations(ops):
        if predicate(perm):
            yield perm


def is_linearizable(
    ops: list[RecordedOp], initial: dict[str, str]
) -> tuple[bool, Optional[list[str]]]:
    """Single-object register linearizability: SingleOrder + RealTime + RVal."""
    for perm in _orders(ops, lambda p: _respects_realtime(p) and _register_legal(p, initial)):
        return True, [op.op_id for op in perm]
    return False, None


def is_sequentially_consistent(
    ops: list[RecordedOp], initial: dict[str, str]
) -> tuple[bool, Optional[list[str]]]:
    """Sequential consistency: SingleOrder + program order + RVal, no RealTime."""
    for perm in _orders(
        ops, lambda p: _respects_program_order(p) and _register_legal(p, initial)
    ):
        return True, [op.op_id for op in perm]
    return False, None


def check_history(ops: list[RecordedOp], initial: dict[str, str]) -> dict[str, Any]:
    lin, lin_order = is_linearizable(ops, initial)
    sc, sc_order = is_sequentially_consistent(ops, initial)
    return {
        "ops": [op.as_dict() for op in ops],
        "realtime_edges": realtime_edges(ops),
        "overlapping_pairs": overlapping_pairs(ops),
        "linearizable": lin,
        "sequentially_consistent": sc,
        "linearization": lin_order,
        "sequential_order": sc_order,
        "lin_implies_sc": (not lin) or sc,
    }


def make_op(
    op_id: str,
    process: str,
    kind: str,
    key: str,
    *,
    arg: Optional[str] = None,
    result: Optional[str] = None,
    inv_s: float,
    ret_s: float,
    lin_point_s: Optional[float] = None,
    replica_id: Optional[str] = None,
) -> RecordedOp:
    return RecordedOp(
        op_id=op_id,
        process=process,
        kind=kind,
        key=key,
        arg=arg,
        result=result,
        inv_s=inv_s,
        ret_s=ret_s,
        lin_point_s=lin_point_s,
        replica_id=replica_id,
    )


class LockedRegister:
    """Single-machine locked register.

    The linearization point is the load (GET) or store (SET) of the
    shared slot while the lock is held. Only one process may be in the
    critical section at a time.
    """

    def __init__(self, clock: Clock, initial: dict[str, str]) -> None:
        self.clock = clock
        self.store = dict(initial)
        self._cs_holder: Optional[str] = None
        self._pending: dict[str, RecordedOp] = {}

    def begin(
        self,
        op_id: str,
        process: str,
        kind: str,
        key: str,
        arg: Optional[str] = None,
    ) -> RecordedOp:
        if process in self._pending:
            raise RuntimeError(f"process {process} already has an in-flight op")
        if self._cs_holder == process:
            raise RuntimeError(f"process {process} is already in the critical section")
        op = RecordedOp(
            op_id=op_id,
            process=process,
            kind=kind,
            key=key,
            arg=arg,
            inv_s=self.clock.now(),
        )
        self._pending[process] = op
        return op

    def enter_cs_and_apply(self, process: str) -> RecordedOp:
        if self._cs_holder is not None:
            raise RuntimeError(f"lock held by {self._cs_holder}")
        op = self._pending.get(process)
        if op is None:
            raise RuntimeError(f"process {process} has no in-flight op")
        self._cs_holder = process
        # Linearization point: the load or store inside the critical section.
        op.lin_point_s = self.clock.now()
        if op.kind == "SET":
            if op.arg is None:
                raise RuntimeError("SET requires arg")
            self.store[op.key] = op.arg
            op.result = "ok"
        elif op.kind == "GET":
            op.result = self.store.get(op.key)
        else:
            raise RuntimeError(f"unknown kind {op.kind}")
        return op

    def leave_cs_and_complete(self, process: str) -> RecordedOp:
        if self._cs_holder != process:
            raise RuntimeError(f"process {process} does not hold the lock")
        op = self._pending.pop(process)
        self._cs_holder = None
        op.ret_s = self.clock.now()
        return op

    def lin_points_in_interval(self, ops: list[RecordedOp]) -> bool:
        return all(
            op.lin_point_s is not None and op.inv_s <= op.lin_point_s <= op.ret_s
            for op in ops
        )

    def order_by_lin_point(self, ops: list[RecordedOp]) -> list[RecordedOp]:
        return sorted(ops, key=lambda op: (op.lin_point_s, op.op_id))


class EventualStore:
    """Two-replica store. A SET is applied on the primary and returns
    without waiting for the secondary. A later sync copies primary to
    secondary. This is a teaching model of eventual replication, not
    a production reconcilation protocol.
    """

    def __init__(
        self,
        clock: Clock,
        initial: dict[str, str],
        sync_delay_s: float = SYNC_DELAY_S,
    ) -> None:
        self.clock = clock
        self.sync_delay_s = sync_delay_s
        self.replicas: dict[str, dict[str, str]] = {
            "r1": dict(initial),
            "r2": dict(initial),
        }
        self.pending_sync_at: Optional[float] = None
        self.primary = "r1"

    def replica_value(self, replica_id: str, key: str) -> Optional[str]:
        return self.replicas[replica_id].get(key)

    def snapshot(self, key: str) -> dict[str, Optional[str]]:
        return {rid: store.get(key) for rid, store in self.replicas.items()}

    def set_on_primary(
        self,
        op_id: str,
        process: str,
        key: str,
        value: str,
        pre_s: float = LOCAL_STEP_S,
        post_s: float = LOCAL_STEP_S,
        wait_for_sync: bool = False,
    ) -> RecordedOp:
        inv = self.clock.now()
        self.clock.advance(pre_s)
        self.replicas[self.primary][key] = value
        applied_at = self.clock.now()
        self.pending_sync_at = round(applied_at + self.sync_delay_s, 10)
        if wait_for_sync:
            self.sync()
        self.clock.advance(post_s)
        return RecordedOp(
            op_id=op_id,
            process=process,
            kind="SET",
            key=key,
            arg=value,
            result="ok",
            inv_s=inv,
            ret_s=self.clock.now(),
            lin_point_s=applied_at,
            replica_id=self.primary,
        )

    def get_from(
        self,
        op_id: str,
        process: str,
        key: str,
        replica_id: str,
        pre_s: float = LOCAL_STEP_S,
        post_s: float = LOCAL_STEP_S,
    ) -> RecordedOp:
        inv = self.clock.now()
        self.clock.advance(pre_s)
        value = self.replicas[replica_id].get(key)
        read_at = self.clock.now()
        self.clock.advance(post_s)
        return RecordedOp(
            op_id=op_id,
            process=process,
            kind="GET",
            key=key,
            result=value,
            inv_s=inv,
            ret_s=self.clock.now(),
            lin_point_s=read_at,
            replica_id=replica_id,
        )

    def sync(self) -> dict[str, Any]:
        if self.pending_sync_at is not None:
            self.clock.wait_until(self.pending_sync_at)
        at = self.clock.now()
        self.replicas["r2"] = dict(self.replicas[self.primary])
        self.pending_sync_at = None
        return {"synced_at_s": at, "replicas": self.snapshot(KEY_TITLE)}
