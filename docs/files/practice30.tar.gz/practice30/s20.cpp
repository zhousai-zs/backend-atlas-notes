#include <concepts>
#include <ranges>
#include <vector>
#include <cstdio>
template <std::integral T>
T clamp_qps(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
int main() {
  std::vector<int> latency_ms{12, 250, 8, 900, 40, 1300};
  auto slow = latency_ms | std::views::filter([](int x){ return x > 200; })
                         | std::views::transform([](int x){ return x / 100; });
  for (int x : slow) std::printf("slow bucket %d\n", x);
  std::printf("clamp=%d\n", clamp_qps(5000, 1, 1000));
  // clamp_qps(1.5, 1.0, 2.0); // 编译失败：double 不满足 std::integral
}
