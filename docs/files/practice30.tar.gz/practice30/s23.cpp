#include <expected>
#include <string>
#include <cstdio>
enum class Err { Empty, NotNumber, OutOfRange };
std::expected<int, Err> parse_timeout(const std::string& s) {
  if (s.empty()) return std::unexpected(Err::Empty);
  int v = 0;
  for (char c : s) {
    if (c < '0' || c > '9') return std::unexpected(Err::NotNumber);
    v = v * 10 + (c - '0');
    if (v > 60000) return std::unexpected(Err::OutOfRange);
  }
  return v;
}
int main() {
  for (std::string s : {"3000", "", "3s", "99999"}) {
    auto r = parse_timeout(s);
    if (r) std::printf("'%s' ok %d\n", s.c_str(), *r);
    else   std::printf("'%s' err %d\n", s.c_str(), static_cast<int>(r.error()));
  }
  auto doubled = parse_timeout("1500").transform([](int v){ return v * 2; });
  std::printf("doubled=%d\n", doubled.value_or(-1));
}
