#include <optional>
#include <variant>
#include <string>
#include <map>
#include <cstdio>
std::optional<std::string> find_nick(const std::map<int,std::string>& m, int uid) {
  if (auto it = m.find(uid); it != m.end()) return it->second;
  return std::nullopt;
}
struct Text { std::string content; };
struct Image { std::string media_id; int width; };
using Msg = std::variant<Text, Image>;
template <class... F> struct overloaded : F... { using F::operator()...; };
template <class... F> overloaded(F...) -> overloaded<F...>;
int main() {
  std::map<int,std::string> m{{1001,"alice"}};
  for (int uid : {1001, 1002}) {
    auto n = find_nick(m, uid);
    std::printf("%d -> %s\n", uid, n.value_or("<none>").c_str());
  }
  for (const auto& [uid, nick] : m) std::printf("binding %d=%s\n", uid, nick.c_str());
  Msg msgs[] = {Text{"hi"}, Image{"m_123", 640}};
  for (auto& msg : msgs)
    std::visit(overloaded{
      [](const Text& t){ std::printf("text: %s\n", t.content.c_str()); },
      [](const Image& i){ std::printf("image: %s w=%d\n", i.media_id.c_str(), i.width); }
    }, msg);
}
