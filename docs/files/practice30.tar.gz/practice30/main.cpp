#include "result.hpp"
#include <cstdio>
int main() {
  std::printf("std=%ld impl=%s\n", (long)__cplusplus, RESULT_IMPL);
  const char* cases[] = {"8080", "", "80a", "70000", "0", "443"};
  int fails = 0;
  bool expect_ok[] = {true, false, false, false, false, true};
  for (int i = 0; i < 6; ++i) {
    auto r = parse_port(cases[i]);
    if (ok(r)) std::printf("  '%s' -> %d\n", cases[i], value(r));
    else std::printf("  '%s' -> error: %s\n", cases[i], error(r).c_str());
    if (ok(r) != expect_ok[i]) ++fails;
  }
  std::puts(fails ? "FAIL" : "ALL_CHECKS_PASSED");
  return fails;
}
