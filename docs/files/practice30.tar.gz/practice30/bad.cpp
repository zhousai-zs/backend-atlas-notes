#include <expected>
std::expected<int,int> f(){return 1;}
int main(){return *f()-1;}
