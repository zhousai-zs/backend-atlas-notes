#pragma once
// 小库：解析配置里的端口号。C++23 用 std::expected，C++17 用 variant 替代实现。
#include <string>
#include <string_view>
#include <version>
#if defined(__cpp_lib_expected) && __cpp_lib_expected >= 202211L
  #include <expected>
  #define RESULT_IMPL "std::expected"
  template <class T> using Result = std::expected<T, std::string>;
  inline auto make_err(std::string m) { return std::unexpected(std::move(m)); }
  template <class T> bool ok(const Result<T>& r) { return r.has_value(); }
  template <class T> const T& value(const Result<T>& r) { return *r; }
  template <class T> const std::string& error(const Result<T>& r) { return r.error(); }
#else
  #include <variant>
  #define RESULT_IMPL "std::variant fallback"
  struct Err { std::string msg; };
  template <class T> using Result = std::variant<T, Err>;
  inline Err make_err(std::string m) { return Err{std::move(m)}; }
  template <class T> bool ok(const Result<T>& r) { return r.index() == 0; }
  template <class T> const T& value(const Result<T>& r) { return std::get<0>(r); }
  template <class T> const std::string& error(const Result<T>& r) { return std::get<1>(r).msg; }
#endif

inline Result<int> parse_port(std::string_view s) {
  if (s.empty()) return make_err("empty");
  int v = 0;
  for (char c : s) {
    if (c < '0' || c > '9') return make_err("not a number: " + std::string(s));
    v = v * 10 + (c - '0');
    if (v > 65535) return make_err("out of range: " + std::string(s));
  }
  if (v == 0) return make_err("port 0 not allowed");
  return v;
}
