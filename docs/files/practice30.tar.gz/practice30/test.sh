#!/bin/sh
set -e
cd "$(dirname "$0")"
g++ --version | head -1
for s in c++17 c++23; do
  echo "== -std=$s"
  g++ -std=$s -Wall -Wextra -fsanitize=address,undefined main.cpp -o port_$s
  ./port_$s
done
echo "== 在 C++17 下直接用 std::expected（预期编译失败）"
printf '#include <expected>\nstd::expected<int,int> f(){return 1;}\nint main(){return *f()-1;}\n' > bad.cpp
if g++ -std=c++17 bad.cpp -o /dev/null 2>err.txt; then echo "UNEXPECTED: compiled"; exit 1; else grep -m1 -E "error" err.txt; echo "rejected as expected"; fi
g++ -std=c++23 bad.cpp -o bad && ./bad && echo "c++23 compiles bad.cpp OK"
