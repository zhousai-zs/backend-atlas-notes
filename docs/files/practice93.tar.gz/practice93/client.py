"""用法: client.py PORT CERTNAME|none OP KEY [VALUE] [--host H] [--token T] [--big N] [--plain] [--repeat N]"""
import argparse, json, socket, ssl, struct
p = argparse.ArgumentParser()
p.add_argument("port", type=int); p.add_argument("cert"); p.add_argument("op"); p.add_argument("key")
p.add_argument("value", nargs="?"); p.add_argument("--host", default="localhost")
p.add_argument("--token"); p.add_argument("--big", type=int, default=0)
p.add_argument("--plain", action="store_true"); p.add_argument("--repeat", type=int, default=1)
a = p.parse_args()

def recv_exact(c, n):
    b = b""
    while len(b) < n:
        x = c.recv(n - len(b))
        if not x: raise ConnectionError("eof")
        b += x
    return b

raw = socket.create_connection(("127.0.0.1", a.port), timeout=3)
try:
    if a.plain:
        conn = raw
    else:
        ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile="certs/ca.crt")  # 校验服务端证书链+主机名
        if a.cert != "none":
            ctx.load_cert_chain(f"certs/{a.cert}.crt", f"certs/{a.cert}.key")
        conn = ctx.wrap_socket(raw, server_hostname=a.host)
        conn.getpeercert()
    req = {"op": a.op, "key": a.key}
    if a.value is not None: req["value"] = a.value
    if a.token: req["token"] = a.token
    if a.big: req["value"] = "x" * a.big
    data = json.dumps(req).encode()
    codes = []
    for _ in range(a.repeat):
        conn.sendall(struct.pack(">I", len(data)) + data)
        (n,) = struct.unpack(">I", recv_exact(conn, 4))
        resp = json.loads(recv_exact(conn, n)); codes.append(resp["code"])
    if a.repeat == 1:
        print("TLS" if not a.plain else "PLAIN", getattr(conn, "version", lambda: "-")(), json.dumps(resp, ensure_ascii=False))
    else:
        print("CODES", " ".join(f"{c}={codes.count(c)}" for c in sorted(set(codes))))
except ssl.SSLCertVerificationError as e:
    print("CLIENT_VERIFY_FAIL", e.verify_message)
except (ssl.SSLError, ConnectionError, OSError) as e:
    print("CONN_FAIL", type(e).__name__, getattr(e, "reason", "") or e)
