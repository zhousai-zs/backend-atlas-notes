"""practice93: 带 mTLS、角色授权、消息大小限制、按身份限速和审计日志的 KV 服务（教学用）。
协议：4 字节大端长度 + JSON 包体。请求 {"op":"GET|PUT|DELETE","key":..,"value":..,"token":可选}
"""
import json, socket, ssl, struct, sys, threading, time

MAX_MSG = 64 * 1024              # 最大消息 64KB：先看长度头，超限直接拒绝，不读包体
RATE, BURST = 5.0, 10            # 每身份令牌桶：每秒 5 个，突发 10 个
ROLE_OF = {"reader-cli": "reader", "writer-cli": "writer"}   # 身份 -> 角色
PERMS = {"reader": {"GET"}, "writer": {"GET", "PUT", "DELETE"}}  # 角色 -> 方法；没列的一律拒绝
SENSITIVE = {"token", "password", "authorization"}

store = {"cfg/banner": "hello"}
lock = threading.Lock()
buckets = {}
audit = open(sys.argv[2] if len(sys.argv) > 2 else "audit.log", "a", buffering=1)

def redact(req):
    return {k: ("***" if k.lower() in SENSITIVE else v) for k, v in req.items() if k != "value"}

def log(identity, op, key, result, extra=None):
    rec = {"ts": round(time.time(), 3), "identity": identity, "op": op, "key": key, "result": result}
    if extra: rec["req"] = extra
    audit.write(json.dumps(rec, ensure_ascii=False) + "\n")

def allow(identity):
    now = time.monotonic()
    tokens, last = buckets.get(identity, (BURST, now))
    tokens = min(BURST, tokens + (now - last) * RATE)
    ok = tokens >= 1
    buckets[identity] = (tokens - 1 if ok else tokens, now)
    return ok

def recv_exact(conn, n):
    buf = b""
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk: raise ConnectionError("eof")
        buf += chunk
    return buf

def send(conn, obj):
    data = json.dumps(obj).encode()
    conn.sendall(struct.pack(">I", len(data)) + data)

def identity_of(conn):
    cert = conn.getpeercert()   # 已经过 CA 校验的客户端证书
    for rdn in cert.get("subject", ()):
        for k, v in rdn:
            if k == "commonName": return v
    return None

def handle(conn):
    try:
        ident = identity_of(conn)
        role = ROLE_OF.get(ident)
        while True:
            (n,) = struct.unpack(">I", recv_exact(conn, 4))
            if n > MAX_MSG:
                log(ident, "?", None, "RESOURCE_EXHAUSTED", {"size": n})
                send(conn, {"code": "RESOURCE_EXHAUSTED", "msg": f"message {n} > {MAX_MSG}"})
                return  # 不读包体，直接断开
            req = json.loads(recv_exact(conn, n))
            op, key = req.get("op"), req.get("key")
            if not allow(ident):
                log(ident, op, key, "RATE_LIMITED"); send(conn, {"code": "RESOURCE_EXHAUSTED", "msg": "rate limited"}); continue
            if role is None or op not in PERMS.get(role, set()):
                log(ident, op, key, "PERMISSION_DENIED", redact(req))
                send(conn, {"code": "PERMISSION_DENIED", "msg": f"{ident} ({role}) cannot {op}"}); continue
            with lock:
                if op == "GET": resp = {"code": "OK", "value": store.get(key)}
                elif op == "PUT": store[key] = req.get("value"); resp = {"code": "OK"}
                else: resp = {"code": "OK", "deleted": store.pop(key, None) is not None}
            log(ident, op, key, "OK", redact(req)); send(conn, resp)
    except (ConnectionError, ssl.SSLError, OSError):
        pass
    finally:
        conn.close()

def main():
    port = int(sys.argv[1])
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain("certs/server.crt", "certs/server.key")
    ctx.load_verify_locations("certs/ca.crt")
    ctx.verify_mode = ssl.CERT_REQUIRED          # mTLS：没有受信客户端证书的握手失败
    s = socket.create_server(("127.0.0.1", port))
    print(f"LISTEN {port}", flush=True)
    while True:
        raw, _ = s.accept()
        try:
            conn = ctx.wrap_socket(raw, server_side=True)
        except (ssl.SSLError, OSError) as e:
            print(f"HANDSHAKE_REJECTED {type(e).__name__}: {getattr(e, 'reason', e)}", flush=True)
            raw.close(); continue
        threading.Thread(target=handle, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    main()
