#!/usr/bin/env bash
# practice93：加密链路层与业务授权层分别测试；日志不暴露凭证
set -u
cd "$(dirname "$0")"
PORT=${PORT:-19393}; FAIL=0
ok(){ echo "PASS $1"; }; bad(){ echo "FAIL $1"; FAIL=1; }
rm -rf certs audit.log server.out; mkdir certs
gen_ca(){ openssl req -x509 -newkey rsa:2048 -nodes -days 30 -subj "/CN=$1" -keyout certs/$1.key -out certs/$1.crt \
  -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null; }
sign(){ # name CN ca [san]
  openssl req -newkey rsa:2048 -nodes -subj "/CN=$2" -keyout certs/$1.key -out certs/$1.csr 2>/dev/null
  { echo "basicConstraints=CA:FALSE"; echo "keyUsage=critical,digitalSignature,keyEncipherment"
    echo "subjectKeyIdentifier=hash"; echo "authorityKeyIdentifier=keyid"
    if [ -n "${4:-}" ]; then echo "extendedKeyUsage=serverAuth"; echo "subjectAltName=$4"; else echo "extendedKeyUsage=clientAuth"; fi; } > certs/$1.ext
  openssl x509 -req -in certs/$1.csr -CA certs/$3.crt -CAkey certs/$3.key -CAcreateserial -days 30 -extfile certs/$1.ext -out certs/$1.crt 2>/dev/null; }
gen_ca ca; gen_ca rogue-ca
sign server kv-server ca "DNS:localhost,IP:127.0.0.1"
sign reader-cli reader-cli ca; sign writer-cli writer-cli ca; sign rogue-cli writer-cli rogue-ca
openssl x509 -in certs/reader-cli.crt -noout -subject -issuer
python3 kvserver.py $PORT audit.log > server.out 2>&1 & SRV=$!; trap 'kill $SRV 2>/dev/null' EXIT
for i in $(seq 50); do grep -q LISTEN server.out && break; sleep 0.1; done
C(){ python3 client.py $PORT "$@"; }
SECRET="tok-SECRET-9f3a"

echo "== A. 加密链路层（与授权无关，只看握手）"
r=$(C reader-cli GET cfg/banner --plain); echo "  明文客户端: $r"; [[ $r == CONN_FAIL* ]] && ok "A1 明文连接 TLS 端口失败" || bad A1
r=$(C none GET cfg/banner); echo "  无客户端证书: $r"; [[ $r == CONN_FAIL* ]] && ok "A2 无证书被拒绝" || bad A2
r=$(C rogue-cli GET cfg/banner); echo "  非受信 CA 签发(CN 冒充 writer-cli): $r"; [[ $r == CONN_FAIL* ]] && ok "A3 冒名证书被拒绝" || bad A3
r=$(C reader-cli GET cfg/banner --host evil.example); echo "  主机名不匹配: $r"; [[ $r == CLIENT_VERIFY_FAIL* ]] && ok "A4 客户端校验服务端主机名" || bad A4
r=$(C reader-cli GET cfg/banner); echo "  正常 mTLS: $r"; [[ $r == "TLS TLSv1."* ]] && ok "A5 mTLS 握手成功" || bad A5
echo "  服务端握手拒绝记录: $(grep -c HANDSHAKE_REJECTED server.out) 次"
echo "| openssl s_client 复核:"; echo | openssl s_client -connect 127.0.0.1:$PORT -CAfile certs/ca.crt -cert certs/reader-cli.crt -key certs/reader-cli.key -servername localhost 2>/dev/null | grep -E "Verify return code|Protocol" | sed 's/^/    /'

echo "== B. 业务授权层（都持合法证书，只看权限）"
r=$(C reader-cli PUT cfg/banner hacked --token $SECRET); echo "  reader PUT: $r"; [[ $r == *PERMISSION_DENIED* ]] && ok "B1 只读角色越权写入被拒绝" || bad B1
r=$(C reader-cli DELETE cfg/banner); [[ $r == *PERMISSION_DENIED* ]] && ok "B2 只读角色删除被拒绝" || bad B2
r=$(C reader-cli GET cfg/banner); echo "  越权后值: $r"; [[ $r == *'"hello"'* ]] && ok "B3 值未被改动" || bad B3
r=$(C writer-cli PUT cfg/banner v2 --token $SECRET); [[ $r == *'"OK"'* ]] && ok "B4 writer 写入成功" || bad B4
r=$(C reader-cli GET cfg/banner); [[ $r == *'"v2"'* ]] && ok "B5 reader 读到新值" || bad B5

echo "== C. 输入规模与速率"
r=$(C writer-cli PUT big --big 200000); echo "  200KB 请求: $r"; [[ $r == *RESOURCE_EXHAUSTED* ]] && ok "C1 超过 64KB 被拒绝" || bad C1
sleep 2.2
r=$(C reader-cli GET cfg/banner --repeat 30); echo "  reader 连发 30 次: $r"; [[ $r == *RESOURCE_EXHAUSTED=* && $r == *OK=* ]] && ok "C2 按身份限速生效" || bad C2
r=$(C writer-cli GET cfg/banner); [[ $r == *'"OK"'* ]] && ok "C3 其他身份不受影响" || bad C3

echo "== D. 审计与凭证"
grep PERMISSION_DENIED audit.log | head -1 | sed 's/^/  /'
grep -q '"identity": "reader-cli", "op": "PUT"' audit.log && ok "D1 越权写入有审计记录" || bad D1
if grep -rq "$SECRET" audit.log server.out; then bad "D2 日志泄露令牌"; else ok "D2 日志不含令牌（已脱敏为 ***）"; fi
if grep -q "PRIVATE KEY" audit.log server.out; then bad D3; else ok "D3 日志不含私钥"; fi
echo "  审计行数: $(wc -l < audit.log)"
[ $FAIL = 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
