"""Versioned teaching service. v2 can inject latency or write a one-way data file."""
from __future__ import annotations

import json, os, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = os.environ.get("REL_VERSION", "v1")
DELAY = float(os.environ.get("REL_DELAY", "0.005"))
DATA_FILE = os.environ.get("DATA_FILE", "")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        return

    def do_GET(self):
        if self.path != "/work":
            self.send_response(404); self.end_headers(); return
        t0 = time.perf_counter()
        time.sleep(DELAY)
        if VERSION == "v2" and DATA_FILE:
            # one-way "migration": once written, rollback of the app does not delete it
            if not os.path.exists(DATA_FILE):
                with open(DATA_FILE, "w") as f:
                    f.write("schema=v2-migrated\n")
        body = json.dumps({
            "ok": True,
            "version": VERSION,
            "latency_ms": round((time.perf_counter() - t0) * 1000, 3),
        }).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Version", VERSION)
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    port = int(os.environ["REL_PORT"])
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
