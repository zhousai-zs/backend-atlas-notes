#!/usr/bin/env python3
from __future__ import annotations

import hashlib, json, os, shutil, subprocess, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ART = ROOT / "artifacts"
REPORTS = ROOT / "reports"
ART.mkdir(exist_ok=True)
REPORTS.mkdir(exist_ok=True)
DATA = REPORTS / "migration.dat"
if DATA.exists():
    DATA.unlink()

V1_PORT, V2_PORT = 18881, 18882


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_release(version: str, delay: float, notes: str) -> Path:
    body = json.dumps({"version": version, "delay": delay, "notes": notes}, indent=2) + "\n"
    digest = hashlib.sha256(body.encode()).hexdigest()[:16]
    path = ART / f"{version}-{digest}.json"
    path.write_text(body)
    return path


def start(version, port, delay):
    env = os.environ.copy()
    env.update({"REL_VERSION": version, "REL_PORT": str(port), "REL_DELAY": str(delay), "DATA_FILE": str(DATA)})
    return subprocess.Popen([sys.executable, str(ROOT / "service.py")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def call(port, timeout=1.5):
    t0 = time.perf_counter()
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/work", timeout=timeout) as r:
        body = json.loads(r.read().decode())
    return body | {"wall_ms": (time.perf_counter() - t0) * 1000}


def percentile(xs, q):
    if not xs:
        return None
    import math
    s = sorted(xs)
    k = max(0, min(len(s) - 1, math.ceil((q / 100.0) * (len(s) - 1))))
    return s[k]


def route(canary_share: float, n: int):
    """Send n requests; first floor(n*share) go to v2 after a stable prefix? Better: every 20th is canary for 5%."""
    samples = {"v1": [], "v2": []}
    records = []
    for i in range(n):
        use_canary = (i % 20) < int(round(20 * canary_share))  # 1 of 20 = 5%
        port = V2_PORT if use_canary else V1_PORT
        rec = call(port)
        samples[rec["version"]].append(rec["wall_ms"])
        records.append(rec)
    return samples, records


def maybe_rollback(samples, threshold_ms=50.0):
    p99_v1 = percentile(samples["v1"], 99)
    p99_v2 = percentile(samples["v2"], 99)
    decision = "continue"
    if p99_v2 is not None and p99_v2 > threshold_ms:
        decision = "rollback"
    return {"p99_v1": p99_v1, "p99_v2": p99_v2, "threshold_ms": threshold_ms, "decision": decision}


def main():
    rel_v1 = write_release("v1", 0.005, "baseline config")
    rel_v2 = write_release("v2", 0.12, "canary config with injected latency")
    p1 = start("v1", V1_PORT, 0.005)
    p2 = start("v2", V2_PORT, 0.12)
    time.sleep(0.15)
    try:
        # both versions run at once
        samples, records = route(0.05, 200)
        metrics = maybe_rollback(samples, threshold_ms=50.0)
        assert metrics["decision"] == "rollback"
        assert samples["v1"] and samples["v2"]
        share = len(samples["v2"]) / (len(samples["v1"]) + len(samples["v2"]))
        # rollback: stop sending to v2, keep artifact
        rollback_to = rel_v1
        assert rollback_to.exists()
        after, _ = route(0.0, 40)  # 0% canary after rollback
        assert not after["v2"]
        migration_remains = DATA.exists() and "schema=v2-migrated" in DATA.read_text()
        results = {
            "lesson": 155,
            "id": "j-release",
            "is_live_prod_traffic": False,
            "canary_share_planned": 0.05,
            "canary_share_observed": round(share, 4),
            "requests_v1": len(samples["v1"]),
            "requests_v2": len(samples["v2"]),
            "metrics": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in metrics.items()},
            "both_versions_running_during_canary": True,
            "rollback_artifact": str(rollback_to.relative_to(ROOT)),
            "rollback_artifact_sha256": sha256(rollback_to),
            "canary_artifact": str(rel_v2.relative_to(ROOT)),
            "migration_file_remains_after_app_rollback": migration_remains,
            "nginx_sample_config": "nginx/canary-5percent.conf",
            "nginx_config_applied_here": False,
            "service_mesh_or_ingress_canary_verified": False,
            "verified_on_this_machine": [
                "local_two_process_5_percent_split",
                "p99_stop_condition_triggers_rollback",
                "rollback_artifact_hashed_and_locatable",
                "v1_and_v2_ran_together_during_canary",
                "data_migration_file_remains_after_app_rollback",
            ],
            "not_verified_on_this_machine": [
                "nginx_or_envoy_weighted_proxy_in_front_of_the_services",
                "mesh_or_ingress_canary_controller",
                "production_traffic_and_long_tail_observation_window",
            ],
        }
        assert 0.03 <= share <= 0.08
        assert migration_remains
        (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
        (REPORTS / "canary.txt").write_text(json.dumps(results, indent=2))
        print(json.dumps(results, ensure_ascii=False, indent=2))
        print("ALL_CHECKS_PASSED")
    finally:
        p1.terminate(); p2.terminate()
        p1.wait(timeout=2); p2.wait(timeout=2)


if __name__ == "__main__":
    main()
