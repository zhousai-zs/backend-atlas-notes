#!/usr/bin/env bash
set -euo pipefail
cat <<'TXT'
Local decision logic (this practice already runs it):
  bash test.sh
  # 200 requests, 5% to v2, p99(v2) vs threshold, rollback to the v1 artifact.

A real proxy / mesh canary (not run on the teaching box unless you have one):
  1. nginx: use nginx/canary-5percent.conf, reload, and measure p99 per upstream
     with access logs or a sidecar histogram. Weighted share is not a guarantee
     of exact 5% on a short sample.
  2. Kubernetes + Istio / Gateway API / Flagger / Ingress canary: follow those
     projects' docs; keep the *same* stop condition (p99 or error rate) you
     used in maybe_rollback().
  3. After rollback, confirm the *application* artifact is the previous hash,
     then separately inspect whether a data migration file or schema change
     is still present. Application rollback does not undo migrations.

Google SRE Workbook, Canarying Releases (fetched 2026-11-15):
  https://sre.google/workbook/canarying-releases/
TXT
