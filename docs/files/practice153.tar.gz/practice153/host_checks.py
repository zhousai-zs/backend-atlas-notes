"""Host-side checks on the same C++ service source.

These verify the *process* contract (SIGTERM, non-root refusal, allocator
failure under RLIMIT_AS). They are not cgroup OOM and not a container runtime.
"""

from __future__ import annotations

import os
import resource
import shutil
import signal
import stat
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
SECRET = "atlas-compile-key-1492"
CXX = ROOT / "tools" / "zig-c++"
BIN = ROOT / "reports" / "service-host"


def _env() -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("ZIG_LOCAL_CACHE_DIR", "/tmp/zig-cache-unit")
    env.setdefault("ZIG_GLOBAL_CACHE_DIR", "/tmp/zig-cache-unit")
    return env


def compile_service() -> Path:
    REPORTS.mkdir(exist_ok=True)
    if BIN.exists():
        BIN.unlink()
    cmd = [
        str(CXX),
        "-target",
        "x86_64-linux-gnu",
        "-std=c++17",
        "-O2",
        "-fno-omit-frame-pointer",
        str(ROOT / "service.cpp"),
        "-o",
        str(BIN),
    ]
    subprocess.run(cmd, check=True, env=_env())
    BIN.chmod(BIN.stat().st_mode | stat.S_IXUSR)
    return BIN


def secret_not_in_binary(bin_path: Path) -> dict:
    data = bin_path.read_bytes()
    leaked = SECRET.encode() in data
    return {"binary": str(bin_path.name), "secret_embedded_in_binary": leaked}


def run_sigterm() -> dict:
    status = REPORTS / "host-service-status.txt"
    if status.exists():
        status.unlink()
    proc = subprocess.Popen(
        [str(BIN), "--status-path", str(status)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    deadline = time.time() + 3
    while time.time() < deadline:
        if status.exists() and "ready" in status.read_text():
            break
        if proc.poll() is not None:
            break
        time.sleep(0.05)
    if not status.exists():
        proc.kill()
        raise SystemExit(f"host process never became ready: {proc.communicate()}")
    proc.send_signal(signal.SIGTERM)
    try:
        rc = proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()
        raise SystemExit("host process ignored SIGTERM")
    text = status.read_text() if status.exists() else ""
    return {
        "exit": rc,
        "status_text": text.strip(),
        "shutdown_ok": rc == 0 and "shutdown_ok" in text,
        "uid_line": next((ln for ln in text.splitlines() if ln.startswith("uid=")), ""),
    }


def run_rlimit_as_via_python() -> dict:
    helper = REPORTS / "rlimit_helper.py"
    helper.write_text(
        "import os, resource, sys\n"
        "limit = 16 * 1024 * 1024\n"
        "resource.setrlimit(resource.RLIMIT_AS, (limit, limit))\n"
        "os.execv(sys.argv[1], [sys.argv[1], '--eat-mb', '64'])\n"
    )
    proc = subprocess.run(
        [os.environ.get("PYTHON", sys_executable()), str(helper), str(BIN)],
        capture_output=True,
        text=True,
        timeout=10,
    )
    log = REPORTS / "memory-rlimit.txt"
    log.write_text(
        f"RLIMIT_AS=16MiB eat=64MiB exit={proc.returncode}\n"
        f"stdout={proc.stdout}\nstderr={proc.stderr}\n"
        "this_is_not_cgroup_oom=true\n"
        "typical_cgroup_oom_exit=137\n"
    )
    return {
        "exit": proc.returncode,
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "is_cgroup_oom": False,
        "observed_exit_is_137": proc.returncode == 137,
        "allocation_failed": proc.returncode != 0,
    }


def sys_executable() -> str:
    import sys

    return sys.executable


def probe_cgroup() -> dict:
    result = {"writable": False, "error": "", "controllers": ""}
    ctrl = Path("/sys/fs/cgroup/cgroup.controllers")
    if ctrl.exists():
        result["controllers"] = ctrl.read_text().strip()
    for base in (
        Path("/sys/fs/cgroup"),
        Path("/sys/fs/cgroup/agent"),
        Path("/sys/fs/cgroup/background"),
        Path("/sys/fs/cgroup/user.slice"),
    ):
        if not base.is_dir():
            continue
        d = base / f"atlas-153-{os.getpid()}"
        try:
            d.mkdir()
        except OSError as e:
            result["error"] = f"mkdir {d}: {e}"
            continue
        result["writable"] = True
        result["error"] = ""
        d.rmdir()
        break
    return result


def engine_probe() -> dict:
    docker = shutil.which("docker")
    podman = shutil.which("podman")
    socket_paths = [
        Path("/var/run/docker.sock"),
        Path(f"/run/user/{os.getuid()}/docker.sock"),
        Path(f"/run/user/{os.getuid()}/podman/podman.sock"),
    ]
    return {
        "docker_path": docker,
        "podman_path": podman,
        "sockets_present": [str(p) for p in socket_paths if p.exists()],
        "engine_binary_present": bool(docker or podman),
    }
