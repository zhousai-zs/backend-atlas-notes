#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export ZIG_LOCAL_CACHE_DIR="${ZIG_LOCAL_CACHE_DIR:-/tmp/zig-cache-unit}"
export ZIG_GLOBAL_CACHE_DIR="${ZIG_GLOBAL_CACHE_DIR:-/tmp/zig-cache-unit}"
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
# The passing string is not enough: refuse a run that claims a live engine
# without a docker-e2e log, and refuse a skipped engine with an empty gap list.
"$PY" - <<'PY'
import json, sys
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["directory_layout_is_not_an_image"] is True
if r["docker_e2e_verified"]:
    assert r["is_live_container_runtime"] is True
    assert r["docker_e2e"]["exit"] == 0
else:
    assert r["is_live_container_runtime"] is False
    assert r["not_verified_on_this_machine"], r
    assert r["host_rlimit_as"]["is_cgroup_oom"] is False
    assert r["host_rlimit_as"]["exit"] != 137
    # log must mention the skip, not pretend docker build ran
    assert "docker_e2e_verified" in Path("results.json").read_text()
print("POSTCHECK_OK")
PY
