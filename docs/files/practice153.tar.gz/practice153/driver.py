#!/usr/bin/env python3
"""j-container acceptance.

Core, if a container engine is usable: scripts/docker-e2e.sh.
On this machine the engine is typically absent; then we accept only
(1) static Dockerfile policy and (2) host-side process checks, and we
explicitly list the end-to-end items that were NOT run.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from host_checks import (
    compile_service,
    engine_probe,
    probe_cgroup,
    run_rlimit_as_via_python,
    run_sigterm,
    secret_not_in_binary,
)
from static_check import check_dockerfile

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def run_docker_e2e() -> dict:
    script = ROOT / "scripts" / "docker-e2e.sh"
    proc = subprocess.run(
        ["bash", str(script)],
        capture_output=True,
        text=True,
        timeout=300,
    )
    (REPORTS / "docker-e2e.log").write_text(
        f"exit={proc.returncode}\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}\n"
    )
    if proc.returncode == 0:
        return {
            "attempted": True,
            "verified": True,
            "skip_reason": None,
            "exit": 0,
            "tail": proc.stdout.strip().splitlines()[-3:],
        }
    if proc.returncode == 2:
        return {
            "attempted": True,
            "verified": False,
            "skip_reason": (proc.stdout or proc.stderr).strip().splitlines()[-1] if (proc.stdout or proc.stderr) else "engine_unavailable",
            "exit": 2,
        }
    return {
        "attempted": True,
        "verified": False,
        "skip_reason": None,
        "exit": proc.returncode,
        "stdout": proc.stdout[-2000:],
        "stderr": proc.stderr[-2000:],
        "failed": True,
    }


def main() -> int:
    static = check_dockerfile()
    assert static["ok"], static["errors"]

    compile_service()
    binary = secret_not_in_binary(REPORTS / "service-host")
    assert not binary["secret_embedded_in_binary"], "host binary contains the compile secret"

    sig = run_sigterm()
    assert sig["shutdown_ok"], sig

    rlimit = run_rlimit_as_via_python()
    assert rlimit["allocation_failed"], rlimit
    assert not rlimit["is_cgroup_oom"]
    # RLIMIT_AS usually surfaces as malloc failure (this source returns 2), not 137.
    assert rlimit["exit"] != 137

    cgroup = probe_cgroup()
    engine = engine_probe()
    docker = run_docker_e2e()
    # If an engine exists and e2e failed hard, fail the lesson.
    if docker.get("failed"):
        print(json.dumps(docker, indent=2))
        print("DOCKER_E2E_FAILED")
        return 1

    verified = [
        "dockerfile_static_multistage_copy_from_and_nonroot_user",
        "host_binary_does_not_embed_compile_secret",
        "host_process_handles_SIGTERM_exit_0",
        "host_RLIMIT_AS_stops_allocation_and_is_not_cgroup_OOM_137",
    ]
    unverified = []
    if not docker["verified"]:
        unverified.extend(
            [
                "docker_or_podman_build_of_the_image",
                "runtime_image_rootfs_secret_scan_via_container_export",
                "docker_stop_SIGTERM_inside_a_container",
                "engine_memory_flag_or_cgroup_memory_max_OOM_exit_137",
                "USER_and_namespaces_enforced_by_a_container_runtime",
            ]
        )
    if not cgroup["writable"]:
        if "engine_memory_flag_or_cgroup_memory_max_OOM_exit_137" not in unverified:
            unverified.append("cgroup_memory_max_writable_on_this_user")
    if docker["verified"]:
        verified.append("docker_e2e_script")
        unverified = [u for u in unverified if "docker" not in u and "engine_memory" not in u and "USER_and_namespaces" not in u]
        if not cgroup["writable"]:
            # docker may still have enforced --memory even if we cannot mkdir a cgroup
            pass

    results = {
        "lesson": 153,
        "id": "j-container",
        "is_live_container_runtime": bool(docker["verified"]),
        "docker_e2e_verified": bool(docker["verified"]),
        "docker_e2e": docker,
        "engine": engine,
        "cgroup": cgroup,
        "dockerfile_static": static,
        "host_binary": binary,
        "host_sigterm": sig,
        "host_rlimit_as": rlimit,
        "verified_on_this_machine": verified,
        "not_verified_on_this_machine": unverified,
        "directory_layout_is_not_an_image": True,
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    # Passing requires honesty: when the engine is missing, unverified must be recorded.
    if not docker["verified"]:
        assert unverified, "engine missing but not_verified list empty"
        assert results["is_live_container_runtime"] is False
    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
