#!/usr/bin/env python3
"""Materialize a multi-stage image layout without Docker, then probe limits."""
from __future__ import annotations

import json, os, shutil, signal, stat, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SECRET = (ROOT / "BUILD_SECRET.txt").read_text().strip()
BUILD = ROOT / "rootfs-build"
RUNTIME = ROOT / "rootfs-runtime"
REPORTS = ROOT / "reports"
BIN = RUNTIME / "usr/local/bin/service"
CXX = ROOT / "tools/zig-c++"
results = {
    "lesson": 153,
    "id": "j-container",
    "docker_daemon": shutil.which("docker") is not None or shutil.which("podman") is not None,
    "cgroup_writable": False,
    "cgroup_error": "",
    "is_live_container_runtime": False,
}


def reset_dir(path: Path):
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True)


def build_stages():
    reset_dir(BUILD)
    reset_dir(RUNTIME)
    (BUILD / "secret").mkdir()
    (BUILD / "src").mkdir()
    shutil.copy(ROOT / "service.cpp", BUILD / "src/service.cpp")
    (BUILD / "secret/compile-secret").write_text(SECRET + "\n")
    (RUNTIME / "usr/local/bin").mkdir(parents=True)
    (RUNTIME / "etc").mkdir()
    (RUNTIME / "etc/passwd").write_text("app:x:1000:1000:app:/home/app:/usr/sbin/nologin\n")
    REPORTS.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.setdefault("ZIG_LOCAL_CACHE_DIR", "/tmp/zig-cache-unit")
    env.setdefault("ZIG_GLOBAL_CACHE_DIR", "/tmp/zig-cache-unit")
    cmd = [str(CXX), "-target", "x86_64-linux-gnu", "-std=c++17", "-O2",
           "-fno-omit-frame-pointer", str(ROOT / "service.cpp"), "-o", str(BIN)]
    subprocess.run(cmd, check=True, env=env)
    BIN.chmod(BIN.stat().st_mode | stat.S_IXUSR)


def scan_secret():
    def found_in(root: Path) -> list[str]:
        hits = []
        for p in root.rglob("*"):
            if not p.is_file() or p.is_symlink():
                continue
            try:
                data = p.read_bytes()
            except OSError:
                continue
            if SECRET.encode() in data:
                hits.append(str(p.relative_to(root)))
        return hits

    build_hits = found_in(BUILD)
    runtime_hits = found_in(RUNTIME)
    (REPORTS / "secret-scan.txt").write_text(
        f"secret={SECRET}\nbuild_hits={build_hits}\nruntime_hits={runtime_hits}\n"
    )
    results["secret_in_build"] = build_hits
    results["secret_in_runtime"] = runtime_hits
    assert build_hits, "compile secret should exist in the build stage"
    assert not runtime_hits, f"runtime image leaked compile secret: {runtime_hits}"


def probe_cgroup():
    for base in (Path("/sys/fs/cgroup"), Path("/sys/fs/cgroup/agent"), Path("/sys/fs/cgroup/background")):
        d = base / f"atlas-153-{os.getpid()}"
        try:
            d.mkdir()
        except OSError as e:
            results["cgroup_error"] = f"mkdir {d}: {e}"
            continue
        results["cgroup_writable"] = True
        try:
            (d / "memory.max").write_text("16M\n")
        finally:
            try:
                d.rmdir()
            except OSError:
                pass
        break
    results["cgroup_controllers"] = Path("/sys/fs/cgroup/cgroup.controllers").read_text().strip() if Path("/sys/fs/cgroup/cgroup.controllers").exists() else ""


def memory_limit():
    import resource
    limit = 16 * 1024 * 1024

    def setlim():
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

    log = REPORTS / "memory-rlimit.txt"
    p = subprocess.run([str(BIN), "--eat-mb", "64"], capture_output=True, text=True, preexec_fn=setlim)
    log.write_text(f"RLIMIT_AS=16MiB eat=64MiB exit={p.returncode}\nstdout={p.stdout}\nstderr={p.stderr}\n")
    results["rlimit_as_bytes"] = limit
    results["rlimit_exit"] = p.returncode
    results["rlimit_stderr"] = p.stderr.strip()
    assert p.returncode != 0, "memory-limited process should not fully allocate 64MiB"
    # This is POSIX RLIMIT_AS, not cgroup OOM (which would typically be 137).
    results["rlimit_is_cgroup_oom"] = False
    results["observed_exit_not_137"] = p.returncode != 137


def sigterm_and_uid():
    status = REPORTS / "service-status.txt"
    if status.exists():
        status.unlink()
    proc = subprocess.Popen(
        [str(BIN), "--status-path", str(status)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    # wait until ready
    for _ in range(50):
        if status.exists() and "ready" in status.read_text():
            break
        time.sleep(0.02)
    else:
        proc.kill()
        raise SystemExit("service did not become ready")
    uid_txt = status.read_text()
    assert "uid=0" not in uid_txt
    uid = os.getuid()
    results["runtime_uid"] = uid
    results["refuses_interpreted_as_root"] = uid != 0
    proc.send_signal(signal.SIGTERM)
    try:
        out, err = proc.communicate(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
        raise SystemExit("SIGTERM was not handled in time")
    text = status.read_text()
    (REPORTS / "sigterm.txt").write_text(f"exit={proc.returncode}\nstatus={text}\nstdout={out}\nstderr={err}\n")
    results["sigterm_exit"] = proc.returncode
    results["sigterm_status"] = text.strip()
    assert proc.returncode == 0, proc.returncode
    assert "shutdown_ok" in text


def main():
    build_stages()
    scan_secret()
    probe_cgroup()
    memory_limit()
    sigterm_and_uid()
    results["runtime_binary"] = str(BIN.relative_to(ROOT))
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("FAIL:", type(e).__name__, e, file=sys.stderr)
        raise
