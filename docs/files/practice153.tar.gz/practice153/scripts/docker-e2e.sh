#!/usr/bin/env bash
# End-to-end acceptance against a real Docker or Podman engine.
# Exit 0 = the live runtime checks passed.
# Exit 2 = no usable engine on this machine (not a test pass, not a test defect).
# Exit 1 = engine present but a check failed.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

ENGINE=""
if command -v docker >/dev/null 2>&1; then
  ENGINE=docker
elif command -v podman >/dev/null 2>&1; then
  ENGINE=podman
fi
if [[ -z "$ENGINE" ]]; then
  echo "NO_CONTAINER_ENGINE"
  exit 2
fi
if ! "$ENGINE" info >/dev/null 2>&1; then
  echo "ENGINE_PRESENT_BUT_DAEMON_UNUSABLE engine=$ENGINE"
  exit 2
fi

SECRET="${BUILD_SECRET:-atlas-compile-key-1492}"
TAG="atlas-153-service:local"
REPORTS="$ROOT/reports"
mkdir -p "$REPORTS"

"$ENGINE" build --build-arg "BUILD_SECRET=$SECRET" -t "$TAG" "$ROOT"

# Secret must not appear in the runtime image filesystem.
# `docker export` of a fresh container is the image rootfs, not the build stage.
cid="$("$ENGINE" create --user 1000:1000 "$TAG" --status-path /tmp/status)"
if "$ENGINE" export "$cid" | grep -F -- "$SECRET" >/dev/null; then
  echo "SECRET_IN_RUNTIME_IMAGE"
  "$ENGINE" rm -f "$cid" >/dev/null
  exit 1
fi
echo "secret_scan_runtime=clean" | tee "$REPORTS/docker-secret-scan.txt"
"$ENGINE" rm -f "$cid" >/dev/null

# SIGTERM via docker stop should let the process write shutdown_ok.
name="atlas-153-term-$$"
"$ENGINE" run -d --user 1000:1000 --name "$name" -v "$REPORTS:/tmp/reports" "$TAG" --status-path /tmp/reports/docker-service-status.txt
# wait until ready (best-effort)
for _ in 1 2 3 4 5 6 7 8; do
  if "$ENGINE" logs "$name" 2>&1 | grep -q ready; then break; fi
  sleep 0.2
done
"$ENGINE" stop -t 3 "$name"
status="$("$ENGINE" inspect -f '{{.State.ExitCode}}' "$name")"
"$ENGINE" rm -f "$name" >/dev/null
if [[ "$status" != "0" ]]; then
  echo "SIGTERM_EXIT=$status"
  exit 1
fi
if ! grep -q shutdown_ok "$REPORTS/docker-service-status.txt" 2>/dev/null; then
  echo "SIGTERM_STATUS_MISSING"
  # still a failure of the live path
  exit 1
fi
echo "sigterm_exit=0" | tee "$REPORTS/docker-sigterm.txt"

# Memory limit: cgroup OOM typically yields 137. Record whatever the engine does.
set +e
"$ENGINE" run --rm --user 1000:1000 --memory 16m --memory-swap 16m "$TAG" --eat-mb 64 >"$REPORTS/docker-oom.stdout" 2>"$REPORTS/docker-oom.stderr"
oom_rc=$?
set -e
echo "docker_oom_exit=$oom_rc" | tee "$REPORTS/docker-oom.txt"
# We do not invent a required exit code beyond "did not fully succeed".
if [[ "$oom_rc" -eq 0 ]]; then
  echo "MEMORY_LIMIT_DID_NOT_STOP_ALLOCATION"
  exit 1
fi
echo "DOCKER_E2E_PASSED engine=$ENGINE oom_exit=$oom_rc"
