#!/usr/bin/env bash
# Manual diagnostic steps for a machine that HAS a container engine.
# Not executed by test.sh as a pass condition.
set -euo pipefail
cat <<'TXT'
1. Confirm the engine:
     docker version   # or: podman version
     docker info
2. Build the image from this directory:
     docker build --build-arg BUILD_SECRET=atlas-compile-key-1492 -t atlas-153-service:local .
3. Show stages / history (secret should not appear in runtime layers):
     docker history atlas-153-service:local
     docker create --name atlas-153-fs atlas-153-service:local
     docker export atlas-153-fs | tar -t | sed -n '1,80p'
     docker export atlas-153-fs | grep -F atlas-compile-key-1492 && echo LEAK || echo clean
     docker rm atlas-153-fs
4. SIGTERM:
     docker run -d --name atlas-153-term --user 1000:1000 atlas-153-service:local
     docker stop -t 3 atlas-153-term
     docker inspect -f '{{.State.ExitCode}}' atlas-153-term
5. Memory cap (expect failure; cgroup OOM is often exit 137, distinct from malloc failure):
     docker run --rm --user 1000:1000 --memory 16m --memory-swap 16m atlas-153-service:local --eat-mb 64
     echo exit=$?
6. If step 5 is skipped because the engine ignores --memory, record that cgroup
   memory is not enforced rather than claiming an OOM result.
TXT
