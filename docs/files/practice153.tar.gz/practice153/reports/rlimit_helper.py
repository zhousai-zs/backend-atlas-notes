import os, resource, sys
limit = 16 * 1024 * 1024
resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
os.execv(sys.argv[1], [sys.argv[1], '--eat-mb', '64'])
