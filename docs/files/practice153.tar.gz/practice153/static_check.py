"""Static checks on the official Dockerfile. These do not build an image."""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DOCKERFILE = ROOT / "Dockerfile"
SECRET_DEFAULT = "atlas-compile-key-1492"


def parse_stages(text: str) -> list[dict]:
    lines = text.splitlines()
    stages: list[dict] = []
    current: dict | None = None
    for i, raw in enumerate(lines, 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.match(r"(?i)^FROM\s+(\S+)(?:\s+AS\s+(\S+))?", line)
        if m:
            current = {
                "index": len(stages),
                "base": m.group(1),
                "name": (m.group(2) or f"stage{len(stages)}").lower(),
                "start_line": i,
                "lines": [line],
                "raw_lines": [(i, line)],
            }
            stages.append(current)
            continue
        if current is not None:
            current["lines"].append(line)
            current["raw_lines"].append((i, line))
    return stages


def check_dockerfile() -> dict:
    text = DOCKERFILE.read_text()
    stages = parse_stages(text)
    errors: list[str] = []
    notes: list[str] = []
    if len(stages) < 2:
        errors.append("need_at_least_two_FROM_stages")
    names = [s["name"] for s in stages]
    build = next((s for s in stages if s["name"] == "build"), stages[0] if stages else None)
    runtime = next((s for s in stages if s["name"] == "runtime"), stages[-1] if stages else None)
    if build is None or runtime is None or build is runtime:
        errors.append("missing_build_or_runtime_stage")
        return _result(errors, notes, stages, names)

    build_text = "\n".join(build["lines"])
    runtime_text = "\n".join(runtime["lines"])

    if "BUILD_SECRET" not in build_text:
        errors.append("build_stage_does_not_mention_BUILD_SECRET")
    if SECRET_DEFAULT in runtime_text or "BUILD_SECRET" in runtime_text:
        errors.append("runtime_stage_mentions_secret")
    if re.search(r"(?i)compile-secret", runtime_text):
        errors.append("runtime_stage_mentions_secret_file")

    copies = [
        line
        for line in runtime["lines"]
        if re.match(r"(?i)^COPY\s+", line)
    ]
    if not any(re.search(r"(?i)^COPY\s+--from=build\s+", c) for c in copies):
        errors.append("runtime_missing_COPY_from_build")
    for c in copies:
        if re.search(r"(?i)compile-secret|BUILD_SECRET", c):
            errors.append(f"runtime_copy_includes_secret:{c}")

    if not any(re.match(r"(?i)^USER\s+", line) for line in runtime["lines"]):
        errors.append("runtime_missing_USER")
    else:
        user_line = next(line for line in runtime["lines"] if re.match(r"(?i)^USER\s+", line))
        if re.match(r"(?i)^USER\s+(0|root)\s*$", user_line):
            errors.append("runtime_USER_is_root")
        notes.append(f"runtime_user_line={user_line}")

    if any(re.match(r"(?i)^COPY\s+", line) and "service.cpp" in line for line in runtime["lines"]):
        errors.append("runtime_copies_source")

    return _result(errors, notes, stages, names)


def _result(errors, notes, stages, names) -> dict:
    return {
        "dockerfile": str(DOCKERFILE.name),
        "stage_count": len(stages),
        "stage_names": names,
        "errors": errors,
        "notes": notes,
        "ok": not errors,
        "proves_image_was_built": False,
    }


if __name__ == "__main__":
    import json

    print(json.dumps(check_dockerfile(), indent=2))
