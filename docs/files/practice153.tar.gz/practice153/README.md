# practice153 — 容器镜像与运行边界

本目录的**主产物**是 `Dockerfile` 和 `scripts/docker-e2e.sh`。

- 若本机有可用的 Docker 或 Podman 守护进程，`test.sh` 会真正 `build` / `export` / `stop` / `--memory`。
- 若没有（当前教学环境通常没有），`test.sh` **不会**把目录里的 rootfs 布局称作镜像，只会：
  1. 静态检查 Dockerfile 的多阶段、`COPY --from=build`、非 root `USER`、运行阶段不含编译密钥；
  2. 在宿主机上编译同一份 `service.cpp`，检查 SIGTERM 与 `RLIMIT_AS`（这不是 cgroup OOM，退出码也不是 137）；
  3. 在 `results.json` 的 `not_verified_on_this_machine` 列出未跑的端到端项。

手工步骤见 `scripts/diagnose.sh`。旧版目录化 rootfs 模拟已废弃，不再作为验收。
