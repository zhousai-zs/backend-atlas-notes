// Teaching KV-style process: handle SIGTERM; optional memory consumer.
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>

static volatile sig_atomic_t stop_flag = 0;
static std::string status_path = "reports/service-status.txt";

static void on_term(int) { stop_flag = 1; }

static void write_status(const char* msg) {
    std::ofstream f(status_path, std::ios::out | std::ios::trunc);
    f << msg << "\nuid=" << getuid() << "\n";
}

int eat_memory_mb(size_t mb) {
    std::vector<void*> held;
    for (size_t i = 0; i < mb; ++i) {
        void* p = std::malloc(1024 * 1024);
        if (!p) {
            std::cerr << "malloc_failed at_mb=" << i << "\n";
            return 2;
        }
        std::memset(p, 1, 1024 * 1024);
        held.push_back(p);
    }
    std::cout << "allocated_mb=" << mb << "\n";
    return 0;
}

int main(int argc, char** argv) {
    if (getuid() == 0) {
        std::cerr << "refuse_root\n";
        return 3;
    }
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--status-path" && i + 1 < argc) status_path = argv[++i];
        else if (a == "--eat-mb" && i + 1 < argc) {
            return eat_memory_mb(std::strtoul(argv[++i], nullptr, 10));
        }
    }
    std::signal(SIGTERM, on_term);
    write_status("ready");
    std::cout << "ready uid=" << getuid() << std::endl;
    while (!stop_flag) {
        usleep(50 * 1000);
    }
    write_status("shutdown_ok");
    std::cout << "shutdown_ok" << std::endl;
    return 0;
}
