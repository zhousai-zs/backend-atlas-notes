#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=c++17 -O0 -g -fsanitize=address,undefined -Wall -Wextra -o lru lru.cpp
./lru
