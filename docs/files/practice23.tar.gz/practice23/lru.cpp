// 第23课实践：有上限的 LRU 缓存 + vector 扩容/reserve 演示
#include <cassert>
#include <cstdio>
#include <list>
#include <map>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

template <class K, class V>
class LruCache {
public:
    explicit LruCache(size_t cap) : cap_(cap) {}
    std::optional<V> get(const K& k) {
        auto it = idx_.find(k);
        if (it == idx_.end()) return std::nullopt;
        // splice 只移动链表节点，不拷贝元素，也不让任何 list 迭代器失效
        items_.splice(items_.begin(), items_, it->second);
        return it->second->second;
    }
    void put(const K& k, V v) {
        auto it = idx_.find(k);
        if (it != idx_.end()) {
            it->second->second = std::move(v);
            items_.splice(items_.begin(), items_, it->second);
            return;
        }
        if (items_.size() == cap_) {          // 淘汰最久未用：链表尾
            idx_.erase(items_.back().first);
            items_.pop_back();
        }
        items_.emplace_front(k, std::move(v));
        idx_[k] = items_.begin();
    }
    size_t size() const { return items_.size(); }
private:
    size_t cap_;
    std::list<std::pair<K, V>> items_;   // 头 = 最近使用
    std::unordered_map<K, typename std::list<std::pair<K, V>>::iterator> idx_;
};

int main() {
    // 1) LRU 正确性
    LruCache<std::string, std::string> c(2);
    c.put("a", "A"); c.put("b", "B");
    assert(c.get("a").value() == "A");   // a 变为最近使用
    c.put("c", "C");                     // 应淘汰 b
    assert(!c.get("b").has_value());
    assert(c.get("a").value() == "A");
    assert(c.get("c").value() == "C");
    c.put("a", "A2");                    // 更新不增加 size
    assert(c.size() == 2 && c.get("a").value() == "A2");
    std::printf("LRU OK: b evicted, size=%zu\n", c.size());

    // 2) vector 扩容：底层地址变化 => 旧指针/引用/迭代器全部失效
    std::vector<int> v{1};
    const int* before = v.data();
    size_t cap0 = v.capacity();
    while (v.capacity() == cap0) v.push_back(0);
    std::printf("vector realloc: capacity %zu -> %zu, data moved=%s\n",
                cap0, v.capacity(), before != v.data() ? "yes" : "no");

    // 3) reserve 只改容量不构造元素；之后在容量内 push_back 地址不变
    std::vector<int> r;
    r.reserve(100);
    std::printf("after reserve(100): size=%zu capacity>=100=%s\n",
                r.size(), r.capacity() >= 100 ? "yes" : "no");
    assert(r.size() == 0);
    r.push_back(1);
    const int* p = r.data();
    for (int i = 0; i < 99; ++i) r.push_back(i);
    assert(p == r.data());
    std::printf("100 push_back within reserved capacity: data stable=yes\n");

    // 4) 有序范围查询用 map：lower_bound/upper_bound
    std::map<int, std::string> by_time{{100, "x"}, {205, "y"}, {300, "z"}, {410, "w"}};
    int n = 0;
    for (auto it = by_time.lower_bound(200); it != by_time.upper_bound(400); ++it) ++n;
    assert(n == 2);
    std::printf("map range [200,400]: %d items\n", n);
    std::puts("ALL_TESTS_PASSED");
}
