#include <iostream>
#include <string>
#include <string_view>

std::string make_body() {
    return std::string("{\"msg\":\"a long body that does not fit in small-string optimization\"}");
}

int main(int argc, char** argv) {
    const std::string mode = argc > 1 ? argv[1] : "scope";

    if (mode == "safe") {
        std::string body = make_body();
        std::string_view view = body;
        std::cout << view << '\n';
        return 0;
    }

    if (mode == "temporary") {
        std::string_view view = make_body();
        std::cout << view << '\n';
        return 0;
    }

    std::string_view view;
    {
        std::string body = make_body();
        view = body;
    }
    std::cout << view << '\n';
}
