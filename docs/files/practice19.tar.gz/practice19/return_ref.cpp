#include "tracer.hpp"

#include <iostream>

const Tracer& make_dangling() {
    return Tracer("temporary returned by reference");
}

int main() {
    const Tracer& t = make_dangling();
    std::cout << "after make_dangling\n";
    (void)t;
}
