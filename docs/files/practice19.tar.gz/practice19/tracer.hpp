#pragma once

#include <iostream>
#include <string>
#include <utility>

class Tracer {
public:
    explicit Tracer(std::string name) : name_(std::move(name)) {
        std::cout << std::string(depth_++, ' ') << "+ " << name_ << '\n';
    }

    ~Tracer() {
        std::cout << std::string(--depth_, ' ') << "- " << name_ << '\n';
    }

    Tracer(const Tracer&) = delete;
    Tracer& operator=(const Tracer&) = delete;
    Tracer(Tracer&&) = delete;
    Tracer& operator=(Tracer&&) = delete;

private:
    std::string name_;
    inline static thread_local int depth_ = 0;
};
