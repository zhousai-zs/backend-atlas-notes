# practice19 · 对象生命周期与存储期

对应课程：`/workspace/atlas/lessons/19-b-lifetime.md`（节点 `b-lifetime`）

## 文件

| 文件 | 作用 |
|------|------|
| `tracer.hpp` | 构造/析构打日志的 Tracer，带 thread_local 缩进 |
| `nested_order.cpp` | 嵌套对象与成员构造/析构顺序 |
| `lifetime_ext.cpp` | 临时对象绑定 const 引用时的寿命延长 |
| `return_ref.cpp` | 函数返回引用不延长临时对象寿命 |
| `view_dangling.cpp` | `string_view` 绑定临时/`scope` 后悬垂（ASan） |
| `test.sh` | 一键编译与检查 |

## 一键验证

```bash
cd /workspace/atlas/lessons/practice19
./test.sh
```

期望最后一行：`all practice19 checks passed`

## 手动命令

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0 nested_order.cpp -o nested_order && ./nested_order
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0 lifetime_ext.cpp -o lifetime_ext && ./lifetime_ext
g++ -std=c++17 -Wall -Wextra -g -O0 -fsanitize=address -fno-omit-frame-pointer return_ref.cpp -o return_ref && ./return_ref
g++ -std=c++17 -Wall -Wextra -g -O0 -fsanitize=address -fno-omit-frame-pointer view_dangling.cpp -o view_dangling
./view_dangling safe
./view_dangling scope      # 期望 ASan 报错
./view_dangling temporary  # 期望 ASan 报错
```
