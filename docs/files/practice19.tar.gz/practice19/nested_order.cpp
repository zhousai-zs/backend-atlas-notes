#include "tracer.hpp"

#include <iostream>

struct Base {
    Tracer t{"Base"};
    Base() { std::cout << "  Base body\n"; }
    ~Base() { std::cout << "  ~Base body\n"; }
};

struct Inner {
    Tracer t{"Inner"};
};

struct Derived : Base {
    Tracer a{"Derived::a"};
    Inner inner;
    Tracer b{"Derived::b"};

    Derived() : a{"Derived::a"}, inner{}, b{"Derived::b"} {
        std::cout << "  Derived body\n";
    }

    ~Derived() {
        std::cout << "  ~Derived body\n";
    }
};

int main() {
    std::cout << "before Derived\n";
    {
        Derived d;
        std::cout << "inside scope\n";
    }
    std::cout << "after Derived\n";
}
