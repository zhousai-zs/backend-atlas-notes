#include "tracer.hpp"

#include <iostream>

Tracer make_tracer() {
    return Tracer("returned temporary");
}

int main() {
    std::cout << "--- const ref extension ---\n";
    {
        const Tracer& t = make_tracer();
        std::cout << "t is alive\n";
    }
    std::cout << "--- after scope ---\n";
}
