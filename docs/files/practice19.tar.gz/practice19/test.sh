#!/usr/bin/env bash
set -euo pipefail

CXX=${CXX:-g++}
BASE=(-std=c++17 -Wall -Wextra -g -O0)
ASAN=(-fsanitize=address -fno-omit-frame-pointer)

$CXX "${BASE[@]}" -Wpedantic -Werror nested_order.cpp -o nested_order
./nested_order > nested_order.out
grep -q "+ Base" nested_order.out
grep -q -- "- Base" nested_order.out

$CXX "${BASE[@]}" -Wpedantic -Werror lifetime_ext.cpp -o lifetime_ext
./lifetime_ext > lifetime_ext.out
grep -q -- "- returned temporary" lifetime_ext.out

$CXX "${BASE[@]}" "${ASAN[@]}" return_ref.cpp -o return_ref 2> return_ref.log
cat return_ref.log
./return_ref > return_ref.out

$CXX "${BASE[@]}" "${ASAN[@]}" view_dangling.cpp -o view_dangling
./view_dangling safe > view_safe.out

set +e
./view_dangling scope > view_scope.out 2>&1
scope_status=$?
./view_dangling temporary > view_temp.out 2>&1
temp_status=$?
set -e

if [ "$scope_status" -eq 0 ] || [ "$temp_status" -eq 0 ]; then
    echo "expected ASan failures for dangling string_view"
    exit 1
fi

grep -q "AddressSanitizer" view_scope.out
grep -q "AddressSanitizer" view_temp.out

echo "all practice19 checks passed"
