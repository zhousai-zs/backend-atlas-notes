#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["is_live_model"] is False and r["is_live_paid_api"] is False
assert r["downstream_invocations"] == 1
assert r["schema_pass_but_blocked_fake_evidence"] is True
by={c["id"]:c for c in r["cases"]}
assert by["good_complete"]["gate_open"] is True
assert by["schema_ok_fake_evidence"]["schema_ok"] is True and by["schema_ok_fake_evidence"]["gate_open"] is False
assert by["truncated_json"]["gate_open"] is False
assert by["openai_style_refusal"]["block_reason"] == "refusal"
assert by["incomplete_finish_length"]["block_reason"] == "incomplete"
print("POSTCHECK_OK")
PY
