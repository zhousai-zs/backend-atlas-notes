"""Format validation vs business/evidence checks. Downstream only after the gate."""

from __future__ import annotations

import json
from typing import Any

from jsonschema import Draft202012Validator
from pydantic import ValidationError

from schema import DIAGNOSIS_SCHEMA, Diagnosis

SCHEMA_VALIDATOR = Draft202012Validator(DIAGNOSIS_SCHEMA)


class DownstreamForbidden(RuntimeError):
    pass


class TicketingDownstream:
    """Standalone ticketing hook used to prove the gate actually blocks calls."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def file_ticket(self, diagnosis: dict[str, Any]) -> None:
        self.calls.append(diagnosis)


def parse_json(raw: str) -> tuple[Any | None, str | None]:
    try:
        return json.loads(raw), None
    except json.JSONDecodeError as exc:
        return None, f"json_decode: {exc.msg} at pos {exc.pos}"


def schema_errors(payload: Any) -> list[str]:
    if not isinstance(payload, dict):
        return [f"not_object:{type(payload).__name__}"]
    errs = [
        f"{list(e.absolute_path) or ['$']}: {e.message}"
        for e in SCHEMA_VALIDATOR.iter_errors(payload)
    ]
    try:
        Diagnosis.model_validate(payload)
    except ValidationError as exc:
        for err in exc.errors():
            loc = ".".join(str(x) for x in err["loc"]) or "$"
            msg = f"pydantic:{loc}: {err['type']}"
            if msg not in errs:
                errs.append(msg)
    return errs


def business_errors(payload: dict[str, Any], evidence_store: dict[str, Any]) -> list[str]:
    errs: list[str] = []
    status = payload.get("status")
    ids = payload.get("evidence_ids") or []
    if status == "ok" and len(ids) == 0:
        errs.append("business:status_ok_requires_evidence_ids")
    if status == "ok" and payload.get("confidence") == "uncertain":
        errs.append("business:status_ok_cannot_be_uncertain")
    missing = [i for i in ids if i not in evidence_store]
    if missing:
        errs.append("evidence_missing:" + ",".join(missing))
    return errs


def inspect_openai_message(message: dict[str, Any], finish_reason: str | None = None) -> dict[str, Any]:
    refusal = message.get("refusal")
    content = message.get("content")
    if finish_reason == "length":
        return {
            "kind": "incomplete",
            "reason": "finish_reason=length",
            "raw": content,
        }
    if refusal:
        return {"kind": "refusal", "reason": str(refusal), "raw": content}
    if content is None:
        return {"kind": "empty", "reason": "content_is_null", "raw": None}
    return {"kind": "content", "reason": None, "raw": content}


def evaluate_case(case: dict[str, Any], evidence_store: dict[str, Any], downstream: TicketingDownstream) -> dict[str, Any]:
    kind = case["kind"]
    raw: str | None = None
    parse_note: str | None = None
    payload: Any | None = None

    if kind == "injected_payload":
        raw = case["raw"]
    elif kind == "openai_chat_message":
        inspected = inspect_openai_message(case["message"])
        if inspected["kind"] != "content":
            result = _blocked(case, inspected["kind"], inspected["reason"], schema_ok=False)
            return result
        raw = inspected["raw"]
    elif kind == "openai_chat_choice":
        ch = case["choice"]
        inspected = inspect_openai_message(ch.get("message") or {}, ch.get("finish_reason"))
        if inspected["kind"] != "content":
            result = _blocked(case, inspected["kind"], inspected["reason"], schema_ok=False)
            return result
        raw = inspected["raw"]
    else:
        raise ValueError(f"unknown case kind {kind}")

    payload, parse_note = parse_json(raw or "")
    if payload is None:
        return _blocked(case, "parse_error", parse_note, schema_ok=False)

    s_errs = schema_errors(payload)
    if s_errs:
        return _blocked(case, "schema_error", s_errs, schema_ok=False, payload=payload)

    b_errs = business_errors(payload, evidence_store)
    if b_errs:
        return _blocked(case, "business_or_evidence_error", b_errs, schema_ok=True, payload=payload)

    if payload.get("status") != "ok":
        return _blocked(case, "status_not_ok", payload.get("status"), schema_ok=True, payload=payload)

    before = len(downstream.calls)
    downstream.file_ticket(payload)
    return {
        "id": case["id"],
        "gate_open": True,
        "schema_ok": True,
        "parse_ok": True,
        "block_reason": None,
        "block_detail": None,
        "downstream_invoked": True,
        "downstream_calls_delta": len(downstream.calls) - before,
        "payload": payload,
    }


def _blocked(case: dict[str, Any], reason: str, detail: Any, schema_ok: bool, payload: Any | None = None) -> dict[str, Any]:
    return {
        "id": case["id"],
        "gate_open": False,
        "schema_ok": schema_ok,
        "parse_ok": reason != "parse_error" and reason not in {"refusal", "incomplete", "empty"},
        "block_reason": reason,
        "block_detail": detail,
        "downstream_invoked": False,
        "downstream_calls_delta": 0,
        "payload": payload,
    }
