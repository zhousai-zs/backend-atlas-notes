#!/usr/bin/env python3
"""k-structured: schema vs evidence vs refusals. Downstream only after the gate.

Official openai==3.51.0 is used only with MockTransport. This does not measure
Structured Outputs adherence of a hosted model.
"""

from __future__ import annotations

import json
from pathlib import Path

from openai import __version__ as openai_version

from sdk_contract import run_scripted_parse, try_live_path_comment
from validate import TicketingDownstream, evaluate_case

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

cases = json.loads((ROOT / "fixtures/cases.json").read_text())
store = json.loads((ROOT / "fixtures/evidence.json").read_text())["items"]
downstream = TicketingDownstream()

rows = []
for case in cases:
    rec = evaluate_case(case, store, downstream)
    expect = bool(case["expect_gate"])
    assert rec["gate_open"] is expect, (case["id"], rec)
    assert rec["downstream_invoked"] is expect, rec
    if expect:
        assert rec["schema_ok"] is True
        assert rec["downstream_calls_delta"] == 1
    else:
        assert rec["downstream_calls_delta"] == 0
        assert rec["block_reason"]
    if case.get("expect_schema") is True:
        assert rec["schema_ok"] is True, rec
    if case["id"] == "schema_ok_fake_evidence":
        assert rec["schema_ok"] is True and rec["gate_open"] is False
        assert "evidence_missing:E999" in str(rec["block_detail"])
    if case["id"] in {"truncated_json", "missing_required_field", "wrong_enum"}:
        assert rec["schema_ok"] is False
    if case["id"] == "openai_style_refusal":
        assert rec["block_reason"] == "refusal"
    if case["id"] == "incomplete_finish_length":
        assert rec["block_reason"] == "incomplete"
    rows.append(rec)

assert downstream.calls, "good_complete must reach ticketing"
assert len(downstream.calls) == 1
assert all(r["id"] != "schema_ok_fake_evidence" or not r["gate_open"] for r in rows)

# Official SDK offline: parse a valid payload, then a refusal, then a truncated one.
sdk_ok = run_scripted_parse(
    {
        "finish_reason": "stop",
        "message": {
            "role": "assistant",
            "content": cases[0]["raw"],
            "refusal": None,
        },
    }
)
assert sdk_ok["openai_version"] == openai_version
assert sdk_ok["parsed"] is not None
assert sdk_ok["parsed"]["evidence_ids"] == ["E11", "E13"]
assert sdk_ok["is_live_paid_api"] is False

sdk_refusal = run_scripted_parse(
    {
        "finish_reason": "stop",
        "message": {
            "role": "assistant",
            "content": None,
            "refusal": "I cannot provide a root-cause diagnosis for this request.",
        },
    }
)
assert sdk_refusal["refusal"]
assert sdk_refusal["parsed"] is None

# A schema-valid but factually wrong payload still parses; the gate must still block it.
sdk_fake = run_scripted_parse(
    {
        "finish_reason": "stop",
        "message": {"role": "assistant", "content": cases[1]["raw"], "refusal": None},
    }
)
assert sdk_fake["parsed"] is not None
fake_case = next(c for c in cases if c["id"] == "schema_ok_fake_evidence")
# Re-evaluate using a fresh downstream to prove parse-success ≠ execute.
d2 = TicketingDownstream()
fake_rec = evaluate_case(fake_case, store, d2)
assert fake_rec["schema_ok"] and not fake_rec["gate_open"] and d2.calls == []

results = {
    "lesson": 163,
    "id": "k-structured",
    "is_live_model": False,
    "is_live_paid_api": False,
    "openai_version": openai_version,
    "jsonschema_used": True,
    "pydantic_used": True,
    "official_sdk_mock_transport": True,
    "n_cases": len(rows),
    "cases": rows,
    "downstream_invocations": len(downstream.calls),
    "schema_pass_but_blocked_fake_evidence": True,
    "sdk_offline": {
        "ok_parsed": sdk_ok["parsed"],
        "refusal_parsed_is_none": sdk_refusal["parsed"] is None,
        "fake_parses_but_gate_blocks": True,
        "used_mock_transport": True,
    },
    "user_live_path": try_live_path_comment(),
    "verified_on_this_machine": [
        "jsonschema_and_pydantic_format_checks",
        "evidence_id_existence_is_separate_from_schema",
        "truncated_missing_refusal_incomplete_do_not_call_downstream",
        "openai_3_51_0_chat_completions_parse_via_MockTransport",
    ],
    "not_verified_on_this_machine": [
        "hosted_model_adherence_to_strict_structured_outputs",
        "paid_OpenAI_API_parse_or_responses_parse",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "gate.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, indent=2, ensure_ascii=False))
assert results["is_live_model"] is False
assert any(not r["gate_open"] for r in rows)
assert results["downstream_invocations"] == 1
print("ALL_CHECKS_PASSED")
