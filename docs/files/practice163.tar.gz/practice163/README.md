# practice163 — 结构化输出与校验

主验收是「格式通过 ≠ 可以执行下游」：schema / pydantic 只检查形状，证据 ID 必须在本地证据库中存在；拒答、截断、缺字段不得调用工单下游。

官方 `openai==3.51.0` 的 `chat.completions.parse` 用 MockTransport 做离线契约，不测量托管模型是否遵守 Structured Outputs。真实路径见 `sdk_contract.try_live_path_comment()`，`test.sh` 不读密钥。
