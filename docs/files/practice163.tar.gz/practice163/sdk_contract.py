"""Offline construction of official openai==3.51.0 client objects. No live HTTP."""

from __future__ import annotations

import json
from typing import Any

import httpx
from openai import OpenAI
from openai import __version__ as openai_version

from schema import Diagnosis


def unused_key_client(transport: httpx.BaseTransport) -> OpenAI:
    """Construct the official client with a placeholder key and a mock transport.

    This only proves the SDK request can be built. It does not call OpenAI and
    does not measure model quality.
    """
    http = httpx.Client(transport=transport)
    return OpenAI(api_key="sk-unused-offline-placeholder", http_client=http, max_retries=0)


def scripted_transport(script: dict[str, Any]) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        body = {
            "id": "chatcmpl-offline-scripted",
            "object": "chat.completion",
            "created": 0,
            "model": "offline-scripted",
            "choices": [
                {
                    "index": 0,
                    "finish_reason": script.get("finish_reason", "stop"),
                    "message": script["message"],
                }
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        return httpx.Response(200, json=body, request=request)

    return httpx.MockTransport(handler)


def run_scripted_parse(script: dict[str, Any]) -> dict[str, Any]:
    client = unused_key_client(scripted_transport(script))
    # chat.completions.parse is the official 3.51.0 helper for Structured Outputs.
    completion = client.chat.completions.parse(
        model="offline-scripted",
        messages=[{"role": "user", "content": "diagnose INC-441"}],
        response_format=Diagnosis,
    )
    choice = completion.choices[0]
    message = choice.message
    return {
        "openai_version": openai_version,
        "finish_reason": choice.finish_reason,
        "refusal": message.refusal,
        "parsed": message.parsed.model_dump() if message.parsed is not None else None,
        "content": message.content,
        "used_mock_transport": True,
        "is_live_paid_api": False,
    }


def try_live_path_comment() -> str:
    return (
        "User live path (not run here): "
        "pip install 'openai==3.51.0' ; export OPENAI_API_KEY ; "
        "client = OpenAI() ; "
        "client.chat.completions.parse(model=<supported-structured-outputs-model>, "
        "messages=..., response_format=Diagnosis) "
        "or client.responses.parse(..., text_format=Diagnosis). "
        "Then pass the raw JSON (or refusal/finish_reason) through validate.evaluate_case. "
        "Do not treat a MockTransport result as evidence of model schema-adherence."
    )
