"""Diagnosis JSON Schema and Pydantic model. Format only; no fact checks."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

SCHEMA_VERSION = "diagnosis.v1"

DIAGNOSIS_SCHEMA: dict = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://atlas.local/schemas/diagnosis.v1.json",
    "title": "IncidentDiagnosis",
    "type": "object",
    "additionalProperties": False,
    "required": [
        "incident_id",
        "status",
        "conclusion",
        "evidence_ids",
        "confidence",
    ],
    "properties": {
        "incident_id": {"type": "string", "minLength": 1},
        "status": {
            "type": "string",
            "enum": ["ok", "incomplete", "refused"],
        },
        "conclusion": {"type": "string"},
        "evidence_ids": {
            "type": "array",
            "items": {"type": "string", "minLength": 1},
        },
        "confidence": {
            "type": "string",
            "enum": ["high", "medium", "low", "uncertain"],
        },
        "open_questions": {"type": "array", "items": {"type": "string"}},
    },
}


class Diagnosis(BaseModel):
    """Pydantic 2 model aligned with DIAGNOSIS_SCHEMA (format only)."""

    model_config = ConfigDict(extra="forbid")

    incident_id: str = Field(min_length=1)
    status: Literal["ok", "incomplete", "refused"]
    conclusion: str
    evidence_ids: list[str]
    confidence: Literal["high", "medium", "low", "uncertain"]
    open_questions: list[str] = Field(default_factory=list)
