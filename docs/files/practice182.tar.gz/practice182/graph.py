"""Official LangGraph 1.2.22: 读日志 → 假设 → 查指标 → 验证 → 输出.

Persistent SqliteSaver (not MemorySaver). The verify node interrupts for a
human decision; side effects run *after* the interrupt and are idempotent
on request_id so a resume (which re-enters the node from the start) cannot
double-write. Auth failures route to abort and are not retried.
"""

from __future__ import annotations

import sqlite3
from operator import add
from typing import Literal

from typing_extensions import Annotated, TypedDict

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt


def exclusive_str(a, b):
    """Explicit reject of conflicting parallel writes; equal or empty is a merge."""

    def empty(x):
        return x is None or x == ""

    if empty(a):
        return b
    if empty(b):
        return a
    if a == b:
        return a
    raise ValueError(f"conflicting updates of field: {a!r} vs {b!r}")


class IncidentState(TypedDict, total=False):
    request_id: str
    auth_ok: bool
    log_excerpt: str
    hypothesis: str
    metrics: str
    verdict: str
    report: str
    stop_reason: str
    last_route: str
    route_log: Annotated[list, add]
    indexed: int
    # Used only by the parallel-update demo graph:
    title: Annotated[str, exclusive_str]


def _schema(conn: sqlite3.Connection):
    conn.execute(
        "CREATE TABLE IF NOT EXISTS index_writes("
        "request_id TEXT PRIMARY KEY, body TEXT NOT NULL)"
    )
    conn.commit()


class Store:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        _schema(conn)

    def publish_index(self, request_id: str, body: str) -> int:
        """Idempotent: second call with the same request_id is a no-op."""
        cur = self.conn.execute("SELECT 1 FROM index_writes WHERE request_id=?", (request_id,))
        if cur.fetchone():
            return 0
        self.conn.execute("INSERT INTO index_writes VALUES(?,?)", (request_id, body))
        self.conn.commit()
        return 1

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM index_writes").fetchone()[0]


def build_incident_graph(store: Store):
    def read_logs(s: IncidentState) -> dict:
        return {"log_excerpt": "FATAL oom at L073", "last_route": "read_logs", "route_log": ["read_logs"]}

    def hypothesize(s: IncidentState) -> dict:
        return {
            "hypothesis": "cgroup memory.max too low",
            "last_route": "hypothesize",
            "route_log": ["hypothesize"],
        }

    def fetch_metrics(s: IncidentState) -> dict:
        if not s.get("auth_ok", True):
            return {
                "metrics": "AUTH_DENIED",
                "last_route": "fetch_metrics",
                "stop_reason": "auth_error_not_retried",
                "route_log": ["fetch_metrics"],
            }
        return {
            "metrics": "memory.max=512Mi used=512Mi",
            "last_route": "fetch_metrics",
            "route_log": ["fetch_metrics"],
        }

    def route_after_metrics(s: IncidentState) -> Literal["verify", "abort"]:
        if s.get("metrics") == "AUTH_DENIED":
            return "abort"
        return "verify"

    def abort(s: IncidentState) -> dict:
        return {
            "verdict": "aborted",
            "stop_reason": "auth_error_not_retried",
            "last_route": "abort",
            "route_log": ["abort"],
        }

    def verify(s: IncidentState) -> dict:
        # Side effects stay after interrupt. On resume LangGraph re-enters this
        # node from the top; interrupt() then returns the resume value and we
        # apply an idempotent write keyed by request_id.
        decision = interrupt(
            {
                "prompt": "approve verification?",
                "hypothesis": s.get("hypothesis"),
                "metrics": s.get("metrics"),
            }
        )
        if decision != "approve":
            return {
                "verdict": "rejected_by_human",
                "stop_reason": "human_rejected",
                "last_route": "verify",
                "route_log": ["verify"],
            }
        body = f"{s.get('hypothesis')}|{s.get('metrics')}"
        wrote = store.publish_index(s["request_id"], body)
        return {
            "verdict": "confirmed",
            "indexed": 1,
            "last_route": "verify",
            "route_log": ["verify"],
            "stop_reason": "verified_pending_output",
        }

    def output(s: IncidentState) -> dict:
        report = f"{s.get('hypothesis')} | {s.get('metrics')} | {s.get('verdict')}"
        return {
            "report": report,
            "stop_reason": "completed",
            "last_route": "output",
            "route_log": ["output"],
        }

    builder = StateGraph(IncidentState)
    builder.add_node("read_logs", read_logs)
    builder.add_node("hypothesize", hypothesize)
    builder.add_node("fetch_metrics", fetch_metrics)
    builder.add_node("verify", verify)
    builder.add_node("output", output)
    builder.add_node("abort", abort)
    builder.add_edge(START, "read_logs")
    builder.add_edge("read_logs", "hypothesize")
    builder.add_edge("hypothesize", "fetch_metrics")
    builder.add_conditional_edges("fetch_metrics", route_after_metrics, {"verify": "verify", "abort": "abort"})
    def route_after_verify(s: IncidentState) -> str:
        return "output" if s.get("verdict") == "confirmed" else "end"

    builder.add_conditional_edges("verify", route_after_verify, {"output": "output", "end": END})
    builder.add_edge("output", END)
    builder.add_edge("abort", END)
    return builder


def build_parallel_graph():
    def left(s: IncidentState) -> dict:
        return {"title": "A"}

    def right_conflict(s: IncidentState) -> dict:
        return {"title": "B"}

    def right_same(s: IncidentState) -> dict:
        return {"title": "A"}

    def _graph(right_fn):
        b = StateGraph(IncidentState)
        b.add_node("left", left)
        b.add_node("right", right_fn)
        b.add_edge(START, "left")
        b.add_edge(START, "right")
        b.add_edge("left", END)
        b.add_edge("right", END)
        return b.compile()

    return _graph(right_conflict), _graph(right_same)


def _connect(path: str, *, check_same_thread: bool) -> sqlite3.Connection:
    conn = sqlite3.connect(path, check_same_thread=check_same_thread, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def open_saver(path: str) -> tuple[sqlite3.Connection, SqliteSaver]:
    """Framework checkpointer. Do not share this connection with business writes."""
    conn = _connect(path, check_same_thread=False)
    saver = SqliteSaver(conn)
    saver.setup()
    return conn, saver


def open_store(path: str) -> tuple[sqlite3.Connection, Store]:
    """Business side-effect table on a separate file, so it is not the checkpointer connection."""
    conn = _connect(path, check_same_thread=False)
    return conn, Store(conn)


def explain(snapshot) -> dict:
    """Explain the current route and stop reason from persisted state."""
    values = snapshot.values
    return {
        "next": list(snapshot.next),
        "last_route": values.get("last_route"),
        "stop_reason": values.get("stop_reason"),
        "route_log": values.get("route_log"),
        "verdict": values.get("verdict"),
        "interrupted": bool(getattr(snapshot, "interrupts", ())),
        "request_id": values.get("request_id"),
    }
