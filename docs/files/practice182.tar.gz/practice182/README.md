# 实践 182：LangGraph 状态图实践

在解压后的 `practice182/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv 中锁定的 langgraph==1.2.22 与 langgraph-checkpoint-sqlite==3.1.3
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

使用文件 SqliteSaver，不用 MemorySaver。节点是确定性的，is_live_model=false。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
