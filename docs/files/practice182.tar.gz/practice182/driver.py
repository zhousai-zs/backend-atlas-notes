#!/usr/bin/env python3
"""LangGraph 1.2.22 + SqliteSaver: resume, auth no-retry, interrupt idempotency, merge/reject."""

from __future__ import annotations

import json
from importlib.metadata import version
from pathlib import Path

from langgraph.types import Command

from graph import build_incident_graph, build_parallel_graph, explain, open_saver, open_store

ROOT = Path(__file__).resolve().parent
assert version("langgraph") == "1.2.22", version("langgraph")
assert version("langgraph-checkpoint-sqlite") == "3.1.3"

DB = ROOT / "reports/graph.sqlite"
IDX = ROOT / "reports/index.sqlite"
DB.parent.mkdir(parents=True, exist_ok=True)
if DB.exists():
    DB.unlink()
if IDX.exists():
    IDX.unlink()

conn, saver = open_saver(str(DB))
iconn, store = open_store(str(IDX))
graph = build_incident_graph(store).compile(checkpointer=saver)

# --- happy path interrupts, then we simulate a process restart ---
cfg = {"configurable": {"thread_id": "incident-1"}}
paused = graph.invoke({"auth_ok": True, "request_id": "req-1"}, cfg)
assert "__interrupt__" in paused
snap = graph.get_state(cfg)
paused_explain = explain(snap)
assert paused_explain["next"] == ["verify"]
assert paused_explain["interrupted"]
assert paused_explain["route_log"] == ["read_logs", "hypothesize", "fetch_metrics"]
assert paused_explain["stop_reason"] is None
assert store.count() == 0  # side effect has not run yet

# Process restart: drop the first process's objects, then reopen both files.
conn.close()
iconn.close()
del graph, saver, store, conn, iconn
import gc
gc.collect()
conn2, saver2 = open_saver(str(DB))
iconn2, store2 = open_store(str(IDX))
graph2 = build_incident_graph(store2).compile(checkpointer=saver2)
snap2 = graph2.get_state(cfg)
restart_explain = explain(snap2)
assert restart_explain["request_id"] == "req-1"
assert restart_explain["next"] == ["verify"]
resumed = graph2.invoke(Command(resume="approve"), cfg)
assert resumed["stop_reason"] == "completed"
assert resumed["last_route"] == "output"
assert resumed["verdict"] == "confirmed"
assert resumed["report"].startswith("cgroup")
assert store2.count() == 1
# Re-entering verify on resume must not have inserted a second row.
# Invoke again on a completed thread should not add another write either.
completed_again = graph2.invoke(None, cfg)
assert store2.count() == 1
done_explain = explain(graph2.get_state(cfg))
assert done_explain["stop_reason"] == "completed"
assert done_explain["next"] == []
assert done_explain["route_log"] == ["read_logs", "hypothesize", "fetch_metrics", "verify", "output"]

# Human reject path (different thread)
cfg_rej = {"configurable": {"thread_id": "incident-reject"}}
graph2.invoke({"auth_ok": True, "request_id": "req-rej"}, cfg_rej)
rej = graph2.invoke(Command(resume="reject"), cfg_rej)
assert rej["stop_reason"] == "human_rejected" and rej["verdict"] == "rejected_by_human"
assert store2.count() == 1  # still only req-1

# Auth error is not retried: one fetch_metrics, then abort, END
cfg_auth = {"configurable": {"thread_id": "incident-auth"}}
auth = graph2.invoke({"auth_ok": False, "request_id": "req-auth"}, cfg_auth)
assert auth["stop_reason"] == "auth_error_not_retried"
assert auth["last_route"] == "abort"
assert auth["route_log"] == ["read_logs", "hypothesize", "fetch_metrics", "abort"]
assert auth.get("report") in {None, ""}
# Fetch happened once; no later retry node appears in the log.
assert auth["route_log"].count("fetch_metrics") == 1

# Two workers / two thread_ids stay isolated
cfg_b = {"configurable": {"thread_id": "incident-B"}}
graph2.invoke({"auth_ok": True, "request_id": "req-B"}, cfg_b)
# incident-1 still completed with req-1; B is waiting at verify
assert explain(graph2.get_state(cfg))["stop_reason"] == "completed"
assert explain(graph2.get_state(cfg_b))["next"] == ["verify"]
assert explain(graph2.get_state(cfg_b))["request_id"] == "req-B"

# --- parallel updates of the same field: explicit reject vs equal merge ---
conflict_g, same_g = build_parallel_graph()
conflicted = None
try:
    conflict_g.invoke({})
except ValueError as e:
    conflicted = str(e)
assert conflicted and "conflicting updates of field" in conflicted
same = same_g.invoke({})
assert same["title"] == "A"

results = {
    "lesson": 182,
    "id": "l-langgraph",
    "langgraph": version("langgraph"),
    "langgraph_checkpoint_sqlite": version("langgraph-checkpoint-sqlite"),
    "used_memory_saver": False,
    "is_live_model": False,
    "paused": paused_explain,
    "after_process_restart": restart_explain,
    "completed": done_explain,
    "index_rows_after_resume": store2.count(),
    "human_rejected_stop_reason": rej["stop_reason"],
    "auth_stop_reason": auth["stop_reason"],
    "auth_route_log": auth["route_log"],
    "thread_isolation": {
        "incident-1_stop": explain(graph2.get_state(cfg))["stop_reason"],
        "incident-B_next": explain(graph2.get_state(cfg_b))["next"],
        "incident-B_request_id": explain(graph2.get_state(cfg_b))["request_id"],
    },
    "parallel_conflict": conflicted,
    "parallel_same_value_merge": same["title"],
    "route_explanations": {
        "interrupt": "next=['verify'] because fetch_metrics routed to verify and interrupt paused the node before the side effect",
        "completed": "next=[] stop_reason=completed last_route=output after Command(resume='approve')",
        "auth": "metrics==AUTH_DENIED routes to abort; fetch_metrics is not re-entered",
        "reject": "Command(resume!='approve') sets stop_reason=human_rejected and does not write the index",
    },
    "verified_on_this_machine": [
        "official_StateGraph_with_file_SqliteSaver_not_MemorySaver",
        "same_thread_id_resumes_after_process_restart",
        "interrupt_resume_idempotent_index_write",
        "auth_error_routes_to_abort_not_retried",
        "parallel_field_updates_explicit_reject_or_equal_merge",
        "stop_reason_and_route_log_readable_from_persisted_state",
    ],
    "not_verified_on_this_machine": [
        "live_chat_model_inside_graph_nodes",
        "multi_host_Postgres_checkpointer",
        "LangGraph_Platform_deployment",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({
    "paused_next": paused_explain["next"],
    "restart_next": restart_explain["next"],
    "done": done_explain["stop_reason"],
    "index": store2.count(),
    "auth": auth["route_log"],
    "conflict": conflicted,
    "merge": same["title"],
}, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
