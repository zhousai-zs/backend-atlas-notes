#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["langgraph"]=="1.2.22" and r["used_memory_saver"] is False
assert r["paused"]["next"]==["verify"] and r["after_process_restart"]["next"]==["verify"]
assert r["completed"]["stop_reason"]=="completed" and r["index_rows_after_resume"]==1
assert r["auth_stop_reason"]=="auth_error_not_retried" and r["auth_route_log"].count("fetch_metrics")==1
assert r["human_rejected_stop_reason"]=="human_rejected"
assert r["thread_isolation"]["incident-1_stop"]=="completed"
assert r["thread_isolation"]["incident-B_request_id"]=="req-B"
assert "conflicting updates" in r["parallel_conflict"]
assert r["parallel_same_value_merge"]=="A"
print("POSTCHECK_OK")
PY
