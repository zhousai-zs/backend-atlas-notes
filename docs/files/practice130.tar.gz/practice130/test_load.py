#!/usr/bin/env python3
"""Acceptance checks for the lesson 130 load-model experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    ARRIVAL_INTERVAL,
    CLOSED_CLIENTS,
    KEY_TITLE,
    MEASURE_S,
    SERVICE_S,
    STALL_S,
    STALL_T0,
    TITLE_V1,
    WORKERS,
    record_with_expected_interval,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "LoadEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_load_testing_product"] and r["not_hdrhistogram"]
    assert r["cycles_are_teaching"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["workers"] == WORKERS == 2
    assert r["service_s"] == SERVICE_S == 0.10
    assert r["stall_t0"] == STALL_T0 == 10.00
    assert r["stall_s"] == STALL_S == 2.00
    assert r["measure_s"] == MEASURE_S == 16.00
    assert r["arrival_interval"] == ARRIVAL_INTERVAL == 0.10
    assert r["closed_clients"] == CLOSED_CLIENTS == 1
    assert r["capacity_qps"] == 20.0
    assert r["intended_open_qps"] == 10.0

    c = r["compare"]["closed"]
    o = r["compare"]["open"]
    assert c["n_intended"] == c["n_ok"] == 140 and c["n_errors"] == 0
    assert c["error_rate"] == 0.0 and c["effective_completion_rate"] == 1.0
    assert c["completion_qps"] == 8.75
    assert c["peak_outstanding"] == 1
    assert c["p50_ok"] == 0.10 and c["p99_ok"] == 0.10 and c["p100_ok"] == 2.10
    assert c["mean_ok"] == 0.1143 and c["n_slow_ok"] == 1
    assert c["p99_corrected"] == 2.0 and c["n_corrected"] == 160
    assert c["p99_bucketed_ok"] == 0.0 and c["p99_bucketed_corrected"] == 2.0
    assert c["bucket_width"] == 0.50
    assert len(record_with_expected_interval(2.10, 0.10)) == 21

    assert o["n_intended"] == o["n_ok"] == 160 and o["n_errors"] == 0
    assert o["error_rate"] == 0.0 and o["effective_completion_rate"] == 1.0
    assert o["completion_qps"] == 10.0
    assert o["peak_outstanding"] == 21
    assert o["p50_ok"] == 0.10 and o["p99_ok"] == 2.00 and o["p100_ok"] == 2.10
    assert o["mean_ok"] == 0.35 and o["n_slow_ok"] == 39
    assert o["p99_bucketed_ok"] == 2.0
    assert r["compare"]["coordinated_omission_hides_stall"]
    assert r["compare"]["expected_interval_corrects_closed"]
    assert r["compare"]["open_p99_sees_stall"]

    tc = r["timeout_pitfall"]["closed"]
    to = r["timeout_pitfall"]["open"]
    assert r["timeout_pitfall"]["timeout_s"] == 1.00
    assert tc["n_intended"] == 142 and tc["n_ok"] == 140
    assert tc["n_timeout"] == 2 and tc["n_errors"] == 2
    assert tc["error_rate"] == 0.0141
    assert tc["effective_completion_rate"] == 0.9859
    assert tc["p99_success_only"] == 0.10 and tc["p100_ok"] == 0.10
    assert tc["p99_all_recorded"] == 1.00
    assert to["n_intended"] == 160 and to["n_ok"] == 149
    assert to["n_timeout"] == 11 and to["error_rate"] == 0.0688
    assert to["effective_completion_rate"] == 0.9313
    assert to["p99_success_only"] == 0.90 and to["p99_all_recorded"] == 1.00
    assert to["completion_qps"] == 9.3125
    assert r["pitfall_success_only_hides_stall"]

    b = r["bounds"]
    mu, mb = b["modest_unbounded"], b["modest_bound"]
    assert mu["peak_outstanding"] == 21 and mu["n_dropped"] == 0 and mu["error_rate"] == 0.0
    assert mb["peak_outstanding"] == 8 and mb["n_dropped"] == 13
    assert mb["error_rate"] == 0.0813 and mb["effective_completion_rate"] == 0.9188
    assert mb["completion_qps"] == 9.1875 and mb["p99_ok"] == 2.00
    ou, oc = b["overload_unbounded"], b["overload_capped"]
    assert b["overload_interval"] == 0.025 and b["overload_bound"] == 16
    assert ou["n_intended"] == oc["n_intended"] == 640
    assert ou["n_ok"] == oc["n_ok"] == 279
    assert ou["n_dropped"] == 0 and ou["n_incomplete"] == 361
    assert ou["error_rate"] == 0.5641 and ou["peak_outstanding"] == 362
    assert ou["p99_ok"] == 9.00 and ou["completion_qps"] == 17.4375
    assert oc["n_dropped"] == 346 and oc["n_incomplete"] == 15
    assert oc["error_rate"] == 0.5641 and oc["peak_outstanding"] == 16
    assert oc["p99_ok"] == 2.80 and oc["completion_qps"] == 17.4375
    assert b["tradeoff_open_loop_needs_bound"]

    assert r["acceptance_coordinated_omission_hides_stall"]
    assert r["acceptance_reports_error_and_completion"]
    assert r["practice_compares_closed_and_open_p99"]
    assert r["pitfall_success_only_hides_stall"]
    assert r["tradeoff_open_loop_needs_bound"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
