#!/usr/bin/env python3
"""Run the lesson 130 coordinated-omission / load-model experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    ARRIVAL_INTERVAL,
    CLOSED_CLIENTS,
    KEY_TITLE,
    MEASURE_S,
    SERVICE_S,
    STALL_S,
    STALL_T0,
    TITLE_V1,
    WORKERS,
    LoadEngine,
    ts,
)


OVERLOAD_INTERVAL = 0.025  # 40 intended QPS; capacity is 20
OVERLOAD_BOUND = 16
COMPARE_BOUND = 8
TIMEOUT_S = 1.00


def _meta() -> dict[str, Any]:
    return {
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "workers": WORKERS,
        "service_s": SERVICE_S,
        "stall_t0": STALL_T0,
        "stall_s": STALL_S,
        "measure_s": MEASURE_S,
        "arrival_interval": ARRIVAL_INTERVAL,
        "closed_clients": CLOSED_CLIENTS,
        "capacity_qps": ts(WORKERS / SERVICE_S),
        "intended_open_qps": ts(1.0 / ARRIVAL_INTERVAL),
    }


def run_closed_vs_open() -> dict[str, Any]:
    eng = LoadEngine()
    closed = eng.run(mode="closed")
    opened = eng.run(mode="open")
    hides = (
        closed["p99_ok"] == SERVICE_S
        and opened["p99_ok"] > closed["p99_ok"] + 1.0
        and closed["n_slow_ok"] == 1
        and opened["n_slow_ok"] > closed["n_slow_ok"]
        and closed["p100_ok"] == opened["p100_ok"] == 2.10
    )
    corrected_reveals = closed["p99_corrected"] >= 2.00
    return {
        "closed": closed,
        "open": opened,
        "coordinated_omission_hides_stall": hides,
        "expected_interval_corrects_closed": corrected_reveals,
        "open_p99_sees_stall": opened["p99_ok"] >= 2.00,
    }


def run_timeout_pitfall() -> dict[str, Any]:
    eng = LoadEngine()
    closed = eng.run(mode="closed", timeout_s=TIMEOUT_S)
    opened = eng.run(mode="open", timeout_s=TIMEOUT_S)
    # Success-only p99 / max stay at the fast service time on the closed
    # loop, while errors carry the pause.
    pitfall = (
        closed["p99_success_only"] == SERVICE_S
        and closed["p100_ok"] == SERVICE_S
        and closed["n_timeout"] > 0
        and closed["error_rate"] > 0.0
        and closed["p99_all_recorded"] > closed["p99_success_only"]
    )
    return {
        "timeout_s": TIMEOUT_S,
        "closed": closed,
        "open": opened,
        "pitfall_success_only_hides_stall": pitfall,
    }


def run_open_loop_bound() -> dict[str, Any]:
    eng = LoadEngine()
    modest_unbounded = eng.run(mode="open", max_outstanding=0)
    modest_bound = eng.run(mode="open", max_outstanding=COMPARE_BOUND)
    overload_unbounded = eng.run(
        mode="open", arrival_interval=OVERLOAD_INTERVAL, max_outstanding=0
    )
    overload_bound = eng.run(
        mode="open",
        arrival_interval=OVERLOAD_INTERVAL,
        max_outstanding=OVERLOAD_BOUND,
    )
    tradeoff = (
        overload_unbounded["peak_outstanding"] > overload_bound["peak_outstanding"]
        and overload_bound["peak_outstanding"] == OVERLOAD_BOUND
        and overload_bound["n_dropped"] > 0
        and overload_unbounded["n_dropped"] == 0
        and overload_unbounded["p99_ok"] > overload_bound["p99_ok"]
        and modest_bound["peak_outstanding"] == COMPARE_BOUND
        and modest_unbounded["peak_outstanding"] > modest_bound["peak_outstanding"]
        and modest_bound["error_rate"] > modest_unbounded["error_rate"]
    )
    return {
        "modest_unbounded": modest_unbounded,
        "modest_bound": modest_bound,
        "overload_interval": OVERLOAD_INTERVAL,
        "overload_bound": OVERLOAD_BOUND,
        "overload_unbounded": overload_unbounded,
        "overload_capped": overload_bound,
        "tradeoff_open_loop_needs_bound": tradeoff,
    }


def run() -> dict[str, Any]:
    meta = _meta()
    compare = run_closed_vs_open()
    pitfall = run_timeout_pitfall()
    bound = run_open_loop_bound()
    return {
        "engine": "LoadEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_load_testing_product": True,
        "not_hdrhistogram": True,
        "cycles_are_teaching": True,
        **meta,
        "compare": compare,
        "timeout_pitfall": pitfall,
        "bounds": bound,
        "acceptance_coordinated_omission_hides_stall": compare[
            "coordinated_omission_hides_stall"
        ],
        "acceptance_reports_error_and_completion": (
            pitfall["closed"]["error_rate"] > 0.0
            and pitfall["open"]["error_rate"] > 0.0
            and "effective_completion_rate" in pitfall["closed"]
            and "effective_completion_rate" in pitfall["open"]
            and "completion_qps" in compare["closed"]
        ),
        "practice_compares_closed_and_open_p99": (
            compare["closed"]["p99_ok"] == 0.10
            and compare["open"]["p99_ok"] == 2.00
        ),
        "pitfall_success_only_hides_stall": pitfall["pitfall_success_only_hides_stall"],
        "tradeoff_open_loop_needs_bound": bound["tradeoff_open_loop_needs_bound"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {path}")
