#!/usr/bin/env python3
"""Teaching LoadEngine — not Redis, not a real load-testing product, not a network service.

A Python 3 standard-library model of an Echo service under two load models:
closed-loop (a fixed number of clients, each sending the next request only
after the previous one returns) and open-loop (constant intended arrival
rate). A scheduled stop-the-world pause is injected so that coordinated
omission can be seen in the recorded p99.

The named source (checked on 2026-11-14) is the HdrHistogram repository at
https://github.com/HdrHistogram/HdrHistogram (README, package-info.java, and
AbstractHistogram.java). Those texts define Coordinated Omission and
recordValueWithExpectedInterval, and they discuss histogram resolution
(significant digits, equivalent values). They do not define the terms
open loop or closed loop; those names come from this node and the teaching
model. This engine is not the HdrHistogram library, not a load generator
product, and not a network service. There is no TCP and no real clock.
Times are teaching virtual-clock values, not production RTT, and not the
repository's 10 ms / 1 ms / 100 s illustration copied into results.
"""
from __future__ import annotations

import heapq
import math
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
WORKERS = 2
SERVICE_S = 0.10
STALL_T0 = 10.00
STALL_S = 2.00
ARRIVAL_INTERVAL = 0.10
CLOSED_CLIENTS = 1
MEASURE_S = 16.00
TIMEOUT_NONE = 0.0
# Teaching histogram: linear buckets in virtual seconds. Not HdrHistogram
# significant-digit encoding.
BUCKET_WIDTH = 0.50


def ts(t: float, nd: int = 4) -> float:
    return round(float(t) + 1e-12, nd)


def percentile(xs: list[float], p: float) -> Optional[float]:
    """Floor percentile: index = min(n-1, floor(p/100 * n)).

    Same teaching rule as lesson 128. Not an HdrHistogram iterator.
    """
    if not xs:
        return None
    ys = sorted(xs)
    n = len(ys)
    idx = min(n - 1, math.floor((p / 100.0) * n))
    return ts(ys[idx])


def record_with_expected_interval(value: float, expected_interval: float) -> list[float]:
    """Teaching analogue of recordValueWithExpectedInterval.

    Records value, then value-I, value-2I, ... while the missing value is
    still >= I. Units are teaching seconds; the Java API uses integers.
    """
    out = [ts(value)]
    if expected_interval <= 0:
        return out
    missing = ts(value - expected_interval)
    # Guard against float drift by stepping on rounded values.
    while missing + 1e-12 >= expected_interval:
        out.append(ts(missing))
        missing = ts(missing - expected_interval)
    return out


class TeachingHistogram:
    """Linear-bucket teaching histogram. Not org.HdrHistogram.Histogram."""

    def __init__(self, bucket_width: float = BUCKET_WIDTH) -> None:
        self.bucket_width = bucket_width
        self._raw: list[float] = []
        self._counts: dict[int, int] = {}

    def record(self, value: float) -> None:
        v = ts(value)
        self._raw.append(v)
        idx = int(math.floor((v + 1e-12) / self.bucket_width))
        self._counts[idx] = self._counts.get(idx, 0) + 1

    def record_many(self, values: list[float]) -> None:
        for v in values:
            self.record(v)

    def bucket_representative(self, idx: int) -> float:
        # Lowest value counted in this bucket (teaching "lowest equivalent").
        return ts(idx * self.bucket_width)

    def expanded_bucket_values(self) -> list[float]:
        out: list[float] = []
        for idx in sorted(self._counts):
            rep = self.bucket_representative(idx)
            out.extend([rep] * self._counts[idx])
        return out

    def percentile_exact(self, p: float) -> Optional[float]:
        return percentile(self._raw, p)

    def percentile_bucketed(self, p: float) -> Optional[float]:
        return percentile(self.expanded_bucket_values(), p)

    def count(self) -> int:
        return len(self._raw)


class LoadEngine:
    """Closed-loop vs open-loop Echo with a scheduled teaching pause."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1

    def run(
        self,
        *,
        mode: str,
        clients: int = CLOSED_CLIENTS,
        arrival_interval: float = ARRIVAL_INTERVAL,
        workers: int = WORKERS,
        service_s: float = SERVICE_S,
        stall_t0: float = STALL_T0,
        stall_s: float = STALL_S,
        measure_s: float = MEASURE_S,
        timeout_s: float = TIMEOUT_NONE,
        max_outstanding: int = 0,
        expected_interval: Optional[float] = None,
    ) -> dict[str, Any]:
        if mode not in ("closed", "open"):
            raise ValueError(f"unknown mode {mode}")
        exp_i = arrival_interval if expected_interval is None else expected_interval
        ev: list[tuple[float, int, int, str, Any]] = []
        seq = 0
        # Same-timestamp order: completions before arrivals before
        # stall edges; the measure-end event is last so a completion
        # exactly at measure_s still counts.
        kind_rank = {
            "svc_done": 0,
            "timeout": 1,
            "arrive": 2,
            "stall_start": 3,
            "stall_end": 4,
            "end": 9,
        }

        def push(t: float, kind: str, payload: Any = None) -> None:
            nonlocal seq
            heapq.heappush(ev, (ts(t), kind_rank[kind], seq, kind, payload))
            seq += 1

        push(stall_t0, "stall_start")
        push(stall_t0 + stall_s, "stall_end")
        push(measure_s, "end")

        if mode == "open":
            t = 0.0
            req_id = 0
            # Include an arrival at 0, not one at exactly measure_s.
            while t + 1e-12 < measure_s:
                push(t, "arrive", req_id)
                req_id += 1
                t = ts(t + arrival_interval)
            n_intended = req_id
        else:
            n_intended = 0  # grows as closed-loop clients issue
            for cid in range(clients):
                push(0.0, "arrive", f"c{cid}-0")

        stalled = False
        free_workers = workers
        queue: list[dict[str, Any]] = []
        in_service: dict[int, dict[str, Any]] = {}
        next_sid = 0
        outstanding = 0
        peak_outstanding = 0
        closed_seq = {cid: 0 for cid in range(clients)}
        results: list[dict[str, Any]] = []
        n_issued = 0
        n_dropped = 0

        def note_outstanding() -> None:
            nonlocal peak_outstanding
            if outstanding > peak_outstanding:
                peak_outstanding = outstanding

        def complete_req(req: dict[str, Any], t_done: float, status: str) -> None:
            nonlocal outstanding, n_intended
            e2e = ts(t_done - req["start"])
            intended_e2e = ts(t_done - req["intended"])
            timed_out = bool(timeout_s > 0 and intended_e2e - 1e-12 > timeout_s)
            if timed_out:
                status = "timeout"
            rec = {
                "id": req["id"],
                "intended": ts(req["intended"]),
                "start": ts(req["start"]),
                "done": ts(t_done),
                "e2e": e2e,
                "intended_e2e": intended_e2e,
                "status": status,
            }
            results.append(rec)
            outstanding -= 1
            if mode == "closed":
                # Closed client issues the next request immediately, unless
                # the run has ended.
                if t_done + 1e-12 < measure_s:
                    cid = req["client"]
                    closed_seq[cid] += 1
                    push(t_done, "arrive", f"c{cid}-{closed_seq[cid]}")

        def try_start(now: float) -> None:
            nonlocal free_workers, next_sid
            while (not stalled) and free_workers > 0 and queue:
                req = queue.pop(0)
                sid = next_sid
                next_sid += 1
                req["svc_start"] = now
                req["remaining"] = service_s
                in_service[sid] = req
                free_workers -= 1
                push(now + service_s, "svc_done", sid)

        ended = False
        while ev:
            t, _, _, kind, payload = heapq.heappop(ev)
            t = ts(t)
            if kind == "end":
                # Anything still queued or in service at the measure end is
                # an incomplete / error for reporting.
                ended = True
                break
            if kind == "stall_start":
                stalled = True
                # Freeze in-service work: cancel their svc_done and keep
                # remaining time.
                for sid, req in list(in_service.items()):
                    elapsed = ts(t - req["svc_start"])
                    rem = ts(req["remaining"] - elapsed)
                    if rem < 0:
                        rem = 0.0
                    req["remaining"] = rem
                    req["frozen"] = True
                continue
            if kind == "stall_end":
                stalled = False
                # Resume frozen work from now.
                for sid, req in list(in_service.items()):
                    if req.get("frozen"):
                        req["svc_start"] = t
                        req["frozen"] = False
                        push(t + req["remaining"], "svc_done", sid)
                try_start(t)
                continue
            if kind == "arrive":
                if mode == "closed":
                    n_intended += 1
                # Open-loop bound: refuse if outstanding already at cap.
                if max_outstanding > 0 and outstanding >= max_outstanding:
                    n_dropped += 1
                    results.append(
                        {
                            "id": payload,
                            "intended": t,
                            "start": t,
                            "done": t,
                            "e2e": 0.0,
                            "intended_e2e": 0.0,
                            "status": "dropped",
                        }
                    )
                    continue
                n_issued += 1
                outstanding += 1
                note_outstanding()
                client = None
                if mode == "closed":
                    client = int(str(payload).split("-")[0][1:])
                req = {
                    "id": payload,
                    "intended": t,
                    "start": t,
                    "client": client,
                }
                queue.append(req)
                if timeout_s > 0:
                    push(t + timeout_s, "timeout", req["id"])
                try_start(t)
                continue
            if kind == "timeout":
                rid = payload
                found_q = None
                for i, req in enumerate(queue):
                    if req["id"] == rid:
                        found_q = i
                        break
                if found_q is not None:
                    req = queue.pop(found_q)
                    complete_req(req, t, "timeout")
                    try_start(t)
                    continue
                found_sid = None
                for sid, req in in_service.items():
                    if req["id"] == rid:
                        found_sid = sid
                        break
                if found_sid is not None:
                    req = in_service.pop(found_sid)
                    free_workers += 1
                    complete_req(req, t, "timeout")
                    try_start(t)
                continue
            if kind == "svc_done":
                sid = payload
                req = in_service.get(sid)
                if req is None:
                    continue
                if stalled or req.get("frozen"):
                    # Stale completion scheduled before the pause.
                    continue
                # Must match the resume start.
                expected_done = ts(req["svc_start"] + req["remaining"])
                if abs(expected_done - t) > 1e-9 and t + 1e-12 < expected_done:
                    continue
                del in_service[sid]
                free_workers += 1
                complete_req(req, t, "ok")
                try_start(t)
                continue

        # End of measure: mark leftover work as incomplete (errors).
        for req in list(queue):
            complete_req(req, measure_s, "incomplete")
        queue.clear()
        for sid, req in list(in_service.items()):
            complete_req(req, measure_s, "incomplete")
        in_service.clear()

        ok = [r for r in results if r["status"] == "ok"]
        errors = [r for r in results if r["status"] != "ok"]
        # Intended latency for successful completions, and for all finished
        # requests that actually ran (not drops at t_send).
        ok_intended = [r["intended_e2e"] for r in ok]
        ok_e2e = [r["e2e"] for r in ok]
        # Success-only vs all-recorded: timeouts/incompletes contribute their
        # intended_e2e; drops contribute no service latency but count as errors.
        all_latency = [r["intended_e2e"] for r in results if r["status"] != "dropped"]
        hist_raw = TeachingHistogram()
        hist_raw.record_many(ok_intended)
        hist_corr = TeachingHistogram()
        for v in ok_intended:
            hist_corr.record_many(record_with_expected_interval(v, exp_i))
        hist_all = TeachingHistogram()
        hist_all.record_many(all_latency)

        n_ok = len(ok)
        n_err = len(errors)
        n_tot = len(results)
        # n_intended for closed equals issued attempts; for open it was pre-counted.
        if mode == "closed":
            n_intended = n_tot  # each issued attempt is in results (no pre-drops before issue... drops unused in closed unless bound)
        error_rate = ts(n_err / n_intended) if n_intended else 0.0
        completion_rate = ts(n_ok / measure_s) if measure_s else 0.0
        effective_completion = ts(n_ok / n_intended) if n_intended else 0.0

        def pct(xs: list[float], p: float) -> Optional[float]:
            return percentile(xs, p)

        return {
            "mode": mode,
            "workers": workers,
            "service_s": ts(service_s),
            "stall_t0": ts(stall_t0),
            "stall_s": ts(stall_s),
            "measure_s": ts(measure_s),
            "arrival_interval": ts(arrival_interval),
            "expected_interval": ts(exp_i),
            "clients": clients if mode == "closed" else 0,
            "timeout_s": timeout_s,
            "max_outstanding": max_outstanding,
            "n_intended": n_intended,
            "n_issued": n_issued,
            "n_ok": n_ok,
            "n_errors": n_err,
            "n_dropped": n_dropped,
            "n_timeout": sum(1 for r in results if r["status"] == "timeout"),
            "n_incomplete": sum(1 for r in results if r["status"] == "incomplete"),
            "error_rate": error_rate,
            "completion_qps": completion_rate,
            "effective_completion_rate": effective_completion,
            "peak_outstanding": peak_outstanding,
            "p50_ok": pct(ok_intended, 50),
            "p99_ok": pct(ok_intended, 99),
            "p100_ok": ts(max(ok_intended)) if ok_intended else None,
            "mean_ok": ts(sum(ok_intended) / n_ok) if n_ok else None,
            "p99_ok_e2e": pct(ok_e2e, 99),
            "p99_all_recorded": pct(all_latency, 99) if all_latency else None,
            "p99_success_only": pct(ok_intended, 99),
            "p99_corrected": hist_corr.percentile_exact(99),
            "n_corrected": hist_corr.count(),
            "p99_bucketed_ok": hist_raw.percentile_bucketed(99),
            "p99_bucketed_corrected": hist_corr.percentile_bucketed(99),
            "bucket_width": BUCKET_WIDTH,
            "n_slow_ok": sum(1 for v in ok_intended if v > service_s + 1e-12),
            "ended": ended,
        }


