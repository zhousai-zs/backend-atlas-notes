#!/usr/bin/env bash
# 端到端：v1/v2 客户端 x v1/v2 服务端四种组合 + 回滚/前滚。只依赖 python3 + protobuf。
set -uo pipefail
cd "$(dirname "$0")"
N=50; FANS=20; FAIL=0
W=$(mktemp -d); PIDS=()
cleanup(){ for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null; done; rm -rf "$W"; }
trap cleanup EXIT
start(){ # ver mode port store
  python3 server.py --version "$1" --mode "$2" --port "$3" --store "$4" >/dev/null 2>&1 & PIDS+=($!)
  for _ in $(seq 50); do curl -s "127.0.0.1:$3/stats" >/dev/null && return; sleep 0.1; done; echo "server $1 start fail"; exit 1; }
stop_all(){ for p in "${PIDS[@]:-}"; do kill "$p" 2>/dev/null; wait "$p" 2>/dev/null; done; PIDS=(); }
J(){ python3 -c "import json,sys; print(json.loads(sys.argv[1])[sys.argv[2]])" "$1" "$2"; }
expect(){ # name actual op expected
  if python3 -c "import sys; a,b=int(sys.argv[1]),int(sys.argv[3]); sys.exit(0 if eval(f'a {sys.argv[2]} b') else 1)" "$2" "$3" "$4"; then
    echo "  PASS $1 ($2 $3 $4)"; else echo "  FAIL $1 (got $2, want $3 $4)"; FAIL=$((FAIL+1)); fi; }

echo "== 0. 契约测试（golden 样本，进程内）"
python3 contract_test.py | sed 's/^/  /'; [ "${PIPESTATUS[0]}" = 0 ] || FAIL=$((FAIL+1))

echo "== 1. 准备数据：v1 客户端经 v1 服务写 ${N} 篇；v2 客户端经 v2 服务写 ${N} 篇（其中 ${FANS} 篇 FANS_ONLY，全部 cover_style=big）"
start v1 safe 18101 "$W/v1data"; python3 client.py --version v1 --port 18101 seed $N >/dev/null
start v2 safe 18102 "$W/v2data"; python3 client.py --version v2 --port 18102 seed $N $FANS >/dev/null
stop_all

echo "== 2. 四种组合（safe 服务端），读 v2 写入的数据"
for sv in v1 v2; do
  port=$([ $sv = v1 ] && echo 18111 || echo 18112); start $sv safe $port "$W/v2data"
  for cv in v1 v2; do
    r=$(python3 client.py --version $cv --port $port check $N); echo "  client=$cv server=$sv: $r"
    expect "client=$cv server=$sv 无 5xx" "$(J "$r" err)" == 0
    expect "client=$cv server=$sv 游客看不到 FANS_ONLY" "$(J "$r" fans_only_seen_by_guest)" == 0
  done
  echo "  server=$sv stats: $(curl -s 127.0.0.1:$port/stats)"
done
stop_all
echo "== 3. 字段缺失：v2 客户端经 v2 服务读 v1 写入的数据"
start v2 safe 18121 "$W/v1data"
r=$(python3 client.py --version v2 --port 18121 check $N); echo "  $r"
expect "v1 数据全部 HasField(cover_style)=False -> 走默认值" "$(J "$r" cover_default_used)" == $N
expect "无 5xx" "$(J "$r" err)" == 0
stop_all

echo "== 4. 反例：v1 naive（黑名单可见性）读 v2 数据"
start v1 naive 18131 "$W/v2data"
r=$(python3 client.py --version v1 --port 18131 check $N); echo "  $r"
expect "naive 把 FANS_ONLY 泄露给游客" "$(J "$r" fans_only_seen_by_guest)" == $FANS
stop_all

for mode in safe naive; do
  echo "== 5-$mode. 回滚：v2 数据 -> 回滚到 v1($mode) 并对全部文章读改写 -> 前滚 v2"
  cp -r "$W/v2data" "$W/rb_$mode"
  start v1 $mode 18141 "$W/rb_$mode"
  r=$(python3 client.py --version v1 --port 18141 retitle $N); echo "  v1($mode) retitle: $r  stats=$(curl -s 127.0.0.1:18141/stats)"
  expect "回滚后读改写全部成功(不因新数据无法解析失败)" "$(J "$r" ok)" == $N
  stop_all
  start v2 safe 18142 "$W/rb_$mode"
  r=$(python3 client.py --version v2 --port 18142 check $N); echo "  前滚 v2 后: $r"
  if [ $mode = safe ]; then
    expect "safe: cover_style 全部保留" "$(J "$r" cover_present)" == $N
    expect "safe: 粉丝仍能看到全部文章" "$(J "$r" fan_200)" == $N
  else
    expect "naive: DTO 拷贝把 cover_style 全部丢掉" "$(J "$r" cover_present)" == 0
  fi
  stop_all
done

if [ $FAIL -eq 0 ]; then echo "ALL_CHECKS_PASSED"; else echo "FAILED=$FAIL"; exit 1; fi
