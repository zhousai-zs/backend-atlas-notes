"""文章服务（教学模拟）：二进制 protobuf over HTTP，文件存储（回滚/前滚共用同一份数据）。
python3 server.py --version v1|v2 --mode safe|naive --port P --store DIR
  POST /put            body=Article 字节 -> 存储
  POST /update_title?id=&title=   读-改-写（回滚场景的关键路径）
  GET  /get?id=&viewer=guest|fan   可见性判断后返回 Article 字节；403 不可见
  GET  /stats          unknown_enum / parse_error 计数
naive 模式（反例）：v1 用「黑名单」判可见性(只拦 DRAFT)；读改写时把已知字段拷到新对象(DTO 转换)。
safe  模式：白名单判可见性(未知枚举按最严格=不可见并计数)；读改写在原消息上修改，保留未知字段。"""
import argparse, os, json, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import schema

ap = argparse.ArgumentParser()
ap.add_argument("--version", choices=["v1", "v2"], required=True)
ap.add_argument("--mode", choices=["safe", "naive"], default="safe")
ap.add_argument("--port", type=int, required=True)
ap.add_argument("--store", required=True)
args = ap.parse_args()
Article, State = schema.get(args.version)
KNOWN = set(State.values_by_number)
stats = {"unknown_enum": 0, "parse_error": 0}
os.makedirs(args.store, exist_ok=True)

def path(i): return os.path.join(args.store, f"{int(i)}.bin")

def load(i):
    with open(path(i), "rb") as f:
        m = Article()
        m.ParseFromString(f.read())
        return m

def save(m):
    tmp = path(m.id) + ".tmp"
    with open(tmp, "wb") as f: f.write(m.SerializeToString())
    os.replace(tmp, path(m.id))

def visible(m, viewer):
    s = m.state
    if s not in KNOWN:
        stats["unknown_enum"] += 1
    if args.mode == "naive":                 # 反例：黑名单，只拦已知的 DRAFT
        return s != schema.DRAFT
    if s == schema.PUBLIC: return True        # 白名单
    if args.version == "v2" and s == schema.FANS_ONLY: return viewer == "fan"
    return False                              # DRAFT / UNSPECIFIED / 未知值 -> 最严格

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def reply(self, code, body=b"", ctype="application/x-protobuf"):
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == "/stats":
            return self.reply(200, json.dumps(stats).encode(), "application/json")
        if u.path == "/get":
            try: m = load(q["id"])
            except Exception:
                stats["parse_error"] += 1; return self.reply(500, b"parse error")
            if not visible(m, q.get("viewer", "guest")): return self.reply(403)
            return self.reply(200, m.SerializeToString())
        self.reply(404)
    def do_POST(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        try:
            if u.path == "/put":
                m = Article(); m.ParseFromString(body); save(m); return self.reply(200)
            if u.path == "/update_title":
                old = load(q["id"])
                if args.mode == "naive":         # 反例：DTO 拷贝，只认识自己版本的字段
                    m = Article(id=old.id, title=old.title, state=old.state, view_count=old.view_count)
                else:
                    m = old                       # 在原消息上改，未知字段随之保留
                m.title = q["title"]; save(m); return self.reply(200)
        except Exception as e:
            stats["parse_error"] += 1; return self.reply(500, str(e).encode())
        self.reply(404)

print(f"server {args.version}/{args.mode} :{args.port}", flush=True)
ThreadingHTTPServer(("127.0.0.1", args.port), H).serve_forever()
