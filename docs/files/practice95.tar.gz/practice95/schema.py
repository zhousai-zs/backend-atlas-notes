"""用 descriptor_pb2 动态构造 v1 / v2 两版 article.proto（无需 protoc），各自独立的 DescriptorPool。
等价的 .proto 见 article_v1.proto / article_v2.proto。"""
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

F = descriptor_pb2.FieldDescriptorProto

def _build(version, reuse_tag4_as_like=False):
    fd = descriptor_pb2.FileDescriptorProto(name=f"article_{version}.proto", package="atlas.article", syntax="proto3")
    en = fd.enum_type.add(name="ArticleState")
    vals = [("ARTICLE_STATE_UNSPECIFIED", 0), ("ARTICLE_STATE_PUBLIC", 1), ("ARTICLE_STATE_DRAFT", 2)]
    if version == "v2":
        vals.append(("ARTICLE_STATE_FANS_ONLY", 3))          # v2 新增枚举值
    for n, v in vals:
        en.value.add(name=n, number=v)
    m = fd.message_type.add(name="Article")
    m.field.add(name="id", number=1, type=F.TYPE_INT64, label=F.LABEL_OPTIONAL)
    m.field.add(name="title", number=2, type=F.TYPE_STRING, label=F.LABEL_OPTIONAL)
    m.field.add(name="state", number=3, type=F.TYPE_ENUM, type_name=".atlas.article.ArticleState", label=F.LABEL_OPTIONAL)
    if reuse_tag4_as_like:   # 反例：删掉 view_count 后把 4 号复用成 like_count
        m.field.add(name="like_count", number=4, type=F.TYPE_INT64, label=F.LABEL_OPTIONAL)
    else:
        m.field.add(name="view_count", number=4, type=F.TYPE_INT64, label=F.LABEL_OPTIONAL)
    if version == "v2":      # v2 新增 optional string cover_style = 5（proto3 optional，显式 presence）
        m.oneof_decl.add(name="_cover_style")
        m.field.add(name="cover_style", number=5, type=F.TYPE_STRING, label=F.LABEL_OPTIONAL,
                    oneof_index=0, proto3_optional=True)
    pool = descriptor_pool.DescriptorPool()
    pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName("atlas.article.Article")), \
           pool.FindEnumTypeByName("atlas.article.ArticleState")

ArticleV1, StateV1 = _build("v1")
ArticleV2, StateV2 = _build("v2")
ArticleBadReuse, _ = _build("v1", reuse_tag4_as_like=True)

def get(version):
    return (ArticleV1, StateV1) if version == "v1" else (ArticleV2, StateV2)

PUBLIC, DRAFT, FANS_ONLY = 1, 2, 3
