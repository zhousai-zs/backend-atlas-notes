"""契约测试：用存档的 golden 样本覆盖 写端{v1,v2} x 读端{v1,v2} 四种组合，外加回滚/JSON/复用编号反例。"""
import os, sys
from google.protobuf import json_format, unknown_fields
from google.protobuf.internal.enum_type_wrapper import EnumTypeWrapper
import schema
from schema import ArticleV1, ArticleV2, StateV1

os.makedirs("golden", exist_ok=True)
golden = {
    "v1": ArticleV1(id=7, title="hello", state=schema.PUBLIC, view_count=12345).SerializeToString(),
    "v2": ArticleV2(id=8, title="fans", state=schema.FANS_ONLY, view_count=9, cover_style="big").SerializeToString(),
}
for k, b in golden.items():
    open(f"golden/article_{k}.bin", "wb").write(b)

fails = 0
def check(name, cond, detail=""):
    global fails
    print(f"{'PASS' if cond else 'FAIL'}  {name}  {detail}")
    if not cond: fails += 1

readers = {"v1": ArticleV1, "v2": ArticleV2}
print("== 四种组合（writer -> reader）")
for w, b in golden.items():
    for r, cls in readers.items():
        m = cls(); m.ParseFromString(b)
        check(f"{w}->{r} 可解析且 id/title 一致", (m.id, m.title) == ((7, "hello") if w == "v1" else (8, "fans")),
              f"bytes={len(b)} state={m.state}")

print("== 新增字段 / 未知字段")
old = ArticleV1.FromString(golden["v2"])
uf = [(f.field_number, f.data) for f in unknown_fields.UnknownFieldSet(old)]
check("v1 读 v2：新枚举以数值 3 保留(open enum)", old.state == 3, f"state={old.state}")
check("v1 读 v2：cover_style 进入 unknown fields", uf == [(5, b"big")], f"unknown={uf}")
check("v1 原样再序列化与 v2 字节一致", old.SerializeToString() == golden["v2"])
old.title = "fans-edited"                                   # 回滚期间 v1 读-改-写
back = ArticleV2.FromString(old.SerializeToString())
check("v1 读改写后 v2 仍读到 cover_style/FANS_ONLY", back.cover_style == "big" and back.state == schema.FANS_ONLY,
      f"cover={back.cover_style!r} state={back.state} title={back.title}")
dto = ArticleV1(id=old.id, title=old.title, state=old.state, view_count=old.view_count)   # 反例：DTO 拷贝
lost = ArticleV2.FromString(dto.SerializeToString())
check("反例 DTO 拷贝：cover_style 丢失(被检测到)", not lost.HasField("cover_style"))
new_from_v1 = ArticleV2.FromString(golden["v1"])
check("v2 读 v1：optional 字段 HasField=False，可用业务默认值兜底", not new_from_v1.HasField("cover_style"),
      f"cover={new_from_v1.cover_style!r}")

print("== 语义兼容")
try:
    EnumTypeWrapper(StateV1).Name(3); crashed = False
except ValueError as e:
    crashed = True; msg = str(e)
check("反例：v1 用 Name(state) 渲染标签会抛 ValueError", crashed, msg if crashed else "")
naive_visible = old.state != schema.DRAFT
safe_visible = old.state == schema.PUBLIC
check("反例：黑名单可见性把 FANS_ONLY 当公开", naive_visible is True)
check("白名单可见性对未知值走最严格(不可见)", safe_visible is False)

print("== JSON 交换")
js = json_format.MessageToJson(ArticleV2.FromString(golden["v2"]))
try:
    json_format.Parse(js, ArticleV1()); jerr = None
except json_format.ParseError as e:
    jerr = str(e)
check("v1 解析 v2 JSON 直接失败", jerr is not None, (jerr or "")[:70])
ign = json_format.Parse(js, ArticleV1(), ignore_unknown_fields=True)
check("ignore_unknown_fields：不报错但 state 变 0、cover 丢失", ign.state == 0 and b"big" not in ign.SerializeToString(),
      f"state={ign.state}")

print("== 复用字段编号（反例）")
bad = schema.ArticleBadReuse.FromString(golden["v1"])
check("删 view_count 后复用 4 号为 like_count：旧数据被静默读成点赞数", bad.like_count == 12345,
      f"like_count={bad.like_count}")

print("ALL_CONTRACT_PASSED" if fails == 0 else f"CONTRACT_FAILS={fails}")
sys.exit(1 if fails else 0)
