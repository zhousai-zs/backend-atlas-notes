"""客户端（教学模拟）：python3 client.py --version v1|v2 --port P CMD ...
  seed N FANS     写入 id 1..N，前 FANS 篇 FANS_ONLY（仅 v2 能写）、其余 PUBLIC；v2 带 cover_style=big
  check N         以 guest/fan 读全部文章，输出 JSON 统计
  retitle N       对全部文章调用 /update_title"""
import argparse, json, urllib.request, urllib.error
import schema
ap = argparse.ArgumentParser()
ap.add_argument("--version", choices=["v1", "v2"], required=True)
ap.add_argument("--port", type=int, required=True)
ap.add_argument("cmd"); ap.add_argument("n", type=int); ap.add_argument("fans", type=int, nargs="?", default=0)
a = ap.parse_args()
Article, State = schema.get(a.version)
base = f"http://127.0.0.1:{a.port}"

def call(method, p, body=None):
    req = urllib.request.Request(base + p, data=body, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5) as r: return r.status, r.read()
    except urllib.error.HTTPError as e: return e.code, e.read()

if a.cmd == "seed":
    for i in range(1, a.n + 1):
        m = Article(id=i, title=f"t{i}", view_count=100 + i)
        m.state = schema.FANS_ONLY if (a.version == "v2" and i <= a.fans) else schema.PUBLIC
        if a.version == "v2": m.cover_style = "big"
        assert call("POST", "/put", m.SerializeToString())[0] == 200
    print(json.dumps({"seeded": a.n}))
elif a.cmd == "retitle":
    codes = [call("POST", f"/update_title?id={i}&title=new{i}")[0] for i in range(1, a.n + 1)]
    print(json.dumps({"ok": codes.count(200), "fail": len(codes) - codes.count(200)}))
elif a.cmd == "check":
    r = {"guest_200": 0, "guest_403": 0, "fan_200": 0, "err": 0, "fans_only_seen_by_guest": 0,
         "unknown_state": 0, "cover_present": 0, "cover_default_used": 0}
    known = set(State.values_by_number)
    for i in range(1, a.n + 1):
        for viewer in ("guest", "fan"):
            code, body = call("GET", f"/get?id={i}&viewer={viewer}")
            if code >= 500: r["err"] += 1; continue
            if code == 403:
                if viewer == "guest": r["guest_403"] += 1
                continue
            m = Article(); m.ParseFromString(body)       # 客户端用自己的版本解析
            r[f"{viewer}_200"] += 1
            if viewer == "guest" and m.state == schema.FANS_ONLY:
                r["fans_only_seen_by_guest"] += 1
            if viewer == "fan":
                if m.state not in known: r["unknown_state"] += 1
                if a.version == "v2":
                    if m.HasField("cover_style"): r["cover_present"] += 1
                    else: r["cover_default_used"] += 1   # 旧数据缺字段 -> 客户端用 "classic" 兜底
    print(json.dumps(r))
