from __future__ import annotations

import json
from pathlib import Path

import yaml
from analyze import dependents, exception_problems, find_spofs, inject_outage

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def main() -> None:
    cat = yaml.safe_load((ROOT / "catalog" / "services.yaml").read_text())
    services = cat["services"]
    assert len(services) == 10
    inc = dependents(services)
    spofs = find_spofs(services, inc)
    before = inject_outage(services, "config", remediations=[])
    # Remediation: give config a replica AND a cached fallback on dependents
    rem = [{"service": "config", "action": "add_replica_and_client_cache", "provides_fallback": True,
            "verification": "inject config outage: only config itself is marked failed; dependents stay up using cache"}]
    after = inject_outage(services, "config", remediations=rem)
    # Bad "governance": more approval steps, same blast radius
    approval_only = {"approval_steps": 3, "blast_radius": len(before), "removed_failure_path": False}

    ex_ok = exception_problems(cat["exceptions"])
    ex_bad = exception_problems(yaml.safe_load((ROOT / "catalog" / "expired-exception.yaml").read_text())["exceptions"])

    checks = [
        ("ten_services", len(services) == 10, str(len(services))),
        ("config_is_spof", any(s["id"] == "config" and s["blast_radius"] >= 8 for s in spofs), str(spofs)),
        ("blast_radius_before_high", len(before) >= 9, f"failed={sorted(before)}"),
        ("remediation_reduces_blast_radius", len(after) == 1 and "config" in after, f"after={sorted(after)}"),
        ("metric_tied_to_failure", len(after) < len(before), f"before={len(before)} after={len(after)}"),
        ("approval_only_does_not_fix", approval_only["removed_failure_path"] is False and approval_only["blast_radius"] == len(before), str(approval_only)),
        ("open_exception_has_owner_and_date", ex_ok == [], str(ex_ok)),
        ("expired_or_ownerless_exception_rejected", len(ex_bad) >= 2, str(ex_bad)),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    report = {"spofs": spofs, "failed_before": sorted(before), "failed_after": sorted(after),
              "remediation": rem, "approval_only": approval_only}
    (ROOT / "reports" / "governance.json").write_text(json.dumps(report, indent=2) + "\n")
    RESULTS.write_text(json.dumps({
        "lesson": 207, "id": "n-governance", "is_live_model": False,
        "report": report,
        "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        "failed": failed,
        "not_verified_on_this_machine": [
            "a production service catalog or real multi-team config outage",
        ],
        "verified_on_this_machine": [
            "10-service dependency graph, config SPOF blast radius computed",
            "fallback remediation reduces injected outage impact; approval-only change does not",
            "exceptions require owner and expiry",
        ],
    }, ensure_ascii=False, indent=2) + "\n")
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
