from __future__ import annotations

from collections import defaultdict
from datetime import date


def dependents(services):
    incoming = defaultdict(list)
    ids = {s["id"] for s in services}
    for s in services:
        for d in s.get("deps") or []:
            if d in ids:
                incoming[d].append(s["id"])
    return incoming


def find_spofs(services, incoming):
    spofs = []
    for s in services:
        if s.get("replicas", 1) <= 1 and len(incoming.get(s["id"], [])) >= 2:
            spofs.append({
                "id": s["id"],
                "owner": s.get("owner"),
                "replicas": s.get("replicas"),
                "dependents": list(incoming.get(s["id"], [])),
                "blast_radius": len(incoming.get(s["id"], [])),
            })
    return spofs


def inject_outage(services, target, remediations):
    """If target is down, which services fail? A remediated service may have fallback."""
    fallback = {r["service"] for r in remediations if r.get("provides_fallback")}
    failed = {target}
    if target in fallback:
        # fallback means dependents survive this outage
        return {target}
    changed = True
    ids = {s["id"]: s for s in services}
    while changed:
        changed = False
        for s in services:
            if s["id"] in failed:
                continue
            if any(d in failed for d in s.get("deps") or []):
                failed.add(s["id"])
                changed = True
    return failed


def exception_problems(exceptions, today=date(2026, 11, 16)):
    problems = []
    for e in exceptions:
        if not e.get("owner"):
            problems.append(f"{e.get('id')}_missing_owner")
        if not e.get("until"):
            problems.append(f"{e.get('id')}_missing_until")
        else:
            until = date.fromisoformat(str(e["until"]))
            if until < today and e.get("status") == "open":
                problems.append(f"{e.get('id')}_expired")
    return problems
