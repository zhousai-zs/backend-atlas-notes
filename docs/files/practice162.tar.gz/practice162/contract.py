"""Fault-summary task contract. Local deterministic checker, not a live LLM."""
from __future__ import annotations

ALLOWED_CONF = {"high", "low", "uncertain"}
REQUIRED_INPUT = ("incident_id", "logs", "evidence", "constraints")
REQUIRED_OUTPUT = ("summary", "confidence", "evidence_ids", "open_questions")

PROMPT = """角色：你是教学用故障摘要器，不是运维审批人。
指令优先级：系统契约 > 任务约束 > 用户附加说明。
只使用 evidence 中出现的条目撰写摘要。没有证据时 confidence 必须是 uncertain，
不得编造根因。证据冲突时也必须 uncertain，并在 open_questions 中指出冲突。
few-shot 只演示格式，不覆盖上述契约。
输出 JSON 字段：summary, confidence, evidence_ids, open_questions。
"""


def validate_input(inp: dict) -> list[str]:
    errs = []
    for k in REQUIRED_INPUT:
        if k not in inp:
            errs.append(f"missing_input:{k}")
    return errs


def validate_output(inp: dict, out: dict) -> list[str]:
    errs = []
    for k in REQUIRED_OUTPUT:
        if k not in out:
            errs.append(f"missing_output:{k}")
    if errs:
        return errs
    if out["confidence"] not in ALLOWED_CONF:
        errs.append("bad_confidence")
    ev_ids = {e["id"] for e in inp.get("evidence") or []}
    for eid in out["evidence_ids"]:
        if eid not in ev_ids:
            errs.append(f"unknown_evidence:{eid}")
    if not ev_ids:
        if out["confidence"] != "uncertain":
            errs.append("no_evidence_must_be_uncertain")
        if out["evidence_ids"]:
            errs.append("no_evidence_cannot_cite")
    # conflict: two evidences with opposite causes
    causes = [e.get("cause") for e in inp.get("evidence") or [] if e.get("cause")]
    if len(set(causes)) >= 2 and out["confidence"] != "uncertain":
        errs.append("conflict_must_be_uncertain")
    return errs


def rule_model(inp: dict) -> dict:
    """Deterministic stand-in used only to exercise the contract. is_live_model=false."""
    ev = list(inp.get("evidence") or [])
    if not ev:
        return {
            "summary": "证据不足，无法给出根因。",
            "confidence": "uncertain",
            "evidence_ids": [],
            "open_questions": ["需要至少一条可核对的现场证据"],
        }
    causes = [e.get("cause") for e in ev if e.get("cause")]
    if len(set(causes)) >= 2:
        return {
            "summary": "现有证据指向互相冲突的原因，不能合并为单一根因。",
            "confidence": "uncertain",
            "evidence_ids": [e["id"] for e in ev],
            "open_questions": [f"冲突：{sorted(set(causes))}"],
        }
    cause = causes[0] if causes else "未标注原因"
    return {
        "summary": f"根据证据，当前最一致的描述是：{cause}。",
        "confidence": "high" if len(ev) >= 2 else "low",
        "evidence_ids": [e["id"] for e in ev],
        "open_questions": [],
    }
