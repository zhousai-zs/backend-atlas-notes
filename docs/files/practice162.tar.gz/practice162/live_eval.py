#!/usr/bin/env python3
"""Optional live path: run tests/cases.json against a real model.

This script is NOT executed by test.sh. It never invents a passing
prompt-effectiveness result from the rule_model fixture.

Usage (user machine, official SDK, a key you provide yourself):

  pip install 'openai==3.51.0'
  export OPENAI_API_KEY=...          # not read by test.sh
  python live_eval.py --model gpt-6.1-terra   # or another model you choose

Usage (local OpenAI-compatible server you already run, no OpenAI key):

  python live_eval.py --base-url http://127.0.0.1:8000/v1 --model <local>

The checker in contract.py is the grader. A run is only evidence of prompt
effect when this script talks to a real model and writes
reports/live_eval.json with is_live_model=true.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from contract import PROMPT, validate_output  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", default=None, help="OpenAI-compatible base URL")
    ap.add_argument("--model", required=True)
    ap.add_argument("--cases", default=str(ROOT / "tests" / "cases.json"))
    args = ap.parse_args()
    try:
        from openai import OpenAI
    except ImportError:
        print("install openai==3.51.0 first", file=sys.stderr)
        return 2
    kwargs = {}
    if args.base_url:
        kwargs["base_url"] = args.base_url
        kwargs["api_key"] = os.environ.get("OPENAI_API_KEY", "sk-local-placeholder")
    else:
        if not os.environ.get("OPENAI_API_KEY"):
            print("OPENAI_API_KEY is required for the hosted API path", file=sys.stderr)
            return 2
        # The official client reads the env var itself.
    client = OpenAI(**kwargs)
    cases = json.loads(Path(args.cases).read_text())
    rows = []
    for case in cases:
        user = json.dumps(case["input"], ensure_ascii=False)
        resp = client.chat.completions.create(
            model=args.model,
            messages=[
                {"role": "system", "content": PROMPT},
                {"role": "user", "content": user},
            ],
            temperature=0,
        )
        text = resp.choices[0].message.content or ""
        try:
            out = json.loads(text)
        except json.JSONDecodeError as exc:
            out = {"_raw": text, "_parse_error": str(exc)}
            errs = [f"json_decode:{exc.msg}"]
        else:
            errs = validate_output(case["input"], out)
        rows.append(
            {
                "id": case["id"],
                "output": out,
                "contract_errors": errs,
                "passed": not errs,
                "finish_reason": resp.choices[0].finish_reason,
            }
        )
    report = {
        "is_live_model": True,
        "model": args.model,
        "base_url": args.base_url or "official-default",
        "cases": rows,
        "all_passed": all(r["passed"] for r in rows),
    }
    dest = ROOT / "reports" / "live_eval.json"
    dest.parent.mkdir(exist_ok=True)
    dest.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
