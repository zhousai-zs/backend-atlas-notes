#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from contract import PROMPT, rule_model, validate_input, validate_output

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
bundle = json.loads((ROOT / "tests/cases.json").read_text())
assert bundle["fixed"] is True

# A "stronger wording" prompt must not be accepted as proof of correctness
STRONG = PROMPT + "\n务必保证答案正确，一定要给出根因。"

results_cases = []
for case in bundle["cases"]:
    inp = case["input"]
    in_errs = validate_input(inp)
    out = rule_model(inp)
    out_errs = validate_output(inp, out)
    rec = {
        "id": case["id"],
        "input_ok": not in_errs,
        "output": out,
        "contract_errors": out_errs,
        "passed": not in_errs and not out_errs,
    }
    results_cases.append(rec)

# Demonstrate stronger wording does not override the contract:
missing = next(c for c in bundle["cases"] if c["id"] == "missing")
# even if we naively "answered" with high confidence, the test set still fails it
bad = {"summary": "一定是磁盘故障", "confidence": "high", "evidence_ids": [], "open_questions": []}
bad_errs = validate_output(missing["input"], bad)
assert "no_evidence_must_be_uncertain" in bad_errs

assert all(c["passed"] for c in results_cases)
assert {c["id"] for c in results_cases} == {"normal", "missing", "conflict"}
assert next(c for c in results_cases if c["id"] == "missing")["output"]["confidence"] == "uncertain"
assert next(c for c in results_cases if c["id"] == "conflict")["output"]["confidence"] == "uncertain"

results = {
    "lesson": 162,
    "id": "k-prompt",
    "is_live_model": False,
    "used_paid_api": False,
    "fixed_test_set": str((ROOT / "tests/cases.json").relative_to(ROOT)),
    "n_cases": len(results_cases),
    "cases": results_cases,
    "stronger_wording_does_not_bypass_contract": True,
    "stronger_wording_bad_output_caught": bad_errs,
    "prompt_chars": len(PROMPT),
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "prompt.txt").write_text(PROMPT)
print(json.dumps(results, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
