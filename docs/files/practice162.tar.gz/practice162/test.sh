#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
python3 driver.py 2>&1 | tee run.log
PY="${PYTHON:-python3}"
if [[ -x /workspace/atlas/cmvenv/bin/python && -z "${PYTHON:-}" ]]; then PY=/workspace/atlas/cmvenv/bin/python; fi
"$PY" - <<'CHK'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert r["is_live_model"] is False
assert r["prompt_effect_on_llm_verified"] is False
assert r["contract_checker_verified"] is True
assert r["rule_model_is_not_prompt_evidence"] is True
print("POSTCHECK_OK")
CHK
