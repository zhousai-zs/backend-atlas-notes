#!/usr/bin/env python3
"""Teaching experiments for Backend Atlas lesson 100 (g-mvcc).

Scenes use a content-backend article (draft / published, view count).
They are teaching hypotheses, not Tencent / WeChat internals.

All numbers come from the teaching MVCCEngine in engine.py. That engine
is not InnoDB, PostgreSQL, or SQLite. Timing measurements use a fixed
hold of 0.2s; wait assertions in test_mvcc.py use a loose threshold so
the result stays stable across runs.
"""
from __future__ import annotations

import threading
import time
from typing import Optional

from engine import MVCCEngine, Tx


ARTICLE_ID = 1
HOLD_S = 0.2
TITLE = "autumn-review"


def _seed_article(engine: MVCCEngine, views: int = 100, status: str = "draft") -> None:
    engine.create_table("articles")
    engine.seed(
        "articles",
        ARTICLE_ID,
        {"id": ARTICLE_ID, "title": TITLE, "status": status, "views": views},
    )


def _row(engine: MVCCEngine, tx: Tx) -> Optional[dict]:
    return engine.consistent_read(tx, "articles", ARTICLE_ID)


def _brief(row: Optional[dict]) -> Optional[dict]:
    if row is None:
        return None
    return {"status": row["status"], "views": row["views"]}


# ---------------------------------------------------------------------------
# 1) Snapshot visibility: RR keeps the first consistent-read snapshot;
#    RC takes a fresh snapshot on every consistent read.
# ---------------------------------------------------------------------------

def experiment_snapshot_visibility() -> dict:
    initial = {"status": "draft", "views": 100}
    after_b = {"status": "published", "views": 120}

    def run(isolation: str) -> dict:
        eng = MVCCEngine()
        _seed_article(eng, views=100, status="draft")
        a = eng.begin(isolation)
        first = _brief(_row(eng, a))
        b = eng.begin("READ COMMITTED")
        eng.update(
            b,
            "articles",
            ARTICLE_ID,
            {"title": TITLE, "status": "published", "views": 120},
        )
        eng.commit(b)
        second = _brief(_row(eng, a))
        c = eng.begin("READ COMMITTED")
        c_sees = _brief(_row(eng, c))
        eng.commit(c)
        eng.commit(a)
        return {"a_first": first, "a_second": second, "c_sees": c_sees}

    rr = run("REPEATABLE READ")
    rc = run("READ COMMITTED")
    return {
        "initial": initial,
        "after_b": after_b,
        "rr": rr,
        "rc": rc,
    }


# ---------------------------------------------------------------------------
# 2) Consistent read vs current / locking read.
# ---------------------------------------------------------------------------

def experiment_consistent_vs_locking() -> dict:
    eng = MVCCEngine()
    _seed_article(eng, views=100, status="draft")

    # B publishes while A already holds an RR snapshot.
    a = eng.begin("REPEATABLE READ")
    snap_before = _brief(_row(eng, a))
    b = eng.begin("READ COMMITTED")
    eng.update(
        b,
        "articles",
        ARTICLE_ID,
        {"title": TITLE, "status": "published", "views": 120},
    )
    eng.commit(b)

    snap_after = _brief(_row(eng, a))
    current = _brief(
        eng.locking_read(a, "articles", ARTICLE_ID, mode="FOR UPDATE")
    )
    # A took a lock but did not modify the row; roll back so later
    # timing experiments start from a clean engine.
    status_views_after_current = current
    eng.rollback(a)

    snap_wait = _wait_while_holder(
        holder_kind="snapshot",
        hold_s=HOLD_S,
        initial_views=100,
        initial_status="draft",
    )
    lock_wait = _wait_while_holder(
        holder_kind="locking",
        hold_s=HOLD_S,
        initial_views=100,
        initial_status="draft",
    )

    return {
        "a_snapshot_before_b": snap_before,
        "a_snapshot_after_b": snap_after,
        "a_current_after_b": status_views_after_current,
        "snapshot_read_does_not_block_update": snap_wait,
        "locking_read_blocks_update": lock_wait,
    }


def _wait_while_holder(
    holder_kind: str, hold_s: float, initial_views: int, initial_status: str
) -> dict:
    """A holds either a snapshot or a FOR UPDATE lock for hold_s seconds.

    B then tries an UPDATE. Returns B's wait time.
    """
    eng = MVCCEngine()
    _seed_article(eng, views=initial_views, status=initial_status)
    a_ready = threading.Event()
    a_done = threading.Event()
    errors: list[str] = []

    def holder() -> None:
        try:
            a = eng.begin("REPEATABLE READ")
            if holder_kind == "snapshot":
                eng.consistent_read(a, "articles", ARTICLE_ID)
            else:
                eng.locking_read(a, "articles", ARTICLE_ID, mode="FOR UPDATE")
            a_ready.set()
            time.sleep(hold_s)
            eng.commit(a)
        except Exception as exc:  # noqa: BLE001 — surface in the result dict
            errors.append(f"holder: {exc!r}")
            a_ready.set()
        finally:
            a_done.set()

    t = threading.Thread(target=holder, name=f"holder-{holder_kind}")
    t.start()
    if not a_ready.wait(timeout=2.0):
        errors.append("holder did not become ready")
    t0 = time.monotonic()
    b = eng.begin("READ COMMITTED")
    eng.update(
        b,
        "articles",
        ARTICLE_ID,
        {"title": TITLE, "status": "published", "views": 120},
    )
    eng.commit(b)
    wait_s = round(time.monotonic() - t0, 4)
    t.join(timeout=2.0)
    a_done.wait(timeout=0.5)
    return {
        "hold_s": hold_s,
        "wait_s": wait_s,
        "blocked": wait_s >= hold_s * 0.75,
        "errors": errors,
    }


# ---------------------------------------------------------------------------
# 3) Undo / long transaction / purge.
# ---------------------------------------------------------------------------

def experiment_purge_long_tx() -> dict:
    updates = 50
    eng = MVCCEngine()
    _seed_article(eng, views=100, status="draft")
    versions_at_start = eng.version_count("articles", ARTICLE_ID)

    # Long-lived RR transaction: first consistent read pins a snapshot
    # of the draft (views=100) for the rest of this transaction.
    long_tx = eng.begin("REPEATABLE READ")
    pinned = _brief(_row(eng, long_tx))

    for i in range(updates):
        w = eng.begin("READ COMMITTED")
        # 50 committed updates: views become 101, 102, ... 150,
        # and after the first one the article is published.
        eng.update(
            w,
            "articles",
            ARTICLE_ID,
            {
                "title": TITLE,
                "status": "published",
                "views": 100 + (i + 1),
            },
        )
        eng.commit(w)

    versions_while_active_before_purge = eng.version_count("articles", ARTICLE_ID)
    # Purge cannot drop the chain while the long snapshot is alive.
    blocked = eng.purge()
    versions_while_active = eng.version_count("articles", ARTICLE_ID)
    still_pinned = _brief(_row(eng, long_tx))

    # The long transaction ends; nothing else holds a snapshot.
    eng.commit(long_tx)
    after = eng.purge()
    versions_after = eng.version_count("articles", ARTICLE_ID)
    fresh = eng.begin("READ COMMITTED")
    latest = _brief(_row(eng, fresh))
    eng.commit(fresh)

    return {
        "updates": updates,
        "versions_at_start": versions_at_start,
        "long_tx_pinned": pinned,
        "long_tx_still_sees_after_updates": still_pinned,
        "versions_while_long_tx_active_before_purge": versions_while_active_before_purge,
        "versions_while_long_tx_active": versions_while_active,
        "purge_while_active": blocked,
        "versions_after_long_tx_end_and_purge": versions_after,
        "purge_after_end": after,
        "latest_after_purge": latest,
    }


# ---------------------------------------------------------------------------
# 4) naive vs safe: lost view increments, and dashboard locking vs snapshot.
# ---------------------------------------------------------------------------

def experiment_naive_vs_safe() -> dict:
    initial = 100
    concurrent = 19  # plus the naive/safe increment itself → expected 120
    expected = initial + concurrent + 1  # 120

    naive = _lost_increment(safe=False, initial=initial, concurrent=concurrent)
    safe = _lost_increment(safe=True, initial=initial, concurrent=concurrent)

    # Dashboard: naive path takes FOR UPDATE just to render a preview,
    # and blocks a publisher; safe path uses a consistent read.
    dash_lock = _wait_while_holder(
        holder_kind="locking",
        hold_s=HOLD_S,
        initial_views=100,
        initial_status="draft",
    )
    dash_snap = _wait_while_holder(
        holder_kind="snapshot",
        hold_s=HOLD_S,
        initial_views=100,
        initial_status="draft",
    )

    return {
        "initial_views": initial,
        "concurrent_increments": concurrent,
        "own_increment": 1,
        "expected": expected,
        "naive_final": naive["final"],
        "naive_wrote_back": naive["wrote_back"],
        "naive_snapshot_views": naive["snapshot_views"],
        "views_after_concurrent": naive["views_after_concurrent"],
        "safe_final": safe["final"],
        "safe_wrote_from_latest": safe["wrote_from_latest"],
        "locking_dashboard_blocks_writer": dash_lock,
        "snapshot_dashboard_does_not_block": dash_snap,
    }


def _lost_increment(safe: bool, initial: int, concurrent: int) -> dict:
    """A reads views, concurrent sessions each add 1, then A adds 1.

    naive: A writes back snapshot_views + 1 (absolute), losing the others.
    safe: A does views = views + 1 on the latest committed version.
    """
    eng = MVCCEngine()
    _seed_article(eng, views=initial, status="published")

    a = eng.begin("REPEATABLE READ")
    snap = eng.consistent_read(a, "articles", ARTICLE_ID)
    assert snap is not None
    snapshot_views = snap["views"]

    for _ in range(concurrent):
        w = eng.begin("READ COMMITTED")
        eng.update_current(
            w,
            "articles",
            ARTICLE_ID,
            lambda d: {**d, "views": d["views"] + 1},
        )
        eng.commit(w)

    mid = eng.begin("READ COMMITTED")
    mid_views = _row(eng, mid)["views"]  # type: ignore[index]
    eng.commit(mid)

    if safe:
        written = eng.update_current(
            a,
            "articles",
            ARTICLE_ID,
            lambda d: {**d, "views": d["views"] + 1},
        )
        wrote_back = written["views"]
    else:
        wrote_back = snapshot_views + 1
        eng.update(
            a,
            "articles",
            ARTICLE_ID,
            {**snap, "views": wrote_back},
        )
    eng.commit(a)

    c = eng.begin("READ COMMITTED")
    final = _row(eng, c)["views"]  # type: ignore[index]
    eng.commit(c)
    return {
        "snapshot_views": snapshot_views,
        "views_after_concurrent": mid_views,
        "wrote_back": wrote_back,
        "wrote_from_latest": safe,
        "final": final,
    }


def run_all_experiments() -> dict:
    return {
        "model": "teaching MVCCEngine (not InnoDB/PostgreSQL/SQLite)",
        "hold_s": HOLD_S,
        "snapshot_visibility": experiment_snapshot_visibility(),
        "consistent_vs_locking": experiment_consistent_vs_locking(),
        "purge_long_tx": experiment_purge_long_tx(),
        "naive_vs_safe": experiment_naive_vs_safe(),
    }


if __name__ == "__main__":
    import json
    import sys

    data = run_all_experiments()
    json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
