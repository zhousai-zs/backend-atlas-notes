#!/usr/bin/env python3
"""Acceptance checks for the g-mvcc teaching lab."""
from __future__ import annotations

import json
import os
import sys

from app import HOLD_S, run_all_experiments

HERE = os.path.dirname(os.path.abspath(__file__))


MYSQL_MULTI_VERSIONING = (
    "https://dev.mysql.com/doc/refman/8.4/en/innodb-multi-versioning.html"
)
MYSQL_CONSISTENT_READ = (
    "https://dev.mysql.com/doc/refman/8.4/en/innodb-consistent-read.html"
)
MYSQL_LOCKING_READS = (
    "https://dev.mysql.com/doc/refman/8.4/en/innodb-locking-reads.html"
)
MYSQL_PURGE = (
    "https://dev.mysql.com/doc/refman/8.4/en/innodb-purge-configuration.html"
)


def main() -> int:
    data = run_all_experiments()
    data.update(
        {
            "python": sys.version.split()[0],
            "mysql_doc": MYSQL_MULTI_VERSIONING,
            "mysql_doc_checked": "2026-11-11",
            "mysql_doc_edition": "MySQL 8.4",
            "consistent_read_doc": MYSQL_CONSISTENT_READ,
            "locking_reads_doc": MYSQL_LOCKING_READS,
            "purge_doc": MYSQL_PURGE,
        }
    )

    _assert_snapshot(data["snapshot_visibility"])
    _assert_consistent_vs_locking(data["consistent_vs_locking"])
    _assert_purge(data["purge_long_tx"])
    _assert_naive_vs_safe(data["naive_vs_safe"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

    vis = data["snapshot_visibility"]
    cvl = data["consistent_vs_locking"]
    pur = data["purge_long_tx"]
    nvs = data["naive_vs_safe"]
    snap_w = cvl["snapshot_read_does_not_block_update"]["wait_s"]
    lock_w = cvl["locking_read_blocks_update"]["wait_s"]
    dash_lock_w = nvs["locking_dashboard_blocks_writer"]["wait_s"]
    dash_snap_w = nvs["snapshot_dashboard_does_not_block"]["wait_s"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"rr_a=({vis['rr']['a_first']['status']},{vis['rr']['a_first']['views']})"
        f"->({vis['rr']['a_second']['status']},{vis['rr']['a_second']['views']}) "
        f"rr_c=({vis['rr']['c_sees']['status']},{vis['rr']['c_sees']['views']}) "
        f"rc_a=({vis['rc']['a_first']['status']},{vis['rc']['a_first']['views']})"
        f"->({vis['rc']['a_second']['status']},{vis['rc']['a_second']['views']}) "
        f"current=({cvl['a_current_after_b']['status']},{cvl['a_current_after_b']['views']}) "
        f"snap_wait_s={snap_w} lock_wait_s={lock_w} hold_s={HOLD_S} "
        f"purge_active={pur['versions_while_long_tx_active']} "
        f"purge_after={pur['versions_after_long_tx_end_and_purge']} "
        f"naive_views={nvs['naive_final']} safe_views={nvs['safe_final']} "
        f"expected_views={nvs['expected']} "
        f"dash_lock_wait_s={dash_lock_w} dash_snap_wait_s={dash_snap_w}"
    )
    return 0


def _assert_snapshot(vis: dict) -> None:
    assert vis["initial"] == {"status": "draft", "views": 100}, vis
    assert vis["after_b"] == {"status": "published", "views": 120}, vis

    rr = vis["rr"]
    assert rr["a_first"] == {"status": "draft", "views": 100}, rr
    # RR keeps the first consistent-read snapshot.
    assert rr["a_second"] == {"status": "draft", "views": 100}, rr
    assert rr["c_sees"] == {"status": "published", "views": 120}, rr

    rc = vis["rc"]
    assert rc["a_first"] == {"status": "draft", "views": 100}, rc
    # RC takes a fresh snapshot on the second consistent read.
    assert rc["a_second"] == {"status": "published", "views": 120}, rc
    assert rc["c_sees"] == {"status": "published", "views": 120}, rc


def _assert_consistent_vs_locking(cvl: dict) -> None:
    assert cvl["a_snapshot_before_b"] == {"status": "draft", "views": 100}, cvl
    assert cvl["a_snapshot_after_b"] == {"status": "draft", "views": 100}, cvl
    # Current / FOR UPDATE read sees the latest committed version.
    assert cvl["a_current_after_b"] == {"status": "published", "views": 120}, cvl

    snap = cvl["snapshot_read_does_not_block_update"]
    lock = cvl["locking_read_blocks_update"]
    assert snap["hold_s"] == HOLD_S and lock["hold_s"] == HOLD_S, (snap, lock)
    assert snap["errors"] == [] and lock["errors"] == [], (snap, lock)
    # Snapshot read sets no row lock: B's UPDATE returns almost immediately
    # even though A is still holding its snapshot for 0.2s.
    assert snap["wait_s"] < 0.05, snap
    assert snap["blocked"] is False, snap
    # Locking read holds the row: B waits for the 0.2s hold.
    assert lock["wait_s"] >= 0.15, lock
    assert lock["blocked"] is True, lock


def _assert_purge(pur: dict) -> None:
    assert pur["updates"] == 50, pur
    assert pur["versions_at_start"] == 1, pur
    assert pur["long_tx_pinned"] == {"status": "draft", "views": 100}, pur
    assert pur["long_tx_still_sees_after_updates"] == {
        "status": "draft",
        "views": 100,
    }, pur
    # 1 genesis + 50 committed updates = 51 versions, all kept while the
    # long snapshot is alive (even if purge is invoked).
    assert pur["versions_while_long_tx_active_before_purge"] == 51, pur
    assert pur["versions_while_long_tx_active"] == 51, pur
    assert pur["purge_while_active"]["purged"] == 0, pur
    assert pur["purge_while_active"]["remaining"] == 51, pur
    # After the long transaction ends, purge keeps only the current version.
    assert pur["versions_after_long_tx_end_and_purge"] == 1, pur
    assert pur["purge_after_end"]["purged"] == 50, pur
    assert pur["purge_after_end"]["remaining"] == 1, pur
    assert pur["latest_after_purge"] == {"status": "published", "views": 150}, pur


def _assert_naive_vs_safe(nvs: dict) -> None:
    assert nvs["initial_views"] == 100, nvs
    assert nvs["concurrent_increments"] == 19, nvs
    assert nvs["own_increment"] == 1, nvs
    assert nvs["expected"] == 120, nvs
    # naive writes snapshot 100 + 1 back, losing the 19 concurrent increments.
    assert nvs["naive_snapshot_views"] == 100, nvs
    assert nvs["views_after_concurrent"] == 119, nvs
    assert nvs["naive_wrote_back"] == 101, nvs
    assert nvs["naive_final"] == 101, nvs
    # safe does views = views + 1 on the latest committed version.
    assert nvs["safe_final"] == 120, nvs
    assert nvs["safe_wrote_from_latest"] is True, nvs

    locked = nvs["locking_dashboard_blocks_writer"]
    snap = nvs["snapshot_dashboard_does_not_block"]
    assert locked["hold_s"] == HOLD_S and snap["hold_s"] == HOLD_S, (locked, snap)
    assert locked["errors"] == [] and snap["errors"] == [], (locked, snap)
    assert locked["wait_s"] >= 0.15 and locked["blocked"] is True, locked
    assert snap["wait_s"] < 0.05 and snap["blocked"] is False, snap


if __name__ == "__main__":
    raise SystemExit(main())
