#!/usr/bin/env python3
"""Teaching MVCC engine for Backend Atlas lesson 100 (g-mvcc).

This is a single-process, in-memory teaching model. It is NOT InnoDB,
PostgreSQL, or the SQLite kernel.

Visibility and locking follow the *documented* MySQL 8.4 InnoDB
behaviour as checked on 2026-11-11:

- https://dev.mysql.com/doc/refman/8.4/en/innodb-multi-versioning.html
- https://dev.mysql.com/doc/refman/8.4/en/innodb-consistent-read.html
- https://dev.mysql.com/doc/refman/8.4/en/innodb-locking-reads.html
- https://dev.mysql.com/doc/refman/8.4/en/innodb-purge-configuration.html

The official consistent-read page describes a snapshot as a timepoint:
a query sees changes committed before that point, and no later or
uncommitted changes (except earlier statements of the same transaction).
REPEATABLE READ (InnoDB default): all consistent reads in a transaction
use the snapshot established by the first such read.
READ COMMITTED: each consistent read sets and reads its own fresh snapshot.
A consistent read sets no locks. A locking read (SELECT FOR UPDATE /
FOR SHARE) and UPDATE/DELETE read the latest committed version and take
locks; they wait if the row is held by an uncommitted transaction.

The teaching model approximates that timepoint with a monotonically
increasing commit timestamp. InnoDB's source-level ReadView (active
transaction ids and related fields) is not spelled out on the 8.4 pages
cited above, so this engine does not invent those fields.

Old versions stay on a per-row chain (a stand-in for update undo).
purge() drops versions no active snapshot can still need. A long-lived
snapshot therefore blocks cleanup of the chain back to the version it
must reconstruct.

SQLite is deliberately not used here: its isolation / WAL snapshot
semantics are not InnoDB's, and must not be presented as such.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


ISOLATION_LEVELS = ("READ COMMITTED", "REPEATABLE READ")


class LockWaitTimeout(Exception):
    """Raised when a locking read / UPDATE waits longer than the timeout."""


class TxStateError(Exception):
    """Raised when an operation is issued on a non-active transaction."""


@dataclass
class RowVersion:
    """One version on a row's chain.

    begin_ts is the commit timestamp at which this version became
    visible; None means the creating transaction has not committed yet.
    end_ts is the commit timestamp at which a later version hid it;
    None means it is still current (or not yet hidden).
    prev points at the immediately older version (teaching stand-in
    for a roll pointer into undo).
    """

    trx_id: int
    begin_ts: Optional[int]
    end_ts: Optional[int]
    data: dict
    prev: Optional["RowVersion"] = None
    deleted: bool = False


@dataclass
class ReadView:
    """Teaching snapshot: a commit-timestamp timepoint.

    view_ts is the last commit timestamp observed when the snapshot
    was taken. The creator transaction always sees its own writes.
    """

    view_ts: int
    creator_txid: int


@dataclass
class Row:
    head: RowVersion
    exclusive: Optional[int] = None  # txid holding FOR UPDATE / UPDATE
    shared: set = field(default_factory=set)  # txids holding FOR SHARE


@dataclass
class Tx:
    txid: int
    isolation: str
    status: str = "active"
    read_view: Optional[ReadView] = None
    # (table, pk) -> uncommitted RowVersion created by this tx
    writes: dict = field(default_factory=dict)
    locked: set = field(default_factory=set)  # (table, pk)


class MVCCEngine:
    """In-memory multi-version store with RR/RC snapshots, locks, and purge."""

    def __init__(self) -> None:
        self._tables: dict[str, dict[Any, Row]] = {}
        self._next_txid = 1
        self._ts = 0  # last commit timestamp; genesis rows use 0
        self._active: dict[int, Tx] = {}
        self._lock = threading.RLock()
        self._cv = threading.Condition(self._lock)

    # ----- schema / seed -----

    def create_table(self, name: str) -> None:
        with self._lock:
            self._tables.setdefault(name, {})

    def seed(self, table: str, pk: Any, data: dict) -> None:
        """Insert a committed genesis row (begin_ts=0)."""
        with self._lock:
            self.create_table(table)
            row_data = {**data, "id": data.get("id", pk)}
            self._tables[table][pk] = Row(
                head=RowVersion(trx_id=0, begin_ts=0, end_ts=None, data=row_data)
            )

    def begin(self, isolation: str) -> Tx:
        iso = isolation.upper()
        if iso not in ISOLATION_LEVELS:
            raise ValueError(f"unknown isolation: {isolation}")
        with self._lock:
            tx = Tx(txid=self._next_txid, isolation=iso)
            self._next_txid += 1
            self._active[tx.txid] = tx
            return tx

    # ----- consistent (snapshot) reads: no row locks -----

    def consistent_read(self, tx: Tx, table: str, pk: Any) -> Optional[dict]:
        """Snapshot read. Establishes or reuses a ReadView; never takes a row lock."""
        with self._lock:
            self._check_active(tx)
            view = self._snapshot_for_consistent_read(tx)
            row = self._get_row(table, pk)
            if row is None:
                return self._own_insert(tx, table, pk)
            ver = self._visible_version(row.head, view, tx.txid)
            if ver is None or ver.deleted:
                return None
            return dict(ver.data)

    def _snapshot_for_consistent_read(self, tx: Tx) -> ReadView:
        if tx.isolation == "REPEATABLE READ":
            if tx.read_view is None:
                tx.read_view = ReadView(view_ts=self._ts, creator_txid=tx.txid)
            return tx.read_view
        # READ COMMITTED: a fresh snapshot for every consistent read
        tx.read_view = ReadView(view_ts=self._ts, creator_txid=tx.txid)
        return tx.read_view

    # ----- locking (current) reads and writes -----

    def locking_read(
        self,
        tx: Tx,
        table: str,
        pk: Any,
        mode: str = "FOR UPDATE",
        timeout_s: float = 2.0,
    ) -> Optional[dict]:
        """Current read: latest committed version, plus a row lock.

        mode is 'FOR UPDATE' (exclusive) or 'FOR SHARE' (shared).
        Waits if the row is held by another uncommitted transaction.
        """
        exclusive = mode.upper() != "FOR SHARE"
        with self._cv:
            self._check_active(tx)
            self._acquire_row_lock(tx, table, pk, exclusive=exclusive, timeout_s=timeout_s)
            row = self._get_row(table, pk)
            if row is None:
                return self._own_insert(tx, table, pk)
            ver = self._latest_for_tx(row.head, tx.txid)
            if ver is None or ver.deleted:
                return None
            return dict(ver.data)

    def update(
        self,
        tx: Tx,
        table: str,
        pk: Any,
        data: dict,
        timeout_s: float = 2.0,
    ) -> dict:
        """Current-read the latest committed row, lock it, write an absolute version."""
        with self._cv:
            self._check_active(tx)
            self._acquire_row_lock(tx, table, pk, exclusive=True, timeout_s=timeout_s)
            return self._install_write(tx, table, pk, dict(data), deleted=False)

    def update_current(
        self,
        tx: Tx,
        table: str,
        pk: Any,
        mutate: Callable[[dict], dict],
        timeout_s: float = 2.0,
    ) -> dict:
        """Lock, read the latest committed version, apply mutate(), write a new version.

        This is the teaching stand-in for ``UPDATE ... SET views = views + 1``.
        """
        with self._cv:
            self._check_active(tx)
            self._acquire_row_lock(tx, table, pk, exclusive=True, timeout_s=timeout_s)
            row = self._get_row(table, pk)
            if row is None:
                raise KeyError(f"missing row {table}.{pk}")
            ver = self._latest_for_tx(row.head, tx.txid)
            if ver is None or ver.deleted:
                raise KeyError(f"row {table}.{pk} is not visible for update")
            new_data = mutate(dict(ver.data))
            return self._install_write(tx, table, pk, new_data, deleted=False)

    def delete(self, tx: Tx, table: str, pk: Any, timeout_s: float = 2.0) -> None:
        with self._cv:
            self._check_active(tx)
            self._acquire_row_lock(tx, table, pk, exclusive=True, timeout_s=timeout_s)
            row = self._get_row(table, pk)
            if row is None:
                return
            ver = self._latest_for_tx(row.head, tx.txid)
            if ver is None or ver.deleted:
                return
            self._install_write(tx, table, pk, dict(ver.data), deleted=True)

    # ----- commit / rollback -----

    def commit(self, tx: Tx) -> int:
        with self._cv:
            self._check_active(tx)
            self._ts += 1
            cts = self._ts
            for (table, pk), ver in tx.writes.items():
                ver.begin_ts = cts
                # Hide the previous committed version at this timestamp.
                older = ver.prev
                while older is not None and older.begin_ts is None:
                    older = older.prev
                if older is not None and older.end_ts is None:
                    older.end_ts = cts
            self._release_locks(tx)
            tx.status = "committed"
            self._active.pop(tx.txid, None)
            tx.writes.clear()
            self._cv.notify_all()
            return cts

    def rollback(self, tx: Tx) -> None:
        with self._cv:
            self._check_active(tx)
            for (table, pk), ver in tx.writes.items():
                row = self._get_row(table, pk)
                if row is None:
                    continue
                # Unlink this tx's uncommitted version(s) from the chain.
                if row.head is ver:
                    row.head = ver.prev  # type: ignore[assignment]
                    if row.head is None:
                        del self._tables[table][pk]
                else:
                    cur = row.head
                    while cur is not None and cur.prev is not ver:
                        cur = cur.prev
                    if cur is not None:
                        cur.prev = ver.prev
            self._release_locks(tx)
            tx.status = "aborted"
            self._active.pop(tx.txid, None)
            tx.writes.clear()
            self._cv.notify_all()

    # ----- version chain / purge -----

    def version_count(self, table: str, pk: Any) -> int:
        with self._lock:
            row = self._get_row(table, pk)
            if row is None:
                return 0
            n = 0
            v: Optional[RowVersion] = row.head
            while v is not None:
                n += 1
                v = v.prev
            return n

    def chain_snapshot(self, table: str, pk: Any) -> list[dict]:
        """Return a debug view of the version chain, newest first."""
        with self._lock:
            row = self._get_row(table, pk)
            out: list[dict] = []
            if row is None:
                return out
            v: Optional[RowVersion] = row.head
            while v is not None:
                out.append(
                    {
                        "trx_id": v.trx_id,
                        "begin_ts": v.begin_ts,
                        "end_ts": v.end_ts,
                        "deleted": v.deleted,
                        "data": dict(v.data),
                    }
                )
                v = v.prev
            return out

    def active_snapshot_min_ts(self) -> Optional[int]:
        with self._lock:
            return self._min_needed_ts()

    def purge(self) -> dict:
        """Drop versions no active snapshot can still need.

        If any transaction still holds a ReadView, the chain must be kept
        from the current version back through the version visible at the
        oldest such snapshot (the teaching stand-in for 'update undo
        cannot be discarded while a snapshot might reconstruct it').
        When no snapshot remains, only the current committed version is
        kept.
        """
        with self._lock:
            min_ts = self._min_needed_ts()
            purged = 0
            remaining = 0
            for table in self._tables.values():
                for row in table.values():
                    dropped = self._purge_row(row, min_ts)
                    purged += dropped
                    remaining += self._count_chain(row.head)
            return {
                "purged": purged,
                "remaining": remaining,
                "min_active_snapshot_ts": min_ts,
            }

    # ----- internals -----

    def _check_active(self, tx: Tx) -> None:
        if tx.status != "active" or self._active.get(tx.txid) is not tx:
            raise TxStateError(f"transaction {tx.txid} is {tx.status}")

    def _get_row(self, table: str, pk: Any) -> Optional[Row]:
        tab = self._tables.get(table)
        if tab is None:
            return None
        return tab.get(pk)

    def _own_insert(self, tx: Tx, table: str, pk: Any) -> Optional[dict]:
        ver = tx.writes.get((table, pk))
        if ver is None or ver.deleted:
            return None
        return dict(ver.data)

    def _visible_version(
        self, head: RowVersion, view: ReadView, txid: int
    ) -> Optional[RowVersion]:
        v: Optional[RowVersion] = head
        while v is not None:
            if v.trx_id == txid and v.begin_ts is None:
                return v
            if v.begin_ts is not None and v.begin_ts <= view.view_ts:
                if v.end_ts is None or v.end_ts > view.view_ts:
                    return v
            v = v.prev
        return None

    def _latest_for_tx(self, head: RowVersion, txid: int) -> Optional[RowVersion]:
        v: Optional[RowVersion] = head
        while v is not None:
            if v.trx_id == txid and v.begin_ts is None:
                return v
            if v.begin_ts is not None:
                return v
            v = v.prev  # skip another tx's uncommitted version
        return None

    def _install_write(
        self, tx: Tx, table: str, pk: Any, data: dict, deleted: bool
    ) -> dict:
        payload = {**data, "id": data.get("id", pk)}
        existing = tx.writes.get((table, pk))
        if existing is not None and existing.begin_ts is None:
            existing.data = payload
            existing.deleted = deleted
            return dict(payload)
        row = self._get_row(table, pk)
        prev = row.head if row is not None else None
        ver = RowVersion(
            trx_id=tx.txid,
            begin_ts=None,
            end_ts=None,
            data=payload,
            prev=prev,
            deleted=deleted,
        )
        if row is None:
            self.create_table(table)
            self._tables[table][pk] = Row(head=ver)
        else:
            row.head = ver
        tx.writes[(table, pk)] = ver
        return dict(payload)

    def _row_blocked(self, row: Optional[Row], txid: int, exclusive: bool) -> bool:
        if row is None:
            return False
        if row.exclusive is not None and row.exclusive != txid:
            return True
        if exclusive and any(s != txid for s in row.shared):
            return True
        return False

    def _acquire_row_lock(
        self, tx: Tx, table: str, pk: Any, exclusive: bool, timeout_s: float
    ) -> None:
        # Caller holds self._cv.
        deadline = time.monotonic() + timeout_s
        key = (table, pk)
        while True:
            row = self._get_row(table, pk)
            if not self._row_blocked(row, tx.txid, exclusive):
                if row is None:
                    # Lock reservation on a row that will be inserted; create a
                    # placeholder only if we need to record the holder. For
                    # updates of existing seeded rows this branch is unused.
                    tx.locked.add(key)
                    return
                if exclusive:
                    row.exclusive = tx.txid
                    row.shared.discard(tx.txid)
                else:
                    if row.exclusive == tx.txid:
                        pass  # already hold exclusive; keep it
                    else:
                        row.shared.add(tx.txid)
                tx.locked.add(key)
                return
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise LockWaitTimeout(
                    f"timed out waiting for lock on {table}.{pk}"
                )
            self._cv.wait(timeout=remaining)

    def _release_locks(self, tx: Tx) -> None:
        for table, pk in list(tx.locked):
            row = self._get_row(table, pk)
            if row is None:
                continue
            if row.exclusive == tx.txid:
                row.exclusive = None
            row.shared.discard(tx.txid)
        tx.locked.clear()

    def _min_needed_ts(self) -> Optional[int]:
        snaps = [
            tx.read_view.view_ts
            for tx in self._active.values()
            if tx.read_view is not None
        ]
        return min(snaps) if snaps else None

    @staticmethod
    def _count_chain(head: Optional[RowVersion]) -> int:
        n = 0
        v = head
        while v is not None:
            n += 1
            v = v.prev
        return n

    @staticmethod
    def _purge_row(row: Row, min_ts: Optional[int]) -> int:
        oldest_needed: Optional[RowVersion] = None
        cur: Optional[RowVersion] = row.head
        while cur is not None:
            if cur.begin_ts is None:
                needed = True
            elif min_ts is None:
                needed = cur.end_ts is None
            else:
                # Keep anything not already hidden at min_ts, i.e. the
                # version visible at the oldest snapshot and every newer
                # version on the undo chain used to reach it.
                needed = cur.end_ts is None or cur.end_ts > min_ts
            if not needed:
                break
            oldest_needed = cur
            cur = cur.prev
        if oldest_needed is None:
            return 0
        dropped = 0
        p = oldest_needed.prev
        oldest_needed.prev = None
        while p is not None:
            dropped += 1
            p = p.prev
        return dropped
