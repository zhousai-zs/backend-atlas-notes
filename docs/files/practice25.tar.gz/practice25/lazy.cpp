#include <deque>
#include <algorithm>
template <typename T> struct Q {           // 无约束版本
    std::deque<T> q;
    void push(T v) { q.push_back(v); }
    T max() const { return *std::max_element(q.begin(), q.end()); }
};
struct Msg { int id; };
int main() {
    Q<Msg> q; q.push({1});                 // 能编译：max() 从未实例化
#ifdef CALL_MAX
    q.max();
#endif
}
