#include "bounded_queue.h"
#include <cassert>
#include <iostream>
#include <string>
#include <type_traits>

// 函数模板 + 显式特化
template <typename T> std::string kind(const T&) { return "generic"; }
template <> std::string kind<int>(const int&) { return "int-specialization"; }
// 普通重载（非模板）优先于模板
std::string kind(const char*) { return "overload-cstr"; }

// SFINAE 版本：只对整数类型启用
template <typename T, std::enable_if_t<std::is_integral_v<T>, int> = 0>
T twice(T x) { return x * 2; }

// 依赖名：T::value_type 必须写 typename
template <typename C>
typename C::value_type first_or(const C& c, typename C::value_type d) {
    return c.empty() ? d : *c.begin();
}

struct Msg { int id; };  // 没有 operator<

int main() {
    BoundedQueue<int> q(3);
    assert(q.push(5) && q.push(9) && q.push(1));
    assert(!q.push(7));                 // 满了
    assert(q.size() == 3 && *q.max() == 9);
    assert(*q.pop() == 5 && q.size() == 2);

    BoundedQueue<std::string> s(2);
    s.push("openid_b"); s.push("openid_a");
    assert(*s.max() == "openid_b");

    BoundedQueue<int> e(1);
    assert(!e.pop() && !e.max());       // 空队列

    static_assert(Comparable<int> && !Comparable<Msg>);
    assert(kind(1.5) == "generic");
    assert(kind(42) == "int-specialization");
    assert(kind("x") == "overload-cstr");
    assert(twice(21) == 42);
    std::deque<int> dq{3,4};
    assert(first_or(dq, -1) == 3);
    std::cout << "ALL_TESTS_PASSED\n";
}
