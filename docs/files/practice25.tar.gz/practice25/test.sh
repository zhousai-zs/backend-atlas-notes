#!/bin/bash
set -e
cd "$(dirname "$0")"
g++ -std=c++20 -Wall -Wextra -fsanitize=address,undefined -g main.cpp -o main && ./main
if g++ -std=c++20 -c bad.cpp -o /dev/null 2> bad.err; then echo "FAIL: bad.cpp 不该编译通过"; exit 1; fi
grep -q "Comparable" bad.err && echo "BAD_TYPE_REJECTED_WITH_CONCEPT_MESSAGE"
grep -E "constraints not satisfied|required for the satisfaction" bad.err | head -3
g++ -std=c++20 lazy.cpp -o /dev/null && echo "UNCONSTRAINED_COMPILES_UNTIL_MAX_USED"
if g++ -std=c++20 -DCALL_MAX lazy.cpp -o /dev/null 2>/dev/null; then echo FAIL; exit 1; else echo "CALL_MAX_FAILS_DEEP_IN_STL"; fi
