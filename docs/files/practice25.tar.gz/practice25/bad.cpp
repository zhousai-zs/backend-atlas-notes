#include "bounded_queue.h"
struct Msg { int id; };
int main() { BoundedQueue<Msg> q(4); }
