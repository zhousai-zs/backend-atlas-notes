#pragma once
#include <concepts>
#include <cstddef>
#include <deque>
#include <optional>
#include <algorithm>

// 约束：元素必须能用 < 比较（用于 max()），并且可移动
template <typename T>
concept Comparable = requires(const T& a, const T& b) {
    { a < b } -> std::convertible_to<bool>;
};

template <typename T>
    requires Comparable<T> && std::movable<T>
class BoundedQueue {
public:
    explicit BoundedQueue(std::size_t cap) : cap_(cap) {}
    bool push(T v) {                       // 满了返回 false，不阻塞
        if (q_.size() >= cap_) return false;
        q_.push_back(std::move(v));
        return true;
    }
    std::optional<T> pop() {
        if (q_.empty()) return std::nullopt;
        T v = std::move(q_.front());
        q_.pop_front();
        return v;
    }
    std::optional<T> max() const {         // 只有这里用到 <
        if (q_.empty()) return std::nullopt;
        return *std::max_element(q_.begin(), q_.end());
    }
    std::size_t size() const { return q_.size(); }
    std::size_t capacity() const { return cap_; }
private:
    std::size_t cap_;
    std::deque<T> q_;
};
