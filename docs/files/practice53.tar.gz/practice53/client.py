#!/usr/bin/env python3
"""select 聊天客户端（第53课）：连接后可发消息、收广播。"""
from __future__ import annotations

import argparse
import select
import socket
import sys
import time


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18053)
    ap.add_argument("--send", default="", help="发送一条消息后继续读/或退出")
    ap.add_argument("--expect", default="", help="期望在超时内收到包含此子串的广播")
    ap.add_argument("--timeout", type=float, default=5.0)
    ap.add_argument("--hold", type=float, default=0.0, help="连接保持秒数（用于占住高编号 fd）")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(args.timeout)
    try:
        s.connect((args.host, args.port))
        fd = s.fileno()
        if not args.quiet:
            print(f"CONNECTED fd={fd} to {args.host}:{args.port}", flush=True)

        if args.send:
            payload = args.send.encode()
            if not payload.endswith(b"\n"):
                payload += b"\n"
            s.sendall(payload)
            if not args.quiet:
                print(f"SENT bytes={len(payload)}", flush=True)

        deadline = time.monotonic() + args.timeout
        got = b""
        hold_until = time.monotonic() + args.hold

        while time.monotonic() < deadline:
            # hold 模式：占住连接直到 hold 结束
            remaining_hold = hold_until - time.monotonic()
            if args.hold > 0 and remaining_hold > 0 and not args.expect:
                # 只是占坑，短暂 select 防止忙等
                select.select([s], [], [], min(0.2, remaining_hold))
                # 若有数据就读掉，避免撑爆
                r, _, _ = select.select([s], [], [], 0)
                if r:
                    chunk = s.recv(4096)
                    if not chunk:
                        print("PEER_CLOSED during hold", flush=True)
                        sys.exit(1)
                    got += chunk
                if time.monotonic() >= hold_until and not args.expect:
                    print(f"HOLD_DONE fd={fd}", flush=True)
                    sys.exit(0)
                continue

            wait = min(0.5, max(0.0, deadline - time.monotonic()))
            r, _, _ = select.select([s], [], [], wait)
            if not r:
                if args.expect:
                    continue
                if args.hold > 0 and time.monotonic() >= hold_until:
                    print(f"HOLD_DONE fd={fd}", flush=True)
                    sys.exit(0)
                break
            chunk = s.recv(4096)
            if not chunk:
                if not args.quiet:
                    print("PEER_CLOSED", flush=True)
                break
            got += chunk
            if args.expect and args.expect.encode() in got:
                print(f"GOT_EXPECT ok fd={fd} text={got!r}", flush=True)
                sys.exit(0)

        if args.expect:
            print(f"RESULT fail missing expect={args.expect!r} got={got!r}", file=sys.stderr)
            sys.exit(1)

        if args.send and not args.hold:
            # 发送方默认不期待自己的广播回环（服务不回环）
            print(f"SEND_DONE fd={fd} got_extra={got!r}", flush=True)
            sys.exit(0)

        print(f"RESULT ok fd={fd} got={got!r}", flush=True)
    except Exception as e:
        print(f"RESULT fail {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        try:
            s.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
