#!/usr/bin/env bash
# Backend Atlas 第53课：select 聊天服务、集合更新、max_fd 下降
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18053
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2
rm -f /tmp/sel53-srv.log /tmp/sel53-a.out /tmp/sel53-b.out /tmp/sel53-c.out

python3 server.py "$PORT" > /tmp/sel53-srv.log 2>&1 &
SRV=$!
cleanup(){
  kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
  fuser -k ${PORT}/tcp 2>/dev/null || true
  # 清掉可能残留的客户端
  pkill -f "practice53/client.py" 2>/dev/null || true
}
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/sel53-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

SSOUT=$(ss -ltnp "sport = :$PORT" 2>/dev/null || ss -ltnp | grep ":$PORT" || true)
echo "$SSOUT" | head -3
echo "$SSOUT" | grep -q ":$PORT" && ok "ss 可见 TCP 监听 :$PORT" || bad "ss 未见 TCP :$PORT"

# --- 1) 两客户端互相广播 ---
python3 client.py --port "$PORT" --expect "from-A" --timeout 8 > /tmp/sel53-b.out 2>&1 &
B=$!
sleep 0.25
python3 client.py --port "$PORT" --expect "from-B" --timeout 8 > /tmp/sel53-a.out 2>&1 &
A=$!
sleep 0.25
# A 发 from-A，B 应收；B 发 from-B，A 应收
python3 client.py --port "$PORT" --send "from-helper-noop" --timeout 2 >/dev/null 2>&1 || true
# 用第三个短连接不够；直接让已有连接发：再起发送专用客户端不行——服务不回环给自己
# 所以：再起 sender 发 from-A，B 等待；再起 sender 发 from-B，A 等待
# 更干净：A/B 是接收端，用独立 sender
# 重启接收端方案：上面 A/B 已在 expect。用 sender：
python3 - "$PORT" <<'PY' > /tmp/sel53-send1.out 2>&1 &
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
time.sleep(0.1)
s.sendall(b"from-A\n")
time.sleep(0.5)
s.close()
PY
SEND1=$!
wait $B
BRC=$?
cat /tmp/sel53-b.out
if [ "$BRC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/sel53-b.out && grep -q "from-A" /tmp/sel53-b.out; then
  ok "客户端 B 收到 A 侧广播 from-A"
else
  bad "客户端 B 未收到 from-A rc=$BRC"
fi

python3 - "$PORT" <<'PY' > /tmp/sel53-send2.out 2>&1 &
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
time.sleep(0.1)
s.sendall(b"from-B\n")
time.sleep(0.5)
s.close()
PY
wait $A
ARC=$?
cat /tmp/sel53-a.out
if [ "$ARC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/sel53-a.out && grep -q "from-B" /tmp/sel53-a.out; then
  ok "客户端 A 收到 B 侧广播 from-B"
else
  bad "客户端 A 未收到 from-B rc=$ARC"
fi
wait $SEND1 2>/dev/null || true

# --- 2) 关闭一个客户端后服务继续，剩余客户端仍可用 ---
# 清日志游标：记录当前行数
LINES_BEFORE=$(wc -l < /tmp/sel53-srv.log)

python3 client.py --port "$PORT" --hold 30 --timeout 35 > /tmp/sel53-hold1.out 2>&1 &
H1=$!
python3 client.py --port "$PORT" --hold 30 --timeout 35 > /tmp/sel53-hold2.out 2>&1 &
H2=$!
sleep 0.4
# 确认两个 ACCEPT
sleep 0.2
grep -c "ACCEPT" /tmp/sel53-srv.log >/dev/null
ok "已建立 hold 连接（准备关闭其一）"

# 杀掉 H1，服务应打印 CLOSE + STATE after_close，且 max_fd 更新
kill $H1 2>/dev/null || true
wait $H1 2>/dev/null || true
sleep 0.5

if grep -q "CLOSE fd=" /tmp/sel53-srv.log; then
  ok "关闭连接后服务从集合摘掉（CLOSE 日志）"
else
  bad "未见 CLOSE 日志"
fi

# 剩余 H2 仍应能收广播
python3 client.py --port "$PORT" --expect "still-alive" --timeout 6 > /tmp/sel53-remain.out 2>&1 &
REM=$!
sleep 0.3
python3 - "$PORT" <<'PY'
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
s.sendall(b"still-alive\n")
time.sleep(0.4)
s.close()
PY
wait $REM
RRC=$?
cat /tmp/sel53-remain.out
if [ "$RRC" -eq 0 ] && grep -q "still-alive" /tmp/sel53-remain.out; then
  ok "关闭一个客户端后剩余客户端仍可收广播"
else
  bad "关闭后广播失败 rc=$RRC"
fi
kill $H2 2>/dev/null || true
wait $H2 2>/dev/null || true
sleep 0.3

# --- 3) max_fd 在关闭高编号 fd 后下降 ---
# 策略：顺序连接 3 个客户端，记录各自 fd；关掉最大 fd 的那个；断言日志 max_fd 下降
python3 - "$PORT" <<'PY' > /tmp/sel53-maxfd.out 2>&1
import socket, time, sys, os, select

PORT = int(sys.argv[1])
socks = []
fds = []
for i in range(3):
    s = socket.socket()
    s.connect(("127.0.0.1", PORT))
    socks.append(s)
    fds.append(s.fileno())
    time.sleep(0.05)
print(f"CLIENT_FDS {fds}")
# 关掉最大 fd
mx = max(fds)
idx = fds.index(mx)
print(f"CLOSING_MAX_FD {mx}")
socks[idx].close()
time.sleep(0.6)
# 再关其余，避免泄漏
for i, s in enumerate(socks):
    if i == idx:
        continue
    try:
        s.close()
    except OSError:
        pass
time.sleep(0.3)
print("MAXFD_PROBE_DONE")
PY

cat /tmp/sel53-maxfd.out
# 从服务日志提取 after_close 的 max_fd 序列
echo "---- max_fd related log ----"
grep -E "STATE after_|ACCEPT fd=|CLOSE fd=" /tmp/sel53-srv.log | tail -40

# 解析：找 CLOSING 对应的 CLOSE 之后的 max_fd，应小于关闭前
python3 - <<'PY'
import re
log = open("/tmp/sel53-srv.log").read()
# 取所有 STATE 行的 max_fd
states = [(m.group(1), int(m.group(2))) for m in re.finditer(
    r"STATE (\w+) .*max_fd=(\d+)", log)]
accepts = [int(x) for x in re.findall(r"ACCEPT fd=(\d+)", log)]
closes = [int(x) for x in re.findall(r"CLOSE fd=(\d+)", log)]
print(f"accepts_tail={accepts[-6:] if accepts else []}")
print(f"closes_tail={closes[-6:] if closes else []}")
print(f"states_tail={states[-8:] if states else []}")

# 找到某次 after_close：关闭的 fd 若曾是当时最大，则新 max_fd 应 < 该 fd
ok_drop = False
# 简单启发式：存在 after_close 的 max_fd，且整段日志里出现过更大的 max_fd
maxfds = [m[1] for m in states]
if len(maxfds) >= 2:
    peak = max(maxfds)
    # 最后一个 after_close（或任意 after_close）max_fd 小于 peak
    after_closes = [v for k, v in states if "close" in k]
    if after_closes and min(after_closes) < peak:
        ok_drop = True
    # 更强：peak 之后出现更小的 max_fd
    peak_i = maxfds.index(peak)
    if any(v < peak for v in maxfds[peak_i+1:]):
        ok_drop = True

# 额外：客户端报告的 CLOSING_MAX_FD 应出现在 CLOSE 日志，且随后 max_fd < that
probe = open("/tmp/sel53-maxfd.out").read()
m = re.search(r"CLOSING_MAX_FD (\d+)", probe)
if m:
    closed = int(m.group(1))
    # 找 CLOSE fd=closed 之后最近的 STATE after_close
    parts = log.split(f"CLOSE fd={closed}")
    if len(parts) >= 2:
        tail = parts[-1][:500]
        m2 = re.search(r"max_fd=(\d+)", tail)
        if m2 and int(m2.group(1)) < closed:
            ok_drop = True
            print(f"ASSERT max_fd dropped: closed={closed} new_max_fd={m2.group(1)}")

print("DROP_OK" if ok_drop else "DROP_FAIL")
raise SystemExit(0 if ok_drop else 1)
PY
MAXRC=$?
if [ "$MAXRC" -eq 0 ]; then
  ok "关闭高编号 fd 后 max_fd 下降"
else
  bad "max_fd 未观察到下降"
fi

# --- 4) 空闲超时心跳（timeval）---
# 短暂无人可读时应出现 IDLE heartbeat
sleep 2.5
if grep -q "IDLE heartbeat" /tmp/sel53-srv.log; then
  ok "超时路径打印 IDLE heartbeat（演示 timeval）"
else
  # 可能一直有连接；再等一会
  sleep 2.5
  if grep -q "IDLE heartbeat" /tmp/sel53-srv.log; then
    ok "超时路径打印 IDLE heartbeat（演示 timeval）"
  else
    bad "未见 IDLE heartbeat"
  fi
fi

# --- 5) 端口占用明确错误 ---
OUT=$(python3 server.py "$PORT" 2>&1) || RC=$?
RC=${RC:-0}
echo "second_bind rc=$RC out=$OUT"
echo "$OUT" | grep -qiE "EADDRINUSE|already in use|port .* in use" && ok "端口占用给出明确错误" || bad "端口占用错误不明确: $OUT"
[ "${RC}" -eq 2 ] && ok "端口占用退出码为 2" || bad "端口占用退出码异常 rc=$RC"

# --- 6) 服务仍存活 + 收尾广播 ---
if kill -0 $SRV 2>/dev/null; then
  ok "全部用例后服务进程仍存活"
  python3 client.py --port "$PORT" --expect "final-ping" --timeout 5 > /tmp/sel53-final-recv.out 2>&1 &
  FR=$!
  sleep 0.25
  python3 - "$PORT" <<'PY'
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
s.sendall(b"final-ping\n")
time.sleep(0.3)
s.close()
PY
  wait $FR
  cat /tmp/sel53-final-recv.out
  grep -q "final-ping" /tmp/sel53-final-recv.out && ok "收尾广播成功" || bad "收尾广播失败"
else
  bad "服务进程已退出"
  cat /tmp/sel53-srv.log
fi

echo "---- server log (tail) ----"
tail -50 /tmp/sel53-srv.log || true

if [ "$fail" -eq 0 ]; then
  echo "ALL_CHECKS_PASSED"
  exit 0
else
  echo "SOME_CHECKS_FAILED"
  exit 1
fi
