#!/usr/bin/env python3
"""select 聊天服务：同时监听 listen fd + 多 client，广播；关闭后更新集合与 max_fd（第53课 d-select）。"""
from __future__ import annotations

import errno
import select
import socket
import sys
import time

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18053
BACKLOG = 128
# Python select 底层仍受 FD_SETSIZE 约束（常见 1024）；教学用显式上限
FD_SETSIZE = getattr(select, "FD_SETSIZE", 1024)
IDLE_TIMEOUT = 2.0  # 秒：超时打印心跳，演示 timeval 语义


def fd_ok(fd: int) -> bool:
    """不对超出集合范围的 fd 做等价于 FD_SET 的操作。"""
    return 0 <= fd < FD_SETSIZE


def main() -> None:
    clients: dict[int, socket.socket] = {}
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((HOST, PORT))
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                print(
                    f"ERROR: port {HOST}:{PORT} already in use (EADDRINUSE)",
                    file=sys.stderr,
                    flush=True,
                )
                sys.exit(2)
            print(f"ERROR: bind failed: {e}", file=sys.stderr, flush=True)
            sys.exit(1)
        srv.listen(BACKLOG)
        srv.setblocking(False)
        listen_fd = srv.fileno()
        if not fd_ok(listen_fd):
            print(f"ERROR: listen fd {listen_fd} >= FD_SETSIZE={FD_SETSIZE}", file=sys.stderr)
            sys.exit(1)

        # clients: fd -> socket
        # 维护「当前关心的最大 fd」；关闭高编号 fd 后必须下降
        max_fd = listen_fd
        print(
            f"select chat listening on {HOST}:{PORT} "
            f"listen_fd={listen_fd} FD_SETSIZE={FD_SETSIZE} max_fd={max_fd}",
            flush=True,
        )

        last_idle_print = time.monotonic()
        while True:
            # --- 每次 select 前重建集合（select 返回后会改写传入的集合）---
            rlist = [srv]
            for fd, sock in list(clients.items()):
                if not fd_ok(fd):
                    # 防御：不应出现；若出现则摘掉，绝不放进 select
                    print(f"WARN: drop out-of-range fd={fd}", flush=True)
                    try:
                        sock.close()
                    except OSError:
                        pass
                    clients.pop(fd, None)
                    continue
                rlist.append(sock)

            # nfds 语义：内核扫描 [0, nfds)；Python 的 select.select 自动取 max+1
            # 我们显式维护并打印 max_fd，便于测试断言「关闭高编号后下降」
            tracked = [listen_fd] + list(clients.keys())
            max_fd = max(tracked) if tracked else listen_fd
            nfds = max_fd + 1

            try:
                readable, _w, _x = select.select(rlist, [], [], IDLE_TIMEOUT)
            except (ValueError, OSError) as e:
                # 常见：坏 fd / 超出 FD_SETSIZE
                print(f"select error: {e}; rebuilding set", flush=True)
                # 清理已关闭 fd
                dead = []
                for fd, sock in clients.items():
                    try:
                        sock.getpeername()
                    except OSError:
                        dead.append(fd)
                for fd in dead:
                    _close_client(clients, fd, "select-error-cleanup")
                tracked = [listen_fd] + list(clients.keys())
                max_fd = max(tracked) if tracked else listen_fd
                print(f"STATE after_cleanup clients={len(clients)} max_fd={max_fd} nfds={max_fd+1}", flush=True)
                continue

            now = time.monotonic()
            if not readable:
                # 超时：演示 timeval；打印空闲心跳
                if now - last_idle_print >= IDLE_TIMEOUT - 0.05:
                    print(
                        f"IDLE heartbeat clients={len(clients)} max_fd={max_fd} nfds={nfds}",
                        flush=True,
                    )
                    last_idle_print = now
                continue

            # 处理可读
            # 注意：必须先处理 listen，再处理 clients；关闭时立刻从 dict 摘掉
            if srv in readable:
                _accept_loop(srv, clients)
                tracked = [listen_fd] + list(clients.keys())
                max_fd = max(tracked) if tracked else listen_fd
                print(
                    f"STATE after_accept clients={len(clients)} max_fd={max_fd} nfds={max_fd+1}",
                    flush=True,
                )

            for fd, sock in list(clients.items()):
                if sock not in readable:
                    continue
                try:
                    data = sock.recv(4096)
                except OSError as e:
                    print(f"recv err fd={fd}: {e}", flush=True)
                    _close_client(clients, fd, "recv-error")
                    tracked = [listen_fd] + list(clients.keys())
                    max_fd = max(tracked) if tracked else listen_fd
                    print(
                        f"STATE after_close fd={fd} clients={len(clients)} "
                        f"max_fd={max_fd} nfds={max_fd+1}",
                        flush=True,
                    )
                    continue

                if not data:
                    # 对端关闭：从集合摘掉，并可能降低 max_fd
                    closed_fd = fd
                    _close_client(clients, fd, "peer-eof")
                    tracked = [listen_fd] + list(clients.keys())
                    max_fd = max(tracked) if tracked else listen_fd
                    print(
                        f"STATE after_close fd={closed_fd} clients={len(clients)} "
                        f"max_fd={max_fd} nfds={max_fd+1}",
                        flush=True,
                    )
                    continue

                # 广播：发给除发送者外的所有客户端
                peer = "?"
                try:
                    peer = f"{sock.getpeername()[0]}:{sock.getpeername()[1]}"
                except OSError:
                    pass
                msg = data
                print(f"RECV fd={fd} peer={peer} bytes={len(data)}", flush=True)
                dead_targets: list[int] = []
                for tfd, tsock in clients.items():
                    if tfd == fd:
                        continue
                    try:
                        tsock.sendall(msg)
                    except OSError as e:
                        print(f"broadcast send fail fd={tfd}: {e}", flush=True)
                        dead_targets.append(tfd)
                for tfd in dead_targets:
                    _close_client(clients, tfd, "broadcast-fail")
                if dead_targets:
                    tracked = [listen_fd] + list(clients.keys())
                    max_fd = max(tracked) if tracked else listen_fd
                    print(
                        f"STATE after_broadcast_cleanup clients={len(clients)} "
                        f"max_fd={max_fd} nfds={max_fd+1}",
                        flush=True,
                    )

    finally:
        for fd in list(clients.keys()):
            _close_client(clients, fd, "shutdown")
        try:
            srv.close()
        except OSError:
            pass


def _accept_loop(srv: socket.socket, clients: dict[int, socket.socket]) -> None:
    """边缘/水平触发下可能积压多个连接；循环 accept 直到 EAGAIN。"""
    while True:
        try:
            conn, addr = srv.accept()
        except BlockingIOError:
            break
        except OSError as e:
            if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                break
            print(f"accept err: {e}", flush=True)
            break
        conn.setblocking(False)
        fd = conn.fileno()
        if not fd_ok(fd):
            print(
                f"REJECT fd={fd} >= FD_SETSIZE={FD_SETSIZE} from {addr} "
                f"(不对超范围 fd 做 FD_SET)",
                flush=True,
            )
            try:
                conn.close()
            except OSError:
                pass
            continue
        clients[fd] = conn
        print(f"ACCEPT fd={fd} peer={addr[0]}:{addr[1]}", flush=True)


def _close_client(clients: dict[int, socket.socket], fd: int, reason: str) -> None:
    sock = clients.pop(fd, None)
    if sock is None:
        return
    peer = "?"
    try:
        peer = f"{sock.getpeername()[0]}:{sock.getpeername()[1]}"
    except OSError:
        pass
    try:
        sock.close()
    except OSError:
        pass
    print(f"CLOSE fd={fd} peer={peer} reason={reason}", flush=True)


if __name__ == "__main__":
    main()
