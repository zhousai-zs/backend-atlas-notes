#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from trace import Tracer, current, run_broken_async, run_fixed_async

ROOT = Path(__file__).resolve().parent
(ROOT / "reports").mkdir(exist_ok=True)


def handle_storage(tracer: Tracer, key: str):
    span = tracer.start("storage.get", "internal", key=key)
    tok = tracer.activate(span)
    try:
        span.event("disk.read", key=key)
        return {"ok": True, "value": "dark"}
    finally:
        tracer.reset(tok)


def handle_rpc(tracer: Tracer, key: str):
    span = tracer.start("rpc.kv.get", "server")
    tok = tracer.activate(span)
    try:
        return handle_storage(tracer, key)
    finally:
        tracer.reset(tok)


def main():
    tracer = Tracer()
    incoming = {
        "traceparent": "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
        "baggage": "region=sha,token=s3cret-token,env=lab",
    }
    remote = tracer.extract(incoming)
    assert remote is not None
    tok = tracer.activate(remote)
    try:
        client = tracer.start("client.kv.get", "client")
        ctok = tracer.activate(client)
        try:
            handle_rpc(tracer, "theme")
        finally:
            tracer.reset(ctok)
    finally:
        tracer.reset(tok)

    names = [s.name for s in tracer.spans]
    assert names == ["client.kv.get", "rpc.kv.get", "storage.get"]
    ids = {s.name: s for s in tracer.spans}
    assert ids["client.kv.get"].trace_id == "4bf92f3577b34da6a3ce929d0e0e4736"
    assert ids["rpc.kv.get"].trace_id == ids["storage.get"].trace_id == ids["client.kv.get"].trace_id
    assert ids["client.kv.get"].parent_span_id == "00f067aa0ba902b7"
    assert ids["rpc.kv.get"].parent_span_id == ids["client.kv.get"].span_id
    assert ids["storage.get"].parent_span_id == ids["rpc.kv.get"].span_id
    assert "token" in tracer.dropped_baggage
    assert ids["client.kv.get"].attributes.get("baggage", {}).get("token") is None
    # baggage landed on the remote parent, not the client span; check remote
    assert remote.attributes["baggage"] == {"region": "sha", "env": "lab"}
    assert "s3cret-token" not in json.dumps([s.__dict__ for s in tracer.spans], default=str)

    # logs include trace_id from current context
    log = {
        "event": "kv.request",
        "trace_id": ids["rpc.kv.get"].trace_id,
        "span_id": ids["rpc.kv.get"].span_id,
        "status": "ok",
    }
    assert log["trace_id"] == "4bf92f3577b34da6a3ce929d0e0e4736"

    # broken async: worker starts a new root trace
    broken_tracer = Tracer()
    parent = broken_tracer.start("rpc.kv.get", "server")
    ptok = broken_tracer.activate(parent)
    lost = {}

    def worker_broken():
        child = broken_tracer.start("storage.get.async", "internal")
        lost["trace_id"] = child.trace_id
        lost["parent"] = child.parent_span_id
        return child

    child_b = run_broken_async(broken_tracer, parent, worker_broken)
    broken_tracer.reset(ptok)
    assert child_b.trace_id != parent.trace_id
    assert child_b.parent_span_id is None

    # fixed async: same trace, parent linked
    fixed_tracer = Tracer()
    parent2 = fixed_tracer.start("rpc.kv.get", "server")
    ptok2 = fixed_tracer.activate(parent2)
    child_f = run_fixed_async(fixed_tracer, parent2, lambda: fixed_tracer.start("storage.get.async", "internal"))
    fixed_tracer.reset(ptok2)
    assert child_f.trace_id == parent2.trace_id
    assert child_f.parent_span_id == parent2.span_id

    tree = {
        "incoming_traceparent": incoming["traceparent"],
        "trace_id": ids["client.kv.get"].trace_id,
        "spans": [
            {
                "name": s.name,
                "span_id": s.span_id,
                "parent": s.parent_span_id,
            }
            for s in tracer.spans
        ],
        "exported_traceparent": tracer.format_traceparent(ids["rpc.kv.get"]),
        "dropped_baggage": tracer.dropped_baggage,
        "log": log,
        "broken_async": {"child_trace_id": child_b.trace_id, "parent_trace_id": parent.trace_id, "parent_span": child_b.parent_span_id},
        "fixed_async": {"child_trace_id": child_f.trace_id, "parent_trace_id": parent2.trace_id, "parent_span": child_f.parent_span_id},
    }
    (ROOT / "reports" / "trace.json").write_text(json.dumps(tree, indent=2) + "\n")
    results = {
        "span_count": len(tracer.spans),
        "shared_trace_id": ids["client.kv.get"].trace_id,
        "chain": [s.name for s in tracer.spans],
        "dropped_baggage": tracer.dropped_baggage,
        "log_trace_id": log["trace_id"],
        "broken_new_trace": child_b.trace_id != parent.trace_id,
        "fixed_same_trace": child_f.trace_id == parent2.trace_id,
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(tree, indent=2))
    print(json.dumps(results))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
