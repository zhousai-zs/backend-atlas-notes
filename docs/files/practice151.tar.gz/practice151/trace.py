"""Teaching W3C Trace Context + a tiny in-process span recorder."""
from __future__ import annotations

import secrets
from contextvars import ContextVar, copy_context
from dataclasses import dataclass, field


FORBIDDEN_BAGGAGE = {"password", "token", "api_key", "authorization", "secret"}

# ContextVar holds the current span id / trace id for this execution context.
current = ContextVar("trace_current", default=None)


def new_id(n=16) -> str:
    return secrets.token_hex(n)


@dataclass
class Span:
    name: str
    trace_id: str
    span_id: str
    parent_span_id: str | None
    kind: str
    status: str = "ok"
    events: list = field(default_factory=list)
    attributes: dict = field(default_factory=dict)

    def event(self, name: str, **attrs):
        self.events.append({"name": name, **attrs})


class Tracer:
    def __init__(self):
        self.spans: list[Span] = []
        self.dropped_baggage: list[str] = []

    def start(self, name: str, kind: str, parent: Span | None = None, **attrs) -> Span:
        inherited = parent if parent is not None else current.get()
        if inherited is None:
            trace_id = new_id(16)
            parent_id = None
        else:
            trace_id = inherited.trace_id
            parent_id = inherited.span_id
        span = Span(
            name=name,
            trace_id=trace_id,
            span_id=new_id(8),
            parent_span_id=parent_id,
            kind=kind,
            attributes=attrs,
        )
        self.spans.append(span)
        return span

    def activate(self, span: Span):
        return current.set(span)

    def reset(self, token):
        current.reset(token)

    def parse_traceparent(self, header: str) -> dict:
        # version-trace_id-parent_id-flags   (W3C Trace Context)
        parts = header.strip().split("-")
        if len(parts) != 4:
            raise ValueError("invalid traceparent")
        version, trace_id, parent_id, flags = parts
        if version != "00" or len(trace_id) != 32 or len(parent_id) != 16 or len(flags) != 2:
            raise ValueError("invalid traceparent fields")
        return {"version": version, "trace_id": trace_id, "parent_id": parent_id, "flags": flags}

    def format_traceparent(self, span: Span, flags="01") -> str:
        return f"00-{span.trace_id}-{span.span_id}-{flags}"

    def parse_baggage(self, header: str) -> dict:
        out = {}
        if not header:
            return out
        for item in header.split(","):
            if "=" not in item:
                continue
            k, v = item.split("=", 1)
            k, v = k.strip(), v.strip()
            if k.lower() in FORBIDDEN_BAGGAGE:
                self.dropped_baggage.append(k)
                continue
            out[k] = v
        return out

    def extract(self, headers: dict) -> Span | None:
        raw = headers.get("traceparent")
        if not raw:
            return None
        parsed = self.parse_traceparent(raw)
        baggage = self.parse_baggage(headers.get("baggage", ""))
        # remote parent is a virtual span we don't export as a local record
        remote = Span(
            name="remote-parent",
            trace_id=parsed["trace_id"],
            span_id=parsed["parent_id"],
            parent_span_id=None,
            kind="remote",
            attributes={"baggage": baggage, "flags": parsed["flags"]},
        )
        return remote


def run_broken_async(tracer: Tracer, parent: Span, work):
    """Anti-pattern: start a worker thread/callback without copying context."""
    # simulate a thread that sees the default ContextVar (no parent)
    token = current.set(None)
    try:
        return work()
    finally:
        current.reset(token)


def run_fixed_async(tracer: Tracer, parent: Span, work):
    """Propagate: bind the parent span in the worker context."""
    def bound():
        tok = current.set(parent)
        try:
            return work()
        finally:
            current.reset(tok)

    ctx = copy_context()
    return ctx.run(bound)
