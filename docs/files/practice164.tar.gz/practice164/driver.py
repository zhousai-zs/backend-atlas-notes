#!/usr/bin/env python3
"""RAG with real MiniLM retrieval and a deterministic citation checker.

The extractive composer is not an LLM. Injected bad answers prove the checker.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from binder import BoundAnswer, check_answer, extractive_compose
from fetch_model import fetch
from minilm import MiniLM
from retrieve import BM25, topk

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

corpus = json.loads((ROOT / "corpus/docs.json").read_text())
bundle = json.loads((ROOT / "queries.json").read_text())
k = int(bundle["retriever_k"])

chunks = []
for doc in corpus["docs"]:
    for p in doc["paragraphs"]:
        chunks.append(
            {
                "id": p["id"],
                "doc_id": doc["id"],
                "title": doc["title"],
                "tags": doc["tags"],
                "text": p["text"],
            }
        )
chunk_by_id = {c["id"]: c for c in chunks}

model = MiniLM(fetch())
matrix = model.encode([c["text"] for c in chunks])
bm25 = BM25(chunks)

rows = []
for q in bundle["questions"]:
    qv = model.encode([q["query"]])[0]
    sem_scores = matrix @ qv
    lex_scores = bm25.scores(q["query"])
    # hybrid: z-score then add, for recall only; citations still need support check
    def z(x):
        s = np.std(x)
        return (x - np.mean(x)) / s if s > 1e-9 else np.zeros_like(x)

    hybrid = z(sem_scores) + z(lex_scores)
    hits = topk(chunks, hybrid, k, "hybrid_minilm_bm25")
    retrieved_ids = {h.chunk_id for h in hits}
    gold_hit = any(g in retrieved_ids for g in q["gold_paragraphs"]) if q["answerable"] else None

    composed = extractive_compose(q["id"], hits, q)
    errs = check_answer(composed, retrieved_ids, chunk_by_id, q)
    rec = {
        "id": q["id"],
        "query": q["query"],
        "answerable": q["answerable"],
        "retrieved": [{"id": h.chunk_id, "score": round(h.score, 4)} for h in hits],
        "gold_in_topk": gold_hit,
        "composer": composed.composer,
        "status": composed.status,
        "citations": composed.citations,
        "reason": composed.reason,
        "contract_errors": errs,
        "passed": not errs,
    }
    assert rec["passed"], rec
    if q["answerable"]:
        assert rec["gold_in_topk"] is True, rec
        assert rec["status"] == "answered"
    else:
        assert rec["status"] == "abstain"
        assert rec["reason"] == "not_retrieved"
    rows.append(rec)

# Injected counterexamples: checker must fail these.
bad_unsupported = BoundAnswer(
    "Q01",
    "answered",
    "kv-node-7 died because DNS aliases failed at the gateway.",
    ["D20-P01"],
    None,
    composer="injected_bad_citation",
)
# Pretend D20-P01 was retrieved so we test support, not retrieval.
fake_retr = {"D20-P01", "D01-P01"}
bad_errs = check_answer(bad_unsupported, fake_retr, chunk_by_id, bundle["questions"][0])
assert any(e.startswith("citation_does_not_support") or e == "cited_text_lacks_support_span" for e in bad_errs), bad_errs

bad_unseen = BoundAnswer(
    "Q01",
    "answered",
    "kv-node-7 ran out of RAM.",
    ["D01-P01"],
    None,
    composer="injected_unretrieved_cite",
)
unseen_errs = check_answer(bad_unseen, {"D05-P01"}, chunk_by_id, bundle["questions"][0])
assert any(e.startswith("cite_not_retrieved") for e in unseen_errs), unseen_errs

bad_absent = BoundAnswer(
    "Q05",
    "abstain",
    "该电话号码在世界上不存在。",
    [],
    "fact_absent",
    composer="injected_fact_absent",
)
absent_errs = check_answer(bad_absent, set(), chunk_by_id, bundle["questions"][4])
assert "not_retrieved_must_not_be_called_fact_absent" in absent_errs

results = {
    "lesson": 164,
    "id": "k-rag",
    "is_live_model": False,
    "used_official_minilm_onnx": True,
    "composer_is_llm": False,
    "n_docs": corpus["n_docs"],
    "n_paragraphs": corpus["n_paragraphs"],
    "retriever_k": k,
    "retriever": "hybrid z-score MiniLM + BM25",
    "questions": rows,
    "answerable_all_retrieved_and_supported": all(r["passed"] and r["gold_in_topk"] for r in rows if r["answerable"]),
    "unanswerable_abstain_not_fact_absent": all(
        r["reason"] == "not_retrieved" for r in rows if not r["answerable"]
    ),
    "counterexamples_caught": {
        "unsupported_citation": bad_errs,
        "cite_not_retrieved": unseen_errs,
        "fact_absent_mislabel": absent_errs,
    },
    "verified_on_this_machine": [
        "minilm_hybrid_retriever_hits_gold_for_answerable_queries",
        "extractive_composer_cites_supporting_paragraphs_only",
        "unanswerable_questions_abstain_with_not_retrieved",
        "checker_rejects_unrelated_citation_and_fact_absent_label",
    ],
    "not_verified_on_this_machine": [
        "generative_LLM_RAG_answer_quality",
        "LangChain_production_retriever_or_pgvector_index",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "rag.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
