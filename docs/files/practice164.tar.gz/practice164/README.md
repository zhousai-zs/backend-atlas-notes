# practice164 — RAG 与可追溯回答

MiniLM + BM25 混合召回，抽取式组答（不是 LLM）。引用必须支持结论；检索不到不得写成 fact_absent。不把 23MB 模型打进 tar，请设置 MINILM_HOME。

```bash
bash test.sh
```
