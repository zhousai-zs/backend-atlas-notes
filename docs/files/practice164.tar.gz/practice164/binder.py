"""Citation binder and support checker. Deterministic, not an LLM."""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class BoundAnswer:
    question_id: str
    status: str  # answered | abstain
    conclusion: str
    citations: list[str]
    reason: str | None
    composer: str


def normalize(s: str) -> str:
    return re.sub(r"\s+", " ", s.lower()).strip()


def span_supported(text: str, spans: list[str]) -> bool:
    n = normalize(text)
    return any(normalize(sp) in n for sp in spans)


def check_answer(
    answer: BoundAnswer,
    retrieved_ids: set[str],
    chunk_by_id: dict[str, dict],
    gold: dict,
) -> list[str]:
    """Program checks. Passing this is not evidence of LLM citation quality."""
    errs: list[str] = []
    if answer.status == "abstain":
        if answer.citations:
            errs.append("abstain_must_not_cite")
        if gold.get("answerable"):
            errs.append("abstained_on_answerable")
        else:
            # Must not invent "the fact does not exist".
            if answer.reason == "fact_absent":
                errs.append("not_retrieved_must_not_be_called_fact_absent")
            if answer.reason not in {"not_retrieved", "insufficient_evidence"}:
                errs.append(f"bad_abstain_reason:{answer.reason}")
        return errs

    if not gold.get("answerable"):
        errs.append("answered_unanswerable")
    if not answer.citations:
        errs.append("answered_without_citations")
    for cid in answer.citations:
        if cid not in retrieved_ids:
            errs.append(f"cite_not_retrieved:{cid}")
        if cid not in chunk_by_id:
            errs.append(f"cite_unknown:{cid}")
            continue
        if gold.get("support_spans") and not span_supported(
            chunk_by_id[cid]["text"], gold["support_spans"]
        ):
            errs.append(f"citation_does_not_support:{cid}")
    # Every gold support span should be backed by at least one citation
    # when the question is answerable and we require support.
    if gold.get("support_spans") and answer.citations:
        cited_text = " ".join(chunk_by_id[c]["text"] for c in answer.citations if c in chunk_by_id)
        if not span_supported(cited_text, gold["support_spans"]):
            if "citation_does_not_support" not in ",".join(errs):
                errs.append("cited_text_lacks_support_span")
    return errs


def extractive_compose(
    question_id: str,
    hits,
    gold: dict,
) -> BoundAnswer:
    """Quote a retrieved paragraph that contains a support span, else abstain.

    This is a teaching extractor, not a generative model.
    """
    if not gold.get("answerable"):
        return BoundAnswer(
            question_id,
            "abstain",
            "检索结果中没有足够证据，不能把『没检索到』写成『该事实不存在』。",
            [],
            "not_retrieved",
            composer="extractive_not_llm",
        )
    spans = gold.get("support_spans") or []
    for h in hits:
        if span_supported(h.text, spans):
            return BoundAnswer(
                question_id,
                "answered",
                h.text,
                [h.chunk_id],
                None,
                composer="extractive_not_llm",
            )
    return BoundAnswer(
        question_id,
        "abstain",
        "已检索但没有段落包含所需支持片段。",
        [],
        "insufficient_evidence",
        composer="extractive_not_llm",
    )
