#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" fetch_model.py
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False and r["composer_is_llm"] is False
assert r["n_docs"] == 20
assert r["answerable_all_retrieved_and_supported"] is True
assert r["unanswerable_abstain_not_fact_absent"] is True
assert r["counterexamples_caught"]["fact_absent_mislabel"]
print("POSTCHECK_OK")
PY
