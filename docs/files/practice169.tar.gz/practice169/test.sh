#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False and r["scripted_policy_is_llm"] is False
t=r["terminals"]
assert t["budget_exhausted_max_steps"]["terminal"]=="budget_exhausted"
assert t["budget_exhausted_calls"]["terminal"]=="budget_exhausted"
assert t["tool_failure"]["terminal"]=="tool_failure"
assert t["cancel"]["terminal"]=="cancel"
assert t["success"]=="success"
assert "cited_not_returned" in t["cited_not_returned"]["stop_reason"]
assert r["replay"]["matched_state_transitions"] and r["replay"]["matched_terminal"]
print("POSTCHECK_OK")
PY
