# practice169 — Agent 循环与 Workflow

脚本策略（不是 LLM）覆盖成功、预算耗尽、工具失败、取消，并回放状态迁移。引用必须来自已返回段落。

```bash
bash test.sh
```
