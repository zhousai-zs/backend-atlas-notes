#!/usr/bin/env python3
"""Workflow vs scripted Agent loop. The policies are not LLMs."""

from __future__ import annotations

import json
from pathlib import Path

from harness import (
    Loop,
    Tools,
    agent_bad_citation,
    agent_cancel,
    agent_good,
    agent_infinite,
    workflow_policy,
)

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

questions = [
    {"id": "Q1", "q": "Why was kv-node-7 terminated?", "answerable": True},
    {"id": "Q2", "q": "Does a failed readiness probe restart the container by itself?", "answerable": True},
    {"id": "Q3", "q": "What is the Shanghai NOC manager's personal mobile number?", "answerable": False},
]


def as_dict(run) -> dict:
    return {
        "question_id": run.question_id,
        "kind": run.kind,
        "policy": run.policy,
        "terminal": run.terminal,
        "stop_reason": run.stop_reason,
        "answer": run.answer,
        "citations": run.citations,
        "tool_calls": run.tool_calls,
        "steps": run.steps,
        "elapsed_ms": run.elapsed_ms,
        "scripted_policy_is_llm": run.scripted_policy_is_llm,
        "events": [
            {
                "step": e.step,
                "state": e.state,
                "action": e.action,
                "observation": e.observation,
                "elapsed_ms": e.elapsed_ms,
            }
            for e in run.events
        ],
    }


# --- baseline: same questions, workflow vs good agent ---
wf_loop = Loop(Tools("ok"), max_steps=8, budget_calls=8)
ag_loop = Loop(Tools("ok"), max_steps=8, budget_calls=8)
wf_runs = [wf_loop.run(q, workflow_policy(q), kind="workflow", policy_name="fixed_path") for q in questions]
ag_runs = [ag_loop.run(q, agent_good(q), kind="agent", policy_name="scripted_good") for q in questions]
for r in wf_runs + ag_runs:
    assert r.terminal == "success", as_dict(r)
assert wf_runs[0].citations == ["D01-P01"] and wf_runs[2].stop_reason == "abstain"

# --- four terminal states ---
inf = Loop(Tools("ok"), max_steps=5, budget_calls=100).run(
    questions[0], agent_infinite(questions[0]), kind="agent", policy_name="infinite_retrieve"
)
assert inf.terminal == "budget_exhausted" and inf.stop_reason == "max_steps"
assert inf.steps == 5

bud = Loop(Tools("ok"), max_steps=20, budget_calls=1).run(
    questions[0], agent_good(questions[0]), kind="agent", policy_name="good_but_tiny_budget"
)
# retrieve consumes the only budgeted call; next tool (read) exhausts
assert bud.terminal == "budget_exhausted" and bud.stop_reason == "budget_calls"

err = Loop(Tools("error"), max_steps=8, budget_calls=8).run(
    questions[0], workflow_policy(questions[0]), kind="workflow", policy_name="fixed_path"
)
assert err.terminal == "tool_failure"

can = Loop(Tools("ok"), max_steps=8, budget_calls=8).run(
    questions[0], agent_cancel(questions[0]), kind="agent", policy_name="user_cancel"
)
assert can.terminal == "cancel"

# --- citation of unread material is rejected ---
bad = Loop(Tools("ok"), max_steps=8, budget_calls=8).run(
    questions[0], agent_bad_citation(questions[0]), kind="agent", policy_name="cite_unread"
)
assert bad.terminal == "tool_failure" and "cited_not_returned" in bad.stop_reason

# --- empty retrieve: workflow abstains successfully ---
empty = Loop(Tools("empty"), max_steps=8, budget_calls=8).run(
    questions[0], workflow_policy(questions[0]), kind="workflow", policy_name="fixed_path"
)
assert empty.terminal == "success" and empty.stop_reason == "abstain"

# --- replay: play the recorded action sequence on a fresh loop ---
def playback(events):
    seq = [e.action for e in events]
    i = {"n": 0}

    def policy(_snap):
        act = seq[i["n"]]
        i["n"] += 1
        return act

    return policy


replay_src = wf_runs[0]
replay = Loop(Tools("ok"), max_steps=8, budget_calls=8).run(
    questions[0], playback(replay_src.events), kind="workflow", policy_name="replay"
)
assert replay.terminal == replay_src.terminal
assert replay.citations == replay_src.citations
assert [e.action for e in replay.events] == [e.action for e in replay_src.events]
# state transitions match
assert [e.state for e in replay.events] == [e.state for e in replay_src.events]

# cost / success comparison (scripted, same question set)
def pack(runs):
    return {
        "success_n": sum(1 for r in runs if r.terminal == "success"),
        "mean_calls": sum(r.tool_calls for r in runs) / len(runs),
        "mean_steps": sum(r.steps for r in runs) / len(runs),
        "by_question": {r.question_id: {"terminal": r.terminal, "calls": r.tool_calls, "steps": r.steps, "stop": r.stop_reason} for r in runs},
    }


results = {
    "lesson": 169,
    "id": "l-loop",
    "is_live_model": False,
    "scripted_policy_is_llm": False,
    "who_chooses_next_action": {
        "workflow": "code (fixed_path)",
        "agent": "the policy in the loop (here a script, standing in for a model)",
    },
    "question_set": questions,
    "workflow": pack(wf_runs),
    "agent_scripted_good": pack(ag_runs),
    "terminals": {
        "success": as_dict(wf_runs[0])["terminal"],
        "budget_exhausted_max_steps": as_dict(inf),
        "budget_exhausted_calls": as_dict(bud),
        "tool_failure": as_dict(err),
        "cancel": as_dict(can),
        "cited_not_returned": as_dict(bad),
        "empty_retrieve_abstain": as_dict(empty),
    },
    "replay": {
        "matched_terminal": replay.terminal == replay_src.terminal,
        "matched_citations": replay.citations == replay_src.citations,
        "matched_actions": [e.action for e in replay.events] == [e.action for e in replay_src.events],
        "matched_state_transitions": [e.state for e in replay.events] == [e.state for e in replay_src.events],
    },
    "runs": {
        "workflow": [as_dict(r) for r in wf_runs],
        "agent_good": [as_dict(r) for r in ag_runs],
    },
    "verified_on_this_machine": [
        "four_terminals_success_budget_tool_failure_cancel",
        "max_steps_stops_infinite_retrieve",
        "citation_of_unread_paragraph_rejected",
        "fixed_action_replay_reproduces_transitions",
    ],
    "not_verified_on_this_machine": [
        "live_LLM_action_selection_or_success_rate",
        "paid_or_local_chat_model_in_the_loop",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "loops.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(
    {
        "workflow": results["workflow"],
        "agent": results["agent_scripted_good"],
        "terminals": {k: (v if isinstance(v, str) else v.get("terminal")) for k, v in results["terminals"].items()},
        "replay": results["replay"],
    },
    indent=2,
))
print("ALL_CHECKS_PASSED")
