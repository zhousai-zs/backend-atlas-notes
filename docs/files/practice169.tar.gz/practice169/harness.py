"""Deterministic Workflow vs scripted-policy Agent. Not an LLM."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Literal

ROOT = Path(__file__).resolve().parent
CORPUS = {d["id"]: d["text"] for d in json.loads((ROOT / "corpus/docs.json").read_text())}

Terminal = Literal["success", "budget_exhausted", "tool_failure", "cancel"]
ActionName = Literal["retrieve", "read", "answer", "abstain", "cancel"]


@dataclass
class Event:
    step: int
    state: str
    action: dict
    observation: Any
    elapsed_ms: float


@dataclass
class Run:
    question_id: str
    kind: str  # workflow | agent
    policy: str
    terminal: Terminal
    stop_reason: str
    answer: str | None
    citations: list[str]
    events: list[Event] = field(default_factory=list)
    tool_calls: int = 0
    steps: int = 0
    elapsed_ms: float = 0.0
    scripted_policy_is_llm: bool = False


class Tools:
    def __init__(self, mode: str = "ok"):
        self.mode = mode  # ok | empty | error | repeat
        self._last: list[str] = []

    def retrieve(self, query: str) -> dict:
        if self.mode == "error":
            raise RuntimeError("retrieve backend unavailable")
        if self.mode == "empty":
            return {"hits": []}
        q = query.lower()
        hits = []
        for i, t in CORPUS.items():
            if any(tok in t.lower() or tok in q for tok in q.split() if len(tok) > 3):
                # return id only; body requires read()
                hits.append({"id": i, "score": 1.0})
        if "kv-node" in q or "oom" in q:
            hits = [{"id": "D01-P01", "score": 1.2}] + [h for h in hits if h["id"] != "D01-P01"]
        if "readiness" in q or "restart" in q:
            hits = [{"id": "D08-P01", "score": 1.2}] + [h for h in hits if h["id"] != "D08-P01"]
        if "stdio" in q or "stderr" in q:
            hits = [{"id": "D14-P02", "score": 1.2}] + [h for h in hits if h["id"] != "D14-P02"]
        if self.mode == "repeat":
            hits = self._last or hits
        self._last = hits
        return {"hits": hits}

    def read(self, paragraph_id: str) -> dict:
        if paragraph_id not in CORPUS:
            raise KeyError(f"unknown paragraph {paragraph_id}")
        return {"id": paragraph_id, "text": CORPUS[paragraph_id]}


def citation_ok(citations: list[str], returned: set[str]) -> tuple[bool, str]:
    for c in citations:
        if c not in returned:
            return False, f"cited_not_returned:{c}"
        if c not in CORPUS:
            return False, f"cited_unknown:{c}"
    return True, "ok"


class Loop:
    def __init__(self, tools: Tools, *, max_steps: int, budget_calls: int):
        self.tools = tools
        self.max_steps = max_steps
        self.budget_calls = budget_calls

    def run(self, question: dict, policy: Callable[[dict], dict], *, kind: str, policy_name: str) -> Run:
        returned: set[str] = set()
        read_text: dict[str, str] = {}
        hits: list[dict] = []
        events: list[Event] = []
        calls = 0
        elapsed = 0.0
        state = "start"
        answer = None
        citations: list[str] = []
        terminal: Terminal | None = None
        stop = ""
        for step in range(1, self.max_steps + 2):
            if step > self.max_steps:
                terminal, stop = "budget_exhausted", "max_steps"
                break
            if calls >= self.budget_calls and kind == "agent":
                # budget is checked before a new tool action; answer/abstain/cancel still allowed
                pass
            snapshot = {
                "state": state,
                "hits": hits,
                "returned": sorted(returned),
                "read_text": read_text,
                "calls": calls,
                "step": step,
                "question": question["q"],
            }
            action = policy(snapshot)
            name = action["name"]
            obs: Any
            dt = 1.0  # teaching clock, one unit per step
            try:
                if name in {"retrieve", "read"}:
                    if calls >= self.budget_calls:
                        terminal, stop = "budget_exhausted", "budget_calls"
                        events.append(Event(step, state, action, {"error": "budget_calls"}, dt))
                        elapsed += dt
                        break
                    if name == "retrieve":
                        obs = self.tools.retrieve(action.get("query", question["q"]))
                        hits = obs["hits"]
                        # retrieve does not automatically mark text as returned
                    else:
                        obs = self.tools.read(action["paragraph_id"])
                        returned.add(obs["id"])
                        read_text[obs["id"]] = obs["text"]
                    calls += 1
                    state = "observed"
                elif name == "answer":
                    citations = list(action.get("citations") or [])
                    answer = action.get("answer")
                    ok, why = citation_ok(citations, returned)
                    if not ok:
                        obs = {"error": why}
                        terminal, stop = "tool_failure", why
                    else:
                        obs = {"ok": True}
                        terminal, stop = "success", "answered"
                elif name == "abstain":
                    answer = None
                    citations = []
                    obs = {"reason": action.get("reason", "not_retrieved")}
                    terminal, stop = "success", "abstain"
                elif name == "cancel":
                    obs = {"reason": action.get("reason", "user_cancel")}
                    terminal, stop = "cancel", "cancel"
                else:
                    obs = {"error": f"unknown_action:{name}"}
                    terminal, stop = "tool_failure", f"unknown_action:{name}"
            except Exception as e:
                obs = {"error": f"{type(e).__name__}:{e}"}
                terminal, stop = "tool_failure", f"{type(e).__name__}"
            events.append(Event(step, state, action, obs, dt))
            elapsed += dt
            if terminal:
                break
        assert terminal is not None
        return Run(
            question_id=question["id"],
            kind=kind,
            policy=policy_name,
            terminal=terminal,
            stop_reason=stop,
            answer=answer,
            citations=citations,
            events=events,
            tool_calls=calls,
            steps=len(events),
            elapsed_ms=elapsed,
        )


# --- policies (scripted; not LLMs) ---

def workflow_policy(question: dict) -> Callable[[dict], dict]:
    """Fixed path: retrieve → read top hit if any → answer or abstain. No extra loops."""

    stage = {"n": 0}

    def policy(snap: dict) -> dict:
        stage["n"] += 1
        if stage["n"] == 1:
            return {"name": "retrieve", "query": question["q"]}
        if stage["n"] == 2:
            if not snap["hits"]:
                return {"name": "abstain", "reason": "not_retrieved"}
            return {"name": "read", "paragraph_id": snap["hits"][0]["id"]}
        if question.get("answerable") and snap["read_text"]:
            pid = next(iter(snap["read_text"]))
            return {"name": "answer", "answer": snap["read_text"][pid], "citations": [pid]}
        return {"name": "abstain", "reason": "not_retrieved"}

    return policy


def agent_good(question: dict) -> Callable[[dict], dict]:
    """Scripted agent: may read the first hit, then stop. Same actions as a model could choose."""

    def policy(snap: dict) -> dict:
        if not snap["hits"]:
            return {"name": "retrieve", "query": question["q"]}
        unread = [h["id"] for h in snap["hits"] if h["id"] not in snap["returned"]]
        if unread:
            return {"name": "read", "paragraph_id": unread[0]}
        if question.get("answerable") and snap["read_text"]:
            pid = next(iter(snap["read_text"]))
            return {"name": "answer", "answer": snap["read_text"][pid], "citations": [pid]}
        return {"name": "abstain", "reason": "not_retrieved"}

    return policy


def agent_infinite(_question: dict) -> Callable[[dict], dict]:
    def policy(_snap: dict) -> dict:
        return {"name": "retrieve", "query": "keep looking"}

    return policy


def agent_cancel(_question: dict) -> Callable[[dict], dict]:
    def policy(snap: dict) -> dict:
        if snap["step"] == 1:
            return {"name": "retrieve", "query": _question["q"]}
        return {"name": "cancel", "reason": "user_cancel"}

    return policy


def agent_bad_citation(question: dict) -> Callable[[dict], dict]:
    def policy(snap: dict) -> dict:
        if not snap["hits"]:
            return {"name": "retrieve", "query": question["q"]}
        # answer without reading: citation not in returned set
        return {"name": "answer", "answer": "made up", "citations": ["D01-P01"]}

    return policy
