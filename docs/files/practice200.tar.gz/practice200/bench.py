"""Teaching benchmark for the ADR assumption about threading models.

This is a Python TCP echo server, not a C++ reactor. It still produces
real timings for three models under many concurrent short connections:
thread-per-connection, a bounded thread pool, and an asyncio event loop
(the coroutine stand-in).
"""
from __future__ import annotations

import concurrent.futures
import socket
import threading
import time
import asyncio
from typing import Callable


def _serve_conn(conn):
    try:
        data = conn.recv(64)
        conn.sendall(data or b"ok")
    finally:
        conn.close()


def run_thread_per_conn(port: int, stop: threading.Event):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port)); s.listen(128); s.settimeout(0.05)
    while not stop.is_set():
        try:
            c, _ = s.accept()
        except socket.timeout:
            continue
        threading.Thread(target=_serve_conn, args=(c,), daemon=True).start()
    s.close()


def run_pool(port: int, stop: threading.Event, workers=8):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", port)); s.listen(128); s.settimeout(0.05)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        while not stop.is_set():
            try:
                c, _ = s.accept()
            except socket.timeout:
                continue
            ex.submit(_serve_conn, c)
    s.close()


def run_asyncio(port: int, stop: threading.Event):
    async def handler(reader, writer):
        data = await reader.read(64)
        writer.write(data or b"ok")
        await writer.drain()
        writer.close()
        await writer.wait_closed()

    async def main():
        server = await asyncio.start_server(handler, "127.0.0.1", port)
        while not stop.is_set():
            await asyncio.sleep(0.02)
        server.close()
        await server.wait_closed()

    asyncio.run(main())


def client_wave(port: int, n: int, concurrency: int) -> dict:
    ok = 0
    errors = 0
    t0 = time.perf_counter()

    def one(_i):
        nonlocal ok, errors
        try:
            s = socket.create_connection(("127.0.0.1", port), timeout=2)
            s.sendall(b"ping")
            s.recv(64)
            s.close()
            ok += 1
        except Exception:
            errors += 1

    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as ex:
        list(ex.map(one, range(n)))
    dt = time.perf_counter() - t0
    return {"ok": ok, "errors": errors, "seconds": dt, "qps": ok / dt if dt else 0, "n": n, "concurrency": concurrency}


def free_port() -> int:
    s = socket.socket(); s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def bench_model(name: str, runner: Callable, n=300, concurrency=80) -> dict:
    port = free_port()
    stop = threading.Event()
    th = threading.Thread(target=runner, args=(port, stop), daemon=True)
    th.start()
    time.sleep(0.08)
    try:
        r = client_wave(port, n, concurrency)
        r["model"] = name
        return r
    finally:
        stop.set()
        th.join(timeout=2)
