#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["validation_good"]["ok"] is True
assert r["validation_bad"]["ok"] is False
assert Path("adr/0001-reactor-threading.md").read_text().count("qps=")>=3
assert r["failed"]==[]
print("POSTCHECK_OK")
PY
