# ADR 0001. Reactor 并发模型（教学测量）

## Status
Accepted (teaching record). Review when: connection concurrency target changes by 10x, tail latency SLO is missed, or the implementation language changes.

## Context
教学用回显服务需要在约 80 路并发短连接下选择并发模型。候选是每连接一个线程、有界线程池、以及 asyncio 协程（作为事件循环/协程模型的测量替身）。这不是 C++ Reactor 的生产基准，但关键假设「每连接线程在高并发短连接下更贵」必须有本次测量数据。

## Decision
选择 **thread_pool** 作为这一教学负载下的默认模型（以本次 ok 数与 qps 为证据）。C++ 生产实现仍可能用 epoll Reactor + 线程池，需在同类负载下复测。

## Consequences
正向：有可复现数字，后来者知道当时比较了什么。负向：Python 运行时与 C++ 栈大小、调度器不同，不能把 qps 绝对值搬到生产。采用有界池或事件循环后，过载时要有明确的拒绝策略。

## Alternatives
- thread-per-connection（每连接线程）：实现简单，但在本次 80 并发短连接下测量为 thread_per_connection: ok=300/300 errors=0 seconds=0.0636 qps=4720.6 concurrency=80。被否决作为默认，因为线程创建/栈开销在该负载下没有优势，且错误数或耗时不优于另外两者。
- thread_pool（有界线程池）：thread_pool: ok=300/300 errors=0 seconds=0.0427 qps=7023.9 concurrency=80。若未当选，原因是 qps/错误数不如胜者；若当选，则作为可预测的并发上限。
- asyncio_coroutines（协程/事件循环）：asyncio_coroutines: ok=300/300 errors=0 seconds=0.0550 qps=5453.7 concurrency=80。这是协程模型的测量，不是 C++ coroutine 的等价实现。

本次测量原始数据：
- thread_per_connection: ok=300/300 errors=0 seconds=0.0636 qps=4720.6 concurrency=80
- thread_pool: ok=300/300 errors=0 seconds=0.0427 qps=7023.9 concurrency=80
- asyncio_coroutines: ok=300/300 errors=0 seconds=0.0550 qps=5453.7 concurrency=80
