from __future__ import annotations

import re

REQUIRED = ["status", "context", "decision", "consequences", "alternatives"]


def parse(md: str) -> dict:
    fields = {}
    cur = None
    buf = []
    for line in md.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            if cur:
                fields[cur] = "\n".join(buf).strip()
            cur = m.group(1).strip().lower()
            buf = []
        else:
            buf.append(line)
    if cur:
        fields[cur] = "\n".join(buf).strip()
    return fields


def validate(md: str) -> dict:
    fields = parse(md)
    problems = []
    for k in REQUIRED:
        if k not in fields or not fields[k]:
            problems.append(f"missing_{k}")
    alt = fields.get("alternatives") or fields.get("rejected alternatives") or ""
    if alt and ("thread-per-connection" not in alt.lower() and "每连接" not in alt):
        # accept either language
        if "thread-per-connection" not in md.lower() and "每连接线程" not in md:
            problems.append("alternatives_do_not_discuss_rejected_models")
    if "qps" not in md.lower() and "seconds" not in md.lower() and "测量" not in md:
        problems.append("no_measurement_data")
    title = re.search(r"^#\s+ADR", md, re.M)
    if not title:
        problems.append("missing_title")
    # Conclusion-only: just a Decision section would already fail REQUIRED.
    return {"ok": not problems, "problems": problems, "fields": list(fields)}
