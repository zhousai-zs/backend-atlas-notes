from __future__ import annotations

import json
from pathlib import Path

from bench import bench_model, run_asyncio, run_pool, run_thread_per_conn
from validate_adr import validate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def main() -> None:
    results = [
        bench_model("thread_per_connection", run_thread_per_conn),
        bench_model("thread_pool", run_pool),
        bench_model("asyncio_coroutines", run_asyncio),
    ]
    by = {r["model"]: r for r in results}
    (ROOT / "reports" / "bench.json").write_text(json.dumps(results, indent=2) + "\n")

    def fmt(r):
        return f"{r['model']}: ok={r['ok']}/{r['n']} errors={r['errors']} seconds={r['seconds']:.4f} qps={r['qps']:.1f} concurrency={r['concurrency']}"

    lines = "\n".join("- " + fmt(r) for r in results)
    # Decision can prefer pool or asyncio based on actual numbers; record both rejected reasons.
    winner = max(results, key=lambda r: (r["ok"] - r["errors"], r["qps"]))
    adr = f"""# ADR 0001. Reactor 并发模型（教学测量）

## Status
Accepted (teaching record). Review when: connection concurrency target changes by 10x, tail latency SLO is missed, or the implementation language changes.

## Context
教学用回显服务需要在约 80 路并发短连接下选择并发模型。候选是每连接一个线程、有界线程池、以及 asyncio 协程（作为事件循环/协程模型的测量替身）。这不是 C++ Reactor 的生产基准，但关键假设「每连接线程在高并发短连接下更贵」必须有本次测量数据。

## Decision
选择 **{winner['model']}** 作为这一教学负载下的默认模型（以本次 ok 数与 qps 为证据）。C++ 生产实现仍可能用 epoll Reactor + 线程池，需在同类负载下复测。

## Consequences
正向：有可复现数字，后来者知道当时比较了什么。负向：Python 运行时与 C++ 栈大小、调度器不同，不能把 qps 绝对值搬到生产。采用有界池或事件循环后，过载时要有明确的拒绝策略。

## Alternatives
- thread-per-connection（每连接线程）：实现简单，但在本次 {by['thread_per_connection']['concurrency']} 并发短连接下测量为 {fmt(by['thread_per_connection'])}。被否决作为默认，因为线程创建/栈开销在该负载下没有优势，且错误数或耗时不优于另外两者。
- thread_pool（有界线程池）：{fmt(by['thread_pool'])}。若未当选，原因是 qps/错误数不如胜者；若当选，则作为可预测的并发上限。
- asyncio_coroutines（协程/事件循环）：{fmt(by['asyncio_coroutines'])}。这是协程模型的测量，不是 C++ coroutine 的等价实现。

本次测量原始数据：
{lines}
"""
    (ROOT / "adr" / "0001-reactor-threading.md").write_text(adr)
    # A conclusion-only ADR must fail the validator.
    bad = "# ADR X\n\n## Decision\nUse coroutines.\n"
    good_v = validate(adr)
    bad_v = validate(bad)
    checks = [
        ("all_three_models_ran", all(r["n"] == 300 for r in results) and all(r["ok"] + r["errors"] == 300 for r in results), json.dumps(results)),
        ("good_adr_accepted", good_v["ok"] is True, str(good_v)),
        ("conclusion_only_rejected", bad_v["ok"] is False and "missing_context" in bad_v["problems"], str(bad_v)),
        ("rejected_models_discussed", "thread-per-connection" in adr and "被否决" in adr or "若未当选" in adr, ""),
        ("data_in_adr", "qps=" in adr, ""),
    ]
    # fix the rejected_models check logic - the `or` binds wrongly
    checks[3] = ("rejected_models_discussed", "thread-per-connection" in adr and ("被否决" in adr or "若未当选" in adr), "")
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 200,
                "id": "n-adr",
                "is_live_model": False,
                "winner": winner["model"],
                "bench": results,
                "validation_good": good_v,
                "validation_bad": bad_v,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "not_verified_on_this_machine": [
                    "a C++ epoll/coroutine reactor under production hardware",
                ],
                "verified_on_this_machine": [
                    "three real Python TCP server models timed under 80 concurrent short connections",
                    "ADR validator rejects a conclusion-only record and accepts a record with context, alternatives, and data",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
