#!/usr/bin/env python3
"""Contrast naive vs safe MySQL-like session / pool / bind-parameter behavior."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

from app import UserStore
from engine import (
    DEFAULT_CHARSET,
    PreparedGone,
    SessionDead,
    TeachingConnection,
    TransactionAborted,
    fetch_user,
    init_db,
)
from pool import NaivePool, PoolTimeout, SafePool

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results.json"


def fresh_db():
    fd, path = tempfile.mkstemp(prefix="practice97_", suffix=".db")
    os.close(fd)
    init_db(path)
    return path


def print_table(title, rows, headers):
    print()
    print(f"== {title} ==")
    widths = [len(h) for h in headers]
    for r in rows:
        for i, h in enumerate(headers):
            widths[i] = max(widths[i], len(str(r.get(h, ""))))
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    print(fmt.format(*headers))
    print(fmt.format(*("-" * w for w in widths)))
    for r in rows:
        print(fmt.format(*[str(r.get(h, "")) for h in headers]))


def exp_injection():
    db = fresh_db()
    try:
        safe_pool, naive_pool = SafePool(db, size=3), NaivePool(db, size=3)
        safe, naive = UserStore(safe_pool, "safe"), UserStore(naive_pool, "naive")
        payload = "' OR '1'='1"
        t0 = time.perf_counter()
        naive_leaked = naive.get_user_by_name(payload)
        naive_ms = (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        safe_rows = safe.get_user_by_name(payload)
        safe_ms = (time.perf_counter() - t0) * 1000
        naive_alice = naive.get_user_by_name("alice")
        safe_alice = safe.get_user_by_name("alice")
        # Bound-parameter evidence: last safe SQL must not contain the payload,
        # and bind_count must have increased.
        # Grab a connection and run one more bound query to inspect last_sql.
        c = safe_pool.checkout()
        before = c.bind_count
        c.execute_bound("SELECT id, name FROM users WHERE name = ?", (payload,))
        last_sql, last_params, after = c.last_sql, c.last_params, c.bind_count
        safe_pool.checkin(c)
        out = {
            "payload": payload,
            "naive_rows": len(naive_leaked),
            "naive_names": [r["name"] for r in naive_leaked],
            "safe_rows": len(safe_rows),
            "safe_names": [r["name"] for r in safe_rows],
            "naive_alice": len(naive_alice),
            "safe_alice": len(safe_alice),
            "naive_ms": round(naive_ms, 3),
            "safe_ms": round(safe_ms, 3),
            "bind_sql": last_sql,
            "bind_params": list(last_params),
            "bind_count_delta": after - before,
            "payload_in_sql": payload in (last_sql or ""),
        }
        assert out["naive_rows"] == 5, out
        assert out["safe_rows"] == 0, out
        assert out["naive_alice"] == 1 and out["safe_alice"] == 1, out
        assert out["bind_count_delta"] == 1, out
        assert out["payload_in_sql"] is False, out
        assert out["bind_params"] == [payload], out
        return out
    finally:
        os.unlink(db)


def exp_reconnect():
    db = fresh_db()
    try:
        # --- naive silent reconnect ---
        naive_conn = TeachingConnection(db, conn_id=11, mode="naive")
        naive_conn.execute("BEGIN")
        naive_conn.execute_concat("UPDATE users SET bio = '%s' WHERE name = '%s'", "in-tx-change", "alice")
        naive_conn.prepare("get_alice", "SELECT bio FROM users WHERE name = ?")
        naive_in_tx_before = naive_conn.in_tx
        naive_prep_before = sorted(naive_conn.prepared)
        naive_conn.kill()
        t0 = time.perf_counter()
        naive_conn.silent_reconnect()
        naive_re_ms = (time.perf_counter() - t0) * 1000
        naive_in_tx_after = naive_conn.in_tx
        # Client still thinks COMMIT is valid for the original transaction.
        naive_conn.execute("COMMIT")
        naive_commit_reported = True
        alice_after_naive = fetch_user(db, 1)
        # Client-cached prepared name still appears usable (silently reattached).
        naive_prep_client = sorted(naive_conn.client_prepared)
        naive_prep_exec_ok = False
        try:
            rows = naive_conn.execute_prepared("get_alice", ("alice",))
            naive_prep_exec_ok = True
            naive_prep_rows = rows
        except (PreparedGone, SessionDead) as e:
            naive_prep_rows = [{"error": type(e).__name__}]

        # Reset alice bio is still hello; next experiment uses a fresh db? same db is ok.

        # --- safe reconnect ---
        safe_conn = TeachingConnection(db, conn_id=21, mode="safe")
        safe_conn.execute("BEGIN")
        safe_conn.execute_bound("UPDATE users SET bio = ? WHERE name = ?", ("in-tx-change", "alice"))
        safe_conn.prepare("get_alice", "SELECT bio FROM users WHERE name = ?")
        safe_in_tx_before = safe_conn.in_tx
        safe_conn.kill()
        aborted = None
        new_id = 22
        t0 = time.perf_counter()
        try:
            old_id, was_in_tx = safe_conn.safe_reconnect()
            safe_conn.conn_id = new_id
            raise TransactionAborted(old_id, safe_conn.conn_id, was_in_tx)
        except TransactionAborted as e:
            aborted = e
        safe_re_ms = (time.perf_counter() - t0) * 1000
        safe_in_tx_after = safe_conn.in_tx
        safe_charset = safe_conn.charset
        alice_after_safe = fetch_user(db, 1)
        safe_prep_exec_ok = False
        safe_prep_err = None
        try:
            safe_conn.execute_prepared("get_alice", ("alice",))
            safe_prep_exec_ok = True
        except PreparedGone as e:
            safe_prep_err = type(e).__name__

        out = {
            "naive_in_tx_before_kill": naive_in_tx_before,
            "naive_in_tx_after_reconnect": naive_in_tx_after,
            "naive_commit_reported": naive_commit_reported,
            "naive_alice_bio": alice_after_naive["bio"],
            "naive_false_success": naive_commit_reported and alice_after_naive["bio"] != "in-tx-change",
            "naive_reconnect_ms": round(naive_re_ms, 3),
            "naive_prepared_before": naive_prep_before,
            "naive_prepared_client_after": naive_prep_client,
            "naive_prepared_exec_ok": naive_prep_exec_ok,
            "safe_in_tx_before_kill": safe_in_tx_before,
            "safe_in_tx_after_reconnect": safe_in_tx_after,
            "safe_aborted": aborted is not None,
            "safe_old_id": aborted.old_id if aborted else None,
            "safe_new_id": aborted.new_id if aborted else None,
            "safe_was_in_tx": aborted.was_in_tx if aborted else None,
            "safe_id_changed": bool(aborted and aborted.old_id != aborted.new_id),
            "safe_charset_after": safe_charset,
            "safe_alice_bio": alice_after_safe["bio"],
            "safe_reconnect_ms": round(safe_re_ms, 3),
            "safe_prepared_exec_ok": safe_prep_exec_ok,
            "safe_prepared_err": safe_prep_err,
        }
        assert out["naive_in_tx_after_reconnect"] is True, out
        assert out["naive_false_success"] is True, out
        assert out["naive_alice_bio"] == "hello", out
        assert out["naive_prepared_exec_ok"] is True, out
        assert out["safe_aborted"] is True, out
        assert out["safe_in_tx_after_reconnect"] is False, out
        assert out["safe_id_changed"] is True, out
        assert out["safe_alice_bio"] == "hello", out
        assert out["safe_prepared_exec_ok"] is False, out
        assert out["safe_prepared_err"] == "PreparedGone", out
        return out
    finally:
        os.unlink(db)


def exp_pool_reset():
    db = fresh_db()
    try:
        def run(pool_cls, mode):
            pool = pool_cls(db, size=1)
            a = pool.checkout()
            a.execute("SET NAMES latin1")
            a.execute("BEGIN")
            a.execute(
                "UPDATE users SET role = 'admin' WHERE id = 2"
                if mode == "naive"
                else "UPDATE users SET role = ? WHERE id = ?",
                None if mode == "naive" else ("admin", 2),
            )
            dirty_charset = a.charset
            dirty_in_tx = a.in_tx
            pool.checkin(a)
            b = pool.checkout()
            b_charset = b.charset
            b_in_tx = b.in_tx
            # Next borrower COMMITs whatever they think they have.
            b.execute("COMMIT")
            bob = fetch_user(db, 2)
            pool.checkin(b)
            return {
                "a_charset": dirty_charset,
                "a_in_tx": dirty_in_tx,
                "b_charset": b_charset,
                "b_in_tx": b_in_tx,
                "bob_role": bob["role"],
            }

        # naive first (it will actually commit the leaked update)
        naive = run(NaivePool, "naive")
        # Use a fresh database for the safe path so leftover naive
        # connections cannot lock the file.
        os.unlink(db)
        db = fresh_db()
        safe = run(SafePool, "safe")
        out = {
            "naive_a_charset": naive["a_charset"],
            "naive_b_charset": naive["b_charset"],
            "naive_a_in_tx": naive["a_in_tx"],
            "naive_b_in_tx": naive["b_in_tx"],
            "naive_bob_role": naive["bob_role"],
            "naive_tx_leaked": naive["bob_role"] == "admin",
            "naive_charset_leaked": naive["b_charset"] == "latin1",
            "safe_a_charset": safe["a_charset"],
            "safe_b_charset": safe["b_charset"],
            "safe_a_in_tx": safe["a_in_tx"],
            "safe_b_in_tx": safe["b_in_tx"],
            "safe_bob_role": safe["bob_role"],
            "safe_tx_leaked": safe["bob_role"] == "admin",
            "safe_charset_reset": safe["b_charset"] == DEFAULT_CHARSET,
        }
        assert out["naive_tx_leaked"] is True, out
        assert out["naive_charset_leaked"] is True, out
        assert out["naive_b_in_tx"] is True, out
        assert out["safe_tx_leaked"] is False, out
        assert out["safe_charset_reset"] is True, out
        assert out["safe_b_in_tx"] is False, out
        assert out["safe_bob_role"] == "user", out
        return out
    finally:
        os.unlink(db)


def exp_pool_exhaustion():
    db = fresh_db()
    try:
        pool = SafePool(db, size=3, checkout_timeout=0.2)
        held = [pool.checkout() for _ in range(3)]
        for c in held:
            c.execute("BEGIN")
        t0 = time.perf_counter()
        timed_out = False
        try:
            pool.checkout(timeout=0.2)
        except PoolTimeout:
            timed_out = True
        held_ms = (time.perf_counter() - t0) * 1000
        # release and retry
        for c in held:
            pool.checkin(c)
        t0 = time.perf_counter()
        c4 = pool.checkout(timeout=0.2)
        free_ms = (time.perf_counter() - t0) * 1000
        ok = c4 is not None
        pool.checkin(c4)
        out = {
            "pool_size": 3,
            "held": 3,
            "fourth_timed_out": timed_out,
            "fourth_wait_ms": round(held_ms, 3),
            "after_release_ok": ok,
            "after_release_wait_ms": round(free_ms, 3),
            "checkout_fail": pool.checkout_fail,
            "connects_created": pool._created,
        }
        assert out["fourth_timed_out"] is True, out
        assert out["fourth_wait_ms"] >= 180, out
        assert out["after_release_ok"] is True, out
        assert out["after_release_wait_ms"] < 50, out
        return out
    finally:
        os.unlink(db)


def exp_wait_timeout():
    db = fresh_db()
    try:
        # size=1 so the same physical connection sits idle in the pool.
        # default_wait_timeout is the teaching stand-in for the server's
        # global wait_timeout: after 0.12s idle the server drops the session.
        safe_pool = SafePool(db, size=1, checkout_timeout=0.5, default_wait_timeout=0.12)
        naive_pool = NaivePool(db, size=1, checkout_timeout=0.5, default_wait_timeout=0.12)

        s = safe_pool.checkout()
        old_id = s.conn_id
        s.execute("SET NAMES latin1")
        # Safe check-in resets charset, but wait_timeout returns to the
        # configured global default (0.12s), so a long idle still expires.
        safe_pool.checkin(s)
        time.sleep(0.25)
        t0 = time.perf_counter()
        s2 = safe_pool.checkout()
        safe_ms = (time.perf_counter() - t0) * 1000
        out_safe = {
            "safe_new_session": s2.conn_id != old_id,
            "safe_old_id": old_id,
            "safe_new_id": s2.conn_id,
            "safe_alive": s2.alive,
            "safe_charset": s2.charset,
            "safe_checkout_ms": round(safe_ms, 3),
        }
        safe_pool.checkin(s2)

        n = naive_pool.checkout()
        n.execute("SET NAMES latin1")
        naive_old_id = n.conn_id
        naive_pool.checkin(n)  # dirty charset kept
        time.sleep(0.25)
        t0 = time.perf_counter()
        n2 = naive_pool.checkout()
        naive_ms = (time.perf_counter() - t0) * 1000
        out_naive = {
            "naive_alive": n2.alive,
            "naive_charset": n2.charset,
            "naive_kept_id": n2.conn_id == naive_old_id,
            "naive_silent_reconnect": n2.alive and n2.charset == "latin1",
            "naive_checkout_ms": round(naive_ms, 3),
        }
        naive_pool.checkin(n2)

        out = {
            "wait_timeout_s": 0.12,
            "idle_s": 0.25,
            **out_safe,
            **out_naive,
        }
        assert out["safe_new_session"] is True, out
        assert out["safe_charset"] == DEFAULT_CHARSET, out
        assert out["safe_alive"] is True, out
        assert out["naive_silent_reconnect"] is True, out
        return out
    finally:
        os.unlink(db)


def main():
    results = {}
    results["injection"] = exp_injection()
    results["reconnect"] = exp_reconnect()
    results["pool_reset"] = exp_pool_reset()
    results["pool_exhaustion"] = exp_pool_exhaustion()
    results["wait_timeout"] = exp_wait_timeout()

    print_table(
        "1. SQL injection (get_user_by_name)",
        [
            {"path": "naive", "rows": results["injection"]["naive_rows"],
             "names": ",".join(results["injection"]["naive_names"]),
             "alice": results["injection"]["naive_alice"],
             "ms": results["injection"]["naive_ms"]},
            {"path": "safe", "rows": results["injection"]["safe_rows"],
             "names": ",".join(results["injection"]["safe_names"]) or "(none)",
             "alice": results["injection"]["safe_alice"],
             "ms": results["injection"]["safe_ms"]},
        ],
        ["path", "rows", "names", "alice", "ms"],
    )
    print(
        "  bind evidence: sql=%r params=%s payload_in_sql=%s bind_delta=%s"
        % (
            results["injection"]["bind_sql"],
            results["injection"]["bind_params"],
            results["injection"]["payload_in_sql"],
            results["injection"]["bind_count_delta"],
        )
    )

    print_table(
        "2. Reconnect mid-transaction (UPDATE alice bio, then kill session)",
        [
            {
                "path": "naive",
                "in_tx_after": results["reconnect"]["naive_in_tx_after_reconnect"],
                "commit": results["reconnect"]["naive_commit_reported"],
                "bio": results["reconnect"]["naive_alice_bio"],
                "false_success": results["reconnect"]["naive_false_success"],
                "prepared_ok": results["reconnect"]["naive_prepared_exec_ok"],
            },
            {
                "path": "safe",
                "in_tx_after": results["reconnect"]["safe_in_tx_after_reconnect"],
                "commit": "aborted" if results["reconnect"]["safe_aborted"] else "n/a",
                "bio": results["reconnect"]["safe_alice_bio"],
                "false_success": False,
                "prepared_ok": results["reconnect"]["safe_prepared_exec_ok"],
            },
        ],
        ["path", "in_tx_after", "commit", "bio", "false_success", "prepared_ok"],
    )
    print(
        "  safe ids %s -> %s  prepared_err=%s"
        % (
            results["reconnect"]["safe_old_id"],
            results["reconnect"]["safe_new_id"],
            results["reconnect"]["safe_prepared_err"],
        )
    )

    print_table(
        "3. Pool check-in: leftover SET NAMES latin1 + uncommitted role update on bob",
        [
            {
                "path": "naive",
                "b_charset": results["pool_reset"]["naive_b_charset"],
                "b_in_tx": results["pool_reset"]["naive_b_in_tx"],
                "bob_role": results["pool_reset"]["naive_bob_role"],
                "tx_leaked": results["pool_reset"]["naive_tx_leaked"],
            },
            {
                "path": "safe",
                "b_charset": results["pool_reset"]["safe_b_charset"],
                "b_in_tx": results["pool_reset"]["safe_b_in_tx"],
                "bob_role": results["pool_reset"]["safe_bob_role"],
                "tx_leaked": results["pool_reset"]["safe_tx_leaked"],
            },
        ],
        ["path", "b_charset", "b_in_tx", "bob_role", "tx_leaked"],
    )

    ex = results["pool_exhaustion"]
    print()
    print("== 4. Pool exhaustion by long transactions ==")
    print(
        "  size=%s held=%s fourth_timed_out=%s wait_ms=%s after_release_ok=%s after_ms=%s"
        % (
            ex["pool_size"],
            ex["held"],
            ex["fourth_timed_out"],
            ex["fourth_wait_ms"],
            ex["after_release_ok"],
            ex["after_release_wait_ms"],
        )
    )

    wt = results["wait_timeout"]
    print()
    print("== 5. wait_timeout idle disconnect ==")
    print(
        "  timeout=%ss idle=%ss  safe_new_session=%s (%s->%s, charset=%s)  "
        "naive_silent_reconnect=%s (kept_id=%s, charset=%s)"
        % (
            wt["wait_timeout_s"],
            wt["idle_s"],
            wt["safe_new_session"],
            wt["safe_old_id"],
            wt["safe_new_id"],
            wt["safe_charset"],
            wt["naive_silent_reconnect"],
            wt["naive_kept_id"],
            wt["naive_charset"],
        )
    )

    RESULTS.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print()
    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
