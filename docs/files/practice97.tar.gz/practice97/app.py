"""Teaching user query/update helpers on top of the pool."""
from __future__ import annotations


class UserStore:
    def __init__(self, pool, mode: str):
        self.pool = pool
        self.mode = mode

    def get_user_by_name(self, name: str):
        conn = self.pool.checkout()
        try:
            if self.mode == "safe":
                return conn.execute_bound(
                    "SELECT id, name, role, bio FROM users WHERE name = ?",
                    (name,),
                )
            return conn.execute_concat(
                "SELECT id, name, role, bio FROM users WHERE name = '%s'",
                name,
            )
        finally:
            self.pool.checkin(conn)

    def update_user_bio(self, name: str, bio: str):
        conn = self.pool.checkout()
        try:
            if self.mode == "safe":
                conn.execute_bound(
                    "UPDATE users SET bio = ? WHERE name = ?",
                    (bio, name),
                )
            else:
                conn.execute_concat(
                    "UPDATE users SET bio = '%s' WHERE name = '%s'",
                    bio,
                    name,
                )
            return conn
        finally:
            self.pool.checkin(conn)
