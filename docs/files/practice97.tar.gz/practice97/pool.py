"""Naive vs safe teaching connection pools."""
from __future__ import annotations

import itertools
import queue
from engine import TeachingConnection, TransactionAborted


class PoolTimeout(Exception):
    pass


class BasePool:
    def __init__(self, db_path: str, size: int = 3, checkout_timeout: float = 0.2, mode: str = "safe",
                 default_wait_timeout: float = 8.0):
        self.db_path = db_path
        self.size = size
        self.checkout_timeout = checkout_timeout
        self.mode = mode
        self.default_wait_timeout = default_wait_timeout
        self._ids = itertools.count(1)
        self._idle: queue.Queue = queue.Queue()
        self._created = 0
        self.checkout_ok = 0
        self.checkout_fail = 0
        for _ in range(size):
            self._idle.put(self._new())

    def _new(self) -> TeachingConnection:
        cid = next(self._ids)
        self._created += 1
        return TeachingConnection(self.db_path, cid, mode=self.mode, wait_timeout=self.default_wait_timeout)

    def qsize(self) -> int:
        return self._idle.qsize()


class SafePool(BasePool):
    def __init__(self, db_path: str, size: int = 3, checkout_timeout: float = 0.2, default_wait_timeout: float = 8.0):
        super().__init__(db_path, size, checkout_timeout, mode="safe", default_wait_timeout=default_wait_timeout)

    def checkout(self, timeout=None) -> TeachingConnection:
        if timeout is None:
            timeout = self.checkout_timeout
        try:
            conn = self._idle.get(timeout=timeout)
        except queue.Empty:
            self.checkout_fail += 1
            raise PoolTimeout(f"pool exhausted (size={self.size})")
        if (not conn.alive) or conn.is_idle_timed_out():
            # Dead or wait_timeout: replace with a brand-new session.
            try:
                conn.kill()
            except Exception:
                pass
            conn = self._new()
        self.checkout_ok += 1
        return conn

    def checkin(self, conn: TeachingConnection):
        if not conn.alive or conn.is_idle_timed_out():
            try:
                conn.kill()
            except Exception:
                pass
            self._idle.put(self._new())
            return
        # mysql_reset_connection() equivalent: do not close, do clear state.
        conn.reset_like_mysql_reset_connection()
        self._idle.put(conn)

    def reconnect(self, conn: TeachingConnection) -> TeachingConnection:
        old_id, was_in_tx = conn.safe_reconnect()
        new = self._new()
        # Drop the old object; the caller must not keep using it as the old tx.
        raise TransactionAborted(old_id, new.conn_id, was_in_tx)


class NaivePool(BasePool):
    def __init__(self, db_path: str, size: int = 3, checkout_timeout: float = 0.2, default_wait_timeout: float = 8.0):
        super().__init__(db_path, size, checkout_timeout, mode="naive", default_wait_timeout=default_wait_timeout)

    def checkout(self, timeout=None) -> TeachingConnection:
        if timeout is None:
            timeout = self.checkout_timeout
        try:
            conn = self._idle.get(timeout=timeout)
        except queue.Empty:
            self.checkout_fail += 1
            raise PoolTimeout(f"pool exhausted (size={self.size})")
        # Naive: hand out whatever is there, including dead or dirty sessions.
        if not conn.alive or conn.is_idle_timed_out():
            conn.silent_reconnect()
        self.checkout_ok += 1
        return conn

    def checkin(self, conn: TeachingConnection):
        # Naive: return as-is. Leftover tx / charset leak to the next borrower.
        self._idle.put(conn)

    def reconnect(self, conn: TeachingConnection) -> TeachingConnection:
        conn.silent_reconnect()
        return conn
