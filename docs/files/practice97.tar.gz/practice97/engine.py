"""Teaching MySQL-like session on top of sqlite3 (stdlib only).

This models session state, prepared statements, disconnect, and reconnect
semantics. It is not a MySQL server and must not be quoted as production
MySQL performance.
"""
from __future__ import annotations

import re
import sqlite3
import time

DEFAULT_CHARSET = "utf8mb4"


class SessionDead(Exception):
    """The server-side session is gone (disconnect or wait_timeout)."""


class TransactionAborted(Exception):
    """Reconnect created a NEW session; the old transaction was not resumed."""

    def __init__(self, old_id, new_id, was_in_tx):
        self.old_id = old_id
        self.new_id = new_id
        self.was_in_tx = was_in_tx
        super().__init__(
            f"session {old_id} lost; new session is {new_id}; "
            f"in_tx was {was_in_tx}; old transaction cannot be resumed"
        )


class PreparedGone(Exception):
    """Prepared statement is no longer valid in this session."""


def _ident(value: str) -> str:
    return value.strip().strip("'\"")


class TeachingConnection:
    """One client session. Each instance has its own sqlite connection."""

    def __init__(self, db_path: str, conn_id: int, mode: str, wait_timeout: float = 8.0):
        self.db_path = db_path
        self.conn_id = conn_id
        self.mode = mode  # 'safe' | 'naive'
        self.default_wait_timeout = wait_timeout
        self.wait_timeout = wait_timeout
        self.charset = DEFAULT_CHARSET
        self.autocommit = True
        self.in_tx = False
        self.alive = True
        self.prepared = {}          # server-side registry: name -> sql
        self.client_prepared = {}   # client-side cache (naive may keep this after reconnect)
        self.bind_count = 0
        self.concat_count = 0
        self.connect_count = 0
        self.last_sql = None
        self.last_params = None
        self.last_active = time.monotonic()
        self._sqlite = None
        self._open_sqlite()

    def _open_sqlite(self):
        self._sqlite = sqlite3.connect(self.db_path, isolation_level=None, timeout=5.0)
        self._sqlite.row_factory = sqlite3.Row
        self._sqlite.execute("PRAGMA busy_timeout=5000")
        self.connect_count += 1
        self.alive = True
        self.last_active = time.monotonic()

    def is_idle_timed_out(self) -> bool:
        return self.alive and (time.monotonic() - self.last_active) > self.wait_timeout

    def kill(self):
        """Simulate the server dropping this session.

        Uncommitted work is rolled back (sqlite close/rollback) and server-side
        prepared statements disappear. Client-visible fields such as in_tx,
        charset and client_prepared are left untouched — a naive caller may
        still believe the old session is alive.
        """
        if self._sqlite is not None:
            try:
                # Always try a rollback while the handle is still open.
                self._sqlite.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            try:
                self._sqlite.close()
            except sqlite3.Error:
                pass
        self._sqlite = None
        self.alive = False
        self.prepared.clear()

    def _touch_or_die(self):
        if self.alive and self.is_idle_timed_out():
            self.kill()
        if not self.alive or self._sqlite is None:
            raise SessionDead(f"session {self.conn_id} is dead")
        self.last_active = time.monotonic()

    def silent_reconnect(self):
        """NAIVE: open a NEW server session but pretend the old one continues."""
        old_in_tx = self.in_tx
        old_charset = self.charset
        old_auto = self.autocommit
        old_id = self.conn_id
        cached = dict(self.client_prepared or self.prepared)
        self.kill()
        self._open_sqlite()
        # Pretend nothing happened.
        self.in_tx = old_in_tx
        self.charset = old_charset
        self.autocommit = old_auto
        self.client_prepared = cached
        # Server-side prepared statements are actually gone.
        self.prepared = {}
        self._silent_old_id = old_id
        return self

    def safe_reconnect(self):
        """SAFE: NEW session, clear state, and tell the caller the truth."""
        old_id = self.conn_id
        was_in_tx = self.in_tx
        self.kill()
        self._open_sqlite()
        # A new session id (thread_id equivalent).
        self.conn_id = old_id  # will be overwritten by caller/pool with a new id
        self.charset = DEFAULT_CHARSET
        self.autocommit = True
        self.in_tx = False
        self.prepared.clear()
        self.client_prepared.clear()
        return old_id, was_in_tx

    def reset_like_mysql_reset_connection(self):
        """Pool check-in path: clear session without closing the connection."""
        self._touch_or_die()
        if self.in_tx:
            self._sqlite.execute("ROLLBACK")
            self.in_tx = False
        self.autocommit = True
        self.charset = DEFAULT_CHARSET
        self.wait_timeout = self.default_wait_timeout
        self.prepared.clear()
        self.client_prepared.clear()
        self.last_sql = None
        self.last_params = None

    def execute_concat(self, sql_template: str, *values):
        """NAIVE string interpolation. Values are not escaped."""
        self.concat_count += 1
        filled = sql_template % values
        return self.execute(filled, params=None, _from_concat=True)

    def execute_bound(self, sql: str, params):
        """SAFE bound-parameter execution (models a prepared/binary protocol)."""
        if params is None:
            params = ()
        if not isinstance(params, (tuple, list)):
            raise TypeError("params must be a sequence")
        self.bind_count += 1
        return self.execute(sql, params=tuple(params), _from_concat=False)

    def prepare(self, name: str, sql: str):
        self._touch_or_die()
        self.prepared[name] = sql
        self.client_prepared[name] = sql
        return name

    def execute_prepared(self, name: str, params=()):
        self._touch_or_die()
        sql = self.prepared.get(name)
        if sql is None:
            # Naive client may still hold the name.
            if name in self.client_prepared and self.mode == "naive":
                # Silent re-use of a client-cached statement text on a new
                # session — hides the fact that the server dropped it.
                sql = self.client_prepared[name]
                self.prepared[name] = sql
            else:
                raise PreparedGone(f"prepared statement {name!r} is not valid in this session")
        return self.execute_bound(sql, params)

    def deallocate(self, name: str):
        self._touch_or_die()
        self.prepared.pop(name, None)
        self.client_prepared.pop(name, None)

    def execute(self, sql: str, params=None, _from_concat=False):
        self._touch_or_die()
        raw = sql.strip().rstrip(";")
        self.last_sql = raw
        self.last_params = params
        upper = raw.upper()

        m_names = re.match(r"SET\s+NAMES\s+(.+)$", raw, re.I)
        if m_names:
            self.charset = _ident(m_names.group(1))
            return []

        m_cs = re.match(r"SET\s+(?:character_set_client|CHARACTER_SET_CLIENT)\s*=\s*(.+)$", raw, re.I)
        if m_cs:
            self.charset = _ident(m_cs.group(1))
            return []

        m_ac = re.match(r"SET\s+(?:autocommit|AUTOCOMMIT)\s*=\s*(.+)$", raw, re.I)
        if m_ac:
            val = _ident(m_ac.group(1)).lower()
            self.autocommit = val in ("1", "on", "true")
            return []

        m_wt = re.match(r"SET\s+(?:wait_timeout|WAIT_TIMEOUT)\s*=\s*(.+)$", raw, re.I)
        if m_wt:
            self.wait_timeout = float(_ident(m_wt.group(1)))
            return []

        if upper in ("BEGIN", "BEGIN TRANSACTION", "START TRANSACTION"):
            if not self.in_tx:
                self._sqlite.execute("BEGIN")
                self.in_tx = True
                self.autocommit = False
            return []

        if upper == "COMMIT":
            # MySQL COMMIT with no active transaction is still a successful
            # no-op. After a silent reconnect this is how a client reports
            # "commit ok" even though the original transaction already died.
            try:
                self._sqlite.execute("COMMIT")
            except sqlite3.OperationalError as e:
                if "no transaction is active" not in str(e).lower():
                    raise
            self.in_tx = False
            self.autocommit = True
            return []

        if upper == "ROLLBACK":
            if self.in_tx:
                self._sqlite.execute("ROLLBACK")
            self.in_tx = False
            self.autocommit = True
            return []

        m_prep = re.match(r"PREPARE\s+(\w+)\s+FROM\s+'((?:[^']|'')*)'$", raw, re.I)
        if m_prep:
            sql_text = m_prep.group(2).replace("''", "'")
            self.prepare(m_prep.group(1), sql_text)
            return []

        m_exec = re.match(r"EXECUTE\s+(\w+)$", raw, re.I)
        if m_exec:
            return self.execute_prepared(m_exec.group(1), params or ())

        m_de = re.match(r"(?:DEALLOCATE|DROP)\s+PREPARE\s+(\w+)$", raw, re.I)
        if m_de:
            self.deallocate(m_de.group(1))
            return []

        if params is not None:
            cur = self._sqlite.execute(raw, params)
        else:
            cur = self._sqlite.execute(raw)
        if cur.description is None:
            return []
        return [dict(r) for r in cur.fetchall()]


def init_db(db_path: str):
    conn = sqlite3.connect(db_path, isolation_level=None)
    conn.execute("DROP TABLE IF EXISTS users")
    conn.execute(
        """
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL,
            bio TEXT NOT NULL
        )
        """
    )
    conn.executemany(
        "INSERT INTO users(id, name, role, bio) VALUES (?, ?, ?, ?)",
        [
            (1, "alice", "user", "hello"),
            (2, "bob", "user", "hobby:chess"),
            (3, "cindy", "user", "hobby:music"),
            (4, "dave", "user", "hobby:coding"),
            (5, "admin", "admin", "root bio"),
        ],
    )
    conn.close()


def fetch_user(db_path: str, user_id: int):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT id, name, role, bio FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None
