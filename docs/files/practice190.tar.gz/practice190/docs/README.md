---
id: kv-readme
title: KV teaching store
acl: public
version: "2.0"
as_of: "2026-11-01"
supersedes: null
---
# KV teaching store

The text protocol supports SET, GET, and EXISTS. EXISTS returns 1 or 0 and does not create a key.
