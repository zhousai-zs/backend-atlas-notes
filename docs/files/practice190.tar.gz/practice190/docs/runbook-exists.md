---
id: runbook-exists
title: Incident runbook — missing exists
acl: eng
version: "2.0"
as_of: "2026-11-10"
supersedes: runbook-timeout-old
---
# Missing EXISTS implementation

If logs say "exists not implemented", confirm handle_line has an EXISTS branch and the symbol is linked. Do not restart the process as the first step.
