---
id: legal-oncall
title: Restricted on-call legal notes
acl: legal
version: "1.0"
as_of: "2026-11-01"
supersedes: null
---
# Restricted

LEGAL_SECRET_DO_NOT_RETRIEVE: settlement clause and private pager numbers live only in this document.
