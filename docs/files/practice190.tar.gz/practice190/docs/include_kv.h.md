---
id: kv-header
title: kv.h interface notes
acl: eng
version: "2.0"
as_of: "2026-11-01"
supersedes: null
---
# include/kv.h

`bool exists(const std::string& key) const;` is a const membership query over `data_`.
