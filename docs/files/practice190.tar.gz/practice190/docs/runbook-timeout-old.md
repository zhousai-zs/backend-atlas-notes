---
id: runbook-timeout-old
title: Incident runbook — timeouts (superseded)
acl: eng
version: "1.0"
as_of: "2025-01-15"
supersedes: null
stale: true
superseded_by: runbook-exists
---
# Timeouts (old)

Old advice: always restart the kv process when p99 rises. This runbook is retained for history and is stale.
