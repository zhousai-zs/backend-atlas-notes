#!/usr/bin/env python3
"""Local engineering knowledge base with ACL at retrieval time and stale markers.

Lexical retrieval (token overlap). This is not an embedding model and is not
presented as SBERT. Unauthorized documents are dropped before a model context
is built, not only at display time. Official LangChain retrieval doc now lives
under deepagents/retrieval (redirect checked 2026-11-16).
"""
from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)

FM_RE = re.compile(r"^---\n([\s\S]*?)\n---\n([\s\S]*)$")

def parse_fm(text: str) -> tuple[dict, str]:
    m = FM_RE.match(text)
    if not m:
        return {}, text
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip().strip('"')
    return fm, m.group(2)

def tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[A-Za-z0-9_]+", text.lower()) if len(t) >= 2}

# Roles: viewer can read public; eng can read public+eng; legal can read all.
ACL = {
    "viewer": {"public"},
    "eng": {"public", "eng"},
    "legal": {"public", "eng", "legal"},
}

docs = []
for path in sorted((ROOT / "docs").glob("*.md")):
    fm, body = parse_fm(path.read_text(encoding="utf-8"))
    docs.append({
        "path": str(path.relative_to(ROOT)),
        "id": fm.get("id", path.stem),
        "title": fm.get("title", path.stem),
        "acl": fm.get("acl", "eng"),
        "version": fm.get("version"),
        "as_of": fm.get("as_of"),
        "stale": fm.get("stale", "false").lower() == "true" or bool(fm.get("superseded_by")),
        "superseded_by": fm.get("superseded_by") or None,
        "body": body,
        "tokens": tokenize(fm.get("title", "") + " " + body),
    })

LEGAL_MARK = "LEGAL_SECRET_DO_NOT_RETRIEVE"


def retrieve(query: str, role: str, k: int = 4) -> list[dict]:
    allowed = ACL[role]
    q = tokenize(query)
    # Filter at recall, before scoring is exposed to the model context.
    candidates = [d for d in docs if d["acl"] in allowed]
    ranked = []
    for d in candidates:
        overlap = len(q & d["tokens"])
        if overlap <= 0:
            continue
        ranked.append((overlap, d))
    ranked.sort(key=lambda x: -x[0])
    out = []
    for overlap, d in ranked[:k]:
        body = d["body"]
        if d["stale"]:
            body = f"[STALE] version={d['version']} as_of={d['as_of']} superseded_by={d['superseded_by']}\n" + body
        out.append({
            "id": d["id"],
            "path": d["path"],
            "version": d["version"],
            "as_of": d["as_of"],
            "stale": d["stale"],
            "acl": d["acl"],
            "score_token_overlap": overlap,
            "body": body,
        })
    return out


def context_text(hits: list[dict]) -> str:
    parts = []
    for h in hits:
        parts.append(f"## {h['title'] if 'title' in h else h['id']} ({h['path']} v{h['version']})\n{h['body']}")
    return "\n\n".join(parts)

# Queries
eng_hits = retrieve("How should I handle exists not implemented and what does EXISTS return?", role="eng")
viewer_hits = retrieve("How should I handle exists not implemented and what does EXISTS return?", role="viewer")
# A query that would strongly match the legal doc if ACL were not applied first.
legalish = retrieve("settlement clause private pager numbers LEGAL_SECRET_DO_NOT_RETRIEVE", role="eng")
legal_ok = retrieve("settlement clause private pager numbers LEGAL_SECRET_DO_NOT_RETRIEVE", role="legal")

eng_ctx = json.dumps(eng_hits, ensure_ascii=False)
viewer_ctx = json.dumps(viewer_hits, ensure_ascii=False)
legalish_ctx = json.dumps(legalish, ensure_ascii=False)
legal_ok_ctx = json.dumps(legal_ok, ensure_ascii=False)

# All docs that would have matched lexically without ACL:
q = tokenize("settlement clause private pager numbers LEGAL_SECRET_DO_NOT_RETRIEVE")
unfiltered = [d["id"] for d in docs if len(q & d["tokens"]) > 0]

results = {
    "lesson": 190,
    "id": "m-knowledge",
    "is_live_model": False,
    "retriever": "lexical token overlap (not an embedding model, not SBERT, not a hash-as-vector stand-in)",
    "official_retrieval_doc_requested": "https://docs.langchain.com/oss/python/langchain/retrieval",
    "official_retrieval_doc_final": "https://docs.langchain.com/oss/python/deepagents/retrieval",
    "eng_hit_ids": [h["id"] for h in eng_hits],
    "viewer_hit_ids": [h["id"] for h in viewer_hits],
    "eng_query_for_legal_hit_ids": [h["id"] for h in legalish],
    "legal_role_hit_ids": [h["id"] for h in legal_ok],
    "unfiltered_lexical_ids_for_legal_query": unfiltered,
    "unauthorized_legal_not_in_eng_context": LEGAL_MARK not in legalish_ctx and "legal-oncall" not in legalish_ctx,
    "unauthorized_legal_not_in_eng_exists_context": LEGAL_MARK not in eng_ctx,
    "legal_role_can_see_restricted": LEGAL_MARK in legal_ok_ctx,
    "stale_docs_in_eng_hits": [h["id"] for h in eng_hits if h["stale"]],
    "stale_marked": all(h["body"].startswith("[STALE]") for h in eng_hits if h["stale"]) or any(h["stale"] for h in retrieve("old timeout restart kv process", "eng")),
    "viewer_cannot_see_eng_runbook": "runbook-exists" not in [h["id"] for h in viewer_hits],
    "hits_include_path_and_version": all("path" in h and "version" in h for h in eng_hits),
    "verified_on_this_machine": [
        "ACL filtered at recall for role=eng vs legal",
        "stale runbook is marked [STALE] when retrieved",
        "answers carry path and version",
        "lexical retriever labeled honestly",
    ],
    "not_verified_on_this_machine": [
        "LangChain production retrievers or embedding indexes (this practice uses a local lexical index)",
        "live-model answering quality",
    ],
}

# Ensure stale marking works on a query that actually retrieves the old runbook.
stale_hits = retrieve("old timeout restart kv process", "eng")
results["stale_query_ids"] = [h["id"] for h in stale_hits]
results["stale_marked"] = any(h["stale"] and h["body"].startswith("[STALE]") for h in stale_hits)
results["stale_docs_in_eng_hits"] = [h["id"] for h in stale_hits if h["stale"]]

# viewer should still see public README
results["viewer_sees_public"] = "kv-readme" in results["viewer_hit_ids"] or any(h["acl"]=="public" for h in viewer_hits)

checks = {
    "acl": results["unauthorized_legal_not_in_eng_context"] and results["unauthorized_legal_not_in_eng_exists_context"],
    "legal_unfiltered_would_hit": "legal-oncall" in unfiltered,
    "legal_role": results["legal_role_can_see_restricted"],
    "stale": results["stale_marked"],
    "path_ver": results["hits_include_path_and_version"] or len(eng_hits) == 0,
    "viewer": results["viewer_cannot_see_eng_runbook"],
}
# eng query should retrieve something useful
checks["eng_hits"] = any(i in results["eng_hit_ids"] for i in ("kv-readme", "kv-header", "runbook-exists"))
if not all(checks.values()):
    raise SystemExit(f"checks failed: {checks}\n{json.dumps(results, indent=2)}")

(REPORTS / "eng_hits.json").write_text(json.dumps(eng_hits, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("ENG", results["eng_hit_ids"])
print("VIEWER", results["viewer_hit_ids"])
print("LEGALISH", results["eng_query_for_legal_hit_ids"], "unfiltered", unfiltered)
print("STALE", results["stale_query_ids"], results["stale_marked"])
print("ALL_CHECKS_PASSED")
