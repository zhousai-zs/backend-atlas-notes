#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["unauthorized_legal_not_in_eng_context"] and r["legal_role_can_see_restricted"]
assert "legal-oncall" in r["unfiltered_lexical_ids_for_legal_query"]
assert r["stale_marked"] and r["official_retrieval_doc_final"].endswith("/deepagents/retrieval")
assert "lexical" in r["retriever"]
print("POSTCHECK_OK")
PY
