#!/usr/bin/env bash
# Backend Atlas 第51课实践验证：多客户端 TCP Echo、EOF、端口占用、异常断开
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18051
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2

python3 server.py "$PORT" > /tmp/tcp51-srv.log 2>&1 &
SRV=$!
cleanup(){ kill $SRV 2>/dev/null; wait $SRV 2>/dev/null; fuser -k ${PORT}/tcp 2>/dev/null || true; }
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/tcp51-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

SSOUT=$(ss -ltnp "sport = :$PORT" 2>/dev/null || ss -ltnp | grep ":$PORT" || true)
echo "$SSOUT" | head -5
echo "$SSOUT" | grep -q ":$PORT" && ok "ss -ltnp 可见 TCP 监听 :$PORT" || bad "ss 未见 TCP :$PORT"

# 1) 单客户端 echo
OUT=$(python3 client.py --port "$PORT" --payload 'hello-echo' 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "单客户端 echo 成功" || bad "单客户端失败: $OUT"
echo "$OUT" | grep -q "got=b'hello-echo'" && ok "echo 内容正确" || bad "echo 内容不对: $OUT"

# 2) 多客户端并发 echo
OUT=$(python3 - <<PY
import socket, threading, time
PORT = $PORT
results = []
lock = threading.Lock()

def worker(i):
    s = socket.create_connection(("127.0.0.1", PORT), timeout=2)
    msg = f"client-{i}-payload".encode()
    s.sendall(msg)
    got = b""
    while len(got) < len(msg):
        chunk = s.recv(4096)
        if not chunk:
            break
        got += chunk
    s.close()
    with lock:
        results.append((i, got == msg, got))

threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
for t in threads: t.start()
for t in threads: t.join()
ok_n = sum(1 for _, good, _ in results if good)
print(f"multi_ok={ok_n}/{len(results)}")
for i, good, got in sorted(results):
    if not good:
        print(f"bad {i} {got!r}")
PY
) || true
echo "$OUT"
echo "$OUT" | grep -q "multi_ok=8/8" && ok "8 客户端并发 echo 全部成功" || bad "多客户端失败: $OUT"

# 3) EOF 后服务仍存活
OUT=$(python3 - <<PY
import socket
s = socket.create_connection(("127.0.0.1", $PORT), timeout=2)
s.sendall(b"before-eof")
got = s.recv(64)
assert got == b"before-eof", got
s.shutdown(socket.SHUT_WR)  # send FIN / EOF to server
# drain any remaining (should be none)
s.settimeout(0.5)
try:
    extra = s.recv(64)
except socket.timeout:
    extra = b""
s.close()
print(f"eof_client_ok got={got!r} extra={extra!r}")
PY
) || true
echo "$OUT"
echo "$OUT" | grep -q "eof_client_ok" && ok "客户端半关闭/EOF 正常完成" || bad "EOF 客户端失败: $OUT"
sleep 0.3
if kill -0 $SRV 2>/dev/null; then
  ok "EOF 后服务进程仍存活"
else
  bad "EOF 后服务进程已退出"
  cat /tmp/tcp51-srv.log
fi
# 再连一次确认仍可服务
OUT=$(python3 client.py --port "$PORT" --payload 'after-eof' 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "EOF 后仍可接受新连接并 echo" || bad "EOF 后无法服务: $OUT"
grep -q "eof " /tmp/tcp51-srv.log && ok "服务端日志记录到 eof" || bad "服务端未见 eof 日志"

# 4) 端口占用时明确错误
OUT=$(python3 server.py "$PORT" 2>&1) || RC=$?
RC=${RC:-0}
echo "second_bind rc=$RC out=$OUT"
echo "$OUT" | grep -qiE "EADDRINUSE|already in use|port .* in use" && ok "端口占用给出明确错误信息" || bad "端口占用错误不明确: $OUT"
[ "${RC}" -eq 2 ] && ok "端口占用退出码为 2" || bad "端口占用退出码异常 rc=$RC"

# 5) 异常断开（RST / 未读完就 close）不拖垮 server
OUT=$(python3 - <<PY
import socket, time, os, struct
# abrupt close with SO_LINGER=0 -> often RST
s = socket.create_connection(("127.0.0.1", $PORT), timeout=2)
s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack('ii', 1, 0))
s.sendall(b"abort-me-please")
time.sleep(0.05)
s.close()  # RST-ish
print("abrupt_closed")
PY
) || true
echo "$OUT"
echo "$OUT" | grep -q "abrupt_closed" && ok "异常断开客户端已执行" || bad "异常断开脚本失败"
sleep 0.3
if kill -0 $SRV 2>/dev/null; then
  ok "异常断开后服务进程仍存活"
else
  bad "异常断开后服务进程退出"
fi
OUT=$(python3 client.py --port "$PORT" --payload 'still-alive' 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "异常断开后仍可 echo" || bad "异常断开后无法服务: $OUT"

# 6) 短写/分多次发送拼回
OUT=$(python3 - <<PY
import socket, time
s = socket.create_connection(("127.0.0.1", $PORT), timeout=2)
s.sendall(b"PART1")
time.sleep(0.05)
s.sendall(b"PART2")
s.shutdown(socket.SHUT_WR)
got = b""
while True:
    chunk = s.recv(4096)
    if not chunk:
        break
    got += chunk
s.close()
print(f"got={got!r}")
assert got == b"PART1PART2", got
print("stream_echo_ok")
PY
) || true
echo "$OUT"
echo "$OUT" | grep -q "stream_echo_ok" && ok "多次 send 拼成字节流后完整 echo" || bad "流式 echo 失败: $OUT"

echo "--- ss -ltnp ---"; ss -ltnp | grep ":$PORT" || true
echo "--- /proc/net/sockstat ---"; cat /proc/net/sockstat 2>/dev/null || true
echo "NOTE: box 若无 tcpdump/strace，抓包与系统调用跟踪请在有权限的机器上按课文执行。"

[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
