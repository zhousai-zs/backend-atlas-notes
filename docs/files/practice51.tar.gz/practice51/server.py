#!/usr/bin/env python3
"""TCP multi-client Echo server for Backend Atlas lesson 51 (d-socket)."""
import errno
import socket
import sys
import threading

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18051
BACKLOG = 128


def handle_client(conn: socket.socket, addr):
    peer = f"{addr[0]}:{addr[1]}"
    try:
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        while True:
            try:
                data = conn.recv(4096)
            except InterruptedError:
                continue
            except OSError as e:
                if e.errno == errno.EINTR:
                    continue
                print(f"recv err {peer}: {e}", flush=True)
                break
            if not data:
                # EOF: peer closed write side or connection closed
                print(f"eof {peer}", flush=True)
                break
            # Echo back; handle short writes
            view = memoryview(data)
            while len(view):
                try:
                    n = conn.send(view)
                except InterruptedError:
                    continue
                except OSError as e:
                    if e.errno == errno.EINTR:
                        continue
                    print(f"send err {peer}: {e}", flush=True)
                    return
                if n == 0:
                    print(f"send returned 0 {peer}", flush=True)
                    return
                view = view[n:]
    except Exception as e:
        print(f"client exception {peer}: {e}", flush=True)
    finally:
        try:
            conn.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            conn.close()
        except OSError:
            pass
        print(f"closed {peer}", flush=True)


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((HOST, PORT))
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                print(
                    f"ERROR: port {HOST}:{PORT} already in use (EADDRINUSE)",
                    file=sys.stderr,
                    flush=True,
                )
                sys.exit(2)
            print(f"ERROR: bind failed: {e}", file=sys.stderr, flush=True)
            sys.exit(1)
        srv.listen(BACKLOG)
        print(f"tcp echo listening on {HOST}:{PORT} backlog={BACKLOG}", flush=True)

        while True:
            try:
                conn, addr = srv.accept()
            except InterruptedError:
                continue
            except OSError as e:
                if e.errno == errno.EINTR:
                    continue
                print(f"accept err: {e}", flush=True)
                continue
            t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            t.start()
    finally:
        try:
            srv.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
