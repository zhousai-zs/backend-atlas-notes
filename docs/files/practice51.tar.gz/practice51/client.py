#!/usr/bin/env python3
"""Simple TCP echo client helper for lesson 51."""
import argparse
import socket
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18051)
    ap.add_argument("--payload", default="hello")
    ap.add_argument("--timeout", type=float, default=2.0)
    ap.add_argument("--shutdown-wr", action="store_true", help="half-close after send")
    args = ap.parse_args()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(args.timeout)
    try:
        s.connect((args.host, args.port))
        data = args.payload.encode()
        s.sendall(data)
        if args.shutdown_wr:
            s.shutdown(socket.SHUT_WR)
        got = b""
        while len(got) < len(data):
            chunk = s.recv(4096)
            if not chunk:
                break
            got += chunk
        print(f"RESULT ok sent={len(data)} got={got!r}")
        if got != data:
            print("RESULT mismatch", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"RESULT fail {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        s.close()


if __name__ == "__main__":
    main()
