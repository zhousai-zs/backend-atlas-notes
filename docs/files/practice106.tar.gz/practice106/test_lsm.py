#!/usr/bin/env python3
"""Acceptance checks for practice106 (LSMEngine)."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert_trace(data["flush_compaction_trace"])
    _assert_stall(data["write_stall"])
    _assert_tombstones(data["tombstones"])
    _assert_amp(data["amplification"])
    _assert_tradeoff(data["aggressive_vs_lazy"])

    t = data["flush_compaction_trace"]
    s = data["write_stall"]
    d = data["tombstones"]
    a = data["amplification"]
    v = data["aggressive_vs_lazy"]
    mid = d["compact_l0_to_l1"]
    bot = d["compact_l1_to_l2_bottommost"]
    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"flush={t['flush_count']} "
        f"compact={t['compact_count']} "
        f"hits={t['hits']} "
        f"l0_after={t['l0_files_after']} "
        f"l1_after={t['l1_files_after']} "
        f"fast_stall={s['fast']['stall_count']} "
        f"fast_stop={s['fast']['stop_count']} "
        f"fast_stop_s={s['fast']['stop_seconds']} "
        f"fast_p99={s['fast']['write_p99_s']} "
        f"fast_l0_peak={s['fast']['l0_peak_events']} "
        f"slow_stall={s['slow']['stall_count']} "
        f"slow_stop={s['slow']['stop_count']} "
        f"slow_stop_s={s['slow']['stop_seconds']} "
        f"slow_p99={s['slow']['write_p99_s']} "
        f"tomb_mid_kept={mid['tombstones_kept']} "
        f"tomb_mid_dropped={mid['tombstones_dropped']} "
        f"l2_still_has_value={mid['l2_still_has_value']} "
        f"tomb_bot_kept={bot['tombstones_kept']} "
        f"tomb_bot_dropped={bot['tombstones_dropped']} "
        f"tomb_left={bot['any_tombstone_left']} "
        f"lv_wamp={a['leveled']['write_amp']} "
        f"lv_ramp={a['leveled']['read_amp']} "
        f"lv_samp={a['leveled']['space_amp']} "
        f"un_wamp={a['universal']['write_amp']} "
        f"un_ramp={a['universal']['read_amp']} "
        f"un_samp={a['universal']['space_amp']} "
        f"flush_eq_user={a['sequential_write_amp_split']['flush_equals_user']} "
        f"lv_flush={a['leveled']['flush_bytes']} "
        f"lv_compact={a['leveled']['compact_bytes']} "
        f"agg_ramp={v['aggressive']['read_amp']} "
        f"lazy_ramp={v['lazy']['read_amp']} "
        f"agg_l0={v['aggressive']['l0_files']} "
        f"lazy_l0={v['lazy']['l0_files']} "
        f"agg_p99={v['aggressive']['write_p99_s']} "
        f"lazy_p99={v['lazy']['write_p99_s']} "
        f"agg_compact_bytes={v['aggressive']['compact_bytes']} "
        f"lazy_compact_bytes={v['lazy']['compact_bytes']}"
    )
    return 0


def _assert_trace(t: dict) -> None:
    assert t["hits"] == t["keys_written"] == 40
    assert t["flush_count"] >= 4
    assert t["compact_count"] >= 1
    assert t["first_flush"]["keys"] > 0
    assert t["first_compact"]["style"] == "level"
    assert t["first_compact"]["from_level"] == 0
    assert t["first_compact"]["to_level"] == 1
    # After L0->L1, some data must have landed in L1.
    assert t["l1_files_after"] >= 1
    assert t["l1_bytes_after"] > 0
    assert any("FLUSH" in line for line in t["visual_log"])
    assert any("COMPACT" in line for line in t["visual_log"])


def _assert_stall(s: dict) -> None:
    fast, slow = s["fast"], s["slow"]
    # Faster writes must pile up enough pressure to stop or stall.
    assert fast["stop_count"] + fast["stall_count"] >= 1
    assert fast["stop_seconds"] + fast["stall_seconds"] > 0
    # Slowing the write rate must avoid a full stop, and should stall
    # less (ideally not at all) than the burst.
    assert slow["stop_count"] == 0
    assert slow["stop_seconds"] == 0
    assert slow["stall_count"] <= fast["stall_count"]
    assert (slow["stall_seconds"] + slow["stop_seconds"]) < (
        fast["stall_seconds"] + fast["stop_seconds"]
    )
    # Both paths must still report amplification, not only a rate.
    for side in (fast, slow):
        assert side["write_amp"] > 0
        assert side["read_amp"] > 0
        assert side["space_amp"] >= 1.0
    assert fast["l0_peak_events"] >= s["slow"]["l0_peak_events"]


def _assert_tombstones(d: dict) -> None:
    assert d["after_push_to_l2"]["status"] == "ok"
    assert d["after_push_to_l2"]["value"] == d["value"]
    assert d["after_push_to_l2"]["l2_has_value"] is True
    assert d["after_delete_memtable"]["status"] == "not_found"
    assert d["after_flush_tombstone"]["status"] == "not_found"
    mid = d["compact_l0_to_l1"]
    assert mid["did"] is True
    assert mid["status"] == "not_found"
    # L2 still holds the old value, so the tombstone must be kept.
    assert mid["l2_still_has_value"] is True
    assert mid["tombstones_kept"] >= 1
    assert mid["tombstones_dropped"] == 0
    assert mid["tombstones_in_l1"] >= 1
    bot = d["compact_l1_to_l2_bottommost"]
    assert bot["did"] is True
    assert bot["status"] == "not_found"
    # Bottom-most: the tombstone and the old value both go away.
    assert bot["tombstones_dropped"] >= 1
    assert bot["tombstones_in_l2"] == 0
    assert bot["any_tombstone_left"] == 0


def _assert_amp(a: dict) -> None:
    lv, un = a["leveled"], a["universal"]
    split = a["sequential_write_amp_split"]
    # Flush of new keys is about one write of the user bytes; compaction
    # is the extra amplification. Total write amp must exceed 1.
    assert split["flush_equals_user"] is True
    assert lv["compact_bytes"] > 0
    assert lv["write_amp"] > 1.0
    assert lv["sst_bytes_written"] == lv["flush_bytes"] + lv["compact_bytes"]
    assert un["sst_bytes_written"] == un["flush_bytes"] + un["compact_bytes"]
    assert un["write_amp"] >= 1.0
    # Leveled pays more write amplification; universal (tiered) should
    # not exceed it on this insert-only workload (allow equality).
    assert lv["write_amp"] >= un["write_amp"]
    # Every get must report a file/memtable touch count.
    assert lv["read_amp"] >= 1.0
    assert un["read_amp"] >= 1.0
    assert lv["space_amp"] >= 1.0
    assert un["space_amp"] >= 1.0


def _assert_tradeoff(v: dict) -> None:
    a, b = v["aggressive"], v["lazy"]
    # Leftover L0 is the lazy side's unpaid compact debt, and it shows
    # up in read amplification. Aggressive spends that IO earlier.
    assert a["l0_files"] < b["l0_files"]
    assert a["read_amp"] < b["read_amp"]
    assert a["compact_bytes"] > b["compact_bytes"]
    assert a["write_p99_s"] > 0
    assert b["write_p99_s"] > 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"ASSERTION_FAILED: {exc}", file=sys.stderr)
        raise
