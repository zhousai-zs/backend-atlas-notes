#!/usr/bin/env python3
"""Experiments for lesson 106: LSM tree, SST, and compaction."""
from __future__ import annotations

import json
import sys
from typing import Any

from engine import LSMEngine, Options


DOCS_CHECKED = "2026-11-12"
ROCKSDB_DOCS = (
    "https://github.com/facebook/rocksdb/wiki/Compaction"
    " (301 -> https://github.com/meta/rocksdb/wiki/Compaction, 200); "
    "https://github.com/facebook/rocksdb/wiki/Leveled-Compaction"
    " (301 -> wiki/Leveled-Compaction, 200); "
    "https://github.com/facebook/rocksdb/wiki/Universal-Compaction"
    " (301 -> wiki/Universal-Compaction, 200); "
    "https://github.com/facebook/rocksdb/wiki/Write-Stalls"
    " (301 -> wiki/Write-Stalls, 200); "
    "https://github.com/facebook/rocksdb/wiki/MemTable"
    " (301 -> wiki/MemTable, 200); "
    "https://github.com/facebook/rocksdb/wiki/A-Tutorial-of-RocksDB-SST-formats"
    " (301 -> wiki/A-Tutorial-of-RocksDB-SST-formats, 200)"
)

# Teaching payload used across experiments (same title as earlier lessons).
TITLE = "Weekly digest (revised)"


def _engine(**kwargs: Any) -> LSMEngine:
    return LSMEngine(Options(**kwargs))


def _put_many(eng: LSMEngine, n: int, start: int = 1, interval: float = 0.0, prefix: str = "article") -> None:
    for i in range(start, start + n):
        eng.put(f"{prefix}:{i:03d}:title", f"draft-{i:03d}", write_interval=interval)


def _log_excerpt(eng: LSMEngine, kinds: tuple[str, ...] = ("FLUSH", "COMPACT", "STALL", "STOP", "RESUME", "MEMTABLE_SEAL")) -> list[str]:
    return [line for line in eng.log.lines() if any(f"] {k} " in line or line.endswith(f"] {k}") for k in kinds)]


def experiment_flush_compaction_trace() -> dict[str, Any]:
    """Follow flush and L0->L1 compaction in the visual log."""
    eng = _engine(
        style="level",
        write_buffer_size=200,
        level0_file_num_compaction_trigger=4,
        auto_compact=True,
        compaction_bandwidth=10000,
        level0_slowdown_writes_trigger=80,
        level0_stop_writes_trigger=120,
        soft_pending_compaction_bytes=10**9,
        hard_pending_compaction_bytes=10**9,
    )
    # Enough keys to fill several memtables (about 41 B each) and reach
    # four L0 files, which must trigger L0 -> L1 compaction.
    _put_many(eng, 40, interval=0.01)
    # Point reads after the tree has been rewritten.
    hits = 0
    for i in range(1, 41):
        st, val = eng.get(f"article:{i:03d}:title")
        if st == "ok" and val == f"draft-{i:03d}":
            hits += 1
    tree = eng.tree_shape()
    flush_events = eng.log.of("FLUSH")
    compact_events = eng.log.of("COMPACT")
    return {
        "keys_written": 40,
        "hits": hits,
        "flush_count": len(flush_events),
        "compact_count": len(compact_events),
        "first_flush": flush_events[0] if flush_events else None,
        "first_compact": compact_events[0] if compact_events else None,
        "l0_files_after": tree["levels"][0]["files"],
        "l1_files_after": tree["levels"][1]["files"],
        "l1_bytes_after": tree["levels"][1]["bytes"],
        "tree": tree,
        "visual_log": _log_excerpt(eng),
        "metrics": eng.metrics(),
    }


def experiment_write_stall() -> dict[str, Any]:
    """Same compaction bandwidth, two write rates; watch stall / stop."""
    common = dict(
        style="level",
        write_buffer_size=200,
        max_write_buffer_number=3,
        level0_file_num_compaction_trigger=4,
        level0_slowdown_writes_trigger=8,
        level0_stop_writes_trigger=12,
        max_bytes_for_level_base=800,
        max_bytes_for_level_multiplier=4,
        soft_pending_compaction_bytes=4000,
        hard_pending_compaction_bytes=8000,
        delayed_write_rate=400,
        compaction_bandwidth=800,  # SST output bytes / s; slower than a burst
        auto_compact=True,
    )
    n = 80

    fast = _engine(**common)
    _put_many(fast, n, interval=0.001)  # 1000 writes/s attempted
    for i in range(1, n + 1):
        st, _ = fast.get(f"article:{i:03d}:title")
        assert st == "ok"
    fast_m = fast.metrics()

    slow = _engine(**common)
    _put_many(slow, n, interval=0.15)  # ~6.7 writes/s, compaction can keep up
    for i in range(1, n + 1):
        st, _ = slow.get(f"article:{i:03d}:title")
        assert st == "ok"
    slow_m = slow.metrics()

    return {
        "keys_written": n,
        "compaction_bandwidth": 800,
        "fast": {
            "write_interval_s": 0.001,
            "attempted_rate_per_s": 1000.0,
            "stall_count": fast_m["stall_count"],
            "stop_count": fast_m["stop_count"],
            "stall_seconds": fast_m["stall_seconds"],
            "stop_seconds": fast_m["stop_seconds"],
            "write_p99_s": fast_m["write_p99_s"],
            "write_amp": fast_m["write_amp"],
            "read_amp": fast_m["read_amp"],
            "space_amp": fast_m["space_amp"],
            "l0_peak_events": _peak_l0(fast),
            "stop_reasons": [e.get("reason", "") for e in fast.log.of("STOP")],
            "stall_reasons": [e.get("reason", "") for e in fast.log.of("STALL")],
            "visual_log_head": _log_excerpt(fast)[:30],
            "metrics": fast_m,
        },
        "slow": {
            "write_interval_s": 0.15,
            "attempted_rate_per_s": round(1 / 0.15, 4),
            "stall_count": slow_m["stall_count"],
            "stop_count": slow_m["stop_count"],
            "stall_seconds": slow_m["stall_seconds"],
            "stop_seconds": slow_m["stop_seconds"],
            "write_p99_s": slow_m["write_p99_s"],
            "write_amp": slow_m["write_amp"],
            "read_amp": slow_m["read_amp"],
            "space_amp": slow_m["space_amp"],
            "l0_peak_events": _peak_l0(slow),
            "stop_reasons": [e.get("reason", "") for e in slow.log.of("STOP")],
            "stall_reasons": [e.get("reason", "") for e in slow.log.of("STALL")],
            "visual_log_head": _log_excerpt(slow)[:30],
            "metrics": slow_m,
        },
    }


def _peak_l0(eng: LSMEngine) -> int:
    peak = 0
    for ev in eng.log.events:
        if "l0_or_runs" in ev:
            peak = max(peak, int(ev["l0_or_runs"]))
        if ev["kind"] == "TREE" and "levels" in ev:
            for item in ev["levels"]:
                if item.startswith("L0:"):
                    files = int(item.split(":")[1].split("f")[0])
                    peak = max(peak, files)
    # Also consider the final tree.
    if eng.opts.style == "level":
        peak = max(peak, eng.tree_shape()["levels"][0]["files"])
    return peak


def experiment_tombstones() -> dict[str, Any]:
    """A tombstone may be dropped only at the bottom-most level for that key."""
    eng = _engine(
        style="level",
        write_buffer_size=200,
        auto_compact=False,
        level0_file_num_compaction_trigger=4,
        num_levels=4,
        target_file_size=400,
        # Keep stall thresholds out of the way; this experiment is manual.
        level0_slowdown_writes_trigger=80,
        level0_stop_writes_trigger=120,
        soft_pending_compaction_bytes=10**9,
        hard_pending_compaction_bytes=10**9,
    )
    key = "article:001:title"
    eng.put(key, TITLE)
    sst0 = eng.flush()
    # Push the live value down to L2, so L2 is bottom-most for this key.
    assert eng.force_compact_level(0)  # L0 -> L1
    assert eng.force_compact_level(1)  # L1 -> L2
    tree_after_push = eng.tree_shape()
    st, val = eng.get(key)
    assert st == "ok" and val == TITLE
    l2_has_value = any(s.get(key) and s.get(key).kind == "put" for s in eng.levels[2])

    # Now delete. The tombstone sits in the memtable, then in L0, then L1.
    eng.delete(key)
    st_mem, _ = eng.get(key)
    tomb_l0 = eng.flush()
    st_l0, _ = eng.get(key)
    compact_l0 = eng.force_compact_level(0)  # L0 -> L1; L2 still has the value
    st_l1, _ = eng.get(key)
    mid = eng.log.of("COMPACT")[-1]
    tombstones_in_l1 = sum(s.tombstones for s in eng.levels[1])
    tombstones_in_l2 = sum(s.tombstones for s in eng.levels[2])
    l2_still_has_value = any(
        (s.get(key) is not None and s.get(key).kind == "put") for s in eng.levels[2]
    )
    tree_mid = eng.tree_shape()

    compact_l1 = eng.force_compact_level(1)  # L1 + overlapping L2 -> L2 (bottom-most)
    st_bottom, _ = eng.get(key)
    last = eng.log.of("COMPACT")[-1]
    tombstones_in_l2_after = sum(s.tombstones for s in eng.levels[2])
    any_tombstone = sum(s.tombstones for lv in eng.levels for s in lv)
    tree_end = eng.tree_shape()

    return {
        "key": key,
        "value": TITLE,
        "flushed_to_l0_file": sst0.file_no if sst0 else None,
        "after_push_to_l2": {
            "status": st,
            "value": val,
            "l2_has_value": l2_has_value,
            "l0_files": tree_after_push["levels"][0]["files"],
            "l1_files": tree_after_push["levels"][1]["files"],
            "l2_files": tree_after_push["levels"][2]["files"],
        },
        "after_delete_memtable": {"status": st_mem},
        "tombstone_flushed_file": tomb_l0.file_no if tomb_l0 else None,
        "after_flush_tombstone": {"status": st_l0},
        "compact_l0_to_l1": {
            "did": compact_l0,
            "status": st_l1,
            "tombstones_kept": mid["tombstones_kept"],
            "tombstones_dropped": mid["tombstones_dropped"],
            "tombstones_in_l1": tombstones_in_l1,
            "tombstones_in_l2": tombstones_in_l2,
            "l2_still_has_value": l2_still_has_value,
        },
        "compact_l1_to_l2_bottommost": {
            "did": compact_l1,
            "status": st_bottom,
            "tombstones_kept": last["tombstones_kept"],
            "tombstones_dropped": last["tombstones_dropped"],
            "tombstones_in_l2": tombstones_in_l2_after,
            "any_tombstone_left": any_tombstone,
        },
        "tree_mid": tree_mid,
        "tree_end": tree_end,
        "visual_log": _log_excerpt(eng),
    }


def experiment_amplification() -> dict[str, Any]:
    """Report write / read / space amplification, not just a QPS number.

    Same sequential insert workload under leveled and universal styles,
    plus a reminder that a sequential flush does not make total write
    amplification equal to 1: compaction still rewrites bytes.
    """
    n = 80
    shared = dict(
        write_buffer_size=200,
        level0_file_num_compaction_trigger=4,
        max_bytes_for_level_base=800,
        max_bytes_for_level_multiplier=4,
        target_file_size=400,
        compaction_bandwidth=20000,
        level0_slowdown_writes_trigger=80,
        level0_stop_writes_trigger=120,
        soft_pending_compaction_bytes=10**9,
        hard_pending_compaction_bytes=10**9,
        auto_compact=True,
        universal_size_amp_percent=200,
    )

    leveled = _engine(style="level", **shared)
    _put_many(leveled, n, interval=0.001)
    leveled.settle()
    leveled.compact_all()
    for i in range(1, n + 1):
        leveled.get(f"article:{i:03d}:title")
    lv = leveled.metrics()

    uni = _engine(style="universal", **shared)
    _put_many(uni, n, interval=0.001)
    uni.settle()
    uni.compact_all()
    for i in range(1, n + 1):
        uni.get(f"article:{i:03d}:title")
    un = uni.metrics()

    # Sequential inserts: every flush is already key-ordered, but leveled
    # compaction still rewrites those keys into lower levels.
    seq_user = lv["user_bytes"]
    return {
        "keys_written": n,
        "title_note": "sequential inserts of new article:*:title keys",
        "leveled": {
            "user_bytes": lv["user_bytes"],
            "flush_bytes": lv["flush_bytes"],
            "compact_bytes": lv["compact_bytes"],
            "sst_bytes_written": lv["sst_bytes_written"],
            "write_amp": lv["write_amp"],
            "read_amp": lv["read_amp"],
            "space_amp": lv["space_amp"],
            "live_bytes": lv["live_bytes"],
            "stored_bytes": lv["stored_bytes"],
            "flush_count": lv["flush_count"],
            "compact_count": lv["compact_count"],
            "tree": lv["tree"],
        },
        "universal": {
            "user_bytes": un["user_bytes"],
            "flush_bytes": un["flush_bytes"],
            "compact_bytes": un["compact_bytes"],
            "sst_bytes_written": un["sst_bytes_written"],
            "write_amp": un["write_amp"],
            "read_amp": un["read_amp"],
            "space_amp": un["space_amp"],
            "live_bytes": un["live_bytes"],
            "stored_bytes": un["stored_bytes"],
            "flush_count": un["flush_count"],
            "compact_count": un["compact_count"],
            "tree": un["tree"],
        },
        "sequential_write_amp_split": {
            "user_bytes": seq_user,
            "leveled_flush_bytes": lv["flush_bytes"],
            "leveled_compact_bytes": lv["compact_bytes"],
            "leveled_write_amp": lv["write_amp"],
            "flush_equals_user": lv["flush_bytes"] == seq_user,
            # The pitfall: flush can look "cheap" (sequential, ≈ user bytes)
            # while total SST writes are much larger because of compaction.
        },
    }


def experiment_aggressive_vs_lazy() -> dict[str, Any]:
    """More aggressive compaction improves reads, but spends IO and moves tail latency."""
    n = 70
    base = dict(
        style="level",
        write_buffer_size=200,
        max_bytes_for_level_base=800,
        max_bytes_for_level_multiplier=4,
        target_file_size=400,
        compaction_bandwidth=2000,
        delayed_write_rate=400,
        level0_slowdown_writes_trigger=8,
        level0_stop_writes_trigger=12,
        soft_pending_compaction_bytes=4000,
        hard_pending_compaction_bytes=8000,
        auto_compact=True,
    )
    # Aggressive: compact L0 earlier. Lazy: wait for more L0 files.
    aggressive = _engine(level0_file_num_compaction_trigger=2, **base)
    lazy = _engine(level0_file_num_compaction_trigger=8, **base)
    interval = 0.02
    _put_many(aggressive, n, interval=interval)
    _put_many(lazy, n, interval=interval)
    aggressive.settle()
    lazy.settle()
    # Compact only while each style still exceeds its own L0 trigger,
    # so the lazy side is allowed to keep leftover L0 files.
    aggressive.compact_all()
    lazy.compact_all()
    for i in range(1, n + 1):
        aggressive.get(f"article:{i:03d}:title")
        lazy.get(f"article:{i:03d}:title")
    a = aggressive.metrics()
    b = lazy.metrics()
    return {
        "keys_written": n,
        "write_interval_s": interval,
        "compaction_bandwidth": 2000,
        "aggressive": {
            "level0_file_num_compaction_trigger": 2,
            "l0_files": a["tree"]["levels"][0]["files"],
            "write_amp": a["write_amp"],
            "read_amp": a["read_amp"],
            "space_amp": a["space_amp"],
            "compact_count": a["compact_count"],
            "compact_bytes": a["compact_bytes"],
            "write_p99_s": a["write_p99_s"],
            "stall_count": a["stall_count"],
            "stop_count": a["stop_count"],
            "stall_seconds": a["stall_seconds"],
            "stop_seconds": a["stop_seconds"],
            "tree": a["tree"],
        },
        "lazy": {
            "level0_file_num_compaction_trigger": 8,
            "l0_files": b["tree"]["levels"][0]["files"],
            "write_amp": b["write_amp"],
            "read_amp": b["read_amp"],
            "space_amp": b["space_amp"],
            "compact_count": b["compact_count"],
            "compact_bytes": b["compact_bytes"],
            "write_p99_s": b["write_p99_s"],
            "stall_count": b["stall_count"],
            "stop_count": b["stop_count"],
            "stall_seconds": b["stall_seconds"],
            "stop_seconds": b["stop_seconds"],
            "tree": b["tree"],
        },
    }


def run_all_experiments() -> dict[str, Any]:
    return {
        "flush_compaction_trace": experiment_flush_compaction_trace(),
        "write_stall": experiment_write_stall(),
        "tombstones": experiment_tombstones(),
        "amplification": experiment_amplification(),
        "aggressive_vs_lazy": experiment_aggressive_vs_lazy(),
        "python": sys.version.split()[0],
        "rocksdb_docs": ROCKSDB_DOCS,
        "docs_checked": DOCS_CHECKED,
    }


if __name__ == "__main__":
    data = run_all_experiments()
    json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
