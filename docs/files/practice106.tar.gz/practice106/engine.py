#!/usr/bin/env python3
"""Teaching LSMEngine — not RocksDB.

A Python standard-library model of an LSM tree: updates first go into a
memtable; a full memtable is sealed and flushed into an immutable SST
in L0; compaction then merges sorted runs. The engine can run a
leveled (some-to-some into the next level) style or a simplified
universal / tiered style. Tombstones are dropped only when the
compaction output is bottom-most for that key. Write stalls fire when
immutable memtables, L0 files, or pending compaction bytes cross the
teaching thresholds, and a visual log records flush, compaction, and
stall events.

This is not RocksDB, not Redis, and not a network server. The shape of
memtable / L0 / Ln, the fact that RocksDB's leveled style is
tiered+leveled (flush creates a new L0 run and does not rewrite
existing L0 files), universal being tiered, the three write-stall
causes, and the read / write / space amplification trade-off follow
the RocksDB wiki pages checked on 2026-11-12, for the subset
implemented here. This engine does not implement block-based or
plain-table SST formats, bloom filters, block cache, WAL, MANIFEST,
column families, subcompactions, compaction filters, snapshots,
intra-L0 compaction, dynamic level bytes, FIFO compaction, trivial
move, or RocksDB's exact compaction scoring and file-picking.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional


KIND_PUT = "put"
KIND_DEL = "del"


@dataclass(frozen=True)
class Record:
    key: str
    seq: int
    kind: str
    value: str

    def nbytes(self) -> int:
        # Teaching size: key + value + a fixed per-record header.
        return len(self.key.encode()) + len(self.value.encode()) + 16


@dataclass
class SST:
    file_no: int
    level: int
    records: tuple[Record, ...]
    run_id: int = 0  # universal: each flushed or compacted run has an id

    def __post_init__(self) -> None:
        object.__setattr__(self, "records", tuple(self.records))

    @property
    def smallest(self) -> str:
        return self.records[0].key if self.records else ""

    @property
    def largest(self) -> str:
        return self.records[-1].key if self.records else ""

    @property
    def nbytes(self) -> int:
        return sum(r.nbytes() for r in self.records)

    @property
    def tombstones(self) -> int:
        return sum(1 for r in self.records if r.kind == KIND_DEL)

    def overlaps_key(self, key: str) -> bool:
        if not self.records:
            return False
        return self.smallest <= key <= self.largest

    def overlaps_range(self, lo: str, hi: str) -> bool:
        if not self.records:
            return False
        return not (self.largest < lo or self.smallest > hi)

    def get(self, key: str) -> Optional[Record]:
        lo, hi = 0, len(self.records) - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            rec = self.records[mid]
            if rec.key < key:
                lo = mid + 1
            elif rec.key > key:
                hi = mid - 1
            else:
                return rec
        return None

    def summary(self) -> dict[str, Any]:
        return {
            "file_no": self.file_no,
            "level": self.level,
            "run_id": self.run_id,
            "keys": len(self.records),
            "bytes": self.nbytes,
            "tombstones": self.tombstones,
            "smallest": self.smallest,
            "largest": self.largest,
        }


@dataclass
class MemTable:
    records: dict[str, Record] = field(default_factory=dict)
    sealed: bool = False

    def nbytes(self) -> int:
        return sum(r.nbytes() for r in self.records.values())

    def put(self, rec: Record) -> None:
        if self.sealed:
            raise RuntimeError("immutable memtable is read-only")
        self.records[rec.key] = rec

    def get(self, key: str) -> Optional[Record]:
        return self.records.get(key)

    def sorted_records(self) -> list[Record]:
        return [self.records[k] for k in sorted(self.records)]


@dataclass
class Options:
    write_buffer_size: int = 200
    max_write_buffer_number: int = 3
    level0_file_num_compaction_trigger: int = 4
    level0_slowdown_writes_trigger: int = 8
    level0_stop_writes_trigger: int = 12
    max_bytes_for_level_base: int = 800
    max_bytes_for_level_multiplier: int = 4
    target_file_size: int = 400
    soft_pending_compaction_bytes: int = 4000
    hard_pending_compaction_bytes: int = 8000
    delayed_write_rate: int = 400  # user bytes / simulated second while stalling
    compaction_bandwidth: int = 800  # SST output bytes / simulated second
    style: str = "level"  # "level" or "universal"
    auto_compact: bool = True
    num_levels: int = 4
    universal_size_amp_percent: int = 200
    universal_min_merge: int = 2


class Clock:
    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        self.t = round(self.t + float(seconds), 10)


class VisualLog:
    def __init__(self, clock: Clock) -> None:
        self.clock = clock
        self.events: list[dict[str, Any]] = []

    def emit(self, kind: str, **fields: Any) -> None:
        ev: dict[str, Any] = {"t": round(self.clock.now(), 6), "kind": kind}
        ev.update(fields)
        self.events.append(ev)

    def lines(self) -> list[str]:
        out: list[str] = []
        for ev in self.events:
            kind = ev["kind"]
            rest = {k: v for k, v in ev.items() if k not in ("t", "kind")}
            payload = " ".join(f"{k}={v}" for k, v in rest.items())
            out.append(f"[t={ev['t']:.6f}] {kind} {payload}".rstrip())
        return out

    def kinds(self) -> list[str]:
        return [e["kind"] for e in self.events]

    def of(self, kind: str) -> list[dict[str, Any]]:
        return [e for e in self.events if e["kind"] == kind]


class LSMEngine:
    def __init__(self, options: Optional[Options] = None, clock: Optional[Clock] = None) -> None:
        self.opts = options or Options()
        if self.opts.style not in ("level", "universal"):
            raise ValueError(f"unknown style: {self.opts.style}")
        self.clock = clock or Clock()
        self.log = VisualLog(self.clock)
        self.active = MemTable()
        self.immutables: list[MemTable] = []  # newest last
        self.levels: list[list[SST]] = [[] for _ in range(self.opts.num_levels)]
        # universal: a list of runs, newest first; each run is a list of non-overlapping SSTs
        self.runs: list[list[SST]] = []
        self.next_file = 1
        self.next_seq = 1
        self.next_run = 1
        self.bg_credit = 0.0
        self.stats = {
            "user_writes": 0,
            "user_bytes": 0,
            "flush_bytes": 0,
            "flush_count": 0,
            "compact_bytes": 0,
            "compact_count": 0,
            "sst_bytes_written": 0,
            "get_count": 0,
            "files_touched": 0,
            "stall_count": 0,
            "stop_count": 0,
            "stall_seconds": 0.0,
            "stop_seconds": 0.0,
            "tombstones_kept": 0,
            "tombstones_dropped": 0,
            "versions_dropped": 0,
            "write_latency": [],
        }

    # ------------------------------------------------------------------ stats
    def write_amp(self) -> float:
        ub = self.stats["user_bytes"]
        return round(self.stats["sst_bytes_written"] / ub, 4) if ub else 0.0

    def read_amp(self) -> float:
        gc = self.stats["get_count"]
        return round(self.stats["files_touched"] / gc, 4) if gc else 0.0

    def live_bytes(self) -> int:
        live = 0
        seen: set[str] = set()
        for rec in self._scan_newest_first():
            if rec.key in seen:
                continue
            seen.add(rec.key)
            if rec.kind == KIND_PUT:
                live += rec.nbytes()
        return live

    def stored_bytes(self) -> int:
        n = self.active.nbytes() + sum(m.nbytes() for m in self.immutables)
        if self.opts.style == "level":
            n += sum(s.nbytes for level in self.levels for s in level)
        else:
            n += sum(s.nbytes for run in self.runs for s in run)
        return n

    def space_amp(self) -> float:
        live = self.live_bytes()
        return round(self.stored_bytes() / live, 4) if live else 0.0

    def metrics(self) -> dict[str, Any]:
        lat = self.stats["write_latency"]
        p99 = 0.0
        if lat:
            s = sorted(lat)
            p99 = s[min(len(s) - 1, int(len(s) * 0.99))]
        return {
            "user_writes": self.stats["user_writes"],
            "user_bytes": self.stats["user_bytes"],
            "flush_count": self.stats["flush_count"],
            "flush_bytes": self.stats["flush_bytes"],
            "compact_count": self.stats["compact_count"],
            "compact_bytes": self.stats["compact_bytes"],
            "sst_bytes_written": self.stats["sst_bytes_written"],
            "write_amp": self.write_amp(),
            "read_amp": self.read_amp(),
            "space_amp": self.space_amp(),
            "live_bytes": self.live_bytes(),
            "stored_bytes": self.stored_bytes(),
            "stall_count": self.stats["stall_count"],
            "stop_count": self.stats["stop_count"],
            "stall_seconds": round(self.stats["stall_seconds"], 6),
            "stop_seconds": round(self.stats["stop_seconds"], 6),
            "write_p99_s": round(p99, 6),
            "tombstones_kept": self.stats["tombstones_kept"],
            "tombstones_dropped": self.stats["tombstones_dropped"],
            "versions_dropped": self.stats["versions_dropped"],
            "tree": self.tree_shape(),
        }

    def tree_shape(self) -> dict[str, Any]:
        if self.opts.style == "level":
            levels = []
            for i, files in enumerate(self.levels):
                levels.append({
                    "level": i,
                    "files": len(files),
                    "bytes": sum(s.nbytes for s in files),
                    "tombstones": sum(s.tombstones for s in files),
                    "ssts": [s.summary() for s in files],
                })
            return {
                "style": "level",
                "memtable_bytes": self.active.nbytes(),
                "memtable_keys": len(self.active.records),
                "immutable_memtables": len(self.immutables),
                "levels": levels,
            }
        runs = []
        for i, run in enumerate(self.runs):
            runs.append({
                "run_index": i,
                "run_id": run[0].run_id if run else 0,
                "files": len(run),
                "bytes": sum(s.nbytes for s in run),
                "tombstones": sum(s.tombstones for s in run),
                "ssts": [s.summary() for s in run],
            })
        return {
            "style": "universal",
            "memtable_bytes": self.active.nbytes(),
            "memtable_keys": len(self.active.records),
            "immutable_memtables": len(self.immutables),
            "runs": runs,
            "run_count": len(self.runs),
        }

    # ------------------------------------------------------------------ writes
    def put(self, key: str, value: str, write_interval: float = 0.0) -> dict[str, Any]:
        rec = Record(key, self.next_seq, KIND_PUT, value)
        self.next_seq += 1
        return self._write(rec, write_interval)

    def delete(self, key: str, write_interval: float = 0.0) -> dict[str, Any]:
        rec = Record(key, self.next_seq, KIND_DEL, "")
        self.next_seq += 1
        return self._write(rec, write_interval)

    def _write(self, rec: Record, write_interval: float) -> dict[str, Any]:
        t0 = self.clock.now()
        if write_interval > 0:
            self._background(write_interval)
        status, reason = self._wait_if_needed(rec.nbytes())
        self.active.put(rec)
        self.stats["user_writes"] += 1
        self.stats["user_bytes"] += rec.nbytes()
        self.log.emit("WRITE" if rec.kind == KIND_PUT else "DELETE", key=rec.key, seq=rec.seq)
        if self.active.nbytes() >= self.opts.write_buffer_size:
            self._seal_memtable()
        if self.opts.auto_compact:
            self._drain_available()
        latency = round(self.clock.now() - t0, 6)
        self.stats["write_latency"].append(latency)
        return {"status": status, "reason": reason, "latency_s": latency, "seq": rec.seq}

    def _wait_if_needed(self, incoming_bytes: int) -> tuple[str, str]:
        """Block (stop) or slow down (stall) until the write may proceed."""
        status, reason = "ok", ""
        # Stop first.
        while True:
            stop = self._stop_reason()
            if not stop:
                break
            if status != "stopped":
                self.stats["stop_count"] += 1
                self.log.emit("STOP", reason=stop, **self._pressure())
            status, reason = "stopped", stop
            t0 = self.clock.now()
            # Wait in slices until pressure drops or no more background work.
            slice_t = max(incoming_bytes / max(self.opts.compaction_bandwidth, 1), 0.01)
            progressed = self._background(slice_t, require_work=True)
            self.stats["stop_seconds"] = round(
                self.stats["stop_seconds"] + (self.clock.now() - t0), 6
            )
            if not progressed and self._stop_reason():
                # Deadlock guard: force one job even if credit is short.
                if not self._force_one_job():
                    break
        if status == "stopped" and not self._stop_reason():
            self.log.emit("RESUME", after="stop", **self._pressure())
        # Then stall (slow down).
        stall = self._stall_reason()
        if stall:
            self.stats["stall_count"] += 1
            self.log.emit("STALL", reason=stall, **self._pressure())
            delay = incoming_bytes / max(self.opts.delayed_write_rate, 1)
            t0 = self.clock.now()
            self._background(delay)
            self.stats["stall_seconds"] = round(
                self.stats["stall_seconds"] + (self.clock.now() - t0), 6
            )
            status, reason = "stalled", stall
            self.log.emit("RESUME", after="stall", **self._pressure())
        return status, reason

    def _stop_reason(self) -> str:
        imm = len(self.immutables)
        if imm >= self.opts.max_write_buffer_number:
            return f"stopping writes because we have {imm} immutable memtables (waiting for flush), max_write_buffer_number is set to {self.opts.max_write_buffer_number}"
        # Sealing the active table now would reach the max number of
        # memtables and leave no slot for a new active one.
        if imm >= max(self.opts.max_write_buffer_number - 1, 1) and (
            self.active.nbytes() >= self.opts.write_buffer_size
        ):
            return f"stopping writes because we have {imm} immutable memtables (waiting for flush), max_write_buffer_number is set to {self.opts.max_write_buffer_number}"
        n0 = self._l0_or_run_count()
        if n0 >= self.opts.level0_stop_writes_trigger:
            return f"stopping writes because we have {n0} level-0 files"
        pending = self.pending_compaction_bytes()
        if pending >= self.opts.hard_pending_compaction_bytes:
            return f"stopping writes because of estimated pending compaction bytes {pending}"
        return ""

    def _stall_reason(self) -> str:
        imm = len(self.immutables)
        if (
            self.opts.max_write_buffer_number > 3
            and imm >= self.opts.max_write_buffer_number - 1
        ):
            return f"stalling writes because we have {imm} immutable memtables (waiting for flush), max_write_buffer_number is set to {self.opts.max_write_buffer_number}"
        n0 = self._l0_or_run_count()
        if n0 >= self.opts.level0_slowdown_writes_trigger:
            return f"stalling writes because we have {n0} level-0 files"
        pending = self.pending_compaction_bytes()
        if pending >= self.opts.soft_pending_compaction_bytes:
            return f"stalling writes because of estimated pending compaction bytes {pending}"
        return ""

    def _l0_or_run_count(self) -> int:
        if self.opts.style == "level":
            return len(self.levels[0])
        return len(self.runs)

    def _pressure(self) -> dict[str, Any]:
        return {
            "l0_or_runs": self._l0_or_run_count(),
            "immutable_memtables": len(self.immutables),
            "pending_bytes": self.pending_compaction_bytes(),
        }

    # ------------------------------------------------------------------ flush
    def _seal_memtable(self) -> None:
        if not self.active.records:
            return
        self.active.sealed = True
        self.log.emit(
            "MEMTABLE_SEAL",
            keys=len(self.active.records),
            bytes=self.active.nbytes(),
            immutable_waiting=len(self.immutables) + 1,
        )
        self.immutables.append(self.active)
        self.active = MemTable()

    def settle(self) -> None:
        """Flush every leftover memtable. Does not force extra compaction."""
        if self.active.records:
            self._seal_memtable()
        while self.immutables:
            self._flush_one()

    def flush(self) -> Optional[SST]:
        """Seal the active memtable if needed and flush the oldest immutable."""
        if self.active.records and not self.immutables:
            self._seal_memtable()
        return self._flush_one()

    def _flush_one(self) -> Optional[SST]:
        if not self.immutables:
            return None
        mem = self.immutables.pop(0)
        recs = mem.sorted_records()
        if not recs:
            return None
        sst = self._new_sst(level=0, records=recs, run_id=self.next_run)
        self.next_run += 1
        self._install_flush(sst)
        self.stats["flush_count"] += 1
        self.stats["flush_bytes"] += sst.nbytes
        self.stats["sst_bytes_written"] += sst.nbytes
        self.log.emit(
            "FLUSH",
            file=sst.file_no,
            keys=len(sst.records),
            bytes=sst.nbytes,
            smallest=sst.smallest,
            largest=sst.largest,
        )
        self.log.emit("TREE", **_tree_brief(self.tree_shape()))
        return sst

    def _install_flush(self, sst: SST) -> None:
        if self.opts.style == "level":
            self.levels[0].append(sst)
        else:
            self.runs.insert(0, [sst])  # newest first

    def _new_sst(self, level: int, records: Iterable[Record], run_id: int) -> SST:
        recs = tuple(records)
        sst = SST(file_no=self.next_file, level=level, records=recs, run_id=run_id)
        self.next_file += 1
        return sst

    # ------------------------------------------------------------------ get
    def get(self, key: str) -> tuple[str, str]:
        self.stats["get_count"] += 1
        touched = 0
        rec = self.active.get(key)
        touched += 1  # memtable counts as one source
        if rec is None:
            for mem in reversed(self.immutables):
                touched += 1
                rec = mem.get(key)
                if rec is not None:
                    break
        if rec is None:
            if self.opts.style == "level":
                rec, extra = self._get_leveled(key)
            else:
                rec, extra = self._get_universal(key)
            touched += extra
        self.stats["files_touched"] += touched
        if rec is None or rec.kind == KIND_DEL:
            return "not_found", ""
        return "ok", rec.value

    def _get_leveled(self, key: str) -> tuple[Optional[Record], int]:
        touched = 0
        # L0: files may overlap; newest file (later flush) wins.
        for sst in reversed(self.levels[0]):
            touched += 1
            rec = sst.get(key)
            if rec is not None:
                return rec, touched
        for level in range(1, len(self.levels)):
            for sst in self.levels[level]:
                if sst.overlaps_key(key):
                    touched += 1
                    rec = sst.get(key)
                    return rec, touched
        return None, touched

    def _get_universal(self, key: str) -> tuple[Optional[Record], int]:
        touched = 0
        for run in self.runs:  # newest first
            for sst in run:
                if sst.overlaps_key(key):
                    touched += 1
                    rec = sst.get(key)
                    if rec is not None:
                        return rec, touched
                    break
        return None, touched

    def _scan_newest_first(self) -> Iterable[Record]:
        """Yield records from newest run to oldest, for live-size accounting."""
        yield from self.active.records.values()
        for mem in reversed(self.immutables):
            yield from mem.records.values()
        if self.opts.style == "level":
            for sst in reversed(self.levels[0]):
                yield from sst.records
            for level in range(1, len(self.levels)):
                for sst in self.levels[level]:
                    yield from sst.records
        else:
            for run in self.runs:
                for sst in run:
                    yield from sst.records

    # ------------------------------------------------------------------ compaction
    def pending_compaction_bytes(self) -> int:
        if self.opts.style == "universal":
            return self._universal_pending()
        pending = 0
        trigger = self.opts.level0_file_num_compaction_trigger
        if len(self.levels[0]) >= trigger:
            pending += sum(s.nbytes for s in self.levels[0])
            lo, hi = _span(self.levels[0])
            if lo is not None:
                pending += sum(s.nbytes for s in self.levels[1] if s.overlaps_range(lo, hi))
        for level in range(1, len(self.levels) - 1):
            size = sum(s.nbytes for s in self.levels[level])
            target = self._level_target(level)
            if size > target and self.levels[level]:
                # Teaching estimate: one file plus overlapping next-level files.
                victim = max(self.levels[level], key=lambda s: s.nbytes)
                pending += victim.nbytes
                pending += sum(
                    s.nbytes
                    for s in self.levels[level + 1]
                    if s.overlaps_range(victim.smallest, victim.largest)
                )
        return pending

    def _level_target(self, level: int) -> int:
        if level <= 0:
            return 0
        t = self.opts.max_bytes_for_level_base
        for _ in range(1, level):
            t *= self.opts.max_bytes_for_level_multiplier
        return t

    def compact_once(self) -> bool:
        if self.opts.style == "universal":
            return self._compact_universal()
        return self._compact_leveled()

    def compact_all(self) -> int:
        n = 0
        while self.compact_once():
            n += 1
        return n

    def force_compact_level(self, level: int) -> bool:
        """Compact this level into the next, even if it is under the target.

        Teaching helper for the tombstone experiment; not a RocksDB API.
        """
        if self.opts.style != "level":
            raise RuntimeError("force_compact_level is for leveled style")
        if level < 0 or level >= len(self.levels) - 1:
            return False
        if not self.levels[level]:
            return False
        return self._compact_from_level(level, force=True)

    def _compact_leveled(self) -> bool:
        scores: list[tuple[float, int]] = []
        if len(self.levels[0]) >= self.opts.level0_file_num_compaction_trigger:
            by_files = len(self.levels[0]) / self.opts.level0_file_num_compaction_trigger
            by_size = (
                sum(s.nbytes for s in self.levels[0]) / self.opts.max_bytes_for_level_base
            )
            scores.append((max(by_files, by_size), 0))
        for level in range(1, len(self.levels) - 1):
            target = self._level_target(level)
            size = sum(s.nbytes for s in self.levels[level])
            if size > target:
                scores.append((size / target, level))
        if not scores:
            return False
        scores.sort(reverse=True)
        return self._compact_from_level(scores[0][1], force=False)

    def _compact_from_level(self, level: int, force: bool) -> bool:
        inputs_this = list(self.levels[level]) if level == 0 else []
        if level == 0:
            if not inputs_this:
                return False
            lo, hi = _span(inputs_this)
        else:
            if not self.levels[level]:
                return False
            # some-to-some: pick one file (the largest) and overlapping next.
            victim = max(self.levels[level], key=lambda s: s.nbytes)
            inputs_this = [victim]
            lo, hi = victim.smallest, victim.largest
        assert lo is not None and hi is not None
        next_level = level + 1
        inputs_next = [s for s in self.levels[next_level] if s.overlaps_range(lo, hi)]
        merged, kept, dropped, versions = self._merge(
            inputs_this + inputs_next, output_level=next_level
        )
        outputs = self._split_outputs(merged, next_level, run_id=self.next_run)
        self.next_run += 1
        # Uninstall inputs, install outputs, keep non-overlapping files.
        drop = {id(s) for s in inputs_this + inputs_next}
        self.levels[level] = [s for s in self.levels[level] if id(s) not in drop]
        self.levels[next_level] = [s for s in self.levels[next_level] if id(s) not in drop]
        self.levels[next_level].extend(outputs)
        self.levels[next_level].sort(key=lambda s: s.smallest)
        out_bytes = sum(s.nbytes for s in outputs)
        self.stats["compact_count"] += 1
        self.stats["compact_bytes"] += out_bytes
        self.stats["sst_bytes_written"] += out_bytes
        self.stats["tombstones_kept"] += kept
        self.stats["tombstones_dropped"] += dropped
        self.stats["versions_dropped"] += versions
        self.log.emit(
            "COMPACT",
            style="level",
            from_level=level,
            to_level=next_level,
            force=force,
            inputs=[s.file_no for s in inputs_this + inputs_next],
            outputs=[s.file_no for s in outputs],
            input_bytes=sum(s.nbytes for s in inputs_this + inputs_next),
            output_bytes=out_bytes,
            tombstones_kept=kept,
            tombstones_dropped=dropped,
            versions_dropped=versions,
        )
        self.log.emit("TREE", **_tree_brief(self.tree_shape()))
        return True

    def _merge(
        self, ssts: list[SST], output_level: int
    ) -> tuple[list[Record], int, int, int]:
        """Merge SSTs; keep the newest version of each key.

        A tombstone is dropped only when the output level is bottom-most
        for that key: no overlapping file exists in any lower (higher-
        numbered) level. Older versions of the same key are always
        dropped. Snapshots are not modelled.
        """
        buckets: dict[str, list[Record]] = {}
        for sst in ssts:
            for rec in sst.records:
                buckets.setdefault(rec.key, []).append(rec)
        out: list[Record] = []
        kept = dropped = versions = 0
        for key in sorted(buckets):
            group = sorted(buckets[key], key=lambda r: r.seq, reverse=True)
            newest = group[0]
            versions += len(group) - 1
            if newest.kind == KIND_DEL:
                if self._is_bottommost(key, output_level, ssts):
                    dropped += 1
                    continue
                kept += 1
            out.append(newest)
        return out, kept, dropped, versions

    def _is_bottommost(self, key: str, output_level: int, merging: list[SST]) -> bool:
        merging_ids = {id(s) for s in merging}
        if self.opts.style == "level":
            for level in range(output_level + 1, len(self.levels)):
                for sst in self.levels[level]:
                    if id(sst) in merging_ids:
                        continue
                    if sst.get(key) is not None or sst.overlaps_key(key):
                        # overlaps_key is a range check; confirm the key exists
                        # only when the file actually holds it, otherwise a
                        # neighboring key in the same file would pin a
                        # tombstone forever. Check existence.
                        if sst.get(key) is not None:
                            return False
            return True
        # Universal: bottom-most if no older run (not in this merge) holds the key.
        merging_runs = {s.run_id for s in merging}
        for run in self.runs:
            if not run or run[0].run_id in merging_runs:
                continue
            for sst in run:
                if sst.get(key) is not None:
                    return False
        return True

    def _split_outputs(self, records: list[Record], level: int, run_id: int) -> list[SST]:
        if not records:
            return []
        target = self.opts.target_file_size
        chunks: list[SST] = []
        buf: list[Record] = []
        size = 0
        for rec in records:
            buf.append(rec)
            size += rec.nbytes()
            if size >= target:
                chunks.append(self._new_sst(level, buf, run_id))
                buf, size = [], 0
        if buf:
            chunks.append(self._new_sst(level, buf, run_id))
        return chunks

    # ------------------------------------------------------------------ universal
    def _universal_pending(self) -> int:
        # Teaching estimate: if we are going to merge, cost is the sum of
        # the runs that would be picked (newest similar-sized, or all if
        # size amplification is high).
        if len(self.runs) < self.opts.level0_file_num_compaction_trigger:
            if self._universal_size_amp_percent() <= self.opts.universal_size_amp_percent:
                return 0
        picked = self._pick_universal_runs()
        return sum(s.nbytes for run in picked for s in run)

    def _universal_size_amp_percent(self) -> float:
        if not self.runs:
            return 0.0
        total = sum(s.nbytes for run in self.runs for s in run)
        earliest = sum(s.nbytes for s in self.runs[-1])  # oldest run
        if earliest <= 0:
            return 0.0
        return (total - earliest) / earliest * 100.0

    def _pick_universal_runs(self) -> list[list[SST]]:
        """Pick a set of runs to merge.

        Teaching subset of the wiki algorithm: if size amplification
        (all files except the earliest, over the earliest) exceeds the
        threshold, merge everything. Otherwise, if there are enough
        runs, merge a prefix of similar-sized newest runs (at least
        min_merge).
        """
        if not self.runs:
            return []
        if self._universal_size_amp_percent() > self.opts.universal_size_amp_percent:
            return list(self.runs)
        if len(self.runs) < self.opts.level0_file_num_compaction_trigger:
            return []
        # Similar size: take a contiguous newest prefix whose next run
        # is not dramatically larger (size_ratio-like 100% slack).
        picked = [self.runs[0]]
        for run in self.runs[1:]:
            prev = sum(s.nbytes for s in picked[-1])
            cur = sum(s.nbytes for s in run)
            if cur > prev * 2 and len(picked) >= self.opts.universal_min_merge:
                break
            picked.append(run)
            if len(picked) >= 8:
                break
        if len(picked) < self.opts.universal_min_merge:
            return []
        return picked

    def _compact_universal(self) -> bool:
        picked = self._pick_universal_runs()
        if len(picked) < self.opts.universal_min_merge:
            return False
        files = [s for run in picked for s in run]
        # Output is a new (older than not-picked newer runs) sorted run.
        # Place it at the index of the oldest picked run after removal.
        merged, kept, dropped, versions = self._merge(files, output_level=0)
        outputs = self._split_outputs(merged, level=0, run_id=self.next_run)
        self.next_run += 1
        pick_ids = {id(run[0]) if run else 0 for run in picked}
        # Remove picked runs, insert the new run where the oldest picked was.
        new_runs: list[list[SST]] = []
        inserted = False
        oldest_pick_index = max(self.runs.index(run) for run in picked)
        for i, run in enumerate(self.runs):
            if (run and id(run[0]) in pick_ids) or run in picked:
                if i == oldest_pick_index and not inserted:
                    if outputs:
                        new_runs.append(outputs)
                    inserted = True
                continue
            new_runs.append(run)
        if not inserted and outputs:
            new_runs.append(outputs)
        self.runs = new_runs
        out_bytes = sum(s.nbytes for s in outputs)
        self.stats["compact_count"] += 1
        self.stats["compact_bytes"] += out_bytes
        self.stats["sst_bytes_written"] += out_bytes
        self.stats["tombstones_kept"] += kept
        self.stats["tombstones_dropped"] += dropped
        self.stats["versions_dropped"] += versions
        self.log.emit(
            "COMPACT",
            style="universal",
            runs_merged=len(picked),
            inputs=[s.file_no for s in files],
            outputs=[s.file_no for s in outputs],
            input_bytes=sum(s.nbytes for s in files),
            output_bytes=out_bytes,
            tombstones_kept=kept,
            tombstones_dropped=dropped,
            versions_dropped=versions,
            size_amp_percent=round(self._universal_size_amp_percent(), 2),
        )
        self.log.emit("TREE", **_tree_brief(self.tree_shape()))
        return True

    # ------------------------------------------------------------------ background
    def _drain_available(self) -> None:
        """Spend leftover credit and do any zero-cost bookkeeping jobs."""
        self._run_jobs_with_credit()

    def _background(self, dt: float, require_work: bool = False) -> bool:
        if dt <= 0:
            return False
        self.bg_credit += dt * max(self.opts.compaction_bandwidth, 0)
        did = self._run_jobs_with_credit()
        self.clock.advance(dt)
        if require_work and not did:
            return self._force_one_job()
        return did

    def _run_jobs_with_credit(self) -> bool:
        did = False
        while True:
            cost = self._next_job_cost()
            if cost is None:
                break
            if cost > self.bg_credit:
                break
            self._do_next_job()
            self.bg_credit -= cost
            did = True
        return did

    def _next_job_cost(self) -> Optional[int]:
        if self.immutables:
            return sum(r.nbytes() for r in self.immutables[0].sorted_records())
        if not self.opts.auto_compact:
            return None
        if self.opts.style == "level":
            if self._leveled_has_work():
                return self._estimate_level_compact_cost()
            return None
        picked = self._pick_universal_runs()
        if len(picked) >= self.opts.universal_min_merge:
            return sum(s.nbytes for run in picked for s in run)
        return None

    def _leveled_has_work(self) -> bool:
        if len(self.levels[0]) >= self.opts.level0_file_num_compaction_trigger:
            return True
        for level in range(1, len(self.levels) - 1):
            if sum(s.nbytes for s in self.levels[level]) > self._level_target(level):
                return True
        return False

    def _estimate_level_compact_cost(self) -> int:
        # Approximate output size as input size (before dropping versions).
        if len(self.levels[0]) >= self.opts.level0_file_num_compaction_trigger:
            lo, hi = _span(self.levels[0])
            n = sum(s.nbytes for s in self.levels[0])
            if lo is not None:
                n += sum(s.nbytes for s in self.levels[1] if s.overlaps_range(lo, hi))
            return max(n, 1)
        for level in range(1, len(self.levels) - 1):
            if sum(s.nbytes for s in self.levels[level]) > self._level_target(level):
                victim = max(self.levels[level], key=lambda s: s.nbytes)
                n = victim.nbytes
                n += sum(
                    s.nbytes
                    for s in self.levels[level + 1]
                    if s.overlaps_range(victim.smallest, victim.largest)
                )
                return max(n, 1)
        return 1

    def _do_next_job(self) -> None:
        if self.immutables:
            self._flush_one()
            return
        self.compact_once()

    def _force_one_job(self) -> bool:
        if self._next_job_cost() is None:
            return False
        cost = self._next_job_cost() or 0
        self._do_next_job()
        # Charge time for the forced job.
        dt = cost / max(self.opts.compaction_bandwidth, 1)
        self.clock.advance(dt)
        self.bg_credit = 0.0
        return True


def _span(ssts: list[SST]) -> tuple[Optional[str], Optional[str]]:
    if not ssts:
        return None, None
    return min(s.smallest for s in ssts), max(s.largest for s in ssts)


def _tree_brief(shape: dict[str, Any]) -> dict[str, Any]:
    if shape["style"] == "level":
        return {
            "mem_keys": shape["memtable_keys"],
            "imm": shape["immutable_memtables"],
            "levels": [
                f"L{lv['level']}:{lv['files']}f/{lv['bytes']}B/t{lv['tombstones']}"
                for lv in shape["levels"]
            ],
        }
    return {
        "mem_keys": shape["memtable_keys"],
        "imm": shape["immutable_memtables"],
        "runs": shape["run_count"],
        "run_bytes": [r["bytes"] for r in shape["runs"]],
    }
