#!/usr/bin/env python3
"""Acceptance checks for the lesson 127 protocol-evolution experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, TITLE_V1, TITLE_V2, TITLE_V3, WRITE_S, UPGRADE_S


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "EvolutionEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_etcd"] and r["not_a_real_protocol"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["write_s"] == WRITE_S == 0.05
    assert r["upgrade_s"] == UPGRADE_S == 0.10
    assert r["nodes"] == ["n1", "n2", "n3"]

    m = r["matrix"]
    ids = [c["id"] for c in m["cells"]]
    assert ids == [
        "v1_write_v1_read_v1",
        "v1_write_v1_read_v2",
        "v2_writer_gate_off_writes_v1",
        "v2_write_v2_read_v2",
        "v2_record_v1_reader_refuses",
    ]
    for c in m["cells"][:4]:
        assert c["ok"] and c["title"] == TITLE_V2
    assert m["cells"][0]["write_fmt"] == 1 and m["cells"][0]["t_ack"] == 0.10
    assert m["cells"][1]["cluster_version"] == "v1" and m["cells"][1]["t_ack"] == 0.30
    assert m["cells"][2]["write_fmt"] == 1 and m["cells"][2]["feature_log_v2"] is False
    assert m["cells"][3]["write_fmt"] == 2 and m["cells"][3]["editor"] == "desk"
    assert m["cells"][3]["feature_log_v2"] is True and m["cells"][3]["t_ack"] == 0.55
    bad = m["cells"][4]
    assert bad["ok"] is False and bad["reason"] == "unsupported_format"
    assert bad["title_on_v1"] == TITLE_V2 and bad["new_value"] == TITLE_V3
    assert bad["misread"] is False and bad["unsafe_decode_title"] == TITLE_V3
    assert bad["applied"] == ["n1", "n2"] and bad["t_ack"] == 0.60
    assert m["legal_cells_ok"] and m["gate_off_writes_v1"] and m["gate_on_writes_v2"]
    assert m["old_will_not_misread"]

    h = r["half"]
    assert h["snapshot_t"] == 0.05 and h["snapshot_checksum"] == "efe1be83bdea6938"
    assert h["snapshot_title"] == TITLE_V1
    assert h["write_revised"]["t_ack"] == 0.15 and h["write_revised"]["fmt"] == 1
    assert h["upgrade_n1"]["t_negotiated"] == 0.35 and h["upgrade_n1"]["cluster_version"] == "v1"
    assert h["upgrade_n1"]["state"] == "mixed" and h["upgrade_n1"]["feature_log_v2"] is False
    assert h["upgrade_n2"]["t_negotiated"] == 0.65 and h["upgrade_n2"]["state"] == "mixed"
    assert h["write_half"]["t_ack"] == 0.75 and h["write_half"]["fmt"] == 1
    assert h["write_half"]["applied"] == ["n1", "n2", "n3"]
    assert h["write_half"]["value"] == TITLE_V3
    assert h["downgrade_n2"]["ok"] and h["downgrade_n2"]["t_negotiated"] == 0.95
    assert h["downgrade_n1"]["ok"] and h["downgrade_n1"]["t_negotiated"] == 1.10
    assert h["downgrade_n1"]["state"] == "all_v1"
    assert h["end"]["state"] == "all_v1" and h["end"]["feature_log_v2"] is False
    assert h["read_after_rollback"]["title"] == TITLE_V3
    assert h["read_after_rollback"]["t_ack"] == 1.15
    assert h["rollback_ok"] and h["mixed_stayed_v1"]

    irr = r["irreversible"]
    assert irr["snapshot_checksum"] == "efe1be83bdea6938"
    assert irr["upgrade_n1"]["cluster_version"] == "v1"
    assert irr["upgrade_n2"]["t_negotiated"] == 0.50
    assert irr["upgrade_n3"]["t_negotiated"] == 0.65
    assert irr["upgrade_n3"]["cluster_version"] == "v2"
    assert irr["upgrade_n3"]["feature_log_v2"] is True
    assert irr["write_hotfix"]["fmt"] == 2 and irr["write_hotfix"]["t_ack"] == 0.70
    assert irr["write_hotfix"]["applied"] == ["n1", "n2", "n3"]
    assert irr["downgrade"]["ok"] is False
    assert irr["downgrade"]["reason"] == "cluster_already_v2_and_log_has_v2_records"
    assert irr["downgrade"]["recovery"] == "restore_from_pre_upgrade_snapshot"
    assert irr["downgrade"]["t_ack"] == 0.80
    assert irr["restore"]["ok"] and irr["restore"]["title"] == TITLE_V1
    assert irr["restore"]["t_ack"] == 0.95 and irr["restore"]["cluster_version"] == "v1"
    assert irr["downgrade_refused"] and irr["restore_recovers_snapshot_title"]

    p = r["pitfall"]
    assert p["all_new_passes"] and p["mixed_issue_visible"]
    assert p["all_new"]["write_fmt"] == 2 and p["all_new"]["title"] == TITLE_V2
    assert p["mixed"]["refused"] == [{"node": "n3", "reason": "unsupported_format", "binary": "v1"}]
    assert p["all_new_only_is_insufficient"]

    assert r["acceptance_old_will_not_misread"]
    assert r["acceptance_irreversible_has_restore"]
    assert r["practice_matrix_and_half_rollback"]
    assert r["pitfall_only_test_all_new"]
    assert r["tradeoff_compat_code_shrinks_blast_radius"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
