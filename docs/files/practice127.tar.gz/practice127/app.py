#!/usr/bin/env python3
"""Run the lesson 127 protocol-evolution experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    EDITOR_V2,
    KEY_TITLE,
    NEGOTIATE_S,
    RESTORE_S,
    SNAPSHOT_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    UPGRADE_S,
    WRITE_S,
    EvolutionEngine,
)


def _cell(writer: str, cluster: str, reader: str, rec_fmt: int, result: dict[str, Any]) -> dict[str, Any]:
    return {
        "writer": writer,
        "cluster_version": cluster,
        "reader": reader,
        "record_fmt": rec_fmt,
        "ok": result["ok"],
        "reason": result["reason"],
        "title": result.get("title"),
    }


def run_compat_matrix() -> dict[str, Any]:
    """Four legal cells plus one illegal v2-record vs v1-reader cell."""
    cells = []

    # 1) v1 writes v1, v1 reads
    a = EvolutionEngine()
    w = a.write(TITLE_V2, at=0.00, leader="n1")
    r = a.read("n2")
    cells.append({
        "id": "v1_write_v1_read_v1",
        **_cell("v1", "v1", "v1", 1, r),
        "write_ok": w["ok"],
        "write_fmt": w["fmt"],
        "title": r["title"],
        "t_ack": r["t_ack"],
    })

    # 2) v1 writes v1, v2 reads (upgrade a follower only; cluster stays v1)
    b = EvolutionEngine()
    w = b.write(TITLE_V2, at=0.00, leader="n1")
    b.upgrade("n2", at=0.10)
    r = b.read("n2")
    cells.append({
        "id": "v1_write_v1_read_v2",
        **_cell("v1", b.cluster_version, "v2", 1, r),
        "write_fmt": w["fmt"],
        "title": r["title"],
        "cluster_after_upgrade": b.cluster_version,
        "t_ack": r["t_ack"],
    })

    # 3) v2 binary, cluster still v1 (gate off) writes v1; v1 reads
    c = EvolutionEngine()
    c.upgrade("n1", at=0.00)
    status = c.status()
    w = c.write(TITLE_V2, at=0.20, leader="n1")
    r = c.read("n3")
    cells.append({
        "id": "v2_writer_gate_off_writes_v1",
        **_cell("v2", c.cluster_version, "v1", w["fmt"], r),
        "feature_log_v2": status["feature_log_v2"],
        "write_fmt": w["fmt"],
        "title": r["title"],
        "t_ack": r["t_ack"],
    })

    # 4) all v2, gate on, write v2, v2 reads
    d = EvolutionEngine()
    d.upgrade("n1", at=0.00)
    d.upgrade("n2")
    d.upgrade("n3")
    w = d.write(TITLE_V2, leader="n1")
    r = d.read("n2")
    cells.append({
        "id": "v2_write_v2_read_v2",
        **_cell("v2", d.cluster_version, "v2", w["fmt"], r),
        "feature_log_v2": d.feature_log_v2(),
        "write_fmt": w["fmt"],
        "editor": d.nodes["n2"]["store"][KEY_TITLE].get("editor"),
        "title": r["title"],
        "t_ack": r["t_ack"],
    })

    # 5) cluster v2 writes v2; a leftover v1 member must refuse, not mis-read.
    illegal = EvolutionEngine()
    illegal.write(TITLE_V2, at=0.00)  # v1 fmt revised, all nodes have revised
    illegal.upgrade("n1", at=0.10)
    illegal.upgrade("n2")
    illegal.upgrade("n3")
    # n3 downgrade is refused (cluster already v2). Force a v1 binary *without*
    # rolling the log back, then have n1 (v2, gate on) write hotfix as v2.
    # First restore n3 store/log to pre-v2-cluster state? After the three
    # upgrades no v2 record exists yet. Downgrade is refused because cluster_version
    # is already v2 even with only v1 records (etcd: downgrade not possible once
    # cluster version bumped). Force binary back to v1 on n3 only as a leftover
    # old process, then write hotfix.
    before = illegal.nodes["n3"]["store"][KEY_TITLE]["value"]
    illegal.nodes["n3"]["binary"] = "v1"
    w_bad = illegal.write(TITLE_V3, leader="n1")
    n3 = w_bad["results"]["n3"]
    # Contrast: unsafe decoder would have taken the new title from the v2 record.
    last = [rec for rec in illegal.nodes["n1"]["log"] if rec["fmt"] == 2][-1]
    unsafe_title = illegal.unsafe_decode(last)["value"]

    cells.append({
        "id": "v2_record_v1_reader_refuses",
        "writer": "v2",
        "cluster_version": "v2",
        "reader": "v1",
        "record_fmt": 2,
        "ok": n3["ok"],
        "reason": n3["reason"],
        "title_on_v1": n3["title"],
        "title_before": before,
        "new_value": TITLE_V3,
        "misread": n3["title"] == TITLE_V3,
        "unsafe_decode_title": unsafe_title,
        "applied": w_bad["applied"],
        "refused": w_bad["refused"],
        "t_ack": w_bad["t_ack"],
    })

    old_will_not_misread = (
        cells[-1]["ok"] is False
        and cells[-1]["reason"] == "unsupported_format"
        and cells[-1]["title_on_v1"] == TITLE_V2
        and cells[-1]["title_on_v1"] == cells[-1]["title_before"]
        and cells[-1]["title_on_v1"] != TITLE_V3
        and cells[-1]["unsafe_decode_title"] == TITLE_V3
        and cells[-1]["misread"] is False
        and "n3" not in cells[-1]["applied"]
    )
    legal_ok = all(c["ok"] and c["title"] == TITLE_V2 for c in cells[:4])
    gate_off_writes_v1 = cells[2]["write_fmt"] == 1 and cells[2]["cluster_version"] == "v1"
    gate_on_writes_v2 = cells[3]["write_fmt"] == 2 and cells[3]["record_fmt"] == 2
    return {
        "cells": cells,
        "legal_cells_ok": legal_ok,
        "gate_off_writes_v1": gate_off_writes_v1,
        "gate_on_writes_v2": gate_on_writes_v2,
        "old_will_not_misread": old_will_not_misread,
        "t_end": max(c["t_ack"] for c in cells),
    }


def run_half_upgrade_rollback() -> dict[str, Any]:
    """Upgrade two of three members, confirm cluster stays v1, then roll back."""
    eng = EvolutionEngine()
    snap = eng.snapshot(at=0.00)
    w1 = eng.write(TITLE_V2, at=0.10)
    u1 = eng.upgrade("n1", at=0.20)
    mid1 = eng.status()
    u2 = eng.upgrade("n2", at=0.50)
    mid2 = eng.status()
    w_half = eng.write(TITLE_V3, at=0.70)
    # Half upgraded: n1 n2 are v2, n3 is v1, cluster still v1, writes stay fmt 1.
    d2 = eng.downgrade("n2", at=0.80)
    d1 = eng.downgrade("n1")
    end = eng.status()
    r = eng.read("n3")
    return {
        "snapshot_t": snap.taken_at,
        "snapshot_checksum": snap.checksum,
        "snapshot_title": TITLE_V1,
        "write_revised": {"t_ack": w1["t_ack"], "fmt": w1["fmt"], "ok": w1["ok"]},
        "upgrade_n1": {"t_negotiated": u1["t_negotiated"], "cluster_version": u1["cluster_version"], "state": u1["state"], "feature_log_v2": u1["feature_log_v2"]},
        "after_one": mid1,
        "upgrade_n2": {"t_negotiated": u2["t_negotiated"], "cluster_version": u2["cluster_version"], "state": u2["state"], "feature_log_v2": u2["feature_log_v2"]},
        "after_two": mid2,
        "write_half": {"t_ack": w_half["t_ack"], "fmt": w_half["fmt"], "applied": w_half["applied"], "value": w_half["value"]},
        "downgrade_n2": {"ok": d2["ok"], "t_negotiated": d2.get("t_negotiated"), "cluster_version": d2.get("cluster_version"), "state": d2.get("state")},
        "downgrade_n1": {"ok": d1["ok"], "t_negotiated": d1.get("t_negotiated"), "cluster_version": d1.get("cluster_version"), "state": d1.get("state")},
        "end": end,
        "read_after_rollback": r,
        "rollback_ok": d1["ok"] and d2["ok"] and end["state"] == "all_v1" and end["cluster_version"] == "v1" and end["feature_log_v2"] is False,
        "mixed_stayed_v1": mid2["state"] == "mixed" and mid2["cluster_version"] == "v1" and w_half["fmt"] == 1 and set(w_half["applied"]) == {"n1", "n2", "n3"},
        "t_end": eng.now(),
    }


def run_irreversible_and_restore() -> dict[str, Any]:
    """After a full upgrade the cluster version bumps; binary downgrade is refused; restore from the snapshot."""
    eng = EvolutionEngine()
    snap = eng.snapshot(at=0.00)
    w1 = eng.write(TITLE_V2, at=0.10)
    u1 = eng.upgrade("n1", at=0.20)
    u2 = eng.upgrade("n2")
    u3 = eng.upgrade("n3")
    full = eng.status()
    w2 = eng.write(TITLE_V3)
    after_write = eng.status()
    down = eng.downgrade("n1")
    rest = eng.restore(snap)
    end = eng.status()
    return {
        "snapshot_t": snap.taken_at,
        "snapshot_checksum": snap.checksum,
        "snapshot_title": TITLE_V1,
        "write_revised_ack": w1["t_ack"],
        "upgrade_n1": {"cluster_version": u1["cluster_version"], "state": u1["state"], "t_negotiated": u1["t_negotiated"]},
        "upgrade_n2": {"cluster_version": u2["cluster_version"], "state": u2["state"], "t_negotiated": u2["t_negotiated"]},
        "upgrade_n3": {"cluster_version": u3["cluster_version"], "state": u3["state"], "feature_log_v2": u3["feature_log_v2"], "t_negotiated": u3["t_negotiated"]},
        "after_full": full,
        "write_hotfix": {"t_ack": w2["t_ack"], "fmt": w2["fmt"], "applied": w2["applied"], "editor": EDITOR_V2},
        "after_v2_write": after_write,
        "downgrade": {
            "ok": down["ok"],
            "reason": down.get("reason"),
            "recovery": down.get("recovery"),
            "t_ack": down.get("t_ack"),
        },
        "restore": {
            "ok": rest["ok"],
            "title": rest["title"],
            "checksum": rest["checksum"],
            "cluster_version": rest["cluster_version"],
            "t_start": rest["t_start"],
            "t_ack": rest["t_ack"],
        },
        "end": end,
        "downgrade_refused": down["ok"] is False and down["reason"].startswith("cluster_already_v2"),
        "restore_recovers_snapshot_title": rest["title"] == TITLE_V1 and end["cluster_version"] == "v1" and end["state"] == "all_v1",
        "t_end": eng.now(),
    }


def run_pitfall_all_new_only() -> dict[str, Any]:
    """A cluster that is already all-v2 looks fine; that test alone misses mixed-cluster behavior."""
    full = EvolutionEngine()
    full.upgrade("n1", at=0.00)
    full.upgrade("n2")
    full.upgrade("n3")
    w = full.write(TITLE_V2)
    r = full.read("n2")
    all_new_passes = w["ok"] and w["fmt"] == 2 and r["ok"] and r["title"] == TITLE_V2

    # The same write format against a leftover v1 member is exactly what the
    # all-new test never exercises.
    missed = EvolutionEngine()
    missed.upgrade("n1", at=0.00)
    missed.upgrade("n2")
    missed.upgrade("n3")
    missed.nodes["n3"]["binary"] = "v1"
    # n3 still holds Weekly digest from init (it was v2 only after upgrades,
    # no v2 record yet... actually upgrades don't rewrite the log). Write v2.
    w2 = missed.write(TITLE_V3)
    n3 = w2["results"]["n3"]
    mixed_issue_visible = n3["reason"] == "unsupported_format" and n3["ok"] is False
    return {
        "all_new_passes": all_new_passes,
        "all_new": {"write_fmt": w["fmt"], "read_ok": r["ok"], "title": r["title"], "t_end": full.now()},
        "mixed_issue_visible": mixed_issue_visible,
        "mixed": {"refused": w2["refused"], "applied": w2["applied"], "t_end": missed.now()},
        "all_new_only_is_insufficient": all_new_passes and mixed_issue_visible,
        "t_end": max(full.now(), missed.now()),
    }


def run() -> dict[str, Any]:
    matrix = run_compat_matrix()
    half = run_half_upgrade_rollback()
    irr = run_irreversible_and_restore()
    pit = run_pitfall_all_new_only()
    return {
        "engine": "EvolutionEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_etcd": True,
        "not_a_real_protocol": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "write_s": WRITE_S,
        "upgrade_s": UPGRADE_S,
        "snapshot_s": SNAPSHOT_S,
        "restore_s": RESTORE_S,
        "negotiate_s": NEGOTIATE_S,
        "nodes": ["n1", "n2", "n3"],
        "matrix": matrix,
        "half": half,
        "irreversible": irr,
        "pitfall": pit,
        "acceptance_old_will_not_misread": matrix["old_will_not_misread"],
        "acceptance_irreversible_has_restore": irr["downgrade_refused"] and irr["restore_recovers_snapshot_title"],
        "practice_matrix_and_half_rollback": (
            matrix["legal_cells_ok"]
            and matrix["gate_off_writes_v1"]
            and matrix["gate_on_writes_v2"]
            and half["rollback_ok"]
            and half["mixed_stayed_v1"]
        ),
        "pitfall_only_test_all_new": pit["all_new_only_is_insufficient"],
        "tradeoff_compat_code_shrinks_blast_radius": (
            half["mixed_stayed_v1"]
            and half["rollback_ok"]
            and matrix["gate_off_writes_v1"]
        ),
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
