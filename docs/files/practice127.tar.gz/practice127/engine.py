#!/usr/bin/env python3
"""Teaching EvolutionEngine — not Redis, not etcd, not a real protocol or product.

A Python 3 standard-library model of a three-node teaching KV whose replicated
log has a v1 and a v2 record format. Member binaries may be mixed. The cluster
version is the lowest common binary version and is the feature gate for writing
v2 records. The engine is used to build a read/write compatibility matrix,
simulate a half-cluster upgrade and rollback, and show the recovery path after
an irreversible cluster-version bump.

The named source (checked on 2026-11-14) is the etcd 3.5 upgrade guide
https://etcd.io/docs/v3.5/upgrades/upgrade_3_5/. That page describes mixed
versions operating at the lowest common protocol, new features becoming
available only after every member is upgraded, and downgrade becoming
impossible once the cluster version has been bumped — with a pre-upgrade
snapshot as the remaining recovery path. This engine is not etcd, not an
etcd rolling upgrade, and not a network service. There is no Raft, no WAL,
no TCP, and no real clock. Persistence is a teaching dict flush, not fsync.
Clock is virtual. write_s, upgrade_s, snapshot_s, restore_s, and
negotiate_s are teaching delays, not production RTT. The guide does not use
the words "feature gate" or "migration state machine"; those names come from
this node. The v1/v2 log format is a teaching format, not etcd's WAL or
mvcc db.
"""
from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
NODES = ("n1", "n2", "n3")
WRITE_S = 0.05
UPGRADE_S = 0.10
SNAPSHOT_S = 0.05
RESTORE_S = 0.10
NEGOTIATE_S = 0.05
EDITOR_V2 = "desk"


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


def checksum_log(log: list[dict[str, Any]]) -> str:
    blob = json.dumps(log, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class Snapshot:
    taken_at: float
    logs: dict[str, list[dict[str, Any]]]
    stores: dict[str, dict[str, Any]]
    checksum: str
    cluster_version: str


class EvolutionEngine:
    def __init__(
        self,
        *,
        write_s: float = WRITE_S,
        upgrade_s: float = UPGRADE_S,
        snapshot_s: float = SNAPSHOT_S,
        restore_s: float = RESTORE_S,
        negotiate_s: float = NEGOTIATE_S,
        title: str = TITLE_V1,
    ) -> None:
        self.clock = Clock()
        self.write_s = float(write_s)
        self.upgrade_s = float(upgrade_s)
        self.snapshot_s = float(snapshot_s)
        self.restore_s = float(restore_s)
        self.negotiate_s = float(negotiate_s)
        self.key = KEY_TITLE
        self.events: list[dict[str, Any]] = []
        self.snapshots: list[Snapshot] = []
        self.flush_count = 0
        self.nodes: dict[str, dict[str, Any]] = {}
        rec = self._record_v1(KEY_TITLE, title, version=1)
        for name in NODES:
            store = {KEY_TITLE: {"value": title, "version": 1, "fmt": 1}}
            self.nodes[name] = {
                "name": name,
                "binary": "v1",
                "log": [dict(rec)],
                "store": store,
            }
        self.cluster_version = "v1"
        self._event("init", cluster_version="v1", feature_log_v2=False)

    def now(self) -> float:
        return ts(self.clock.now())

    def advance(self, t: float) -> None:
        self.clock.wait_until(float(t))

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def feature_log_v2(self) -> bool:
        return self.cluster_version == "v2"

    def migration_state(self) -> str:
        binaries = [self.nodes[n]["binary"] for n in NODES]
        n_v2 = sum(1 for b in binaries if b == "v2")
        if n_v2 == 0:
            return "all_v1"
        if n_v2 < len(NODES):
            return "mixed"
        if self.cluster_version == "v2":
            return "all_v2"
        return "all_binaries_v2_pending"

    def _negotiate(self) -> str:
        self.clock.wait_until(self.clock.now() + self.negotiate_s)
        lowest = "v1" if any(self.nodes[n]["binary"] == "v1" for n in NODES) else "v2"
        prev = self.cluster_version
        self.cluster_version = lowest
        self._event(
            "negotiate",
            from_version=prev,
            cluster_version=lowest,
            feature_log_v2=self.feature_log_v2(),
            state=self.migration_state(),
        )
        return lowest

    def _record_v1(self, key: str, value: str, *, version: int) -> dict[str, Any]:
        return {"fmt": 1, "key": key, "value": value, "version": version}

    def _record_v2(self, key: str, value: str, *, version: int, editor: str = EDITOR_V2) -> dict[str, Any]:
        return {"fmt": 2, "key": key, "value": value, "version": version, "editor": editor}

    def _decode(self, binary: str, rec: dict[str, Any]) -> tuple[bool, Optional[dict[str, Any]], str]:
        """Return (ok, applied_store_item, reason). Never silently invent a title."""
        fmt = rec.get("fmt")
        if fmt == 1:
            return True, {"value": rec["value"], "version": rec["version"], "fmt": 1}, "ok"
        if fmt == 2:
            if binary == "v2":
                return True, {
                    "value": rec["value"],
                    "version": rec["version"],
                    "fmt": 2,
                    "editor": rec.get("editor"),
                }, "ok"
            return False, None, "unsupported_format"
        return False, None, "unknown_format"

    def unsafe_decode(self, rec: dict[str, Any]) -> dict[str, Any]:
        """Anti-pattern: ignore fmt and blindly take fields. May mis-read a v2 record."""
        return {"value": rec.get("value"), "version": rec.get("version"), "fmt": rec.get("fmt")}

    def write(
        self,
        value: str,
        *,
        at: Optional[float] = None,
        leader: str = "n1",
        force_fmt: Optional[int] = None,
    ) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        t0 = self.clock.now()
        leader_bin = self.nodes[leader]["binary"]
        cur_ver = self.nodes[leader]["store"][self.key]["version"]
        version = cur_ver + 1
        if force_fmt is None:
            fmt = 2 if (leader_bin == "v2" and self.feature_log_v2()) else 1
        else:
            fmt = int(force_fmt)
        if fmt == 2:
            rec = self._record_v2(self.key, value, version=version)
        else:
            rec = self._record_v1(self.key, value, version=version)

        results: dict[str, Any] = {}
        applied = []
        refused = []
        for name, node in self.nodes.items():
            ok, item, reason = self._decode(node["binary"], rec)
            if ok and item is not None:
                node["log"].append(dict(rec))
                node["store"][self.key] = item
                self.flush_count += 1
                applied.append(name)
                results[name] = {"ok": True, "reason": reason, "title": item["value"], "fmt": rec["fmt"]}
            else:
                refused.append({"node": name, "reason": reason, "binary": node["binary"]})
                results[name] = {"ok": False, "reason": reason, "title": node["store"][self.key]["value"], "fmt": rec["fmt"]}
        self.clock.wait_until(t0 + self.write_s)
        # Acceptance: a v1 node that refused a v2 record must still hold the previous title.
        misread = []
        for item in refused:
            held = self.nodes[item["node"]]["store"][self.key]["value"]
            if held == value and rec["fmt"] == 2 and item["binary"] == "v1":
                misread.append(item["node"])
        ev = self._event(
            "write",
            value=value,
            fmt=rec["fmt"],
            version=version,
            leader=leader,
            leader_binary=leader_bin,
            cluster_version=self.cluster_version,
            feature_log_v2=self.feature_log_v2(),
            applied=applied,
            refused=refused,
            misread=misread,
            latency=ts(self.write_s),
        )
        ev["ok"] = len(applied) > 0
        ev["results"] = results
        ev["t_start"] = ts(t0)
        ev["t_ack"] = self.now()
        return ev

    def read(self, node: str, *, at: Optional[float] = None, last: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        t0 = self.clock.now()
        target = last if last is not None else (self.nodes[node]["log"][-1] if self.nodes[node]["log"] else None)
        if target is None:
            self.clock.wait_until(t0 + self.write_s)
            return self._event("read", node=node, ok=False, reason="empty", title=None)
        ok, item, reason = self._decode(self.nodes[node]["binary"], target)
        self.clock.wait_until(t0 + self.write_s)
        title = item["value"] if ok and item else self.nodes[node]["store"][self.key]["value"]
        # If refused, report stored title (previous), never a guessed new value.
        rec = self._event(
            "read",
            node=node,
            binary=self.nodes[node]["binary"],
            ok=ok,
            reason=reason,
            title=title if ok else self.nodes[node]["store"][self.key]["value"],
            fmt=target.get("fmt"),
            latency=ts(self.write_s),
        )
        rec["t_start"] = ts(t0)
        rec["t_ack"] = self.now()
        if not ok:
            rec["would_have_misread"] = self.unsafe_decode(target).get("value")
        return rec

    def upgrade(self, node: str, *, at: Optional[float] = None) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        if self.nodes[node]["binary"] == "v2":
            return self._event("upgrade", node=node, ok=False, reason="already_v2")
        t0 = self.clock.now()
        self.clock.wait_until(t0 + self.upgrade_s)
        self.nodes[node]["binary"] = "v2"
        ev = self._event("upgrade", node=node, ok=True, binary="v2", t_start=ts(t0), t_ack=self.now())
        self._negotiate()
        ev["cluster_version"] = self.cluster_version
        ev["feature_log_v2"] = self.feature_log_v2()
        ev["state"] = self.migration_state()
        ev["t_negotiated"] = self.now()
        return ev

    def downgrade(self, node: str, *, at: Optional[float] = None) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        t0 = self.clock.now()
        self.clock.wait_until(t0 + self.upgrade_s)
        has_v2 = any(rec.get("fmt") == 2 for rec in self.nodes[node]["log"])
        if self.cluster_version == "v2":
            reason = "cluster_already_v2"
            if has_v2:
                reason = "cluster_already_v2_and_log_has_v2_records"
            ev = self._event(
                "downgrade",
                node=node,
                ok=False,
                reason=reason,
                recovery="restore_from_pre_upgrade_snapshot",
                t_start=ts(t0),
                t_ack=self.now(),
            )
            return ev
        if has_v2:
            ev = self._event(
                "downgrade",
                node=node,
                ok=False,
                reason="log_has_v2_records",
                recovery="restore_from_pre_upgrade_snapshot",
                t_start=ts(t0),
                t_ack=self.now(),
            )
            return ev
        if self.nodes[node]["binary"] == "v1":
            return self._event("downgrade", node=node, ok=False, reason="already_v1", t_start=ts(t0))
        self.nodes[node]["binary"] = "v1"
        ev = self._event("downgrade", node=node, ok=True, binary="v1", t_start=ts(t0), t_ack=self.now())
        self._negotiate()
        ev["cluster_version"] = self.cluster_version
        ev["feature_log_v2"] = self.feature_log_v2()
        ev["state"] = self.migration_state()
        ev["t_negotiated"] = self.now()
        return ev

    def snapshot(self, *, at: Optional[float] = None) -> Snapshot:
        if at is not None:
            self.advance(at)
        t0 = self.clock.now()
        self.clock.wait_until(t0 + self.snapshot_s)
        logs = {n: copy.deepcopy(self.nodes[n]["log"]) for n in NODES}
        stores = {n: copy.deepcopy(self.nodes[n]["store"]) for n in NODES}
        chk = checksum_log(logs["n1"])
        snap = Snapshot(
            taken_at=self.now(),
            logs=logs,
            stores=stores,
            checksum=chk,
            cluster_version=self.cluster_version,
        )
        self.snapshots.append(snap)
        self._event("snapshot", checksum=chk, cluster_version=self.cluster_version, title=stores["n1"][self.key]["value"])
        return snap

    def restore(self, snap: Snapshot, *, binaries: str = "v1", at: Optional[float] = None) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        t0 = self.clock.now()
        self.clock.wait_until(t0 + self.restore_s)
        for n in NODES:
            self.nodes[n]["log"] = copy.deepcopy(snap.logs[n])
            self.nodes[n]["store"] = copy.deepcopy(snap.stores[n])
            self.nodes[n]["binary"] = binaries
        self.cluster_version = "v1" if binaries == "v1" else snap.cluster_version
        self._negotiate()
        title = self.nodes["n1"]["store"][self.key]["value"]
        ev = self._event(
            "restore",
            ok=True,
            checksum=snap.checksum,
            title=title,
            cluster_version=self.cluster_version,
            binaries=binaries,
            t_start=ts(t0),
            t_ack=self.now(),
        )
        return ev

    def titles(self) -> dict[str, Any]:
        return {
            n: {
                "binary": self.nodes[n]["binary"],
                "title": self.nodes[n]["store"][self.key]["value"],
                "version": self.nodes[n]["store"][self.key]["version"],
                "fmt": self.nodes[n]["store"][self.key]["fmt"],
                "log_len": len(self.nodes[n]["log"]),
                "max_fmt": max((r.get("fmt") or 1) for r in self.nodes[n]["log"]),
            }
            for n in NODES
        }

    def status(self) -> dict[str, Any]:
        return {
            "t": self.now(),
            "cluster_version": self.cluster_version,
            "feature_log_v2": self.feature_log_v2(),
            "state": self.migration_state(),
            "nodes": self.titles(),
        }
