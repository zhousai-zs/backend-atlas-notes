#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["scripted_policy_is_llm"] is False
assert r["happy"]["state"]=="completed"
assert r["restart_idempotent"]["body_unchanged"]
assert r["self_report_without_file"]["state"]=="failed"
assert r["shared_auth_bob_write"]["reason"]=="unauthorized"
assert r["budget"]["stop_reason"]=="budget_exhausted"
assert r["cancel"]["state"]=="cancelled"
print("POSTCHECK_OK")
PY
