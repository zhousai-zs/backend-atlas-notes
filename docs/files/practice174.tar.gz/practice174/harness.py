"""Minimal Agent Harness: state machine, SQLite events, shared auth, idempotent side effects.

The policy is a scripted sequence of tool calls, not an LLM.
"""

from __future__ import annotations

import json
import sqlite3
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "reports" / "harness.db"
WORK = ROOT / "workspace"
STATES = ("ready", "running", "waiting", "failed", "cancelled", "completed")

# Shared authorization layer — every tool goes through this.
ACL = {"alice": {"read_file", "write_report"}, "bob": {"read_file"}}


@dataclass
class Auth:
    user: str

    def allow(self, tool: str) -> bool:
        return tool in ACL.get(self.user, set())


class Store:
    def __init__(self, path: Path = DB):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS tasks(
                task_id TEXT PRIMARY KEY, state TEXT, goal TEXT, user TEXT,
                steps INTEGER, started REAL, stopped REAL, stop_reason TEXT,
                checkpoint TEXT)"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, t REAL,
                from_state TEXT, to_state TEXT, reason TEXT, call_id TEXT, detail TEXT)"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS artifacts(
                idem_key TEXT PRIMARY KEY, task_id TEXT, path TEXT, body TEXT, t REAL)"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS originals(
                id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, call_id TEXT, body TEXT)"""
        )
        self.conn.commit()

    def upsert_task(self, rec: dict):
        self.conn.execute(
            """INSERT INTO tasks(task_id,state,goal,user,steps,started,stopped,stop_reason,checkpoint)
               VALUES(:task_id,:state,:goal,:user,:steps,:started,:stopped,:stop_reason,:checkpoint)
               ON CONFLICT(task_id) DO UPDATE SET
                 state=excluded.state, steps=excluded.steps, stopped=excluded.stopped,
                 stop_reason=excluded.stop_reason, checkpoint=excluded.checkpoint""",
            rec,
        )
        self.conn.commit()

    def get_task(self, task_id: str) -> dict | None:
        row = self.conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
        if not row:
            return None
        cols = [c[0] for c in self.conn.execute("PRAGMA table_info(tasks)")]
        return dict(zip(cols, row))

    def event(self, task_id, frm, to, reason, call_id=None, detail=None):
        self.conn.execute(
            "INSERT INTO events(task_id,t,from_state,to_state,reason,call_id,detail) VALUES(?,?,?,?,?,?,?)",
            (task_id, time.time(), frm, to, reason, call_id, json.dumps(detail) if not isinstance(detail, str) and detail is not None else detail),
        )
        self.conn.commit()

    def events(self, task_id):
        cols = ["id", "task_id", "t", "from_state", "to_state", "reason", "call_id", "detail"]
        return [dict(zip(cols, r)) for r in self.conn.execute("SELECT * FROM events WHERE task_id=? ORDER BY id", (task_id,))]


def trim(text: str, limit: int = 200) -> tuple[str, bool]:
    if len(text) <= limit:
        return text, False
    return text[:limit] + f"\n[truncated original_len={len(text)}]", True


class Harness:
    def __init__(self, store: Store, auth: Auth, *, max_steps=8, budget_s=30.0):
        self.store = store
        self.auth = auth
        self.max_steps = max_steps
        self.budget_s = budget_s

    def create(self, task_id: str, goal: str) -> dict:
        rec = dict(task_id=task_id, state="ready", goal=goal, user=self.auth.user, steps=0, started=time.time(), stopped=None, stop_reason=None, checkpoint=None)
        self.store.upsert_task(rec)
        self.store.event(task_id, None, "ready", "created")
        return rec

    def _transit(self, rec, to, reason, call_id=None, detail=None):
        frm = rec["state"]
        rec["state"] = to
        self.store.event(rec["task_id"], frm, to, reason, call_id, detail)
        self.store.upsert_task(rec)
        return rec

    def _tool_read(self, path: str) -> str:
        p = (WORK / path).resolve()
        if not str(p).startswith(str(WORK.resolve())):
            raise PermissionError("path_outside_workspace")
        return p.read_text()

    def _tool_write_report(self, path: str, body: str, idem_key: str) -> dict:
        existing = self.store.conn.execute("SELECT path, body FROM artifacts WHERE idem_key=?", (idem_key,)).fetchone()
        if existing:
            return {"wrote": False, "reused": True, "path": existing[0]}
        dest = WORK / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(body)
        self.store.conn.execute(
            "INSERT INTO artifacts(idem_key,task_id,path,body,t) VALUES(?,?,?,?,?)",
            (idem_key, "pending", str(dest), body, time.time()),
        )
        self.store.conn.commit()
        return {"wrote": True, "reused": False, "path": str(dest)}

    def run(self, rec: dict, policy, *, cancel=False) -> dict:
        rec = self._transit(rec, "running", "start") if rec["state"] in {"ready", "waiting"} else rec
        t0 = rec["started"] or time.time()
        while rec["state"] == "running":
            if cancel:
                rec["stopped"] = time.time()
                rec["stop_reason"] = "cancel"
                return self._transit(rec, "cancelled", "cancel")
            if rec["steps"] >= self.max_steps or (time.time() - t0) > self.budget_s:
                rec["stopped"] = time.time()
                rec["stop_reason"] = "budget_exhausted" if rec["steps"] >= self.max_steps or True else "deadline"
                rec["stop_reason"] = "budget_exhausted"
                return self._transit(rec, "failed", "budget_exhausted")
            action = policy(rec)
            if action is not None and action.get("name") == "wait":
                rec["stop_reason"] = "waiting_for_input"
                return self._transit(rec, "waiting", action.get("reason", "wait"))
            if action is None or action.get("name") == "stop":
                # Independent acceptance, not the model's word.
                return self._accept(rec, action or {})
            tool = action["name"]
            call_id = action.get("call_id") or f"call-{uuid.uuid4().hex[:8]}"
            rec["steps"] += 1
            if not self.auth.allow(tool):
                rec["stopped"] = time.time()
                rec["stop_reason"] = "unauthorized"
                return self._transit(rec, "failed", "unauthorized", call_id, {"tool": tool})
            try:
                if tool == "read_file":
                    raw = self._tool_read(action["path"])
                    shown, was_trim = trim(raw)
                    self.store.conn.execute("INSERT INTO originals(task_id,call_id,body) VALUES(?,?,?)", (rec["task_id"], call_id, raw))
                    self.store.conn.commit()
                    rec["checkpoint"] = json.dumps({"last_read": shown, "truncated": was_trim, "call_id": call_id})
                    self.store.event(rec["task_id"], "running", "running", "tool_ok", call_id, {"tool": tool, "truncated": was_trim})
                elif tool == "write_report":
                    out = self._tool_write_report(action["path"], action["body"], action["idem_key"])
                    self.store.conn.execute("UPDATE artifacts SET task_id=? WHERE idem_key=?", (rec["task_id"], action["idem_key"]))
                    self.store.conn.commit()
                    rec["checkpoint"] = json.dumps({"write": out, "call_id": call_id})
                    self.store.event(rec["task_id"], "running", "running", "tool_ok", call_id, {"tool": tool, "reused": out["reused"]})
                else:
                    rec["stopped"] = time.time()
                    rec["stop_reason"] = "unknown_tool"
                    return self._transit(rec, "failed", "unknown_tool", call_id)
                self.store.upsert_task(rec)
            except Exception as e:
                rec["stopped"] = time.time()
                rec["stop_reason"] = type(e).__name__
                return self._transit(rec, "failed", "tool_error", call_id, {"error": str(e)})
        return rec

    def _accept(self, rec, action) -> dict:
        """Completion requires the report file to exist. Self-reported success is ignored."""
        claimed = action.get("claimed_success", False)
        expected = WORK / action.get("expect_path", "report.md")
        rec["stopped"] = time.time()
        rec["stop_reason"] = "accepted" if expected.is_file() else "acceptance_failed"
        if expected.is_file():
            return self._transit(rec, "completed", "file_verified", detail={"claimed_success": claimed, "path": str(expected)})
        return self._transit(rec, "failed", "acceptance_failed_missing_file", detail={"claimed_success": claimed, "path": str(expected)})
