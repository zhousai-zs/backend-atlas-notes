# 实践 174：Agent Harness 的组成

在解压后的 `practice174/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（标准库 + sqlite3）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

策略是脚本化的确定性规则，scripted_policy_is_llm=false，不调用外部模型。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
