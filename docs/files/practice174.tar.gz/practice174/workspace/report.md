kv-node-7 OOM_KILL
