#!/usr/bin/env python3
"""Acceptance checks for practice115 (CAP and choices under partition)."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments
from engine import KEY_TITLE, LOCAL_STEP_S, REPLICATE_DELAY_S, TITLE_V1, TITLE_V2, TITLE_V3, WAIT_S


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert(data["title_v1"] == TITLE_V1, "title v1 is Weekly digest")
    _assert(data["title_v2"] == TITLE_V2, "title v2 is Weekly digest (revised)")
    _assert(data["title_v3"] == TITLE_V3, "title v3 is Weekly digest (hotfix)")
    _assert(data["key"] == KEY_TITLE, "key is article:01:title")
    _assert(data["local_step_s"] == LOCAL_STEP_S, "local step is 0.01s")
    _assert(data["replicate_delay_s"] == REPLICATE_DELAY_S, "replicate delay is 0.08s")
    _assert(data["wait_s"] == WAIT_S, "wait_s is 0.05s")
    _assert(data["not_redis"] is True, "engine is not Redis")
    _assert(data["not_a_network_service"] is True, "engine is not a network service")
    _assert(data["not_raft"] is True, "engine is not Raft")

    wb = data["no_partition_wait_both"]
    _assert(wb["partitioned_during_write"] is False, "wait_both has no partition")
    _assert(wb["set_inv_s"] == 0.0, "wait_both SET starts at 0.0")
    _assert(wb["set_ret_s"] == 0.1, "wait_both SET returns at 0.10")
    _assert(wb["set_latency_s"] == 0.1, "wait_both latency is 0.10")
    _assert(wb["set_status"] == "ok", "wait_both SET is ok")
    _assert(wb["replicas_at_set_return"]["r1"] == TITLE_V2, "wait_both r1 is v2 at return")
    _assert(wb["replicas_at_set_return"]["r2"] == TITLE_V2, "wait_both r2 is v2 at return")
    _assert(wb["get_r1_value"] == TITLE_V2, "wait_both GET r1 is v2")
    _assert(wb["get_r2_value"] == TITLE_V2, "wait_both GET r2 is v2")
    _assert(wb["cap_available"] is True, "wait_both is CAP-available")
    _assert(wb["conflict"] is False, "wait_both has no conflict")

    la = data["no_partition_local_ack"]
    _assert(la["partitioned_during_write"] is False, "local_ack has no partition")
    _assert(la["set_inv_s"] == 0.0, "local_ack SET starts at 0.0")
    _assert(la["set_ret_s"] == 0.02, "local_ack SET returns at 0.02")
    _assert(la["set_latency_s"] == 0.02, "local_ack latency is 0.02")
    _assert(la["set_status"] == "ok", "local_ack SET is ok")
    _assert(la["replicas_at_set_return"]["r1"] == TITLE_V2, "local_ack r1 is v2 at return")
    _assert(la["replicas_at_set_return"]["r2"] == TITLE_V1, "local_ack r2 is still v1 at return")
    _assert(la["get_r2_before_copy_inv_s"] == 0.02, "stale GET starts at 0.02")
    _assert(la["get_r2_before_copy_ret_s"] == 0.04, "stale GET returns at 0.04")
    _assert(la["get_r2_before_copy_value"] == TITLE_V1, "GET on r2 before copy is v1")
    _assert(la["async_copy_applied_at"] == 0.09, "async copy applies at 0.09")
    _assert(la["replicas_after_copy"]["r1"] == TITLE_V2, "after copy r1 is v2")
    _assert(la["replicas_after_copy"]["r2"] == TITLE_V2, "after copy r2 is v2")
    _assert(la["get_r2_after_copy_inv_s"] == 0.09, "fresh GET starts at 0.09")
    _assert(la["get_r2_after_copy_ret_s"] == 0.11, "fresh GET returns at 0.11")
    _assert(la["get_r2_after_copy_value"] == TITLE_V2, "GET on r2 after copy is v2")

    lat = data["no_partition_latency"]
    _assert(lat["wait_both_latency_s"] == 0.1, "compared wait_both latency 0.10")
    _assert(lat["local_ack_latency_s"] == 0.02, "compared local_ack latency 0.02")
    _assert(lat["latencies_differ"] is True, "the two latencies differ")
    _assert(lat["wait_both_slower"] is True, "waiting for both is slower")
    _assert(lat["no_partition_in_either_path"] is True, "neither path was partitioned")
    _assert(lat["both_sets_ok"] is True, "both no-partition SETs succeeded")
    _assert(
        lat["acceptance_cap_does_not_decide_latency_without_partition"] is True,
        "acceptance: CAP does not decide latency without a partition",
    )

    rf = data["partition_refuse_write"]
    _assert(rf["partitioned_during_write"] is True, "refuse path is partitioned")
    _assert(rf["set_r1_inv_s"] == 0.0, "refuse SET r1 starts at 0.0")
    _assert(rf["set_r1_ret_s"] == 0.05, "refuse SET r1 returns at 0.05")
    _assert(rf["set_r1_status"] == "rejected", "refuse SET r1 is rejected")
    _assert(rf["set_r1_note"] == "peer_unreachable", "refuse SET r1 is peer_unreachable")
    _assert(rf["replicas_after_set_r1"]["r1"] == TITLE_V1, "r1 unchanged after rejected SET")
    _assert(rf["replicas_after_set_r1"]["r2"] == TITLE_V1, "r2 unchanged after rejected SET on r1")
    _assert(rf["set_r2_inv_s"] == 0.06, "refuse SET r2 starts at 0.06")
    _assert(rf["set_r2_ret_s"] == 0.11, "refuse SET r2 returns at 0.11")
    _assert(rf["set_r2_status"] == "rejected", "refuse SET r2 is rejected")
    _assert(rf["set_r2_note"] == "peer_unreachable", "refuse SET r2 is peer_unreachable")
    _assert(rf["get_r1_inv_s"] == 0.11, "refuse GET r1 starts at 0.11")
    _assert(rf["get_r1_ret_s"] == 0.13, "refuse GET r1 returns at 0.13")
    _assert(rf["get_r1_value"] == TITLE_V1, "refuse GET r1 is Weekly digest")
    _assert(rf["get_r2_inv_s"] == 0.13, "refuse GET r2 starts at 0.13")
    _assert(rf["get_r2_ret_s"] == 0.15, "refuse GET r2 returns at 0.15")
    _assert(rf["get_r2_value"] == TITLE_V1, "refuse GET r2 is Weekly digest")
    _assert(rf["conflict"] is False, "refuse path has no conflict")
    _assert(rf["cap_available_for_sets"] is False, "refuse SETs are not CAP-available")
    _assert(rf["sla_got_a_reply_for_sets"] is True, "refuse SETs still got a reply")
    _assert(rf["pitfall_sla_is_not_cap_availability"] is True, "SLA reply is not CAP availability")
    _assert(rf["linearizable_no_successful_conflicting_writes"] is True, "no successful conflicting writes")
    _assert(rf["replicas_were_not_failed"] is True, "replicas were not crashed")
    _assert(rf["user_visible"]["set_r1"] == "rejected", "user sees SET r1 rejected")
    _assert(rf["user_visible"]["set_r2"] == "rejected", "user sees SET r2 rejected")
    _assert(rf["user_visible"]["title_on_r1"] == TITLE_V1, "user sees old title on r1")
    _assert(rf["user_visible"]["title_on_r2"] == TITLE_V1, "user sees old title on r2")

    ac = data["partition_accept_conflict"]
    _assert(ac["partitioned_during_write"] is True, "accept path is partitioned")
    _assert(ac["set_r1_inv_s"] == 0.0, "accept SET r1 starts at 0.0")
    _assert(ac["set_r1_ret_s"] == 0.02, "accept SET r1 returns at 0.02")
    _assert(ac["set_r1_status"] == "ok", "accept SET r1 is ok")
    _assert(ac["replicas_after_set_r1"]["r1"] == TITLE_V2, "after SET r1, r1 is v2")
    _assert(ac["replicas_after_set_r1"]["r2"] == TITLE_V1, "after SET r1, r2 is still v1")
    _assert(ac["set_r2_inv_s"] == 0.02, "accept SET r2 starts at 0.02")
    _assert(ac["set_r2_ret_s"] == 0.04, "accept SET r2 returns at 0.04")
    _assert(ac["set_r2_status"] == "ok", "accept SET r2 is ok")
    _assert(ac["replicas_after_set_r2"]["r1"] == TITLE_V2, "after SET r2, r1 is v2")
    _assert(ac["replicas_after_set_r2"]["r2"] == TITLE_V3, "after SET r2, r2 is hotfix")
    _assert(ac["get_r1_inv_s"] == 0.04, "accept GET r1 starts at 0.04")
    _assert(ac["get_r1_ret_s"] == 0.06, "accept GET r1 returns at 0.06")
    _assert(ac["get_r1_value"] == TITLE_V2, "accept GET r1 is revised")
    _assert(ac["get_r2_inv_s"] == 0.06, "accept GET r2 starts at 0.06")
    _assert(ac["get_r2_ret_s"] == 0.08, "accept GET r2 returns at 0.08")
    _assert(ac["get_r2_value"] == TITLE_V3, "accept GET r2 is hotfix")
    _assert(ac["conflict_before_heal"] is True, "conflict exists before heal")
    _assert(ac["heal_s"] == 0.08, "heal is at 0.08")
    _assert(ac["conflict_after_heal"] is True, "conflict remains after heal")
    _assert(ac["get_r1_after_heal_value"] == TITLE_V2, "after heal GET r1 is still revised")
    _assert(ac["get_r2_after_heal_value"] == TITLE_V3, "after heal GET r2 is still hotfix")
    _assert(ac["linearizable"] is False, "conflicting successful writes are not linearizable")
    _assert(ac["cap_available_for_sets"] is True, "accept SETs are CAP-available")
    _assert(ac["replicas_were_not_failed"] is True, "accept replicas were not crashed")
    _assert(ac["user_visible"]["conflict"] is True, "user sees a conflict")
    _assert(ac["user_visible"]["conflict_still_visible_after_heal"] is True, "conflict survives heal")

    dl = data["delay_looks_like_partition"]
    _assert(dl["actual_partition"] is False, "delay path has no actual partition")
    _assert(dl["wait_s"] == 0.05, "delay path wait_s is 0.05")
    _assert(dl["replicate_delay_s"] == 0.08, "delay path replicate delay is 0.08")
    _assert(dl["set_inv_s"] == 0.0, "timeout SET starts at 0.0")
    _assert(dl["set_ret_s"] == 0.05, "timeout SET returns at 0.05")
    _assert(dl["set_status"] == "rejected", "timeout SET is rejected")
    _assert(dl["set_note"] == "peer_ack_after_wait_s", "rejected because ack would be late")
    _assert(dl["late_ack_would_arrive_at"] == 0.09, "late ack would arrive at 0.09")
    _assert(dl["replicas_at_reject"]["r1"] == TITLE_V1, "at reject r1 is still v1")
    _assert(dl["replicas_at_reject"]["r2"] == TITLE_V1, "at reject r2 is still v1")
    _assert(dl["value_not_applied_after_late_ack"] is True, "late ack does not apply the value")
    _assert(dl["rejected_despite_no_partition"] is True, "rejected despite no partition")
    _assert(dl["get_r1_value"] == TITLE_V1, "after timeout GET r1 is v1")
    _assert(dl["get_r2_value"] == TITLE_V1, "after timeout GET r2 is v1")
    _assert(dl["cap_available_for_set"] is False, "timeout SET is not CAP-available")

    _assert(
        data["acceptance_cap_does_not_decide_latency_without_partition"] is True,
        "acceptance 1",
    )
    _assert(
        data["acceptance_show_both_strategies_user_visible"] is True,
        "acceptance 2: both strategies' user-visible results",
    )
    _assert(data["pitfall_sla_is_not_cap_availability"] is True, "pitfall demonstrated")
    _assert(
        data["tradeoff_choice_depends_on_staleness_conflict_and_write_outage"] is True,
        "tradeoff flag",
    )

    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
