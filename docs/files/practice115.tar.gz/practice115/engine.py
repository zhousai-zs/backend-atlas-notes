#!/usr/bin/env python3
"""Teaching CapEngine — not Redis, not a network service, not Raft, not Jepsen.

A Python 3 standard-library model of two replicas of a single-key
read/write register, an explicit partition switch, and two write
policies used in lesson 115:

* require_peer: a SET commits only when both replicas apply it; if the
  peer cannot be reached within wait_s, the SET is rejected and neither
  replica is updated.
* local_first: a SET applies on the contacted replica and returns; the
  other replica is updated later if the replicas are not isolated.

This is not Redis, not redis-py, and not a network server. There is no
TCP, no real message loss, no Raft, no Paxos, and no Jepsen. The Clock
is a virtual clock so experiments are repeatable. A call to isolate()
is an explicit, omniscient partition; real asynchronous networks have
no such signal, which is a documented difference from Gilbert & Lynch
(2012). Definitions of atomic consistency, availability, and partition
tolerance follow Gilbert & Lynch, "Perspectives on the CAP Theorem"
(IEEE Computer, February 2012), checked on 2026-11-13.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
LOCAL_STEP_S = 0.01
REPLICATE_DELAY_S = 0.08
WAIT_S = 0.05


class Clock:
    """A virtual clock tests can freeze and advance. Not a shared wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t = round(self.t + float(seconds), 10)

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class RecordedOp:
    op_id: str
    process: str
    kind: str  # SET, GET
    key: str
    replica_id: str
    arg: Optional[str] = None
    result: Optional[str] = None
    status: str = "ok"  # ok, rejected
    inv_s: float = 0.0
    ret_s: float = 0.0
    note: Optional[str] = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "op_id": self.op_id,
            "process": self.process,
            "kind": self.kind,
            "key": self.key,
            "replica_id": self.replica_id,
            "arg": self.arg,
            "result": self.result,
            "status": self.status,
            "inv_s": self.inv_s,
            "ret_s": self.ret_s,
            "note": self.note,
        }


@dataclass
class Replica:
    replica_id: str
    value: str
    failed: bool = False


@dataclass
class PendingCopy:
    deliver_at: float
    src: str
    dst: str
    value: str
    commit_id: str


class CapEngine:
    """Two-replica teaching store with an explicit partition switch.

    policy is 'require_peer' or 'local_first'. Replicas are non-failing
    unless a test marks one failed; partitions do not crash a replica.
    """

    def __init__(
        self,
        clock: Clock,
        policy: str,
        initial: str = TITLE_V1,
        replicate_delay_s: float = REPLICATE_DELAY_S,
        wait_s: float = WAIT_S,
    ) -> None:
        if policy not in ("require_peer", "local_first"):
            raise ValueError(f"unknown policy: {policy}")
        self.clock = clock
        self.policy = policy
        self.replicate_delay_s = float(replicate_delay_s)
        self.wait_s = float(wait_s)
        self.replicas: dict[str, Replica] = {
            "r1": Replica("r1", initial),
            "r2": Replica("r2", initial),
        }
        self.partitioned = False
        self.pending: list[PendingCopy] = []
        self.late_events: list[dict[str, Any]] = []

    def peer_id(self, replica_id: str) -> str:
        if replica_id == "r1":
            return "r2"
        if replica_id == "r2":
            return "r1"
        raise KeyError(replica_id)

    def isolate(self) -> None:
        """Drop in-flight copies and stop further inter-replica copies."""
        self.partitioned = True
        dropped = list(self.pending)
        self.pending = []
        for msg in dropped:
            self.late_events.append(
                {
                    "kind": "dropped_by_partition",
                    "at": self.clock.now(),
                    "src": msg.src,
                    "dst": msg.dst,
                    "value": msg.value,
                    "commit_id": msg.commit_id,
                }
            )

    def heal(self) -> None:
        self.partitioned = False

    def _deliver_due(self) -> None:
        due = [m for m in self.pending if m.deliver_at <= self.clock.now()]
        self.pending = [m for m in self.pending if m.deliver_at > self.clock.now()]
        for msg in due:
            if self.partitioned:
                self.late_events.append(
                    {
                        "kind": "dropped_by_partition",
                        "at": self.clock.now(),
                        "src": msg.src,
                        "dst": msg.dst,
                        "value": msg.value,
                        "commit_id": msg.commit_id,
                    }
                )
                continue
            self.replicas[msg.dst].value = msg.value
            self.late_events.append(
                {
                    "kind": "async_copy_applied",
                    "at": self.clock.now(),
                    "src": msg.src,
                    "dst": msg.dst,
                    "value": msg.value,
                    "commit_id": msg.commit_id,
                }
            )

    def snapshot(self) -> dict[str, Any]:
        self._deliver_due()
        r1 = self.replicas["r1"].value
        r2 = self.replicas["r2"].value
        return {
            "r1": r1,
            "r2": r2,
            "conflict": r1 != r2,
            "partitioned": self.partitioned,
            "clock_s": self.clock.now(),
        }

    def set(
        self,
        op_id: str,
        process: str,
        replica_id: str,
        value: str,
        key: str = KEY_TITLE,
    ) -> RecordedOp:
        self._deliver_due()
        inv = self.clock.now()
        target = self.replicas[replica_id]
        peer = self.replicas[self.peer_id(replica_id)]
        op = RecordedOp(
            op_id=op_id,
            process=process,
            kind="SET",
            key=key,
            replica_id=replica_id,
            arg=value,
            inv_s=inv,
        )

        if target.failed:
            self.clock.advance(LOCAL_STEP_S)
            op.status = "rejected"
            op.result = None
            op.ret_s = self.clock.now()
            op.note = "replica_failed"
            return op

        if self.policy == "local_first":
            self.clock.advance(LOCAL_STEP_S)
            self._deliver_due()
            target.value = value
            if not self.partitioned and not peer.failed:
                self.pending.append(
                    PendingCopy(
                        deliver_at=round(self.clock.now() + self.replicate_delay_s, 10),
                        src=replica_id,
                        dst=peer.replica_id,
                        value=value,
                        commit_id=op_id,
                    )
                )
            self.clock.advance(LOCAL_STEP_S)
            op.status = "ok"
            op.result = "ok"
            op.ret_s = self.clock.now()
            op.note = "applied_locally"
            return op

        # require_peer: commit only when both replicas can apply the value.
        self.clock.advance(LOCAL_STEP_S)
        self._deliver_due()
        deadline = round(inv + self.wait_s, 10)
        deliver_at = round(self.clock.now() + self.replicate_delay_s, 10)
        can_reach_peer = (not self.partitioned) and (not peer.failed)
        if can_reach_peer and deliver_at <= deadline:
            self.clock.wait_until(deliver_at)
            self._deliver_due()
            target.value = value
            peer.value = value
            self.clock.advance(LOCAL_STEP_S)
            op.status = "ok"
            op.result = "ok"
            op.ret_s = self.clock.now()
            op.note = "committed_on_both"
            return op

        # Partitioned, or the peer ack would arrive after wait_s.
        self.clock.wait_until(deadline)
        self._deliver_due()
        # Intentionally do not apply the value on either replica.
        op.status = "rejected"
        op.result = None
        op.ret_s = self.clock.now()
        if not can_reach_peer:
            op.note = "peer_unreachable"
        else:
            op.note = "peer_ack_after_wait_s"
            self.late_events.append(
                {
                    "kind": "late_ack_not_applied",
                    "would_arrive_at": deliver_at,
                    "rejected_at": op.ret_s,
                    "src": replica_id,
                    "dst": peer.replica_id,
                    "value": value,
                    "commit_id": op_id,
                }
            )
        return op

    def get(
        self,
        op_id: str,
        process: str,
        replica_id: str,
        key: str = KEY_TITLE,
    ) -> RecordedOp:
        self._deliver_due()
        inv = self.clock.now()
        target = self.replicas[replica_id]
        op = RecordedOp(
            op_id=op_id,
            process=process,
            kind="GET",
            key=key,
            replica_id=replica_id,
            inv_s=inv,
        )
        self.clock.advance(LOCAL_STEP_S)
        self._deliver_due()
        if target.failed:
            self.clock.advance(LOCAL_STEP_S)
            op.status = "rejected"
            op.result = None
            op.ret_s = self.clock.now()
            op.note = "replica_failed"
            return op
        value = target.value
        self.clock.advance(LOCAL_STEP_S)
        op.status = "ok"
        op.result = value
        op.ret_s = self.clock.now()
        op.note = "local_committed_value"
        return op


def cap_available(ops: list[RecordedOp]) -> bool:
    """CAP availability: every request to a non-failing node completed."""
    return all(op.status == "ok" for op in ops)


def sla_got_a_reply(ops: list[RecordedOp]) -> bool:
    """A reply (ok or rejected) came back. This is not CAP availability."""
    return all(op.ret_s >= op.inv_s for op in ops)
