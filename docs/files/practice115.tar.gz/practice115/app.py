#!/usr/bin/env python3
"""Run the lesson 115 CAP-theorem experiments and record observations."""
from __future__ import annotations

from typing import Any

from engine import (
    KEY_TITLE,
    LOCAL_STEP_S,
    REPLICATE_DELAY_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    WAIT_S,
    CapEngine,
    Clock,
    RecordedOp,
    cap_available,
    sla_got_a_reply,
)


def _ops_report(ops: list[RecordedOp]) -> list[dict[str, Any]]:
    return [op.as_dict() for op in ops]


def _flags(ops: list[RecordedOp], snap: dict[str, Any]) -> dict[str, Any]:
    return {
        "cap_available": cap_available(ops),
        "sla_got_a_reply": sla_got_a_reply(ops),
        "replicas_at_end": {"r1": snap["r1"], "r2": snap["r2"]},
        "conflict": snap["conflict"],
        "partitioned": snap["partitioned"],
    }


def no_partition_wait_both() -> dict[str, Any]:
    """Healthy network, require_peer: SET waits for both replicas."""
    clock = Clock()
    store = CapEngine(
        clock,
        policy="require_peer",
        replicate_delay_s=REPLICATE_DELAY_S,
        wait_s=0.20,
    )
    set1 = store.set("set_wait_both", "editor", "r1", TITLE_V2)
    snap_at_return = store.snapshot()
    get_r1 = store.get("get_r1_after_wait", "reader", "r1")
    get_r2 = store.get("get_r2_after_wait", "reader2", "r2")
    ops = [set1, get_r1, get_r2]
    snap = store.snapshot()
    return {
        "policy": "require_peer",
        "partitioned_during_write": False,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "wait_s": 0.20,
        "ops": _ops_report(ops),
        "set_inv_s": set1.inv_s,
        "set_ret_s": set1.ret_s,
        "set_status": set1.status,
        "set_latency_s": round(set1.ret_s - set1.inv_s, 10),
        "replicas_at_set_return": {
            "r1": snap_at_return["r1"],
            "r2": snap_at_return["r2"],
        },
        "get_r1_value": get_r1.result,
        "get_r2_value": get_r2.result,
        **_flags(ops, snap),
    }


def no_partition_local_ack() -> dict[str, Any]:
    """Healthy network, local_first: SET returns after the local replica."""
    clock = Clock()
    store = CapEngine(
        clock,
        policy="local_first",
        replicate_delay_s=REPLICATE_DELAY_S,
        wait_s=WAIT_S,
    )
    set1 = store.set("set_local_ack", "editor", "r1", TITLE_V2)
    snap_at_return = store.snapshot()
    get_r2_stale = store.get("get_r2_before_copy", "reader", "r2")
    # Async copy is scheduled at local apply (0.01) + 0.08 = 0.09.
    store.clock.wait_until(0.09)
    store._deliver_due()
    copy_at = 0.09
    snap_after_copy = store.snapshot()
    get_r2_after = store.get("get_r2_after_copy", "reader2", "r2")
    ops = [set1, get_r2_stale, get_r2_after]
    snap = store.snapshot()
    return {
        "policy": "local_first",
        "partitioned_during_write": False,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "ops": _ops_report(ops),
        "set_inv_s": set1.inv_s,
        "set_ret_s": set1.ret_s,
        "set_status": set1.status,
        "set_latency_s": round(set1.ret_s - set1.inv_s, 10),
        "replicas_at_set_return": {
            "r1": snap_at_return["r1"],
            "r2": snap_at_return["r2"],
        },
        "get_r2_before_copy_inv_s": get_r2_stale.inv_s,
        "get_r2_before_copy_ret_s": get_r2_stale.ret_s,
        "get_r2_before_copy_value": get_r2_stale.result,
        "async_copy_applied_at": copy_at,
        "replicas_after_copy": {
            "r1": snap_after_copy["r1"],
            "r2": snap_after_copy["r2"],
        },
        "get_r2_after_copy_inv_s": get_r2_after.inv_s,
        "get_r2_after_copy_ret_s": get_r2_after.ret_s,
        "get_r2_after_copy_value": get_r2_after.result,
        **_flags(ops, snap),
    }


def compare_no_partition_latency(
    wait_both: dict[str, Any], local_ack: dict[str, Any]
) -> dict[str, Any]:
    return {
        "wait_both_latency_s": wait_both["set_latency_s"],
        "local_ack_latency_s": local_ack["set_latency_s"],
        "latencies_differ": wait_both["set_latency_s"] != local_ack["set_latency_s"],
        "wait_both_slower": wait_both["set_latency_s"] > local_ack["set_latency_s"],
        "no_partition_in_either_path": (
            wait_both["partitioned_during_write"] is False
            and local_ack["partitioned_during_write"] is False
        ),
        "both_sets_ok": (
            wait_both["set_status"] == "ok" and local_ack["set_status"] == "ok"
        ),
        "acceptance_cap_does_not_decide_latency_without_partition": True,
        "note": (
            "Both paths ran on a healthy network with no partition. "
            "CAP does not choose 0.10s vs 0.02s for the SET; that choice "
            "is the latency/consistency trade-off of PACELC's else-branch."
        ),
    }


def partition_refuse_write() -> dict[str, Any]:
    """Isolated replicas, require_peer: both writes are rejected."""
    clock = Clock()
    store = CapEngine(
        clock,
        policy="require_peer",
        replicate_delay_s=REPLICATE_DELAY_S,
        wait_s=WAIT_S,
    )
    store.isolate()
    set_r1 = store.set("set_r1_revised", "editor", "r1", TITLE_V2)
    snap_after_r1 = store.snapshot()
    clock.advance(LOCAL_STEP_S)  # 0.06
    set_r2 = store.set("set_r2_hotfix", "editor2", "r2", TITLE_V3)
    snap_after_r2 = store.snapshot()
    get_r1 = store.get("get_r1_after_refuse", "reader", "r1")
    get_r2 = store.get("get_r2_after_refuse", "reader2", "r2")
    ops = [set_r1, set_r2, get_r1, get_r2]
    snap = store.snapshot()
    return {
        "policy": "require_peer",
        "partitioned_during_write": True,
        "wait_s": WAIT_S,
        "ops": _ops_report(ops),
        "set_r1_inv_s": set_r1.inv_s,
        "set_r1_ret_s": set_r1.ret_s,
        "set_r1_status": set_r1.status,
        "set_r1_note": set_r1.note,
        "replicas_after_set_r1": {
            "r1": snap_after_r1["r1"],
            "r2": snap_after_r1["r2"],
        },
        "set_r2_inv_s": set_r2.inv_s,
        "set_r2_ret_s": set_r2.ret_s,
        "set_r2_status": set_r2.status,
        "set_r2_note": set_r2.note,
        "replicas_after_set_r2": {
            "r1": snap_after_r2["r1"],
            "r2": snap_after_r2["r2"],
        },
        "get_r1_inv_s": get_r1.inv_s,
        "get_r1_ret_s": get_r1.ret_s,
        "get_r1_value": get_r1.result,
        "get_r2_inv_s": get_r2.inv_s,
        "get_r2_ret_s": get_r2.ret_s,
        "get_r2_value": get_r2.result,
        "user_visible": {
            "set_r1": "rejected",
            "set_r2": "rejected",
            "title_on_r1": get_r1.result,
            "title_on_r2": get_r2.result,
            "conflict": snap["conflict"],
        },
        "linearizable_no_successful_conflicting_writes": (
            set_r1.status == "rejected"
            and set_r2.status == "rejected"
            and snap["r1"] == TITLE_V1
            and snap["r2"] == TITLE_V1
            and snap["conflict"] is False
        ),
        "replicas_were_not_failed": (
            store.replicas["r1"].failed is False
            and store.replicas["r2"].failed is False
        ),
        "pitfall_sla_is_not_cap_availability": (
            sla_got_a_reply([set_r1, set_r2]) is True
            and cap_available([set_r1, set_r2]) is False
        ),
        **_flags(ops, snap),
        # Reads completed; the two SETs did not. CAP availability is
        # judged on the SETs that were issued to non-failing nodes.
        "cap_available_for_sets": cap_available([set_r1, set_r2]),
        "sla_got_a_reply_for_sets": sla_got_a_reply([set_r1, set_r2]),
    }


def partition_accept_conflict() -> dict[str, Any]:
    """Isolated replicas, local_first: both writes succeed and diverge."""
    clock = Clock()
    store = CapEngine(
        clock,
        policy="local_first",
        replicate_delay_s=REPLICATE_DELAY_S,
        wait_s=WAIT_S,
    )
    store.isolate()
    set_r1 = store.set("set_r1_revised", "editor", "r1", TITLE_V2)
    snap_after_r1 = store.snapshot()
    set_r2 = store.set("set_r2_hotfix", "editor2", "r2", TITLE_V3)
    snap_after_r2 = store.snapshot()
    get_r1 = store.get("get_r1_after_accept", "reader", "r1")
    get_r2 = store.get("get_r2_after_accept", "reader2", "r2")
    ops = [set_r1, set_r2, get_r1, get_r2]
    snap_before_heal = store.snapshot()
    heal_s = store.clock.now()
    store.heal()
    snap_after_heal = store.snapshot()
    get_r1_healed = store.get("get_r1_after_heal", "reader3", "r1")
    get_r2_healed = store.get("get_r2_after_heal", "reader4", "r2")
    all_ops = ops + [get_r1_healed, get_r2_healed]
    snap = store.snapshot()
    return {
        "policy": "local_first",
        "partitioned_during_write": True,
        "ops": _ops_report(all_ops),
        "set_r1_inv_s": set_r1.inv_s,
        "set_r1_ret_s": set_r1.ret_s,
        "set_r1_status": set_r1.status,
        "replicas_after_set_r1": {
            "r1": snap_after_r1["r1"],
            "r2": snap_after_r1["r2"],
        },
        "set_r2_inv_s": set_r2.inv_s,
        "set_r2_ret_s": set_r2.ret_s,
        "set_r2_status": set_r2.status,
        "replicas_after_set_r2": {
            "r1": snap_after_r2["r1"],
            "r2": snap_after_r2["r2"],
        },
        "get_r1_inv_s": get_r1.inv_s,
        "get_r1_ret_s": get_r1.ret_s,
        "get_r1_value": get_r1.result,
        "get_r2_inv_s": get_r2.inv_s,
        "get_r2_ret_s": get_r2.ret_s,
        "get_r2_value": get_r2.result,
        "replicas_before_heal": {
            "r1": snap_before_heal["r1"],
            "r2": snap_before_heal["r2"],
        },
        "conflict_before_heal": snap_before_heal["conflict"],
        "heal_s": heal_s,
        "replicas_after_heal": {
            "r1": snap_after_heal["r1"],
            "r2": snap_after_heal["r2"],
        },
        "conflict_after_heal": snap_after_heal["conflict"],
        "get_r1_after_heal_value": get_r1_healed.result,
        "get_r2_after_heal_value": get_r2_healed.result,
        "user_visible": {
            "set_r1": "ok",
            "set_r2": "ok",
            "title_on_r1": get_r1.result,
            "title_on_r2": get_r2.result,
            "conflict": True,
            "conflict_still_visible_after_heal": snap_after_heal["conflict"],
        },
        "linearizable": False,
        "reason_not_linearizable": (
            "Two successful SETs of different values on the same register, "
            "followed by GETs that return those different values."
        ),
        "replicas_were_not_failed": (
            store.replicas["r1"].failed is False
            and store.replicas["r2"].failed is False
        ),
        **_flags(all_ops, snap),
        "cap_available_for_sets": cap_available([set_r1, set_r2]),
    }


def delay_looks_like_partition() -> dict[str, Any]:
    """No real partition, but peer ack arrives after wait_s, so require_peer rejects."""
    clock = Clock()
    store = CapEngine(
        clock,
        policy="require_peer",
        replicate_delay_s=REPLICATE_DELAY_S,
        wait_s=WAIT_S,
    )
    set1 = store.set("set_timeout_no_partition", "editor", "r1", TITLE_V2)
    snap_at_reject = store.snapshot()
    would_arrive_at = None
    for ev in store.late_events:
        if ev.get("kind") == "late_ack_not_applied":
            would_arrive_at = ev["would_arrive_at"]
            break
    # Advance past the time the ack would have arrived, still not applied.
    if would_arrive_at is not None:
        clock.wait_until(would_arrive_at)
        store._deliver_due()
    snap_after_late = store.snapshot()
    get_r1 = store.get("get_r1_after_timeout", "reader", "r1")
    get_r2 = store.get("get_r2_after_timeout", "reader2", "r2")
    ops = [set1, get_r1, get_r2]
    snap = store.snapshot()
    return {
        "policy": "require_peer",
        "actual_partition": False,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "wait_s": WAIT_S,
        "ops": _ops_report(ops),
        "set_inv_s": set1.inv_s,
        "set_ret_s": set1.ret_s,
        "set_status": set1.status,
        "set_note": set1.note,
        "replicas_at_reject": {
            "r1": snap_at_reject["r1"],
            "r2": snap_at_reject["r2"],
        },
        "late_ack_would_arrive_at": would_arrive_at,
        "replicas_after_late_ack_time": {
            "r1": snap_after_late["r1"],
            "r2": snap_after_late["r2"],
        },
        "get_r1_value": get_r1.result,
        "get_r2_value": get_r2.result,
        "rejected_despite_no_partition": (
            set1.status == "rejected" and set1.note == "peer_ack_after_wait_s"
        ),
        "value_not_applied_after_late_ack": (
            snap_after_late["r1"] == TITLE_V1 and snap_after_late["r2"] == TITLE_V1
        ),
        "cap_available_for_set": cap_available([set1]),
        **_flags(ops, snap),
    }


def run_all_experiments() -> dict[str, Any]:
    wait_both = no_partition_wait_both()
    local_ack = no_partition_local_ack()
    latency = compare_no_partition_latency(wait_both, local_ack)
    refuse = partition_refuse_write()
    accept = partition_accept_conflict()
    delay = delay_looks_like_partition()
    return {
        "engine": "CapEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_raft": True,
        "not_jepsen": True,
        "key": KEY_TITLE,
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "title_v3": TITLE_V3,
        "local_step_s": LOCAL_STEP_S,
        "replicate_delay_s": REPLICATE_DELAY_S,
        "wait_s": WAIT_S,
        "no_partition_wait_both": wait_both,
        "no_partition_local_ack": local_ack,
        "no_partition_latency": latency,
        "partition_refuse_write": refuse,
        "partition_accept_conflict": accept,
        "delay_looks_like_partition": delay,
        "acceptance_cap_does_not_decide_latency_without_partition": (
            latency["acceptance_cap_does_not_decide_latency_without_partition"]
            and latency["latencies_differ"]
            and latency["no_partition_in_either_path"]
        ),
        "acceptance_show_both_strategies_user_visible": (
            refuse["user_visible"]["set_r1"] == "rejected"
            and refuse["user_visible"]["set_r2"] == "rejected"
            and refuse["user_visible"]["title_on_r1"] == TITLE_V1
            and refuse["user_visible"]["title_on_r2"] == TITLE_V1
            and refuse["user_visible"]["conflict"] is False
            and accept["user_visible"]["set_r1"] == "ok"
            and accept["user_visible"]["set_r2"] == "ok"
            and accept["user_visible"]["title_on_r1"] == TITLE_V2
            and accept["user_visible"]["title_on_r2"] == TITLE_V3
            and accept["user_visible"]["conflict"] is True
        ),
        "pitfall_sla_is_not_cap_availability": refuse["pitfall_sla_is_not_cap_availability"],
        "tradeoff_choice_depends_on_staleness_conflict_and_write_outage": True,
    }


if __name__ == "__main__":
    import json
    import os

    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(json.dumps({
        "wait_both": {
            "ret": data["no_partition_wait_both"]["set_ret_s"],
            "lat": data["no_partition_wait_both"]["set_latency_s"],
            "reps": data["no_partition_wait_both"]["replicas_at_set_return"],
        },
        "local_ack": {
            "ret": data["no_partition_local_ack"]["set_ret_s"],
            "lat": data["no_partition_local_ack"]["set_latency_s"],
            "reps": data["no_partition_local_ack"]["replicas_at_set_return"],
            "stale": data["no_partition_local_ack"]["get_r2_before_copy_value"],
            "copy_at": data["no_partition_local_ack"]["async_copy_applied_at"],
            "after": data["no_partition_local_ack"]["get_r2_after_copy_value"],
        },
        "refuse": data["partition_refuse_write"]["user_visible"],
        "refuse_times": {
            "s1": [
                data["partition_refuse_write"]["set_r1_inv_s"],
                data["partition_refuse_write"]["set_r1_ret_s"],
                data["partition_refuse_write"]["set_r1_status"],
            ],
            "s2": [
                data["partition_refuse_write"]["set_r2_inv_s"],
                data["partition_refuse_write"]["set_r2_ret_s"],
                data["partition_refuse_write"]["set_r2_status"],
            ],
            "g1": [
                data["partition_refuse_write"]["get_r1_inv_s"],
                data["partition_refuse_write"]["get_r1_value"],
            ],
            "g2": [
                data["partition_refuse_write"]["get_r2_inv_s"],
                data["partition_refuse_write"]["get_r2_value"],
            ],
        },
        "accept": data["partition_accept_conflict"]["user_visible"],
        "accept_times": {
            "s1": [
                data["partition_accept_conflict"]["set_r1_inv_s"],
                data["partition_accept_conflict"]["set_r1_ret_s"],
            ],
            "s2": [
                data["partition_accept_conflict"]["set_r2_inv_s"],
                data["partition_accept_conflict"]["set_r2_ret_s"],
            ],
            "g1": [
                data["partition_accept_conflict"]["get_r1_inv_s"],
                data["partition_accept_conflict"]["get_r1_value"],
            ],
            "g2": [
                data["partition_accept_conflict"]["get_r2_inv_s"],
                data["partition_accept_conflict"]["get_r2_value"],
            ],
        },
        "delay": {
            "ret": data["delay_looks_like_partition"]["set_ret_s"],
            "status": data["delay_looks_like_partition"]["set_status"],
            "note": data["delay_looks_like_partition"]["set_note"],
            "late": data["delay_looks_like_partition"]["late_ack_would_arrive_at"],
            "rejected": data["delay_looks_like_partition"]["rejected_despite_no_partition"],
        },
        "acceptance": {
            "latency": data["acceptance_cap_does_not_decide_latency_without_partition"],
            "visible": data["acceptance_show_both_strategies_user_visible"],
            "pitfall": data["pitfall_sla_is_not_cap_availability"],
        },
    }, ensure_ascii=False, indent=2))
