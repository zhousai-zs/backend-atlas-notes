#!/usr/bin/env python3
from __future__ import annotations

import json, os, subprocess, sys, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
PY = sys.executable
TOKEN = "diag-token-teaching"
SECRET = "super-secret-ops-key"
BROKEN_PORT, FIXED_PORT = 18901, 18902

# Trust boundary (teaching diagram, also written to reports/)
BOUNDARY = {
    "untrusted": ["client HTTP query string", "Authorization header"],
    "boundary": "diagnostic HTTP process",
    "trusted_after_auth": ["allowlisted hostnames for fetch", "hostname regex for ping"],
    "never_cross": ["shell metacharacters", "link-local and localhost URLs", "file://", "cloud metadata addresses"],
    "secrets": ["process env DIAG_SECRET must not appear in responses"],
}


def start(mode, port, side):
    env = os.environ.copy()
    env.update({
        "DIAG_MODE": mode,
        "DIAG_PORT": str(port),
        "DIAG_TOKEN": TOKEN,
        "DIAG_SECRET": SECRET,
        "SIDE_FILE": str(side),
    })
    return subprocess.Popen([PY, str(ROOT / "server.py")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def req(port, path, token=None, timeout=1.0):
    headers = {"User-Agent": "practice156"}
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    url = f"http://127.0.0.1:{port}{path}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode())
        except Exception:
            body = {}
        return e.code, body


def leak(body) -> bool:
    text = json.dumps(body)
    return SECRET in text or "Traceback" in text or "super-secret" in text


def run_mode(mode, port, side_path: Path):
    if side_path.exists():
        side_path.unlink()
    proc = start(mode, port, side_path)
    try:
        for _ in range(50):
            try:
                code, _ = req(port, "/health")
                if code == 200:
                    break
            except Exception:
                time.sleep(0.02)
        else:
            raise SystemExit(f"{mode} server not up")

        # unauthorized should not trigger side effects in fixed mode
        c1, b1 = req(port, "/diag/fetch?url=" + urllib.parse.quote("http://127.0.0.1/secret"), token=None)
        c2, b2 = req(port, "/diag/ping?host=" + urllib.parse.quote("1.2.3.4;cat /etc/passwd"), token=None)
        c3, b3 = req(port, "/side-effects")
        unauth = {"fetch": c1, "ping": c2, "side_effects": b3.get("count"), "leaked": leak(b1) or leak(b2)}

        # authorized SSRF / injection attempts
        c4, b4 = req(port, "/diag/fetch?url=" + urllib.parse.quote("http://169.254.169.254/latest/meta-data/"), token=TOKEN)
        c5, b5 = req(port, "/diag/fetch?url=" + urllib.parse.quote("file:///etc/passwd"), token=TOKEN)
        c6, b6 = req(port, "/diag/ping?host=" + urllib.parse.quote("8.8.8.8;id"), token=TOKEN)
        # allowlisted / safe
        c7, b7 = req(port, "/diag/fetch?url=" + urllib.parse.quote("http://example.invalid/status"), token=TOKEN)
        c8, b8 = req(port, "/diag/ping?host=cache-1.internal", token=TOKEN)
        c9, b9 = req(port, "/side-effects")
        return {
            "unauth_codes": [c1, c2],
            "unauth_side_effects": b3.get("count"),
            "unauth_leaked": leak(b1) or leak(b2),
            "ssrf_metadata": {"code": c4, "body": b4, "leaked": leak(b4)},
            "ssrf_file": {"code": c5, "body": b5, "leaked": leak(b5)},
            "shell_inject": {"code": c6, "body": b6, "leaked": leak(b6)},
            "allow_fetch": {"code": c7, "body": b7},
            "allow_ping": {"code": c8, "body": b8},
            "side_effects_end": b9.get("count"),
        }
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()


def main():
    broken = run_mode("broken", BROKEN_PORT, REPORTS / "side-broken.txt")
    fixed = run_mode("fixed", FIXED_PORT, REPORTS / "side-fixed.txt")
    # broken must be caught
    assert broken["unauth_side_effects"] and broken["unauth_side_effects"] > 0
    assert broken["unauth_leaked"] or broken["ssrf_metadata"]["leaked"] or True
    # broken leaks on 401
    assert broken["unauth_leaked"] is True
    assert broken["shell_inject"]["body"].get("shell") is True
    assert "composed" in broken["shell_inject"]["body"] and ";id" in broken["shell_inject"]["body"]["composed"]
    assert broken["ssrf_metadata"]["code"] == 200

    # fixed acceptance
    assert fixed["unauth_codes"] == [401, 401]
    assert fixed["unauth_side_effects"] == 0
    assert fixed["unauth_leaked"] is False
    assert fixed["ssrf_metadata"]["code"] == 400 and not fixed["ssrf_metadata"]["leaked"]
    assert fixed["ssrf_file"]["code"] == 400
    assert fixed["shell_inject"]["code"] == 400 and not fixed["shell_inject"]["leaked"]
    assert fixed["allow_fetch"]["code"] == 200
    assert fixed["allow_ping"]["code"] == 200
    assert SECRET not in json.dumps(fixed)

    results = {
        "lesson": 156,
        "id": "j-security",
        "is_live_network_ssrf": False,
        "trust_boundary": BOUNDARY,
        "broken": {k: broken[k] for k in broken if k not in ("allow_fetch",)},
        "fixed": fixed,
        "unauth_no_side_effects_fixed": fixed["unauth_side_effects"] == 0,
        "errors_do_not_leak_secret_or_stack_fixed": True,
        "broken_caught": True,
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    (REPORTS / "boundary.json").write_text(json.dumps(BOUNDARY, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
