"""Diagnostic HTTP API: broken vs fixed trust boundary."""
from __future__ import annotations

import json, os, subprocess, traceback, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

MODE = os.environ.get("DIAG_MODE", "fixed")  # fixed | broken
TOKEN = os.environ.get("DIAG_TOKEN", "diag-token-teaching")
SECRET = os.environ.get("DIAG_SECRET", "super-secret-ops-key")
SIDE_EFFECTS = int(os.environ.get("SIDE_EFFECT_START", "0"))
SIDE_FILE = os.environ.get("SIDE_FILE", "reports/side-effects.txt")
ALLOW_HOSTS = {"example.invalid", "httpbin.local"}


def record_side_effect(kind: str):
    global SIDE_EFFECTS
    SIDE_EFFECTS += 1
    with open(SIDE_FILE, "a") as f:
        f.write(f"{kind}\n")


def authorized(handler) -> bool:
    auth = handler.headers.get("Authorization", "")
    return auth == f"Bearer {TOKEN}"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        return

    def _send(self, code, obj, raw=None):
        body = raw if raw is not None else json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(self, code, msg, exc=None):
        if MODE == "broken":
            payload = {"error": msg, "secret": SECRET, "stack": traceback.format_exc() if exc else "n/a"}
        else:
            payload = {"error": "request_rejected", "code": code}
        # fixed path must not leak
        text = json.dumps(payload)
        if MODE == "fixed":
            assert SECRET not in text
            assert "Traceback" not in text
        self._send(code, payload)

    def do_GET(self):
        global SIDE_EFFECTS
        u = urlparse(self.path)
        qs = parse_qs(u.query)
        if u.path == "/health":
            self._send(200, {"ok": True, "mode": MODE})
            return
        if u.path == "/side-effects":
            self._send(200, {"count": SIDE_EFFECTS})
            return
        if not authorized(self):
            # unauthorized must not cause side effects in fixed mode
            if MODE == "broken" and u.path in {"/diag/fetch", "/diag/ping"}:
                record_side_effect("unauthorized")
            self._error(401, "unauthorized")
            return
        if u.path == "/diag/fetch":
            url = (qs.get("url") or [""])[0]
            try:
                if MODE == "fixed":
                    p = urlparse(url)
                    host = (p.hostname or "").lower()
                    if p.scheme not in {"http", "https"} or host not in ALLOW_HOSTS:
                        self._error(400, "url_not_allowed")
                        return
                # broken: fetches arbitrary URL (SSRF). We do not actually contact
                # link-local/cloud metadata; record the attempt as a caught side effect.
                record_side_effect(f"fetch:{url}")
                if MODE == "broken":
                    self._send(200, {"ok": True, "fetched": url, "would_ssrf": True})
                else:
                    self._send(200, {"ok": True, "fetched": url})
            except Exception as e:
                self._error(500, "fetch_failed", e)
            return
        if u.path == "/diag/ping":
            host = (qs.get("host") or [""])[0]
            try:
                if MODE == "fixed":
                    import re
                    if not re.fullmatch(r"[A-Za-z0-9.-]+", host):
                        self._error(400, "host_not_allowed")
                        return
                    # no shell
                    record_side_effect(f"ping:{host}")
                    self._send(200, {"ok": True, "host": host, "shell": False})
                    return
                # broken: interpolates into a shell
                record_side_effect(f"shell:{host}")
                # Do not actually execute attacker commands. Record the composed
                # command so the test can prove injection would have reached the shell.
                composed = f"ping -c 1 {host}"
                self._send(200, {"ok": True, "composed": composed, "shell": True})
            except Exception as e:
                self._error(500, "ping_failed", e)
            return
        self._error(404, "not_found")


if __name__ == "__main__":
    open(SIDE_FILE, "w").close()
    port = int(os.environ["DIAG_PORT"])
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
