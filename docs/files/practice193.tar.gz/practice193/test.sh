#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:$PWD/tools:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
echo "INVENTORY cmake=$(command -v cmake) zig-c++=$PWD/tools/zig-c++"
cmake --version | head -1
./tools/zig-c++ --version | head -1
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["cpp_build_succeeded"]
assert r["unauthorized_prefix_blocked"] and r["agent_cannot_raise_deadline"]
assert r["model_user_id_not_used_as_identity"]
assert r["failed"]==[]
assert "4.4.4" in r["toolchain"]["cmake_version"]
print("POSTCHECK_OK")
PY
