"""RPC tool gateway: auth, prefix ACL, forced deadline, write approval, audit.

The C++ process speaks a line-oriented teaching RPC (GET/EXISTS/SET/SLEEP).
This is not gRPC; identity and deadline follow the same responsibility split
as gRPC transport credentials and server-side limits: the model does not get
to pick the user, and it cannot raise the gateway cap.
"""
from __future__ import annotations

import socket
import time
from dataclasses import dataclass, field
from typing import Any


class RpcClient:
    def __init__(self, host: str, port: int, timeout: float):
        self.host = host
        self.port = port
        self.timeout = timeout

    def call(self, line: str, timeout: float | None = None) -> str:
        to = self.timeout if timeout is None else timeout
        s = socket.create_connection((self.host, self.port), timeout=to)
        try:
            s.settimeout(to)
            s.sendall((line.rstrip("\n") + "\n").encode())
            data = b""
            while b"\n" not in data:
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
            return data.decode().strip()
        finally:
            s.close()


@dataclass
class Approval:
    ticket: str
    key: str
    issued_to: str


@dataclass
class Gateway:
    backend: RpcClient
    identities: dict[str, str]  # token -> principal
    max_deadline_ms: int = 150
    rate_limit: int = 20
    audit: list[dict[str, Any]] = field(default_factory=list)
    approvals: dict[str, Approval] = field(default_factory=dict)
    hits: dict[str, int] = field(default_factory=dict)

    def issue_approval(self, ticket: str, key: str, issued_to: str) -> None:
        self.approvals[ticket] = Approval(ticket, key, issued_to)

    def _principal(self, token: str) -> str | None:
        return self.identities.get(token)

    def _allowed_key(self, principal: str, key: str) -> bool:
        return key.startswith(principal + "/")

    def invoke(self, token: str, tool: str, args: dict[str, Any]) -> dict[str, Any]:
        started = time.monotonic()
        rec: dict[str, Any] = {"tool": tool, "args_preview": {k: args.get(k) for k in args if k != "token"}}
        principal = self._principal(token)
        if not principal:
            rec["result"] = {"ok": False, "error": "unauthenticated"}
            self.audit.append(rec)
            return rec["result"]

        rec["principal"] = principal
        # Model-supplied user_id is ignored. Identity comes from the token.
        claimed = args.get("user_id")
        rec["ignored_user_id"] = claimed

        self.hits[principal] = self.hits.get(principal, 0) + 1
        if self.hits[principal] > self.rate_limit:
            rec["result"] = {"ok": False, "error": "rate_limited"}
            self.audit.append(rec)
            return rec["result"]

        requested = args.get("deadline_ms")
        try:
            requested_i = int(requested) if requested is not None else self.max_deadline_ms
        except (TypeError, ValueError):
            requested_i = self.max_deadline_ms
        enforced = min(max(requested_i, 1), self.max_deadline_ms)
        rec["requested_deadline_ms"] = requested_i
        rec["enforced_deadline_ms"] = enforced
        # The agent cannot raise the cap, even by sending a larger deadline_ms.
        if requested_i > self.max_deadline_ms:
            rec["deadline_clamped"] = True

        tool = tool.lower()
        if tool in {"get", "exists"}:
            key = str(args.get("key") or "")
            if not self._allowed_key(principal, key):
                rec["result"] = {"ok": False, "error": "forbidden_prefix", "key": key}
                self.audit.append(rec)
                return rec["result"]
            cmd = "GET " + key if tool == "get" else "EXISTS " + key
            try:
                raw = self.backend.call(cmd, timeout=enforced / 1000.0)
            except (socket.timeout, TimeoutError):
                rec["result"] = {"ok": False, "error": "deadline_exceeded", "enforced_deadline_ms": enforced}
                self.audit.append(rec)
                return rec["result"]
            rec["backend_ms"] = int((time.monotonic() - started) * 1000)
            rec["result"] = {"ok": True, "raw": raw, "enforced_deadline_ms": enforced}
            self.audit.append(rec)
            return rec["result"]

        if tool == "sleep":
            # Used only to prove deadline clamping; still authenticated.
            ms = int(args.get("ms") or 0)
            try:
                raw = self.backend.call(f"SLEEP {ms}", timeout=enforced / 1000.0)
            except (socket.timeout, TimeoutError):
                rec["result"] = {"ok": False, "error": "deadline_exceeded", "enforced_deadline_ms": enforced}
                self.audit.append(rec)
                return rec["result"]
            rec["result"] = {"ok": True, "raw": raw, "enforced_deadline_ms": enforced}
            self.audit.append(rec)
            return rec["result"]

        if tool == "set":
            key = str(args.get("key") or "")
            value = str(args.get("value") or "")
            ticket = str(args.get("approval") or args.get("approved") or "")
            if not self._allowed_key(principal, key):
                rec["result"] = {"ok": False, "error": "forbidden_prefix", "key": key}
                self.audit.append(rec)
                return rec["result"]
            ap = self.approvals.get(ticket)
            if ap is None or ap.key != key or ap.issued_to != principal:
                rec["result"] = {"ok": False, "error": "write_requires_approval"}
                self.audit.append(rec)
                return rec["result"]
            raw = self.backend.call(f"SET {key} {value}", timeout=enforced / 1000.0)
            rec["result"] = {"ok": True, "raw": raw, "enforced_deadline_ms": enforced}
            self.audit.append(rec)
            return rec["result"]

        rec["result"] = {"ok": False, "error": "unknown_tool"}
        self.audit.append(rec)
        return rec["result"]
