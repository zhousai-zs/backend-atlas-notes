#pragma once
#include <mutex>
#include <string>
#include <unordered_map>
#include <optional>
#include <chrono>
#include <thread>

class KvStore {
 public:
  void set(const std::string& key, const std::string& value) {
    std::lock_guard<std::mutex> g(mu_);
    data_[key] = value;
  }
  std::optional<std::string> get(const std::string& key) const {
    std::lock_guard<std::mutex> g(mu_);
    auto it = data_.find(key);
    if (it == data_.end()) return std::nullopt;
    return it->second;
  }
  bool exists(const std::string& key) const {
    std::lock_guard<std::mutex> g(mu_);
    return data_.count(key) != 0;
  }
  // Teaching hook: block so the gateway can enforce a deadline. Not a production API.
  void debug_sleep(int ms) const {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
  }

 private:
  mutable std::mutex mu_;
  std::unordered_map<std::string, std::string> data_;
};
