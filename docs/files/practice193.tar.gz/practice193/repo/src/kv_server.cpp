#include "kv_store.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cctype>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

static std::string trim(std::string s) {
  while (!s.empty() && (s.back() == '\r' || s.back() == '\n' || s.back() == ' ')) s.pop_back();
  return s;
}

static std::string handle(KvStore& store, const std::string& line) {
  std::istringstream in(line);
  std::string cmd;
  in >> cmd;
  for (char& c : cmd) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  if (cmd == "GET") {
    std::string key;
    in >> key;
    if (key.empty()) return "ERR missing-key";
    auto v = store.get(key);
    return v ? "VALUE " + *v : "MISSING";
  }
  if (cmd == "EXISTS") {
    std::string key;
    in >> key;
    if (key.empty()) return "ERR missing-key";
    return store.exists(key) ? "1" : "0";
  }
  if (cmd == "SET") {
    std::string key, value;
    in >> key;
    std::getline(in, value);
    if (!value.empty() && value[0] == ' ') value.erase(0, 1);
    if (key.empty()) return "ERR missing-key";
    store.set(key, value);
    return "OK";
  }
  if (cmd == "SLEEP") {
    int ms = 0;
    in >> ms;
    if (ms < 0) ms = 0;
    if (ms > 5000) ms = 5000;
    store.debug_sleep(ms);
    return "SLEPT";
  }
  if (cmd == "PING") return "PONG";
  return "ERR unknown-command";
}

static void serve_client(int fd, KvStore* store) {
  std::string buf;
  char tmp[1024];
  while (true) {
    ssize_t n = ::recv(fd, tmp, sizeof(tmp), 0);
    if (n <= 0) break;
    buf.append(tmp, tmp + n);
    size_t pos;
    while ((pos = buf.find('\n')) != std::string::npos) {
      std::string line = trim(buf.substr(0, pos));
      buf.erase(0, pos + 1);
      if (line.empty()) continue;
      std::string resp = handle(*store, line) + "\n";
      if (::send(fd, resp.data(), resp.size(), 0) <= 0) {
        ::close(fd);
        return;
      }
    }
  }
  ::close(fd);
}

int main(int argc, char** argv) {
  int port = 0;
  if (argc >= 2) port = std::stoi(argv[1]);
  KvStore store;
  store.set("alice/profile", "alice-ok");
  store.set("bob/secret", "should-not-leak");
  store.set("alice/item", "item-1");

  int srv = ::socket(AF_INET, SOCK_STREAM, 0);
  if (srv < 0) return 1;
  int opt = 1;
  setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  addr.sin_port = htons(static_cast<uint16_t>(port));
  if (bind(srv, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) return 2;
  if (port == 0) {
    socklen_t len = sizeof(addr);
    if (getsockname(srv, reinterpret_cast<sockaddr*>(&addr), &len) != 0) return 3;
    port = ntohs(addr.sin_port);
  }
  if (listen(srv, 16) != 0) return 4;
  std::cout << "READY " << port << std::endl;
  std::cout.flush();
  std::vector<std::thread> threads;
  while (true) {
    sockaddr_in cli{};
    socklen_t cl = sizeof(cli);
    int fd = accept(srv, reinterpret_cast<sockaddr*>(&cli), &cl);
    if (fd < 0) continue;
    threads.emplace_back(serve_client, fd, &store);
    threads.back().detach();
  }
}
