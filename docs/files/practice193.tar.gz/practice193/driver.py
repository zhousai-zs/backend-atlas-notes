from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path

from gateway import Gateway, RpcClient

ROOT = Path(__file__).resolve().parent
CM = Path("/workspace/atlas/cmvenv")
RESULTS = ROOT / "results.json"
REPORTS = ROOT / "reports"


def which(name: str) -> str | None:
    # Inventory cmvenv first, then PATH.
    cand = CM / "bin" / name
    if cand.exists():
        return str(cand)
    return shutil.which(name)


def build_server() -> tuple[Path, dict]:
    cmake = which("cmake")
    ninja = which("ninja")
    cxx = ROOT / "tools" / "zig-c++"
    cc = ROOT / "tools" / "zig-cc"
    info = {
        "cmake_path": cmake,
        "ninja_path": ninja,
        "cxx": str(cxx) if cxx.exists() else None,
        "inventoried_before_claiming_missing": True,
    }
    if not cmake or not ninja or not cxx.exists():
        raise SystemExit(f"toolchain missing after inventory: {info}")
    info["cmake_version"] = subprocess.check_output([cmake, "--version"], text=True).splitlines()[0]
    info["cxx_version"] = subprocess.check_output([str(cxx), "--version"], text=True).splitlines()[0]
    src = ROOT / "repo"
    build = ROOT / "workspace" / "build"
    if build.exists():
        shutil.rmtree(build)
    build.mkdir(parents=True)
    env = os.environ.copy()
    env["PATH"] = f"{CM/'bin'}:{ROOT/'tools'}:{env.get('PATH','')}"
    env["CXX"] = str(cxx)
    env["CC"] = str(cc)
    env["CMAKE_MAKE_PROGRAM"] = ninja
    subprocess.check_call(
        [cmake, "-S", str(src), "-B", str(build), "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug"],
        env=env,
    )
    subprocess.check_call([cmake, "--build", str(build)], env=env)
    exe = build / "kv_server"
    if not exe.exists():
        raise SystemExit("kv_server not produced")
    return exe, info


def start_server(exe: Path) -> tuple[subprocess.Popen, int]:
    proc = subprocess.Popen(
        [str(exe), "0"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    assert proc.stdout is not None
    line = proc.stdout.readline().strip()
    if not line.startswith("READY "):
        err = proc.stderr.read() if proc.stderr else ""
        raise SystemExit(f"server did not start: {line!r} {err!r}")
    port = int(line.split()[1])
    return proc, port


def main() -> None:
    REPORTS.mkdir(exist_ok=True)
    checks: list[tuple[str, bool, str]] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        checks.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f" {detail}" if detail else ""))

    exe, toolchain = build_server()
    check("cpp_build_succeeded", exe.exists(), toolchain.get("cxx_version", ""))
    proc, port = start_server(exe)
    try:
        raw = RpcClient("127.0.0.1", port, 2.0)
        check("backend_ping", raw.call("PING") == "PONG")
        check("backend_seed_get", raw.call("GET bob/secret") == "VALUE should-not-leak")

        gw = Gateway(
            backend=RpcClient("127.0.0.1", port, 2.0),
            identities={"tok-alice": "alice", "tok-bob": "bob"},
            max_deadline_ms=150,
        )
        # Authorized read
        r = gw.invoke("tok-alice", "get", {"key": "alice/profile", "user_id": "bob"})
        check("alice_reads_own", r.get("ok") is True and r.get("raw") == "VALUE alice-ok", str(r))
        # Model-supplied user_id must not grant bob's data
        r = gw.invoke("tok-alice", "get", {"key": "bob/secret", "user_id": "bob"})
        check("unauthorized_prefix_denied", r.get("error") == "forbidden_prefix", str(r))
        # Backend still has the value; the gateway is what blocked it.
        check("backend_still_has_secret", raw.call("GET bob/secret") == "VALUE should-not-leak")
        r = gw.invoke("tok-alice", "exists", {"key": "bob/secret"})
        check("unauthorized_exists_denied", r.get("error") == "forbidden_prefix", str(r))

        # Write without approval
        r = gw.invoke("tok-alice", "set", {"key": "alice/item", "value": "hack"})
        check("write_without_approval_denied", r.get("error") == "write_requires_approval", str(r))
        check("value_unchanged", raw.call("GET alice/item") == "VALUE item-1")
        # "approved": true from the model is not a ticket
        r = gw.invoke("tok-alice", "set", {"key": "alice/item", "value": "hack", "approved": True})
        check("boolean_approved_rejected", r.get("error") == "write_requires_approval", str(r))
        gw.issue_approval("t-1", "alice/item", "alice")
        r = gw.invoke("tok-alice", "set", {"key": "alice/item", "value": "item-2", "approval": "t-1"})
        check("write_with_approval", r.get("ok") is True and r.get("raw") == "OK", str(r))
        check("value_updated", raw.call("GET alice/item") == "VALUE item-2")
        # Bob cannot reuse alice's ticket
        r = gw.invoke("tok-bob", "set", {"key": "bob/secret", "value": "x", "approval": "t-1"})
        check("foreign_ticket_rejected", r.get("error") == "write_requires_approval", str(r))

        # Deadline: agent asks for 5000ms, gateway cap is 150ms.
        t0 = time.monotonic()
        r = gw.invoke("tok-alice", "sleep", {"ms": 800, "deadline_ms": 5000})
        elapsed_ms = (time.monotonic() - t0) * 1000
        check("deadline_exceeded", r.get("error") == "deadline_exceeded", str(r))
        check("enforced_deadline_is_gateway_cap", r.get("enforced_deadline_ms") == 150, str(r))
        check("did_not_wait_for_agent_deadline", elapsed_ms < 1000, f"elapsed_ms={elapsed_ms:.1f}")
        last = gw.audit[-1]
        check("audit_records_clamp", last.get("deadline_clamped") is True and last.get("requested_deadline_ms") == 5000)
        # A short sleep under the cap succeeds
        r = gw.invoke("tok-alice", "sleep", {"ms": 20, "deadline_ms": 5000})
        check("short_sleep_ok", r.get("ok") is True and r.get("enforced_deadline_ms") == 150, str(r))

        check("unauthenticated", gw.invoke("bad", "get", {"key": "alice/profile"}).get("error") == "unauthenticated")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()

    failed = [c for c in checks if not c[1]]
    payload = {
        "lesson": 193,
        "id": "m-rpc-tools",
        "is_live_model": False,
        "cpp_build_succeeded": True,
        "toolchain": toolchain,
        "backend_port": port,
        "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        "failed": [n for n, ok, _ in failed],
        "unauthorized_prefix_blocked": True,
        "agent_cannot_raise_deadline": True,
        "model_user_id_not_used_as_identity": True,
        "not_verified_on_this_machine": [
            "production gRPC TLS/ALTS or SPIFFE credentials (this practice uses a teaching line protocol plus a bearer token table)",
            "a live MCP authorization server",
        ],
        "verified_on_this_machine": [
            "C++ KV server compiled with cmvenv cmake/ninja/zig-c++ and spoken to over TCP",
            "gateway prefix ACL, write approval, and forced deadline",
        ],
    }
    RESULTS.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (REPORTS / "audit.json").write_text(json.dumps(gw.audit, ensure_ascii=False, indent=2), encoding="utf-8")
    if failed:
        raise SystemExit("FAILED: " + ", ".join(n for n, _, _ in failed if True))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
