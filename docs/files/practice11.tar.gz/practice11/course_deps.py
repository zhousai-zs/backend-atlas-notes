#!/usr/bin/env python3
"""课程依赖检查：Kahn 拓扑序 + 自环/多节点环残留点。"""
from __future__ import annotations

from collections import deque
from typing import Dict, List, Tuple, Optional


def check_course_deps(
    courses: List[str],
    prereq_edges: List[Tuple[str, str]],
) -> Tuple[Optional[List[str]], List[str]]:
    """
    prereq_edges: (pre, course) 表示必须先学 pre，再学 course（边 pre → course）。
    返回 (合法拓扑序或 None, 环相关节点列表)。
    """
    nodes = list(dict.fromkeys(courses))  # 保序去重
    adj: Dict[str, List[str]] = {u: [] for u in nodes}
    indeg: Dict[str, int] = {u: 0 for u in nodes}

    for pre, course in prereq_edges:
        if pre not in adj:
            adj[pre] = []
            indeg.setdefault(pre, 0)
            nodes.append(pre)
        if course not in adj:
            adj[course] = []
            indeg.setdefault(course, 0)
            nodes.append(course)
        adj[pre].append(course)
        indeg[course] += 1

    # 自环：边 pre → pre
    self_loops = [u for u, vs in adj.items() for v in vs if v == u]

    q = deque(sorted([u for u in indeg if indeg[u] == 0]))  # sorted 让演示序稳定
    order: List[str] = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            if v == u:
                continue  # 自环无法通过减入度消除
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)

    if self_loops or len(order) != len(indeg):
        stuck = sorted(set(self_loops) | {u for u, d in indeg.items() if d > 0})
        return None, stuck
    return order, []


def demo() -> None:
    courses = ["a-sequence", "a-hash", "a-tree", "a-graph", "a-shell"]
    # 合法 DAG：多个合法序（hash 与 tree 可互换）
    ok_edges = [
        ("a-sequence", "a-hash"),
        ("a-sequence", "a-tree"),
        ("a-sequence", "a-graph"),
        ("a-hash", "a-graph"),
        ("a-shell", "a-sequence"),
    ]
    order, stuck = check_course_deps(courses, ok_edges)
    print("=== 用例1：无环 ===")
    print("  合法学习顺序:", order)
    print("  环节点:", stuck)
    assert stuck == [] and order is not None
    assert order.index("a-shell") < order.index("a-sequence")
    assert order.index("a-sequence") < order.index("a-graph")
    assert order.index("a-hash") < order.index("a-graph")
    print("  OK: 依赖约束均满足；hash/tree 相对顺序可因实现而变（皆合法）。")

    print("\n=== 用例2：自环 ===")
    order2, stuck2 = check_course_deps(["X", "Y"], [("X", "X"), ("Y", "X")])
    print("  序:", order2, "环节点:", stuck2)
    assert order2 is None and "X" in stuck2
    print("  OK: 检出自环 X。")

    print("\n=== 用例3：多节点环 A→B→C→A ===")
    order3, stuck3 = check_course_deps(
        ["A", "B", "C", "D"],
        [("A", "B"), ("B", "C"), ("C", "A"), ("D", "A")],
    )
    print("  序:", order3, "环节点:", stuck3)
    assert order3 is None
    assert set(stuck3) >= {"A", "B", "C"}
    print("  OK: 检出多节点环；D 指向环，通常也会留在残留集或仅环上三点（本实现含入度未清零者）。")

    print("\n全部用例通过。")


if __name__ == "__main__":
    demo()
