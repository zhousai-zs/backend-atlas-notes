# practice185：诊断 Agent 的结果验证与轨迹评测

教学假设：一个内容后台的值班诊断 Agent 根据冻结参考日志写出报告。日志、工单和租户名都是为实验构造的，不代表任何公司的内部系统。

## 运行

需要 Python 3（本机验证为 3.13.5），只需标准库：

```bash
bash test.sh
```

脚本调用 `python3 driver.py`，把完整输出写入 `run.log`，并生成 `results.json` 与 `artifacts/`。最后一行应为 `ALL_CHECKS_PASSED`。

也可以复制到干净目录后独立运行：

```bash
tmp_dir=$(mktemp -d)
cp -a practice185 "$tmp_dir/"
cd "$tmp_dir/practice185"
bash test.sh
```

## 本包检查什么

- 20 个任务：正常查询、无证据、工具失败、权限拒绝、虚假完成各 4 个；开发集与保留集各 10 个。
- 只在开发集上比较脚本策略 v1 / v2，再在保留集上验收；保留集不参与选择。
- 规则检查器先验文件、证据编号和禁止动作；越权是硬失败，不能被文风分抵消。
- 总说“已完成”的模型替身必须被拒绝。
- 固定脚本路径回放应得到相同状态路径。
- 本次默认不调用付费或网络模型。`results.json` 里的 `live_model.executed` 应为 `false`；四套脚本替身的 `evaluations.<name>.is_live_model` 也应为 `false`。该字段表示是否使用了真实或网络模型，不是“全部离线”的反义标记。

`artifacts/` 是运行时目录，不必事先存在。
