#!/usr/bin/env python3
"""Run lesson 185 evaluation checks and write results.json / artifacts."""

from __future__ import annotations

import json
import os
import platform
import sys
from collections import Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path

from eval_harness.runner import (
    evidence_fingerprints,
    load_suite,
    replay_trace,
    run_suite,
    select_policy_on_dev,
    state_path_of,
)
from eval_harness.scorer import load_human_reviews

ROOT = Path(__file__).resolve().parent
BJ = timezone(timedelta(hours=8))


def now_bj() -> str:
    return datetime.now(BJ).strftime("%Y-%m-%d %H:%M:%S CST")


def compact(summary: dict) -> dict:
    keep = [
        "model",
        "is_live_model",
        "live_model_flag_inconsistent",
        "trials_per_task",
        "overall",
        "by_split",
        "by_category",
        "failure_samples",
        "scripted_paths_reproducible",
    ]
    return {k: summary[k] for k in keep}


def main() -> int:
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    human_path = ROOT / "gold" / "human_reviews.json"
    human_reviews = load_human_reviews(human_path)

    tasks, expected = load_suite(ROOT)
    assert len(tasks) == 20
    cats = Counter(t["category"] for t in tasks)
    splits = Counter(t["split"] for t in tasks)

    # 1) Policy selection uses dev only.
    tune_record = select_policy_on_dev(
        ROOT,
        artifacts,
        candidates=["v1", "v2"],
        human_reviews=human_reviews,
    )
    (artifacts / "tuning.json").write_text(
        json.dumps(tune_record, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    selected = tune_record["selected"]

    # 2) Evaluate v1, v2, always_complete, overreach on all 20 tasks.
    # Scripted policies: 3 trials to show a fixed path reproduces.
    evals = {}
    for name, trials in (("v1", 3), ("v2", 3), ("always_complete", 1), ("overreach", 1)):
        summary = run_suite(
            ROOT,
            artifacts / "runs",
            name,
            tasks=tasks,
            trials=trials,
            human_reviews=human_reviews,
        )
        evals[name] = summary
        (artifacts / f"eval-{name}.json").write_text(
            json.dumps(compact(summary), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    # 3) Replay one trial of each v2 task; state path must match.
    replays = []
    v2_first = [t for t in evals["v2"]["traces"] if t["trial_index"] == 0]
    task_by_id = {t["id"]: t for t in tasks}
    for original in v2_first:
        rec = replay_trace(ROOT, artifacts, task_by_id[original["task_id"]], original)
        replays.append(rec)
    replay_ok = all(r["match"] for r in replays)
    (artifacts / "replay.json").write_text(
        json.dumps({"all_match": replay_ok, "items": replays}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    # 4) Live model gate: do not invent runs. No paid API call is made here.
    live_key_present = any(
        os.environ.get(name)
        for name in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY")
    )
    live = {
        "executed": False,
        "key_detected_in_env": bool(live_key_present),
        "reason": (
            "本实践默认不调用付费或网络模型 API。"
            "即使环境变量中可能存在密钥，本次 runner 也没有读取其内容，也没有发起真实模型请求。"
            "固定脚本模型的路径复现不能当作真实模型已通过。"
        ),
        "variance_recorded": False,
        "interface": {
            "planned_flag": "未提供 --live 实现调用，避免误跑付费接口",
            "would_record": ["task_id", "trial_index", "pass", "taxonomy", "elapsed_ms", "model_name", "model_version"],
        },
    }

    # 5) Checks
    checks = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    check("task_count_20", len(tasks) == 20, f"n={len(tasks)}")
    check(
        "five_categories_times_four",
        cats == {
            "normal_query": 4,
            "no_evidence": 4,
            "tool_failure": 4,
            "permission_denied": 4,
            "fake_complete": 4,
        },
        str(dict(cats)),
    )
    check("split_10_10", splits == {"dev": 10, "heldout": 10}, str(dict(splits)))
    check(
        "each_category_split_balanced",
        all(
            sum(1 for t in tasks if t["category"] == c and t["split"] == s) == 2
            for c in cats
            for s in ("dev", "heldout")
        ),
        "2 dev + 2 heldout per category",
    )
    check(
        "tuning_used_only_dev",
        tune_record["used_split"] == "dev"
        and set(tune_record["used_task_ids"]) == {t["id"] for t in tasks if t["split"] == "dev"}
        and set(tune_record["heldout_task_ids_not_used"]) == {t["id"] for t in tasks if t["split"] == "heldout"}
        and tune_record["heldout_consulted"] is False,
        f"selected={selected}, used={tune_record['used_task_ids']}",
    )
    check("selected_policy_is_v2", selected == "v2", f"selected={selected}")

    v2 = evals["v2"]
    v1 = evals["v1"]
    always = evals["always_complete"]
    over = evals["overreach"]

    check(
        "v2_all_tasks_pass",
        v2["overall"]["passed"] == 60 and v2["overall"]["n"] == 60 and v2["overall"]["hard_fails"] == 0,
        f"v2 overall={v2['overall']}",
    )
    check(
        "v2_heldout_all_pass",
        v2["by_split"]["heldout"]["passed"] == 30 and v2["by_split"]["heldout"]["failed"] == 0,
        f"heldout={v2['by_split']['heldout']}",
    )
    check("v2_scripted_paths_reproducible", v2["scripted_paths_reproducible"], "three trials share one state path per task")

    # v1 should fail the four non-normal categories (3 trials * 8 dev/held tasks in those cats = 24? 
    # 4 categories * 4 tasks * 3 trials = 48 failures if all non-normal fail; 4 normal * 3 = 12 passes)
    v1_by_cat = v1["by_category"]
    check(
        "v1_passes_normal_query",
        v1_by_cat["normal_query"]["failed"] == 0 and v1_by_cat["normal_query"]["passed"] == 12,
        str(v1_by_cat["normal_query"]),
    )
    for cat in ("no_evidence", "tool_failure", "permission_denied", "fake_complete"):
        check(
            f"v1_fails_{cat}",
            v1_by_cat[cat]["passed"] == 0,
            str(v1_by_cat[cat]),
        )
    check(
        "v1_permission_is_hard_fail",
        v1_by_cat["permission_denied"]["hard_fails"] == v1_by_cat["permission_denied"]["n"],
        str(v1_by_cat["permission_denied"]),
    )

    check(
        "always_complete_all_rejected",
        always["overall"]["passed"] == 0 and always["overall"]["n"] == 20,
        str(always["overall"]),
    )
    # Every always_complete failure should mention missing artifacts or wrong evidence,
    # not be accepted because of the "已完成" text.
    always_claimed = all("已完成" in (s.get("final_text") or "") for s in always["scores"])
    always_reject_check = all(
        any(c["name"] == "reject_self_reported_completion" and not c["ok"] for c in s["checks"])
        or any(c["name"] in {"report_file_exists", "gold_evidence_cited", "no_invented_or_placeholder_ids", "report_status"} and not c["ok"] for c in s["checks"])
        for s in always["scores"]
    )
    check("always_complete_claims_done", always_claimed, "all final_text contain 已完成")
    check("always_complete_rejected_by_checkers", always_reject_check, "deterministic checkers rejected all 20")

    check(
        "overreach_all_hard_fail",
        over["overall"]["hard_fails"] == 20 and over["overall"]["passed"] == 0,
        str(over["overall"]),
    )
    # High style/quality must not rescue unauthorized calls.
    over_high_style = all(s["style_score"] >= 0.8 for s in over["scores"])
    over_unauth = all(s["taxonomy"] == "unauthorized" for s in over["scores"])
    check("overreach_style_high_but_hard_fail", over_high_style and over_unauth, f"style high={over_high_style}, taxonomy all unauthorized={over_unauth}")

    check("replay_state_paths_match", replay_ok, f"matched={sum(r['match'] for r in replays)}/{len(replays)}")

    check("live_model_not_executed", live["executed"] is False and live["variance_recorded"] is False, live["reason"])

    # Per-eval and per-trial flags must agree with the offline boundary.
    # is_live_model is "used a live model", not "all trials were offline".
    for name, summary in evals.items():
        trace_live = [bool((t.get("model") or {}).get("is_live_model")) for t in summary["traces"]]
        score_live = [bool((s.get("model") or {}).get("is_live_model")) for s in summary["scores"]]
        check(
            f"{name}_is_live_model_false",
            summary["is_live_model"] is False
            and summary.get("live_model_flag_inconsistent") is False
            and (not any(trace_live))
            and (not any(score_live)),
            (
                f"summary.is_live_model={summary['is_live_model']}, "
                f"inconsistent={summary.get('live_model_flag_inconsistent')}, "
                f"trace_live={sum(trace_live)}/{len(trace_live)}, "
                f"score_live={sum(score_live)}/{len(score_live)}"
            ),
        )
    check(
        "scripted_evals_agree_with_live_model_executed",
        all(evals[name]["is_live_model"] is False for name in evals) and live["executed"] is False,
        "all scripted stubs report is_live_model=false and live_model.executed=false",
    )

    # Human reviews cover a small v2 dev sample and cannot override hard fails
    reviewed_keys = set(human_reviews)
    check("human_reviews_are_v2_dev_sample", len(reviewed_keys) >= 4 and all(k.startswith("v2:") for k in reviewed_keys), f"keys={sorted(reviewed_keys)}")
    # Demonstrate hard-fail override immunity using overreach quality scores
    check(
        "human_or_quality_cannot_override_hard_fail",
        all((s["quality_score"] >= 0.5) and (not s["passed"]) and s["hard_fail"] for s in over["scores"]),
        "overreach quality scores do not flip passed=true",
    )

    fps = evidence_fingerprints(ROOT)
    check("frozen_evidence_20", len(fps) == 20, f"n={len(fps)}")

    failed_checks = [c for c in checks if not c["ok"]]
    all_ok = not failed_checks

    results = {
        "lesson": 185,
        "node_id": "l-eval",
        "generated_at": now_bj(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "evidence_sha256": fps,
        "tuning": {
            "selected": selected,
            "used_split": tune_record["used_split"],
            "used_task_ids": tune_record["used_task_ids"],
            "heldout_task_ids_not_used": tune_record["heldout_task_ids_not_used"],
            "heldout_consulted": tune_record["heldout_consulted"],
            "comparisons_dev": {k: v["dev"] for k, v in tune_record["comparisons"].items()},
        },
        "evaluations": {k: compact(v) for k, v in evals.items()},
        "replay": {"all_match": replay_ok, "n": len(replays)},
        "is_live_model": False,
        "live_model": live,
        "human_reviews_path": str(human_path.relative_to(ROOT)) if human_path.is_file() else None,
        "human_review_keys": sorted(reviewed_keys),
        "checks": checks,
        "all_checks_passed": all_ok,
    }
    (ROOT / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    # Readable summary to stdout (also captured in run.log by test.sh)
    print(f"generated_at={results['generated_at']}")
    print(f"python={results['python']}")
    print(f"tuning_selected={selected} heldout_consulted={tune_record['heldout_consulted']}")
    for name in ("v1", "v2", "always_complete", "overreach"):
        o = evals[name]["overall"]
        print(
            f"eval {name}: n={o['n']} passed={o['passed']} failed={o['failed']} "
            f"hard_fails={o['hard_fails']} pass_rate={o['pass_rate']} "
            f"avg_elapsed_ms={o['avg_elapsed_ms']} avg_tool_calls={o['avg_tool_calls']} "
            f"taxonomy={o['taxonomy']}"
        )
        if name in ("v2", "v1"):
            for split, st in evals[name]["by_split"].items():
                print(f"  {name}/{split}: passed={st['passed']}/{st['n']} taxonomy={st['taxonomy']}")
            for cat, st in evals[name]["by_category"].items():
                print(f"  {name}/{cat}: passed={st['passed']}/{st['n']} hard_fails={st['hard_fails']} taxonomy={st['taxonomy']}")
    print(f"replay_all_match={replay_ok}")
    print(f"live_model_executed={live['executed']}")
    for c in checks:
        mark = "OK" if c["ok"] else "FAIL"
        print(f"CHECK {mark}: {c['name']} ({c['detail']})")
    if all_ok:
        print("ALL_CHECKS_PASSED")
        return 0
    print("SOME_CHECKS_FAILED")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
