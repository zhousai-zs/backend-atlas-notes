"""Minimal agent loop: model proposes actions, executor runs tools, traces are recorded."""

from __future__ import annotations

import time
import traceback
from typing import Any

from .environment import TaskEnvironment
from .models import ScriptedModel
from .tools import ToolExecutor


def run_trial(
    task: dict[str, Any],
    model: ScriptedModel,
    env: TaskEnvironment,
    trial_index: int = 0,
) -> dict[str, Any]:
    budget = task.get("budget") or {}
    max_steps = int(budget.get("max_steps", 8))
    max_tool_calls = int(budget.get("max_tool_calls", 6))
    time_budget_ms = int(budget.get("time_budget_ms", 5000))
    tools = ToolExecutor(env)
    history: list[dict[str, Any]] = []
    started = time.perf_counter()
    budget_failure = None
    final_text = ""
    step_no = 0

    try:
        while True:
            elapsed_ms = (time.perf_counter() - started) * 1000
            if elapsed_ms > time_budget_ms:
                budget_failure = "time_budget_exceeded"
                break
            if step_no >= max_steps:
                budget_failure = "max_steps_exceeded"
                break

            decision = model.decide(task, history, tools)
            step_no += 1
            if decision.kind == "final":
                final_text = decision.text
                history.append(
                    {
                        "type": "final",
                        "text": decision.text,
                        "step": step_no,
                    }
                )
                break

            tool_calls_so_far = sum(1 for s in history if s.get("type") == "tool")
            if tool_calls_so_far >= max_tool_calls:
                budget_failure = "max_tool_calls_exceeded"
                break

            result = tools.call(decision.tool, decision.arguments)
            history.append(
                {
                    "type": "tool",
                    "step": step_no,
                    "tool": result.tool,
                    "arguments": result.arguments,
                    "ok": result.ok,
                    "data": result.data,
                    "error_type": result.error_type,
                    "error_message": result.error_message,
                    "unauthorized": result.unauthorized,
                }
            )
    except Exception as exc:  # unexpected harness bug; surface it clearly
        history.append(
            {
                "type": "harness_error",
                "error": repr(exc),
                "traceback": traceback.format_exc(),
            }
        )

    elapsed_ms = (time.perf_counter() - started) * 1000
    report = None
    report_exists = env.report_path.is_file()
    if report_exists:
        import json

        report = json.loads(env.report_path.read_text(encoding="utf-8"))

    trace = {
        "task_id": task["id"],
        "category": task["category"],
        "split": task["split"],
        "trial_index": trial_index,
        "model": {
            "name": model.name,
            "policy_id": getattr(model, "policy_id", model.name),
            "is_live_model": bool(getattr(model, "is_live_model", False)),
        },
        "steps": history,
        "tool_call_count": sum(1 for s in history if s.get("type") == "tool"),
        "unauthorized_calls": [
            {"tool": s["tool"], "arguments": s.get("arguments")}
            for s in history
            if s.get("unauthorized")
        ],
        "final_text": final_text,
        "report_exists": report_exists,
        "report": report,
        "elapsed_ms": round(elapsed_ms, 3),
        "budget": {
            "max_steps": max_steps,
            "max_tool_calls": max_tool_calls,
            "time_budget_ms": time_budget_ms,
        },
        "budget_failure": budget_failure,
        # Scripted usage counters, not billed API cost.
        "scripted_usage": {
            "model_decisions": step_no,
            "tool_calls": sum(1 for s in history if s.get("type") == "tool"),
            "units": step_no + sum(1 for s in history if s.get("type") == "tool"),
        },
    }
    return trace
