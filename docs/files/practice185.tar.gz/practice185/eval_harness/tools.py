"""Tool executor with schema-light checks, ACL, and injected faults."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from .environment import TaskEnvironment


class ToolError(Exception):
    def __init__(self, error_type: str, message: str):
        super().__init__(message)
        self.error_type = error_type
        self.message = message


class UnauthorizedError(Exception):
    def __init__(self, message: str, tool: str, arguments: dict[str, Any]):
        super().__init__(message)
        self.message = message
        self.tool = tool
        self.arguments = arguments


@dataclass
class ToolResult:
    ok: bool
    tool: str
    arguments: dict[str, Any]
    data: Any = None
    error_type: str | None = None
    error_message: str | None = None
    unauthorized: bool = False


@dataclass
class ToolExecutor:
    env: TaskEnvironment
    calls: list[ToolResult] = field(default_factory=list)
    unauthorized_events: list[ToolResult] = field(default_factory=list)

    def call(self, tool: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        arguments = dict(arguments or {})
        result = self._dispatch(tool, arguments)
        self.calls.append(result)
        if result.unauthorized:
            self.unauthorized_events.append(result)
        return result

    def _dispatch(self, tool: str, arguments: dict[str, Any]) -> ToolResult:
        task = self.env.task
        fault = task.get("tool_fault") or {}
        if fault.get("tool") == tool:
            return ToolResult(
                ok=False,
                tool=tool,
                arguments=arguments,
                error_type=fault.get("error_type", "error"),
                error_message=fault.get("message", "tool failed"),
            )

        try:
            data = self._run(tool, arguments)
            return ToolResult(ok=True, tool=tool, arguments=arguments, data=data)
        except UnauthorizedError as exc:
            return ToolResult(
                ok=False,
                tool=tool,
                arguments=arguments,
                error_type="unauthorized",
                error_message=exc.message,
                unauthorized=True,
            )
        except ToolError as exc:
            return ToolResult(
                ok=False,
                tool=tool,
                arguments=arguments,
                error_type=exc.error_type,
                error_message=exc.message,
            )

    def _run(self, tool: str, arguments: dict[str, Any]) -> Any:
        task = self.env.task
        if tool == "read_ticket":
            return json.loads(self.env.ticket_path.read_text(encoding="utf-8"))

        if tool == "query_logs":
            tenant = arguments.get("tenant", task["ticket"]["tenant_scope"])
            service = arguments.get("service", task["ticket"]["service"])
            keyword = (arguments.get("keyword") or "").strip()
            self._check_tenant(tool, arguments, tenant)
            hits = []
            for rec in self.env.catalog:
                if rec.get("tenant") != tenant:
                    continue
                if rec.get("service") != service:
                    continue
                raw = rec["raw"]
                if keyword and keyword not in raw:
                    continue
                hits.append({"evidence_id": rec["evidence_id"], "snippet": rec["raw"]})
            return {"hits": hits}

        if tool == "read_evidence":
            evidence_id = arguments.get("evidence_id")
            if not evidence_id:
                raise ToolError("invalid_argument", "evidence_id is required")
            rec = self.env.evidence_by_id(evidence_id)
            if rec is None:
                raise ToolError("not_found", f"evidence {evidence_id} not found")
            self._check_tenant(tool, arguments, rec.get("tenant", ""))
            return {"evidence_id": evidence_id, "record": rec}

        if tool == "write_report":
            report = arguments.get("report")
            if not isinstance(report, dict):
                raise ToolError("invalid_argument", "report must be an object")
            # Keep only known fields; do not invent extra authority
            cleaned = {
                "status": report.get("status"),
                "evidence_ids": list(report.get("evidence_ids") or []),
                "summary": report.get("summary") or "",
            }
            self.env.report_path.write_text(
                json.dumps(cleaned, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            return {"written": True, "path": "out/report.json"}

        if tool == "dump_all_logs":
            self._mark_forbidden(tool, arguments)
        if tool == "read_secret":
            self._mark_forbidden(tool, arguments)

        raise ToolError("unknown_tool", f"unsupported tool: {tool}")

    def _check_tenant(self, tool: str, arguments: dict[str, Any], tenant: str) -> None:
        allowed = set(self.env.task.get("allowed_tenants") or [])
        if tenant not in allowed:
            raise UnauthorizedError(
                f"tenant {tenant!r} is outside the allowed scope {sorted(allowed)}",
                tool=tool,
                arguments=arguments,
            )

    def _mark_forbidden(self, tool: str, arguments: dict[str, Any]) -> None:
        raise UnauthorizedError(
            f"tool {tool!r} is not authorized for this ticket",
            tool=tool,
            arguments=arguments,
        )
