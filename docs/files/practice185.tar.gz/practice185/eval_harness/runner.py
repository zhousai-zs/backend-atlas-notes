"""Eval runner: isolated trials, policy selection on dev only, replay, aggregation."""

from __future__ import annotations

import hashlib
import json
import shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .agent import run_trial
from .environment import TaskEnvironment
from .models import build_model
from .scorer import load_human_reviews, score_trace


def load_suite(root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    tasks = json.loads((root / "data" / "tasks.json").read_text(encoding="utf-8"))["tasks"]
    expected = json.loads((root / "gold" / "expected.json").read_text(encoding="utf-8"))
    return tasks, expected


def evidence_fingerprints(root: Path) -> dict[str, str]:
    out = {}
    for path in sorted((root / "data" / "evidence").glob("*.log")):
        out[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return out


def run_suite(
    root: Path,
    work_root: Path,
    model_name: str,
    tasks: list[dict[str, Any]] | None = None,
    trials: int = 1,
    human_reviews: dict[str, Any] | None = None,
) -> dict[str, Any]:
    all_tasks, expected = load_suite(root)
    selected = tasks if tasks is not None else all_tasks
    work_root.mkdir(parents=True, exist_ok=True)
    traces = []
    scores = []
    for task in selected:
        for trial_index in range(trials):
            env_dir = work_root / model_name / task["id"] / f"trial-{trial_index}"
            if env_dir.exists():
                shutil.rmtree(env_dir)
            env = TaskEnvironment(task, root / "data" / "evidence", env_dir)
            model = build_model(model_name)
            trace = run_trial(task, model, env, trial_index=trial_index)
            (env_dir / "trace.json").write_text(
                json.dumps(trace, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            score = score_trace(task, expected[task["id"]], trace, human_reviews=human_reviews)
            (env_dir / "score.json").write_text(
                json.dumps(score, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            traces.append(trace)
            scores.append(score)
    return summarize(model_name, traces, scores, trials=trials)


def summarize(
    model_name: str,
    traces: list[dict[str, Any]],
    scores: list[dict[str, Any]],
    trials: int,
) -> dict[str, Any]:
    by_split: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_category: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for s in scores:
        by_split[s["split"]].append(s)
        by_category[s["category"]].append(s)

    def bucket(items: list[dict[str, Any]]) -> dict[str, Any]:
        n = len(items)
        passed = sum(1 for s in items if s["passed"])
        return {
            "n": n,
            "passed": passed,
            "failed": n - passed,
            "pass_rate": round(passed / n, 4) if n else None,
            "hard_fails": sum(1 for s in items if s["hard_fail"]),
            "taxonomy": dict(Counter(s["taxonomy"] for s in items)),
            "avg_elapsed_ms": round(sum(s["elapsed_ms"] for s in items) / n, 3) if n else None,
            "avg_tool_calls": round(sum(s["tool_call_count"] for s in items) / n, 3) if n else None,
            "avg_scripted_units": round(
                sum((s.get("scripted_usage") or {}).get("units", 0) for s in items) / n, 3
            )
            if n
            else None,
            "avg_quality_score": round(sum(s["quality_score"] for s in items) / n, 3) if n else None,
        }

    failures = [s for s in scores if not s["passed"]]
    failure_samples = []
    for s in failures:
        failure_samples.append(
            {
                "task_id": s["task_id"],
                "split": s["split"],
                "category": s["category"],
                "taxonomy": s["taxonomy"],
                "hard_fail": s["hard_fail"],
                "hard_reasons": s["hard_reasons"],
                "failed_checks": [c["name"] for c in s["checks"] if not c["ok"]],
                "final_text": s.get("final_text"),
                "report": s.get("report"),
            }
        )

    # Reproducibility of scripted paths: compare state paths across trials
    path_groups: dict[str, set[str]] = defaultdict(set)
    for t in traces:
        key = f"{t['task_id']}"
        path_groups[key].add(_state_path(t))
    reproducible = {tid: (len(paths) == 1) for tid, paths in path_groups.items()}

    # is_live_model means a real/network model was used in this evaluation.
    # Do not invert the per-trial flags: all(not flag) is "all offline", not "is live".
    live_flags = [bool((t.get("model") or {}).get("is_live_model")) for t in traces]
    live_inconsistent = bool(live_flags) and any(live_flags) and not all(live_flags)
    return {
        "model": model_name,
        "is_live_model": any(live_flags),
        "live_model_flag_inconsistent": live_inconsistent,
        "trials_per_task": trials,
        "overall": bucket(scores),
        "by_split": {k: bucket(v) for k, v in sorted(by_split.items())},
        "by_category": {k: bucket(v) for k, v in sorted(by_category.items())},
        "failure_samples": failure_samples,
        "scripted_paths_reproducible": all(reproducible.values()) if traces else True,
        "reproducible_by_task": reproducible,
        "scores": scores,
        "traces": traces,
    }


def _state_path(trace: dict[str, Any]) -> str:
    compact = []
    for step in trace.get("steps") or []:
        if step.get("type") == "tool":
            compact.append(
                {
                    "type": "tool",
                    "tool": step.get("tool"),
                    "arguments": step.get("arguments"),
                    "ok": step.get("ok"),
                    "error_type": step.get("error_type"),
                    "unauthorized": step.get("unauthorized"),
                    "data": _strip_volatile(step.get("data")),
                }
            )
        elif step.get("type") == "final":
            compact.append({"type": "final", "text": step.get("text")})
        else:
            compact.append({"type": step.get("type")})
    compact.append({"report": trace.get("report"), "budget_failure": trace.get("budget_failure")})
    return json.dumps(compact, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _strip_volatile(data: Any) -> Any:
    return data


def state_path_of(trace: dict[str, Any]) -> str:
    return _state_path(trace)


def replay_trace(root: Path, work_root: Path, task: dict[str, Any], original: dict[str, Any]) -> dict[str, Any]:
    """Re-run the same scripted model; compare state path, not wall-clock time."""
    model_name = original["model"]["policy_id"]
    env_dir = work_root / "replay" / model_name / task["id"] / f"trial-{original['trial_index']}"
    if env_dir.exists():
        shutil.rmtree(env_dir)
    env = TaskEnvironment(task, root / "data" / "evidence", env_dir)
    model = build_model(model_name)
    replayed = run_trial(task, model, env, trial_index=original["trial_index"])
    (env_dir / "trace.json").write_text(
        json.dumps(replayed, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return {
        "task_id": task["id"],
        "match": state_path_of(original) == state_path_of(replayed),
        "original_path": state_path_of(original),
        "replayed_path": state_path_of(replayed),
        "elapsed_ms_original": original.get("elapsed_ms"),
        "elapsed_ms_replayed": replayed.get("elapsed_ms"),
    }


def select_policy_on_dev(
    root: Path,
    work_root: Path,
    candidates: list[str],
    human_reviews: dict[str, Any] | None = None,
) -> dict[str, Any]:
    tasks, _ = load_suite(root)
    dev = [t for t in tasks if t["split"] == "dev"]
    held_ids = [t["id"] for t in tasks if t["split"] == "heldout"]
    results = {}
    for name in candidates:
        summary = run_suite(
            root,
            work_root / "tune",
            name,
            tasks=dev,
            trials=1,
            human_reviews=human_reviews,
        )
        # Drop heavy traces from the recorded tuning record, keep scores needed to choose.
        results[name] = {
            "dev": summary["by_split"].get("dev") or summary["overall"],
            "overall_on_loaded_tasks": summary["overall"],
            "failure_samples": summary["failure_samples"],
            "loaded_task_ids": [t["id"] for t in dev],
        }
    # Selection rule: maximize dev pass_rate, then minimize hard_fails, then prefer v2 if tied.
    def key(name: str) -> tuple:
        dev_stats = results[name]["dev"]
        return (
            dev_stats["pass_rate"] or 0.0,
            -dev_stats["hard_fails"],
            1 if name == "v2" else 0,
        )

    selected = sorted(candidates, key=key, reverse=True)[0]
    record = {
        "candidates": candidates,
        "selected": selected,
        "rule": "maximize dev pass_rate, then minimize hard_fails, then prefer v2 if tied",
        "used_split": "dev",
        "used_task_ids": [t["id"] for t in dev],
        "heldout_task_ids_not_used": held_ids,
        "heldout_consulted": False,
        "comparisons": results,
        "note": "Policy selection looked only at the dev split. Held-out tasks were not loaded or scored in this step.",
    }
    return record
