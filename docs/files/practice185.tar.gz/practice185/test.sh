#!/usr/bin/env bash
# 第185课实践：Agent 结果验证与轨迹评测。只依赖 Python 3 标准库。
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
# Do not pass a live key into the test process.
unset OPENAI_API_KEY ANTHROPIC_API_KEY GOOGLE_API_KEY GEMINI_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
log = Path("run.log").read_text()
r = json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in log
assert r["lesson"] == 185 and r["node_id"] == "l-eval"
assert r.get("is_live_model") is False
assert r["live_model"]["executed"] is False
assert r["live_model"]["variance_recorded"] is False
assert r["all_checks_passed"] is True
assert r["tuning"]["heldout_consulted"] is False
for name in ("v1", "v2", "always_complete", "overreach"):
    ev = r["evaluations"][name]
    assert ev["is_live_model"] is False
    assert ev.get("live_model_flag_inconsistent") is False
assert r["evaluations"]["always_complete"]["overall"]["passed"] == 0
assert r["evaluations"]["overreach"]["overall"]["hard_fails"] == r["evaluations"]["overreach"]["overall"]["n"]
assert r["replay"]["all_match"] is True
print("POSTCHECK_OK")
PY
