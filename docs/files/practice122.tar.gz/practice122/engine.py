#!/usr/bin/env python3
"""Teaching MessageDeliveryEngine — not Redis, not a real broker, not a network service.

A Python 3 standard-library model of a topic with partitions, a producer,
a consumer, a wallet, an outbox, and a dead-letter log. It is used to
observe ack vs redelivery, outbox vs "send after commit", per-partition
ordering, poison-message isolation, and the gap between exactly-once
processing of local state and uncoordinated external side effects.

Delivery-semantics terms follow Apache Kafka's "Message Delivery
Semantics" (AK 4.4 docs, checked on 2026-11-14): at-most-once, at-least-once,
exactly-once; process-then-save-position vs save-position-then-process;
store the consumer position in the same recoverable place as the output;
exactly-once for non-Kafka destinations needs cooperation with those
systems. This engine is not Kafka, not a Kafka client, not Kafka Streams,
and not a transactional producer. There is no ISR, no broker replication,
no transactional.id, no isolation.level, and no TCP. The log is an
in-process list. Persistence is a teaching dict flushed before replies,
not a disk or fsync. Clock is virtual. rpc_delay_s is a teaching delay,
not production RTT.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
TOPIC = "wallet-credits"
RPC_DELAY_S = 0.01
DEFAULT_CREDIT = 30
INITIAL_BALANCE = 100


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class LogRecord:
    offset: int
    partition: int
    key: str
    value: dict[str, Any]
    produce_t: float
    producer_id: Optional[str] = None
    seq: Optional[int] = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "offset": self.offset,
            "partition": self.partition,
            "key": self.key,
            "value": dict(self.value),
            "produce_t": self.produce_t,
            "producer_id": self.producer_id,
            "seq": self.seq,
        }


class MessageDeliveryEngine:
    def __init__(
        self,
        n_partitions: int = 1,
        rpc_delay_s: float = RPC_DELAY_S,
        balance: int = INITIAL_BALANCE,
        max_retries: int = 3,
        dedup_retain_s: Optional[float] = None,
    ) -> None:
        self.clock = Clock()
        self.rpc_delay_s = float(rpc_delay_s)
        self.n_partitions = int(n_partitions)
        self.max_retries = int(max_retries)
        self.dedup_retain_s = dedup_retain_s
        self.flush_count = 0
        self.rpc_count = 0
        self.events: list[dict[str, Any]] = []

        self.logs: dict[int, list[LogRecord]] = {p: [] for p in range(self.n_partitions)}
        # Idempotent-producer teaching state: (producer_id, seq) already in the log.
        self.producer_seen: set[tuple[str, int]] = set()
        self._producer_seq: dict[str, int] = {}

        # Consumer group durable position: next offset to read, per partition.
        self.committed: dict[int, int] = {p: 0 for p in range(self.n_partitions)}
        # Volatile fetch position (lost on consumer crash).
        self.position: dict[int, int] = {p: 0 for p in range(self.n_partitions)}
        self.in_flight: dict[int, Optional[LogRecord]] = {p: None for p in range(self.n_partitions)}
        self.attempts: dict[tuple[int, int], int] = {}  # (partition, offset) -> attempts
        self.consumer_down = False

        # Wallet durable state.
        self.balance = int(balance)
        self.initial_balance = int(balance)
        self.ledger: list[dict[str, Any]] = []
        self.dedup: dict[str, dict[str, Any]] = {}  # idempotency key -> record
        # External side effect that is NOT in the same durable boundary.
        self.push_attempts = 0
        self.pushes: list[dict[str, Any]] = []

        # Outbox (same flush as business writes when used).
        self.outbox: list[dict[str, Any]] = []
        self.dlq: list[dict[str, Any]] = []

        self._event("init", partitions=self.n_partitions, balance=self.balance)

    # ------------------------------------------------------------------ clock
    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def _flush(self, agent: str, reason: str) -> None:
        self.flush_count += 1
        self._event("persist_flushed", agent=agent, reason=reason, flush_count=self.flush_count)

    def _rpc(self) -> None:
        self.rpc_count += 1
        self.clock.wait_until(self.clock.now() + self.rpc_delay_s)

    def _partition_for(self, key: str) -> int:
        # Deterministic teaching hash: not Kafka's murmur2.
        return sum(key.encode()) % self.n_partitions

    def _expire_dedup(self) -> None:
        if self.dedup_retain_s is None:
            return
        cutoff = self.clock.now() - self.dedup_retain_s
        expired = [k for k, rec in self.dedup.items() if rec["t"] <= cutoff + 1e-12]
        for k in expired:
            rec = self.dedup.pop(k)
            self._event("dedup_expired", key=k, written_t=rec["t"])

    # ------------------------------------------------------------------ produce
    def produce(
        self,
        key: str,
        value: dict[str, Any],
        *,
        partition: Optional[int] = None,
        producer_id: Optional[str] = None,
        idempotent: bool = False,
        duplicate_send: bool = False,
    ) -> list[dict[str, Any]]:
        """Append to the teaching log. duplicate_send models a retried produce.

        If idempotent=True, a retried send with the same producer_id and seq
        is not appended again (teaching stand-in for the Kafka 0.11+
        idempotent producer). This is not Kafka's actual PID/epoch protocol.
        """
        if partition is None:
            partition = self._partition_for(key)
        results = []
        seq = None
        if producer_id is not None:
            self._producer_seq.setdefault(producer_id, 0)
            self._producer_seq[producer_id] += 1
            seq = self._producer_seq[producer_id]
        attempts = 2 if duplicate_send else 1
        for i in range(attempts):
            self._rpc()
            appended = True
            if idempotent and producer_id is not None:
                if (producer_id, seq) in self.producer_seen:
                    appended = False
            if appended:
                off = len(self.logs[partition])
                rec = LogRecord(off, partition, key, dict(value), self.clock.now(), producer_id, seq)
                self.logs[partition].append(rec)
                if producer_id is not None:
                    self.producer_seen.add((producer_id, seq))
                self._flush("broker", "append")
                self._event("produced", **rec.as_dict(), retried=i > 0, appended=True)
                results.append({**rec.as_dict(), "appended": True, "retried": i > 0})
            else:
                existing = next(
                    r for r in self.logs[partition] if r.producer_id == producer_id and r.seq == seq
                )
                self._event("produce_deduped", partition=partition, offset=existing.offset, producer_id=producer_id, seq=seq)
                results.append({**existing.as_dict(), "appended": False, "retried": i > 0})
        return results

    # ------------------------------------------------------------------ consume
    def poll(self, partition: int = 0) -> Optional[dict[str, Any]]:
        if self.consumer_down:
            raise RuntimeError("consumer is down")
        self._rpc()
        log = self.logs[partition]
        pos = self.position[partition]
        if pos >= len(log):
            self.in_flight[partition] = None
            return None
        rec = log[pos]
        self.in_flight[partition] = rec
        self.position[partition] = pos + 1
        self.attempts[(partition, rec.offset)] = self.attempts.get((partition, rec.offset), 0) + 1
        self._event("polled", partition=partition, offset=rec.offset, key=rec.key, attempt=self.attempts[(partition, rec.offset)])
        return rec.as_dict()

    def ack(self, partition: int = 0) -> dict[str, Any]:
        """Commit the consumer position (teaching stand-in for offset commit).

        committed[p] is the next offset to read. ack after processing a
        record at offset k stores k+1.
        """
        if self.consumer_down:
            raise RuntimeError("consumer is down")
        rec = self.in_flight[partition]
        if rec is None:
            raise RuntimeError("nothing in flight")
        self._rpc()
        self.committed[partition] = rec.offset + 1
        self.in_flight[partition] = None
        self._flush("consumer", "ack")
        self._event("acked", partition=partition, committed_offset=self.committed[partition], key=rec.key)
        return {"partition": partition, "committed_offset": self.committed[partition]}

    def crash_consumer(self) -> None:
        self.consumer_down = True
        self.in_flight = {p: None for p in range(self.n_partitions)}
        # Volatile position is lost; on recover it is reloaded from committed.
        self._event("consumer_crashed", committed=dict(self.committed))

    def recover_consumer(self) -> dict[str, Any]:
        self.consumer_down = False
        self.position = dict(self.committed)
        self.in_flight = {p: None for p in range(self.n_partitions)}
        self._event("consumer_recovered", position=dict(self.position))
        return {"position": dict(self.position), "committed": dict(self.committed)}

    def rewind(self, partition: int = 0, offset: int = 0) -> None:
        """Teaching rewind (Kafka allows seeking to an old offset)."""
        self.committed[partition] = offset
        self.position[partition] = offset
        self.in_flight[partition] = None
        self._flush("consumer", "rewind")
        self._event("rewound", partition=partition, offset=offset)

    # ------------------------------------------------------------------ wallet apply
    def apply(
        self,
        rec: dict[str, Any],
        *,
        use_dedup: bool = True,
        external_push: bool = False,
        include_push_in_boundary: bool = False,
    ) -> dict[str, Any]:
        """Apply a credit to the wallet.

        The idempotency key and the balance are flushed together when
        use_dedup is True — the same recoverable boundary. An external
        push is issued on every apply attempt unless include_push_in_boundary
        is also True (which still only records it locally; it is not a
        real HTTP call).
        """
        if self.consumer_down:
            raise RuntimeError("consumer is down")
        self._expire_dedup()
        value = rec["value"]
        if value.get("op") == "poison" or not isinstance(value.get("amount"), int):
            attempt = self.attempts[(rec["partition"], rec["offset"])]
            self._event("apply_rejected", key=rec["key"], offset=rec["offset"], attempt=attempt, reason="poison")
            return {"applied": False, "poison": True, "attempt": attempt, "balance": self.balance}

        key = value.get("idempotency_key") or rec["key"]
        amount = int(value["amount"])
        duplicate = use_dedup and key in self.dedup
        pushed = False
        # Uncoordinated external side effect: happens even on a duplicate
        # unless the caller folded it into the same boundary.
        if external_push and not (include_push_in_boundary and duplicate):
            self.push_attempts += 1
            self.pushes.append({"t": self.now(), "key": key, "duplicate": duplicate, "n": self.push_attempts})
            pushed = True

        if duplicate:
            self._event("apply_duplicate", key=key, amount=amount, balance=self.balance)
            return {
                "applied": False,
                "duplicate": True,
                "poison": False,
                "balance": self.balance,
                "pushed": pushed,
                "push_attempts": self.push_attempts,
            }

        self.balance += amount
        self.ledger.append({"t": self.now(), "key": key, "amount": amount, "balance": self.balance, "offset": rec["offset"], "partition": rec["partition"]})
        if use_dedup:
            self.dedup[key] = {"amount": amount, "t": self.now(), "offset": rec["offset"]}
        if include_push_in_boundary and external_push and not pushed:
            self.push_attempts += 1
            self.pushes.append({"t": self.now(), "key": key, "duplicate": False, "n": self.push_attempts, "in_boundary": True})
            pushed = True
        self._flush("wallet", "apply")
        self._event("applied", key=key, amount=amount, balance=self.balance, used_dedup=use_dedup)
        return {
            "applied": True,
            "duplicate": False,
            "poison": False,
            "balance": self.balance,
            "pushed": pushed,
            "push_attempts": self.push_attempts,
        }

    def isolate_poison(self, rec: dict[str, Any]) -> dict[str, Any]:
        """Move a poison record to the teaching DLQ and allow the partition to advance."""
        item = {**rec, "attempts": self.attempts[(rec["partition"], rec["offset"])], "isolated_t": self.now()}
        self.dlq.append(item)
        self._flush("broker", "dlq")
        self._event("poison_isolated", partition=rec["partition"], offset=rec["offset"], key=rec["key"], attempts=item["attempts"])
        return item

    # ------------------------------------------------------------------ outbox
    def business_commit(
        self,
        *,
        credit: int,
        idempotency_key: str,
        publish_now: bool = False,
        use_outbox: bool = True,
        crash_after_commit: bool = False,
        article: str = KEY_TITLE,
        title: str = TITLE_V1,
    ) -> dict[str, Any]:
        """Commit a local business change, optionally with an outbox row.

        use_outbox=True: the outbox row is flushed with the balance.
        publish_now=True and use_outbox=False: send after the commit
        (a crash between them loses the message).
        """
        self.balance += credit
        self.ledger.append({"t": self.now(), "key": idempotency_key, "amount": credit, "balance": self.balance, "source": "business"})
        self.dedup[idempotency_key] = {"amount": credit, "t": self.now(), "source": "business"}
        row = None
        if use_outbox:
            row = {
                "id": f"ob-{len(self.outbox)+1}",
                "key": idempotency_key,
                "value": {"op": "credit", "amount": credit, "idempotency_key": idempotency_key, "article": article, "title": title},
                "sent": False,
                "t": self.now(),
            }
            self.outbox.append(row)
        self._flush("wallet", "business_commit")
        self._event("business_committed", key=idempotency_key, amount=credit, balance=self.balance, outbox=bool(row))
        if crash_after_commit and not use_outbox:
            # Model a crash before the subsequent produce.
            self._event("crashed_after_business_before_send", key=idempotency_key)
            return {"committed": True, "produced": False, "lost": True, "outbox": False, "balance": self.balance}
        if publish_now and not use_outbox:
            self.produce(idempotency_key, {"op": "credit", "amount": credit, "idempotency_key": idempotency_key, "article": article, "title": title})
            return {"committed": True, "produced": True, "lost": False, "outbox": False, "balance": self.balance}
        return {"committed": True, "produced": False, "lost": False, "outbox": bool(row), "balance": self.balance, "outbox_id": row["id"] if row else None}

    def drain_outbox(self) -> list[dict[str, Any]]:
        sent = []
        for row in self.outbox:
            if row["sent"]:
                continue
            self.produce(row["key"], dict(row["value"]))
            row["sent"] = True
            row["sent_t"] = self.now()
            self._flush("wallet", "outbox_sent")
            self._event("outbox_sent", id=row["id"], key=row["key"])
            sent.append(dict(row))
        return sent

    # ------------------------------------------------------------------ views
    def snapshot(self) -> dict[str, Any]:
        return {
            "t": self.now(),
            "balance": self.balance,
            "committed": dict(self.committed),
            "position": dict(self.position),
            "log_lengths": {str(p): len(self.logs[p]) for p in self.logs},
            "dedup_keys": sorted(self.dedup),
            "dlq_count": len(self.dlq),
            "dlq": [
                {"partition": x["partition"], "offset": x["offset"], "key": x["key"], "attempts": x["attempts"]}
                for x in self.dlq
            ],
            "outbox_pending": sum(1 for r in self.outbox if not r["sent"]),
            "outbox_sent": sum(1 for r in self.outbox if r["sent"]),
            "push_attempts": self.push_attempts,
            "ledger": list(self.ledger),
            "consumer_down": self.consumer_down,
        }
