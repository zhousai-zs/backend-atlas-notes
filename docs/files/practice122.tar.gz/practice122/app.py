#!/usr/bin/env python3
"""Run the lesson 122 message-delivery experiments."""
from __future__ import annotations

from typing import Any, Optional

from engine import (
    DEFAULT_CREDIT,
    INITIAL_BALANCE,
    KEY_TITLE,
    RPC_DELAY_S,
    TITLE_V1,
    TOPIC,
    MessageDeliveryEngine,
)


def _step(eng: MessageDeliveryEngine, name: str, **extra: Any) -> dict[str, Any]:
    return {"t": eng.now(), "step": name, **eng.snapshot(), **extra}


def run_process_then_crash(*, use_dedup: bool) -> dict[str, Any]:
    """Process a credit, crash before ack, recover, and redeliver."""
    eng = MessageDeliveryEngine()
    trace: list[dict[str, Any]] = []
    trace.append(_step(eng, "初始：余额 100，日志为空"))
    produced = eng.produce(
        "settlement:s1",
        {"op": "credit", "amount": DEFAULT_CREDIT, "idempotency_key": "settlement:s1", "article": KEY_TITLE, "title": TITLE_V1},
    )
    trace.append(_step(eng, "生产者写入一条入账消息", produced=produced))
    rec = eng.poll(0)
    applied = eng.apply(rec, use_dedup=use_dedup)
    trace.append(_step(eng, "消费者处理消息，余额已增加，尚未 ack", applied=applied, rec=rec))
    eng.crash_consumer()
    trace.append(_step(eng, "业务提交后、ack 前消费者崩溃", applied=applied))
    recovered = eng.recover_consumer()
    rec2 = eng.poll(0)
    applied2 = eng.apply(rec2, use_dedup=use_dedup)
    trace.append(_step(eng, "恢复后同一条消息被重投并再次处理", recovered=recovered, rec=rec2, applied=applied2))
    ack = eng.ack(0)
    trace.append(_step(eng, "第二次处理后 ack，提交消费位置", ack=ack))
    return {
        "use_dedup": use_dedup,
        "trace": trace,
        "initial_balance": INITIAL_BALANCE,
        "credit": DEFAULT_CREDIT,
        "balance_after_first_apply": applied["balance"],
        "balance_after_redelivery": applied2["balance"],
        "first_applied": applied["applied"],
        "second_duplicate": applied2.get("duplicate", False),
        "second_applied": applied2["applied"],
        "final_balance": eng.balance,
        "double_credited": eng.balance == INITIAL_BALANCE + 2 * DEFAULT_CREDIT,
        "exactly_once_wallet": eng.balance == INITIAL_BALANCE + DEFAULT_CREDIT,
        "committed_offset": eng.committed[0],
        "log_length": len(eng.logs[0]),
        "t_end": eng.now(),
        "rpc_count": eng.rpc_count,
        "flush_count": eng.flush_count,
    }


def run_ack_then_crash() -> dict[str, Any]:
    """Save position first, then crash before processing — at-most-once / lost message."""
    eng = MessageDeliveryEngine()
    eng.produce("settlement:s1", {"op": "credit", "amount": DEFAULT_CREDIT, "idempotency_key": "settlement:s1"})
    rec = eng.poll(0)
    ack = eng.ack(0)
    # Crash after ack, before apply.
    eng.crash_consumer()
    recovered = eng.recover_consumer()
    rec2 = eng.poll(0)
    return {
        "acked_before_apply": True,
        "ack": ack,
        "recovered_position": recovered["position"],
        "repoll": rec2,
        "message_lost": rec2 is None,
        "final_balance": eng.balance,
        "credit_missing": eng.balance == INITIAL_BALANCE,
        "t_end": eng.now(),
    }


def run_outbox_vs_send_after_commit() -> dict[str, Any]:
    lost = MessageDeliveryEngine()
    r_lost = lost.business_commit(credit=DEFAULT_CREDIT, idempotency_key="settlement:out-lost", publish_now=True, use_outbox=False, crash_after_commit=True)
    # After "restart", there is no outbox to drain and nothing in the log.
    safe = MessageDeliveryEngine()
    r_safe = safe.business_commit(credit=DEFAULT_CREDIT, idempotency_key="settlement:out-ok", use_outbox=True)
    # Crash after the joint commit, before the poller runs.
    pending_before = safe.snapshot()["outbox_pending"]
    drained = safe.drain_outbox()
    return {
        "send_after_commit": {
            "result": r_lost,
            "log_length": len(lost.logs[0]),
            "balance": lost.balance,
            "message_lost": r_lost["lost"] and len(lost.logs[0]) == 0,
        },
        "outbox": {
            "result": r_safe,
            "pending_after_commit": pending_before,
            "drained": drained,
            "log_length": len(safe.logs[0]),
            "balance": safe.balance,
            "message_published_after_drain": len(safe.logs[0]) == 1 and pending_before == 1,
        },
        "outbox_survives_crash_before_send": pending_before == 1 and len(safe.logs[0]) == 1,
        "t_end_lost": lost.now(),
        "t_end_outbox": safe.now(),
    }


def run_ordering() -> dict[str, Any]:
    eng = MessageDeliveryEngine(n_partitions=2)
    # Same key hashes to one partition; different key to the other (verify).
    k_a, k_b = "wallet:alice", "wallet:bob"
    pa, pb = eng._partition_for(k_a), eng._partition_for(k_b)
    assert pa != pb, (pa, pb)
    eng.produce(k_a, {"op": "credit", "amount": 30, "idempotency_key": "a1"})
    eng.produce(k_a, {"op": "credit", "amount": 10, "idempotency_key": "a2"})
    eng.produce(k_b, {"op": "credit", "amount": 5, "idempotency_key": "b1"})
    # Interleave consumption: finish Bob's partition before Alice's second message.
    order_applied = []
    r = eng.poll(pa)
    order_applied.append(("A", r["offset"], r["value"]["amount"], eng.apply(r)["balance"]))
    eng.ack(pa)
    r = eng.poll(pb)
    order_applied.append(("B", r["offset"], r["value"]["amount"], eng.apply(r)["balance"]))
    eng.ack(pb)
    r = eng.poll(pa)
    order_applied.append(("A", r["offset"], r["value"]["amount"], eng.apply(r)["balance"]))
    eng.ack(pa)
    alice_amounts = [x[2] for x in order_applied if x[0] == "A"]
    return {
        "partition_alice": pa,
        "partition_bob": pb,
        "log_alice": [m.as_dict() for m in eng.logs[pa]],
        "log_bob": [m.as_dict() for m in eng.logs[pb]],
        "apply_order": order_applied,
        "alice_amounts_in_order": alice_amounts == [30, 10],
        "bob_applied_between_alice": [x[0] for x in order_applied] == ["A", "B", "A"],
        "cross_partition_not_totally_ordered": True,
        "final_balance": eng.balance,
        "t_end": eng.now(),
    }


def run_poison(*, isolate: bool) -> dict[str, Any]:
    eng = MessageDeliveryEngine(max_retries=3)
    eng.produce("settlement:good1", {"op": "credit", "amount": 30, "idempotency_key": "good1"})
    eng.produce("settlement:poison", {"op": "poison", "amount": "bad"})
    eng.produce("settlement:good2", {"op": "credit", "amount": 10, "idempotency_key": "good2"})
    rec1 = eng.poll(0)
    eng.apply(rec1)
    eng.ack(0)
    attempts = []
    isolated = None
    later = None
    blocked = False
    if isolate:
        while True:
            rec = eng.poll(0)
            result = eng.apply(rec)
            attempts.append({"offset": rec["offset"], "attempt": result["attempt"], "poison": result["poison"]})
            if result["poison"] and result["attempt"] >= eng.max_retries:
                isolated = eng.isolate_poison(rec)
                eng.ack(0)  # advance past the poison
                break
            # Do not ack a poison record; rewind volatile position to retry.
            eng.position[0] = rec["offset"]
            eng.in_flight[0] = None
        later = eng.poll(0)
        later_applied = eng.apply(later)
        eng.ack(0)
        later = {"rec": later, "applied": later_applied}
    else:
        # Retry forever and never advance — the next good message stays blocked.
        for _ in range(eng.max_retries + 2):
            rec = eng.poll(0)
            result = eng.apply(rec)
            attempts.append({"offset": rec["offset"], "attempt": result["attempt"], "poison": result["poison"]})
            eng.position[0] = rec["offset"]
            eng.in_flight[0] = None
        # Without isolation the consumer is still stuck on the poison offset.
        blocked = eng.committed[0] == 1 and eng.position[0] == 1
        later = {"blocked": True, "next_committed": eng.committed[0], "log_length": len(eng.logs[0])}
    return {
        "isolate": isolate,
        "attempts": attempts,
        "isolated": isolated,
        "later": later,
        "final_balance": eng.balance,
        "dlq_count": len(eng.dlq),
        "poison_isolated": bool(isolated),
        "later_message_applied": (later or {}).get("applied", {}).get("applied", False) if isolate else False,
        "head_of_line_blocked": (not isolate) and blocked,
        "t_end": eng.now(),
        "rpc_count": eng.rpc_count,
    }


def run_side_effect_pitfall() -> dict[str, Any]:
    """Wallet is idempotent; an uncoordinated external push is not."""
    eng = MessageDeliveryEngine()
    eng.produce("settlement:s1", {"op": "credit", "amount": 30, "idempotency_key": "settlement:s1"})
    rec = eng.poll(0)
    a1 = eng.apply(rec, use_dedup=True, external_push=True)
    eng.crash_consumer()
    eng.recover_consumer()
    rec2 = eng.poll(0)
    a2 = eng.apply(rec2, use_dedup=True, external_push=True)
    eng.ack(0)
    return {
        "balance_after_redelivery": eng.balance,
        "wallet_exactly_once": eng.balance == INITIAL_BALANCE + 30,
        "push_attempts": eng.push_attempts,
        "external_side_effect_duplicated": eng.push_attempts == 2,
        "first_push": a1["push_attempts"],
        "second_push": a2["push_attempts"],
        "second_was_duplicate": a2["duplicate"],
        "t_end": eng.now(),
    }


def run_tradeoff() -> dict[str, Any]:
    # Retention window: rewind after the key expires, and the credit is applied twice.
    short = MessageDeliveryEngine(dedup_retain_s=0.05)
    short.produce("settlement:s1", {"op": "credit", "amount": 30, "idempotency_key": "settlement:s1"})
    rec = short.poll(0)
    short.apply(rec)
    short.ack(0)
    t_after_apply = short.now()
    short.clock.wait_until(short.clock.now() + 0.06)  # past retain window
    short.rewind(0, 0)
    rec2 = short.poll(0)
    short.apply(rec2)
    short.ack(0)
    short_res = {
        "dedup_retain_s": 0.05,
        "t_after_apply": t_after_apply,
        "t_replay": short.now(),
        "final_balance": short.balance,
        "double_credited_after_expire": short.balance == INITIAL_BALANCE + 60,
        "ledger": list(short.ledger),
        "rpc_count": short.rpc_count,
        "flush_count": short.flush_count,
    }
    long = MessageDeliveryEngine(dedup_retain_s=1.0)
    long.produce("settlement:s1", {"op": "credit", "amount": 30, "idempotency_key": "settlement:s1"})
    rec = long.poll(0)
    long.apply(rec)
    long.ack(0)
    long.clock.wait_until(long.clock.now() + 0.06)
    long.rewind(0, 0)
    rec2 = long.poll(0)
    r2 = long.apply(rec2)
    long.ack(0)
    long_res = {
        "dedup_retain_s": 1.0,
        "final_balance": long.balance,
        "duplicate_on_replay": r2["duplicate"],
        "double_credited_after_expire": long.balance == INITIAL_BALANCE + 60,
        "rpc_count": long.rpc_count,
        "flush_count": long.flush_count,
    }
    # Coordination cost: outbox vs send-after-commit, 10 business events.
    # Outbox does a joint flush then a produce; send-after-commit does a flush
    # then a produce and can lose the message if we crash (counted separately).
    n = 10
    ob = MessageDeliveryEngine()
    for i in range(n):
        ob.business_commit(credit=1, idempotency_key=f"ob-{i}", use_outbox=True)
    ob.drain_outbox()
    nbox = {
        "n": n,
        "elapsed_s": ob.now(),
        "rpc_count": ob.rpc_count,
        "flush_count": ob.flush_count,
        "log_length": len(ob.logs[0]),
        "messages_published": len(ob.logs[0]),
    }
    fire = MessageDeliveryEngine()
    lost = 0
    for i in range(n):
        # Even without a crash, fire-and-forget still does commit + produce.
        fire.business_commit(credit=1, idempotency_key=f"fi-{i}", use_outbox=False, publish_now=True)
    # One extra run that crashes before send, to show the lost-message cost.
    crash = MessageDeliveryEngine()
    crash.business_commit(credit=1, idempotency_key="fi-crash", use_outbox=False, publish_now=True, crash_after_commit=True)
    fire_res = {
        "n": n,
        "elapsed_s": fire.now(),
        "rpc_count": fire.rpc_count,
        "flush_count": fire.flush_count,
        "messages_published": len(fire.logs[0]),
        "crash_demo_lost": crash.snapshot()["log_lengths"]["0"] == 0 and crash.balance == INITIAL_BALANCE + 1,
    }
    return {
        "short_window": short_res,
        "long_window": long_res,
        "outbox_cost": nbox,
        "send_after_commit_cost": fire_res,
        "short_window_replays_after_expire": short_res["double_credited_after_expire"],
        "long_window_holds": (not long_res["double_credited_after_expire"]) and long_res["duplicate_on_replay"],
        "outbox_publishes_all": nbox["messages_published"] == n,
        "transactional_path_more_flushes": nbox["flush_count"] > fire_res["flush_count"],
        "rpc_delay_s": RPC_DELAY_S,
    }


def run_idempotent_produce() -> dict[str, Any]:
    naive = MessageDeliveryEngine()
    naive.produce("settlement:s1", {"op": "credit", "amount": 30, "idempotency_key": "settlement:s1"}, producer_id="p1", duplicate_send=True, idempotent=False)
    idem = MessageDeliveryEngine()
    idem.produce("settlement:s1", {"op": "credit", "amount": 30, "idempotency_key": "settlement:s1"}, producer_id="p1", duplicate_send=True, idempotent=True)
    return {
        "naive_log_length": len(naive.logs[0]),
        "idempotent_log_length": len(idem.logs[0]),
        "retry_duplicates_without_idempotent_producer": len(naive.logs[0]) == 2,
        "idempotent_producer_dedups": len(idem.logs[0]) == 1,
        "t_end_naive": naive.now(),
        "t_end_idem": idem.now(),
    }


def run() -> dict[str, Any]:
    naive = run_process_then_crash(use_dedup=False)
    safe = run_process_then_crash(use_dedup=True)
    ack_first = run_ack_then_crash()
    outbox = run_outbox_vs_send_after_commit()
    order = run_ordering()
    poison_block = run_poison(isolate=False)
    poison_ok = run_poison(isolate=True)
    pit = run_side_effect_pitfall()
    tr = run_tradeoff()
    prod = run_idempotent_produce()
    return {
        "engine": "MessageDeliveryEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_broker": True,
        "not_kafka": True,
        "rpc_delay_s": RPC_DELAY_S,
        "topic": TOPIC,
        "key": KEY_TITLE,
        "crash_before_ack_naive": naive,
        "crash_before_ack_dedup": safe,
        "ack_then_crash": ack_first,
        "outbox": outbox,
        "ordering": order,
        "poison_blocked": poison_block,
        "poison_isolated": poison_ok,
        "side_effect_pitfall": pit,
        "tradeoff": tr,
        "idempotent_produce": prod,
        "acceptance_exactly_once_scope_vs_external": safe["exactly_once_wallet"]
        and pit["wallet_exactly_once"]
        and pit["external_side_effect_duplicated"],
        "acceptance_poison_isolated": poison_ok["poison_isolated"]
        and poison_ok["later_message_applied"]
        and poison_block["head_of_line_blocked"],
        "practice_redelivery_does_not_double_credit": safe["exactly_once_wallet"]
        and naive["double_credited"],
        "pitfall_middleware_promise_is_not_universal": pit["external_side_effect_duplicated"],
        "tradeoff_txn_cost_and_retain_window": tr["short_window_replays_after_expire"]
        and tr["long_window_holds"]
        and tr["transactional_path_more_flushes"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path
    r = run()
    Path(__file__).with_name("results.json").write_text(json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("wrote results.json")
