#!/usr/bin/env python3
"""Acceptance checks for the lesson 122 message-delivery experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import DEFAULT_CREDIT, INITIAL_BALANCE, KEY_TITLE, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "MessageDeliveryEngine"
    assert r["not_redis"] and r["not_a_network_service"] and r["not_a_real_broker"]
    assert r["not_kafka"]
    assert r["key"] == KEY_TITLE
    assert r["rpc_delay_s"] == 0.01

    naive = r["crash_before_ack_naive"]
    assert naive["first_applied"] and naive["second_applied"]
    assert naive["balance_after_first_apply"] == INITIAL_BALANCE + DEFAULT_CREDIT
    assert naive["balance_after_redelivery"] == INITIAL_BALANCE + 2 * DEFAULT_CREDIT
    assert naive["double_credited"] and not naive["exactly_once_wallet"]
    assert naive["final_balance"] == 160

    safe = r["crash_before_ack_dedup"]
    assert safe["first_applied"] and safe["second_duplicate"] and not safe["second_applied"]
    assert safe["balance_after_first_apply"] == INITIAL_BALANCE + DEFAULT_CREDIT
    assert safe["balance_after_redelivery"] == INITIAL_BALANCE + DEFAULT_CREDIT
    assert safe["exactly_once_wallet"] and not safe["double_credited"]
    assert safe["final_balance"] == 130
    assert safe["committed_offset"] == 1

    ack_first = r["ack_then_crash"]
    assert ack_first["acked_before_apply"] and ack_first["message_lost"]
    assert ack_first["credit_missing"] and ack_first["final_balance"] == INITIAL_BALANCE
    assert ack_first["repoll"] is None

    out = r["outbox"]
    assert out["send_after_commit"]["message_lost"]
    assert out["send_after_commit"]["log_length"] == 0
    assert out["send_after_commit"]["balance"] == INITIAL_BALANCE + DEFAULT_CREDIT
    assert out["outbox"]["message_published_after_drain"]
    assert out["outbox_survives_crash_before_send"]
    assert out["outbox"]["log_length"] == 1

    order = r["ordering"]
    assert order["partition_alice"] != order["partition_bob"]
    assert order["alice_amounts_in_order"]
    assert order["bob_applied_between_alice"]
    assert order["cross_partition_not_totally_ordered"]
    assert order["final_balance"] == INITIAL_BALANCE + 30 + 10 + 5

    blocked = r["poison_blocked"]
    assert blocked["head_of_line_blocked"]
    assert blocked["dlq_count"] == 0
    assert not blocked["later_message_applied"]
    assert blocked["final_balance"] == INITIAL_BALANCE + DEFAULT_CREDIT  # only good1

    isolated = r["poison_isolated"]
    assert isolated["poison_isolated"] and isolated["later_message_applied"]
    assert isolated["dlq_count"] == 1
    assert isolated["final_balance"] == INITIAL_BALANCE + DEFAULT_CREDIT + 10
    assert isolated["isolated"]["attempts"] == 3
    assert isolated["isolated"]["offset"] == 1

    pit = r["side_effect_pitfall"]
    assert pit["wallet_exactly_once"] and pit["balance_after_redelivery"] == 130
    assert pit["external_side_effect_duplicated"] and pit["push_attempts"] == 2
    assert pit["second_was_duplicate"]

    tr = r["tradeoff"]
    assert tr["short_window_replays_after_expire"]
    assert tr["short_window"]["final_balance"] == 160
    assert tr["long_window_holds"]
    assert tr["long_window"]["final_balance"] == 130
    assert tr["outbox_publishes_all"]
    assert tr["transactional_path_more_flushes"]
    assert tr["outbox_cost"]["flush_count"] > tr["send_after_commit_cost"]["flush_count"]
    assert tr["send_after_commit_cost"]["crash_demo_lost"]

    prod = r["idempotent_produce"]
    assert prod["retry_duplicates_without_idempotent_producer"]
    assert prod["idempotent_producer_dedups"]
    assert prod["naive_log_length"] == 2
    assert prod["idempotent_log_length"] == 1

    assert r["acceptance_exactly_once_scope_vs_external"]
    assert r["acceptance_poison_isolated"]
    assert r["practice_redelivery_does_not_double_credit"]
    assert r["pitfall_middleware_promise_is_not_universal"]
    assert r["tradeoff_txn_cost_and_retain_window"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
