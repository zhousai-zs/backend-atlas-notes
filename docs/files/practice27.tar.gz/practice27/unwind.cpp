#include <cstdio>
#include <stdexcept>
struct Guard { const char* n; ~Guard() { std::printf("~Guard(%s)\n", n); } };
void inner() { Guard g{"inner"}; throw std::runtime_error("boom"); }
void middle() { Guard g{"middle"}; inner(); std::puts("never printed"); }
int main() {
    try { Guard g{"main-try"}; middle(); }
    catch (const std::exception& e) { std::printf("caught: %s\n", e.what()); }
}
