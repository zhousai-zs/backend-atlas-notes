#!/bin/bash
set -e
cd "$(dirname "$0")"
g++ -std=c++23 -Wall -Wextra -fsanitize=address,undefined -g config_reload.cpp -o config_reload
./config_reload
g++ -std=c++23 -Wall unwind.cpp -o unwind && ./unwind
