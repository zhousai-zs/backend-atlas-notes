#include <atomic>
#include <cstdio>
#include <expected>
#include <fstream>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>

struct Config {
    int timeout_ms = 0;
    int max_conn = 0;
    std::map<std::string, std::string> raw;
};

// 纯函数：只读输入、构造新对象，不碰全局状态
std::expected<Config, std::string> parse_config(const std::string& text) {
    Config c;
    std::istringstream in(text);
    std::string line;
    int lineno = 0;
    while (std::getline(in, line)) {
        ++lineno;
        if (line.empty() || line[0] == '#') continue;
        auto eq = line.find('=');
        if (eq == std::string::npos)
            return std::unexpected("line " + std::to_string(lineno) + ": missing '='");
        c.raw[line.substr(0, eq)] = line.substr(eq + 1);
    }
    try {
        c.timeout_ms = std::stoi(c.raw.at("timeout_ms"));
        c.max_conn = std::stoi(c.raw.at("max_conn"));
    } catch (const std::exception& e) {
        return std::unexpected(std::string("bad or missing field: ") + e.what());
    }
    if (c.timeout_ms <= 0) return std::unexpected("timeout_ms must be > 0");
    return c;
}

class ConfigHolder {
public:
    explicit ConfigHolder(Config init)
        : cur_(std::make_shared<const Config>(std::move(init))) {}

    std::shared_ptr<const Config> get() const {
        std::lock_guard lk(mu_);
        return cur_;
    }

    // 强保证：要么全部换成新配置，要么什么都没变
    std::expected<void, std::string> reload(const std::string& text) {
        auto parsed = parse_config(text);                       // 1. 可能失败的工作全部在旁边做
        if (!parsed) return std::unexpected(parsed.error());
        auto next = std::make_shared<const Config>(std::move(*parsed)); // 可能抛 bad_alloc，仍未改动
        std::lock_guard lk(mu_);
        cur_.swap(next);                                         // 2. 提交：noexcept
        return {};
    }

    // 反例：边解析边写，失败时留下“半新半旧”
    void bad_reload(const std::string& text) {
        auto c = std::const_pointer_cast<Config>(cur_);
        std::istringstream in(text);
        std::string line;
        while (std::getline(in, line)) {
            auto eq = line.find('=');
            auto k = line.substr(0, eq), v = line.substr(eq + 1);
            if (k == "timeout_ms") c->timeout_ms = std::stoi(v);  // 已经写进去了
            if (k == "max_conn") c->max_conn = std::stoi(v);      // 这里可能抛
        }
    }

private:
    mutable std::mutex mu_;
    std::shared_ptr<const Config> cur_;
};

static int fails = 0;
#define CHECK(x) do { if (!(x)) { std::printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #x); ++fails; } } while (0)

int main() {
    ConfigHolder h(*parse_config("timeout_ms=200\nmax_conn=100\n"));
    auto before = h.get();

    // 注入各种失败
    const char* bad[] = {
        "timeout_ms=500\nmax_conn=abc\n",   // stoi 抛 invalid_argument
        "timeout_ms=500\n",                 // 缺字段
        "timeout_ms=500\nnoequal\n",        // 格式错
        "timeout_ms=-1\nmax_conn=10\n",     // 校验失败
        "timeout_ms=500\nmax_conn=99999999999999\n", // out_of_range
    };
    for (auto t : bad) {
        auto r = h.reload(t);
        CHECK(!r);
        std::printf("reload rejected: %s\n", r ? "?" : r.error().c_str());
        CHECK(h.get() == before);
        CHECK(h.get()->timeout_ms == 200 && h.get()->max_conn == 100);
    }

    // 旧快照在 reload 成功后依然有效
    auto old = h.get();
    CHECK(h.reload("timeout_ms=300\nmax_conn=50\n"));
    CHECK(h.get()->timeout_ms == 300 && h.get()->max_conn == 50);
    CHECK(old->timeout_ms == 200);

    // 反例：基本保证都谈不上一致
    try { h.bad_reload("timeout_ms=999\nmax_conn=abc\n"); } catch (const std::exception& e) {
        std::printf("bad_reload threw: %s; now timeout_ms=%d max_conn=%d (half-applied)\n",
                    e.what(), h.get()->timeout_ms, h.get()->max_conn);
        CHECK(h.get()->timeout_ms == 999 && h.get()->max_conn == 50);
    }

    static_assert(noexcept(std::declval<std::shared_ptr<const Config>&>().swap(
        std::declval<std::shared_ptr<const Config>&>())));

    if (fails == 0) std::puts("ALL_CHECKS_PASSED");
    return fails != 0;
}
