"""Teaching metrics registry. Not a Prometheus server."""
from __future__ import annotations

from collections import defaultdict


class Registry:
    def __init__(self, buckets=(5, 10, 25, 50, 100, 250, 500, 1000)):
        self.buckets = tuple(buckets)
        self.counters = defaultdict(int)  # (name, frozen_labels) -> value
        self.gauges = defaultdict(float)
        self.hist = {}  # (name, labels) -> {bucket: count, "inf": n, "sum": s, "count": n}

    def _key(self, name, labels):
        if "user_id" in labels or "request_id" in labels:
            raise ValueError(f"high-cardinality label forbidden: {labels}")
        return name, tuple(sorted(labels.items()))

    def inc(self, name, labels=None, amount=1):
        self.counters[self._key(name, labels or {})] += amount

    def set_gauge(self, name, value, labels=None):
        self.gauges[self._key(name, labels or {})] = value

    def observe(self, name, value, labels=None):
        k = self._key(name, labels or {})
        slot = self.hist.setdefault(k, {b: 0 for b in self.buckets} | {"+Inf": 0, "sum": 0.0, "count": 0})
        for b in self.buckets:
            if value <= b:
                slot[b] += 1
        slot["+Inf"] += 1
        slot["sum"] += value
        slot["count"] += 1

    def counter(self, name, labels=None):
        return self.counters.get(self._key(name, labels or {}), 0)

    def error_rate(self, ok=None, err=None):
        ok = ok if ok is not None else self.counter("http_requests_total", {"status": "ok"})
        err = err if err is not None else self.counter("http_requests_total", {"status": "error"})
        total = ok + err
        return (err / total) if total else 0.0

    def series_count(self):
        return len(self.counters) + len(self.gauges) + len(self.hist)

    def expose(self) -> str:
        lines = []
        for (name, labels), val in sorted(self.counters.items(), key=str):
            lines.append(f"{name}{fmt_labels(labels)} {val}")
        for (name, labels), val in sorted(self.gauges.items(), key=str):
            lines.append(f"{name}{fmt_labels(labels)} {val}")
        for (name, labels), slot in sorted(self.hist.items(), key=str):
            acc = 0
            for b in self.buckets:
                # already cumulative in observe()
                lines.append(f"{name}_bucket{fmt_labels(labels + (('le', str(b)),))} {slot[b]}")
            lines.append(f"{name}_bucket{fmt_labels(labels + (('le', '+Inf'),))} {slot['+Inf']}")
            lines.append(f"{name}_sum{fmt_labels(labels)} {slot['sum']}")
            lines.append(f"{name}_count{fmt_labels(labels)} {slot['count']}")
        return "\n".join(lines) + "\n"


def fmt_labels(labels):
    if not labels:
        return ""
    if isinstance(labels, dict):
        items = sorted(labels.items())
    else:
        items = list(labels)
    inner = ",".join(f'{k}="{v}"' for k, v in items)
    return "{" + inner + "}"


def client_percentile(samples, q):
    """Nearest-rank: value at ceil(q/100 * n), 1-based. Teaching only."""
    import math
    if not samples:
        return None
    s = sorted(samples)
    # index at ceil(q/100 * (n-1)) so a single tail sample is visible in p99 of n=100
    k = max(0, min(len(s) - 1, math.ceil((q / 100.0) * (len(s) - 1))))
    return s[k]
