#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from metrics import Registry, client_percentile

ROOT = Path(__file__).resolve().parent
(ROOT / "reports").mkdir(exist_ok=True)
reg = Registry()

# Interval 1: 80 ok, 20 error; latencies mixed; in-flight peaks then returns to 0
in_flight = 0
latencies = []
for i in range(100):
    in_flight += 1
    reg.set_gauge("http_in_flight", in_flight)
    ok = i % 5 != 0
    # 20 errors at 80, 200, ... wait: i%5==0 -> 20 errors. ok=80
    latency = 8 if ok else 40
    if i in (7, 17, 27):
        latency = 120  # tail
    latencies.append(latency)
    status = "ok" if ok else "error"
    reg.inc("http_requests_total", {"status": status, "route": "kv.get"})
    reg.observe("http_request_latency_ms", latency, {"route": "kv.get"})
    in_flight -= 1
    reg.set_gauge("http_in_flight", in_flight)

ok = reg.counter("http_requests_total", {"status": "ok", "route": "kv.get"})
err = reg.counter("http_requests_total", {"status": "error", "route": "kv.get"})
rate = reg.error_rate(
    ok=ok,
    err=err,
)

# Interval 2 (next scrape window): 10 ok, 10 error -> different rate
ok2 = err2 = 0
for i in range(20):
    status = "ok" if i < 10 else "error"
    if status == "ok":
        ok2 += 1
    else:
        err2 += 1
rate2 = err2 / (ok2 + err2)

# High cardinality pitfall: one series per user_id / request_id
try:
    reg.inc("http_requests_total", {"user_id": "u-99"})
    forbidden = "accepted"
except ValueError as e:
    forbidden = str(e)

naive_series = 100  # if each request_id were a label
safe_series = reg.series_count()

# Two instances, client p99 cannot be averaged
inst_a = [10] * 99 + [1000]
inst_b = [100] * 100
p99_a = client_percentile(inst_a, 99)
p99_b = client_percentile(inst_b, 99)
p99_avg = (p99_a + p99_b) / 2
p99_all = client_percentile(inst_a + inst_b, 99)

text = reg.expose()
(ROOT / "reports" / "metrics.txt").write_text(text)

results = {
    "ok": ok,
    "error": err,
    "interval1_error_rate": round(rate, 4),
    "interval2_error_rate": round(rate2, 4),
    "in_flight_end": reg.gauges[reg._key("http_in_flight", {})],
    "safe_series": safe_series,
    "naive_request_id_series": naive_series,
    "user_id_rejected": "user_id" in forbidden,
    "p99_a": p99_a,
    "p99_b": p99_b,
    "p99_average": p99_avg,
    "p99_combined": p99_all,
    "histogram_count": reg.hist[reg._key("http_request_latency_ms", {"route": "kv.get"})]["count"],
}
assert ok == 80 and err == 20
assert abs(rate - 0.2) < 1e-9
assert abs(rate2 - 0.5) < 1e-9
assert results["in_flight_end"] == 0
assert results["user_id_rejected"]
assert naive_series > safe_series
assert p99_avg != p99_all  # averaging instance p99 is wrong
(ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
print("error_rate interval1=", results["interval1_error_rate"], "interval2=", results["interval2_error_rate"])
print("series safe=", safe_series, "naive_request_id=", naive_series, "user_id_rejected=", results["user_id_rejected"])
print("p99 a=", p99_a, "b=", p99_b, "avg=", p99_avg, "combined=", p99_all)
print("in_flight_end=", results["in_flight_end"], "hist_count=", results["histogram_count"])
print("ALL_CHECKS_PASSED")
