#!/usr/bin/env python3
"""Run the lesson 125 multi-DC / disaster-recovery experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    CROSS_DC_S,
    DC_EAST,
    DC_WEST,
    KEY_TITLE,
    LOCAL_WRITE_S,
    RUNBOOK_STEP_S,
    TITLE_EAST,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    TITLE_WEST,
    GeoKVEngine,
)


def _lats(writes: list[dict[str, Any]]) -> dict[str, Any]:
    xs = [w["latency"] for w in writes if w["acked"]]
    return {
        "n_acked": len(xs),
        "latency_min": None if not xs else min(xs),
        "latency_max": None if not xs else max(xs),
        "latency_mean": None if not xs else round(sum(xs) / len(xs) + 1e-12, 2),
        "elapsed_s": None if not writes else writes[-1]["t_ack"],
    }


def run_sync_vs_async_and_runbook() -> dict[str, Any]:
    """Three-version story + failover runbook: measure write latency, RPO, RTO."""

    def _story(mode: str) -> dict[str, Any]:
        eng = GeoKVEngine(mode=mode)
        # v1 is already synced on both DCs at t=0 (Weekly digest).
        w2 = eng.write(TITLE_V2, at=0.30)
        w3 = eng.write(TITLE_V3, at=0.40)
        # Crash after v3 is acked but, in async mode, before it reaches the west.
        # async: v2 acked 0.35, replicates 0.55; v3 acked 0.45, replicates 0.65; crash 0.60.
        # sync: both writes already on west at ack; crash still at 0.60 (after last ack 0.25+...).
        # For sync, w2 starts at 0.30 ends 0.55, w3 at 0.55? write(at=0.40) while w2 still in
        # progress: advance(0.40) doesn't finish w2 (ends 0.55), then another write on same
        # primary overlaps. We serialize: issue w3 at 0.40 only in async; in sync issue after w2.
        return eng, w2, w3

    # Async: explicit timeline.
    async_eng = GeoKVEngine(mode="async")
    a2 = async_eng.write(TITLE_V2, at=0.30)
    a3 = async_eng.write(TITLE_V3, at=0.40)
    async_eng.crash(DC_EAST, at=0.60)
    async_rb = async_eng.runbook_failover(new_primary=DC_WEST, fence_old=True)
    a_after = async_eng.write("Weekly digest (after-failover)", at=None)
    a_old = async_eng.write("Weekly digest (stale-primary)", dc=DC_EAST)

    # Sync: start w3 after w2 acks so we don't overlap a sync wait.
    sync_eng = GeoKVEngine(mode="sync")
    s2 = sync_eng.write(TITLE_V2, at=0.30)  # ack 0.55
    s3 = sync_eng.write(TITLE_V3, at=0.55)  # ack 0.80
    sync_eng.crash(DC_EAST, at=0.85)
    sync_rb = sync_eng.runbook_failover(new_primary=DC_WEST, fence_old=True)
    s_after = sync_eng.write("Weekly digest (after-failover)")
    s_old = sync_eng.write("Weekly digest (stale-primary)", dc=DC_EAST)

    return {
        "local_write_s": LOCAL_WRITE_S,
        "cross_dc_s": CROSS_DC_S,
        "runbook_step_s": RUNBOOK_STEP_S,
        "async": {
            "writes": [a2, a3],
            "latencies": _lats([a2, a3]),
            "runbook": async_rb,
            "title_on_west_after": async_eng.read(DC_WEST),
            "title_on_east_after_crash": async_eng.read(DC_EAST),
            "write_after": a_after,
            "write_old_primary": a_old,
            "snapshots": {"east": async_eng.snapshot_dc(DC_EAST), "west": async_eng.snapshot_dc(DC_WEST)},
            "t_end": async_eng.now(),
        },
        "sync": {
            "writes": [s2, s3],
            "latencies": _lats([s2, s3]),
            "runbook": sync_rb,
            "title_on_west_after": sync_eng.read(DC_WEST),
            "write_after": s_after,
            "write_old_primary": s_old,
            "snapshots": {"east": sync_eng.snapshot_dc(DC_EAST), "west": sync_eng.snapshot_dc(DC_WEST)},
            "t_end": sync_eng.now(),
        },
        "async_rpo_positive": async_rb["rpo_s"] > 0 and async_rb["lost_count"] >= 1,
        "sync_rpo_zero": sync_rb["rpo_s"] == 0.0 and sync_rb["lost_count"] == 0,
        "async_faster_writes": a2["latency"] < s2["latency"] and a2["latency"] == LOCAL_WRITE_S,
        "sync_waits_for_replica": s2["latency"] == LOCAL_WRITE_S + CROSS_DC_S,
        "old_primary_fenced": (not a_old["acked"]) and a_old["reason"] in {"fenced", "dc_down"} and (not s_old["acked"]),
        "new_primary_writable": a_after["acked"] and s_after["acked"],
    }


def run_tradeoff_ten_writes() -> dict[str, Any]:
    """10 sequential writes, then crash immediately after the last ack."""

    def _run(mode: str) -> dict[str, Any]:
        eng = GeoKVEngine(mode=mode)
        writes = []
        t = 0.0
        for i in range(10):
            w = eng.write(f"Weekly digest (w{i+1})", at=t)
            writes.append(w)
            t = w["t_ack"]
        crash_at = t  # immediately after last ack
        eng.crash(DC_EAST, at=crash_at)
        rb = eng.runbook_failover(new_primary=DC_WEST, fence_old=True)
        return {
            "mode": mode,
            "writes": [{"version": w["version"], "latency": w["latency"], "t_ack": w["t_ack"], "acked": w["acked"]} for w in writes],
            "latencies": _lats(writes),
            "runbook": {k: rb[k] for k in ("t_fail", "t_writable", "rto_s", "rpo_s", "lost_count", "lost_writes", "title_on_new", "last_version_on_new", "last_acked_on_old")},
            "t_end": eng.now(),
        }

    async_r = _run("async")
    sync_r = _run("sync")
    return {
        "async": async_r,
        "sync": sync_r,
        "sync_higher_write_latency": sync_r["latencies"]["latency_max"] > async_r["latencies"]["latency_max"],
        "async_higher_rpo": async_r["runbook"]["rpo_s"] > sync_r["runbook"]["rpo_s"],
        "sync_rpo_zero": sync_r["runbook"]["rpo_s"] == 0.0 and sync_r["runbook"]["lost_count"] == 0,
        "tradeoff_sync_latency_vs_async_rpo": True,
    }


def run_partition_sovereignty() -> dict[str, Any]:
    """During a partition, which DC may write? Four policies."""

    def _base(mode: str) -> GeoKVEngine:
        eng = GeoKVEngine(mode=mode)
        eng.write(TITLE_V2, at=0.00)
        if mode == "async":
            eng.drain()  # let v2 reach the west before the partition, so we test sovereignty not lag
        eng.partition(at=eng.clock.now())
        return eng

    # 1) Async, no failover: only the original primary can write.
    a = _base("async")
    a_east = a.write(TITLE_EAST, dc=DC_EAST)
    a_west = a.write(TITLE_WEST, dc=DC_WEST)
    async_no_fo = {
        "writable": list(a.writable_dcs()),
        "east": a_east,
        "west": a_west,
        "titles": {"east": a.read(DC_EAST), "west": a.read(DC_WEST)},
    }

    # 2) Sync, no failover: primary cannot complete a durable write; standby refused.
    s = _base("sync")
    s_east = s.write(TITLE_EAST, dc=DC_EAST)
    s_west = s.write(TITLE_WEST, dc=DC_WEST)
    sync_no_fo = {
        "writable": list(s.writable_dcs()),
        "east": s_east,
        "west": s_west,
        "titles": {"east": s.read(DC_EAST), "west": s.read(DC_WEST)},
    }

    # 3) Failover without fencing: both DCs accept writes; titles diverge.
    split = _base("async")
    split.runbook_failover(new_primary=DC_WEST, fence_old=False)
    # East is down? No, we only partitioned, east still alive. Runbook does not crash east.
    # But wait — _base doesn't crash. Old primary east is still alive and, without fence, still role=standby after promote...
    # promote() sets others to standby, so east would be standby and refuse writes!
    # That's NOT split brain unless we forget to demote. Split brain is when we promote west WITHOUT changing east's role / fence.
    # I need a "bad promote" that only sets west as primary without demoting east.
    # I'll add a manual split-brain path here using internal state to model a mistaken dual-primary.
    # Better: add engine method or do it in experiment without hidden API...
    # Use a dedicated helper on the engine after I add `promote_without_demote`? Or fence_old=False should leave old as primary too for the pitfall.
    # I'll adjust after seeing — for now, implement dual_primary in this function by a second engine method I'll add.
    # Actually I'll change runbook/promote when fence_old is False to leave old role as primary (brain split). That's the teaching mistake.
    # Don't change promote() globally — add `dual_promote` in this experiment via a new engine method.
    # I'll call a method `mistaken_dual_primary` — need to add it.

    # Placeholder filled after engine helper exists; constructed below if present.
    return {
        "async_no_failover": async_no_fo,
        "sync_no_failover": sync_no_fo,
    }


def run_backup_drill() -> dict[str, Any]:
    """Having a backup is not the same as having verified a restore."""
    # Verified path: backup v2, later write v3, wipe, restore, verify.
    good = GeoKVEngine(mode="async")
    good.write(TITLE_V2, at=0.00)
    good.drain()
    b = good.backup(DC_EAST)
    t_backup = good.now()
    good.write(TITLE_V3, at=0.30)
    good.drain()
    t_fail = good.now()
    good.wipe(DC_EAST)
    title_after_wipe = good.read(DC_EAST)
    rest = good.restore(b, DC_EAST)
    ver = good.verify(b, DC_EAST)

    # Pitfall: a backup object exists, the store is wiped, restore is never run, verify fails.
    bad = GeoKVEngine(mode="async")
    bad.write(TITLE_V2, at=0.00)
    bad.drain()
    b2 = bad.backup(DC_EAST)
    bad.write(TITLE_V3, at=0.30)
    bad.wipe(DC_EAST)
    # Pretend the operator stops after "we have a backup".
    unverified = bad.verify(b2, DC_EAST)

    return {
        "verified": {
            "backup_t": t_backup,
            "backup_checksum": b.checksum,
            "backup_title": TITLE_V2,
            "title_after_later_write": TITLE_V3,
            "title_after_wipe": title_after_wipe,
            "restore": rest,
            "verify": ver,
            "title_after_restore": good.read(DC_EAST),
        },
        "unverified": {
            "has_backup": True,
            "restore_ran": False,
            "title_after_wipe": bad.read(DC_EAST),
            "verify": unverified,
        },
        "verified_restore_ok": ver["verify_ok"] and good.read(DC_EAST) == TITLE_V2,
        "unverified_verify_fails": (not unverified["verify_ok"]) and bad.read(DC_EAST) is None,
        "backup_does_not_include_later_write": good.read(DC_EAST) == TITLE_V2,
        "pitfall_backup_never_verified": (not unverified["verify_ok"]) and ver["verify_ok"],
        "t_end_verified": good.now(),
        "t_end_unverified": bad.now(),
    }


def run() -> dict[str, Any]:
    # Partition experiment is completed after we add split-brain helper.
    from engine import GeoKVEngine as _E  # noqa: F401

    story = run_sync_vs_async_and_runbook()
    trade = run_tradeoff_ten_writes()
    sov = run_partition_sovereignty()
    # split-brain + fenced failover during partition (east still up)
    split = GeoKVEngine(mode="async")
    split.write(TITLE_V2, at=0.00)
    split.drain()
    split.partition()
    split.mistaken_dual_primary(DC_WEST)
    e1 = split.write(TITLE_EAST, dc=DC_EAST)
    w1 = split.write(TITLE_WEST, dc=DC_WEST)
    split_res = {
        "writable": list(split.writable_dcs()),
        "east_write": e1,
        "west_write": w1,
        "titles": {"east": split.read(DC_EAST), "west": split.read(DC_WEST)},
        "diverged": split.read(DC_EAST) != split.read(DC_WEST) and e1["acked"] and w1["acked"],
        "both_writable": set(split.writable_dcs()) == {DC_EAST, DC_WEST},
    }
    fenced = GeoKVEngine(mode="async")
    fenced.write(TITLE_V2, at=0.00)
    fenced.drain()
    fenced.partition()
    fenced_rb = fenced.runbook_failover(new_primary=DC_WEST, fence_old=True)
    fe = fenced.write(TITLE_EAST, dc=DC_EAST)
    fw = fenced.write(TITLE_WEST, dc=DC_WEST)
    fenced_res = {
        "runbook_writable": fenced_rb["writable_after"],
        "writable": list(fenced.writable_dcs()),
        "east_write": fe,
        "west_write": fw,
        "titles": {"east": fenced.read(DC_EAST), "west": fenced.read(DC_WEST)},
        "only_west_writable": fenced.writable_dcs() == [DC_WEST] and (not fe["acked"]) and fw["acked"],
    }
    sov["split_brain"] = split_res
    sov["fenced_failover"] = fenced_res
    sov["partition_async_only_east"] = sov["async_no_failover"]["writable"] == [DC_EAST] and sov["async_no_failover"]["east"]["acked"] and (not sov["async_no_failover"]["west"]["acked"])
    sov["partition_sync_nobody_durable"] = (not sov["sync_no_failover"]["east"]["acked"]) and (not sov["sync_no_failover"]["west"]["acked"])
    sov["acceptance_writable_dc_is_explicit"] = (
        sov["partition_async_only_east"]
        and sov["partition_sync_nobody_durable"]
        and split_res["diverged"] and split_res["both_writable"]
        and fenced_res["only_west_writable"]
    )

    bak = run_backup_drill()
    return {
        "engine": "GeoKVEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_multi_dc_product": True,
        "not_spanner": True,
        "not_google_sre_production": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "local_write_s": LOCAL_WRITE_S,
        "cross_dc_s": CROSS_DC_S,
        "story": story,
        "tradeoff": trade,
        "sovereignty": sov,
        "backup": bak,
        "acceptance_writable_dc_during_partition": sov["acceptance_writable_dc_is_explicit"],
        "acceptance_restore_then_verify": bak["verified_restore_ok"] and bak["unverified_verify_fails"],
        "practice_runbook_measures_rto_and_rpo": story["async_rpo_positive"]
        and story["sync_rpo_zero"]
        and story["new_primary_writable"]
        and story["old_primary_fenced"],
        "pitfall_backup_never_verified": bak["pitfall_backup_never_verified"],
        "tradeoff_sync_latency_vs_async_rpo": trade["sync_higher_write_latency"]
        and trade["async_higher_rpo"]
        and trade["sync_rpo_zero"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
