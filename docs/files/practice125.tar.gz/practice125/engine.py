#!/usr/bin/env python3
"""Teaching GeoKVEngine — not Redis, not a real multi-DC product, not a network service.

A Python 3 standard-library model of a two-datacenter teaching KV with
synchronous or asynchronous replication, write sovereignty, a fencing
token, a failover runbook, and a backup/restore drill. It is used to
observe write latency vs potential RPO, which DC may write during a
partition, lost windows after a failover, and whether a backup actually
restores the expected data.

Checklist items such as "implement backups", "document the process for
moving your service to a new datacenter" and "restoring data from
backups", examining datacenter outages and network failures, and
keeping spare replicated deployments follow Google SRE Chapter 27,
Reliable Product Launches at Scale, and Appendix E, Launch Coordination
Checklist (checked on 2026-11-14). This engine is not Google's
production stack, not Spanner, not a DNS/GSLB traffic shift, and not a
real backup product. The chapter and appendix do not define RPO, RTO,
fencing, or synchronous vs asynchronous replication; those names and
the measured windows come from this teaching model. There is no TCP,
no WAN, no disk, and no real clock. Persistence is a teaching dict
flush, not fsync. Clock is virtual. local_write_s, cross_dc_s, and
runbook step delays are teaching delays, not production RTT.
"""
from __future__ import annotations

import hashlib
import heapq
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
TITLE_EAST = "Weekly digest (east)"
TITLE_WEST = "Weekly digest (west)"
KEY_TITLE = "article:01:title"
DC_EAST = "dc-east"
DC_WEST = "dc-west"
LOCAL_WRITE_S = 0.05
CROSS_DC_S = 0.20
RUNBOOK_STEP_S = 0.05


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


def checksum(store: dict[str, Any]) -> str:
    blob = "|".join(f"{k}={store[k]['value']}@{store[k]['version']}" for k in sorted(store))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass(order=True)
class Event:
    t: float
    seq: int
    kind: str = field(compare=False)
    payload: dict[str, Any] = field(compare=False, default_factory=dict)


@dataclass
class Backup:
    taken_at: float
    dc: str
    store: dict[str, Any]
    checksum: str
    verified: bool = False


class GeoKVEngine:
    def __init__(
        self,
        *,
        mode: str = "async",  # async | sync
        local_write_s: float = LOCAL_WRITE_S,
        cross_dc_s: float = CROSS_DC_S,
        runbook_step_s: float = RUNBOOK_STEP_S,
        primary: str = DC_EAST,
        title: str = TITLE_V1,
    ) -> None:
        if mode not in {"async", "sync"}:
            raise ValueError("mode must be async or sync")
        self.clock = Clock()
        self.mode = mode
        self.local_write_s = float(local_write_s)
        self.cross_dc_s = float(cross_dc_s)
        self.runbook_step_s = float(runbook_step_s)
        self.partitioned = False
        self.epoch = 1
        self._seq = 0
        self._write_seq = 0
        self.events: list[Event] = []
        self.log: list[dict[str, Any]] = []
        self.flush_count = 0
        self.backups: list[Backup] = []

        initial = {"value": title, "version": 1, "epoch": 1, "acked": True, "t": 0.0}
        self.dcs: dict[str, dict[str, Any]] = {}
        for name in (DC_EAST, DC_WEST):
            self.dcs[name] = {
                "name": name,
                "alive": True,
                "role": "primary" if name == primary else "standby",
                "epoch": 1 if name == primary else 0,
                "fenced": False,
                "store": {KEY_TITLE: dict(initial)},
                "acked_log": [{"key": KEY_TITLE, "value": title, "version": 1, "t": 0.0, "epoch": 1}],
            }
        self.primary = primary
        self.members = [DC_EAST, DC_WEST]
        self._event("init", mode=mode, primary=primary)

    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.log.append(ev)
        return ev

    def _flush(self, dc: str, reason: str) -> None:
        self.flush_count += 1
        self._event("persist_flushed", dc=dc, reason=reason, flush_count=self.flush_count)

    def _push(self, t: float, kind: str, **payload: Any) -> None:
        self._seq += 1
        heapq.heappush(self.events, Event(t, self._seq, kind, payload))

    def advance(self, t: float) -> None:
        while self.events and self.events[0].t <= t + 1e-12:
            ev = heapq.heappop(self.events)
            self.clock.wait_until(ev.t)
            self._apply_event(ev)
        if t > self.clock.now():
            self.clock.wait_until(t)

    def drain(self) -> None:
        while self.events:
            ev = heapq.heappop(self.events)
            self.clock.wait_until(ev.t)
            self._apply_event(ev)

    def _apply_event(self, ev: Event) -> None:
        if ev.kind == "replicate":
            src = ev.payload["src"]
            dest = ev.payload["dest"]
            item = ev.payload["item"]
            # In-flight replication is dropped if the source has crashed,
            # the destination is down, or the DCs are partitioned at arrival.
            if self.partitioned or not self.dcs[src]["alive"] or not self.dcs[dest]["alive"]:
                self._event("replicate_dropped", src=src, dest=dest, version=item["version"], reason="in_flight_dropped")
                return
            self._apply_local(dest, item, replicated=True)
            self.dcs[dest]["acked_log"].append({
                "key": item["key"], "value": item["value"], "version": item["version"],
                "t": item.get("t", self.clock.now()), "epoch": item["epoch"],
            })
            self._event("replicated", src=src, dest=dest, version=item["version"], value=item["value"])

    def _apply_local(self, dc: str, item: dict[str, Any], *, replicated: bool = False) -> None:
        store = self.dcs[dc]["store"]
        cur = store.get(item["key"])
        if cur is not None and cur["version"] > item["version"]:
            # Stale replica payload; ignore.
            return
        store[item["key"]] = {
            "value": item["value"],
            "version": item["version"],
            "epoch": item["epoch"],
            "acked": item.get("acked", True),
            "t": item.get("t", self.clock.now()),
        }
        self._flush(dc, "replicate" if replicated else "local_write")

    def writable_dcs(self) -> list[str]:
        """Which DCs would accept a write at the current instant (pre-flight check)."""
        out = []
        for name, dc in self.dcs.items():
            ok, _ = self._accepts_write(name)
            if ok:
                out.append(name)
        return out

    def _accepts_write(self, dc: str) -> tuple[bool, str]:
        node = self.dcs[dc]
        if not node["alive"]:
            return False, "dc_down"
        if node["fenced"]:
            return False, "fenced"
        if node["role"] != "primary":
            return False, "not_primary"
        if node["epoch"] < self.epoch:
            return False, "stale_epoch"
        return True, "ok"

    def write(self, value: str, *, at: Optional[float] = None, dc: Optional[str] = None, key: str = KEY_TITLE) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        target = dc or self.primary
        ok, reason = self._accepts_write(target)
        rec: dict[str, Any] = {
            "t_start": self.now(),
            "dc": target,
            "value": value,
            "mode": self.mode,
            "accepted": False,
            "acked": False,
            "reason": reason,
            "version": None,
            "t_ack": None,
            "latency": None,
            "epoch": self.dcs[target]["epoch"],
        }
        if not ok:
            rec["t_ack"] = self.now()
            rec["latency"] = 0.0
            self._event("write_rejected", **{k: rec[k] for k in ("dc", "value", "reason")})
            return rec

        # Local persist.
        self.clock.wait_until(self.clock.now() + self.local_write_s)
        self._write_seq += 1
        version = self.dcs[target]["store"].get(key, {}).get("version", 0) + 1
        item = {
            "key": key,
            "value": value,
            "version": version,
            "epoch": self.dcs[target]["epoch"],
            "t": self.clock.now(),
            "acked": False,
        }
        self._apply_local(target, item, replicated=False)
        rec["accepted"] = True
        rec["version"] = version
        others = [n for n in self.members if n != target]

        if self.mode == "sync":
            unreachable = [
                n for n in others
                if self.partitioned or not self.dcs[n]["alive"] or self.dcs[n]["fenced"]
            ]
            if unreachable:
                # Unacked: roll back to the previous durable version on this DC.
                prev = [e for e in self.dcs[target]["acked_log"] if e["key"] == key]
                if prev:
                    last = prev[-1]
                    self.dcs[target]["store"][key] = {
                        "value": last["value"],
                        "version": last["version"],
                        "epoch": last["epoch"],
                        "acked": True,
                        "t": last["t"],
                    }
                else:
                    self.dcs[target]["store"].pop(key, None)
                rec["reason"] = "sync_replica_unreachable"
                rec["t_ack"] = self.now()
                rec["latency"] = ts(self.local_write_s)
                rec["version"] = None
                self._event("write_failed_sync", dc=target, reason=rec["reason"], unreachable=unreachable)
                return rec
            # Wait for required replicas and apply.
            if others:
                self.clock.wait_until(self.clock.now() + self.cross_dc_s)
            item["acked"] = True
            for other in others:
                self._apply_local(other, item, replicated=True)
                self.dcs[other]["acked_log"].append({
                    "key": key, "value": value, "version": version,
                    "t": item["t"], "epoch": item["epoch"],
                })
                self._event("replicated", src=target, dest=other, version=version, value=value, sync=True)
        else:
            # Async: ack locally, schedule in-flight replication to every other member.
            for dest in others:
                self._push(self.clock.now() + self.cross_dc_s, "replicate", src=target, dest=dest, item=dict(item, acked=True))

        item["acked"] = True
        self.dcs[target]["store"][key]["acked"] = True
        self.dcs[target]["acked_log"].append({"key": key, "value": value, "version": version, "t": self.clock.now(), "epoch": item["epoch"]})
        rec["acked"] = True
        rec["reason"] = "ok"
        rec["t_ack"] = self.now()
        rec["latency"] = ts(self.clock.now() - rec["t_start"])
        self._event("write_acked", dc=target, version=version, value=value, latency=rec["latency"])
        return rec

    def crash(self, dc: str, at: Optional[float] = None) -> None:
        if at is not None:
            self.advance(at)
        self.dcs[dc]["alive"] = False
        self._event("crash", dc=dc)

    def partition(self, at: Optional[float] = None) -> None:
        if at is not None:
            self.advance(at)
        self.partitioned = True
        self._event("partition")

    def heal(self, at: Optional[float] = None) -> None:
        if at is not None:
            self.advance(at)
        self.partitioned = False
        self._event("heal")

    def fence(self, dc: str) -> None:
        self.dcs[dc]["fenced"] = True
        self._event("fence", dc=dc, epoch=self.epoch)

    def mistaken_dual_primary(self, dc: str) -> None:
        """Teaching anti-pattern: raise a second primary without fencing or bumping a global epoch."""
        self.dcs[dc]["role"] = "primary"
        self.dcs[dc]["epoch"] = self.epoch  # same token as the old primary; do not bump
        self.dcs[dc]["fenced"] = False
        # Intentionally do not increment self.epoch and do not demote the old primary.
        self._event("mistaken_dual_primary", dc=dc, writable=list(self.writable_dcs()))

    def promote(self, dc: str) -> None:
        if not self.dcs[dc]["alive"]:
            raise RuntimeError(f"{dc} is down")
        for name, node in self.dcs.items():
            if name != dc:
                node["role"] = "standby"
        self.epoch += 1
        self.dcs[dc]["role"] = "primary"
        self.dcs[dc]["epoch"] = self.epoch
        self.dcs[dc]["fenced"] = False
        self.primary = dc
        self._event("promote", dc=dc, epoch=self.epoch)

    def _step(self, name: str) -> dict[str, Any]:
        self.clock.wait_until(self.clock.now() + self.runbook_step_s)
        rec = {"t": self.now(), "step": name, "primary": self.primary, "epoch": self.epoch, "writable": list(self.writable_dcs())}
        self._event("runbook_step", **rec)
        return rec

    def runbook_failover(self, *, new_primary: str, fence_old: bool = True) -> dict[str, Any]:
        """Teaching runbook: detect, fence the old primary, promote, declare writable.

        Each step costs runbook_step_s on the virtual clock. In-flight async
        replications from a crashed primary are already dropped (see crash()).
        """
        t_fail = self.clock.now()
        old = DC_EAST if new_primary == DC_WEST else DC_WEST
        steps = []
        steps.append(self._step("detect_primary_failure"))
        if fence_old:
            self.fence(old)
            steps.append(self._step("fence_old_primary"))
            if old in self.members:
                self.members = [n for n in self.members if n != old]
                steps.append(self._step("drop_old_primary_from_replica_set"))
        else:
            steps.append(self._step("skip_fence"))
        self.promote(new_primary)
        steps.append(self._step("promote_standby"))
        t_writable = self.clock.now()
        lost = self._lost_writes(new_primary)
        last_here = self._last_version(new_primary)
        last_acked_old = self._last_acked_version(old)
        rpo_s = 0.0
        if lost:
            last_kept_t = self._version_ack_t(old, last_here) or t_fail
            last_lost_t = max(w["t"] for w in lost)
            rpo_s = ts(last_lost_t - last_kept_t)
        out = {
            "t_fail": ts(t_fail),
            "t_writable": ts(t_writable),
            "rto_s": ts(t_writable - t_fail),
            "rpo_s": ts(rpo_s),
            "lost_writes": lost,
            "lost_count": len(lost),
            "new_primary": new_primary,
            "old_primary": old,
            "fenced": fence_old,
            "epoch": self.epoch,
            "title_on_new": self.read(new_primary),
            "steps": steps,
            "writable_after": list(self.writable_dcs()),
            "last_version_on_new": last_here,
            "last_acked_on_old": last_acked_old,
        }
        self._event("runbook_done", rto_s=out["rto_s"], rpo_s=out["rpo_s"], lost_count=out["lost_count"])
        return out

    def _last_version(self, dc: str) -> int:
        rec = self.dcs[dc]["store"].get(KEY_TITLE)
        return rec["version"] if rec else 0

    def _last_acked_version(self, dc: str) -> int:
        log = self.dcs[dc]["acked_log"]
        return log[-1]["version"] if log else 0

    def _version_ack_t(self, dc: str, version: int) -> Optional[float]:
        for e in self.dcs[dc]["acked_log"]:
            if e["version"] == version:
                return e["t"]
        rec = self.dcs[dc]["store"].get(KEY_TITLE)
        if rec and rec["version"] == version:
            return rec["t"]
        return None

    def _lost_writes(self, new_primary: str) -> list[dict[str, Any]]:
        old = DC_EAST if new_primary == DC_WEST else DC_WEST
        have = self._last_version(new_primary)
        lost = []
        for e in self.dcs[old]["acked_log"]:
            if e["version"] > have:
                lost.append({"version": e["version"], "value": e["value"], "t": ts(e["t"])})
        return lost

    def read(self, dc: str, key: str = KEY_TITLE) -> Optional[str]:
        rec = self.dcs[dc]["store"].get(key)
        return rec["value"] if rec else None

    def snapshot_dc(self, dc: str) -> dict[str, Any]:
        node = self.dcs[dc]
        rec = node["store"].get(KEY_TITLE)
        return {
            "name": dc,
            "alive": node["alive"],
            "role": node["role"],
            "epoch": node["epoch"],
            "fenced": node["fenced"],
            "title": rec["value"] if rec else None,
            "version": rec["version"] if rec else None,
        }

    def backup(self, dc: Optional[str] = None) -> Backup:
        name = dc or self.primary
        store = {k: dict(v) for k, v in self.dcs[name]["store"].items()}
        b = Backup(taken_at=self.clock.now(), dc=name, store=store, checksum=checksum(store), verified=False)
        self.backups.append(b)
        self._event("backup", dc=name, checksum=b.checksum, title=store.get(KEY_TITLE, {}).get("value"))
        return b

    def wipe(self, dc: str) -> None:
        self.dcs[dc]["store"] = {}
        self._event("wipe", dc=dc)

    def restore(self, backup: Backup, dc: Optional[str] = None) -> dict[str, Any]:
        name = dc or backup.dc
        self.clock.wait_until(self.clock.now() + self.runbook_step_s)
        self.dcs[name]["store"] = {k: dict(v) for k, v in backup.store.items()}
        self._flush(name, "restore")
        self._event("restore", dc=name, checksum=backup.checksum, taken_at=ts(backup.taken_at))
        return {"dc": name, "t": self.now(), "checksum": backup.checksum, "title": self.read(name)}

    def verify(self, backup: Backup, dc: Optional[str] = None) -> dict[str, Any]:
        name = dc or backup.dc
        self.clock.wait_until(self.clock.now() + self.runbook_step_s)
        store = self.dcs[name]["store"]
        cs = checksum(store)
        title_ok = self.read(name) == backup.store.get(KEY_TITLE, {}).get("value")
        ok = cs == backup.checksum and title_ok
        backup.verified = ok
        rec = {
            "t": self.now(),
            "dc": name,
            "expected_checksum": backup.checksum,
            "actual_checksum": cs,
            "expected_title": backup.store.get(KEY_TITLE, {}).get("value"),
            "actual_title": self.read(name),
            "verify_ok": ok,
        }
        self._event("verify", **rec)
        return rec
