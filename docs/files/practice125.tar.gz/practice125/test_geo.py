#!/usr/bin/env python3
"""Acceptance checks for the lesson 125 multi-DC recovery experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    CROSS_DC_S,
    DC_EAST,
    DC_WEST,
    KEY_TITLE,
    LOCAL_WRITE_S,
    RUNBOOK_STEP_S,
    TITLE_EAST,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    TITLE_WEST,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "GeoKVEngine"
    assert r["not_redis"] and r["not_a_network_service"] and r["not_a_real_multi_dc_product"]
    assert r["not_spanner"] and r["not_google_sre_production"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["local_write_s"] == LOCAL_WRITE_S == 0.05
    assert r["cross_dc_s"] == CROSS_DC_S == 0.20

    story = r["story"]
    assert story["local_write_s"] == 0.05 and story["cross_dc_s"] == 0.20
    assert story["runbook_step_s"] == RUNBOOK_STEP_S == 0.05
    assert story["async_rpo_positive"] and story["sync_rpo_zero"]
    assert story["async_faster_writes"] and story["sync_waits_for_replica"]
    assert story["old_primary_fenced"] and story["new_primary_writable"]

    a = story["async"]
    assert a["latencies"]["latency_mean"] == 0.05 and a["latencies"]["n_acked"] == 2
    assert a["writes"][0]["t_ack"] == 0.35 and a["writes"][0]["value"] == TITLE_V2
    assert a["writes"][1]["t_ack"] == 0.45 and a["writes"][1]["value"] == TITLE_V3
    arb = a["runbook"]
    assert arb["t_fail"] == 0.60 and arb["t_writable"] == 0.80 and arb["rto_s"] == 0.20
    assert arb["rpo_s"] == 0.10 and arb["lost_count"] == 1
    assert arb["lost_writes"] == [{"version": 3, "value": TITLE_V3, "t": 0.45}]
    assert arb["title_on_new"] == TITLE_V2
    assert [s["step"] for s in arb["steps"]] == [
        "detect_primary_failure",
        "fence_old_primary",
        "drop_old_primary_from_replica_set",
        "promote_standby",
    ]
    assert a["write_after"]["acked"] and a["write_after"]["dc"] == DC_WEST
    assert a["write_after"]["latency"] == 0.05 and a["write_after"]["t_ack"] == 0.85
    assert a["write_old_primary"]["reason"] == "dc_down" and not a["write_old_primary"]["acked"]
    assert a["snapshots"]["east"]["fenced"] and not a["snapshots"]["east"]["alive"]
    assert a["snapshots"]["west"]["role"] == "primary" and a["snapshots"]["west"]["epoch"] == 2

    s = story["sync"]
    assert s["latencies"]["latency_mean"] == 0.25 and s["latencies"]["n_acked"] == 2
    assert s["writes"][0]["t_ack"] == 0.55 and s["writes"][1]["t_ack"] == 0.80
    srb = s["runbook"]
    assert srb["t_fail"] == 0.85 and srb["t_writable"] == 1.05 and srb["rto_s"] == 0.20
    assert srb["rpo_s"] == 0.0 and srb["lost_count"] == 0 and srb["lost_writes"] == []
    assert srb["title_on_new"] == TITLE_V3
    assert s["write_after"]["acked"] and s["write_after"]["latency"] == 0.05
    assert s["write_after"]["t_start"] == 1.05 and s["write_after"]["t_ack"] == 1.10

    trade = r["tradeoff"]
    assert trade["async"]["latencies"]["elapsed_s"] == 0.50
    assert trade["async"]["latencies"]["latency_mean"] == 0.05
    assert trade["sync"]["latencies"]["elapsed_s"] == 2.50
    assert trade["sync"]["latencies"]["latency_mean"] == 0.25
    assert trade["async"]["runbook"]["rpo_s"] == 0.20
    assert trade["async"]["runbook"]["rto_s"] == 0.20
    assert trade["async"]["runbook"]["lost_count"] == 4
    assert trade["async"]["runbook"]["title_on_new"] == "Weekly digest (w6)"
    assert trade["async"]["runbook"]["last_version_on_new"] == 7
    assert trade["async"]["runbook"]["last_acked_on_old"] == 11
    assert trade["sync"]["runbook"]["rpo_s"] == 0.0 and trade["sync"]["runbook"]["lost_count"] == 0
    assert trade["sync"]["runbook"]["title_on_new"] == "Weekly digest (w10)"
    assert trade["sync"]["runbook"]["last_version_on_new"] == 11
    assert trade["sync_higher_write_latency"] and trade["async_higher_rpo"] and trade["sync_rpo_zero"]

    sov = r["sovereignty"]
    assert sov["async_no_failover"]["writable"] == [DC_EAST]
    assert sov["async_no_failover"]["east"]["acked"] and not sov["async_no_failover"]["west"]["acked"]
    assert sov["async_no_failover"]["west"]["reason"] == "not_primary"
    assert sov["async_no_failover"]["titles"]["east"] == TITLE_EAST
    assert sov["async_no_failover"]["titles"]["west"] == TITLE_V2
    assert not sov["sync_no_failover"]["east"]["acked"]
    assert sov["sync_no_failover"]["east"]["reason"] == "sync_replica_unreachable"
    assert not sov["sync_no_failover"]["west"]["acked"]
    assert sov["sync_no_failover"]["west"]["reason"] == "not_primary"
    assert sov["sync_no_failover"]["titles"] == {"east": TITLE_V2, "west": TITLE_V2}
    assert sov["partition_async_only_east"] and sov["partition_sync_nobody_durable"]
    sb = sov["split_brain"]
    assert sb["both_writable"] and sb["diverged"] and sb["writable"] == [DC_EAST, DC_WEST]
    assert sb["east_write"]["acked"] and sb["west_write"]["acked"]
    assert sb["titles"] == {"east": TITLE_EAST, "west": TITLE_WEST}
    fd = sov["fenced_failover"]
    assert fd["only_west_writable"] and fd["writable"] == [DC_WEST]
    assert fd["east_write"]["reason"] == "fenced" and not fd["east_write"]["acked"]
    assert fd["west_write"]["acked"] and fd["titles"]["west"] == TITLE_WEST

    bak = r["backup"]
    assert bak["verified"]["backup_t"] == 0.25
    assert bak["verified"]["backup_checksum"] == "9c3632257ba5e3fa"
    assert bak["verified"]["backup_title"] == TITLE_V2
    assert bak["verified"]["title_after_later_write"] == TITLE_V3
    assert bak["verified"]["title_after_wipe"] is None
    assert bak["verified"]["restore"]["t"] == 0.60
    assert bak["verified"]["verify"]["t"] == 0.65 and bak["verified"]["verify"]["verify_ok"]
    assert bak["verified"]["title_after_restore"] == TITLE_V2
    assert bak["unverified"]["has_backup"] and not bak["unverified"]["restore_ran"]
    assert bak["unverified"]["verify"]["actual_checksum"] == "e3b0c44298fc1c14"
    assert bak["unverified"]["verify"]["actual_title"] is None
    assert not bak["unverified"]["verify"]["verify_ok"]
    assert bak["verified_restore_ok"] and bak["unverified_verify_fails"]
    assert bak["backup_does_not_include_later_write"]

    assert r["acceptance_writable_dc_during_partition"]
    assert r["acceptance_restore_then_verify"]
    assert r["practice_runbook_measures_rto_and_rpo"]
    assert r["pitfall_backup_never_verified"]
    assert r["tradeoff_sync_latency_vs_async_rpo"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
