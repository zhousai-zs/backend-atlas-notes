from __future__ import annotations

import argparse
import signal
import sys
import time
from pathlib import Path

from jobsvc import JobStore

STOP = False


def on_term(signum, frame):
    # Simulate a hard kill path when SIGKILL is used; SIGTERM we still exit quickly.
    raise SystemExit(128 + signum)


def work_payload(store: JobStore, job: dict) -> tuple[bool, str, str | None]:
    kind = job["kind"]
    if job["cancel_requested"]:
        return False, "", "cancelled"
    if kind == "diagnose":
        # Slow enough that the test can kill the first worker mid-flight.
        time.sleep(0.4)
        status = store.apply_effect_once(job["job_id"], "diag:" + job["payload"])
        return True, status, None
    if kind == "always_fail":
        time.sleep(0.05)
        return False, "", "injected_failure"
    return False, "", "unknown_kind"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--worker-id", required=True)
    ap.add_argument("--lease", type=float, default=0.25)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()
    signal.signal(signal.SIGTERM, on_term)
    store = JobStore(Path(args.db))
    while True:
        job = store.claim(args.worker_id, args.lease)
        if not job:
            if args.once:
                return
            time.sleep(0.05)
            continue
        try:
            ok, result, err = work_payload(store, job)
            # Re-read cancel before finish.
            latest = store.get(job["job_id"])
            if latest and latest["state"] == "cancelled":
                if args.once:
                    return
                continue
            store.finish(job["job_id"], args.worker_id, ok, result, err)
        except SystemExit:
            # Lease expires; do not finish. Side effect may or may not have run;
            # uniqueness of job_id keeps it exactly once.
            raise
        if args.once:
            return


if __name__ == "__main__":
    main()
