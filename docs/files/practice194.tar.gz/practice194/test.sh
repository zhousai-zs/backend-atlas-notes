#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 -c "import sqlite3,sys; print('python',sys.version.split()[0],'sqlite',sqlite3.sqlite_version)"
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["lease_takeover_no_double_effect"]
assert r["cancelled_and_failed_queryable"]
assert r["failed"]==[]
print("POSTCHECK_OK")
PY
