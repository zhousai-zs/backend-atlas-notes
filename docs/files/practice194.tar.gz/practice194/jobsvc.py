"""Teaching job service: API process, SQLite state, leased workers.

This is not Temporal. Temporal Workflow Execution uses a Workflow Id plus a
Run Id and durable event history. Here we keep a single job_id, a lease, and
an idempotent side-effect table so a second worker can resume without
double-applying.
"""
from __future__ import annotations

import sqlite3
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

STATES = ("queued", "running", "succeeded", "failed", "cancelled")
TERMINAL = {"succeeded", "failed", "cancelled"}


class JobStore:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.cx = sqlite3.connect(str(path), timeout=10, isolation_level=None)
        self.cx.execute("PRAGMA journal_mode=WAL")
        self.cx.execute("PRAGMA busy_timeout=5000")
        self.cx.executescript(
            """
            CREATE TABLE IF NOT EXISTS jobs (
              job_id TEXT PRIMARY KEY,
              kind TEXT NOT NULL,
              payload TEXT NOT NULL,
              state TEXT NOT NULL,
              lease_owner TEXT,
              lease_until REAL,
              result TEXT,
              error TEXT,
              cancel_requested INTEGER NOT NULL DEFAULT 0,
              created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS effects (
              job_id TEXT PRIMARY KEY,
              note TEXT NOT NULL,
              applied_at REAL NOT NULL
            );
            """
        )

    def submit(self, kind: str, payload: str, job_id: str | None = None) -> str:
        jid = job_id or uuid.uuid4().hex
        self.cx.execute(
            "INSERT INTO jobs(job_id, kind, payload, state, created_at) VALUES (?,?,?,?,?)",
            (jid, kind, payload, "queued", time.time()),
        )
        return jid

    def get(self, job_id: str) -> dict | None:
        row = self.cx.execute("SELECT job_id, kind, payload, state, lease_owner, lease_until, result, error, cancel_requested FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        if not row:
            return None
        keys = ["job_id", "kind", "payload", "state", "lease_owner", "lease_until", "result", "error", "cancel_requested"]
        return dict(zip(keys, row))

    def request_cancel(self, job_id: str) -> dict:
        job = self.get(job_id)
        if not job:
            return {"ok": False, "error": "not_found"}
        if job["state"] in TERMINAL:
            return {"ok": False, "error": "already_terminal", "state": job["state"]}
        self.cx.execute("UPDATE jobs SET cancel_requested=1, state='cancelled', lease_owner=NULL, lease_until=NULL WHERE job_id=? AND state NOT IN ('succeeded','failed','cancelled')", (job_id,))
        return {"ok": True, "state": self.get(job_id)["state"]}

    def claim(self, worker_id: str, lease_sec: float, now: float | None = None) -> dict | None:
        now = time.time() if now is None else now
        row = self.cx.execute(
            """
            SELECT job_id FROM jobs
            WHERE state IN ('queued','running')
              AND cancel_requested=0
              AND (lease_owner IS NULL OR lease_until < ?)
            ORDER BY created_at
            LIMIT 1
            """,
            (now,),
        ).fetchone()
        if not row:
            return None
        jid = row[0]
        self.cx.execute(
            "UPDATE jobs SET state='running', lease_owner=?, lease_until=? WHERE job_id=? AND (lease_owner IS NULL OR lease_until < ?)",
            (worker_id, now + lease_sec, jid, now),
        )
        job = self.get(jid)
        if not job or job["lease_owner"] != worker_id:
            return None
        return job

    def heartbeat(self, job_id: str, worker_id: str, lease_sec: float) -> bool:
        now = time.time()
        cur = self.cx.execute(
            "UPDATE jobs SET lease_until=? WHERE job_id=? AND lease_owner=? AND state='running'",
            (now + lease_sec, job_id, worker_id),
        )
        return cur.rowcount == 1

    def finish(self, job_id: str, worker_id: str, ok: bool, result: str | None, error: str | None) -> None:
        state = "succeeded" if ok else "failed"
        self.cx.execute(
            "UPDATE jobs SET state=?, result=?, error=?, lease_owner=NULL, lease_until=NULL WHERE job_id=? AND lease_owner=?",
            (state, result, error, job_id, worker_id),
        )

    def apply_effect_once(self, job_id: str, note: str) -> str:
        """Idempotent side effect keyed by job_id. A second worker hits this and does not insert again."""
        try:
            self.cx.execute(
                "INSERT INTO effects(job_id, note, applied_at) VALUES (?,?,?)",
                (job_id, note, time.time()),
            )
            return "applied"
        except sqlite3.IntegrityError:
            return "already_applied"

    def effect_count(self) -> int:
        return int(self.cx.execute("SELECT COUNT(*) FROM effects").fetchone()[0])

    def effect_for(self, job_id: str) -> str | None:
        row = self.cx.execute("SELECT note FROM effects WHERE job_id=?", (job_id,)).fetchone()
        return row[0] if row else None
