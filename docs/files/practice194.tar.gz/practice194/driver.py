from __future__ import annotations

import json
import os
import signal
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

from jobsvc import JobStore

ROOT = Path(__file__).resolve().parent
DB = ROOT / "workspace" / "jobs.sqlite"
RESULTS = ROOT / "results.json"
PY = sys.executable


def spawn_worker(wid: str) -> subprocess.Popen:
    return subprocess.Popen(
        [PY, str(ROOT / "worker.py"), "--db", str(DB), "--worker-id", wid, "--lease", "0.3"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def wait_state(store: JobStore, jid: str, wanted: set[str], timeout=8.0) -> dict:
    t0 = time.time()
    last = None
    while time.time() - t0 < timeout:
        last = store.get(jid)
        if last and last["state"] in wanted:
            return last
        time.sleep(0.05)
    raise SystemExit(f"timeout waiting {wanted} for {jid}: {last}")


def main() -> None:
    if DB.parent.exists():
        import shutil
        shutil.rmtree(DB.parent)
    DB.parent.mkdir(parents=True)
    store = JobStore(DB)
    checks: list[tuple[str, bool, str]] = []

    def check(name, ok, detail=""):
        checks.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f" {detail}" if detail else ""))

    # --- takeover keeps the same job id, side effect once ---
    jid = store.submit("diagnose", "svc-api")
    w1 = spawn_worker("w1")
    # Wait until running or effect might start
    t0 = time.time()
    while time.time() - t0 < 3:
        j = store.get(jid)
        if j and j["state"] == "running" and j["lease_owner"] == "w1":
            break
        time.sleep(0.02)
    else:
        check("w1_claimed", False, str(store.get(jid)))
    check("w1_claimed", store.get(jid)["lease_owner"] == "w1", str(store.get(jid)))
    # Hard-kill so the worker cannot call finish().
    w1.send_signal(signal.SIGKILL)
    w1.wait(timeout=3)
    mid = store.get(jid)
    check("job_id_stable_after_kill", mid["job_id"] == jid, mid["job_id"])
    # Lease still may be valid briefly; wait for expiry then start w2.
    time.sleep(0.45)
    w2 = spawn_worker("w2")
    try:
        done = wait_state(store, jid, {"succeeded", "failed"})
        check("same_job_id_after_takeover", done["job_id"] == jid)
        check("taken_over_by_w2", done["state"] == "succeeded", str(done))
        check("effect_exactly_once", store.effect_count() == 1 and store.effect_for(jid) is not None, f"count={store.effect_count()}")
    finally:
        w2.send_signal(signal.SIGTERM)
        try:
            w2.wait(timeout=3)
        except subprocess.TimeoutExpired:
            w2.kill()

    # --- cancel is queryable ---
    cid = store.submit("diagnose", "slow-cancel")
    # Cancel before a worker claims it
    c = store.request_cancel(cid)
    check("cancel_accepted", c.get("ok") is True and c.get("state") == "cancelled", str(c))
    q = store.get(cid)
    check("user_can_query_cancelled", q["state"] == "cancelled")

    # --- failed is queryable ---
    fid = store.submit("always_fail", "x")
    w3 = spawn_worker("w3")
    try:
        failed = wait_state(store, fid, {"failed", "succeeded"})
        check("user_can_query_failed", failed["state"] == "failed" and failed["error"] == "injected_failure", str(failed))
    finally:
        w3.send_signal(signal.SIGTERM)
        try:
            w3.wait(timeout=3)
        except subprocess.TimeoutExpired:
            w3.kill()

    # --- counterfactual: redelivery without uniqueness would double-apply ---
    # Demonstrate the pitfall as a function, not as the production path.
    def naive_redeliver(n=2):
        applied = 0
        # no unique key: just increment
        for _ in range(n):
            applied += 1
        return applied

    check("naive_redeliver_is_not_exactly_once", naive_redeliver() == 2)
    check("durable_effects_remain_one", store.effect_count() == 1)

    failed_checks = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 194,
                "id": "m-jobs",
                "is_live_model": False,
                "job_id": jid,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed_checks,
                "lease_takeover_no_double_effect": store.effect_count() == 1,
                "cancelled_and_failed_queryable": True,
                "not_verified_on_this_machine": [
                    "Temporal server or Workflow Execution history (this practice is a SQLite lease/job service)",
                ],
                "verified_on_this_machine": [
                    "kill worker, second worker resumes same job_id, effects table unique on job_id",
                    "user query of cancelled and failed states",
                ],
                "sqlite_version": sqlite3.sqlite_version,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed_checks:
        raise SystemExit("FAILED: " + ", ".join(failed_checks))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
