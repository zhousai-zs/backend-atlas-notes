#!/usr/bin/env python3
"""Creator-wallet debit / transfer service for lesson 99.

Two execution paths against a real sqlite3 database (two or more
connections / sessions):

  naive  – application-level read-modify-write with an absolute UPDATE,
           or autocommit of each statement, or retry of only the failed
           statement.
  safe   – a single-statement conditional UPDATE, or BEGIN IMMEDIATE so
           the whole read-modify-write holds a reserved lock; retries
           roll back and repeat the entire transaction.

This is still a teaching service: the business setting (creator wallet,
paid-article purchase) is a classroom hypothesis. sqlite3 isolation is
NOT PostgreSQL / InnoDB isolation; see the lesson text and
https://www.sqlite.org/isolation.html.
"""
from __future__ import annotations

import os
import sqlite3
import tempfile
import threading
import time
from typing import Optional


DEFAULT_BUSY_MS = 5000


def connect(path: str, timeout_s: float = 5.0) -> sqlite3.Connection:
    # isolation_level=None => autocommit; we issue explicit BEGIN / COMMIT.
    conn = sqlite3.connect(path, timeout=timeout_s, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute(f"PRAGMA busy_timeout={int(timeout_s * 1000)}")
    return conn


def init_wallets(path: str, rows: list[tuple[int, str, int]]) -> None:
    if os.path.exists(path):
        os.remove(path)
    conn = connect(path)
    try:
        conn.execute(
            """
            CREATE TABLE wallet (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                balance INTEGER NOT NULL,
                version INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.executemany(
            "INSERT INTO wallet(id, name, balance, version) VALUES (?,?,?,0)",
            rows,
        )
    finally:
        conn.close()


def get_balance(conn: sqlite3.Connection, wallet_id: int) -> int:
    row = conn.execute(
        "SELECT balance FROM wallet WHERE id=?", (wallet_id,)
    ).fetchone()
    if row is None:
        raise KeyError(wallet_id)
    return int(row[0])


def total_balance(conn: sqlite3.Connection) -> int:
    return int(conn.execute("SELECT SUM(balance) FROM wallet").fetchone()[0] or 0)


def snapshot(conn: sqlite3.Connection) -> dict[int, int]:
    return {
        int(r["id"]): int(r["balance"])
        for r in conn.execute("SELECT id, balance FROM wallet ORDER BY id")
    }


# ---------------------------------------------------------------------------
# Debit: naive RMW vs safe conditional / BEGIN IMMEDIATE / version CAS
# ---------------------------------------------------------------------------

def naive_rmw_debit(conn: sqlite3.Connection, wallet_id: int, amount: int) -> bool:
    """SELECT, compute in Python, UPDATE to an absolute value. Autocommit.

    Two sessions that both observe the same balance will silently
    overwrite each other: the classic lost update.
    """
    bal = get_balance(conn, wallet_id)
    if bal < amount:
        return False
    conn.execute(
        "UPDATE wallet SET balance=? WHERE id=?",
        (bal - amount, wallet_id),
    )
    return True


def safe_conditional_debit(conn: sqlite3.Connection, wallet_id: int, amount: int) -> bool:
    """One atomic statement: decrement only if the balance is enough."""
    cur = conn.execute(
        "UPDATE wallet SET balance = balance - ? WHERE id=? AND balance >= ?",
        (amount, wallet_id, amount),
    )
    return cur.rowcount == 1


def safe_immediate_debit(conn: sqlite3.Connection, wallet_id: int, amount: int) -> bool:
    """BEGIN IMMEDIATE serializes writers, then read-modify-write safely."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        bal = get_balance(conn, wallet_id)
        if bal < amount:
            conn.execute("ROLLBACK")
            return False
        conn.execute(
            "UPDATE wallet SET balance=? WHERE id=?",
            (bal - amount, wallet_id),
        )
        conn.execute("COMMIT")
        return True
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise


def safe_cas_debit(conn: sqlite3.Connection, wallet_id: int, amount: int) -> bool:
    """Version-column compare-and-set; caller may retry the whole debit."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        row = conn.execute(
            "SELECT balance, version FROM wallet WHERE id=?", (wallet_id,)
        ).fetchone()
        if row is None:
            conn.execute("ROLLBACK")
            raise KeyError(wallet_id)
        bal, ver = int(row[0]), int(row[1])
        if bal < amount:
            conn.execute("ROLLBACK")
            return False
        cur = conn.execute(
            "UPDATE wallet SET balance=?, version=version+1 "
            "WHERE id=? AND version=?",
            (bal - amount, wallet_id, ver),
        )
        if cur.rowcount != 1:
            conn.execute("ROLLBACK")
            return False
        conn.execute("COMMIT")
        return True
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise


# ---------------------------------------------------------------------------
# Transfer: autocommit each leg vs one transaction
# ---------------------------------------------------------------------------

def naive_transfer(conn: sqlite3.Connection, src: int, dst: int, amount: int) -> bool:
    """Each UPDATE is its own implicit transaction (autocommit)."""
    if not naive_rmw_debit(conn, src, amount):
        return False
    # Credit uses an absolute write too, so concurrent credits can be lost.
    bal = get_balance(conn, dst)
    conn.execute("UPDATE wallet SET balance=? WHERE id=?", (bal + amount, dst))
    return True


def safe_transfer(conn: sqlite3.Connection, src: int, dst: int, amount: int) -> bool:
    """Debit and credit in one BEGIN IMMEDIATE transaction."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        s = get_balance(conn, src)
        if s < amount:
            conn.execute("ROLLBACK")
            return False
        d = get_balance(conn, dst)
        conn.execute("UPDATE wallet SET balance=? WHERE id=?", (s - amount, src))
        conn.execute("UPDATE wallet SET balance=? WHERE id=?", (d + amount, dst))
        conn.execute("COMMIT")
        return True
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise


def safe_conditional_transfer(
    conn: sqlite3.Connection, src: int, dst: int, amount: int
) -> bool:
    conn.execute("BEGIN IMMEDIATE")
    try:
        cur = conn.execute(
            "UPDATE wallet SET balance = balance - ? WHERE id=? AND balance >= ?",
            (amount, src, amount),
        )
        if cur.rowcount != 1:
            conn.execute("ROLLBACK")
            return False
        conn.execute(
            "UPDATE wallet SET balance = balance + ? WHERE id=?",
            (amount, dst),
        )
        conn.execute("COMMIT")
        return True
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise


# ---------------------------------------------------------------------------
# Scripted experiments (deterministic where races would otherwise flake)
# ---------------------------------------------------------------------------

def experiment_lost_update(dirpath: str) -> dict:
    """Two real sqlite3 connections, interleaved SELECT then absolute UPDATE."""
    path = os.path.join(dirpath, "lost_update.db")
    init_wallets(path, [(1, "creator_alice", 100)])

    c1, c2 = connect(path), connect(path)
    try:
        b1 = get_balance(c1, 1)
        b2 = get_balance(c2, 1)
        assert b1 == 100 and b2 == 100
        c1.execute("UPDATE wallet SET balance=? WHERE id=?", (b1 - 30, 1))
        c2.execute("UPDATE wallet SET balance=? WHERE id=?", (b2 - 30, 1))
        c3 = connect(path)
        try:
            naive_final = get_balance(c3, 1)
        finally:
            c3.close()
    finally:
        c1.close()
        c2.close()

    # Safe: conditional UPDATE, two sessions, same interleaving of calls.
    path_s = os.path.join(dirpath, "lost_update_safe.db")
    init_wallets(path_s, [(1, "creator_alice", 100)])
    s1, s2 = connect(path_s), connect(path_s)
    try:
        ok1 = safe_conditional_debit(s1, 1, 30)
        ok2 = safe_conditional_debit(s2, 1, 30)
        s3 = connect(path_s)
        try:
            cond_final = get_balance(s3, 1)
        finally:
            s3.close()
    finally:
        s1.close()
        s2.close()

    # Safe: BEGIN IMMEDIATE, two threads so the second waits on the lock.
    path_i = os.path.join(dirpath, "lost_update_imm.db")
    init_wallets(path_i, [(1, "creator_alice", 100)])
    hold_s = 0.20
    ready = threading.Event()
    waits: list[float] = []
    flags: list[bool] = []

    def first():
        conn = connect(path_i)
        try:
            conn.execute("BEGIN IMMEDIATE")
            ready.set()
            bal = get_balance(conn, 1)
            time.sleep(hold_s)
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (bal - 30, 1))
            conn.execute("COMMIT")
            flags.append(True)
        finally:
            conn.close()

    def second():
        ready.wait(timeout=5)
        conn = connect(path_i, timeout_s=5.0)
        try:
            t0 = time.perf_counter()
            ok = safe_immediate_debit(conn, 1, 30)
            waits.append(time.perf_counter() - t0)
            flags.append(ok)
        finally:
            conn.close()

    t_a = threading.Thread(target=first)
    t_b = threading.Thread(target=second)
    t_a.start()
    t_b.start()
    t_a.join()
    t_b.join()
    c = connect(path_i)
    try:
        imm_final = get_balance(c, 1)
    finally:
        c.close()

    # CAS variant, two sequential calls (no race needed to show the write).
    path_c = os.path.join(dirpath, "lost_update_cas.db")
    init_wallets(path_c, [(1, "creator_alice", 100)])
    k1, k2 = connect(path_c), connect(path_c)
    try:
        cas1 = safe_cas_debit(k1, 1, 30)
        cas2 = safe_cas_debit(k2, 1, 30)
        k3 = connect(path_c)
        try:
            cas_final = get_balance(k3, 1)
        finally:
            k3.close()
    finally:
        k1.close()
        k2.close()

    return {
        "initial": 100,
        "each_debit": 30,
        "sessions": 2,
        "expected": 40,
        "naive_final": naive_final,
        "safe_conditional_final": cond_final,
        "safe_conditional_ok": [ok1, ok2],
        "safe_immediate_final": imm_final,
        "safe_immediate_ok": flags,
        "safe_immediate_wait_s": round(waits[0], 4) if waits else None,
        "safe_immediate_hold_s": hold_s,
        "safe_cas_final": cas_final,
        "safe_cas_ok": [cas1, cas2],
    }


def experiment_atomicity(dirpath: str) -> dict:
    """Transfer 30 from A to B; crash between debit and credit."""
    path_n = os.path.join(dirpath, "atomic_naive.db")
    init_wallets(path_n, [(1, "alice", 100), (2, "bob", 100)])
    c = connect(path_n)
    try:
        # Naive: debit autocommits, then the process "crashes" before credit.
        naive_rmw_debit(c, 1, 30)
        # Simulate crash: close without a credit.
    finally:
        c.close()
    c2 = connect(path_n)
    try:
        naive_snap = snapshot(c2)
        naive_total = total_balance(c2)
    finally:
        c2.close()

    path_s = os.path.join(dirpath, "atomic_safe.db")
    init_wallets(path_s, [(1, "alice", 100), (2, "bob", 100)])
    c = connect(path_s)
    try:
        c.execute("BEGIN IMMEDIATE")
        s = get_balance(c, 1)
        d = get_balance(c, 2)
        c.execute("UPDATE wallet SET balance=? WHERE id=?", (s - 30, 1))
        # Crash before credit and before COMMIT: close the connection.
        # SQLite rolls back the uncommitted transaction.
    finally:
        c.close()
    c2 = connect(path_s)
    try:
        safe_snap = snapshot(c2)
        safe_total = total_balance(c2)
    finally:
        c2.close()

    return {
        "a_initial": 100,
        "b_initial": 100,
        "transfer": 30,
        "expected_total": 200,
        "naive_after_crash": {
            "a": naive_snap[1],
            "b": naive_snap[2],
            "total": naive_total,
        },
        "safe_after_crash": {
            "a": safe_snap[1],
            "b": safe_snap[2],
            "total": safe_total,
        },
    }


def experiment_durability(dirpath: str) -> dict:
    path = os.path.join(dirpath, "durable.db")
    init_wallets(path, [(1, "alice", 100)])

    c = connect(path)
    try:
        c.execute("BEGIN IMMEDIATE")
        c.execute("UPDATE wallet SET balance=? WHERE id=?", (70, 1))
        c.execute("COMMIT")
    finally:
        c.close()
    c2 = connect(path)
    try:
        after_commit = get_balance(c2, 1)
    finally:
        c2.close()

    path_u = os.path.join(dirpath, "undurable.db")
    init_wallets(path_u, [(1, "alice", 100)])
    c = connect(path_u)
    try:
        c.execute("BEGIN IMMEDIATE")
        c.execute("UPDATE wallet SET balance=? WHERE id=?", (70, 1))
        # No COMMIT: close / "crash".
    finally:
        c.close()
    c2 = connect(path_u)
    try:
        after_crash = get_balance(c2, 1)
    finally:
        c2.close()

    return {
        "initial": 100,
        "written": 70,
        "committed_visible": after_commit,
        "committed_seen_by_new_connection": after_commit == 70,
        "uncommitted_after_crash": after_crash,
        "uncommitted_invisible_after_crash": after_crash == 100,
    }


def experiment_invariants(dirpath: str) -> dict:
    """Deterministic barrier lost-updates + a safe concurrent transfer soak."""
    # --- Debit campaign, barrier so every naive worker reads the same value.
    n_workers = 8
    initial = 1000
    debit = 10
    expected = initial - n_workers * debit  # 920

    path_n = os.path.join(dirpath, "inv_debit_naive.db")
    init_wallets(path_n, [(1, "alice", initial)])
    barrier = threading.Barrier(n_workers, timeout=10)
    errors: list[str] = []

    def naive_worker():
        conn = connect(path_n)
        try:
            bal = get_balance(conn, 1)
            barrier.wait()
            conn.execute(
                "UPDATE wallet SET balance=? WHERE id=?",
                (bal - debit, 1),
            )
        except Exception as e:
            errors.append(f"naive: {type(e).__name__}: {e}")
        finally:
            conn.close()

    threads = [threading.Thread(target=naive_worker) for _ in range(n_workers)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    c = connect(path_n)
    try:
        naive_final = get_balance(c, 1)
        naive_neg = naive_final < 0
    finally:
        c.close()

    path_s = os.path.join(dirpath, "inv_debit_safe.db")
    init_wallets(path_s, [(1, "alice", initial)])
    barrier_s = threading.Barrier(n_workers, timeout=10)
    safe_ok = []
    lock = threading.Lock()

    def safe_worker():
        conn = connect(path_s)
        try:
            # Arrive together so they all try to debit the same starting
            # balance; conditional UPDATE must still apply all 8 times.
            barrier_s.wait()
            ok = safe_conditional_debit(conn, 1, debit)
            with lock:
                safe_ok.append(ok)
        except Exception as e:
            errors.append(f"safe: {type(e).__name__}: {e}")
        finally:
            conn.close()

    threads = [threading.Thread(target=safe_worker) for _ in range(n_workers)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    c = connect(path_s)
    try:
        safe_final = get_balance(c, 1)
        safe_neg = safe_final < 0
    finally:
        c.close()

    # --- Transfer soak on the safe path: many threads, sum must hold.
    n_accounts = 10
    each = 1000
    total0 = n_accounts * each
    workers = 16
    ops = 40
    path_t = os.path.join(dirpath, "inv_transfer_safe.db")
    init_wallets(
        path_t,
        [(i, f"c{i}", each) for i in range(1, n_accounts + 1)],
    )
    start_gate = threading.Barrier(workers, timeout=10)
    done_ops = {"ok": 0, "rej": 0}
    dlock = threading.Lock()

    def transfer_worker(seed: int):
        conn = connect(path_t, timeout_s=10.0)
        try:
            start_gate.wait()
            x = seed
            for k in range(ops):
                # Tiny deterministic LCG so we do not need the random module
                # to be a "source of truth"; still enough cross-account mix.
                x = (1103515245 * x + 12345) & 0x7FFFFFFF
                src = (x % n_accounts) + 1
                x = (1103515245 * x + 12345) & 0x7FFFFFFF
                dst = (x % n_accounts) + 1
                if src == dst:
                    dst = src % n_accounts + 1
                try:
                    ok = safe_conditional_transfer(conn, src, dst, 7)
                except sqlite3.OperationalError:
                    ok = False
                    # Retry the whole transfer once after a short pause.
                    time.sleep(0.01)
                    try:
                        ok = safe_conditional_transfer(conn, src, dst, 7)
                    except sqlite3.OperationalError:
                        ok = False
                with dlock:
                    if ok:
                        done_ops["ok"] += 1
                    else:
                        done_ops["rej"] += 1
        except Exception as e:
            errors.append(f"xfer: {type(e).__name__}: {e}")
        finally:
            conn.close()

    threads = [
        threading.Thread(target=transfer_worker, args=(i + 1,))
        for i in range(workers)
    ]
    t0 = time.perf_counter()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    soak_s = round(time.perf_counter() - t0, 4)
    c = connect(path_t)
    try:
        soak_total = total_balance(c)
        soak_snap = snapshot(c)
        soak_neg = sum(1 for v in soak_snap.values() if v < 0)
        soak_min = min(soak_snap.values())
        soak_max = max(soak_snap.values())
    finally:
        c.close()

    # --- Deterministic naive transfer that breaks the sum.
    # T1: A->B 10, T2: B->C 10, both using absolute RMW, barrier after reads.
    path_nt = os.path.join(dirpath, "inv_transfer_naive.db")
    init_wallets(path_nt, [(1, "a", 100), (2, "b", 100), (3, "c", 100)])
    barrier_t = threading.Barrier(2, timeout=10)
    t2_wrote_b = threading.Event()
    box: dict = {}

    def naive_t1():
        conn = connect(path_nt)
        try:
            a = get_balance(conn, 1)
            b = get_balance(conn, 2)
            barrier_t.wait()
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (a - 10, 1))
            # Wait until T2 has written B=90, then overwrite with B=110
            # (absolute value computed from the stale read). T2's debit of
            # B is lost; C already received +10; total becomes 310.
            if not t2_wrote_b.wait(timeout=10):
                raise TimeoutError("t2 did not write B")
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (b + 10, 2))
            box["t1"] = (a, b)
        finally:
            conn.close()

    def naive_t2():
        conn = connect(path_nt)
        try:
            b = get_balance(conn, 2)
            cbal = get_balance(conn, 3)
            barrier_t.wait()
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (cbal + 10, 3))
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (b - 10, 2))
            box["t2"] = (b, cbal)
            t2_wrote_b.set()
        finally:
            conn.close()

    t1 = threading.Thread(target=naive_t1)
    t2 = threading.Thread(target=naive_t2)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    c = connect(path_nt)
    try:
        nt_snap = snapshot(c)
        nt_total = total_balance(c)
    finally:
        c.close()

    return {
        "errors": errors,
        "debit_campaign": {
            "n_workers": n_workers,
            "initial": initial,
            "debit": debit,
            "expected_final": expected,
            "naive_final": naive_final,
            "naive_delta_from_expected": naive_final - expected,
            "naive_negative": naive_neg,
            "safe_final": safe_final,
            "safe_successes": sum(1 for x in safe_ok if x),
            "safe_negative": safe_neg,
        },
        "naive_transfer_break": {
            "initial_total": 300,
            "expected_total": 300,
            "final": {"a": nt_snap[1], "b": nt_snap[2], "c": nt_snap[3]},
            "final_total": nt_total,
            "delta": nt_total - 300,
            "reads": {k: list(v) if isinstance(v, tuple) else v for k, v in box.items()},
        },
        "safe_transfer_soak": {
            "accounts": n_accounts,
            "initial_each": each,
            "initial_total": total0,
            "workers": workers,
            "ops_per_worker": ops,
            "attempted": workers * ops,
            "ok": done_ops["ok"],
            "rejected": done_ops["rej"],
            "final_total": soak_total,
            "delta": soak_total - total0,
            "negative_accounts": soak_neg,
            "min_balance": soak_min,
            "max_balance": soak_max,
            "elapsed_s": soak_s,
        },
    }


def experiment_retry(dirpath: str) -> dict:
    """Naive retries only the credit; safe retries the whole transaction.

    The credit-timeout case: the credit actually landed, the client saw a
    failure, and naive retried only the credit (duplicate in-flow).

    The safe path injects a failure before COMMIT, rolls back, and
    retries debit+credit together. Also exercises sqlite3 busy / locked
    retry of an entire BEGIN IMMEDIATE transfer.
    """
    # --- Naive duplicate credit after a "failed" (but applied) in-flow.
    path_n = os.path.join(dirpath, "retry_naive.db")
    init_wallets(path_n, [(1, "alice", 100), (2, "bob", 100)])
    c = connect(path_n)
    try:
        naive_rmw_debit(c, 1, 30)
        # Credit applied...
        bal = get_balance(c, 2)
        c.execute("UPDATE wallet SET balance=? WHERE id=?", (bal + 30, 2))
        # ...but the client is told it failed (timeout / lost response)
        # and retries only the credit statement.
        bal = get_balance(c, 2)
        c.execute("UPDATE wallet SET balance=? WHERE id=?", (bal + 30, 2))
        naive_snap = snapshot(c)
        naive_total = total_balance(c)
    finally:
        c.close()

    # --- Safe: injected failure before commit, full rollback, retry.
    path_s = os.path.join(dirpath, "retry_safe.db")
    init_wallets(path_s, [(1, "alice", 100), (2, "bob", 100)])

    class InjectedFailure(Exception):
        pass

    def safe_transfer_may_fail(conn: sqlite3.Connection, fail: bool) -> bool:
        conn.execute("BEGIN IMMEDIATE")
        try:
            s = get_balance(conn, 1)
            if s < 30:
                conn.execute("ROLLBACK")
                return False
            d = get_balance(conn, 2)
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (s - 30, 1))
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (d + 30, 2))
            if fail:
                conn.execute("ROLLBACK")
                raise InjectedFailure("serialization / deadlock injected")
            conn.execute("COMMIT")
            return True
        except InjectedFailure:
            raise
        except Exception:
            try:
                conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise

    c = connect(path_s)
    retries = 0
    attempts = 0
    try:
        while True:
            attempts += 1
            try:
                safe_transfer_may_fail(c, fail=(attempts == 1))
                break
            except InjectedFailure:
                retries += 1
                if retries > 5:
                    raise
        safe_snap = snapshot(c)
        safe_total = total_balance(c)
    finally:
        c.close()

    # --- sqlite3 locked/busy: two overlapping BEGIN IMMEDIATE transfers
    # on the same pair of rows. The second waits or gets busy; safe retry
    # of the *whole* transaction leaves the sum intact.
    path_b = os.path.join(dirpath, "retry_busy.db")
    init_wallets(path_b, [(1, "alice", 100), (2, "bob", 100)])
    hold = threading.Event()
    released = threading.Event()
    busy_hits = {"count": 0, "retries": 0, "ok": 0}
    hold_s = 0.15

    def holder():
        conn = connect(path_b, timeout_s=5.0)
        try:
            conn.execute("BEGIN IMMEDIATE")
            hold.set()
            s = get_balance(conn, 1)
            d = get_balance(conn, 2)
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (s - 10, 1))
            conn.execute("UPDATE wallet SET balance=? WHERE id=?", (d + 10, 2))
            time.sleep(hold_s)
            conn.execute("COMMIT")
        finally:
            conn.close()
            released.set()

    def waiter():
        hold.wait(timeout=5)
        # Short busy_timeout so we actually observe a locked error, then
        # retry the entire transfer (not a single statement).
        conn = connect(path_b, timeout_s=0.05)
        try:
            attempts_w = 0
            while attempts_w < 40:
                attempts_w += 1
                try:
                    if safe_conditional_transfer(conn, 1, 2, 10):
                        busy_hits["ok"] += 1
                        break
                except sqlite3.OperationalError as e:
                    msg = str(e).lower()
                    if "locked" in msg or "busy" in msg:
                        busy_hits["count"] += 1
                        busy_hits["retries"] += 1
                        time.sleep(0.02)
                        continue
                    raise
        finally:
            conn.close()

    t_h = threading.Thread(target=holder)
    t_w = threading.Thread(target=waiter)
    t_h.start()
    t_w.start()
    t_h.join()
    t_w.join()
    c = connect(path_b)
    try:
        busy_snap = snapshot(c)
        busy_total = total_balance(c)
    finally:
        c.close()

    return {
        "amount": 30,
        "expected_total": 200,
        "expected_a": 70,
        "expected_b": 130,
        "naive_a": naive_snap[1],
        "naive_b": naive_snap[2],
        "naive_total": naive_total,
        "naive_duplicate_credit": naive_snap[2] == 160,
        "safe_a": safe_snap[1],
        "safe_b": safe_snap[2],
        "safe_total": safe_total,
        "safe_retries": retries,
        "safe_attempts": attempts,
        "busy": {
            "locked_or_busy_errors": busy_hits["count"],
            "whole_tx_retries": busy_hits["retries"],
            "waiter_ok": busy_hits["ok"],
            "final_a": busy_snap[1],
            "final_b": busy_snap[2],
            "final_total": busy_total,
            "expected_total": 200,
            "two_transfers_applied": busy_snap[1] == 80 and busy_snap[2] == 120,
            "hold_s": hold_s,
        },
    }


def run_sqlite_experiments(dirpath: Optional[str] = None) -> dict:
    cleanup = False
    if dirpath is None:
        dirpath = tempfile.mkdtemp(prefix="practice99_")
        cleanup = False  # caller / test keeps results; dbs are small
    os.makedirs(dirpath, exist_ok=True)
    return {
        "sqlite_version": sqlite3.sqlite_version,
        "lost_update": experiment_lost_update(dirpath),
        "atomicity": experiment_atomicity(dirpath),
        "durability": experiment_durability(dirpath),
        "invariants": experiment_invariants(dirpath),
        "retry": experiment_retry(dirpath),
        "db_dir": dirpath,
        "cleanup": cleanup,
    }


if __name__ == "__main__":
    import json

    print(json.dumps(run_sqlite_experiments("/tmp/practice99-preview"), indent=2, ensure_ascii=False))
