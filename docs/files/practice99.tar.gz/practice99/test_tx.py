#!/usr/bin/env python3
"""Acceptance checks for the g-transaction teaching lab."""
from __future__ import annotations

import json
import os
import sqlite3
import sys

from app import run_sqlite_experiments
from engine import run_isolation_experiments

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    db_dir = os.path.join(HERE, "_dbs")
    os.makedirs(db_dir, exist_ok=True)
    sqlite = run_sqlite_experiments(db_dir)
    model = run_isolation_experiments()

    data = {
        "python": sys.version.split()[0],
        "sqlite_version": sqlite3.sqlite_version,
        "pg_doc": "https://www.postgresql.org/docs/current/transaction-iso.html",
        "pg_doc_checked": "2026-11-11",
        "pg_doc_edition": "PostgreSQL 18",
        "sqlite_isolation_doc": "https://www.sqlite.org/isolation.html",
        "lost_update": sqlite["lost_update"],
        "atomicity": sqlite["atomicity"],
        "durability": sqlite["durability"],
        "invariants": sqlite["invariants"],
        "retry": sqlite["retry"],
        "isolation_model": model,
    }

    _assert_lost_update(data["lost_update"])
    _assert_atomicity(data["atomicity"])
    _assert_durability(data["durability"])
    _assert_invariants(data["invariants"])
    _assert_retry(data["retry"])
    _assert_isolation_model(data["isolation_model"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

    lu = data["lost_update"]
    at = data["atomicity"]
    inv = data["invariants"]
    rt = data["retry"]
    soak = inv["safe_transfer_soak"]
    debit = inv["debit_campaign"]
    brk = inv["naive_transfer_break"]
    skew = data["isolation_model"]["write_skew"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"lost_update naive={lu['naive_final']} safe_cond={lu['safe_conditional_final']} "
        f"safe_imm={lu['safe_immediate_final']} expected={lu['expected']} "
        f"imm_wait_s={lu['safe_immediate_wait_s']} "
        f"atomic_naive_total={at['naive_after_crash']['total']} "
        f"atomic_safe_total={at['safe_after_crash']['total']} "
        f"debit_naive={debit['naive_final']} debit_safe={debit['safe_final']} "
        f"xfer_naive_total={brk['final_total']} "
        f"soak_total={soak['final_total']} soak_ok={soak['ok']}/{soak['attempted']} "
        f"retry_naive_total={rt['naive_total']} retry_safe_total={rt['safe_total']} "
        f"retry_safe_retries={rt['safe_retries']} "
        f"busy_retries={rt['busy']['whole_tx_retries']} "
        f"skew_rr_on_duty={skew['REPEATABLE READ']['final_on_duty']} "
        f"skew_s_on_duty={skew['SERIALIZABLE']['final_on_duty']}"
    )
    return 0


def _assert_lost_update(lu: dict) -> None:
    assert lu["initial"] == 100 and lu["each_debit"] == 30, lu
    assert lu["expected"] == 40, lu
    # Two sessions each deduct 30 from 100; lost update leaves 70.
    assert lu["naive_final"] == 70, lu
    assert lu["safe_conditional_final"] == 40, lu
    assert lu["safe_conditional_ok"] == [True, True], lu
    assert lu["safe_immediate_final"] == 40, lu
    assert all(lu["safe_immediate_ok"]), lu
    assert lu["safe_cas_final"] == 40, lu
    assert lu["safe_cas_ok"] == [True, True], lu
    # The second BEGIN IMMEDIATE waited for the reserved lock.
    assert lu["safe_immediate_wait_s"] is not None, lu
    assert lu["safe_immediate_wait_s"] >= 0.15, lu
    assert lu["safe_immediate_hold_s"] == 0.2, lu


def _assert_atomicity(at: dict) -> None:
    assert at["expected_total"] == 200, at
    # Naive autocommit debit survives the crash; credit never happens.
    assert at["naive_after_crash"]["a"] == 70, at
    assert at["naive_after_crash"]["b"] == 100, at
    assert at["naive_after_crash"]["total"] == 170, at
    # Safe uncommitted transfer rolls back completely.
    assert at["safe_after_crash"]["a"] == 100, at
    assert at["safe_after_crash"]["b"] == 100, at
    assert at["safe_after_crash"]["total"] == 200, at


def _assert_durability(du: dict) -> None:
    assert du["committed_visible"] == 70, du
    assert du["committed_seen_by_new_connection"] is True, du
    assert du["uncommitted_after_crash"] == 100, du
    assert du["uncommitted_invisible_after_crash"] is True, du


def _assert_invariants(inv: dict) -> None:
    assert inv["errors"] == [], inv
    d = inv["debit_campaign"]
    assert d["n_workers"] == 8 and d["initial"] == 1000 and d["debit"] == 10, d
    assert d["expected_final"] == 920, d
    # Barrier: all 8 naive workers read 1000 and write 990.
    assert d["naive_final"] == 990, d
    assert d["naive_delta_from_expected"] == 70, d
    assert d["safe_final"] == 920, d
    assert d["safe_successes"] == 8, d
    assert d["safe_negative"] is False, d

    brk = inv["naive_transfer_break"]
    assert brk["initial_total"] == 300, brk
    # Both transfers read B=100; one write to B is lost; sum drifts by 10.
    assert brk["final_total"] != 300, brk
    assert brk["final_total"] == 310, brk
    assert brk["delta"] == 10, brk
    assert brk["final"]["a"] == 90, brk
    assert brk["final"]["c"] == 110, brk

    soak = inv["safe_transfer_soak"]
    assert soak["initial_total"] == 10000, soak
    assert soak["attempted"] == 16 * 40 == 640, soak
    assert soak["ok"] + soak["rejected"] == 640, soak
    assert soak["ok"] == 640, soak
    assert soak["final_total"] == 10000, soak
    assert soak["delta"] == 0, soak
    assert soak["negative_accounts"] == 0, soak
    assert soak["min_balance"] >= 0, soak


def _assert_retry(rt: dict) -> None:
    assert rt["naive_a"] == 70, rt
    assert rt["naive_b"] == 160, rt
    assert rt["naive_total"] == 230, rt
    assert rt["naive_duplicate_credit"] is True, rt
    assert rt["safe_a"] == 70, rt
    assert rt["safe_b"] == 130, rt
    assert rt["safe_total"] == 200, rt
    assert rt["safe_retries"] == 1, rt
    assert rt["safe_attempts"] == 2, rt
    busy = rt["busy"]
    assert busy["final_total"] == 200, busy
    assert busy["two_transfers_applied"] is True, busy
    assert busy["final_a"] == 80 and busy["final_b"] == 120, busy
    assert busy["waiter_ok"] == 1, busy
    assert busy["locked_or_busy_errors"] >= 1, busy
    assert busy["whole_tx_retries"] == busy["locked_or_busy_errors"], busy


def _assert_isolation_model(m: dict) -> None:
    assert "teaching" in m["model"] and "not" in m["model"].lower(), m["model"]

    dirty = m["dirty_read"]
    assert dirty["READ UNCOMMITTED"]["dirty"] is True, dirty
    assert dirty["READ UNCOMMITTED"]["uncommitted_observe"] == 999, dirty
    assert dirty["READ UNCOMMITTED"]["after_t1_rollback"] == 100, dirty
    for iso in ("READ COMMITTED", "REPEATABLE READ", "SERIALIZABLE"):
        assert dirty[iso]["dirty"] is False, (iso, dirty[iso])
        assert dirty[iso]["uncommitted_observe"] == 100, (iso, dirty[iso])

    nr = m["nonrepeatable_read"]
    assert nr["READ UNCOMMITTED"]["nonrepeatable"] is True, nr
    assert nr["READ COMMITTED"]["nonrepeatable"] is True, nr
    assert nr["READ COMMITTED"]["first"] == 100 and nr["READ COMMITTED"]["second"] == 70, nr
    assert nr["REPEATABLE READ"]["nonrepeatable"] is False, nr
    assert nr["REPEATABLE READ"]["first"] == nr["REPEATABLE READ"]["second"] == 100, nr
    assert nr["SERIALIZABLE"]["nonrepeatable"] is False, nr

    ph = m["phantom_read"]
    assert ph["READ UNCOMMITTED"]["phantom"] is True, ph
    assert ph["READ COMMITTED"]["phantom"] is True, ph
    assert ph["READ COMMITTED"]["first_count"] == 2, ph
    assert ph["READ COMMITTED"]["second_count"] == 3, ph
    # Teaching RR is snapshot-style, like PostgreSQL RR (phantoms not seen).
    assert ph["REPEATABLE READ"]["phantom"] is False, ph
    assert ph["REPEATABLE READ"]["first_count"] == ph["REPEATABLE READ"]["second_count"] == 2, ph
    assert ph["SERIALIZABLE"]["phantom"] is False, ph

    lost = m["lost_update"]
    for iso in ("READ UNCOMMITTED", "READ COMMITTED"):
        assert lost[iso]["silent_lost_update"] is True, (iso, lost[iso])
        assert lost[iso]["final"] == 70, (iso, lost[iso])
        assert lost[iso]["t1_committed"] and lost[iso]["t2_committed"], (iso, lost[iso])
    for iso in ("REPEATABLE READ", "SERIALIZABLE"):
        assert lost[iso]["silent_lost_update"] is False, (iso, lost[iso])
        assert lost[iso]["t1_committed"] is True, (iso, lost[iso])
        assert lost[iso]["t2_committed"] is False, (iso, lost[iso])
        assert lost[iso]["retried_aborted_tx"] is True, (iso, lost[iso])
        assert lost[iso]["retry_ok"] is True, (iso, lost[iso])
        assert lost[iso]["before_retry"] == 70, (iso, lost[iso])
        assert lost[iso]["final"] == 40, (iso, lost[iso])

    skew = m["write_skew"]
    assert skew["REPEATABLE READ"]["write_skew"] is True, skew
    assert skew["REPEATABLE READ"]["final_on_duty"] == 0, skew
    assert skew["REPEATABLE READ"]["t2_committed"] is True, skew
    assert skew["SERIALIZABLE"]["write_skew"] is False, skew
    assert skew["SERIALIZABLE"]["final_on_duty"] == 1, skew
    assert skew["SERIALIZABLE"]["t2_committed"] is False, skew

    retry = m["retry"]
    assert retry["deadlock_caught"] is True, retry
    assert retry["naive_total"] == 230, retry
    assert retry["naive_b"] == 160, retry
    assert retry["safe_total"] == 200, retry
    assert retry["safe_a"] == 70 and retry["safe_b"] == 130, retry
    assert retry["safe_retries"] == 1, retry


if __name__ == "__main__":
    raise SystemExit(main())
