#!/usr/bin/env python3
"""Teaching isolation / transaction model for Backend Atlas lesson 99.

This is a scripted, single-process teaching model. It is NOT PostgreSQL,
InnoDB, or the SQLite kernel. Isolation-level names follow the SQL
standard / PostgreSQL documentation so the phenomena can be lined up
with https://www.postgresql.org/docs/current/transaction-iso.html
(checked 2026-11-11, PostgreSQL 18 docs), but the implementation is
deliberately small: versioned rows, per-statement or per-transaction
snapshots, and a simplified SSI-style rw-dependency check.

SQLite experiments live in app.py and must not be read as PostgreSQL
semantics (see that file and the lesson text).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


ISOLATION_LEVELS = (
    "READ UNCOMMITTED",
    "READ COMMITTED",
    "REPEATABLE READ",
    "SERIALIZABLE",
)


class SerializationFailure(Exception):
    """Raised when the teaching model refuses to commit a conflicting tx."""


class Deadlock(Exception):
    """Raised when the teaching model detects a lock-order cycle."""


@dataclass
class Version:
    xmin: int
    cts: int  # commit timestamp of the tx that created this version (0 = genesis)
    xmax: Optional[int] = None
    xmax_cts: Optional[int] = None
    data: dict = field(default_factory=dict)
    deleted: bool = False


@dataclass
class WriteOp:
    table: str
    pk: Any
    data: Optional[dict]  # None means delete
    read_cts: Optional[int]  # committed cts observed at write time


@dataclass
class PredicateRead:
    table: str
    predicate: Callable[[dict], bool]
    pks: frozenset


@dataclass
class Tx:
    txid: int
    isolation: str
    start_cts: int
    writes: dict = field(default_factory=dict)  # (table, pk) -> WriteOp
    read_keys: set = field(default_factory=set)
    predicates: list = field(default_factory=list)
    status: str = "active"
    # For a simplified lock manager used only by the deadlock demo.
    held_locks: set = field(default_factory=set)


class IsolationEngine:
    """In-memory multi-version store with four named isolation levels."""

    def __init__(self):
        self._tables: dict[str, dict[Any, list[Version]]] = {}
        self._next_txid = 1
        self._cts = 0
        self._active: dict[int, Tx] = {}
        self._committed: dict[int, Tx] = {}  # txid -> frozen tx (for SSI)
        self._commit_order: list[int] = []
        # lock_key -> txid, used only by acquire_lock / deadlock demo
        self._locks: dict[tuple, int] = {}
        self._wait_for: dict[int, int] = {}  # waiter txid -> holder txid

    def create_table(self, name: str) -> None:
        if name not in self._tables:
            self._tables[name] = {}

    def seed(self, table: str, pk: Any, data: dict) -> None:
        """Insert a committed genesis row (cts=0, xmin=0)."""
        self.create_table(table)
        row = dict(data)
        row_pk = row.get("id", pk)
        self._tables[table][pk] = [
            Version(xmin=0, cts=0, data={**row, "id": row_pk})
        ]

    def begin(self, isolation: str) -> Tx:
        iso = isolation.upper()
        if iso not in ISOLATION_LEVELS:
            raise ValueError(f"unknown isolation: {isolation}")
        tx = Tx(txid=self._next_txid, isolation=iso, start_cts=self._cts)
        self._next_txid += 1
        self._active[tx.txid] = tx
        return tx

    # ----- reads -----

    def select(self, tx: Tx, table: str, pk: Any) -> Optional[dict]:
        self._check_active(tx)
        key = (table, pk)
        if key in tx.writes:
            op = tx.writes[key]
            tx.read_keys.add(key)
            return None if op.data is None else dict(op.data)
        if tx.isolation == "READ UNCOMMITTED":
            dirty = self._peek_dirty(tx, table, pk)
            if dirty is not None:
                tx.read_keys.add(key)
                return dict(dirty)
            row = self._latest_committed(table, pk, as_of_cts=None)
        elif tx.isolation == "READ COMMITTED":
            row = self._latest_committed(table, pk, as_of_cts=None)
        else:
            # REPEATABLE READ and SERIALIZABLE: snapshot at first use,
            # aligned with PostgreSQL's "snapshot as of the start of the
            # first non-transaction-control statement" idea. We take the
            # snapshot at BEGIN (start_cts), which is equivalent if the
            # caller does not interleave commits between BEGIN and the
            # first statement. Demos always read immediately after BEGIN.
            row = self._latest_committed(table, pk, as_of_cts=tx.start_cts)
        tx.read_keys.add(key)
        return dict(row.data) if row is not None else None

    def select_where(self, tx: Tx, table: str, pred: Callable[[dict], bool]) -> list[dict]:
        self._check_active(tx)
        pks = set(self._tables.get(table, {}))
        # Uncommitted inserts by others are only visible at READ UNCOMMITTED.
        if tx.isolation == "READ UNCOMMITTED":
            for other in self._active.values():
                if other.txid == tx.txid:
                    continue
                for (t, pk), op in other.writes.items():
                    if t == table:
                        pks.add(pk)
        # Own writes (including inserts) are always candidates.
        for (t, pk) in tx.writes:
            if t == table:
                pks.add(pk)
        rows = []
        seen = set()
        for pk in list(pks):
            row = self.select(tx, table, pk)
            if row is not None and pred(row):
                rows.append(row)
                seen.add(pk)
        tx.predicates.append(PredicateRead(table, pred, frozenset(seen)))
        return rows

    # ----- writes -----

    def insert(self, tx: Tx, table: str, pk: Any, data: dict) -> None:
        self._check_active(tx)
        existing = self.select(tx, table, pk)
        if existing is not None:
            raise ValueError(f"duplicate key {table}.{pk}")
        payload = {**data, "id": data.get("id", pk)}
        tx.writes[(table, pk)] = WriteOp(table, pk, payload, read_cts=None)

    def update(self, tx: Tx, table: str, pk: Any, fields: dict) -> None:
        self._check_active(tx)
        current = self.select(tx, table, pk)
        if current is None:
            raise KeyError(f"missing row {table}.{pk}")
        # ww-conflict check at REPEATABLE READ / SERIALIZABLE, matching
        # PostgreSQL RR: "could not serialize access due to concurrent update"
        # if a row changed after our snapshot.
        if tx.isolation in ("REPEATABLE READ", "SERIALIZABLE"):
            latest = self._latest_committed(table, pk, as_of_cts=None)
            if latest is not None and latest.cts > tx.start_cts:
                self.rollback(tx)
                raise SerializationFailure(
                    "could not serialize access due to concurrent update"
                )
        new = {**current, **fields}
        read_cts = self._visible_cts(tx, table, pk)
        tx.writes[(table, pk)] = WriteOp(table, pk, new, read_cts=read_cts)

    def delete(self, tx: Tx, table: str, pk: Any) -> None:
        self._check_active(tx)
        current = self.select(tx, table, pk)
        if current is None:
            raise KeyError(f"missing row {table}.{pk}")
        if tx.isolation in ("REPEATABLE READ", "SERIALIZABLE"):
            latest = self._latest_committed(table, pk, as_of_cts=None)
            if latest is not None and latest.cts > tx.start_cts:
                self.rollback(tx)
                raise SerializationFailure(
                    "could not serialize access due to concurrent update"
                )
        read_cts = self._visible_cts(tx, table, pk)
        tx.writes[(table, pk)] = WriteOp(table, pk, None, read_cts=read_cts)

    def commit(self, tx: Tx) -> None:
        self._check_active(tx)
        if tx.isolation in ("REPEATABLE READ", "SERIALIZABLE"):
            # Re-check ww conflicts at commit in case the change landed
            # after our update() call (scripted interleaving).
            for key, op in tx.writes.items():
                latest = self._latest_committed(op.table, op.pk, as_of_cts=None)
                if latest is not None and latest.cts > tx.start_cts and op.read_cts is not None:
                    self.rollback(tx)
                    raise SerializationFailure(
                        "could not serialize access due to concurrent update"
                    )
        if tx.isolation == "SERIALIZABLE":
            if self._has_serialization_anomaly(tx):
                self.rollback(tx)
                raise SerializationFailure(
                    "could not serialize access due to read/write dependencies"
                )
        self._cts += 1
        cts = self._cts
        for (table, pk), op in tx.writes.items():
            self.create_table(table)
            chain = self._tables[table].setdefault(pk, [])
            if chain:
                cur = chain[-1]
                if cur.xmax is None:
                    cur.xmax = tx.txid
                    cur.xmax_cts = cts
            if op.data is not None:
                chain.append(Version(xmin=tx.txid, cts=cts, data=dict(op.data)))
            else:
                # deletion: leave the xmax-marked version as the tip
                if not chain:
                    chain.append(
                        Version(
                            xmin=tx.txid,
                            cts=cts,
                            data={},
                            deleted=True,
                            xmax=tx.txid,
                            xmax_cts=cts,
                        )
                    )
                else:
                    chain[-1].deleted = True
        tx.status = "committed"
        self._active.pop(tx.txid, None)
        self._committed[tx.txid] = tx
        self._commit_order.append(tx.txid)
        for k in list(tx.held_locks):
            if self._locks.get(k) == tx.txid:
                self._locks.pop(k, None)
        tx.held_locks.clear()
        self._wait_for.pop(tx.txid, None)

    def rollback(self, tx: Tx) -> None:
        if tx.status != "active":
            return
        tx.status = "aborted"
        self._active.pop(tx.txid, None)
        for k in list(tx.held_locks):
            if self._locks.get(k) == tx.txid:
                self._locks.pop(k, None)
        tx.held_locks.clear()
        self._wait_for.pop(tx.txid, None)

    # ----- lock / deadlock demo (teaching locks, not SQLite's lock manager) -----

    def acquire_lock(self, tx: Tx, table: str, pk: Any) -> None:
        """Exclusive row lock. Detects wait-for cycles and raises Deadlock."""
        self._check_active(tx)
        key = (table, pk)
        holder = self._locks.get(key)
        if holder is None or holder == tx.txid:
            self._locks[key] = tx.txid
            tx.held_locks.add(key)
            self._wait_for.pop(tx.txid, None)
            return True
        self._wait_for[tx.txid] = holder
        if self._wait_for_cycle():
            self._wait_for.pop(tx.txid, None)
            self.rollback(tx)
            raise Deadlock(f"deadlock: {tx.txid} waiting for {holder} on {key}")
        # Non-cyclic wait: the lock is not granted. The caller should
        # either let the holder finish, or have the holder try a lock
        # that closes a cycle (which raises Deadlock).
        return False

    # ----- internals -----

    def _check_active(self, tx: Tx) -> None:
        if tx.status != "active":
            raise RuntimeError(f"tx {tx.txid} is {tx.status}")

    def _peek_dirty(self, reader: Tx, table: str, pk: Any) -> Optional[dict]:
        # Last writer among active peers wins for the teaching RU demo.
        found = None
        for other in self._active.values():
            if other.txid == reader.txid:
                continue
            op = other.writes.get((table, pk))
            if op is not None:
                found = op.data
        return found

    def _latest_committed(
        self, table: str, pk: Any, as_of_cts: Optional[int]
    ) -> Optional[Version]:
        chain = self._tables.get(table, {}).get(pk, [])
        visible = None
        for ver in chain:
            if as_of_cts is None:
                # most recent committed version that is not deleted
                if ver.xmax is None and not ver.deleted:
                    visible = ver
                elif ver.xmax is not None and not ver.deleted:
                    # superseded; skip
                    continue
                elif ver.deleted and ver.xmax is not None:
                    visible = None
            else:
                if ver.cts <= as_of_cts and (ver.xmax_cts is None or ver.xmax_cts > as_of_cts):
                    if ver.deleted:
                        visible = None
                    else:
                        visible = ver
        if as_of_cts is None:
            # recompute strictly: latest version with no xmax, or whose
            # xmax is unset, preferring the last non-deleted tip
            visible = None
            for ver in chain:
                # A version is currently committed-visible if it has been
                # committed (always true for versions in the chain) and
                # has not been superseded (xmax is None) and is not a
                # deletion marker.
                if ver.xmax is None and not ver.deleted:
                    visible = ver
        return visible

    def _visible_cts(self, tx: Tx, table: str, pk: Any) -> Optional[int]:
        if tx.isolation in ("READ UNCOMMITTED", "READ COMMITTED"):
            row = self._latest_committed(table, pk, as_of_cts=None)
        else:
            row = self._latest_committed(table, pk, as_of_cts=tx.start_cts)
        return None if row is None else row.cts

    def _has_serialization_anomaly(self, tx: Tx) -> bool:
        """Simplified SSI: abort on an rw-dependency cycle with overlapping txs.

        An rw-dependency T -> U exists when T read a key (or predicate)
        that U wrote, and U committed after T's snapshot. The classic
        write-skew example is a two-cycle T1 -> T2 -> T1.
        """
        # Overlapping committed transactions: committed after our snapshot
        # and already in the history (we are not yet committed).
        peers: list[Tx] = []
        for tid in self._commit_order:
            other = self._committed[tid]
            # other committed with some cts > tx.start_cts
            # We don't store cts on Tx; infer from versions or order.
            # Any committed tx that wrote after we started is a candidate
            # if it is not before our snapshot. Use write tips.
            if self._tx_commit_cts(other) > tx.start_cts:
                peers.append(other)

        def wrote(t: Tx, key: tuple) -> bool:
            return key in t.writes

        def read_key(t: Tx, key: tuple) -> bool:
            return key in t.read_keys

        def predicate_conflict(reader: Tx, writer: Tx) -> bool:
            for pred in reader.predicates:
                for (table, pk), op in writer.writes.items():
                    if table != pred.table:
                        continue
                    # Writer inserted/updated/deleted a row that would
                    # change the predicate result for the reader.
                    data = op.data
                    if data is not None and pred.predicate(data):
                        if pk not in pred.pks:
                            return True
                    if data is None and pk in pred.pks:
                        return True
                    # Updated out of the set
                    if data is not None and pk in pred.pks and not pred.predicate(data):
                        return True
            return False

        # Build directed rw edges among {tx} ∪ peers, then look for a
        # cycle that includes tx. We also include ww as a dependency
        # (already aborted above for RR/S, so usually empty).
        nodes = [tx] + peers
        ids = {t.txid for t in nodes}
        adj: dict[int, set[int]] = {t.txid: set() for t in nodes}

        def add_rw(src: Tx, dst: Tx) -> None:
            if src.txid == dst.txid:
                return
            if src.txid in ids and dst.txid in ids:
                adj[src.txid].add(dst.txid)

        def b_not_in_snapshot_of_a(a: Tx, b: Tx) -> bool:
            # The committing tx (tx) is not yet in anyone's snapshot.
            if b is tx:
                return True
            if a is tx:
                return True
            return self._tx_commit_cts(b) > a.start_cts

        for a in nodes:
            for b in nodes:
                if a.txid == b.txid:
                    continue
                for key in set(a.read_keys):
                    if wrote(b, key):
                        # a -rw-> b if b wrote a key a read, and b is not
                        # already in a's snapshot (b committed later, or
                        # b is the tx currently committing).
                        if b_not_in_snapshot_of_a(a, b):
                            add_rw(a, b)
                if predicate_conflict(a, b):
                    if b_not_in_snapshot_of_a(a, b):
                        add_rw(a, b)

        # Cycle detection from tx
        seen: set[int] = set()
        stack: set[int] = set()

        def dfs(u: int) -> bool:
            if u in stack:
                return True
            if u in seen:
                return False
            seen.add(u)
            stack.add(u)
            for v in adj.get(u, ()):
                if dfs(v):
                    return True
            stack.remove(u)
            return False

        return dfs(tx.txid)

    def _tx_commit_cts(self, tx: Tx) -> int:
        # Infer commit cts from any version this tx wrote; fall back to
        # scanning chains. Genesis txs are not stored.
        for (table, pk), op in tx.writes.items():
            chain = self._tables.get(table, {}).get(pk, [])
            for ver in chain:
                if ver.xmin == tx.txid:
                    return ver.cts
            for ver in chain:
                if ver.xmax == tx.txid and ver.xmax_cts is not None:
                    return ver.xmax_cts
        return 0

    def _wait_for_cycle(self) -> bool:
        seen: set[int] = set()
        for start in list(self._wait_for):
            cur = start
            trail = set()
            while cur in self._wait_for:
                if cur in trail:
                    return True
                trail.add(cur)
                if cur in seen:
                    break
                cur = self._wait_for[cur]
            seen |= trail
        return False


# ---------------------------------------------------------------------------
# Scripted, deterministic phenomena demos
# ---------------------------------------------------------------------------

def _wallet(eng: IsolationEngine, a: int = 100, b: int = 100) -> None:
    eng.seed("wallet", 1, {"id": 1, "name": "alice", "balance": a})
    eng.seed("wallet", 2, {"id": 2, "name": "bob", "balance": b})


def demo_dirty_read() -> dict:
    """T1 writes 999 and has not committed; T2 may or may not see it."""
    out = {}
    for iso in ISOLATION_LEVELS:
        eng = IsolationEngine()
        _wallet(eng, 100, 100)
        t1 = eng.begin(iso)
        t2 = eng.begin(iso)
        eng.update(t1, "wallet", 1, {"balance": 999})
        seen = eng.select(t2, "wallet", 1)["balance"]
        eng.rollback(t1)
        after = eng.select(t2, "wallet", 1)
        # T2 at RU already observed 999; after T1 rollback, a new RU
        # read sees the committed 100. For higher levels, both reads
        # were 100. We record the uncommitted observation.
        out[iso] = {
            "uncommitted_observe": seen,
            "dirty": seen == 999,
            "after_t1_rollback": None if after is None else after["balance"],
        }
    return out


def demo_nonrepeatable_read() -> dict:
    out = {}
    for iso in ISOLATION_LEVELS:
        eng = IsolationEngine()
        _wallet(eng, 100, 100)
        t1 = eng.begin(iso)
        first = eng.select(t1, "wallet", 1)["balance"]
        t2 = eng.begin("READ COMMITTED")
        eng.update(t2, "wallet", 1, {"balance": 70})
        eng.commit(t2)
        second = eng.select(t1, "wallet", 1)["balance"]
        eng.commit(t1)
        out[iso] = {
            "first": first,
            "second": second,
            "nonrepeatable": first != second,
        }
    return out


def demo_phantom_read() -> dict:
    """Count of 'paid' orders changes when a concurrent insert commits."""
    out = {}
    for iso in ISOLATION_LEVELS:
        eng = IsolationEngine()
        eng.seed("orders", 1, {"id": 1, "status": "paid", "amount": 10})
        eng.seed("orders", 2, {"id": 2, "status": "paid", "amount": 20})
        eng.seed("orders", 3, {"id": 3, "status": "draft", "amount": 30})
        pred = lambda r: r["status"] == "paid"
        t1 = eng.begin(iso)
        first = eng.select_where(t1, "orders", pred)
        t2 = eng.begin("READ COMMITTED")
        eng.insert(t2, "orders", 4, {"id": 4, "status": "paid", "amount": 40})
        eng.commit(t2)
        second = eng.select_where(t1, "orders", pred)
        eng.commit(t1)
        out[iso] = {
            "first_count": len(first),
            "second_count": len(second),
            "first_ids": sorted(r["id"] for r in first),
            "second_ids": sorted(r["id"] for r in second),
            "phantom": len(first) != len(second),
        }
    return out


def demo_lost_update() -> dict:
    """Two sessions read 100, each subtract 30, write an absolute value."""
    out = {}
    for iso in ISOLATION_LEVELS:
        eng = IsolationEngine()
        _wallet(eng, 100, 100)
        t1 = eng.begin(iso)
        t2 = eng.begin(iso)
        a1 = eng.select(t1, "wallet", 1)["balance"]
        a2 = eng.select(t2, "wallet", 1)["balance"]
        aborted = []
        eng.update(t1, "wallet", 1, {"balance": a1 - 30})
        try:
            eng.commit(t1)
            t1_ok = True
        except SerializationFailure as e:
            t1_ok = False
            aborted.append(str(e))
        try:
            eng.update(t2, "wallet", 1, {"balance": a2 - 30})
            eng.commit(t2)
            t2_ok = True
        except SerializationFailure as e:
            t2_ok = False
            aborted.append(str(e))
        # Read the committed result with a fresh tx.
        t3 = eng.begin("READ COMMITTED")
        before_retry = eng.select(t3, "wallet", 1)["balance"]
        eng.commit(t3)
        retried = False
        retry_ok = None
        if t1_ok and not t2_ok:
            t2r = eng.begin(iso)
            try:
                a2r = eng.select(t2r, "wallet", 1)["balance"]
                eng.update(t2r, "wallet", 1, {"balance": a2r - 30})
                eng.commit(t2r)
                retried = True
                retry_ok = True
            except SerializationFailure as e:
                retried = True
                retry_ok = False
                aborted.append("retry: " + str(e))
        t4 = eng.begin("READ COMMITTED")
        final = eng.select(t4, "wallet", 1)["balance"]
        eng.commit(t4)
        silent_lost = bool(t1_ok and t2_ok and final != 40)
        out[iso] = {
            "before_retry": before_retry,
            "final": final,
            "expected": 40,
            "silent_lost_update": silent_lost,
            "t1_committed": t1_ok,
            "t2_committed": t2_ok,
            "retried_aborted_tx": retried,
            "retry_ok": retry_ok,
            "aborted": aborted,
        }
    return out


def demo_write_skew() -> dict:
    """Two on-duty editors; each reads 'two on duty' and clocks itself off.

    Invariant: at least one editor stays on duty. Snapshot isolation
    (teaching REPEATABLE READ) allows both to commit; SERIALIZABLE
    aborts the second, matching the spirit of PostgreSQL SSI.
    """
    out = {}
    for iso in ("REPEATABLE READ", "SERIALIZABLE"):
        eng = IsolationEngine()
        eng.seed("editor", 1, {"id": 1, "name": "ed_a", "on_duty": 1})
        eng.seed("editor", 2, {"id": 2, "name": "ed_b", "on_duty": 1})
        pred = lambda r: r["on_duty"] == 1
        t1 = eng.begin(iso)
        t2 = eng.begin(iso)
        c1 = eng.select_where(t1, "editor", pred)
        c2 = eng.select_where(t2, "editor", pred)
        assert len(c1) == 2 and len(c2) == 2
        aborted = None
        eng.update(t1, "editor", 1, {"on_duty": 0})
        eng.commit(t1)
        t2_ok = True
        try:
            eng.update(t2, "editor", 2, {"on_duty": 0})
            eng.commit(t2)
        except SerializationFailure as e:
            t2_ok = False
            aborted = str(e)
        t3 = eng.begin("READ COMMITTED")
        remaining = eng.select_where(t3, "editor", pred)
        eng.commit(t3)
        out[iso] = {
            "initial_on_duty": 2,
            "final_on_duty": len(remaining),
            "final_ids": sorted(r["id"] for r in remaining),
            "t2_committed": t2_ok,
            "write_skew": len(remaining) == 0,
            "aborted": aborted,
        }
    return out


def demo_deadlock_and_retry() -> dict:
    """Lock-order cycle: T1 locks A then B, T2 locks B then A.

    Naive: after T2 is aborted mid-transfer (A already 'applied' in a
    confused client that does not roll back), retry only the credit to
    B. Result: B is credited twice or the total drifts.

    Safe: roll the whole transaction back and retry it from the start.
    """
    # --- Naive: apply debit as if autocommitted, then deadlock on the
    # opposite lock, then retry only the credit. We model "already
    # applied debit" with a committed one-row update, then a second
    # attempt that only credits B (duplicate credit).
    eng_n = IsolationEngine()
    _wallet(eng_n, 100, 100)
    # First leg: debit Alice in its own committed tx (naive autocommit).
    t_debit = eng_n.begin("READ COMMITTED")
    a = eng_n.select(t_debit, "wallet", 1)
    eng_n.update(t_debit, "wallet", 1, {"balance": a["balance"] - 30})
    eng_n.commit(t_debit)
    # Opposite-order lock cycle on a second transfer attempt (teaching
    # lock manager). T1 holds Alice, T2 holds Bob, each waits for the
    # other.
    t1 = eng_n.begin("READ COMMITTED")
    t2 = eng_n.begin("READ COMMITTED")
    eng_n.acquire_lock(t1, "wallet", 1)
    eng_n.acquire_lock(t2, "wallet", 2)
    deadlock_caught = False
    waited = eng_n.acquire_lock(t2, "wallet", 1)  # T2 waits for T1 (not a cycle yet)
    if waited is not False:
        raise RuntimeError("expected T2 to wait on Alice")
    try:
        # T2 is waiting; T1 now tries to lock Bob (held by T2) -> cycle.
        eng_n.acquire_lock(t1, "wallet", 2)
    except Deadlock:
        deadlock_caught = True
    # Naive client: T2 failed after some peer already credited? We
    # follow the brief: debit of A is done, credit of B failed, retry
    # only the credit. To exhibit *duplicate* credit we also model the
    # case where the credit had actually landed before the client saw
    # a failure (timeout / lost response), then the retry credits again.
    # Here: perform the credit once (as if it landed), raise a failure
    # to the client, retry the credit.
    t_credit1 = eng_n.begin("READ COMMITTED")
    b = eng_n.select(t_credit1, "wallet", 2)
    eng_n.update(t_credit1, "wallet", 2, {"balance": b["balance"] + 30})
    eng_n.commit(t_credit1)
    # Client saw a failure and retries only the credit.
    t_credit2 = eng_n.begin("READ COMMITTED")
    b = eng_n.select(t_credit2, "wallet", 2)
    eng_n.update(t_credit2, "wallet", 2, {"balance": b["balance"] + 30})
    eng_n.commit(t_credit2)
    t_end = eng_n.begin("READ COMMITTED")
    naive_a = eng_n.select(t_end, "wallet", 1)["balance"]
    naive_b = eng_n.select(t_end, "wallet", 2)["balance"]
    eng_n.commit(t_end)

    # --- Safe: one transaction, injected SerializationFailure before
    # commit, full rollback, retry the whole transfer.
    eng_s = IsolationEngine()
    _wallet(eng_s, 100, 100)

    def safe_transfer(eng: IsolationEngine, amount: int, fail: bool) -> None:
        tx = eng.begin("SERIALIZABLE")
        try:
            a = eng.select(tx, "wallet", 1)
            b = eng.select(tx, "wallet", 2)
            if a["balance"] < amount:
                eng.rollback(tx)
                raise RuntimeError("insufficient funds")
            eng.update(tx, "wallet", 1, {"balance": a["balance"] - amount})
            eng.update(tx, "wallet", 2, {"balance": b["balance"] + amount})
            if fail:
                eng.rollback(tx)
                raise SerializationFailure("injected serialization failure")
            eng.commit(tx)
        except SerializationFailure:
            if tx.status == "active":
                eng.rollback(tx)
            raise

    retries = 0
    attempts = 0
    while True:
        attempts += 1
        try:
            safe_transfer(eng_s, 30, fail=(attempts == 1))
            break
        except SerializationFailure:
            retries += 1
            if retries > 5:
                raise
    t_end = eng_s.begin("READ COMMITTED")
    safe_a = eng_s.select(t_end, "wallet", 1)["balance"]
    safe_b = eng_s.select(t_end, "wallet", 2)["balance"]
    eng_s.commit(t_end)
    return {
        "deadlock_caught": deadlock_caught,
        "initial_a": 100,
        "initial_b": 100,
        "amount": 30,
        "expected_a": 70,
        "expected_b": 130,
        "expected_total": 200,
        "naive_a": naive_a,
        "naive_b": naive_b,
        "naive_total": naive_a + naive_b,
        "naive_duplicate_credit": naive_b == 160,
        "safe_a": safe_a,
        "safe_b": safe_b,
        "safe_total": safe_a + safe_b,
        "safe_retries": retries,
        "safe_attempts": attempts,
    }


def run_isolation_experiments() -> dict:
    dirty = demo_dirty_read()
    nonrep = demo_nonrepeatable_read()
    phantom = demo_phantom_read()
    lost = demo_lost_update()
    skew = demo_write_skew()
    retry = demo_deadlock_and_retry()
    return {
        "model": "teaching IsolationEngine (not PostgreSQL/InnoDB/SQLite)",
        "dirty_read": dirty,
        "nonrepeatable_read": nonrep,
        "phantom_read": phantom,
        "lost_update": lost,
        "write_skew": skew,
        "retry": retry,
        "pg_table_13_1_checked": "2026-11-11",
        "pg_doc": "https://www.postgresql.org/docs/current/transaction-iso.html",
        "pg_doc_edition": "PostgreSQL 18",
    }


if __name__ == "__main__":
    import json

    print(json.dumps(run_isolation_experiments(), ensure_ascii=False, indent=2))
