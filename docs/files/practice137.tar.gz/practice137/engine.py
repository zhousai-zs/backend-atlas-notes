#!/usr/bin/env python3
"""Teaching CacheEngine — not Redis, not a real profiler/cache product,
not a network service, and not a host perf c2c / cachegrind / g++ /
CPU-counter run.

A Python 3 standard-library, virtual-clock model of adjacent versus
isolated atomic counters (and head/tail queue metadata) on a teaching
KV. The named source (checked on 2026-11-14) is:

* Linux Kernel — False Sharing, at
  https://www.kernel.org/doc/html/latest/kernel-hacking/false-sharing.html
  (kernel docs 7.4.0-rc2). False sharing is related to "cache
  mechanism of maintaining the data coherence of one cache line
  stored in multiple CPU's caches." A frequently written field and
  a never-written field that share a line force other CPUs to
  "reload the whole cache line over and over." Harmful cases have
  a datum shared by many CPUs and at least one writer
  (write/write or write/read). The page says a cache line is
  "usually 64 bytes or more" — not a universal constant. Detection
  uses perf record/report/stat, then perf-c2c and pahole; the
  sample perf-c2c output includes Load Local HITM and Load Remote
  HITM plus the in-line offset of the data. Mitigations should
  "balance performance gains with complexity and space
  consumption"; putting hot data on its own line consumes more
  memory, cache lines and TLB entries.

The page does not expand the acronym HITM. It names a perf-c2c
introduction [3], https://joemario.github.io/blog/2016/09/01/c2c-blog/
(Joe Mario, 2016-09-01): "HITM" stands for "a load that hit in a
modified cacheline." Local HITM is on the same NUMA node; remote
HITM is across nodes and is the most expensive. HITM alone does
not tell true sharing from false sharing; the kernel page's
perf-c2c sample and pahole advice use the data offset for that.

This engine does not invoke host perf, perf c2c, pahole, g++, or
cachegrind, and does not read CPU performance counters. Line size
in the results is the smallest power-of-two padding in a teaching
sweep that eliminates HITM, not a value copied from host sysfs or
assumed to be 64 before the sweep. Times are teaching
virtual-clock values, not production RTT.
"""
from __future__ import annotations

from typing import Any


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"

MEASURE_S = 30.00
MEASURE_NS = 30_000_000_000
COUNTER_BYTES = 8
# Teaching increment costs. Not host counter cycles and not the
# sample HITM counts in the kernel document or the c2c blog.
UNCONTENDED_NS = 5
HITM_NS = 50
# Hidden teaching-machine line size. Results report the value
# measured by the padding sweep, not this constant as a premise.
_TEACHING_LINE = 64
SWEEP_PADDINGS = (8, 16, 32, 64, 128)
N_THREADS_MAIN = 2
N_THREADS_WIDE = 8
N_HOT = 8
N_COLD = 8
HOST_UNAME_R = "6.12.113+"
HOST_L1D_LINE = 64  # getconf/sysfs on this box; not a result source


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def increments_for(cost_ns: int, n_threads: int) -> dict[str, Any]:
    per = MEASURE_NS // cost_ns
    agg = per * n_threads
    return {
        "n_threads": n_threads,
        "cost_ns": cost_ns,
        "per_thread_increments": per,
        "aggregate_increments": agg,
        "per_thread_rps": ts(per / MEASURE_S, 2),
        "aggregate_rps": ts(agg / MEASURE_S, 2),
        "measure_s": MEASURE_S,
        "times_are_teaching_virtual_clock": True,
    }


def c2c_report(
    *,
    line_addrs: list[int],
    offsets: list[int],
    n_hitm: int,
    labels: list[str],
) -> dict[str, Any]:
    n_lines = len(set(line_addrs))
    return {
        "load_local_hitm": n_hitm,
        "load_remote_hitm": 0,
        "n_cache_lines": n_lines,
        "entries": [
            {
                "cacheline": hex(line_addrs[i]),
                "offset": hex(offsets[i]),
                "symbol": labels[i],
            }
            for i in range(len(labels))
        ],
        "same_line_different_offsets": (
            n_lines == 1 and len(set(offsets)) > 1 and n_hitm > 0
        ),
        "same_line_same_offset": (
            n_lines == 1 and len(set(offsets)) == 1 and n_hitm > 0
        ),
        "kind": (
            "false_sharing"
            if (n_lines == 1 and len(set(offsets)) > 1 and n_hitm > 0)
            else "true_sharing"
            if (n_lines == 1 and len(set(offsets)) == 1 and n_hitm > 0)
            else "no_sharing_hitm"
        ),
        "not_host_perf_c2c": True,
    }


def _fits_same_line(padding: int, line: int = _TEACHING_LINE) -> bool:
    # two COUNTER_BYTES fields with `padding` bytes between them
    return COUNTER_BYTES + padding + COUNTER_BYTES <= line


class CacheEngine:
    """Teaching model of false sharing, HITM, and padding cost."""

    def _pair(self, name: str, padding: int, *, same_counter: bool) -> dict[str, Any]:
        false_or_true = same_counter or _fits_same_line(padding)
        cost = HITM_NS if false_or_true else UNCONTENDED_NS
        stats = increments_for(cost, N_THREADS_MAIN)
        n_hitm = stats["aggregate_increments"] if cost == HITM_NS else 0
        if same_counter:
            addrs, offs, labels = [0x1000, 0x1000], [0x0, 0x0], [
                "counters[0]@cpu0",
                "counters[0]@cpu1",
            ]
        elif _fits_same_line(padding):
            addrs = [0x1000, 0x1000]
            offs = [0x0, COUNTER_BYTES + padding]
            labels = ["counters[0]@cpu0", "counters[1]@cpu1"]
        else:
            addrs = [0x1000, 0x2000]
            offs = [0x0, 0x0]
            labels = ["counters[0]@cpu0", "counters[1]@cpu1"]
        return {
            "name": name,
            "padding_bytes": padding,
            "counter_bytes": COUNTER_BYTES,
            "layout_bytes": (
                COUNTER_BYTES if same_counter else COUNTER_BYTES + padding + COUNTER_BYTES
            ),
            "same_counter": same_counter,
            "cpus": [0, 1],
            **stats,
            "c2c": c2c_report(
                line_addrs=addrs, offsets=offs, n_hitm=n_hitm, labels=labels
            ),
        }

    def _wide(self, name: str, isolated: bool) -> dict[str, Any]:
        n = N_THREADS_WIDE
        cost = UNCONTENDED_NS if isolated else HITM_NS
        stats = increments_for(cost, n)
        n_hitm = 0 if isolated else stats["aggregate_increments"]
        bytes_ = n * (_TEACHING_LINE if isolated else COUNTER_BYTES)
        lines = n if isolated else 1
        return {
            "name": name,
            "isolated": isolated,
            "cpus": list(range(n)),
            "layout_bytes": bytes_,
            "layout_lines": lines,
            **stats,
            "c2c": {
                "load_local_hitm": n_hitm,
                "load_remote_hitm": 0,
                "n_cache_lines": lines,
                "kind": "no_sharing_hitm" if isolated else "false_sharing",
                "not_host_perf_c2c": True,
            },
        }

    def compare(self) -> dict[str, Any]:
        adjacent = self._pair("adjacent_atomics", padding=0, same_counter=False)
        isolated = self._pair("isolated_atomics", padding=_TEACHING_LINE, same_counter=False)
        true_share = self._pair("true_sharing", padding=0, same_counter=True)
        queue_adj = self._pair("queue_head_tail_adjacent", padding=0, same_counter=False)
        queue_adj = {**queue_adj, "name": "queue_head_tail_adjacent"}
        queue_adj["c2c"] = c2c_report(
            line_addrs=[0x3000, 0x3000],
            offsets=[0x0, 0x8],
            n_hitm=queue_adj["aggregate_increments"],
            labels=["queue.tail@producer", "queue.head@consumer"],
        )
        queue_iso = self._pair("queue_head_tail_isolated", padding=_TEACHING_LINE, same_counter=False)
        queue_iso = {**queue_iso, "name": "queue_head_tail_isolated"}
        queue_iso["c2c"] = c2c_report(
            line_addrs=[0x3000, 0x4000],
            offsets=[0x0, 0x0],
            n_hitm=0,
            labels=["queue.tail@producer", "queue.head@consumer"],
        )

        sweep = []
        measured = None
        for pad in SWEEP_PADDINGS:
            run = self._pair(f"sweep_pad_{pad}", padding=pad, same_counter=False)
            hitm = run["c2c"]["load_local_hitm"]
            row = {
                "padding_bytes": pad,
                "same_line": _fits_same_line(pad),
                "load_local_hitm": hitm,
                "aggregate_rps": run["aggregate_rps"],
            }
            sweep.append(row)
            if measured is None and hitm == 0:
                measured = pad
        if measured is None:
            raise RuntimeError("teaching sweep did not eliminate HITM")

        packed_hot = N_HOT * COUNTER_BYTES  # 64, 1 line
        isolated_hot = N_HOT * measured  # 512, 8 lines
        packed_all = (N_HOT + N_COLD) * COUNTER_BYTES  # 128, 2 lines
        pad_hot_only = isolated_hot + measured  # 576, 9 lines (cold packed in 1 line)
        pad_all = (N_HOT + N_COLD) * measured  # 1024, 16 lines
        wide_adj = self._wide("eight_adjacent", isolated=False)
        wide_iso = self._wide("eight_isolated", isolated=True)

        return {
            "process": PROCESS,
            "key": KEY_TITLE,
            "title": TITLE_V1,
            "measure_s": MEASURE_S,
            "uncontended_ns": UNCONTENDED_NS,
            "hitm_ns": HITM_NS,
            "host": {
                "uname_r": HOST_UNAME_R,
                "l1d_line_size": HOST_L1D_LINE,
                "l1d_line_size_is_host_fact_not_result": True,
                "host_perf_invoked": False,
                "host_perf_c2c_invoked": False,
                "host_pahole_invoked": False,
                "host_gxx_invoked": False,
                "host_cachegrind_invoked": False,
            },
            "adjacent_atomics": adjacent,
            "isolated_atomics": isolated,
            "true_sharing": true_share,
            "queue_head_tail_adjacent": queue_adj,
            "queue_head_tail_isolated": queue_iso,
            "padding_sweep": sweep,
            "measured_line_bytes": measured,
            "measured_by": (
                "smallest padding in the power-of-two sweep that eliminated HITM"
            ),
            "line_size_was_not_assumed_before_sweep": True,
            "eight_adjacent": wide_adj,
            "eight_isolated": wide_iso,
            "working_set": {
                "packed_hot_8_bytes": packed_hot,
                "packed_hot_8_lines": packed_hot // measured,
                "isolated_hot_8_bytes": isolated_hot,
                "isolated_hot_8_lines": isolated_hot // measured,
                "isolated_vs_packed_hot_factor": share(isolated_hot, packed_hot),
                "packed_all_16_bytes": packed_all,
                "packed_all_16_lines": packed_all // measured,
                "pad_hot_only_bytes": pad_hot_only,
                "pad_hot_only_lines": pad_hot_only // measured,
                "pad_all_fields_bytes": pad_all,
                "pad_all_fields_lines": pad_all // measured,
                "pad_all_vs_packed_all_factor": share(pad_all, packed_all),
                "pad_all_vs_pad_hot_only_factor": share(pad_all, pad_hot_only),
            },
            "distinguishes_true_and_false_sharing": (
                adjacent["c2c"]["kind"] == "false_sharing"
                and true_share["c2c"]["kind"] == "true_sharing"
                and adjacent["aggregate_rps"] == true_share["aggregate_rps"]
                and adjacent["c2c"]["entries"][0]["offset"]
                != adjacent["c2c"]["entries"][1]["offset"]
                and true_share["c2c"]["entries"][0]["offset"]
                == true_share["c2c"]["entries"][1]["offset"]
            ),
            "measured_line_not_assumed": measured == 64,
            "isolated_beats_adjacent": (
                isolated["aggregate_rps"] > adjacent["aggregate_rps"]
                and isolated["c2c"]["load_local_hitm"] == 0
                and adjacent["c2c"]["load_local_hitm"] > 0
            ),
            "pad_every_field_blows_working_set": (
                pad_all > pad_hot_only and pad_all > packed_all
            ),
            "isolation_reduces_hitm_increases_occupancy": (
                wide_iso["c2c"]["load_local_hitm"] == 0
                and wide_adj["c2c"]["load_local_hitm"] > 0
                and isolated_hot > packed_hot
            ),
        }
