#!/usr/bin/env python3
"""Run the lesson 137 teaching cache / false-sharing experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1, CacheEngine


def run() -> dict[str, Any]:
    eng = CacheEngine()
    cmp = eng.compare()
    return {
        "engine": "CacheEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "measure_s": MEASURE_S,
        "uncontended_ns": cmp["uncontended_ns"],
        "hitm_ns": cmp["hitm_ns"],
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_cache_product": True,
        "not_host_perf": True,
        "not_host_perf_c2c": True,
        "not_host_pahole": True,
        "not_host_gxx": True,
        "not_host_cachegrind": True,
        "times_are_teaching_virtual_clock": True,
        "host": cmp["host"],
        "adjacent_atomics": cmp["adjacent_atomics"],
        "isolated_atomics": cmp["isolated_atomics"],
        "true_sharing": cmp["true_sharing"],
        "queue_head_tail_adjacent": cmp["queue_head_tail_adjacent"],
        "queue_head_tail_isolated": cmp["queue_head_tail_isolated"],
        "padding_sweep": cmp["padding_sweep"],
        "measured_line_bytes": cmp["measured_line_bytes"],
        "measured_by": cmp["measured_by"],
        "line_size_was_not_assumed_before_sweep": cmp["line_size_was_not_assumed_before_sweep"],
        "eight_adjacent": cmp["eight_adjacent"],
        "eight_isolated": cmp["eight_isolated"],
        "working_set": cmp["working_set"],
        "flags": {
            "distinguishes_true_and_false_sharing": cmp["distinguishes_true_and_false_sharing"],
            "measured_line_not_assumed": cmp["measured_line_not_assumed"],
            "isolated_beats_adjacent": cmp["isolated_beats_adjacent"],
            "pad_every_field_blows_working_set": cmp["pad_every_field_blows_working_set"],
            "isolation_reduces_hitm_increases_occupancy": cmp["isolation_reduces_hitm_increases_occupancy"],
        },
        "acceptance_distinguishes_true_and_false_sharing": cmp["distinguishes_true_and_false_sharing"],
        "acceptance_measured_line_not_assumed": cmp["measured_line_not_assumed"],
        "pitfall_pad_every_field": cmp["pad_every_field_blows_working_set"],
        "tradeoff_isolation_vs_occupancy": cmp["isolation_reduces_hitm_increases_occupancy"],
    }


if __name__ == "__main__":
    run()
