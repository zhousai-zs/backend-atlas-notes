#!/usr/bin/env python3
"""Acceptance checks for the lesson 137 teaching cache experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "CacheEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["uncontended_ns"] == 5 and r["hitm_ns"] == 50
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_cache_product"]
    assert r["not_host_perf"] and r["not_host_perf_c2c"] and r["not_host_pahole"]
    assert r["not_host_gxx"] and r["not_host_cachegrind"]
    assert r["times_are_teaching_virtual_clock"]
    assert r["host"]["uname_r"] == "6.12.113+"
    assert r["host"]["l1d_line_size"] == 64
    assert r["host"]["l1d_line_size_is_host_fact_not_result"] is True
    assert r["host"]["host_perf_c2c_invoked"] is False
    assert r["host"]["host_gxx_invoked"] is False

    adj, iso, tru = r["adjacent_atomics"], r["isolated_atomics"], r["true_sharing"]
    assert adj["aggregate_rps"] == 40_000_000.0
    assert adj["aggregate_increments"] == 1_200_000_000
    assert adj["c2c"]["load_local_hitm"] == 1_200_000_000
    assert adj["c2c"]["load_remote_hitm"] == 0
    assert adj["c2c"]["kind"] == "false_sharing"
    assert adj["c2c"]["entries"][0]["offset"] == "0x0"
    assert adj["c2c"]["entries"][1]["offset"] == "0x8"
    assert iso["aggregate_rps"] == 400_000_000.0
    assert iso["c2c"]["load_local_hitm"] == 0
    assert iso["c2c"]["kind"] == "no_sharing_hitm"
    assert iso["padding_bytes"] == 64
    assert tru["aggregate_rps"] == adj["aggregate_rps"]
    assert tru["c2c"]["kind"] == "true_sharing"
    assert tru["c2c"]["entries"][0]["offset"] == tru["c2c"]["entries"][1]["offset"] == "0x0"
    assert r["acceptance_distinguishes_true_and_false_sharing"]
    assert iso["aggregate_rps"] > adj["aggregate_rps"]

    qadj, qiso = r["queue_head_tail_adjacent"], r["queue_head_tail_isolated"]
    assert qadj["aggregate_rps"] == 40_000_000.0
    assert qadj["c2c"]["kind"] == "false_sharing"
    assert qiso["aggregate_rps"] == 400_000_000.0
    assert qiso["c2c"]["load_local_hitm"] == 0

    sweep = {row["padding_bytes"]: row for row in r["padding_sweep"]}
    assert sweep[8]["same_line"] and sweep[16]["same_line"] and sweep[32]["same_line"]
    assert not sweep[64]["same_line"] and not sweep[128]["same_line"]
    assert sweep[32]["load_local_hitm"] == 1_200_000_000
    assert sweep[64]["load_local_hitm"] == 0
    assert r["measured_line_bytes"] == 64
    assert r["line_size_was_not_assumed_before_sweep"]
    assert r["acceptance_measured_line_not_assumed"]

    eight_a, eight_i = r["eight_adjacent"], r["eight_isolated"]
    assert eight_a["aggregate_rps"] == 160_000_000.0
    assert eight_a["c2c"]["load_local_hitm"] == 4_800_000_000
    assert eight_i["aggregate_rps"] == 1_600_000_000.0
    assert eight_i["c2c"]["load_local_hitm"] == 0

    ws = r["working_set"]
    assert ws["packed_hot_8_bytes"] == 64 and ws["isolated_hot_8_bytes"] == 512
    assert ws["isolated_vs_packed_hot_factor"] == 8.0
    assert ws["pad_hot_only_bytes"] == 576 and ws["pad_all_fields_bytes"] == 1024
    assert ws["pad_all_fields_lines"] == 16
    assert ws["pad_all_vs_packed_all_factor"] == 8.0
    assert ws["pad_all_vs_pad_hot_only_factor"] == 1.7778
    assert r["pitfall_pad_every_field"]
    assert r["tradeoff_isolation_vs_occupancy"]

    flags = r["flags"]
    assert flags["distinguishes_true_and_false_sharing"]
    assert flags["measured_line_not_assumed"]
    assert flags["isolated_beats_adjacent"]
    assert flags["pad_every_field_blows_working_set"]
    assert flags["isolation_reduces_hitm_increases_occupancy"]


if __name__ == "__main__":
    main()
