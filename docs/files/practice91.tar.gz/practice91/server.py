#!/usr/bin/env python3
"""practice91 流式发送服务端：对比有界缓冲+控制面优先（bounded）与无界 FIFO（unbounded）。
协议：客户端发 "STREAM <n>\n" 开始；之后可随时发 "CANCEL\n"。服务端每条消息 1KB："<seq> <padding>\n"。
结束时把统计 JSON 打印到 stdout。"""
import argparse, asyncio, json, socket, sys, time

MSG = 1024
HIGH, LOW = 64 * 1024, 16 * 1024      # 传输层写缓冲高/低水位
QUEUE_MAX = 64                         # 应用队列上限（条）

def msg(seq):
    head = f"{seq} ".encode()
    return head + b"x" * (MSG - len(head) - 1) + b"\n"

async def handle(reader, writer, args, done):
    sock = writer.get_extra_info("socket")
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 32 * 1024)   # 让内核缓冲小一点，现象更明显
    writer.transport.set_write_buffer_limits(high=HIGH, low=LOW)
    st = dict(mode=args.mode, produced=0, written=0, peak_queue_items=0,
              peak_buffered_bytes=0, cancel_latency_ms=None, finished="eof")
    line = (await reader.readline()).decode().split()
    n = int(line[1])
    cancel = asyncio.Event(); cancel_at = [None]
    q = asyncio.Queue(maxsize=QUEUE_MAX if args.mode == "bounded" else 0)

    def track():
        buffered = q.qsize() * MSG + writer.transport.get_write_buffer_size()
        st["peak_queue_items"] = max(st["peak_queue_items"], q.qsize())
        st["peak_buffered_bytes"] = max(st["peak_buffered_bytes"], buffered)

    async def control():                       # 控制面：独立读循环，不排在数据后面
        while True:
            l = await reader.readline()
            if not l: return
            if l.strip() == b"CANCEL":
                cancel_at[0] = time.monotonic()
                if args.mode == "bounded":
                    cancel.set()               # 立即生效
                else:
                    await q.put(("CANCEL", None))  # 错误示范：控制消息和数据挤同一个 FIFO

    async def producer():
        for seq in range(n):
            if cancel.is_set(): break
            await q.put(("DATA", msg(seq)))    # bounded: 队列满时在这里被挂起 = 背压传到生产者
            st["produced"] += 1; track()
            if seq % 64 == 0: await asyncio.sleep(0)
        await q.put(("EOF", None))

    async def sender():
        while True:
            if cancel.is_set(): st["finished"] = "cancelled"; break
            kind, data = await q.get()
            if kind == "EOF": break
            if kind == "CANCEL": cancel.set(); st["finished"] = "cancelled"; break
            writer.write(data); st["written"] += 1; track()   # write() 返回 != 对端已收到
            if args.mode == "bounded":
                await writer.drain()           # 超过高水位就等，降到低水位再继续
        if cancel_at[0]:
            st["cancel_latency_ms"] = round((time.monotonic() - cancel_at[0]) * 1000, 1)

    ctl = asyncio.create_task(control())
    prod = asyncio.create_task(producer())
    await sender()
    prod.cancel(); ctl.cancel()
    try:
        writer.close(); await asyncio.wait_for(writer.wait_closed(), 2)
    except Exception: pass
    print(json.dumps(st), flush=True)
    done.set()

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--mode", choices=["bounded", "unbounded"], default="bounded")
    args = ap.parse_args()
    done = asyncio.Event()
    try:
        srv = await asyncio.start_server(lambda r, w: handle(r, w, args, done), "127.0.0.1", args.port)
    except OSError as e:
        print(f"bind failed: {e}", file=sys.stderr); sys.exit(2)
    async with srv:
        await done.wait()

asyncio.run(main())
