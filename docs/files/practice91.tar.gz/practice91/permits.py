#!/usr/bin/env python3
"""并发许可 + 排队超时：40 个请求同时到达，下游每次 200ms（第 7 个请求下游抛异常）。
--limit 0 表示不限并发（错误示范）。"""
import argparse, asyncio, json, time
ap = argparse.ArgumentParser()
ap.add_argument("--limit", type=int, default=4)
ap.add_argument("--queue-timeout", type=float, default=0.3)
ap.add_argument("--deadline", type=float, default=1.0)
a = ap.parse_args()
inflight = peak = 0
stats = dict(ok=0, rejected=0, failed=0, max_reject_wait_ms=0.0)

async def downstream(i):
    global inflight, peak
    inflight += 1; peak = max(peak, inflight)
    try:
        await asyncio.sleep(0.2)
        if i == 7: raise RuntimeError("downstream error")
    finally:
        inflight -= 1

async def handle(i, sem):
    t0 = time.monotonic(); deadline = t0 + a.deadline
    if sem is None:
        try: await downstream(i); stats["ok"] += 1
        except RuntimeError: stats["failed"] += 1
        return
    # 等许可的时间 = min(排队超时, 剩余截止时间)
    wait = min(a.queue_timeout, deadline - time.monotonic())
    try:
        await asyncio.wait_for(sem.acquire(), wait)
    except asyncio.TimeoutError:
        stats["rejected"] += 1      # 快速失败：RESOURCE_EXHAUSTED / 503
        stats["max_reject_wait_ms"] = max(stats["max_reject_wait_ms"], round((time.monotonic()-t0)*1000, 1))
        return
    try:
        await downstream(i); stats["ok"] += 1
    except RuntimeError:
        stats["failed"] += 1
    finally:
        sem.release()               # 异常路径也必须归还许可

async def main():
    sem = asyncio.Semaphore(a.limit) if a.limit > 0 else None
    await asyncio.gather(*(handle(i, sem) for i in range(40)))
    stats.update(limit=a.limit, peak_inflight=peak,
                 permits_left=(sem._value if sem else None))
    print(json.dumps(stats))
asyncio.run(main())
