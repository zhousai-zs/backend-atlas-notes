#!/usr/bin/env bash
# practice91：慢消费者下验证有界缓冲/水位、控制面优先取消、并发许可与排队超时
set -u
cd "$(dirname "$0")"
PY=python3
run_stream() {  # $1=mode $2=port
  $PY server.py --mode $1 --port $2 > srv_$1.json 2> srv_$1.err & local sp=$!
  sleep 0.5
  local peak=0
  $PY client.py --port $2 > cli_$1.json & local cp=$!
  while kill -0 $cp 2>/dev/null; do
    r=$(ps -o rss= -p $sp 2>/dev/null | tr -d ' '); [ -n "$r" ] && [ "$r" -gt "$peak" ] && peak=$r
    sleep 0.05
  done
  sleep 0.5; kill $sp 2>/dev/null; wait $sp 2>/dev/null
  echo $peak > rss_$1.txt
  echo "$1: server=$(cat srv_$1.json) client=$(cat cli_$1.json) peak_rss_kb=$peak"
}
run_stream bounded 18191
run_stream unbounded 18192
$PY permits.py --limit 4 > permits.json;   echo "permits: $(cat permits.json)"
$PY permits.py --limit 0 > nolimit.json;   echo "nolimit: $(cat nolimit.json)"
$PY server.py --port 18193 > /dev/null 2>&1 & HP=$!; sleep 0.4
$PY server.py --port 18193 > /dev/null 2> dup.err; rc=$?; kill $HP 2>/dev/null
$PY - "$rc" <<'PYEOF'
import json, sys
L = lambda f: json.load(open(f)) if open(f).read().strip() else {}
sb, cb = L("srv_bounded.json"), L("cli_bounded.json")
su, cu = L("srv_unbounded.json"), L("cli_unbounded.json")
rb, ru = int(open("rss_bounded.txt").read()), int(open("rss_unbounded.txt").read())
p, nl = L("permits.json"), L("nolimit.json"); rc = int(sys.argv[1]); ok = True
def check(c, m):
    global ok; print(("PASS " if c else "FAIL ") + m); ok &= bool(c)
check(sb.get("peak_buffered_bytes", 1e9) <= 64*1024 + 64*1024 + 4096,
      f"bounded 应用队列+写缓冲峰值 {sb.get('peak_buffered_bytes')}B 有上界(≤~132KB)")
check(su.get("peak_buffered_bytes", 0) > 4 * 1024 * 1024,
      f"unbounded 峰值缓冲 {su.get('peak_buffered_bytes')}B 远超上界(>4MB)")
check(ru > rb + 5000, f"unbounded 峰值 RSS {ru}KB 明显高于 bounded {rb}KB")
check(sb.get("produced", 0) < 50000, f"bounded 生产者被背压挂起，只生产了 {sb.get('produced')} 条")
check(su.get("written", 0) > cu.get("received", 0) * 3,
      f"write() 返回 {su.get('written')} 次 ≫ 客户端实际收到 {cu.get('received')} 条")
check(sb.get("finished") == "cancelled" and (sb.get("cancel_latency_ms") or 1e9) < 500,
      f"bounded 取消 {sb.get('cancel_latency_ms')}ms 内生效（控制面不被饿死）")
check(cb.get("stream_closed_after_cancel") is True, "bounded 客户端在取消后很快看到流结束")
check(cu.get("stream_closed_after_cancel") is False, "unbounded：取消后 3s 内流仍未结束（已 write 的积压仍在排队发送，取消被饿死）")
check(p.get("peak_inflight") == 4, f"许可=4 时在途峰值 {p.get('peak_inflight')}")
check(p.get("rejected", 0) > 0 and p.get("max_reject_wait_ms", 1e9) <= 350,
      f"排队超时快速拒绝 {p.get('rejected')} 个，最长等待 {p.get('max_reject_wait_ms')}ms")
check(p.get("permits_left") == 4, "下游抛异常后许可全部归还（无泄漏）")
check(nl.get("peak_inflight") == 40, f"不限并发时在途峰值 {nl.get('peak_inflight')}")
check(rc == 2, f"端口占用时 rc=2 (rc={rc})")
sys.exit(0 if ok else 1)
PYEOF
[ $? -eq 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
