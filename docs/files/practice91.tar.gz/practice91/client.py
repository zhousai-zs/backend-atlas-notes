#!/usr/bin/env python3
"""慢消费者：每条消息处理 2ms，读 --cancel-after 秒后发 CANCEL，看取消多快生效。"""
import argparse, json, socket, time
ap = argparse.ArgumentParser()
ap.add_argument("--port", type=int, required=True)
ap.add_argument("--n", type=int, default=50000)
ap.add_argument("--cancel-after", type=float, default=1.5)
ap.add_argument("--wait", type=float, default=3.0, help="发 CANCEL 后最多再读多久")
a = ap.parse_args()
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 16 * 1024)
s.connect(("127.0.0.1", a.port)); s.sendall(f"STREAM {a.n}\n".encode())
f = s.makefile("rb"); s.settimeout(0.5)
got, t0, cancel_t, after = 0, time.monotonic(), None, 0
while True:
    now = time.monotonic()
    if cancel_t is None and now - t0 >= a.cancel_after:
        s.sendall(b"CANCEL\n"); cancel_t = now; got_at_cancel = got
    if cancel_t and now - cancel_t > a.wait: break
    try:
        line = f.readline()
    except (socket.timeout, TimeoutError):
        continue
    if not line: break
    got += 1
    if cancel_t: after += 1
    time.sleep(0.002)                      # 慢消费者
eof = bool(cancel_t) and time.monotonic() - cancel_t <= a.wait
print(json.dumps(dict(received=got, received_at_cancel=got_at_cancel,
                      received_after_cancel=after, stream_closed_after_cancel=eof)))
