#!/usr/bin/env python3
"""慢读客户端：每次只 recv 很少字节并 sleep，制造服务端 send EAGAIN。"""
import argparse
import socket
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18052)
    ap.add_argument("--size", type=int, default=20000, help="发送总字节数")
    ap.add_argument("--recv-size", type=int, default=32, help="每次 recv 上限")
    ap.add_argument("--delay", type=float, default=0.02, help="每次 recv 后休眠秒")
    ap.add_argument("--timeout", type=float, default=60.0)
    args = ap.parse_args()

    payload = (b"SLOW" * ((args.size + 3) // 4))[: args.size]
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # 缩小接收窗口，更容易让对端 send 缓冲填满（尽力而为）
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 2048)
    except OSError:
        pass
    s.settimeout(args.timeout)
    try:
        s.connect((args.host, args.port))
        s.sendall(payload)
        s.shutdown(socket.SHUT_WR)
        got = bytearray()
        while len(got) < len(payload):
            chunk = s.recv(args.recv_size)
            if not chunk:
                break
            got.extend(chunk)
            if args.delay > 0:
                time.sleep(args.delay)
        ok = bytes(got) == payload
        print(
            f"SLOW_RESULT ok={ok} sent={len(payload)} got_len={len(got)} "
            f"recv_size={args.recv_size} delay={args.delay}"
        )
        if not ok:
            # 检查是否有重复/丢失痕迹：长度或前缀
            if len(got) != len(payload):
                print(f"len_mismatch expect={len(payload)} got={len(got)}", file=sys.stderr)
            else:
                for i, (a, b) in enumerate(zip(got, payload)):
                    if a != b:
                        print(f"byte_mismatch at {i}", file=sys.stderr)
                        break
            sys.exit(1)
    except Exception as e:
        print(f"SLOW_RESULT fail {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        s.close()


if __name__ == "__main__":
    main()
