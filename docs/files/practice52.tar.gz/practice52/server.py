#!/usr/bin/env python3
"""非阻塞 Echo：限单次 send 大小 + 输出缓冲状态机（Backend Atlas 第52课 d-nonblock）。"""
import errno
import select
import socket
import sys
import time

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18052
# 故意限制单次 send，逼出短写 + 输出缓冲状态机
SEND_LIMIT = int(sys.argv[2]) if len(sys.argv) > 2 else 64
BACKLOG = 128


class Conn:
    __slots__ = ("sock", "addr", "outbuf", "peer_closed", "eagain_count")

    def __init__(self, sock: socket.socket, addr):
        self.sock = sock
        self.addr = addr
        self.outbuf = bytearray()
        self.peer_closed = False  # 对端已 EOF，但仍需冲完 outbuf
        self.eagain_count = 0
        sock.setblocking(False)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        # 缩小发送缓冲，便于在慢读场景下稳定观察到 EAGAIN（教学用）
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4096)
        except OSError:
            pass


def close_conn(conns, c: Conn, reason: str):
    peer = f"{c.addr[0]}:{c.addr[1]}"
    fd = c.sock.fileno()
    try:
        c.sock.close()
    except OSError:
        pass
    conns.pop(fd, None)
    print(f"closed {peer} reason={reason} eagain={c.eagain_count}", flush=True)


def try_flush(c: Conn) -> bool:
    """尝试按 SEND_LIMIT 冲刷 outbuf。返回 False 表示连接应关闭。"""
    while c.outbuf:
        nwant = min(SEND_LIMIT, len(c.outbuf))
        try:
            n = c.sock.send(memoryview(c.outbuf)[:nwant])
        except BlockingIOError:
            c.eagain_count += 1
            # 关键：EAGAIN 后立刻返回，由 select 等可写，绝不自旋
            return True
        except OSError as e:
            if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                c.eagain_count += 1
                return True
            if e.errno in (errno.EPIPE, errno.ECONNRESET, errno.ECONNABORTED):
                print(f"send err {c.addr}: {e}", flush=True)
                return False
            print(f"send err {c.addr}: {e}", flush=True)
            return False
        if n == 0:
            print(f"send returned 0 {c.addr}", flush=True)
            return False
        del c.outbuf[:n]
    return True


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((HOST, PORT))
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                print(
                    f"ERROR: port {HOST}:{PORT} already in use (EADDRINUSE)",
                    file=sys.stderr,
                    flush=True,
                )
                sys.exit(2)
            print(f"ERROR: bind failed: {e}", file=sys.stderr, flush=True)
            sys.exit(1)
        srv.setblocking(False)
        srv.listen(BACKLOG)
        print(
            f"nonblock echo listening on {HOST}:{PORT} "
            f"send_limit={SEND_LIMIT} backlog={BACKLOG}",
            flush=True,
        )

        conns: dict[int, Conn] = {}
        # 简单统计：用于测试观察
        total_eagain = 0

        while True:
            # 对端已 EOF 后 fd 在水平触发下会一直可读；勿再放进 rlist，否则空转占 CPU
            rlist = [srv] + [c.sock for c in conns.values() if not c.peer_closed]
            wlist = [c.sock for c in conns.values() if c.outbuf]
            try:
                readable, writable, _ = select.select(rlist, wlist, [], 1.0)
            except InterruptedError:
                continue

            if srv in readable:
                while True:
                    try:
                        conn, addr = srv.accept()
                    except BlockingIOError:
                        break
                    except OSError as e:
                        if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                            break
                        if e.errno == errno.EINTR:
                            continue
                        print(f"accept err: {e}", flush=True)
                        break
                    c = Conn(conn, addr)
                    conns[conn.fileno()] = c
                    print(f"accept {addr[0]}:{addr[1]}", flush=True)

            # 可读：尽量 recv，追加到 outbuf（不保证一次读完）
            for s in readable:
                if s is srv:
                    continue
                fd = s.fileno()
                c = conns.get(fd)
                if c is None:
                    continue
                while True:
                    try:
                        data = s.recv(4096)
                    except BlockingIOError:
                        break
                    except OSError as e:
                        if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                            break
                        if e.errno == errno.EINTR:
                            continue
                        print(f"recv err {c.addr}: {e}", flush=True)
                        close_conn(conns, c, "recv_err")
                        c = None
                        break
                    if not data:
                        if not c.peer_closed:
                            c.peer_closed = True
                            print(f"eof {c.addr[0]}:{c.addr[1]}", flush=True)
                        break
                    c.outbuf.extend(data)
                    # 非阻塞：一次可读通知也可能需要多次 recv；这里循环到 EAGAIN

            # 可写：按 SEND_LIMIT 冲刷；EAGAIN 不自旋
            for s in writable:
                fd = s.fileno()
                c = conns.get(fd)
                if c is None or not c.outbuf:
                    continue
                before = c.eagain_count
                ok = try_flush(c)
                total_eagain += c.eagain_count - before
                if not ok:
                    close_conn(conns, c, "send_fail")
                    continue

            # 对端已关闭且缓冲冲完 → 关连接
            for fd, c in list(conns.items()):
                if c.peer_closed and not c.outbuf:
                    close_conn(conns, c, "eof_flushed")

    finally:
        try:
            srv.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
