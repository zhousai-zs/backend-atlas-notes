#!/usr/bin/env python3
"""普通 Echo 客户端（第52课）。"""
import argparse
import socket
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18052)
    ap.add_argument("--payload", default="hello")
    ap.add_argument("--timeout", type=float, default=5.0)
    ap.add_argument("--repeat", type=int, default=1, help="把 payload 重复 N 次发送")
    args = ap.parse_args()

    data = (args.payload * args.repeat).encode()
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(args.timeout)
    try:
        s.connect((args.host, args.port))
        s.sendall(data)
        s.shutdown(socket.SHUT_WR)
        got = b""
        while len(got) < len(data):
            chunk = s.recv(4096)
            if not chunk:
                break
            got += chunk
        print(f"RESULT ok sent={len(data)} got_len={len(got)} match={got == data}")
        if got != data:
            print(f"RESULT mismatch first_diff", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"RESULT fail {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        s.close()


if __name__ == "__main__":
    main()
