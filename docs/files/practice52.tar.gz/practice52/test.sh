#!/usr/bin/env bash
# Backend Atlas 第52课实践验证：非阻塞 Echo、限 send、慢读、EAGAIN 不自旋
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18052
SEND_LIMIT=64
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2

python3 server.py "$PORT" "$SEND_LIMIT" > /tmp/nb52-srv.log 2>&1 &
SRV=$!
cleanup(){ kill $SRV 2>/dev/null; wait $SRV 2>/dev/null; fuser -k ${PORT}/tcp 2>/dev/null || true; }
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/nb52-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT send_limit=$SEND_LIMIT (pid=$SRV)"

SSOUT=$(ss -ltnp "sport = :$PORT" 2>/dev/null || ss -ltnp | grep ":$PORT" || true)
echo "$SSOUT" | head -3
echo "$SSOUT" | grep -q ":$PORT" && ok "ss 可见 TCP 监听 :$PORT" || bad "ss 未见 TCP :$PORT"

# 1) 正常小包 echo
OUT=$(python3 client.py --port "$PORT" --payload 'hello-nonblock' 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "正常小包 echo 成功" || bad "小包 echo 失败: $OUT"
echo "$OUT" | grep -q "match=True" && ok "小包内容匹配" || bad "小包内容不匹配: $OUT"

# 2) 大包 + 限单次 send：必须拼回完整响应（不丢不重）
BIG_REPEAT=500
OUT=$(python3 client.py --port "$PORT" --payload 'ABCDEFGH' --repeat "$BIG_REPEAT" --timeout 10 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "限 send 下大包 echo 成功" || bad "大包 echo 失败: $OUT"
echo "$OUT" | grep -q "match=True" && ok "大包内容不丢不重" || bad "大包内容错误: $OUT"
EXPECT_LEN=$((8 * BIG_REPEAT))
echo "$OUT" | grep -q "sent=$EXPECT_LEN" && ok "大包长度 sent=$EXPECT_LEN" || bad "大包长度不对: $OUT"

# 3) 慢读客户端：剩余数据不丢不重；同时另一连接仍可服务
python3 slow_client.py --port "$PORT" --size 12000 --recv-size 16 --delay 0.005 --timeout 90 > /tmp/nb52-slow.out 2>&1 &
SLOW=$!
sleep 0.3
OUT=$(python3 client.py --port "$PORT" --payload 'while-slow' --timeout 5 2>&1) || true
echo "concurrent_during_slow: $OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "慢读进行中仍可服务其他连接" || bad "慢读时其他连接失败: $OUT"
wait $SLOW
SLOW_RC=$?
cat /tmp/nb52-slow.out
if [ "$SLOW_RC" -eq 0 ] && grep -q "SLOW_RESULT ok=True" /tmp/nb52-slow.out; then
  ok "慢读客户端完整回显不丢不重"
else
  bad "慢读客户端失败 rc=$SLOW_RC"
fi

# 4) EAGAIN 路径不占满 CPU
python3 - "$PORT" > /tmp/nb52-cpu-client.out 2>&1 <<'CPY' &
import socket, time, sys
PORT = int(sys.argv[1])
payload = b"X" * 24000
s = socket.socket()
try:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024)
except OSError:
    pass
s.settimeout(60)
s.connect(("127.0.0.1", PORT))
s.sendall(payload)
s.shutdown(socket.SHUT_WR)
# 先停顿，制造服务端积压；采样窗口内几乎不读
time.sleep(2.2)
got = 0
while got < len(payload):
    chunk = s.recv(64)
    if not chunk:
        break
    got += len(chunk)
    time.sleep(0.002)
print(f"cpu_client_done got={got} expect={len(payload)} ok={got==len(payload)}")
s.close()
CPY
CPU_CLIENT=$!
sleep 0.5
read_cpu() {
  awk '{print $14+$15}' /proc/$SRV/stat 2>/dev/null || echo 0
}
T1=$(read_cpu)
sleep 1.5
T2=$(read_cpu)
DELTA=$((T2 - T1))
HZ=$(getconf CLK_TCK 2>/dev/null || echo 100)
MAX_DELTA=$(python3 -c "print(int(0.35 * $HZ * 1.5 + 0.999))")
echo "cpu_sample ticks_delta=$DELTA hz=$HZ max_allowed=$MAX_DELTA (over ~1.5s)"
if [ "$DELTA" -le "$MAX_DELTA" ]; then
  ok "EAGAIN 路径 CPU 采样未占满（delta=$DELTA <= $MAX_DELTA）"
else
  bad "疑似自旋占 CPU：ticks_delta=$DELTA > $MAX_DELTA"
fi
WAIT_LEFT=45
while kill -0 $CPU_CLIENT 2>/dev/null && [ "$WAIT_LEFT" -gt 0 ]; do
  sleep 1
  WAIT_LEFT=$((WAIT_LEFT - 1))
done
if kill -0 $CPU_CLIENT 2>/dev/null; then
  kill $CPU_CLIENT 2>/dev/null || true
  wait $CPU_CLIENT 2>/dev/null || true
  bad "CPU 压测客户端超时未完成"
else
  wait $CPU_CLIENT 2>/dev/null || true
  cat /tmp/nb52-cpu-client.out
  grep -q "ok=True" /tmp/nb52-cpu-client.out && ok "CPU 压测客户端最终完整收到回显" || bad "CPU 压测客户端回显不完整"
fi

# 5) 日志应出现过 eagain>0
if grep -EEo 'eagain=[1-9][0-9]*' /tmp/nb52-srv.log | head -5; then
  ok "服务端日志记录到 EAGAIN 计数 > 0"
else
  echo "---- full server log for eagain debug ----"
  cat /tmp/nb52-srv.log
  bad "未观察到 EAGAIN>0（检查 SO_SNDBUF/慢读是否生效）"
fi

# 6) 端口占用明确错误
OUT=$(python3 server.py "$PORT" "$SEND_LIMIT" 2>&1) || RC=$?
RC=${RC:-0}
echo "second_bind rc=$RC out=$OUT"
echo "$OUT" | grep -qiE "EADDRINUSE|already in use|port .* in use" && ok "端口占用给出明确错误" || bad "端口占用错误不明确: $OUT"
[ "${RC}" -eq 2 ] && ok "端口占用退出码为 2" || bad "端口占用退出码异常 rc=$RC"

# 7) 服务仍存活
if kill -0 $SRV 2>/dev/null; then
  ok "全部用例后服务进程仍存活"
  OUT=$(python3 client.py --port "$PORT" --payload 'final-check' 2>&1) || true
  echo "$OUT"
  echo "$OUT" | grep -q "RESULT ok" && ok "收尾 echo 成功" || bad "收尾 echo 失败"
else
  bad "服务进程已退出"
  cat /tmp/nb52-srv.log
fi

echo "---- server log (tail) ----"
tail -40 /tmp/nb52-srv.log || true

if [ "$fail" -eq 0 ]; then
  echo "ALL_CHECKS_PASSED"
  exit 0
else
  echo "SOME_CHECKS_FAILED"
  exit 1
fi
