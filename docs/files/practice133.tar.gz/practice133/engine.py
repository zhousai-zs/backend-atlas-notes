#!/usr/bin/env python3
"""Teaching HeapEngine — not Redis, not a real profiler/allocator product,
not a network service.

A Python 3 standard-library model of a content-backend KV request path
that allocates many small objects, a teaching size-class heap, and
teaching analogues of TCMalloc heap / allocation / lifetime profiles.

The named source (checked on 2026-11-14) is TCMalloc's sampling document
at https://github.com/google/tcmalloc/blob/master/docs/sampling.md
(raw body: docs/sampling.md). That page defines heap profiling
(traverse sampled objects still on the heap), allocation profiling
(sampled allocations during a time window, via
MallocExtension::StartAllocationProfiling), and lifetime profiling
(observed versus right-censored lifetimes). It also distinguishes
requested size from actual allocated size after size-class rounding,
and notes that RSS for a sampled page can stay resident because a prior
allocation used the page or because a hugepage backs unused pages.

The exact pair of names "in-use 与 allocated bytes" is the node wording.
The official analogues used here are: ProfileType::kHeap /
generic.bytes_in_use_by_app (current usage) versus kAllocations
(allocations during a session), and Sample.requested_size versus
Sample.allocated_size. Those identifiers are in malloc_extension.h,
which sampling.md names. Arena unallocated / unavailable and
"realized fragmentation" are defined in the same repository's
docs/stats.md, not in sampling.md itself.

This engine is not Google TCMalloc, not jemalloc, not a host invocation
of any heap profiler, and not a wall-clock measurement. Times are
teaching virtual-clock values, not production RTT.
"""
from __future__ import annotations

from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"

# Teaching size classes — a small discrete table used as an analogue of
# the size-class idea in sampling.md / size_classes.cc, not a copy of
# TCMalloc's actual class list.
SIZE_CLASSES = (8, 16, 32, 48, 64, 128, 256, 512, 1024, 2048, 4096)
OS_BLOCK = 4096
N_REQUESTS = 2000
REQ_MS = 15  # 2000 * 15 ms = 30.00 s
MEASURE_S = 30.00
SMALL_N = 64
SMALL_REQ = 24  # rounds up to 32
TITLE_REQ = 64  # exact class 64
LEAK_N = 8  # leaked field objects per request in leak mode

STACK_FIELD = (PROCESS, "handle_get", "parse_fields", "alloc_field")
STACK_TITLE = (PROCESS, "handle_get", "serialize_title")


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def size_class(requested: int) -> int:
    for c in SIZE_CLASSES:
        if c >= requested:
            return c
    raise ValueError(f"no teaching size class for {requested}")


def _add_group(
    groups: dict[tuple[str, ...], dict[str, int]],
    stack: tuple[str, ...],
    *,
    count: int,
    requested: int,
    allocated: int,
    from_cache: int = 0,
    from_pool: int = 0,
) -> None:
    g = groups.get(stack)
    if g is None:
        g = {
            "count": 0,
            "requested": 0,
            "allocated": 0,
            "from_cache": 0,
            "from_pool": 0,
        }
        groups[stack] = g
    g["count"] += count
    g["requested"] += requested
    g["allocated"] += allocated
    g["from_cache"] += from_cache
    g["from_pool"] += from_pool


def _rows_from_groups(groups: dict[tuple[str, ...], dict[str, int]], kind: str) -> list[dict[str, Any]]:
    rows = []
    for stack, g in groups.items():
        if g["count"] <= 0:
            continue
        row = {
            "stack": list(stack),
            "leaf": stack[-1],
            "count": g["count"],
            "requested_bytes": g["requested"],
            "allocated_bytes": g["allocated"],
            "kind": kind,
        }
        if kind == "allocated":
            row["from_cache"] = g["from_cache"]
            row["from_pool"] = g["from_pool"]
        rows.append(row)
    rows.sort(key=lambda r: (-r["allocated_bytes"], r["leaf"]))
    return rows


class HeapEngine:
    """Teaching size-class allocator + heap / allocation profiles."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1
        self.reset()

    def reset(self) -> None:
        self._in_use = 0
        self._requested_live = 0
        self.live_groups: dict[tuple[str, ...], dict[str, int]] = {}
        self.cache: dict[int, int] = {}
        self.alloc_groups: dict[tuple[str, ...], dict[str, int]] = {}
        self.t_us = 0
        self.session_open = False
        self.session_start_us = 0
        self.mapped_blocks = 0
        self.unmapped_blocks = 0
        self.peak_physical = 0
        self.in_use_at_peak = 0
        self.n_os_allocs = 0
        self.n_os_releases = 0
        self.pool_slots = 0
        self.pool_in_use = 0
        self.n_allocs = 0
        self.n_frees = 0
        self.n_pool_hits = 0
        self.n_observed = 0
        self.observed_lifetime_us = 0
        self.n_censored_batches = 0
        self.censored_alloc_us_sum = 0  # sum of t_alloc over still-live leaked objs
        self.n_censored_objs = 0

    def cache_bytes(self) -> int:
        return sum(sz * n for sz, n in self.cache.items())

    def idle_pool_bytes(self) -> int:
        return (self.pool_slots - self.pool_in_use) * size_class(SMALL_REQ)

    def in_use_by_app(self) -> int:
        return self._in_use

    def requested_live(self) -> int:
        return self._requested_live

    def internal_fragmentation(self) -> int:
        return self._in_use - self._requested_live

    def retained(self) -> int:
        """Bytes held by the allocator but not in use by the app."""
        return self.cache_bytes() + self.idle_pool_bytes()

    def _committed(self) -> int:
        return self._in_use + self.retained()

    def physical_memory_used(self) -> int:
        return self.mapped_blocks * OS_BLOCK

    def virtual_memory_used(self) -> int:
        return (self.mapped_blocks + self.unmapped_blocks) * OS_BLOCK

    def unmapped_bytes(self) -> int:
        return self.unmapped_blocks * OS_BLOCK

    def arena_unallocated(self) -> int:
        leftover = self.physical_memory_used() - self._committed()
        return leftover if leftover > 0 else 0

    def rss(self) -> int:
        """Teaching RSS analogue: backed physical memory, not a host smaps value."""
        return self.physical_memory_used()

    def _need_mapped(self) -> int:
        committed = self._committed()
        return (committed + OS_BLOCK - 1) // OS_BLOCK if committed else 0

    def _sync_mapping(self) -> None:
        need = self._need_mapped()
        if need > self.mapped_blocks:
            extra = need - self.mapped_blocks
            reuse = min(extra, self.unmapped_blocks)
            self.unmapped_blocks -= reuse
            fresh = extra - reuse
            self.mapped_blocks += extra
            self.n_os_allocs += fresh
        phys = self.physical_memory_used()
        if phys > self.peak_physical:
            self.peak_physical = phys
            self.in_use_at_peak = self._in_use
        elif phys == self.peak_physical and self._in_use > self.in_use_at_peak:
            # Same peak backing, higher live usage (e.g. title allocated
            # into leftover space of the already-mapped block).
            self.in_use_at_peak = self._in_use

    def realized_fragmentation_pct(self, nd: int = 4) -> float:
        if self.peak_physical == 0:
            return 0.0
        return round(
            (self.peak_physical - self.in_use_at_peak) / self.peak_physical * 100.0
            + 1e-12,
            nd,
        )

    def properties(self) -> dict[str, int]:
        return {
            "generic.bytes_in_use_by_app": self.in_use_by_app(),
            "generic.physical_memory_used": self.physical_memory_used(),
            "generic.virtual_memory_used": self.virtual_memory_used(),
            "tcmalloc.page_heap_free": self.retained(),
            "tcmalloc.page_heap_unmapped": self.unmapped_bytes(),
            "arena_unallocated": self.arena_unallocated(),
            "internal_fragmentation": self.internal_fragmentation(),
        }

    def _charge_live(self, stack: tuple[str, ...], requested: int, alloc_sz: int, n: int = 1) -> None:
        self._in_use += alloc_sz * n
        self._requested_live += requested * n
        _add_group(
            self.live_groups,
            stack,
            count=n,
            requested=requested * n,
            allocated=alloc_sz * n,
        )

    def _uncharge_live(self, stack: tuple[str, ...], requested: int, alloc_sz: int, n: int = 1) -> None:
        self._in_use -= alloc_sz * n
        self._requested_live -= requested * n
        _add_group(
            self.live_groups,
            stack,
            count=-n,
            requested=-requested * n,
            allocated=-alloc_sz * n,
        )

    def malloc_n(
        self,
        requested: int,
        stack: tuple[str, ...],
        n: int = 1,
        *,
        t_us: Optional[int] = None,
    ) -> dict[str, int]:
        """Allocate n objects of the same requested size and stack."""
        if t_us is None:
            t_us = self.t_us
        alloc_sz = size_class(requested)
        cached = self.cache.get(alloc_sz, 0)
        from_cache = min(cached, n)
        from_fresh = n - from_cache
        if from_cache:
            left = cached - from_cache
            if left:
                self.cache[alloc_sz] = left
            else:
                del self.cache[alloc_sz]
        self._charge_live(stack, requested, alloc_sz, n)
        self.n_allocs += n
        self._sync_mapping()
        if self.session_open:
            _add_group(
                self.alloc_groups,
                stack,
                count=n,
                requested=requested * n,
                allocated=alloc_sz * n,
                from_cache=from_cache,
            )
        return {
            "requested_size": requested,
            "allocated_size": alloc_sz,
            "n": n,
            "from_cache": from_cache,
            "from_fresh": from_fresh,
        }

    def free_n(
        self,
        requested: int,
        stack: tuple[str, ...],
        n: int = 1,
        *,
        t_us: Optional[int] = None,
        lifetime_us: int = 0,
    ) -> None:
        if t_us is None:
            t_us = self.t_us
        alloc_sz = size_class(requested)
        self._uncharge_live(stack, requested, alloc_sz, n)
        self.n_frees += n
        self.n_observed += n
        self.observed_lifetime_us += lifetime_us * n
        self.cache[alloc_sz] = self.cache.get(alloc_sz, 0) + n
        self._sync_mapping()

    def flush_caches(self) -> int:
        """Drop size-class freelist slots so empty pages can be released.

        Teaching analogue of returning cached objects so the page heap
        can madvise them. Idle pool slots are not flushed here.
        """
        dropped = self.cache_bytes()
        self.cache.clear()
        self._sync_mapping()
        return dropped

    def release_memory_to_system(self, *, flush_caches: bool = False) -> dict[str, Any]:
        """Teaching analogue of ReleaseMemoryToSystem / madvise.

        Fully free mapped blocks (those not covering in-use or retained
        bytes) are unmapped. If the size-class cache still holds slots,
        those pages stay mapped and RSS may not drop. in-use is unchanged.
        """
        cache_before = self.cache_bytes()
        flushed = 0
        if flush_caches:
            flushed = self.flush_caches()
        before = self.physical_memory_used()
        need = self._need_mapped()
        extra = self.mapped_blocks - need
        if extra < 0:
            extra = 0
        if extra:
            self.mapped_blocks -= extra
            self.unmapped_blocks += extra
            self.n_os_releases += extra
        return {
            "rss_before": before,
            "rss_after": self.physical_memory_used(),
            "blocks_released": extra,
            "in_use_by_app": self.in_use_by_app(),
            "cache_before": cache_before,
            "cache_flushed": flushed,
            "flush_caches": flush_caches,
        }

    def start_allocation_profiling(self) -> None:
        self.session_open = True
        self.session_start_us = self.t_us
        self.alloc_groups = {}

    def stop_allocation_profiling(self) -> dict[str, Any]:
        self.session_open = False
        duration_s = ts((self.t_us - self.session_start_us) / 1_000_000)
        return self._summarize_allocation_profile(duration_s)

    def snapshot_heap(self) -> dict[str, Any]:
        """Teaching analogue of SnapshotCurrent(kHeap)."""
        rows = _rows_from_groups(self.live_groups, "in-use")
        total_alloc = sum(r["allocated_bytes"] for r in rows)
        source = rows[0]["leaf"] if rows else None
        return {
            "type": "kHeap",
            "in_use_by_app": self.in_use_by_app(),
            "requested_live": self.requested_live(),
            "internal_fragmentation": self.internal_fragmentation(),
            "rows": rows,
            "source_leaf": source,
            "source_allocated_bytes": rows[0]["allocated_bytes"] if rows else 0,
            "source_share": share(rows[0]["allocated_bytes"], total_alloc) if rows else 0.0,
        }

    def _summarize_allocation_profile(self, duration_s: float) -> dict[str, Any]:
        rows = _rows_from_groups(self.alloc_groups, "allocated")
        total_alloc = sum(r["allocated_bytes"] for r in rows)
        source = rows[0]["leaf"] if rows else None
        return {
            "type": "kAllocations",
            "duration_s": duration_s,
            "n_events": sum(r["count"] for r in rows),
            "allocated_bytes": total_alloc,
            "requested_bytes": sum(r["requested_bytes"] for r in rows),
            "rows": rows,
            "source_leaf": source,
            "source_allocated_bytes": rows[0]["allocated_bytes"] if rows else 0,
            "source_count": rows[0]["count"] if rows else 0,
            "source_share": share(rows[0]["allocated_bytes"], total_alloc) if rows else 0.0,
        }

    def lifetime_summary(self) -> dict[str, Any]:
        """Teaching analogue of lifetime profiling: observed vs censored."""
        n_censored = self.n_censored_objs
        if n_censored:
            # Each still-live object has been live from its t_alloc until now.
            censored_sum = n_censored * self.t_us - self.censored_alloc_us_sum
            censored_mean_ms = ts(censored_sum / n_censored / 1000.0, 2)
        else:
            censored_mean_ms = 0.0
        observed_mean_ms = (
            ts(self.observed_lifetime_us / self.n_observed / 1000.0, 2)
            if self.n_observed
            else 0.0
        )
        return {
            "type": "kLifetimes",
            "n_observed": self.n_observed,
            "n_censored": n_censored,
            "observed_mean_lifetime_ms": observed_mean_ms,
            "censored_mean_lifetime_ms": censored_mean_ms,
        }

    def ensure_pool(self, n: int = SMALL_N) -> None:
        need = n - self.pool_slots
        if need <= 0:
            return
        # Warmup allocations are charged briefly, then parked in the pool.
        self.malloc_n(SMALL_REQ, STACK_FIELD, need)
        self._uncharge_live(STACK_FIELD, SMALL_REQ, size_class(SMALL_REQ), need)
        self.pool_slots += need
        self._sync_mapping()

    def run_request(self, *, mode: str, leak_n: int = 0) -> dict[str, Any]:
        start = self.t_us
        alloc_sz = size_class(SMALL_REQ)
        title_sz = size_class(TITLE_REQ)

        if mode == "pool" and self.pool_slots >= SMALL_N:
            # Checkout pre-parked slots: no allocator malloc for fields.
            self.pool_in_use += SMALL_N
            self._charge_live(STACK_FIELD, SMALL_REQ, alloc_sz, SMALL_N)
            self.n_pool_hits += SMALL_N
            self._sync_mapping()
            field_from_pool = SMALL_N
        else:
            self.malloc_n(SMALL_REQ, STACK_FIELD, SMALL_N)
            field_from_pool = 0

        self.malloc_n(TITLE_REQ, STACK_TITLE, 1)

        mid = {
            "in_use_by_app": self.in_use_by_app(),
            "requested_live": self.requested_live(),
            "internal_fragmentation": self.internal_fragmentation(),
            "rss": self.rss(),
            "heap": self.snapshot_heap(),
        }

        # Title always dies at the end of the request (lifetime = 0 in this
        # teaching model: alloc and free in the same virtual tick).
        self.free_n(TITLE_REQ, STACK_TITLE, 1, lifetime_us=REQ_MS * 1000)

        keep = leak_n if mode == "leak" else 0
        free_fields = SMALL_N - keep
        if field_from_pool:
            # Return slots to the pool; they stay retained, not on the cache.
            self._uncharge_live(STACK_FIELD, SMALL_REQ, alloc_sz, SMALL_N)
            self.pool_in_use -= SMALL_N
            self._sync_mapping()
        else:
            if free_fields:
                self.free_n(SMALL_REQ, STACK_FIELD, free_fields, lifetime_us=REQ_MS * 1000)
            if keep:
                self.n_censored_objs += keep
                self.censored_alloc_us_sum += start * keep
                self.n_censored_batches += 1

        self.t_us += REQ_MS * 1000
        return mid

    def run_load(
        self,
        *,
        mode: str,
        n_requests: int = N_REQUESTS,
        leak_n: int = LEAK_N,
        profile: bool = True,
        release_at_end: bool = False,
        snapshot_mid_request: bool = True,
    ) -> dict[str, Any]:
        self.reset()
        if mode == "pool":
            self.ensure_pool(SMALL_N)
        if profile:
            self.start_allocation_profiling()
        mid_heap = None
        first_in_use = last_in_use = min_in_use = max_in_use = 0
        first_rss = last_rss = min_rss = max_rss = 0
        plateau = True
        rising = True
        prev_in_use: Optional[int] = None
        for i in range(n_requests):
            mid = self.run_request(mode=mode, leak_n=leak_n if mode == "leak" else 0)
            if snapshot_mid_request and i == 0:
                mid_heap = mid
            iu = self.in_use_by_app()
            rs = self.rss()
            if i == 0:
                first_in_use = last_in_use = min_in_use = max_in_use = iu
                first_rss = last_rss = min_rss = max_rss = rs
            else:
                last_in_use = iu
                last_rss = rs
                if iu < min_in_use:
                    min_in_use = iu
                if iu > max_in_use:
                    max_in_use = iu
                if rs < min_rss:
                    min_rss = rs
                if rs > max_rss:
                    max_rss = rs
                if iu != first_in_use:
                    plateau = False
                if prev_in_use is not None and iu <= prev_in_use:
                    rising = False
            prev_in_use = iu
        if n_requests <= 1:
            rising = False
        alloc_prof = self.stop_allocation_profiling() if profile else None
        idle_heap = self.snapshot_heap()
        lifetimes = self.lifetime_summary()
        release = None
        rss_before_release = self.rss()
        release_without_flush = None
        if release_at_end:
            # First try a release while the size-class cache still holds
            # slots — RSS typically does not drop. Then flush and retry.
            release_without_flush = self.release_memory_to_system(flush_caches=False)
            release = self.release_memory_to_system(flush_caches=True)
        return {
            "mode": mode,
            "key": self.key,
            "title": self.title,
            "n_requests": n_requests,
            "measure_s": ts(self.t_us / 1_000_000),
            "times_are_teaching_virtual_clock": True,
            "in_use_by_app": self.in_use_by_app(),
            "requested_live": self.requested_live(),
            "internal_fragmentation": self.internal_fragmentation(),
            "retained": self.retained(),
            "rss": self.rss(),
            "rss_before_release": rss_before_release,
            "virtual_memory_used": self.virtual_memory_used(),
            "unmapped_bytes": self.unmapped_bytes(),
            "arena_unallocated": self.arena_unallocated(),
            "peak_physical": self.peak_physical,
            "in_use_at_peak": self.in_use_at_peak,
            "realized_fragmentation_pct": self.realized_fragmentation_pct(),
            "n_allocs": self.n_allocs,
            "n_frees": self.n_frees,
            "n_pool_hits": self.n_pool_hits,
            "n_os_allocs": self.n_os_allocs,
            "n_os_releases": self.n_os_releases,
            "mapped_blocks": self.mapped_blocks,
            "properties": self.properties(),
            "mid_request": mid_heap,
            "idle_heap": idle_heap,
            "allocation_profile": alloc_prof,
            "lifetimes": lifetimes,
            "release": release,
            "release_without_flush": release_without_flush,
            "in_use_after_each_request": {
                "first": first_in_use,
                "last": last_in_use,
                "min": min_in_use,
                "max": max_in_use,
                "plateau": plateau,
                "monotone_rising": rising,
            },
            "rss_after_each_request": {
                "first": first_rss,
                "last": last_rss,
                "min": min_rss,
                "max": max_rss,
            },
        }

    def compare(self) -> dict[str, Any]:
        ephemeral = self.run_load(mode="ephemeral", release_at_end=False)
        released = self.run_load(mode="ephemeral", release_at_end=True)
        leak = self.run_load(mode="leak", release_at_end=False)
        pooled = self.run_load(mode="pool", release_at_end=False)

        # Official default sampling interval is 2 MiB (a statistical
        # expectation). The teaching engine records every allocation so
        # the practice can attribute the source with exact counts.
        default_period = 2 * 1024 * 1024
        alloc_bytes = ephemeral["allocation_profile"]["allocated_bytes"]
        expected_samples_at_2mib = ts(alloc_bytes / default_period, 4)

        e_mid = ephemeral["mid_request"]["heap"]
        e_idle = ephemeral["idle_heap"]
        e_alloc = ephemeral["allocation_profile"]
        found_by_heap_in_request = e_mid["source_leaf"] == "alloc_field"
        missed_by_idle_heap = e_idle["in_use_by_app"] == 0 or e_idle["source_leaf"] is None
        found_by_alloc = e_alloc["source_leaf"] == "alloc_field"

        rss_unchanged_after_free = (
            ephemeral["in_use_by_app"] == 0
            and ephemeral["rss"] > 0
            and ephemeral["rss_after_each_request"]["first"]
            == ephemeral["rss_after_each_request"]["last"]
        )
        release_without_flush_keeps_rss = (
            released["release_without_flush"]["rss_after"]
            == released["release_without_flush"]["rss_before"]
            and released["release_without_flush"]["blocks_released"] == 0
        )
        release_drops_rss = (
            released["release"]["rss_after"] < released["release"]["rss_before"]
            and released["release"]["in_use_by_app"] == 0
            and released["release"]["flush_caches"]
        )
        leak_not_stable = leak["in_use_after_each_request"]["monotone_rising"]
        ephemeral_stable = ephemeral["in_use_after_each_request"]["plateau"]
        rss_rise_is_not_leak = (
            ephemeral["rss"] > 0
            and ephemeral["in_use_by_app"] == 0
            and ephemeral_stable
            and leak["in_use_by_app"] > ephemeral["in_use_by_app"]
        )
        pool_fewer_allocs = pooled["n_allocs"] < ephemeral["n_allocs"]
        pool_retains = pooled["retained"] > 0 and pooled["in_use_by_app"] == 0

        return {
            "n_requests": N_REQUESTS,
            "measure_s": MEASURE_S,
            "small_n": SMALL_N,
            "small_requested": SMALL_REQ,
            "small_allocated": size_class(SMALL_REQ),
            "title_requested": TITLE_REQ,
            "title_allocated": size_class(TITLE_REQ),
            "leak_n": LEAK_N,
            "os_block": OS_BLOCK,
            "size_classes": list(SIZE_CLASSES),
            "ephemeral": ephemeral,
            "released": released,
            "leak": leak,
            "pool": pooled,
            "default_profile_sampling_interval_bytes": default_period,
            "allocated_bytes_ephemeral": alloc_bytes,
            "expected_samples_at_default_2mib": expected_samples_at_2mib,
            "found_source_by_in_request_heap": found_by_heap_in_request,
            "idle_heap_misses_short_lived": missed_by_idle_heap,
            "found_source_by_allocation_profile": found_by_alloc,
            "rss_does_not_drop_after_free": rss_unchanged_after_free,
            "release_without_flush_keeps_rss": release_without_flush_keeps_rss,
            "release_drops_rss": release_drops_rss,
            "continuous_load_stable_without_leak": ephemeral_stable,
            "continuous_load_rising_with_leak": leak_not_stable,
            "rss_rise_alone_is_not_leak": rss_rise_is_not_leak,
            "pool_reduces_allocations": pool_fewer_allocs,
            "pool_retains_resident_bytes": pool_retains,
        }
