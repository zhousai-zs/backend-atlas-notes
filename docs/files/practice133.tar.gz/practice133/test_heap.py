#!/usr/bin/env python3
"""Acceptance checks for the lesson 133 teaching heap-profile experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, LEAK_N, MEASURE_S, N_REQUESTS, PROCESS, SMALL_N, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "HeapEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["n_requests"] == N_REQUESTS == 2000
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["small_n"] == SMALL_N == 64
    assert r["small_requested"] == 24 and r["small_allocated"] == 32
    assert r["title_requested"] == 64 and r["title_allocated"] == 64
    assert r["leak_n"] == LEAK_N == 8
    assert r["os_block"] == 4096
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_allocator_product"]
    assert r["not_host_tcmalloc"] and r["not_host_jemalloc"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]

    p = r["practice"]
    e = p["ephemeral"]
    assert e["measure_s"] == 30.0 and e["n_requests"] == 2000
    assert e["in_use_by_app"] == 0 and e["requested_live"] == 0
    assert e["internal_fragmentation"] == 0
    assert e["retained"] == 2112 and e["rss"] == 4096
    assert e["arena_unallocated"] == 1984
    assert e["virtual_memory_used"] == 4096 and e["unmapped_bytes"] == 0
    assert e["peak_physical"] == 4096 and e["in_use_at_peak"] == 2112
    assert e["realized_fragmentation_pct"] == 48.4375
    assert e["n_allocs"] == e["n_frees"] == 130000
    assert e["n_pool_hits"] == 0 and e["mapped_blocks"] == 1
    mid = e["mid_request"]
    assert mid["in_use_by_app"] == 2112
    assert mid["requested_live"] == 1600
    assert mid["internal_fragmentation"] == 512
    assert mid["rss"] == 4096
    mh = mid["heap"]
    assert mh["type"] == "kHeap" and mh["source_leaf"] == "alloc_field"
    assert mh["source_allocated_bytes"] == 2048 and mh["source_share"] == 0.9697
    by = {row["leaf"]: row for row in mh["rows"]}
    assert by["alloc_field"]["count"] == 64
    assert by["alloc_field"]["requested_bytes"] == 1536
    assert by["alloc_field"]["allocated_bytes"] == 2048
    assert by["serialize_title"]["count"] == 1
    assert by["serialize_title"]["allocated_bytes"] == 64
    idle = e["idle_heap"]
    assert idle["in_use_by_app"] == 0 and idle["source_leaf"] is None
    assert idle["rows"] == []
    ap = e["allocation_profile"]
    assert ap["type"] == "kAllocations" and ap["duration_s"] == 30.0
    assert ap["n_events"] == 130000
    assert ap["allocated_bytes"] == 4_224_000
    assert ap["requested_bytes"] == 3_200_000
    assert ap["source_leaf"] == "alloc_field"
    assert ap["source_count"] == 128000
    assert ap["source_allocated_bytes"] == 4_096_000
    assert ap["source_share"] == 0.9697
    ab = {row["leaf"]: row for row in ap["rows"]}
    assert ab["alloc_field"]["from_cache"] == 127936
    assert ab["serialize_title"]["count"] == 2000
    assert ab["serialize_title"]["allocated_bytes"] == 128000
    assert ab["serialize_title"]["from_cache"] == 1999
    assert e["lifetimes"]["n_observed"] == 130000
    assert e["lifetimes"]["n_censored"] == 0
    assert e["lifetimes"]["observed_mean_lifetime_ms"] == 15.0
    assert e["in_use_after_each_request"]["plateau"] is True
    assert e["in_use_after_each_request"]["first"] == 0
    assert e["rss_after_each_request"]["first"] == e["rss_after_each_request"]["last"] == 4096
    assert p["found_source_by_in_request_heap"]
    assert p["idle_heap_misses_short_lived"]
    assert p["found_source_by_allocation_profile"]

    rel = r["released"]
    nof = rel["release_without_flush"]
    assert nof["flush_caches"] is False
    assert nof["rss_before"] == nof["rss_after"] == 4096
    assert nof["blocks_released"] == 0 and nof["cache_before"] == 2112
    fl = rel["release"]
    assert fl["flush_caches"] is True
    assert fl["rss_before"] == 4096 and fl["rss_after"] == 0
    assert fl["blocks_released"] == 1 and fl["cache_flushed"] == 2112
    assert fl["in_use_by_app"] == 0
    assert rel["rss"] == 0 and rel["unmapped_bytes"] == 4096 and rel["retained"] == 0

    lk = r["leak"]
    assert lk["in_use_by_app"] == 512000
    assert lk["requested_live"] == 384000
    assert lk["internal_fragmentation"] == 128000
    assert lk["retained"] == 1856 and lk["rss"] == 516096
    assert lk["arena_unallocated"] == 2240
    assert lk["peak_physical"] == 516096 and lk["in_use_at_peak"] == 513856
    assert lk["realized_fragmentation_pct"] == 0.434
    assert lk["idle_heap"]["source_leaf"] == "alloc_field"
    assert lk["idle_heap"]["source_allocated_bytes"] == 512000
    assert lk["idle_heap"]["rows"][0]["count"] == 16000
    assert lk["in_use_after_each_request"]["first"] == 256
    assert lk["in_use_after_each_request"]["last"] == 512000
    assert lk["in_use_after_each_request"]["monotone_rising"] is True
    assert lk["in_use_after_each_request"]["plateau"] is False
    assert lk["rss_after_each_request"]["first"] == 4096
    assert lk["rss_after_each_request"]["last"] == 516096
    assert lk["lifetimes"]["n_observed"] == 114000
    assert lk["lifetimes"]["n_censored"] == 16000
    assert lk["lifetimes"]["observed_mean_lifetime_ms"] == 15.0
    assert lk["lifetimes"]["censored_mean_lifetime_ms"] == 15007.5
    assert lk["allocation_profile"]["source_leaf"] == "alloc_field"
    assert lk["allocation_profile"]["source_count"] == 128000

    pool = r["pool"]
    assert pool["n_allocs"] == 2064
    assert pool["n_pool_hits"] == 128000
    assert pool["in_use_by_app"] == 0 and pool["retained"] == 2112
    assert pool["rss"] == 4096
    assert pool["allocation_profile"]["n_events"] == 2000
    assert pool["allocation_profile"]["source_leaf"] == "serialize_title"
    assert pool["allocation_profile"]["rows"][0]["leaf"] == "serialize_title"
    assert pool["in_use_after_each_request"]["plateau"] is True
    assert pool["mid_request"]["heap"]["source_leaf"] == "alloc_field"

    sb = r["sampling_boundary"]
    assert sb["default_profile_sampling_interval_bytes"] == 2 * 1024 * 1024
    assert sb["allocated_bytes_ephemeral"] == 4_224_000
    assert sb["expected_samples_at_default_2mib"] == 2.0142

    flags = r["flags"]
    assert flags["rss_does_not_drop_after_free"]
    assert flags["release_without_flush_keeps_rss"]
    assert flags["release_drops_rss"]
    assert flags["continuous_load_stable_without_leak"]
    assert flags["continuous_load_rising_with_leak"]
    assert flags["rss_rise_alone_is_not_leak"]
    assert flags["pool_reduces_allocations"]
    assert flags["pool_retains_resident_bytes"]
    assert r["acceptance_explains_rss_after_free"]
    assert r["acceptance_steady_load_platform"]
    assert r["pitfall_rss_rise_is_not_leak"]
    assert r["tradeoff_pool_retains_resident"]
    assert r["practice_found_allocation_source"]


if __name__ == "__main__":
    main()
