#!/usr/bin/env python3
"""Run the lesson 133 teaching heap-profile experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import (
    KEY_TITLE,
    LEAK_N,
    MEASURE_S,
    N_REQUESTS,
    PROCESS,
    SMALL_N,
    SMALL_REQ,
    TITLE_REQ,
    TITLE_V1,
    HeapEngine,
    size_class,
)


def _public_heap(heap: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": heap["type"],
        "in_use_by_app": heap["in_use_by_app"],
        "requested_live": heap["requested_live"],
        "internal_fragmentation": heap["internal_fragmentation"],
        "rows": heap["rows"],
        "source_leaf": heap["source_leaf"],
        "source_allocated_bytes": heap["source_allocated_bytes"],
        "source_share": heap["source_share"],
    }


def _public_alloc(prof: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": prof["type"],
        "duration_s": prof["duration_s"],
        "n_events": prof["n_events"],
        "allocated_bytes": prof["allocated_bytes"],
        "requested_bytes": prof["requested_bytes"],
        "rows": prof["rows"],
        "source_leaf": prof["source_leaf"],
        "source_allocated_bytes": prof["source_allocated_bytes"],
        "source_count": prof["source_count"],
        "source_share": prof["source_share"],
    }


def _public_run(run: dict[str, Any], *, include_release: bool = False) -> dict[str, Any]:
    out = {
        "mode": run["mode"],
        "n_requests": run["n_requests"],
        "measure_s": run["measure_s"],
        "times_are_teaching_virtual_clock": run["times_are_teaching_virtual_clock"],
        "in_use_by_app": run["in_use_by_app"],
        "requested_live": run["requested_live"],
        "internal_fragmentation": run["internal_fragmentation"],
        "retained": run["retained"],
        "rss": run["rss"],
        "virtual_memory_used": run["virtual_memory_used"],
        "unmapped_bytes": run["unmapped_bytes"],
        "arena_unallocated": run["arena_unallocated"],
        "peak_physical": run["peak_physical"],
        "in_use_at_peak": run["in_use_at_peak"],
        "realized_fragmentation_pct": run["realized_fragmentation_pct"],
        "n_allocs": run["n_allocs"],
        "n_frees": run["n_frees"],
        "n_pool_hits": run["n_pool_hits"],
        "n_os_allocs": run["n_os_allocs"],
        "n_os_releases": run["n_os_releases"],
        "mapped_blocks": run["mapped_blocks"],
        "properties": run["properties"],
        "mid_request": {
            "in_use_by_app": run["mid_request"]["in_use_by_app"],
            "requested_live": run["mid_request"]["requested_live"],
            "internal_fragmentation": run["mid_request"]["internal_fragmentation"],
            "rss": run["mid_request"]["rss"],
            "heap": _public_heap(run["mid_request"]["heap"]),
        },
        "idle_heap": _public_heap(run["idle_heap"]),
        "allocation_profile": _public_alloc(run["allocation_profile"]),
        "lifetimes": run["lifetimes"],
        "in_use_after_each_request": run["in_use_after_each_request"],
        "rss_after_each_request": run["rss_after_each_request"],
    }
    if include_release:
        out["release_without_flush"] = run["release_without_flush"]
        out["release"] = run["release"]
    return out


def run() -> dict[str, Any]:
    eng = HeapEngine()
    cmp = eng.compare()
    ephemeral = cmp["ephemeral"]
    released = cmp["released"]
    leak = cmp["leak"]
    pooled = cmp["pool"]

    acceptance_rss = (
        cmp["rss_does_not_drop_after_free"]
        and cmp["release_without_flush_keeps_rss"]
        and cmp["release_drops_rss"]
    )
    acceptance_platform = (
        cmp["continuous_load_stable_without_leak"]
        and cmp["continuous_load_rising_with_leak"]
    )
    pitfall = cmp["rss_rise_alone_is_not_leak"]
    tradeoff = cmp["pool_reduces_allocations"] and cmp["pool_retains_resident_bytes"]
    found_source = (
        cmp["found_source_by_in_request_heap"]
        and cmp["idle_heap_misses_short_lived"]
        and cmp["found_source_by_allocation_profile"]
    )

    return {
        "engine": "HeapEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "n_requests": N_REQUESTS,
        "measure_s": MEASURE_S,
        "small_n": SMALL_N,
        "small_requested": SMALL_REQ,
        "small_allocated": size_class(SMALL_REQ),
        "title_requested": TITLE_REQ,
        "title_allocated": size_class(TITLE_REQ),
        "leak_n": LEAK_N,
        "os_block": cmp["os_block"],
        "size_classes": cmp["size_classes"],
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_allocator_product": True,
        "not_host_tcmalloc": True,
        "not_host_jemalloc": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "practice": {
            "ephemeral": _public_run(ephemeral),
            "source_leaf": ephemeral["allocation_profile"]["source_leaf"],
            "source_count": ephemeral["allocation_profile"]["source_count"],
            "source_allocated_bytes": ephemeral["allocation_profile"]["source_allocated_bytes"],
            "source_share": ephemeral["allocation_profile"]["source_share"],
            "found_source_by_in_request_heap": cmp["found_source_by_in_request_heap"],
            "idle_heap_misses_short_lived": cmp["idle_heap_misses_short_lived"],
            "found_source_by_allocation_profile": cmp["found_source_by_allocation_profile"],
        },
        "released": _public_run(released, include_release=True),
        "leak": _public_run(leak),
        "pool": _public_run(pooled),
        "sampling_boundary": {
            "default_profile_sampling_interval_bytes": cmp[
                "default_profile_sampling_interval_bytes"
            ],
            "allocated_bytes_ephemeral": cmp["allocated_bytes_ephemeral"],
            "expected_samples_at_default_2mib": cmp["expected_samples_at_default_2mib"],
        },
        "flags": {
            "rss_does_not_drop_after_free": cmp["rss_does_not_drop_after_free"],
            "release_without_flush_keeps_rss": cmp["release_without_flush_keeps_rss"],
            "release_drops_rss": cmp["release_drops_rss"],
            "continuous_load_stable_without_leak": cmp[
                "continuous_load_stable_without_leak"
            ],
            "continuous_load_rising_with_leak": cmp["continuous_load_rising_with_leak"],
            "rss_rise_alone_is_not_leak": cmp["rss_rise_alone_is_not_leak"],
            "pool_reduces_allocations": cmp["pool_reduces_allocations"],
            "pool_retains_resident_bytes": cmp["pool_retains_resident_bytes"],
        },
        "acceptance_explains_rss_after_free": acceptance_rss,
        "acceptance_steady_load_platform": acceptance_platform,
        "pitfall_rss_rise_is_not_leak": pitfall,
        "tradeoff_pool_retains_resident": tradeoff,
        "practice_found_allocation_source": found_source,
    }
