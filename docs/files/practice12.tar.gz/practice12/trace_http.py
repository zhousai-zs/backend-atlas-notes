#!/usr/bin/env python3
"""追踪一次 HTTP 请求：记录 DNS、路由提示、端口与连接信息。

用法：
  python3 trace_http.py [host] [path]
默认：httpbin.org /

说明：
- DNS 用 socket.getaddrinfo（不依赖 dig）
- 路由提示尝试读取 `ip route get <ip>`（无权限或缺命令时跳过）
- HTTP 用 urllib 发 GET，打印状态码与部分响应头
- 用 socket 建连验证 TCP 端口 80/443
"""
from __future__ import annotations

import argparse
import socket
import subprocess
import sys
import urllib.error
import urllib.request
from typing import List, Tuple


def dns_lookup(host: str) -> List[Tuple[str, int, str]]:
    """返回 [(family_name, port_hint, ip), ...]；family 用 AF_INET/AF_INET6。"""
    results = []
    seen = set()
    for fam, _type, _proto, _canon, sockaddr in socket.getaddrinfo(
        host, None, type=socket.SOCK_STREAM
    ):
        if fam == socket.AF_INET:
            ip = sockaddr[0]
            key = ("IPv4", ip)
            if key not in seen:
                seen.add(key)
                results.append(("IPv4", 0, ip))
        elif fam == socket.AF_INET6:
            ip = sockaddr[0]
            key = ("IPv6", ip)
            if key not in seen:
                seen.add(key)
                results.append(("IPv6", 0, ip))
    return results


def route_hint(ip: str) -> str:
    try:
        out = subprocess.check_output(
            ["ip", "route", "get", ip],
            stderr=subprocess.STDOUT,
            text=True,
            timeout=5,
        )
        return out.strip()
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        return f"(跳过路由查询: {e.__class__.__name__})"


def tcp_connect(ip: str, port: int, family: int, timeout: float = 5.0) -> str:
    s = socket.socket(family, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((ip, port))
        local = s.getsockname()
        peer = s.getpeername()
        return f"OK local={local} peer={peer}"
    except OSError as e:
        return f"FAIL {e}"
    finally:
        s.close()


def http_get(url: str) -> None:
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "atlas-practice12"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            print(f"HTTP status: {resp.status}")
            # 只打印少量头，避免刷屏
            for k in ("Content-Type", "Server", "Date", "Connection"):
                if resp.headers.get(k):
                    print(f"  {k}: {resp.headers.get(k)}")
            body = resp.read(120)
            print(f"  body_prefix: {body!r}")
    except urllib.error.URLError as e:
        print(f"HTTP FAIL: {e}")


def main() -> int:
    ap = argparse.ArgumentParser(description="追踪一次 HTTP 请求")
    ap.add_argument("host", nargs="?", default="httpbin.org")
    ap.add_argument("path", nargs="?", default="/get")
    ap.add_argument("--scheme", default="https", choices=("http", "https"))
    args = ap.parse_args()

    host = args.host
    port = 443 if args.scheme == "https" else 80
    url = f"{args.scheme}://{host}{args.path}"

    print("=== 1. 应用层目标 ===")
    print(f"URL: {url}")
    print(f"域名: {host}  应用协议: HTTP/{args.scheme.upper()}  传输层端口(约定): {port}")

    print("\n=== 2. DNS：域名 → IP ===")
    addrs = dns_lookup(host)
    if not addrs:
        print("DNS 失败：无结果")
        return 1
    for fam, _, ip in addrs:
        print(f"  {fam}: {ip}")

    # 优先用第一个 IPv4，否则第一个地址
    pick = next((x for x in addrs if x[0] == "IPv4"), addrs[0])
    fam_name, _, ip = pick
    family = socket.AF_INET if fam_name == "IPv4" else socket.AF_INET6

    print("\n=== 3. 路由提示（本机如何把包送向该 IP）===")
    print(route_hint(ip))

    print(f"\n=== 4. 传输层：TCP connect {ip}:{port} ===")
    print(tcp_connect(ip, port, family))

    print("\n=== 5. 应用层：发起 HTTP GET ===")
    http_get(url)

    print("\n=== 6. 验收口述提示 ===")
    print("- MAC：二层、同链路/同广播域内寻址；跨路由器后下一跳 MAC 会变，端到端不靠目的 MAC。")
    print("- IP：三层、跨网寻址与路由转发的标识；端到端目的 IP（除 NAT 外）保持语义。")
    print("- MTU：链路上单帧/单包能承载的最大 IP 载荷相关上限；应用消息（整份 JSON/文件）可远大于 MTU，由 IP 分片或 TCP 分段完成。")
    print("全部步骤完成。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
