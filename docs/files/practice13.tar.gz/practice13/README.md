# practice13 · 关系模型与 SQL 入门

## 跑通

```bash
cd /workspace/atlas/lessons/practice13
python3 users_orders.py
```

可选：`PRACTICE13_DB=/tmp/foo.db python3 users_orders.py`

## 脚本会验证

1. 建 `users` / `orders`（PRIMARY KEY、UNIQUE openid、FOREIGN KEY）
2. 参数化插入样例数据
3. `INNER JOIN` 筛已支付订单；`LEFT JOIN` + `COUNT`/`SUM` 聚合
4. 重复主键 / 重复 openid / 无效外键 → `IntegrityError`
5. `= NULL` 对不上行；`IS NULL` 正确
6. 参数化查询 vs 危险字符串拼接（拼接仅打印，不执行）

## 本环境一次实测摘要（2026-10-31 Asia/Shanghai）

- JOIN paid：2 行（小明两单）
- 聚合：ox_fan_001 → 2 单 / 2980 分；其余见脚本输出
- 重复 id / openid / 外键均按预期失败
- `nickname IS NULL` → 1 行（ox_fan_003）
