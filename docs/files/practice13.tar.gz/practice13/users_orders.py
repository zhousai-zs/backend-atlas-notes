#!/usr/bin/env python3
"""Backend Atlas 第13课实践：users/orders 表、JOIN、主键约束、NULL、参数化查询。

用法：
  python3 users_orders.py

默认在脚本同目录创建 practice13.db；可用环境变量 PRACTICE13_DB 覆盖路径。
"""
from __future__ import annotations

import os
import sqlite3
import sys
from pathlib import Path

DB_PATH = Path(os.environ.get("PRACTICE13_DB", Path(__file__).resolve().parent / "practice13.db"))


def section(title: str) -> None:
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


def main() -> int:
    if DB_PATH.exists():
        DB_PATH.unlink()

    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA foreign_keys = ON")  # SQLite 默认关外键，必须显式打开
    cur = conn.cursor()

    # ------------------------------------------------------------------
    section("1) 建表：users + orders（主键 / 外键 / UNIQUE）")
    cur.executescript(
        """
        CREATE TABLE users (
            id          INTEGER PRIMARY KEY,
            openid      TEXT    NOT NULL UNIQUE,  -- 微信侧用户标识，业务上唯一
            nickname    TEXT,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE orders (
            id          INTEGER PRIMARY KEY,
            user_id     INTEGER NOT NULL,
            amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
            status      TEXT    NOT NULL DEFAULT 'created',
            note        TEXT,  -- 允许 NULL，后面演示 IS NULL
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        """
    )
    print("已创建 users、orders。外键：orders.user_id → users.id；openid UNIQUE。")

    # ------------------------------------------------------------------
    section("2) 插入样例数据（参数化，避免字符串拼接 SQL）")
    users = [
        (1, "ox_fan_001", "小明"),
        (2, "ox_fan_002", "小红"),
        (3, "ox_fan_003", None),  # nickname 缺失 → NULL
    ]
    cur.executemany(
        "INSERT INTO users (id, openid, nickname) VALUES (?, ?, ?)",
        users,
    )
    orders = [
        (101, 1, 990, "paid", "模板消息加购"),
        (102, 1, 1990, "paid", None),
        (103, 2, 500, "created", "待支付"),
        (104, 3, 0, "cancelled", None),
    ]
    cur.executemany(
        "INSERT INTO orders (id, user_id, amount_cents, status, note) VALUES (?, ?, ?, ?, ?)",
        orders,
    )
    conn.commit()
    print(f"插入 users={len(users)} 行, orders={len(orders)} 行。")

    # ------------------------------------------------------------------
    section("3) JOIN：用户与订单连接查询")
    rows = cur.execute(
        """
        SELECT u.id, u.openid, u.nickname, o.id AS order_id, o.amount_cents, o.status
        FROM users AS u
        INNER JOIN orders AS o ON o.user_id = u.id
        WHERE o.status = ?
        ORDER BY u.id, o.id
        """,
        ("paid",),
    ).fetchall()
    print("已支付订单（INNER JOIN + 参数化 status=?）：")
    for r in rows:
        print(" ", r)

    # 聚合：每用户订单数与金额合计
    agg = cur.execute(
        """
        SELECT u.openid,
               COUNT(o.id) AS order_cnt,
               COALESCE(SUM(o.amount_cents), 0) AS total_cents
        FROM users AS u
        LEFT JOIN orders AS o ON o.user_id = u.id
        GROUP BY u.id
        ORDER BY u.id
        """
    ).fetchall()
    print("按用户聚合（LEFT JOIN + COUNT/SUM）：")
    for r in agg:
        print(" ", r)

    # ------------------------------------------------------------------
    section("4) 故意插入重复主键 —— 应失败")
    try:
        cur.execute(
            "INSERT INTO users (id, openid, nickname) VALUES (?, ?, ?)",
            (1, "ox_dup", "重复id"),
        )
        print("ERROR: 重复主键竟然成功了（不应发生）")
        return 1
    except sqlite3.IntegrityError as e:
        print(f"预期失败 IntegrityError: {e}")

    try:
        cur.execute(
            "INSERT INTO users (id, openid, nickname) VALUES (?, ?, ?)",
            (99, "ox_fan_001", "重复openid"),
        )
        print("ERROR: 重复 UNIQUE(openid) 竟然成功了")
        return 1
    except sqlite3.IntegrityError as e:
        print(f"预期失败 UNIQUE(openid): {e}")

    try:
        cur.execute(
            "INSERT INTO orders (id, user_id, amount_cents, status) VALUES (?, ?, ?, ?)",
            (201, 999, 100, "created"),
        )
        print("ERROR: 外键违规竟然成功了")
        return 1
    except sqlite3.IntegrityError as e:
        print(f"预期失败 FOREIGN KEY: {e}")

    # ------------------------------------------------------------------
    section("5) NULL 比较：= NULL 无效，要用 IS NULL")
    wrong = cur.execute(
        "SELECT id, openid, nickname FROM users WHERE nickname = ?",
        (None,),
    ).fetchall()
    # 上面用参数 None 时，SQLite 的「= ?」绑定 NULL 同样得不到行（三值逻辑）
    wrong_literal = cur.execute(
        "SELECT id, openid, nickname FROM users WHERE nickname = NULL"
    ).fetchall()
    right = cur.execute(
        "SELECT id, openid, nickname FROM users WHERE nickname IS NULL"
    ).fetchall()
    print(f"WHERE nickname = NULL     → {len(wrong_literal)} 行（错误用法，通常为空）")
    print(f"WHERE nickname = ? (None) → {len(wrong)} 行（等号绑 NULL 同样对不上）")
    print(f"WHERE nickname IS NULL    → {len(right)} 行：{right}")

    note_null = cur.execute(
        "SELECT id, note FROM orders WHERE note IS NULL"
    ).fetchall()
    print(f"orders.note IS NULL → {note_null}")

    # ------------------------------------------------------------------
    section("6) 参数化 vs 危险拼接（演示对比，不执行拼接查询）")
    # 安全：占位符
    openid = "ox_fan_002"
    safe = cur.execute(
        "SELECT id, openid, nickname FROM users WHERE openid = ?",
        (openid,),
    ).fetchone()
    print(f"参数化查询结果: {safe}")

    # 危险写法仅展示字符串，绝不 execute
    evil_input = "ox_fan_002' OR '1'='1"
    dangerous = f"SELECT id, openid, nickname FROM users WHERE openid = '{evil_input}'"
    print("危险拼接示例（切勿执行）:")
    print(" ", dangerous)
    print("正确做法：永远用 ? / :name 占位符 + 参数元组/字典。")

    conn.close()
    section("全部步骤完成")
    print(f"数据库文件: {DB_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
