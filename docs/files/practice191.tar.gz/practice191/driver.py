#!/usr/bin/env python3
"""Structured query_logs tool: tenant, time range, error_code. No SQL/shell concat.

Bodies and Authorization headers are redacted. Cross-tenant and unbounded
ranges are rejected. Every conclusion cites a request_id that appears in the
tool output.
"""
from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)

LOGS = []
for line in (ROOT / "data/logs.jsonl").read_text(encoding="utf-8").splitlines():
    if line.strip():
        LOGS.append(json.loads(line))

MAX_RANGE_S = 3600
MAX_ROWS = 50
REDACT_PATTERNS = [
    (re.compile(r"Bearer\s+\S+", re.I), "Bearer [REDACTED]"),
    (re.compile(r"sk-[A-Za-z0-9-]+"), "sk-[REDACTED]"),
]


def parse_ts(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def redact(text: str | None) -> str | None:
    if text is None:
        return None
    out = text
    for pat, repl in REDACT_PATTERNS:
        out = pat.sub(repl, out)
    # Never return a full request body; keep only a short, redacted preview.
    if "\n" in out or len(out) > 40:
        out = out.split("\n")[0][:40] + " [BODY_REDACTED]"
    return out


def query_logs(tenant: str, service: str, start: str, end: str, error_code: str | None = None) -> dict:
    """Structured query. Arguments are bound fields, never concatenated into SQL or shell."""
    if not tenant or not service:
        return {"ok": False, "error": "tenant and service are required"}
    try:
        t0, t1 = parse_ts(start), parse_ts(end)
    except ValueError as e:
        return {"ok": False, "error": f"invalid timestamp: {e}"}
    if t1 <= t0:
        return {"ok": False, "error": "end must be after start"}
    if (t1 - t0).total_seconds() > MAX_RANGE_S:
        return {"ok": False, "error": f"unbounded or too-wide range: max {MAX_RANGE_S}s"}

    rows = []
    for rec in LOGS:
        if rec["tenant"] != tenant:
            # cross-tenant rows are not returned (and not "filtered at display")
            continue
        if rec["service"] != service:
            continue
        ts = parse_ts(rec["ts"])
        if not (t0 <= ts <= t1):
            continue
        if error_code is not None and rec.get("error_code") != error_code:
            continue
        rows.append({
            "tenant": rec["tenant"],
            "service": rec["service"],
            "ts": rec["ts"],
            "error_code": rec.get("error_code"),
            "request_id": rec["request_id"],
            "message": rec["message"],
            "level": rec["level"],
            "request_body_preview": redact(rec.get("request_body")),
        })
        if len(rows) >= MAX_ROWS:
            break
    return {"ok": True, "rows": rows, "n": len(rows)}


# Happy path
ok = query_logs("acme", "kv", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z", "EXISTS_UNIMPL")
# Cross-tenant attempt: requesting tenant=acme must not include R-99 (other)
# Direct attempt to spoof: tool only accepts the tenant field, no raw SQL.
cross = query_logs("acme", "kv", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z", "EXISTS_UNIMPL")
# Reject unbounded range (2 hours)
wide = query_logs("acme", "kv", "2026-11-15T14:00:00Z", "2026-11-15T16:05:00Z", "EXISTS_UNIMPL")
# Missing tenant
missing = query_logs("", "kv", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z", "EXISTS_UNIMPL")
# If someone tries to pass SQL in service, it is a literal service name, not executed.
sqli = query_logs("acme", "kv; drop table logs", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z", None)

blob = json.dumps({"ok": ok, "cross": cross, "sqli": sqli}, ensure_ascii=False)
secret_leaked = any(s in blob for s in ("sk-live-AAA", "sk-live-BBB", "sk-other", "Authorization: Bearer sk-"))
other_tenant_leaked = "R-99" in json.dumps(ok)
gateway_leaked = "R-50" in json.dumps(ok)  # different service, must not appear

# Scripted diagnosis citing request ids
cited = [row["request_id"] for row in ok["rows"]]
diagnosis = {
    "observation": f"kv for tenant acme returned {ok['n']} EXISTS_UNIMPL errors in the 5-minute window.",
    "evidence": cited,
    "inference": "The error_code matches a missing exists implementation; this tool result does not by itself prove a code change is already deployed.",
}
# Every cited id is in the tool output.
assert all(any(r["request_id"] == eid for r in ok["rows"]) for eid in diagnosis["evidence"])

results = {
    "lesson": 191,
    "id": "m-logs",
    "is_live_model": False,
    "ok_n": ok["n"],
    "ok_ids": cited,
    "unbounded_rejected": wide["ok"] is False and "range" in wide["error"],
    "missing_tenant_rejected": missing["ok"] is False,
    "cross_tenant_not_returned": not other_tenant_leaked,
    "other_service_not_returned": not gateway_leaked,
    "sql_literal_not_executed": sqli["ok"] is True and sqli["n"] == 0,
    "no_full_sensitive_body": secret_leaked is False and "BODY_REDACTED" in blob,
    "every_conclusion_cites_request_id": diagnosis["evidence"] == cited and cited,
    "diagnosis": diagnosis,
    "verified_on_this_machine": [
        "structured query_logs with tenant/service/time/error_code",
        "unbounded range and missing tenant rejected",
        "cross-tenant and other-service rows not returned",
        "Authorization / secret material redacted; full body not returned",
        "SQL/shell strings are bound literals, not executed",
    ],
    "not_verified_on_this_machine": [
        "a production log backend or OpenTelemetry collector",
    ],
}
checks = {k: results[k] for k in (
    "unbounded_rejected", "missing_tenant_rejected", "cross_tenant_not_returned",
    "other_service_not_returned", "sql_literal_not_executed", "no_full_sensitive_body",
    "every_conclusion_cites_request_id",
)}
if not all(checks.values()) or results["ok_n"] != 2:
    raise SystemExit(f"checks failed: {checks} n={results['ok_n']}")

(REPORTS / "query_ok.json").write_text(json.dumps(ok, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("OK_IDS", cited)
print("WIDE", wide)
print("ALL_CHECKS_PASSED")
