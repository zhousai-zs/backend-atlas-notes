#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["is_live_model"] is False
assert r["ok_n"]==2 and r["cross_tenant_not_returned"] and r["unbounded_rejected"]
assert r["no_full_sensitive_body"] and r["every_conclusion_cites_request_id"]
assert "sk-live-AAA" not in log and "sk-live-BBB" not in Path("results.json").read_text()
print("POSTCHECK_OK")
PY
