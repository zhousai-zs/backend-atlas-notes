#include <coroutine>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <utility>

// Teaching bug: a coroutine stores a pointer into a caller's short-lived
// stack string, suspends, and dereferences it after that string is gone.

struct Task {
  struct promise_type {
    Task get_return_object() { return Task{std::coroutine_handle<promise_type>::from_promise(*this)}; }
    std::suspend_always initial_suspend() { return {}; }
    std::suspend_always final_suspend() noexcept { return {}; }
    void return_void() {}
    void unhandled_exception() { std::terminate(); }
  };
  std::coroutine_handle<promise_type> h;
  explicit Task(std::coroutine_handle<promise_type> h_) : h(h_) {}
  Task(const Task&) = delete;
  Task& operator=(const Task&) = delete;
  Task(Task&& o) noexcept : h(std::exchange(o.h, {})) {}
  ~Task() { if (h) h.destroy(); }
  void resume() { if (h && !h.done()) h.resume(); }
};

struct Delay {
  bool await_ready() const noexcept { return false; }
  void await_suspend(std::coroutine_handle<>) const {
    std::this_thread::sleep_for(std::chrono::milliseconds(5));
  }
  void await_resume() const noexcept {}
};

#if defined(FIX) && FIX
Task process(std::string owned, std::string* out) {
  co_await Delay{};
  out->assign(owned);
  co_return;
}
static Task make_task(std::string* out) { return process(std::string("live-token"), out); }
#else
Task process(const char* p, std::string* out) {
  co_await Delay{};
  out->assign(p);
  co_return;
}
static Task make_task(std::string* out) {
  std::string local = "live-token";
  return process(local.c_str(), out);
}
#endif

int main(int argc, char** argv) {
  const char* mode = (argc > 1) ? argv[1] : "once";
  if (std::strcmp(mode, "bench") == 0) {
    auto t0 = std::chrono::steady_clock::now();
    const int N = 2000;
    for (int i = 0; i < N; i++) {
      std::string out;
      Task t = make_task(&out);
      t.resume();
      t.resume();
    }
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::steady_clock::now() - t0).count();
    std::printf("BENCH n=%d us=%lld us_per=%g\n", N, (long long)us, double(us) / N);
    return 0;
  }
  std::string out = "UNSET";
  Task t = make_task(&out);
  t.resume();
  t.resume();
  std::printf("OUT %s\n", out.c_str());
  return 0;
}
