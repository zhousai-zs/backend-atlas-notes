# 协程跨挂起点后使用临时参数的引用（公开实验）

问题定义：调用方把短生命周期栈上 `std::string` 的 `c_str()` 交给协程，协程在 `co_await` 之后才解引用该指针。此时栈对象已销毁。

复现（公开、可重复）：在本实践目录执行 `bash test.sh`。错误实现用 clang 22.1.8 加上 AddressSanitizer 编译，运行后应报告 stack-use-after-scope 或同等 AddressSanitizer 错误，退出码非 0。本次日志摘要见 reports/asan-bad.txt。

修复：协程按值接收 `std::string owned`，字符串随协程帧一起活过挂起点。同一套 ASan 编译运行应打印 `OUT live-token` 且无 sanitizer 报错。

基准：对修复后的实现跑 2000 次创建/恢复，结果写入 reports/bench.txt（BENCH n=2000 us=10214942 us_per=5107.47）。这是本机微基准，不是生产调度器数字。

局限与适用条件：实验在本机 zig c++ / clang 22.1.8 与 libasan.so.8 上进行，只覆盖「调用方栈上字符串指针跨协程挂起点使用」这一种缺陷；不声称覆盖所有协程竞态，也不公开任何内部主机名、客户数据或私有地址。结论可由上述命令复核。
