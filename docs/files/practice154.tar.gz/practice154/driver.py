#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

from app_contract import run as run_app_contract
from static_check import run as run_static

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def cluster_probe() -> dict:
    kubectl = shutil.which("kubectl")
    if not kubectl:
        return {"kubectl": None, "cluster": False, "reason": "NO_KUBECTL"}
    p = subprocess.run([kubectl, "cluster-info"], capture_output=True, text=True, timeout=10)
    if p.returncode != 0:
        return {"kubectl": kubectl, "cluster": False, "reason": "NO_USABLE_CLUSTER", "stderr": p.stderr[-500:]}
    return {"kubectl": kubectl, "cluster": True, "reason": None}


def run_cluster_e2e() -> dict:
    script = ROOT / "scripts" / "rollout-e2e.sh"
    p = subprocess.run(["bash", str(script)], capture_output=True, text=True, timeout=300)
    (REPORTS / "rollout-e2e.log").write_text(f"exit={p.returncode}\n{p.stdout}\n{p.stderr}\n")
    if p.returncode == 0:
        return {"attempted": True, "verified": True, "exit": 0, "skip_reason": None}
    if p.returncode == 2:
        return {
            "attempted": True,
            "verified": False,
            "exit": 2,
            "skip_reason": (p.stdout or p.stderr).strip().splitlines()[-1] if (p.stdout or p.stderr) else "no_cluster",
        }
    return {"attempted": True, "verified": False, "failed": True, "exit": p.returncode, "stdout": p.stdout[-2000:], "stderr": p.stderr[-2000:]}


def main() -> int:
    static = run_static()
    assert static["ok"], static["errors"]
    app = run_app_contract()
    assert app["ready_before"] == 200 and app["live_before"] == 200 and app["work_before"] == 200, app
    assert app["ready_after_sigterm"] == 503, app
    assert app["exit"] == 0, app
    cluster = cluster_probe()
    e2e = run_cluster_e2e()
    if e2e.get("failed"):
        print(json.dumps(e2e, indent=2))
        print("CLUSTER_E2E_FAILED")
        return 1

    verified = [
        "manifest_replicas_2_and_distinct_startup_readiness_liveness_paths",
        "manifest_requests_limits_preStop_terminationGracePeriodSeconds",
        "counterexample_liveness_on_dependency_is_flagged",
        "app_process_readiness_flips_on_SIGTERM_while_liveness_stayed_200_before_exit",
    ]
    unverified = []
    if not e2e["verified"]:
        unverified.extend(
            [
                "kubectl_apply_and_rolling_update_on_a_real_cluster",
                "Service_endpoints_drop_on_readiness_failure_without_a_restart",
                "liveness_failure_restart_count_from_kubelet",
                "in_flight_requests_during_a_real_rolling_update",
                "kubelet_enforced_requests_and_limits",
            ]
        )

    results = {
        "lesson": 154,
        "id": "j-kubernetes",
        "is_live_cluster": bool(e2e["verified"]),
        "cluster_e2e_verified": bool(e2e["verified"]),
        "cluster": cluster,
        "cluster_e2e": e2e,
        "manifest_static": static,
        "app_contract": app,
        "python_pod_simulator_used_as_kube_acceptance": False,
        "verified_on_this_machine": verified,
        "not_verified_on_this_machine": unverified,
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
    if not e2e["verified"]:
        assert unverified and results["is_live_cluster"] is False
        assert results["python_pod_simulator_used_as_kube_acceptance"] is False
    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
