#!/usr/bin/env python3
from __future__ import annotations

import json, os, signal, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
PY = sys.executable


def http_json(url, timeout=1.0):
    req = urllib.request.Request(url, headers={"User-Agent": "practice154"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode()), dict(r.headers)
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            obj = json.loads(body)
        except Exception:
            obj = {"raw": body}
        return e.code, obj, dict(e.headers)
    except Exception as e:
        return None, {"error": f"{type(e).__name__}: {e}"}, {}


def wait_probe(url, expect=200, timeout=3.0):
    t0 = time.time()
    last = None
    while time.time() - t0 < timeout:
        last = http_json(url, timeout=0.3)
        if last[0] == expect:
            return True, last
        time.sleep(0.03)
    return False, last


def start_pod(name, port, version, extra=None, ready_override=None, dep=None):
    env = os.environ.copy()
    env.update({
        "POD_NAME": name,
        "POD_PORT": str(port),
        "POD_VERSION": version,
        "POD_STATUS": str(REPORTS / f"{name}.json"),
        "WORK_SECONDS": "0.08",
        "STARTUP_DELAY": "0.12",
    })
    if ready_override:
        env["READY_OVERRIDE"] = ready_override
    if dep:
        env["LIVE_DEPENDS_ON"] = dep
    if extra:
        env.update(extra)
    proc = subprocess.Popen([PY, str(ROOT / "pod.py")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return proc


def endpoints(pods):
    ready = []
    for p in pods:
        code, _, _ = http_json(f"http://127.0.0.1:{p['port']}/readyz", timeout=0.3)
        if code == 200:
            ready.append(p)
    return ready


def call_work(pods):
    ready = endpoints(pods)
    if not ready:
        return {"ok": False, "reason": "no_ready_endpoint"}
    # pick first ready (teaching LB)
    p = ready[0]
    code, body, hdr = http_json(f"http://127.0.0.1:{p['port']}/work", timeout=1.5)
    return {"ok": code == 200, "code": code, "body": body, "pod": p["name"], "version": body.get("version") if isinstance(body, dict) else None}


def terminate(proc, grace=1.5):
    proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=grace)
        return proc.returncode
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=1)
        return "killed"


def main():
    results = {"lesson": 154, "id": "j-kubernetes", "is_live_cluster": False, "runtime": "local teaching pods, not kube-apiserver"}
    ports = [18791, 18792, 18793]

    # --- A. readiness failure does not restart ---
    dep_missing = str(REPORTS / "missing-dep")
    if Path(dep_missing).exists():
        Path(dep_missing).unlink()
    a = start_pod("ready-fail", ports[0], "v1", ready_override="fail")
    pods_a = [{"name": "ready-fail", "port": ports[0], "proc": a}]
    ok_s, _ = wait_probe(f"http://127.0.0.1:{ports[0]}/startupz", 200, 2.0)
    code_r, _, _ = http_json(f"http://127.0.0.1:{ports[0]}/readyz")
    code_l, _, _ = http_json(f"http://127.0.0.1:{ports[0]}/healthz")
    time.sleep(0.3)
    still_running = a.poll() is None
    results["readiness_fail"] = {
        "startup_ok": ok_s,
        "ready_code": code_r,
        "live_code": code_l,
        "process_still_running": still_running,
        "restarts": 0,
        "work": call_work(pods_a),
    }
    assert still_running and code_r == 503 and code_l == 200
    assert results["readiness_fail"]["work"]["ok"] is False
    terminate(a)

    # --- B. liveness depending on another service: restart storm ---
    restarts = 0
    proc = start_pod("live-dep", ports[0], "v1", dep=dep_missing)
    wait_probe(f"http://127.0.0.1:{ports[0]}/startupz", 200, 2.0)
    # controller loop: if liveness fails, restart
    for i in range(3):
        code, _, _ = http_json(f"http://127.0.0.1:{ports[0]}/healthz")
        if code != 200:
            terminate(proc)
            restarts += 1
            proc = start_pod("live-dep", ports[0], "v1", dep=dep_missing)
            wait_probe(f"http://127.0.0.1:{ports[0]}/startupz", 200, 2.0)
        time.sleep(0.05)
    terminate(proc)
    results["liveness_storm_restarts"] = restarts
    assert restarts >= 3

    # --- C. rolling update of two replicas, count failures, graceful drain ---
    p1 = start_pod("rep-a", ports[0], "v1")
    p2 = start_pod("rep-b", ports[1], "v1")
    pods = [
        {"name": "rep-a", "port": ports[0], "proc": p1, "version": "v1"},
        {"name": "rep-b", "port": ports[1], "proc": p2, "version": "v1"},
    ]
    assert wait_probe(f"http://127.0.0.1:{ports[0]}/readyz", 200, 2.0)[0]
    assert wait_probe(f"http://127.0.0.1:{ports[1]}/readyz", 200, 2.0)[0]

    stats = {"ok": 0, "fail": 0, "versions": [], "codes": []}

    def burst(n=20):
        for _ in range(n):
            r = call_work(pods)
            stats["ok" if r["ok"] else "fail"] += 1
            stats["codes"].append(r.get("code"))
            if r.get("version"):
                stats["versions"].append(r["version"])

    burst(8)
    # start a new v2 replica (surge), wait ready, then terminate one v1 during an in-flight request
    p3 = start_pod("rep-c", ports[2], "v2")
    pods.append({"name": "rep-c", "port": ports[2], "proc": p3, "version": "v2"})
    assert wait_probe(f"http://127.0.0.1:{ports[2]}/readyz", 200, 2.0)[0]

    # in-flight: start a work call in a thread against the v1 pod we will terminate
    import threading
    inflight = {}

    def long_call():
        inflight["result"] = http_json(f"http://127.0.0.1:{ports[0]}/work", timeout=2.0)

    t = threading.Thread(target=long_call)
    t.start()
    time.sleep(0.02)
    rc = terminate(pods[0]["proc"], grace=2.0)
    t.join(timeout=2.0)
    inflight_code, inflight_body, _ = inflight.get("result", (None, {}, {}))
    results["terminate_inflight"] = {
        "pod_exit": rc,
        "http_code": inflight_code,
        "body": inflight_body,
        "completed_or_rejected": inflight_code in (200, 503),
    }
    assert results["terminate_inflight"]["completed_or_rejected"]
    # remove terminated pod from endpoint list
    pods[:] = [p for p in pods if p["name"] != "rep-a"]
    burst(12)

    # terminate remaining v1
    terminate(pods[0]["proc"])
    pods[:] = [p for p in pods if p["name"] != "rep-b"]
    burst(8)
    terminate(pods[0]["proc"])

    results["rollout"] = {
        "ok": stats["ok"],
        "fail": stats["fail"],
        "seen_versions": sorted(set(stats["versions"])),
        "total": stats["ok"] + stats["fail"],
    }
    assert "v1" in results["rollout"]["seen_versions"] and "v2" in results["rollout"]["seen_versions"]
    # requests/limits are declared in the teaching spec only
    results["declared_resources"] = {"requests": {"cpu": "100m", "memory": "64Mi"}, "limits": {"cpu": "200m", "memory": "128Mi"}}
    results["resource_limits_enforced_here"] = False
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    (REPORTS / "rollout.txt").write_text(json.dumps(results, indent=2))
    print(json.dumps(results, ensure_ascii=False, indent=2))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
