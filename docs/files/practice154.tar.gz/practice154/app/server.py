#!/usr/bin/env python3
"""Tiny HTTP service used by the Deployment manifest.

Endpoints:
  /startupz  — process finished booting
  /healthz   — liveness: this process is not deadlocked (does not check deps)
  /readyz    — readiness: this process will accept traffic (optionally deps)
  /work      — business request; honors SIGTERM drain
"""

from __future__ import annotations

import json
import os
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = os.environ.get("APP_VERSION", "v1")
PORT = int(os.environ.get("PORT", "8080"))
START_DELAY = float(os.environ.get("START_DELAY", "0"))
READY_DEPENDENCY_URL = os.environ.get("READY_DEPENDENCY_URL", "")
# Liveness must not be tied to a dependency. This flag exists only so a
# *wrong* wrapper can be demonstrated in docs; the default server does not
# use it on /healthz.
MISUSE_LIVENESS_DEPENDENCY = os.environ.get("MISUSE_LIVENESS_DEPENDENCY", "")

stopping = False
started_at = 0.0
lock = threading.Lock()


def _on_term(signum, frame):
    global stopping
    stopping = True


signal.signal(signal.SIGTERM, _on_term)
signal.signal(signal.SIGINT, _on_term)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send(self, code: int, body: dict):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        now = time.time()
        if self.path == "/startupz":
            ok = now - started_at >= START_DELAY
            return self._send(200 if ok else 503, {"ok": ok, "probe": "startup"})
        if self.path == "/healthz":
            # Intentionally independent of READY_DEPENDENCY_URL.
            return self._send(200, {"ok": True, "probe": "liveness", "version": VERSION})
        if self.path == "/readyz":
            if stopping:
                return self._send(503, {"ok": False, "reason": "draining"})
            if now - started_at < START_DELAY:
                return self._send(503, {"ok": False, "reason": "starting"})
            return self._send(200, {"ok": True, "probe": "readiness", "version": VERSION})
        if self.path == "/work":
            if stopping:
                return self._send(503, {"ok": False, "reason": "draining"})
            if now - started_at < START_DELAY:
                return self._send(503, {"ok": False, "reason": "starting"})
            time.sleep(float(os.environ.get("WORK_DELAY", "0.05")))
            return self._send(200, {"ok": True, "version": VERSION})
        return self._send(404, {"ok": False})


def main():
    global started_at
    started_at = time.time()
    httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    drain = float(os.environ.get("DRAIN_SECONDS", "0.4"))
    deadline = None
    while True:
        httpd.timeout = 0.05
        httpd.handle_request()
        if stopping:
            if deadline is None:
                deadline = time.time() + drain
            if time.time() >= deadline:
                break
    httpd.server_close()


if __name__ == "__main__":
    main()
