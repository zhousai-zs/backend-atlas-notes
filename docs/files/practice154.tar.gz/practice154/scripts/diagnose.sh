#!/usr/bin/env bash
set -euo pipefail
cat <<'TXT'
1. Need kubectl and a cluster (kind / k3s / minikube / a lab cluster):
     kubectl version --client
     kubectl cluster-info
2. Apply the teaching manifests:
     kubectl apply -f manifests/service.yaml -f manifests/deployment.yaml
     kubectl get pods -l app=atlas-kv -o wide
     kubectl describe pod -l app=atlas-kv | sed -n '/Conditions/,/Events/p'
3. Readiness vs liveness:
     # Make a pod not ready (for example delete its endpoints or exec a drain)
     # observe: it leaves the Service endpoints, but it is not restarted only for readiness.
     kubectl get endpoints atlas-kv -w
4. Rolling update while curling:
     while true; do curl -sS --max-time 1 http://<svc>/work; echo; sleep 0.2; done
     kubectl apply -f manifests/deployment-v2.yaml
     kubectl rollout status deployment/atlas-kv
     kubectl rollout history deployment/atlas-kv
5. Resource limits are *declared* in the manifest. Confirm they are actually
   enforced by the kubelet/cgroup on that cluster (kubectl describe / metrics),
   do not assume a YAML field is a running cap.
6. Do not apply manifests/bad-liveness-on-dependency.yaml except as a deliberate
   negative demo in a disposable namespace.
TXT
