#!/usr/bin/env bash
# Live cluster acceptance. Exit 0 = rollout observed. Exit 2 = no cluster.
# Exit 1 = cluster present but checks failed.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if ! command -v kubectl >/dev/null 2>&1; then
  echo "NO_KUBECTL"
  exit 2
fi
if ! kubectl cluster-info >/dev/null 2>&1; then
  echo "NO_USABLE_CLUSTER"
  exit 2
fi
NS="${KUBE_NAMESPACE:-atlas-154}"
kubectl create namespace "$NS" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n "$NS" apply -f "$ROOT/manifests/service.yaml" -f "$ROOT/manifests/deployment.yaml"
kubectl -n "$NS" rollout status deployment/atlas-kv --timeout=180s
# Continuous requests during the v2 rollout.
fail=0
ok=0
pipe="$(mktemp -u)"
# Best-effort port-forward
kubectl -n "$NS" port-forward svc/atlas-kv 18080:80 >/tmp/atlas-154-pf.log 2>&1 &
pf=$!
trap 'kill $pf 2>/dev/null || true' EXIT
sleep 1
kubectl -n "$NS" apply -f "$ROOT/manifests/deployment-v2.yaml"
# sample for a while while rollout proceeds
for i in $(seq 1 40); do
  if curl -fsS --max-time 1 http://127.0.0.1:18080/work >/tmp/atlas-154-work.json; then
    ok=$((ok+1))
  else
    fail=$((fail+1))
  fi
  sleep 0.2
done
kubectl -n "$NS" rollout status deployment/atlas-kv --timeout=180s
echo "rollout_samples ok=$ok fail=$fail"
if [[ "$ok" -lt 1 ]]; then
  echo "NO_SUCCESSFUL_REQUESTS"
  exit 1
fi
echo "CLUSTER_E2E_PASSED"
