"""One teaching pod process: work handler + startup/readiness/liveness + SIGTERM."""
from __future__ import annotations

import json, os, signal, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

state = {
    "version": os.environ.get("POD_VERSION", "v1"),
    "name": os.environ.get("POD_NAME", "pod"),
    "startup_ok": False,
    "ready": False,
    "live": True,
    "terminating": False,
    "in_flight": 0,
    "completed": 0,
    "rejected": 0,
    "started_at": time.time(),
    "startup_delay": float(os.environ.get("STARTUP_DELAY", "0.15")),
    "work_seconds": float(os.environ.get("WORK_SECONDS", "0.08")),
    "ready_override": os.environ.get("READY_OVERRIDE"),  # "fail" forces not ready
    "live_depends_on": os.environ.get("LIVE_DEPENDS_ON"),  # url, pitfall
}


def maybe_dep_ok() -> bool:
    dep = state["live_depends_on"]
    if not dep:
        return True
    # teaching dependency: a file that must exist
    return os.path.exists(dep)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Pod", state["name"])
        self.send_header("X-Version", state["version"])
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/startupz":
            self._send(200 if state["startup_ok"] else 503, {"startup": state["startup_ok"]})
            return
        if path == "/readyz":
            ok = state["startup_ok"] and state["ready"] and not state["terminating"]
            if state["ready_override"] == "fail":
                ok = False
            self._send(200 if ok else 503, {"ready": ok})
            return
        if path == "/healthz":
            ok = state["live"] and maybe_dep_ok()
            self._send(200 if ok else 503, {"live": ok})
            return
        if path == "/work":
            if state["terminating"] or not state["ready"] or not state["startup_ok"]:
                state["rejected"] += 1
                self._send(503, {"ok": False, "reason": "not_serving", "version": state["version"]})
                return
            state["in_flight"] += 1
            try:
                time.sleep(state["work_seconds"])
                if state["terminating"]:
                    # still finish the in-flight request
                    pass
                state["completed"] += 1
                self._send(200, {"ok": True, "version": state["version"], "pod": state["name"]})
            finally:
                state["in_flight"] -= 1
            return
        if path == "/status":
            self._send(200, {k: state[k] for k in state if k != "started_at"} | {"in_flight": state["in_flight"]})
            return
        self._send(404, {"ok": False})


def become_ready():
    time.sleep(state["startup_delay"])
    state["startup_ok"] = True
    state["ready"] = True


def on_term(signum, frame):
    state["terminating"] = True
    state["ready"] = False


def main():
    signal.signal(signal.SIGTERM, on_term)
    host, port = "127.0.0.1", int(os.environ["POD_PORT"])
    threading.Thread(target=become_ready, daemon=True).start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    while not state["terminating"] or state["in_flight"] > 0:
        httpd.timeout = 0.05
        httpd.handle_request()
    # give a last status file
    Path = __import__("pathlib").Path
    out = os.environ.get("POD_STATUS")
    if out:
        Path(out).write_text(json.dumps({"completed": state["completed"], "rejected": state["rejected"], "version": state["version"]}))
    sys.exit(0)


if __name__ == "__main__":
    main()
