"""Application-level probe contract.

This starts the teaching server as a normal process. It can show that
*this program* returns 503 on /readyz while still answering 200 on /healthz
and staying alive. It does not prove what kube-apiserver or kubelet will do.
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _get(url: str) -> tuple[int, dict | str]:
    try:
        with urllib.request.urlopen(url, timeout=1) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, body


def run() -> dict:
    port = 18754
    env = os.environ.copy()
    env.update({"PORT": str(port), "APP_VERSION": "v1", "START_DELAY": "0", "WORK_DELAY": "0.05"})
    proc = subprocess.Popen(
        [sys.executable, str(ROOT / "app" / "server.py")],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    base = f"http://127.0.0.1:{port}"
    try:
        deadline = time.time() + 3
        while time.time() < deadline:
            try:
                code, _ = _get(base + "/healthz")
                if code == 200:
                    break
            except Exception:
                time.sleep(0.05)
        ready_before, _ = _get(base + "/readyz")
        live_before, _ = _get(base + "/healthz")
        work_before, _ = _get(base + "/work")
        # drain: SIGTERM should flip readiness and still allow a short window
        proc.send_signal(signal.SIGTERM)
        time.sleep(0.12)
        try:
            ready_after, ready_body = _get(base + "/readyz")
        except Exception as e:
            ready_after, ready_body = -1, str(e)
        still_running = proc.poll() is None
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=2)
            raise SystemExit("server did not exit after SIGTERM")
        return {
            "scope": "local_process_only_not_kubelet",
            "ready_before": ready_before,
            "live_before": live_before,
            "work_before": work_before,
            "ready_after_sigterm": ready_after,
            "ready_body": ready_body,
            "still_running_when_readiness_flipped": still_running or ready_after == 503,
            "exit": proc.returncode,
        }
    finally:
        if proc.poll() is None:
            proc.kill()
