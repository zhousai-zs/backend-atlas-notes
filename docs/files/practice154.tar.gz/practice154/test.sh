#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["python_pod_simulator_used_as_kube_acceptance"] is False
assert r["manifest_static"]["ok"] is True
assert r["manifest_static"]["liveness_path"] == "/healthz"
assert r["manifest_static"]["readiness_path"] == "/readyz"
if r["cluster_e2e_verified"]:
    assert r["is_live_cluster"] is True
else:
    assert r["is_live_cluster"] is False
    assert r["not_verified_on_this_machine"]
print("POSTCHECK_OK")
PY
