"""Structural checks on teaching Kubernetes manifests. Does not contact a cluster."""

from __future__ import annotations

from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
MAN = ROOT / "manifests"


def load(name: str):
    return list(yaml.safe_load_all((MAN / name).read_text()))


def _container(doc):
    return doc["spec"]["template"]["spec"]["containers"][0]


def check_main(doc: dict, expect_version: str) -> list[str]:
    errs: list[str] = []
    if doc.get("kind") != "Deployment":
        return ["not_deployment"]
    spec = doc["spec"]
    if spec.get("replicas") != 2:
        errs.append(f"replicas_not_2:{spec.get('replicas')}")
    ru = (spec.get("strategy") or {}).get("rollingUpdate") or {}
    if ru.get("maxUnavailable") not in (0, "0", "0%"):
        errs.append(f"maxUnavailable_not_zero:{ru.get('maxUnavailable')}")
    pod = spec["template"]["spec"]
    if not pod.get("terminationGracePeriodSeconds"):
        errs.append("missing_terminationGracePeriodSeconds")
    c = pod["containers"][0]
    res = c.get("resources") or {}
    for key in ("requests", "limits"):
        block = res.get(key) or {}
        if "cpu" not in block or "memory" not in block:
            errs.append(f"missing_resources_{key}")
    probes = {
        "startupProbe": "/startupz",
        "readinessProbe": "/readyz",
        "livenessProbe": "/healthz",
    }
    for field, path in probes.items():
        probe = c.get(field) or {}
        got = ((probe.get("httpGet") or {}).get("path"))
        if got != path:
            errs.append(f"{field}_path:{got}")
    live_path = ((c.get("livenessProbe") or {}).get("httpGet") or {}).get("path")
    ready_path = ((c.get("readinessProbe") or {}).get("httpGet") or {}).get("path")
    if live_path == ready_path:
        errs.append("liveness_and_readiness_use_same_path")
    if live_path in {"/dependency-health", "/readyz"}:
        errs.append("liveness_tied_to_readiness_or_dependency")
    pre = ((c.get("lifecycle") or {}).get("preStop") or {})
    if not pre:
        errs.append("missing_preStop")
    env = {e["name"]: e.get("value") for e in c.get("env") or []}
    if env.get("APP_VERSION") != expect_version:
        errs.append(f"version:{env.get('APP_VERSION')}")
    return errs


def check_bad_counterexample(doc: dict) -> list[str]:
    """The counterexample must be *detectably* unsafe so students can contrast it."""
    missing: list[str] = []
    c = doc["spec"]["template"]["spec"]["containers"][0]
    live = ((c.get("livenessProbe") or {}).get("httpGet") or {}).get("path")
    if live != "/dependency-health":
        missing.append("expected_bad_liveness_path")
    if c.get("readinessProbe"):
        missing.append("counterexample_should_omit_readiness_for_contrast")
    if c.get("resources"):
        missing.append("counterexample_unexpectedly_has_resources")
    return missing


def check_service(doc: dict) -> list[str]:
    errs: list[str] = []
    if doc.get("kind") != "Service":
        return ["not_service"]
    if (doc["spec"].get("selector") or {}).get("app") != "atlas-kv":
        errs.append("selector")
    return errs


def run() -> dict:
    v1 = load("deployment.yaml")[0]
    v2 = load("deployment-v2.yaml")[0]
    svc = load("service.yaml")[0]
    bad = load("bad-liveness-on-dependency.yaml")[0]
    errors = {
        "deployment_v1": check_main(v1, "v1"),
        "deployment_v2": check_main(v2, "v2"),
        "service": check_service(svc),
        "counterexample_expected_defects_missing": check_bad_counterexample(bad),
    }
    ok = all(len(v) == 0 for v in errors.values())
    return {
        "ok": ok,
        "errors": errors,
        "proves_cluster_ran_a_rollout": False,
        "replicas": v1["spec"]["replicas"],
        "liveness_path": v1["spec"]["template"]["spec"]["containers"][0]["livenessProbe"]["httpGet"]["path"],
        "readiness_path": v1["spec"]["template"]["spec"]["containers"][0]["readinessProbe"]["httpGet"]["path"],
        "startup_path": v1["spec"]["template"]["spec"]["containers"][0]["startupProbe"]["httpGet"]["path"],
        "terminationGracePeriodSeconds": v1["spec"]["template"]["spec"]["terminationGracePeriodSeconds"],
        "resources": v1["spec"]["template"]["spec"]["containers"][0]["resources"],
    }
