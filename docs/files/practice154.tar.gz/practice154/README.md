# practice154 — Kubernetes 服务生命周期

主产物是 `manifests/` 与 `scripts/rollout-e2e.sh`。

本机若无 `kubectl` 和可用集群，不会用 Python 进程冒充 kube-apiserver。
`test.sh` 只验收：清单结构（两副本、三类探针路径分离、资源声明、优雅终止）、
反例清单会被识别，以及教学服务进程自身的就绪/终止契约。
真实滚动升级、endpoints 摘流、kubelet 重启与 cgroup 限额列为 `not_verified_on_this_machine`。
手工步骤见 `scripts/diagnose.sh`。
