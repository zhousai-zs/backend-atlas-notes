#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" fetch_model.py
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["used_official_minilm_onnx"] is True
assert r["teaching_hash_models"]["hash32-v1"]["is_semantic_model"] is False
assert r["minilm"]["dim"] == 384
assert r["query_synonym"]["minilm_rank_of_D01_or_D02"] in (1, 2, 3)
assert r["query_symbol"]["bm25_rank_of_D01_or_D02"] in (1, 2, 3)
# hash results may be listed but must not be the semantic proof field
assert "teaching_hash32_not_semantic_evidence" in r["query_synonym"]
print("POSTCHECK_OK")
PY
