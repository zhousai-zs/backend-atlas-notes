#!/usr/bin/env python3
"""Download the official MiniLM ONNX + tokenizer if they are not cached."""

from __future__ import annotations

import sys
import urllib.request
from pathlib import Path

from minilm import FILES, HF_BASE, candidate_dirs, find_model, verify

UA = "backend-atlas-practice160/1.0 (educational; +https://zhousai-zs.github.io/backend-atlas-notes/)"


def dest_dir() -> Path:
    found = find_model()
    if found:
        return found
    # Prefer the revision cache if the parent exists, else user cache.
    lab = Path("/workspace/atlas/gen-batch-153-162-revision/models/all-MiniLM-L6-v2")
    if lab.parent.is_dir():
        return lab
    d = Path.home() / ".cache" / "atlas-minilm" / "all-MiniLM-L6-v2"
    return d


def fetch() -> Path:
    existing = find_model()
    if existing:
        verify(existing)
        print(f"MODEL_PRESENT {existing}")
        return existing
    root = dest_dir()
    print(f"MODEL_FETCH_DIR {root}")
    for rel in FILES:
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        url = f"{HF_BASE}/{rel}"
        print(f"GET {url}")
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=60) as r:
            path.write_bytes(r.read())
        print(f"  wrote {path} {path.stat().st_size}")
    verify(root)
    print("MODEL_READY")
    return root


if __name__ == "__main__":
    try:
        fetch()
    except Exception as exc:
        print(f"MODEL_FETCH_FAILED {type(exc).__name__}: {exc}", file=sys.stderr)
        sys.exit(2)
