"""Hash/trigram teaching vectors + BM25. These are not the MiniLM model."""
from __future__ import annotations

import hashlib, math, re
from collections import Counter, defaultdict
import numpy as np


def tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def hash_idx(token: str, dim: int, seed: str) -> int:
    h = hashlib.sha256(f"{seed}:{token}".encode()).digest()
    return int.from_bytes(h[:8], "big") % dim


def embed_hash(text: str, dim: int, seed: str) -> np.ndarray:
    v = np.zeros(dim, dtype=np.float64)
    for t in tokens(text):
        v[hash_idx(t, dim, seed)] += 1.0
    n = np.linalg.norm(v)
    return v / n if n else v


def embed_trigram(text: str, dim: int, seed: str) -> np.ndarray:
    v = np.zeros(dim, dtype=np.float64)
    s = f"#{text.lower()}#"
    for i in range(len(s) - 2):
        g = s[i:i+3]
        v[hash_idx(g, dim, seed)] += 1.0
    n = np.linalg.norm(v)
    return v / n if n else v


MODELS = {
    "hash32-v1": lambda text: embed_hash(text, 32, "hash32-v1"),
    "tri48-v2": lambda text: embed_trigram(text, 48, "tri48-v2"),
}


def cosine(a, b):
    if a.shape != b.shape:
        raise ValueError("dimension_or_version_mismatch")
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(a @ b / denom) if denom else 0.0


def knn(query_vec, matrix, k=5):
    # matrix rows must already be same model
    sims = matrix @ query_vec  # both normalized
    order = np.argsort(-sims)[:k]
    return [(int(i), float(sims[i])) for i in order]


class BM25:
    def __init__(self, docs, k1=1.5, b=0.75):
        self.docs = [tokens(d) for d in docs]
        self.k1, self.b = k1, b
        self.N = len(self.docs)
        self.avgdl = sum(len(d) for d in self.docs) / self.N
        df = Counter()
        for d in self.docs:
            df.update(set(d))
        self.idf = {t: math.log((self.N - c + 0.5) / (c + 0.5) + 1) for t, c in df.items()}

    def score(self, query: str):
        q = tokens(query)
        out = []
        for i, d in enumerate(self.docs):
            tf = Counter(d)
            s = 0.0
            dl = len(d) or 1
            for t in q:
                if t not in tf:
                    continue
                idf = self.idf.get(t, 0.0)
                s += idf * (tf[t] * (self.k1 + 1)) / (tf[t] + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
            out.append(s)
        order = np.argsort(-np.array(out))
        return [(int(i), float(out[i])) for i in order[:5]]
