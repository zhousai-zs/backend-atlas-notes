#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
from embed import MODELS, BM25, cosine, knn

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
docs = json.loads((ROOT / "docs.json").read_text())
texts = [d["text"] for d in docs]
assert len(texts) == 50

matrices = {name: np.stack([fn(t) for t in texts]) for name, fn in MODELS.items()}
# dimensions differ
dims = {name: int(mat.shape[1]) for name, mat in matrices.items()}
assert dims["hash32-v1"] != dims["tri48-v2"]

# mixing models must fail
mixed_error = None
try:
    cosine(matrices["hash32-v1"][0], matrices["tri48-v2"][0])
except ValueError as e:
    mixed_error = str(e)
assert mixed_error == "dimension_or_version_mismatch"

# Query 1: synonym of doc 0 — semantic/hash should prefer D01 or D02; keyword "ram exhaustion" may miss "ran out of memory"
q_sem = "the cache machine ran out of ram and killed the kv process"
# Query 2: exact symbol kv-node-7 — keyword should be strong
q_kw = "kv-node-7"

bm25 = BM25(texts)

def pack(name, pairs):
    return [{"id": docs[i]["id"], "score": round(s, 4), "text": docs[i]["text"]} for i, s in pairs]

ann_sem = pack("hash", knn(MODELS["hash32-v1"](q_sem), matrices["hash32-v1"], 5))
ann_kw = pack("bm25", bm25.score(q_sem))
ann_symbol_vec = pack("hash", knn(MODELS["hash32-v1"](q_kw), matrices["hash32-v1"], 5))
ann_symbol_kw = pack("bm25", bm25.score(q_kw))

# nearest neighbor is not automatically the correct runbook:
# construct: pick a query whose nearest vec is a related but not the intended doc
intended = "D03"  # disk 98 percent
q_near = "writes started failing on the gateway"
near = pack("hash", knn(MODELS["hash32-v1"](q_near), matrices["hash32-v1"], 5))
nearest_id = near[0]["id"]
# We only assert the general lesson if nearest is not always the intended one;
# if it happens to be D03, still record the list and assert len>=2 candidates.
assert nearest_id != "D00"
correct_is_nearest = nearest_id == intended

results = {
    "lesson": 160,
    "id": "k-embedding",
    "is_live_model": False,
    "used_sentence_transformers": False,
    "n_docs": 50,
    "models": {"hash32-v1": {"dim": dims["hash32-v1"]}, "tri48-v2": {"dim": dims["tri48-v2"]}},
    "mixing_rejected": mixed_error,
    "rebuild_or_isolate_after_model_change": True,
    "query_synonym": {
        "query": q_sem,
        "vector_hash32": ann_sem,
        "keyword_bm25": ann_kw,
    },
    "query_symbol": {
        "query": q_kw,
        "vector_hash32": ann_symbol_vec,
        "keyword_bm25": ann_symbol_kw,
    },
    "nearest_is_not_automatically_correct": {
        "query": q_near,
        "intended": intended,
        "nearest": nearest_id,
        "neighbors": near,
        "nearest_equals_intended": correct_is_nearest,
    },
    "numpy": np.__version__,
}
# synonym: vector should surface D01 or D02 in top-3; keyword may or may not
top3_ids = {h["id"] for h in ann_sem[:3]}
assert "D01" in top3_ids or "D02" in top3_ids
# symbol: keyword should include D01 (kv-node-7 only in first two infra docs)
kw_ids = {h["id"] for h in ann_symbol_kw[:3]}
assert "D01" in kw_ids or "D02" in kw_ids
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "retrieval.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
