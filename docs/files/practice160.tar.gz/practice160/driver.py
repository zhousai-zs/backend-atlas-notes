#!/usr/bin/env python3
"""Embedding practice: official MiniLM vs BM25 vs hash teaching vectors."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from embed import MODELS, BM25, cosine, knn
from fetch_model import fetch
from minilm import MiniLM

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
docs = json.loads((ROOT / "docs.json").read_text())
texts = [d["text"] for d in docs]
assert len(texts) == 50

# --- lexical + hash teaching vectors (not semantic models) ---
matrices = {name: np.stack([fn(t) for t in texts]) for name, fn in MODELS.items()}
dims = {name: int(mat.shape[1]) for name, mat in matrices.items()}
assert dims["hash32-v1"] != dims["tri48-v2"]
mixed_error = None
try:
    cosine(matrices["hash32-v1"][0], matrices["tri48-v2"][0])
except ValueError as e:
    mixed_error = str(e)
assert mixed_error == "dimension_or_version_mismatch"

# --- official MiniLM ---
model_root = fetch()
encoder = MiniLM(model_root)
sem = encoder.encode(texts)
assert sem.shape == (50, 384)

bm25 = BM25(texts)


def pack_ids(pairs):
    return [{"id": docs[i]["id"], "score": round(float(s), 4), "text": docs[i]["text"]} for i, s in pairs]


def knn_matrix(query_vec, matrix, k=5):
    # cosine already used by knn() for hash; MiniLM vectors are L2-normalized
    # so inner product equals cosine.
    scores = matrix @ query_vec
    idx = np.argsort(-scores)[:k]
    return pack_ids([(int(i), float(scores[i])) for i in idx])


q_sem = "the cache machine ran out of ram and killed the kv process"
q_kw = "kv-node-7"
q_near = "writes started failing on the gateway"
intended = "D03"

q_sem_vec = encoder.encode([q_sem])[0]
q_kw_vec = encoder.encode([q_kw])[0]
q_near_vec = encoder.encode([q_near])[0]

minilm_syn = knn_matrix(q_sem_vec, sem, 5)
minilm_sym = knn_matrix(q_kw_vec, sem, 5)
minilm_near = knn_matrix(q_near_vec, sem, 5)
bm25_syn = pack_ids(bm25.score(q_sem))
bm25_sym = pack_ids(bm25.score(q_kw))
hash_syn = pack_ids(knn(MODELS["hash32-v1"](q_sem), matrices["hash32-v1"], 5))
hash_sym = pack_ids(knn(MODELS["hash32-v1"](q_kw), matrices["hash32-v1"], 5))
hash_near = pack_ids(knn(MODELS["hash32-v1"](q_near), matrices["hash32-v1"], 5))

# Semantic check is on MiniLM, not on the hash vectors.
syn_top3 = {h["id"] for h in minilm_syn[:3]}
assert "D01" in syn_top3 or "D02" in syn_top3, minilm_syn
# Lexical/symbol check is on BM25.
sym_top3 = {h["id"] for h in bm25_sym[:3]}
assert "D01" in sym_top3 or "D02" in sym_top3, bm25_sym

# Paraphrase vs exact-symbol contrast (record, don't force a winner on every query).
minilm_syn_rank = next((i + 1 for i, h in enumerate(minilm_syn) if h["id"] in {"D01", "D02"}), None)
bm25_syn_rank = next((i + 1 for i, h in enumerate(bm25_syn) if h["id"] in {"D01", "D02"}), None)
minilm_sym_rank = next((i + 1 for i, h in enumerate(minilm_sym) if h["id"] in {"D01", "D02"}), None)
bm25_sym_rank = next((i + 1 for i, h in enumerate(bm25_sym) if h["id"] in {"D01", "D02"}), None)

results = {
    "lesson": 160,
    "id": "k-embedding",
    "is_live_model": False,
    "used_sentence_transformers_python_package": False,
    "used_official_minilm_onnx": True,
    "minilm": {
        "model_id": encoder.model_id,
        "onnx_file": encoder.onnx_file,
        "quantized": encoder.quantized,
        "dim": encoder.dim,
        "max_seq_length_used": encoder.max_len,
        "model_dir": str(model_root),
        "runtime": "onnxruntime",
        "runtime_version": __import__("onnxruntime").__version__,
        "tokenizers_version": __import__("tokenizers").__version__,
        "hash_is_not_this_model": True,
    },
    "n_docs": 50,
    "teaching_hash_models": {
        "hash32-v1": {"dim": dims["hash32-v1"], "is_semantic_model": False},
        "tri48-v2": {"dim": dims["tri48-v2"], "is_semantic_model": False},
    },
    "mixing_rejected": mixed_error,
    "rebuild_or_isolate_after_model_change": True,
    "query_synonym": {
        "query": q_sem,
        "minilm": minilm_syn,
        "keyword_bm25": bm25_syn,
        "teaching_hash32_not_semantic_evidence": hash_syn,
        "minilm_rank_of_D01_or_D02": minilm_syn_rank,
        "bm25_rank_of_D01_or_D02": bm25_syn_rank,
    },
    "query_symbol": {
        "query": q_kw,
        "minilm": minilm_sym,
        "keyword_bm25": bm25_sym,
        "teaching_hash32_not_semantic_evidence": hash_sym,
        "minilm_rank_of_D01_or_D02": minilm_sym_rank,
        "bm25_rank_of_D01_or_D02": bm25_sym_rank,
    },
    "nearest_is_not_automatically_correct": {
        "query": q_near,
        "intended": intended,
        "minilm_nearest": minilm_near[0]["id"],
        "minilm_neighbors": minilm_near,
        "minilm_nearest_equals_intended": minilm_near[0]["id"] == intended,
        "hash_nearest_not_used_as_semantic_proof": hash_near[0]["id"],
    },
    "numpy": np.__version__,
    "verified_on_this_machine": [
        "official_all-MiniLM-L6-v2_onnx_encode_50_docs",
        "paraphrase_query_hits_D01_or_D02_in_minilm_top3",
        "symbol_query_kv-node-7_hits_D01_or_D02_in_bm25_top3",
        "hash_and_trigram_vectors_refuse_to_mix",
    ],
    "not_verified_on_this_machine": [
        "sentence_transformers_Python_API_SentenceTransformer_encode",
        "paid_or_hosted_embedding_API",
    ],
}
assert results["used_official_minilm_onnx"] is True
assert results["teaching_hash_models"]["hash32-v1"]["is_semantic_model"] is False
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "retrieval.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
