"""Official all-MiniLM-L6-v2 embeddings via ONNX Runtime.

Model files come from https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2
(the project's own ONNX export). This is a real sentence-embedding model, not a
hash vector. It is still not a paid API and is_live_model refers to a hosted LLM,
not to this local encoder.

Pooling follows 1_Pooling/config.json (mean tokens) and the Normalize module
listed in modules.json (L2).
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

import numpy as np
import onnxruntime as ort
from tokenizers import Tokenizer

MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"
HF_BASE = f"https://huggingface.co/{MODEL_ID}/resolve/main"
# sha256 of the files fetched 2026-11-15
FILES = {
    "onnx/model_quint8_avx2.onnx": "b941bf19f1f1283680f449fa6a7336bb5600bdcd5f84d10ddc5cd72218a0fd21",
    "tokenizer.json": "be50c3628f2bf5bb5e3a7f17b1f74611b2561a3a27eeab05e5aa30f411572037",
    "1_Pooling/config.json": None,
    "modules.json": None,
}

# tokenizer.json in this export pads/truncates at 128, even though
# sentence_bert_config.json says max_seq_length 256. We follow the export
# actually used by the ONNX graph + tokenizer.
MAX_LEN = 128


def candidate_dirs() -> list[Path]:
    env = os.environ.get("MINILM_HOME")
    out: list[Path] = []
    if env:
        out.append(Path(env))
    out.extend(
        [
            Path("/workspace/atlas/gen-batch-153-162-revision/models/all-MiniLM-L6-v2"),
            Path(__file__).resolve().parent / "models" / "all-MiniLM-L6-v2",
            Path.home() / ".cache" / "atlas-minilm" / "all-MiniLM-L6-v2",
        ]
    )
    return out


def find_model() -> Path | None:
    for d in candidate_dirs():
        if (d / "onnx/model_quint8_avx2.onnx").is_file() and (d / "tokenizer.json").is_file():
            return d
    return None


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify(root: Path) -> None:
    for rel, expect in FILES.items():
        path = root / rel
        if not path.is_file():
            raise FileNotFoundError(path)
        if expect:
            got = sha256(path)
            if got != expect:
                raise ValueError(f"checksum mismatch for {rel}: {got}")


class MiniLM:
    def __init__(self, root: Path):
        verify(root)
        self.root = root
        self.session = ort.InferenceSession(
            str(root / "onnx/model_quint8_avx2.onnx"),
            providers=["CPUExecutionProvider"],
        )
        self.tokenizer = Tokenizer.from_file(str(root / "tokenizer.json"))
        # Use the tokenizer's own pad/truncate; still honor attention_mask.
        self.dim = 384
        self.model_id = MODEL_ID
        self.onnx_file = "onnx/model_quint8_avx2.onnx"
        self.quantized = True
        self.max_len = MAX_LEN

    def encode(self, texts: list[str]) -> np.ndarray:
        encs = [self.tokenizer.encode(t) for t in texts]
        # length is already 128 when the baked padding is on; still use the mask.
        n = max(len(e.ids) for e in encs)
        batch = len(texts)
        ids = np.zeros((batch, n), dtype=np.int64)
        mask = np.zeros((batch, n), dtype=np.int64)
        typ = np.zeros((batch, n), dtype=np.int64)
        for i, e in enumerate(encs):
            seq = e.ids[:n]
            attn = (e.attention_mask or [1] * len(e.ids))[:n]
            ids[i, : len(seq)] = seq
            mask[i, : len(attn)] = attn
        hidden = self.session.run(
            None,
            {
                "input_ids": ids,
                "attention_mask": mask,
                "token_type_ids": typ,
            },
        )[0]
        m = mask[:, :, None].astype(np.float64)
        pooled = (hidden.astype(np.float64) * m).sum(1) / np.clip(m.sum(1), 1, None)
        pooled = pooled / np.clip(np.linalg.norm(pooled, axis=1, keepdims=True), 1e-12, None)
        return pooled
