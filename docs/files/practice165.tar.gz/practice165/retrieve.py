"""Chunk retrieval: official MiniLM + BM25. Not an LLM."""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass

import numpy as np


def tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9_]+", text.lower())


class BM25:
    def __init__(self, chunks: list[dict], k1: float = 1.5, b: float = 0.75):
        self.chunks = chunks
        self.docs = [tokens(c["text"]) for c in chunks]
        self.k1, self.b = k1, b
        self.N = len(self.docs)
        self.avgdl = sum(len(d) for d in self.docs) / self.N
        df: Counter[str] = Counter()
        for d in self.docs:
            df.update(set(d))
        self.idf = {t: math.log((self.N - c + 0.5) / (c + 0.5) + 1) for t, c in df.items()}

    def scores(self, query: str) -> np.ndarray:
        q = tokens(query)
        out = np.zeros(self.N, dtype=np.float64)
        for i, d in enumerate(self.docs):
            tf = Counter(d)
            s = 0.0
            dl = len(d) or 1
            for t in q:
                if t not in tf:
                    continue
                idf = self.idf.get(t, 0.0)
                s += idf * (tf[t] * (self.k1 + 1)) / (
                    tf[t] + self.k1 * (1 - self.b + self.b * dl / self.avgdl)
                )
            out[i] = s
        return out


@dataclass
class Hit:
    chunk_id: str
    doc_id: str
    text: str
    score: float
    method: str


def topk(chunks: list[dict], scores: np.ndarray, k: int, method: str) -> list[Hit]:
    order = np.argsort(-scores)[:k]
    hits = []
    for i in order:
        if scores[i] <= 0 and method == "bm25":
            continue
        c = chunks[i]
        hits.append(
            Hit(c["id"], c["doc_id"], c["text"], float(scores[i]), method)
        )
    return hits
