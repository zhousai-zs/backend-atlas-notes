# practice165 — 向量检索与混合召回

在标注查询集上报告文档级 recall@5。教学 NSW 不是 pgvector HNSW；过滤后候选不足要单独解释。设置 MINILM_HOME。

```bash
bash test.sh
```
