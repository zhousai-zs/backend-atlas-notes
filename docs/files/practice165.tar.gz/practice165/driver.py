#!/usr/bin/env python3
"""Vector vs hybrid recall@k. Exact MiniLM search vs a teaching NSW, plus filters."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np

from ann import TeachingNSW
from fetch_model import fetch
from minilm import MiniLM
from retrieve import BM25, topk

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

corpus = json.loads((ROOT / "docs.json").read_text())
spec = json.loads((ROOT / "queries.json").read_text())
k = int(spec["k"])

chunks = []
for doc in corpus["docs"]:
    for p in doc["paragraphs"]:
        chunks.append(
            {
                "id": p["id"],
                "doc_id": doc["id"],
                "tags": doc["tags"],
                "text": p["text"],
            }
        )

model = MiniLM(fetch())
matrix = model.encode([c["text"] for c in chunks])
bm25 = BM25(chunks)
nsw = TeachingNSW(matrix, m=2, seed=1)


def z(x):
    s = float(np.std(x))
    return (x - np.mean(x)) / s if s > 1e-9 else np.zeros_like(x)


def hit_docs(hits, gold_doc: str) -> bool:
    return any(h.doc_id == gold_doc for h in hits)


def eval_queries(family: str, queries: list[dict]) -> dict:
    methods = {"minilm_exact": [], "bm25": [], "hybrid": [], "teaching_nsw": []}
    rows = []
    for q in queries:
        qv = model.encode([q["query"]])[0]
        sem = matrix @ qv
        lex = bm25.scores(q["query"])
        hyb = z(sem) + z(lex)
        exact_nn = int(np.argmax(sem))
        # Start NSW far from the exact neighbor to expose approximation error.
        start = int(np.argmin(sem)) if np.argmin(sem) != exact_nn else 0
        nsw_idx = nsw.search(qv, start=start, hops=3, k=k)
        packs = {
            "minilm_exact": topk(chunks, sem, k, "minilm_exact"),
            "bm25": topk(chunks, lex, k, "bm25"),
            "hybrid": topk(chunks, hyb, k, "hybrid"),
            "teaching_nsw": [
                type("H", (), {"chunk_id": chunks[i]["id"], "doc_id": chunks[i]["doc_id"], "score": float(sem[i]), "text": chunks[i]["text"]})()
                for i in nsw_idx
            ],
        }
        rec = {"id": q["id"], "query": q["query"], "gold_doc": q["gold_doc"], "hits": {}}
        for name, hits in packs.items():
            ok = hit_docs(hits, q["gold_doc"])
            methods[name].append(1.0 if ok else 0.0)
            rec["hits"][name] = {
                "ok": ok,
                "docs": [h.doc_id for h in hits],
                "chunks": [h.chunk_id for h in hits],
            }
        rec["exact_minilm_neighbor_chunk"] = chunks[exact_nn]["id"]
        rec["teaching_nsw_missed_exact_neighbor"] = chunks[exact_nn]["id"] not in rec["hits"]["teaching_nsw"]["chunks"]
        rows.append(rec)
    recall = {name: round(float(np.mean(v)), 4) for name, v in methods.items()}
    return {"family": family, "n": len(queries), "recall_at_k": recall, "queries": rows}


error_rep = eval_queries("error_code", spec["families"]["error_code"])
nl_rep = eval_queries("natural_language", spec["families"]["natural_language"])

# Filter case
fc = spec["filter_case"]
mask = np.array(["network" in c["tags"] for c in chunks], dtype=bool)
qv = model.encode([fc["query"]])[0]
sem = matrix @ qv
sem_filtered = np.where(mask, sem, -np.inf)
cand = int(np.sum(mask))
filtered_hits = topk([c for c in chunks if "network" in c["tags"]], sem[mask], k, "filtered")
gold_still_present_unfiltered = any(c["doc_id"] == fc["gold_doc"] for c in chunks)
gold_present_after_filter = any(c["doc_id"] == fc["gold_doc"] and "network" in c["tags"] for c in chunks)
filtered_hit = any(h.doc_id == fc["gold_doc"] for h in filtered_hits)
# After the network filter, D03 (storage) is gone.
assert gold_still_present_unfiltered and not gold_present_after_filter
assert not filtered_hit
assert cand > 0  # some network docs exist, just not the gold

# ANN miss in embedding space
nsw_misses = [
    r
    for block in (error_rep, nl_rep)
    for r in block["queries"]
    if r["teaching_nsw_missed_exact_neighbor"]
]
assert nsw_misses, "teaching NSW should miss at least one exact MiniLM neighbor with these params"

hnswlib = shutil.which("true")  # placeholder
try:
    import hnswlib as _h  # noqa: F401

    hnswlib_imported = True
except Exception:
    hnswlib_imported = False

results = {
    "lesson": 165,
    "id": "k-vector",
    "is_live_model": False,
    "used_official_minilm_onnx": True,
    "used_hnswlib": False,
    "hnswlib_imported": hnswlib_imported,
    "used_pgvector": False,
    "k": k,
    "recall_definition": spec["recall_definition"],
    "query_set": {
        "error_code_n": error_rep["n"],
        "natural_language_n": nl_rep["n"],
        "ids": [q["id"] for q in error_rep["queries"] + nl_rep["queries"]],
    },
    "error_code": {"recall_at_k": error_rep["recall_at_k"], "queries": error_rep["queries"]},
    "natural_language": {"recall_at_k": nl_rep["recall_at_k"], "queries": nl_rep["queries"]},
    "filter_case": {
        **fc,
        "candidates_after_filter": cand,
        "gold_present_unfiltered": gold_still_present_unfiltered,
        "gold_present_after_filter": gold_present_after_filter,
        "hit_after_filter": filtered_hit,
        "explanation": "The gold document exists in the collection but is excluded by tag=network, so the candidate set cannot contain it.",
    },
    "teaching_nsw_misses_exact_neighbor_on": [r["id"] for r in nsw_misses],
    "teaching_nsw_is_not_pgvector_hnsw": True,
    "hash_vectors_not_used_as_semantic_index": True,
    "verified_on_this_machine": [
        "minilm_exact_and_bm25_and_hybrid_recall_at_k_on_labeled_query_set",
        "teaching_nsw_can_miss_exact_minilm_neighbor",
        "metadata_filter_can_leave_gold_out_of_candidates",
    ],
    "not_verified_on_this_machine": [
        "hnswlib_or_pgvector_HNSW_index_recall",
        "production_ANN_parameters_tuned_on_this_set",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "recall.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(
    {
        "error_code_recall": error_rep["recall_at_k"],
        "nl_recall": nl_rep["recall_at_k"],
        "nsw_misses": results["teaching_nsw_misses_exact_neighbor_on"],
        "filter_hit": filtered_hit,
    },
    indent=2,
))
print("ALL_CHECKS_PASSED")
