#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" fetch_model.py
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["used_hnswlib"] is False and r["used_pgvector"] is False
assert r["query_set"]["error_code_n"]==8 and r["query_set"]["natural_language_n"]==8
assert r["filter_case"]["hit_after_filter"] is False
assert r["filter_case"]["gold_present_after_filter"] is False
assert r["teaching_nsw_misses_exact_neighbor_on"]
assert "recall_definition" in r and "query_set" in r
print("POSTCHECK_OK")
PY
