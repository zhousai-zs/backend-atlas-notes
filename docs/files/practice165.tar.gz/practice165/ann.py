"""Teaching NSW (navigable small world), not hnswlib / pgvector HNSW."""

from __future__ import annotations

import numpy as np


class TeachingNSW:
    def __init__(self, vectors: np.ndarray, m: int = 2, seed: int = 0):
        self.x = vectors
        self.n = len(vectors)
        rng = np.random.default_rng(seed)
        self.graph = [set() for _ in range(self.n)]
        # Connect each node to m random others (weak, intentionally).
        for i in range(self.n):
            choices = [j for j in range(self.n) if j != i]
            for j in rng.choice(choices, size=min(m, len(choices)), replace=False):
                self.graph[i].add(int(j))
                self.graph[int(j)].add(i)

    def search(self, q: np.ndarray, *, start: int, hops: int = 3, k: int = 5) -> list[int]:
        """Greedy walk with a tiny candidate pool. Can miss the exact neighbor."""
        visited = set()
        current = int(start)
        best = []
        for _ in range(hops):
            cand = [current] + [j for j in self.graph[current] if j not in visited]
            if not cand:
                break
            scores = self.x[np.array(cand)] @ q
            order = np.argsort(-scores)
            current = int(cand[int(order[0])])
            for j in cand:
                visited.add(int(j))
                best.append((float(self.x[j] @ q), int(j)))
        best.sort(reverse=True)
        seen = []
        for _, j in best:
            if j not in seen:
                seen.append(j)
            if len(seen) >= k:
                break
        return seen
