#!/usr/bin/env python3
"""Teaching DistTxnEngine — not Redis, not a network service, not a real TM/2PC/TCC product.

A Python 3 standard-library model of a coordinator plus two participants
(order service, inventory service) used to run two-phase commit and Saga
compensation on a virtual clock.

The 2PC participant protocol follows the shape of PostgreSQL's
PREPARE TRANSACTION / COMMIT PREPARED / ROLLBACK PREPARED, checked on
2026-11-14: after a successful prepare, the participant's prepared state
is flushed to a teaching dict (not a disk or fsync) before the vote is
replied; only commit or rollback of that prepared transaction can follow;
effects stay invisible to business reads until commit; reserved stock and
row locks stay held while prepared. The coordinator is an external
transaction manager of the kind the PostgreSQL docs say these commands
are intended for. It is not X/Open XA, not a PostgreSQL instance, not
pg_twophase, and not max_prepared_transactions.

Saga compensation is a new business operation recorded in a ledger, not
ROLLBACK PREPARED and not a database undo of a prepared transaction.

Single-process mailbox, no TCP, no real packet loss. crash_coordinator()
is an omniscient crash: in-flight messages to/from the coordinator are
dropped and its volatile state is cleared; durable logs remain.
Clock is virtual. rpc_delay_s is a teaching delay, not production RTT.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
KEY_TITLE = "article:01:title"
SKU = "promo:weekly-digest"
RPC_DELAY_S = 0.01


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class Message:
    src: str
    dst: str
    kind: str
    payload: dict[str, Any]
    send_at: float
    deliver_at: float
    seq: int
    dropped: bool = False


class DistTxnEngine:
    def __init__(self, stock: int = 5, rpc_delay_s: float = RPC_DELAY_S) -> None:
        self.clock = Clock()
        self.rpc_delay_s = float(rpc_delay_s)
        self.mailbox: list[Message] = []
        self.seq = 0
        self.flush_count = 0
        self.rpc_count = 0
        self.events: list[dict[str, Any]] = []
        self.coordinator_down = False

        # Coordinator durable log (survives crash).
        self.coord_log: dict[str, dict[str, Any]] = {}
        # Coordinator volatile state (lost on crash).
        self.coord_live: dict[str, dict[str, Any]] = {}
        self._xid_seq = 0

        # Inventory durable state.
        self.stock = int(stock)
        self.initial_stock = int(stock)
        self.reservations: dict[str, int] = {}  # xid -> qty (prepared 2PC)
        self.inv_ledger: list[dict[str, Any]] = []

        # Order durable state. Business-visible orders are committed only.
        self.orders: dict[str, dict[str, Any]] = {}
        self.order_prepared: dict[str, dict[str, Any]] = {}  # xid -> order
        self.order_ledger: list[dict[str, Any]] = []

        # Article title, used only by the irreversible Saga step.
        self.title = TITLE_V1
        self.title_key = KEY_TITLE
        self.title_published = False

        self._event("init", stock=self.stock, rpc_delay_s=self.rpc_delay_s)

    # ------------------------------------------------------------------ clock / net
    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def _flush(self, agent: str, reason: str, xid: Optional[str] = None) -> None:
        self.flush_count += 1
        self._event("persist_flushed", agent=agent, reason=reason, xid=xid, flush_count=self.flush_count)

    def _send(self, src: str, dst: str, kind: str, payload: dict[str, Any]) -> Message:
        self.seq += 1
        send_at = self.clock.now()
        msg = Message(src, dst, kind, dict(payload), send_at, round(send_at + self.rpc_delay_s, 10), self.seq)
        if self.coordinator_down and (src == "coord" or dst == "coord"):
            msg.dropped = True
            self._event("message_dropped", src=src, dst=dst, kind=kind, reason="coordinator_down")
        self.mailbox.append(msg)
        self.rpc_count += 1
        self._event("rpc_send", src=src, dst=dst, kind=kind, payload=dict(payload), rpc_count=self.rpc_count)
        return msg

    def run_until_quiet(self) -> None:
        while True:
            due = [m for m in self.mailbox if not m.dropped]
            if not due:
                self.mailbox = [m for m in self.mailbox if not m.dropped]
                return
            due.sort(key=lambda m: (m.deliver_at, m.seq))
            msg = due[0]
            self.clock.wait_until(msg.deliver_at)
            self.mailbox.remove(msg)
            if self.coordinator_down and (msg.src == "coord" or msg.dst == "coord"):
                self._event("message_dropped", src=msg.src, dst=msg.dst, kind=msg.kind, reason="coordinator_down_at_delivery")
                continue
            self._deliver(msg)

    def _deliver(self, msg: Message) -> None:
        self._event("rpc_deliver", src=msg.src, dst=msg.dst, kind=msg.kind, payload=dict(msg.payload))
        kind = msg.kind
        if kind == "prepare":
            self._on_prepare(msg)
        elif kind == "vote":
            self._on_vote(msg)
        elif kind == "commit":
            self._on_commit(msg)
        elif kind == "rollback":
            self._on_rollback(msg)
        elif kind == "ack":
            self._on_ack(msg)
        else:
            raise ValueError(kind)

    # ------------------------------------------------------------------ snapshots
    def available_stock(self) -> int:
        return self.stock - sum(self.reservations.values())

    def snapshot(self) -> dict[str, Any]:
        return {
            "t": self.now(),
            "stock": self.stock,
            "available_stock": self.available_stock(),
            "reservations": dict(self.reservations),
            "prepared_order_xids": sorted(self.order_prepared),
            "committed_orders": {
                oid: {"status": o["status"], "sku": o["sku"], "qty": o["qty"], "article": o.get("article")}
                for oid, o in self.orders.items()
            },
            "title": self.title,
            "title_published": self.title_published,
            "coordinator_down": self.coordinator_down,
            "coord_log": {k: {kk: vv for kk, vv in v.items() if kk != "votes"} | {"votes": dict(v.get("votes") or {})} for k, v in self.coord_log.items()},
        }

    # ------------------------------------------------------------------ 2PC API
    def begin(self, order_id: str, sku: str = SKU, qty: int = 1, article: str = KEY_TITLE) -> str:
        self._xid_seq += 1
        xid = f"xid-{self._xid_seq}"
        rec = {
            "xid": xid,
            "order_id": order_id,
            "sku": sku,
            "qty": qty,
            "article": article,
            "participants": ["order", "inventory"],
            "votes": {},
            "decision": None,
            "acks": {},
            "status": "begun",
        }
        self.coord_log[xid] = rec
        self.coord_live[xid] = {"sent_prepare": [], "sent_decision": []}
        self._flush("coord", "begin", xid)
        self._event("begin", xid=xid, order_id=order_id, sku=sku, qty=qty)
        return xid

    def prepare(self, xid: str, participant: str) -> None:
        rec = self.coord_log[xid]
        live = self.coord_live.get(xid)
        if live is None or self.coordinator_down:
            raise RuntimeError("coordinator is down")
        if rec["decision"] is not None:
            raise RuntimeError("already decided")
        payload = {
            "xid": xid,
            "participant": participant,
            "order_id": rec["order_id"],
            "sku": rec["sku"],
            "qty": rec["qty"],
            "article": rec["article"],
        }
        live["sent_prepare"].append(participant)
        rec["status"] = "preparing"
        self._event("prepare_send", xid=xid, participant=participant)
        self._send("coord", participant, "prepare", payload)

    def decide(self, xid: str) -> str:
        rec = self.coord_log[xid]
        if self.coordinator_down or xid not in self.coord_live:
            raise RuntimeError("coordinator is down")
        if rec["decision"] is not None:
            return rec["decision"]
        votes = rec["votes"]
        needed = rec["participants"]
        if any(votes.get(p) == "no" for p in needed):
            decision = "abort"
        elif all(votes.get(p) == "yes" for p in needed):
            decision = "commit"
        else:
            raise RuntimeError("not all votes in")
        rec["decision"] = decision
        rec["status"] = "decided_" + decision
        rec["decision_t"] = self.now()
        self._flush("coord", "decision", xid)
        self._event("decision", xid=xid, decision=decision, votes=dict(votes))
        return decision

    def send_decision(self, xid: str, participants: Optional[list[str]] = None) -> None:
        rec = self.coord_log[xid]
        live = self.coord_live.get(xid)
        if live is None or self.coordinator_down:
            raise RuntimeError("coordinator is down")
        if rec["decision"] is None:
            raise RuntimeError("no decision yet")
        kind = "commit" if rec["decision"] == "commit" else "rollback"
        targets = list(participants or rec["participants"])
        for p in targets:
            if p in rec["acks"]:
                continue
            live["sent_decision"].append(p)
            self._event("decision_send", xid=xid, participant=p, decision=rec["decision"])
            self._send("coord", p, kind, {"xid": xid, "participant": p})

    def crash_coordinator(self) -> None:
        self.coordinator_down = True
        for m in self.mailbox:
            if m.src == "coord" or m.dst == "coord":
                m.dropped = True
        self.coord_live.clear()
        self._event("coordinator_crashed")

    def recover_coordinator(self) -> dict[str, Any]:
        """Replay the durable log. No decision => presumed abort (teaching TM).

        PostgreSQL participants would keep the prepared transaction until an
        external manager issues COMMIT PREPARED or ROLLBACK PREPARED; they
        do not auto-resolve. This teaching coordinator, after recovering,
        either resends a logged decision or (if it never logged one) decides
        abort and rolls everyone back.
        """
        self.coordinator_down = False
        self.coord_live = {xid: {"sent_prepare": [], "sent_decision": []} for xid in self.coord_log}
        actions = []
        for xid, rec in list(self.coord_log.items()):
            if rec.get("status") == "done":
                continue
            if rec["decision"] is None:
                rec["decision"] = "abort"
                rec["status"] = "decided_abort"
                rec["decision_t"] = self.now()
                rec["presumed_abort"] = True
                self._flush("coord", "recovery_presumed_abort", xid)
                self._event("recovery_presumed_abort", xid=xid)
                actions.append({"xid": xid, "action": "presumed_abort"})
            else:
                actions.append({"xid": xid, "action": "resend_" + rec["decision"]})
            self.send_decision(xid)
        self._event("coordinator_recovered", actions=actions)
        return {"actions": actions}

    # ------------------------------------------------------------------ participants
    def _on_prepare(self, msg: Message) -> None:
        p = msg.payload
        xid, who = p["xid"], p["participant"]
        if who == "order":
            vote, reason = self._prepare_order(xid, p)
        elif who == "inventory":
            vote, reason = self._prepare_inventory(xid, p)
        else:
            raise ValueError(who)
        self._event("vote", participant=who, xid=xid, vote=vote, reason=reason)
        self._send(who, "coord", "vote", {"xid": xid, "participant": who, "vote": vote, "reason": reason})

    def _prepare_order(self, xid: str, p: dict[str, Any]) -> tuple[str, str]:
        if xid in self.order_prepared or any(
            o.get("order_id") == p["order_id"] and o["status"] == "committed" for o in self.orders.values()
        ) or any(o["order_id"] == p["order_id"] for o in self.order_prepared.values()):
            return "no", "duplicate_order"
        rec = {"xid": xid, "order_id": p["order_id"], "sku": p["sku"], "qty": p["qty"], "article": p["article"]}
        self.order_prepared[xid] = rec
        self._flush("order", "prepare", xid)
        return "yes", "prepared"

    def _prepare_inventory(self, xid: str, p: dict[str, Any]) -> tuple[str, str]:
        qty = int(p["qty"])
        if xid in self.reservations:
            return "yes", "already_prepared"
        if self.available_stock() < qty:
            return "no", "insufficient_stock"
        self.reservations[xid] = qty
        self._flush("inventory", "prepare", xid)
        return "yes", "reserved"

    def _on_vote(self, msg: Message) -> None:
        p = msg.payload
        rec = self.coord_log.get(p["xid"])
        if rec is None:
            return
        rec["votes"][p["participant"]] = p["vote"]
        rec.setdefault("vote_reasons", {})[p["participant"]] = p.get("reason")

    def _on_commit(self, msg: Message) -> None:
        p = msg.payload
        xid, who = p["xid"], p["participant"]
        if who == "order":
            self._commit_order(xid)
        else:
            self._commit_inventory(xid)
        self._flush(who, "commit", xid)
        self._event("committed", participant=who, xid=xid)
        self._send(who, "coord", "ack", {"xid": xid, "participant": who, "kind": "commit"})

    def _on_rollback(self, msg: Message) -> None:
        p = msg.payload
        xid, who = p["xid"], p["participant"]
        if who == "order":
            self.order_prepared.pop(xid, None)
        else:
            self.reservations.pop(xid, None)
        self._flush(who, "rollback", xid)
        self._event("rolled_back", participant=who, xid=xid)
        self._send(who, "coord", "ack", {"xid": xid, "participant": who, "kind": "rollback"})

    def _commit_order(self, xid: str) -> None:
        rec = self.order_prepared.pop(xid, None)
        if rec is None:
            return
        self.orders[rec["order_id"]] = {**rec, "status": "committed"}
        self.order_ledger.append({"op": "commit_order", "xid": xid, "order_id": rec["order_id"], "t": self.now()})

    def _commit_inventory(self, xid: str) -> None:
        qty = self.reservations.pop(xid, 0)
        if qty:
            self.stock -= qty
            self.inv_ledger.append({"op": "deduct", "xid": xid, "qty": qty, "stock_after": self.stock, "t": self.now()})

    def _on_ack(self, msg: Message) -> None:
        p = msg.payload
        rec = self.coord_log.get(p["xid"])
        if rec is None:
            return
        rec["acks"][p["participant"]] = p["kind"]
        if all(x in rec["acks"] for x in rec["participants"]):
            rec["status"] = "done"
            self._event("txn_done", xid=p["xid"], decision=rec["decision"])

    # ------------------------------------------------------------------ Saga (local commits + compensation)
    def saga_run(
        self,
        order_id: str,
        *,
        fail_at: Optional[str] = None,
        drop_compensate: bool = False,
        include_publish: bool = False,
        sku: str = SKU,
        qty: int = 1,
        article: str = KEY_TITLE,
    ) -> dict[str, Any]:
        """Execute a Saga: each step commits locally; failure runs compensations.

        Compensation is a new ledger entry (restock / cancel), not a 2PC rollback.
        If include_publish is set, the last step publishes the article title and
        is treated as irreversible: compensation cannot un-publish it.
        """
        xid = f"saga-{order_id}"
        done: list[str] = []
        compensations: list[dict[str, Any]] = []
        failed: Optional[str] = None
        irreversible_blocked = False

        def step_reserve() -> Optional[str]:
            if fail_at == "inventory":
                return "injected_failure"
            if self.available_stock() < qty:
                return "insufficient_stock"
            self.stock -= qty
            self.inv_ledger.append({"op": "saga_reserve", "xid": xid, "qty": qty, "stock_after": self.stock, "t": self.now()})
            self._flush("inventory", "saga_reserve", xid)
            self._event("saga_step", step="inventory", xid=xid, result="committed", stock=self.stock)
            return None

        def step_order() -> Optional[str]:
            if fail_at == "order":
                return "injected_failure"
            self.orders[order_id] = {"xid": xid, "order_id": order_id, "sku": sku, "qty": qty, "article": article, "status": "committed"}
            self.order_ledger.append({"op": "saga_create_order", "xid": xid, "order_id": order_id, "t": self.now()})
            self._flush("order", "saga_create", xid)
            self._event("saga_step", step="order", xid=xid, result="committed")
            return None

        def step_publish() -> Optional[str]:
            if fail_at == "publish":
                return "injected_failure"
            self.title = TITLE_V2
            self.title_published = True
            self._flush("article", "saga_publish", xid)
            self._event("saga_step", step="publish", xid=xid, result="committed", title=self.title)
            return None

        def compensate_publish() -> dict[str, Any]:
            # Publishing to followers is treated as irreversible in this teaching
            # scene: we record a compensating note, but do not un-write the title.
            rec = {
                "op": "compensate_publish",
                "xid": xid,
                "irreversible": True,
                "undone": False,
                "reason": "title already visible to followers; cannot roll back a push",
                "title_still": self.title,
                "t": self.now(),
            }
            self.order_ledger.append(rec)
            self._flush("article", "compensate_blocked", xid)
            self._event("saga_compensate", step="publish", xid=xid, irreversible=True, undone=False)
            return rec

        def compensate_order() -> dict[str, Any]:
            if order_id in self.orders:
                self.orders[order_id]["status"] = "cancelled"
            rec = {
                "op": "compensate_cancel_order",
                "xid": xid,
                "order_id": order_id,
                "irreversible": False,
                "undone": True,
                "t": self.now(),
            }
            self.order_ledger.append(rec)
            self._flush("order", "compensate", xid)
            self._event("saga_compensate", step="order", xid=xid, irreversible=False)
            return rec

        def compensate_inventory() -> dict[str, Any]:
            self.stock += qty
            rec = {
                "op": "compensate_restock",
                "xid": xid,
                "qty": qty,
                "stock_after": self.stock,
                "irreversible": False,
                "undone": True,
                "t": self.now(),
            }
            self.inv_ledger.append(rec)
            self._flush("inventory", "compensate", xid)
            self._event("saga_compensate", step="inventory", xid=xid, irreversible=False, stock=self.stock)
            return rec

        steps: list[tuple[str, Any, Any]] = [
            ("inventory", step_reserve, compensate_inventory),
            ("order", step_order, compensate_order),
        ]
        if include_publish:
            steps.append(("publish", step_publish, compensate_publish))

        # One RPC to each service per step (teaching model of a local call).
        for name, fn, _comp in steps:
            self._send("coord", name, "saga_placeholder", {"xid": xid})
            # saga messages are not in _deliver; we just account RPC + delay.
            self.mailbox = [m for m in self.mailbox if m.kind != "saga_placeholder"]
            self.clock.wait_until(self.clock.now() + self.rpc_delay_s)
            err = fn()
            if err:
                failed = name
                self._event("saga_step", step=name, xid=xid, result="failed", reason=err)
                break
            done.append(name)
            self.clock.wait_until(self.clock.now() + self.rpc_delay_s)

        if failed:
            for name, _fn, comp in reversed(steps):
                if name not in done:
                    continue
                self._send("coord", name, "saga_placeholder", {"xid": xid, "compensate": True})
                self.mailbox = [m for m in self.mailbox if m.kind != "saga_placeholder"]
                self.clock.wait_until(self.clock.now() + self.rpc_delay_s)
                if drop_compensate and name == "inventory":
                    self._event("compensate_dropped", step=name, xid=xid)
                    compensations.append({"op": "compensate_restock", "dropped": True, "xid": xid, "step": name})
                    continue
                rec = comp()
                compensations.append(rec)
                if rec.get("irreversible"):
                    irreversible_blocked = True
                self.clock.wait_until(self.clock.now() + self.rpc_delay_s)

        return {
            "xid": xid,
            "order_id": order_id,
            "completed_steps": done,
            "failed_at": failed,
            "compensations": compensations,
            "success": failed is None,
            "irreversible_blocked": irreversible_blocked,
            "drop_compensate": drop_compensate,
        }

    def reconcile(self) -> dict[str, Any]:
        """Teaching reconciliation: find stock deducted by a Saga with no committed order.

        Eventual consistency is not 'we never need to check'. A dropped
        compensate leaves inventory short until this job runs.
        """
        reserved_open = []
        for e in self.inv_ledger:
            if e.get("op") != "saga_reserve":
                continue
            xid = e["xid"]
            restocked = any(c.get("op") == "compensate_restock" and c.get("xid") == xid and not c.get("dropped") for c in self.inv_ledger)
            committed = any(o.get("xid") == xid and o.get("status") == "committed" for o in self.orders.values())
            cancelled = any(o.get("xid") == xid and o.get("status") == "cancelled" for o in self.orders.values())
            if not restocked and not committed:
                reserved_open.append({"xid": xid, "qty": e["qty"], "cancelled_order": cancelled})
        fixed = []
        for item in reserved_open:
            self.stock += item["qty"]
            rec = {
                "op": "reconcile_restock",
                "xid": item["xid"],
                "qty": item["qty"],
                "stock_after": self.stock,
                "t": self.now(),
            }
            self.inv_ledger.append(rec)
            self._flush("inventory", "reconcile", item["xid"])
            self._event("reconcile", **rec)
            fixed.append(rec)
        return {
            "divergences": reserved_open,
            "fixed": fixed,
            "needed": len(reserved_open) > 0,
            "stock": self.stock,
        }
