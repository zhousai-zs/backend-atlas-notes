#!/usr/bin/env python3
"""Acceptance checks for the lesson 121 distributed-transaction experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import TITLE_V1, TITLE_V2


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "DistTxnEngine"
    assert r["not_redis"] and r["not_a_network_service"] and r["not_a_real_tm"]
    assert r["not_postgresql"] and r["not_xa"]

    tw = r["twopc"]
    happy = tw["happy"]
    assert happy["decision"] == "commit" and happy["consistent"]
    assert happy["committed_order_ids"] == ["order-1"]
    assert happy["stock"] == 4 and happy["available_stock"] == 4
    assert happy["prepared_left"]["orders"] == [] and happy["prepared_left"]["reservations"] == {}
    occ_h = happy["occupancy"]
    assert occ_h["prepared_holds_stock"] and occ_h["prepared_order_not_visible"]
    assert occ_h["business_visible_orders"] == []

    # Crash at every stage, recover, stay consistent.
    for key, expect_decision, expect_orders, expect_stock in (
        ("kill_before_prepare", "abort", [], 5),
        ("kill_after_one_prepare", "abort", [], 5),
        ("kill_after_both_prepare", "abort", [], 5),
        ("kill_after_decision", "commit", ["order-1"], 4),
        ("kill_after_one_commit", "commit", ["order-1"], 4),
    ):
        c = tw[key]
        assert c["consistent"], (key, c["final"], c["decision"], c["prepared_left"])
        assert c["decision"] == expect_decision, (key, c["decision"])
        assert c["committed_order_ids"] == expect_orders, (key, c["committed_order_ids"])
        assert c["stock"] == expect_stock and c["available_stock"] == expect_stock, key
        assert c["prepared_left"]["orders"] == [] and c["prepared_left"]["reservations"] == {}
    assert tw["kill_before_prepare"]["presumed_abort"]
    assert tw["kill_after_one_prepare"]["presumed_abort"]
    assert tw["kill_after_both_prepare"]["presumed_abort"]
    assert not tw["kill_after_decision"]["presumed_abort"]
    assert tw["kill_after_both_prepare"]["during_outage"]["reservation_held"]
    assert tw["kill_after_both_prepare"]["during_outage"]["order_still_invisible"]
    assert tw["kill_after_decision"]["during_outage"]["durable_decision"] == "commit"
    assert tw["kill_after_one_commit"]["during_outage"]["order_status"] == "committed"
    assert tw["kill_after_one_commit"]["during_outage"]["reservation_held"] is True

    occ = r["occupancy"]
    assert occ["prepared_holds_last_unit"] and occ["available_during_block"] == 0
    assert occ["second_inventory_vote"] == "no" and occ["second_decision"] == "abort"
    assert not occ["second_order_committed"] and occ["first_still_prepared"]
    assert occ["after_first_prepare"]["order_visible"] is False

    sg = r["saga"]
    assert sg["happy"]["result"]["success"]
    assert sg["happy"]["final"]["stock"] == 4
    assert sg["happy"]["final"]["committed_orders"]["order-s1"]["status"] == "committed"
    comp = sg["compensate"]
    assert comp["compensation_is_new_operation"] and comp["not_a_prepared_rollback"]
    assert comp["stock_restored"] and comp["order_record_still_present"]
    assert "compensate_restock" in [e["op"] for e in comp["inventory_ledger"]]
    assert "saga_reserve" in [e["op"] for e in comp["inventory_ledger"]]
    irr = sg["irreversible"]
    assert irr["title_still_revised"] and irr["title_published"] and irr["publish_not_undone"]
    assert irr["order_cancelled"] and irr["stock_restored"]
    pit = sg["pitfall_dropped_compensate"]
    assert pit["stock_short_before_reconcile"] and pit["needed_reconcile"]
    assert pit["stock_after_reconcile"] == 5
    assert pit["order_not_committed"]

    tr = r["tradeoff"]
    assert tr["two_pc"]["all_committed"] and tr["saga"]["all_committed"]
    assert tr["saga_fewer_rpcs"] and tr["saga_no_prepared_lock_hold"]
    assert tr["two_pc"]["lock_hold_s_mean"] > 0

    assert r["acceptance_compensation_is_not_db_rollback"]
    assert r["acceptance_prepare_occupies_resources"]
    assert r["pitfall_eventual_consistency_needs_reconcile"]
    assert r["tradeoff_atomicity_costs_coordination"]
    assert r["all_2pc_consistent"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
