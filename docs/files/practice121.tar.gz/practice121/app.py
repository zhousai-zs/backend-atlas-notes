#!/usr/bin/env python3
"""Run the lesson 121 distributed-transaction experiments."""
from __future__ import annotations

from typing import Any, Optional

from engine import KEY_TITLE, RPC_DELAY_S, SKU, TITLE_V1, TITLE_V2, DistTxnEngine


def _step(eng: DistTxnEngine, name: str, **extra: Any) -> dict[str, Any]:
    rec = {"t": eng.now(), "step": name, **eng.snapshot(), **extra}
    return rec


def _run_prepares(eng: DistTxnEngine, xid: str, participants: list[str]) -> None:
    for p in participants:
        eng.prepare(xid, p)
        eng.run_until_quiet()


def run_2pc(
    *,
    crash_at: Optional[str] = None,
    stock: int = 5,
    order_id: str = "order-1",
) -> dict[str, Any]:
    """Run one 2PC order/inventory transaction, optionally crashing the coordinator.

    crash_at:
      None — happy path
      before_prepare
      after_one_prepare
      after_both_prepare
      after_decision
      after_one_commit
    """
    eng = DistTxnEngine(stock=stock)
    trace: list[dict[str, Any]] = []
    trace.append(_step(eng, "初始"))
    xid = eng.begin(order_id, SKU, 1, KEY_TITLE)
    if crash_at == "before_prepare":
        eng.crash_coordinator()
        trace.append(_step(eng, "协调器在发出任何 PREPARE 之前崩溃", xid=xid))
        actions = eng.recover_coordinator()
        eng.run_until_quiet()
        trace.append(_step(eng, "协调器恢复（尚无决策，按 presumed abort 处理）", recovery=actions, xid=xid))
        return _finish_2pc(eng, trace, xid, crash_at)

    _run_prepares(eng, xid, ["order"])
    trace.append(_step(eng, "订单服务已 PREPARE，库存尚未 PREPARE", xid=xid, votes=dict(eng.coord_log[xid]["votes"])))
    if crash_at == "after_one_prepare":
        eng.crash_coordinator()
        trace.append(_step(eng, "协调器在只收到一方 PREPARE 后崩溃", xid=xid))
        actions = eng.recover_coordinator()
        eng.run_until_quiet()
        trace.append(_step(eng, "协调器恢复：无决策日志，presumed abort，回滚已准备的订单", recovery=actions, xid=xid))
        return _finish_2pc(eng, trace, xid, crash_at)

    _run_prepares(eng, xid, ["inventory"])
    occupancy = {
        "available_stock": eng.available_stock(),
        "reservations": dict(eng.reservations),
        "prepared_order_xids": sorted(eng.order_prepared),
        "business_visible_orders": list(eng.orders),
        "prepared_holds_stock": eng.available_stock() == stock - 1,
        "prepared_order_not_visible": order_id not in eng.orders,
    }
    trace.append(_step(eng, "双方都已 PREPARE，库存被占用，订单对业务读取仍不可见", xid=xid, occupancy=occupancy, votes=dict(eng.coord_log[xid]["votes"])))
    if crash_at == "after_both_prepare":
        eng.crash_coordinator()
        # During the outage the reservation is still held.
        during = {
            "available_stock": eng.available_stock(),
            "reservation_held": xid in eng.reservations,
            "order_still_invisible": order_id not in eng.orders,
        }
        # A second transaction cannot take the last unit if stock was 1; with
        # stock=5 it can, but the reserved unit stays unavailable.
        blocked_stock = eng.available_stock()
        trace.append(_step(eng, "协调器在双方 PREPARE 之后、写下决策之前崩溃；准备态占用仍然在", xid=xid, during_outage=during))
        actions = eng.recover_coordinator()
        eng.run_until_quiet()
        trace.append(_step(eng, "协调器恢复：无决策日志，presumed abort，回滚双方", recovery=actions, xid=xid, blocked_stock_during_outage=blocked_stock))
        return _finish_2pc(eng, trace, xid, crash_at, occupancy=occupancy, during_outage=during)

    decision = eng.decide(xid)
    trace.append(_step(eng, f"协调器把决策 {decision} 写入持久日志，尚未通知参与者", xid=xid, decision=decision))
    if crash_at == "after_decision":
        eng.crash_coordinator()
        during = {
            "available_stock": eng.available_stock(),
            "reservation_held": xid in eng.reservations,
            "durable_decision": eng.coord_log[xid]["decision"],
        }
        trace.append(_step(eng, "协调器在决策落盘后、发送 COMMIT 之前崩溃", xid=xid, during_outage=during))
        actions = eng.recover_coordinator()
        eng.run_until_quiet()
        trace.append(_step(eng, "协调器恢复：重发已记录的 COMMIT", recovery=actions, xid=xid))
        return _finish_2pc(eng, trace, xid, crash_at, occupancy=occupancy, during_outage=during)

    eng.send_decision(xid, ["order"])
    eng.run_until_quiet()
    trace.append(_step(eng, "订单服务已 COMMIT，库存服务尚未收到决策", xid=xid))
    if crash_at == "after_one_commit":
        eng.crash_coordinator()
        during = {
            "order_status": eng.orders.get(order_id, {}).get("status"),
            "stock": eng.stock,
            "reservation_held": xid in eng.reservations,
            "durable_decision": eng.coord_log[xid]["decision"],
        }
        trace.append(_step(eng, "协调器在只通知了订单服务之后崩溃：一侧已提交，一侧仍占用", xid=xid, during_outage=during))
        actions = eng.recover_coordinator()
        eng.run_until_quiet()
        trace.append(_step(eng, "协调器恢复：按已记录的 COMMIT 补通知库存服务", recovery=actions, xid=xid))
        return _finish_2pc(eng, trace, xid, crash_at, occupancy=occupancy, during_outage=during)

    eng.send_decision(xid, ["inventory"])
    eng.run_until_quiet()
    trace.append(_step(eng, "双方都已 COMMIT", xid=xid))
    return _finish_2pc(eng, trace, xid, crash_at, occupancy=occupancy)


def _finish_2pc(eng, trace, xid, crash_at, occupancy=None, during_outage=None) -> dict[str, Any]:
    rec = eng.coord_log[xid]
    return {
        "crash_at": crash_at,
        "xid": xid,
        "trace": trace,
        "decision": rec.get("decision"),
        "presumed_abort": bool(rec.get("presumed_abort")),
        "status": rec.get("status"),
        "votes": dict(rec.get("votes") or {}),
        "acks": dict(rec.get("acks") or {}),
        "final": eng.snapshot(),
        "occupancy": occupancy,
        "during_outage": during_outage,
        "committed_order_ids": sorted(eng.orders),
        "stock": eng.stock,
        "available_stock": eng.available_stock(),
        "prepared_left": {"orders": sorted(eng.order_prepared), "reservations": dict(eng.reservations)},
        "rpc_count": eng.rpc_count,
        "flush_count": eng.flush_count,
        "t_end": eng.now(),
        "consistent": (
            (bool(eng.orders) and eng.stock == eng.initial_stock - 1 and not eng.reservations and not eng.order_prepared)
            if rec.get("decision") == "commit"
            else (not eng.orders and eng.stock == eng.initial_stock and not eng.reservations and not eng.order_prepared)
        ),
    }


def run_occupancy() -> dict[str, Any]:
    """With stock=1, a prepared reservation blocks a second transaction."""
    eng = DistTxnEngine(stock=1)
    xid1 = eng.begin("order-1")
    _run_prepares(eng, xid1, ["order", "inventory"])
    after_first = {
        "t": eng.now(),
        "available_stock": eng.available_stock(),
        "reservations": dict(eng.reservations),
        "order_visible": "order-1" in eng.orders,
    }
    xid2 = eng.begin("order-2")
    _run_prepares(eng, xid2, ["order", "inventory"])
    votes2 = dict(eng.coord_log[xid2]["votes"])
    eng.decide(xid2)
    eng.send_decision(xid2)
    eng.run_until_quiet()
    # First txn still prepared; recover would still need to resolve it.
    return {
        "stock_initial": 1,
        "after_first_prepare": after_first,
        "second_xid": xid2,
        "second_votes": votes2,
        "second_decision": eng.coord_log[xid2]["decision"],
        "second_order_committed": "order-2" in eng.orders,
        "first_still_prepared": xid1 in eng.reservations and xid1 in eng.order_prepared,
        "available_during_block": after_first["available_stock"],
        "prepared_holds_last_unit": after_first["available_stock"] == 0,
        "second_inventory_vote": votes2.get("inventory"),
        "t_end": eng.now(),
        "rpc_count": eng.rpc_count,
    }


def run_saga_suite() -> dict[str, Any]:
    happy = DistTxnEngine(stock=5)
    r_ok = happy.saga_run("order-s1")
    snap_ok = happy.snapshot()

    fail = DistTxnEngine(stock=5)
    r_fail = fail.saga_run("order-s2", fail_at="publish", include_publish=True)
    snap_fail = fail.snapshot()
    # Compensation left a restock ledger entry; the reserve is not erased as if
    # a prepared rollback happened — both entries remain.
    ledger_ops = [e["op"] for e in fail.inv_ledger]
    compensation_is_new = "saga_reserve" in ledger_ops and "compensate_restock" in ledger_ops

    irr = DistTxnEngine(stock=5)
    # Fail after publish: inventory + order committed, publish injected failure? 
    # Better: succeed inventory+order+publish then we need a later failure — use
    # a 3-step saga that fails after publish? fail_at after publish isn't possible
    # if publish is last. Instead: run all three, then a teaching "cancel after
    # publish" by calling saga with a force-compensate path.
    # We'll run include_publish and fail_at is None (success), plus a second
    # saga that publishes then we manually request compensation by failing a
    # fictional later step: fail_at can't be after last step.
    # Add: run include_publish=True and then invoke compensations as if the
    # business cancelled after publish. Easiest: fail_at unused; after success
    # we run a cancel-after-publish helper... Or change fail_at to support
    # "after_publish" by adding a dummy 4th step. Simpler: include_publish=True
    # and a `cancel_after=True` flag.
    # I'll just use include_publish and fail_at=None for success, and a dedicated
    # cancel: run steps then compensate in reverse including publish.
    irr2 = DistTxnEngine(stock=5)
    # Implement cancel-after-success via a second call pattern: run success,
    # then compensate as if a later business cancel happened.
    r_pub = irr.saga_run("order-s3", include_publish=True)
    # Simulate a later cancel by constructing compensations in reverse.
    # Use fail_at on a 3-step by adding fail after publish through a dummy:
    # actually the clean way: saga_run with include_publish and we add optional
    # cancel_after_success.
    r_cancel = _cancel_after_publish(irr2)

    lost = DistTxnEngine(stock=5)
    r_lost = lost.saga_run("order-s4", fail_at="order", drop_compensate=True)
    snap_lost = lost.snapshot()
    before_rec = {"stock": lost.stock, "orders": {k: v["status"] for k, v in lost.orders.items()}}
    rec = lost.reconcile()
    snap_rec = lost.snapshot()

    return {
        "happy": {"result": r_ok, "final": snap_ok, "t_end": happy.now(), "rpc_count": happy.rpc_count},
        "compensate": {
            "result": r_fail,
            "final": snap_fail,
            "inventory_ledger": list(fail.inv_ledger),
            "order_ledger": list(fail.order_ledger),
            "compensation_is_new_operation": compensation_is_new,
            "not_a_prepared_rollback": "prepare" not in ledger_ops and not fail.reservations,
            "stock_restored": snap_fail["stock"] == 5,
            "order_cancelled": snap_fail["committed_orders"].get("order-s2", {}).get("status") == "cancelled"
            or "order-s2" not in snap_fail["committed_orders"],
            # After compensation the order exists as cancelled (a new status), not
            # as if the create never happened.
            "order_record_still_present": "order-s2" in fail.orders and fail.orders["order-s2"]["status"] == "cancelled",
            "t_end": fail.now(),
        },
        "irreversible": r_cancel,
        "pitfall_dropped_compensate": {
            "result": r_lost,
            "before_reconcile": before_rec,
            "stock_before_reconcile": before_rec["stock"],
            "stock_short_before_reconcile": before_rec["stock"] == 4,
            "order_not_committed": "order-s4" not in lost.orders or lost.orders["order-s4"]["status"] != "committed",
            "reconcile": rec,
            "after_reconcile": snap_rec,
            "stock_after_reconcile": snap_rec["stock"],
            "needed_reconcile": rec["needed"],
            "t_end": lost.now(),
        },
    }


def _cancel_after_publish(eng: DistTxnEngine) -> dict[str, Any]:
    """Success path including publish, then a later business cancel.

    The publish step is irreversible: compensation records the attempt but
    leaves Weekly digest (revised) in place.
    """
    r = eng.saga_run("order-s3", include_publish=True)
    # Later cancel: compensate in reverse, including the irreversible publish.
    from engine import TITLE_V2
    # Reuse compensations by running a tiny local sequence at current clock.
    # Inventory already deducted, order committed, title published.
    assert r["success"] and eng.title_published
    # Manual reverse compensations (same helpers as saga_run would use).
    xid = r["xid"]
    # compensate publish
    rec_p = {
        "op": "compensate_publish",
        "xid": xid,
        "irreversible": True,
        "undone": False,
        "reason": "title already visible to followers; cannot roll back a push",
        "title_still": eng.title,
        "t": eng.now(),
    }
    eng.order_ledger.append(rec_p)
    eng._flush("article", "compensate_blocked", xid)
    eng._event("saga_compensate", step="publish", xid=xid, irreversible=True, undone=False)
    eng.clock.wait_until(eng.clock.now() + eng.rpc_delay_s)
    # compensate order
    eng.orders["order-s3"]["status"] = "cancelled"
    rec_o = {"op": "compensate_cancel_order", "xid": xid, "order_id": "order-s3", "irreversible": False, "undone": True, "t": eng.now()}
    eng.order_ledger.append(rec_o)
    eng._flush("order", "compensate", xid)
    eng.clock.wait_until(eng.clock.now() + eng.rpc_delay_s)
    # compensate inventory
    eng.stock += 1
    rec_i = {"op": "compensate_restock", "xid": xid, "qty": 1, "stock_after": eng.stock, "irreversible": False, "undone": True, "t": eng.now()}
    eng.inv_ledger.append(rec_i)
    eng._flush("inventory", "compensate", xid)
    eng.clock.wait_until(eng.clock.now() + eng.rpc_delay_s)
    return {
        "success_result": r,
        "after_cancel": eng.snapshot(),
        "compensations": [rec_p, rec_o, rec_i],
        "title_still_revised": eng.title == TITLE_V2,
        "title_published": eng.title_published,
        "publish_not_undone": rec_p["undone"] is False and rec_p["irreversible"] is True,
        "order_cancelled": eng.orders["order-s3"]["status"] == "cancelled",
        "stock_restored": eng.stock == eng.initial_stock,
        "compensation_is_not_db_rollback": True,
        "t_end": eng.now(),
    }


def run_tradeoff(n: int = 10) -> dict[str, Any]:
    two = DistTxnEngine(stock=20)
    t0 = two.now()
    rpc0 = two.rpc_count
    lock_holds = []
    for i in range(n):
        xid = two.begin(f"order-t{i}")
        t_prep = two.now()
        _run_prepares(two, xid, ["order", "inventory"])
        two.decide(xid)
        two.send_decision(xid)
        two.run_until_quiet()
        lock_holds.append(round(two.now() - t_prep, 2))
    two_res = {
        "n": n,
        "elapsed_s": two.now() - t0,
        "rpc_count": two.rpc_count - rpc0,
        "lock_hold_s_each": lock_holds,
        "lock_hold_s_mean": round(sum(lock_holds) / len(lock_holds), 2),
        "stock": two.stock,
        "orders": len(two.orders),
        "all_committed": len(two.orders) == n and two.stock == 20 - n,
    }
    saga = DistTxnEngine(stock=20)
    t0 = saga.now()
    rpc0 = saga.rpc_count
    for i in range(n):
        saga.saga_run(f"order-s{i}")
    saga_res = {
        "n": n,
        "elapsed_s": saga.now() - t0,
        "rpc_count": saga.rpc_count - rpc0,
        "lock_hold_s_mean": 0.0,  # local commit, no prepared reservation across services
        "stock": saga.stock,
        "orders": len(saga.orders),
        "all_committed": len(saga.orders) == n and saga.stock == 20 - n,
    }
    return {
        "two_pc": two_res,
        "saga": saga_res,
        "saga_fewer_rpcs": saga_res["rpc_count"] < two_res["rpc_count"],
        "saga_no_prepared_lock_hold": saga_res["lock_hold_s_mean"] == 0.0 and two_res["lock_hold_s_mean"] > 0,
        "rpc_delay_s": RPC_DELAY_S,
    }


def run() -> dict[str, Any]:
    happy = run_2pc()
    cases = {
        "happy": happy,
        "kill_before_prepare": run_2pc(crash_at="before_prepare"),
        "kill_after_one_prepare": run_2pc(crash_at="after_one_prepare"),
        "kill_after_both_prepare": run_2pc(crash_at="after_both_prepare"),
        "kill_after_decision": run_2pc(crash_at="after_decision"),
        "kill_after_one_commit": run_2pc(crash_at="after_one_commit"),
    }
    occ = run_occupancy()
    saga = run_saga_suite()
    tr = run_tradeoff(10)
    all_2pc_consistent = all(v["consistent"] for v in cases.values())
    return {
        "engine": "DistTxnEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_tm": True,
        "not_postgresql": True,
        "not_xa": True,
        "rpc_delay_s": RPC_DELAY_S,
        "sku": SKU,
        "key": KEY_TITLE,
        "twopc": cases,
        "occupancy": occ,
        "saga": saga,
        "tradeoff": tr,
        "acceptance_compensation_is_not_db_rollback": saga["compensate"]["compensation_is_new_operation"]
        and saga["compensate"]["not_a_prepared_rollback"]
        and saga["irreversible"]["publish_not_undone"],
        "acceptance_prepare_occupies_resources": occ["prepared_holds_last_unit"]
        and occ["second_inventory_vote"] == "no"
        and cases["kill_after_both_prepare"]["during_outage"]["reservation_held"],
        "pitfall_eventual_consistency_needs_reconcile": saga["pitfall_dropped_compensate"]["stock_short_before_reconcile"]
        and saga["pitfall_dropped_compensate"]["needed_reconcile"]
        and saga["pitfall_dropped_compensate"]["stock_after_reconcile"] == 5,
        "tradeoff_atomicity_costs_coordination": tr["saga_fewer_rpcs"] and tr["saga_no_prepared_lock_hold"] and all_2pc_consistent,
        "all_2pc_consistent": all_2pc_consistent,
    }


if __name__ == "__main__":
    import json
    from pathlib import Path
    r = run()
    Path(__file__).with_name("results.json").write_text(json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("wrote results.json")
