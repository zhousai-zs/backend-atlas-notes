#include <cassert>
#include <iostream>
#include "kvutil/kv.h"
int main() {
  auto m = kvutil::parse(" a = 1 ;b=2;;c=");
  assert(m.size() == 3);
  assert(m["a"] == "1");
  assert(m["b"] == "2");
  assert(m["c"] == "");
  std::cout << "kvutil_test: 4 assertions passed\n";
  return 0;
}

