#include <iostream>
int main() {
  std::cout << "hello-unrelated\n";
  return 0;
}

