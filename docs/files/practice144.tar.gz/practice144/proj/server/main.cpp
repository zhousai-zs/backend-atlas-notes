#include <iostream>
#include "kvutil/kv.h"
int main(int argc, char** argv) {
  std::string cfg = argc > 1 ? argv[1] : "timeout_ms = 400; retry=1";
  auto m = kvutil::parse(cfg);
  std::cout << "server: timeout_ms=" << m["timeout_ms"] << " retry=" << m["retry"] << "\n";
  return 0;
}

