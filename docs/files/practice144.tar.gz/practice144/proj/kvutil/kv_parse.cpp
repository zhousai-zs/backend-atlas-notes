#include "kvutil/kv.h"
#include "trim.h"
#ifndef KVUTIL_INTERNAL
#error "KVUTIL_INTERNAL should be defined for kvutil only"
#endif
namespace kvutil {
std::map<std::string, std::string> parse(const std::string& s) {
  std::map<std::string, std::string> out;
  size_t start = 0;
  while (start <= s.size()) {
    size_t end = s.find(';', start);
    if (end == std::string::npos) end = s.size();
    std::string item = s.substr(start, end - start);
    size_t eq = item.find('=');
    if (eq != std::string::npos)
      out[detail::trim(item.substr(0, eq))] = detail::trim(item.substr(eq + 1));
    start = end + 1;
  }
  return out;
}
}

