#pragma once
// 库内部头文件：列入 srcs 而非 hdrs，不对外暴露
#include <string>
namespace kvutil { namespace detail {
inline std::string trim(const std::string& s) {
  auto b = s.find_first_not_of(" 	");
  if (b == std::string::npos) return "";
  auto e = s.find_last_not_of(" 	");
  return s.substr(b, e - b + 1);
}
}}

