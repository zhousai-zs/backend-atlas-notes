#!/usr/bin/env bash
# 第144课实践：把 C++ 库与测试迁入 Bazel，观察重建范围、sandbox 与磁盘缓存。
# 运行：bash test.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
export PATH="$HERE/tools:$PATH"
export USE_BAZEL_VERSION="${USE_BAZEL_VERSION:-9.3.2}"

if command -v g++ >/dev/null 2>&1; then
  export CC="$(command -v gcc 2>/dev/null || command -v cc)"
  export CXX="$(command -v g++)"
  COMPILER_NOTE="system g++ ($CXX)"
elif command -v clang++ >/dev/null 2>&1; then
  export CC="$(command -v clang)"
  export CXX="$(command -v clang++)"
  COMPILER_NOTE="system clang++ ($CXX)"
else
  export CC="$HERE/tools/zig-c++"
  export CXX="$HERE/tools/zig-c++"
  chmod +x "$HERE/tools/"*
  COMPILER_NOTE="zig c++ (clang frontend) via $CXX"
fi

LOG="$HERE/run.log"; : > "$LOG"
say(){ echo "$@" | tee -a "$LOG"; }
run(){ "$@" 2>&1 | tee -a "$LOG"; return ${PIPESTATUS[0]}; }
FAIL=0
check(){ if eval "$2"; then say "CHECK OK: $1"; else say "CHECK FAIL: $1"; FAIL=1; fi; }

WORK=$(mktemp -d)
cp -a "$HERE/proj" "$WORK/src"
cd "$WORK/src"
ZIGCACHE="$WORK/zig-cache"
DISKCACHE="$WORK/disk-cache"
OUTROOT="$WORK/bazel-user"
mkdir -p "$ZIGCACHE" "$DISKCACHE" "$OUTROOT"
export ZIG_LOCAL_CACHE_DIR="$ZIGCACHE"
export ZIG_GLOBAL_CACHE_DIR="$ZIGCACHE"

cat > user.bazelrc <<EOF
build --sandbox_writable_path=$ZIGCACHE
build --action_env=ZIG_LOCAL_CACHE_DIR=$ZIGCACHE
build --action_env=ZIG_GLOBAL_CACHE_DIR=$ZIGCACHE
build --repo_env=CC=$CC
build --repo_env=CXX=$CXX
build --action_env=CC=$CC
build --action_env=CXX=$CXX
EOF

BZ=(bazel --output_user_root="$OUTROOT")
TARGETS=(//server:server //tests:kvutil_test //misc:hello)

say "### 0. 工具版本"
run "${BZ[@]}" version | sed -n '1,8p'
say "compiler: $COMPILER_NOTE"
if [ -x "$CXX" ] || command -v "$CXX" >/dev/null 2>&1; then
  run "$CXX" --version 2>/dev/null | head -2 || true
fi

say
say "### 1. 首次构建库、服务、测试与无关二进制"
run "${BZ[@]}" build "${TARGETS[@]}"
check "server 可执行" "[ -x bazel-bin/server/server ]"
check "test 可执行" "[ -x bazel-bin/tests/kvutil_test ]"
check "hello 可执行" "[ -x bazel-bin/misc/hello ]"
out1=$(./bazel-bin/server/server)
out2=$(./bazel-bin/server/server "timeout_ms=300;retry=2")
say "server default: $out1"
say "server custom: $out2"
check "server 默认输出" "[ \"$out1\" = \"server: timeout_ms=400 retry=1\" ]"
check "server 传参输出" "[ \"$out2\" = \"server: timeout_ms=300 retry=2\" ]"
run ./bazel-bin/misc/hello

say
say "### 2. bazel test"
run "${BZ[@]}" test //tests:kvutil_test --test_output=errors
check "bazel test 通过" "${BZ[@]} test //tests:kvutil_test >/dev/null 2>&1"
run ./bazel-bin/tests/kvutil_test

say
say "### 3. 修改公共头 kv.h，观察重建范围"
echo '// public header touched for rebuild-scope experiment' >> kvutil/kv.h
run "${BZ[@]}" build "${TARGETS[@]}" --explain="$WORK/explain_public.txt" --verbose_explanations --execution_log_json_file="$WORK/inc_public.json"
python3 - "$WORK/inc_public.json" "$WORK/explain_public.txt" <<'PY' | tee -a "$LOG"
import json,sys
from pathlib import Path
raw=Path(sys.argv[1]).read_text()
dec=json.JSONDecoder(); i=0; items=[]
while i<len(raw):
    while i<len(raw) and raw[i].isspace(): i+=1
    if i>=len(raw): break
    obj,end=dec.raw_decode(raw,i); items.append(obj); i=end
comp=[(it.get('targetLabel'), it.get('mnemonic')) for it in items]
print('executed actions:')
for label,mn in comp:
    print(f'  {mn} {label}')
compiles=sorted(label for label,mn in comp if mn=='CppCompile')
print('CppCompile targets=', compiles)
Path(sys.argv[1]+'.summary').write_text(','.join(compiles))
exp=Path(sys.argv[2]).read_text() if Path(sys.argv[2]).exists() else ''
for ln in exp.splitlines():
    if ln.startswith('Executing action'):
        print(ln)
PY
PUB=$(cat "$WORK/inc_public.json.summary" 2>/dev/null || true)
check "公共头变更重编 kvutil" "echo \"$PUB\" | grep -q '//kvutil:kvutil'"
check "公共头变更重编 server" "echo \"$PUB\" | grep -q '//server:server'"
check "公共头变更重编 kvutil_test" "echo \"$PUB\" | grep -q '//tests:kvutil_test'"
check "公共头变更不重编无关 hello" "echo \"$PUB\" | grep -qv '//misc:hello'"

say
say "### 4. 未声明输入：hidden.h 不在 srcs/hdrs，sandbox 应让编译失败"
cat > kvutil/hidden.h <<'EOF'
#pragma once
#define HIDDEN_MARK 1
EOF
python3 - <<'PY'
from pathlib import Path
p=Path('kvutil/kv_parse.cpp')
t=p.read_text()
t=t.replace('#include "trim.h"', '#include "trim.h"\n#include "hidden.h"\n#ifndef HIDDEN_MARK\n#error hidden mark missing\n#endif')
p.write_text(t)
PY
"${BZ[@]}" build //kvutil:kvutil --verbose_failures > "$WORK/undeclared.log" 2>&1
UNDEC=$?
grep -E "fatal error|hidden.h|file not found" "$WORK/undeclared.log" | head -5 | tee -a "$LOG"
say "undeclared build exit=$UNDEC"
check "未声明 hidden.h 时构建失败" "[ $UNDEC -ne 0 ]"
check "报错是找不到 hidden.h" "grep -q \"hidden.h\" \"$WORK/undeclared.log\""

say
say "### 5. 把 hidden.h 写入 srcs 后应通过"
python3 - <<'PY'
from pathlib import Path
p=Path('kvutil/BUILD')
t=p.read_text()
t=t.replace('"trim.h",', '"trim.h",\n        "hidden.h",')
p.write_text(t)
PY
run "${BZ[@]}" build //kvutil:kvutil | tee "$WORK/declared.log"
check "声明 hidden.h 后库能编过" "grep -q 'Build completed successfully' \"$WORK/declared.log\""

say
say "### 6. 磁盘缓存：写入、clean、再构建应命中；改编译参数则编译动作未命中"
cd "$WORK"
rm -rf src
cp -a "$HERE/proj" "$WORK/src"
cd "$WORK/src"
cat > user.bazelrc <<EOF
build --sandbox_writable_path=$ZIGCACHE
build --action_env=ZIG_LOCAL_CACHE_DIR=$ZIGCACHE
build --action_env=ZIG_GLOBAL_CACHE_DIR=$ZIGCACHE
build --repo_env=CC=$CC
build --repo_env=CXX=$CXX
build --action_env=CC=$CC
build --action_env=CXX=$CXX
EOF

run "${BZ[@]}" build "${TARGETS[@]}" --disk_cache="$DISKCACHE"
say "--- bazel clean（保留 disk cache）---"
run "${BZ[@]}" clean
run "${BZ[@]}" build "${TARGETS[@]}" --disk_cache="$DISKCACHE" | tee "$WORK/cache_hit.log"
check "clean 后从 disk cache 命中" "grep -q 'disk cache hit' \"$WORK/cache_hit.log\""

say "--- 增加 --copt（编译命令变化，编译动作不应全部命中旧缓存）---"
run "${BZ[@]}" build "${TARGETS[@]}" --disk_cache="$DISKCACHE" --copt=-DKVUTIL_LESSON=144 | tee "$WORK/cache_copt.log"
check "改 copt 后出现本地执行" "grep -Eq 'linux-sandbox|processwrapper-sandbox' \"$WORK/cache_copt.log\""

say "--- clean 后再以相同 copt 构建，应命中刚才写入的缓存 ---"
run "${BZ[@]}" clean
run "${BZ[@]}" build "${TARGETS[@]}" --disk_cache="$DISKCACHE" --copt=-DKVUTIL_LESSON=144 | tee "$WORK/cache_copt_hit.log"
check "相同 copt 再次 clean 后命中 disk cache" "grep -q 'disk cache hit' \"$WORK/cache_copt_hit.log\""

python3 -c "import json;json.dump({'lesson':144,'id':'j-bazel','failed':$FAIL},open('$HERE/results.json','w'))"
rm -rf "$WORK"
if [ $FAIL -eq 0 ]; then say "ALL_CHECKS_PASSED"; else say "SOME_CHECKS_FAILED"; exit 1; fi
