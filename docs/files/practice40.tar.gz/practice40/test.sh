#!/bin/bash
# Backend Atlas 第40课实践验证：signalfd + 优雅停机
set -u; cd "$(dirname "$0")"; fail=0
gcc -O1 -Wall -pthread -o srv srv.c || exit 1
ok(){ echo "PASS: $1"; }; bad(){ echo "FAIL: $1"; fail=1; }
req(){ python3 - "$1" <<'PY'
import socket,sys
try:
    s=socket.create_connection(("127.0.0.1",int(sys.argv[1])),timeout=5); print(s.recv(10).decode().strip() or "EOF")
except Exception as e: print("REFUSED" if isinstance(e,ConnectionRefusedError) else type(e).__name__)
PY
}
# 场景1：3 个 1.5s 慢请求在途时 SIGTERM，deadline 5s → 排空后退出0，新连接被拒
./srv 18440 1500 5000 > s1.log & P=$!; sleep 0.3
echo "SigBlk 主线程: $(grep SigBlk /proc/$P/status)"
allblk=1; for t in /proc/$P/task/*; do b=$(awk '/SigBlk/{print $2}' $t/status); (( (0x$b & 0x4000) )) || allblk=0; done
n=$(ls /proc/$P/task | wc -l); [ $allblk = 1 ] && ok "全部 $n 个线程 SigBlk 含 SIGTERM(0x4000)" || bad "有线程未屏蔽 SIGTERM"
for i in 1 2 3; do (req 18440 > r1_$i.txt) & done; sleep 0.3
kill -TERM $P; sleep 0.2
nr=$(req 18440); [ "$nr" = REFUSED ] && ok "SIGTERM 后新连接被拒绝" || bad "新连接结果=$nr"
wait $P; rc=$?; wait
oks=$(cat r1_*.txt | grep -c ok)
[ $rc = 0 ] && [ $oks = 3 ] && ok "在途 3 个请求全部完成后退出码 0" || bad "rc=$rc ok=$oks"
cat s1.log
# 场景2：请求要 10s，deadline 1s → 到点强制退出码3
./srv 18441 10000 1000 > s2.log & P=$!; sleep 0.3
(req 18441 > r2.txt) & sleep 0.2
t0=$(date +%s%N); kill -TERM $P; wait $P; rc=$?; t1=$(date +%s%N); wait
ms=$(( (t1-t0)/1000000 ))
[ $rc = 3 ] && [ $ms -lt 2000 ] && ok "deadline 1s 到点强制退出 rc=3 用时 ${ms}ms，客户端看到 $(cat r2.txt)" || bad "rc=$rc ms=$ms"
cat s2.log
# 场景3（反例）：处理器里 printf/malloc 的危险不易稳定复现，这里只用 strace（若有）看 signalfd4
if command -v strace >/dev/null; then ./srv 18442 10 10 >/dev/null & P=$!; sleep 0.3; timeout 2 strace -f -e trace=signal -p $P 2>&1 | head -5 & sleep 0.5; kill -TERM $P; wait; else echo "SKIP: 无 strace"; fi
[ $fail = 0 ] && echo ALL_CHECKS_PASSED
