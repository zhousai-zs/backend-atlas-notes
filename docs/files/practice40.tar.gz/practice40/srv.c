#define _GNU_SOURCE
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/signalfd.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
/* 用法: srv <port> <req_ms> <deadline_ms>
   每个连接 = 一个请求：accept 后 req_ms 毫秒回复 "ok\n" 并关闭 */
#define MAXC 256
static long long now_ms(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000LL+t.tv_nsec/1000000;}
static void *worker(void *a){(void)a;for(;;)pause();return NULL;}
int main(int argc,char**argv){
  int port=atoi(argv[1]); long long req_ms=atoll(argv[2]), dl_ms=atoll(argv[3]);
  sigset_t m; sigemptyset(&m); sigaddset(&m,SIGTERM); sigaddset(&m,SIGINT);
  pthread_sigmask(SIG_BLOCK,&m,NULL);          /* 先屏蔽，再建线程 */
  pthread_t th[4]; for(int i=0;i<4;i++) pthread_create(&th[i],NULL,worker,NULL);
  int sfd=signalfd(-1,&m,SFD_NONBLOCK|SFD_CLOEXEC);
  int lfd=socket(AF_INET,SOCK_STREAM|SOCK_NONBLOCK|SOCK_CLOEXEC,0);
  int one=1; setsockopt(lfd,SOL_SOCKET,SO_REUSEADDR,&one,sizeof one);
  struct sockaddr_in a={.sin_family=AF_INET,.sin_port=htons(port),.sin_addr.s_addr=htonl(0x7f000001)};
  if(bind(lfd,(void*)&a,sizeof a)<0||listen(lfd,64)<0){perror("bind");return 2;}
  int ep=epoll_create1(EPOLL_CLOEXEC); struct epoll_event ev={.events=EPOLLIN};
  ev.data.fd=sfd; epoll_ctl(ep,EPOLL_CTL_ADD,sfd,&ev);
  ev.data.fd=lfd; epoll_ctl(ep,EPOLL_CTL_ADD,lfd,&ev);
  int cfd[MAXC]; long long due[MAXC]; int nc=0, draining=0, accepted=0, served=0; long long deadline=0;
  printf("READY pid=%d\n",getpid()); fflush(stdout);
  for(;;){
    long long now=now_ms(); int timeout=-1;
    for(int i=0;i<nc;i++){ if(due[i]<=now){ write(cfd[i],"ok\n",3); close(cfd[i]); served++; cfd[i]=cfd[--nc]; due[i]=due[nc]; i--; } }
    if(draining){
      if(nc==0){ printf("DRAINED accepted=%d served=%d\n",accepted,served); return 0; }
      if(now>=deadline){ printf("DEADLINE_FORCE_EXIT inflight=%d served=%d\n",nc,served); fflush(stdout); _exit(3); }
      timeout=(int)(deadline-now);
    }
    for(int i=0;i<nc;i++){ int t=(int)(due[i]-now); if(timeout<0||t<timeout) timeout=t<0?0:t; }
    struct epoll_event evs[16]; int n=epoll_wait(ep,evs,16,timeout);
    if(n<0){ if(errno==EINTR) continue; return 1; }
    for(int i=0;i<n;i++){
      int fd=evs[i].data.fd;
      if(fd==sfd){ struct signalfd_siginfo si;
        while(read(sfd,&si,sizeof si)==sizeof si){
          if(!draining){ draining=1; deadline=now_ms()+dl_ms;
            epoll_ctl(ep,EPOLL_CTL_DEL,lfd,NULL); close(lfd); lfd=-1;
            printf("SIGTERM from pid=%u, draining inflight=%d\n",si.ssi_pid,nc); fflush(stdout);} } }
      else if(fd==lfd){ int c; while(nc<MAXC&&(c=accept4(lfd,NULL,NULL,SOCK_CLOEXEC))>=0){ cfd[nc]=c; due[nc]=now_ms()+req_ms; nc++; accepted++; } }
    }
  }
}
