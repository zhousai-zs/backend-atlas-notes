"""Durable retrieve → report → index with crash points, leases, and version gates.

Side-effect policy:
  retrieve_logs  — pure read; safe to replay
  write_report   — idempotent upsert keyed by task_id (UNIQUE); replay overwrites with the same body
  publish_index  — idempotent upsert keyed by task_id; only after report exists

Two workers cannot commit different results because the first successful write
of a report body is frozen; a conflicting body is rejected (not last-writer-wins).
"""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE tasks(
  task_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  version INTEGER NOT NULL,
  permission TEXT NOT NULL,     -- granted | revoked
  state TEXT NOT NULL,          -- pending|running|paused|failed|completed
  step TEXT NOT NULL,           -- retrieve_logs|write_report|publish_index|done
  lease_owner TEXT,
  lease_until REAL,
  crash_at TEXT                 -- optional hook: raise after entering this step
);
CREATE TABLE reports(
  task_id TEXT PRIMARY KEY,
  body TEXT NOT NULL,
  request_id TEXT NOT NULL UNIQUE
);
CREATE TABLE index_entries(
  task_id TEXT PRIMARY KEY,
  pointer TEXT NOT NULL
);
CREATE TABLE events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id TEXT, at REAL, kind TEXT, detail TEXT
);
"""

STEPS = ["retrieve_logs", "write_report", "publish_index", "done"]


class IncompatibleVersion(Exception):
    pass


class PermissionRevoked(Exception):
    pass


class LeaseHeld(Exception):
    pass


class ConflictingReport(Exception):
    pass


class Crash(Exception):
    def __init__(self, step):
        super().__init__(step)
        self.step = step


class Durable:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            path.unlink()
        self.conn = sqlite3.connect(path, timeout=10)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.executescript(SCHEMA)
        self.conn.commit()
        self.current_code_version = 2

    def log(self, task_id, kind, detail=""):
        self.conn.execute(
            "INSERT INTO events(task_id,at,kind,detail) VALUES(?,?,?,?)",
            (task_id, time.time(), kind, detail),
        )
        self.conn.commit()

    def create_task(self, task_id, user_id, *, version, permission="granted", crash_at=None):
        self.conn.execute(
            "INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?)",
            (task_id, user_id, version, permission, "pending", "retrieve_logs", None, 0, crash_at),
        )
        self.conn.commit()

    def _row(self, task_id):
        cols = ["task_id","user_id","version","permission","state","step","lease_owner","lease_until","crash_at"]
        r = self.conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
        return dict(zip(cols, r))

    def acquire(self, task_id, worker, now=None, ttl=30):
        now = time.time() if now is None else now
        t = self._row(task_id)
        if t["version"] != self.current_code_version:
            self.conn.execute("UPDATE tasks SET state='paused' WHERE task_id=?", (task_id,))
            self.conn.commit()
            self.log(task_id, "incompatible_version", f"task={t['version']} code={self.current_code_version}")
            raise IncompatibleVersion(t["version"])
        if t["permission"] != "granted":
            self.conn.execute("UPDATE tasks SET state='paused' WHERE task_id=?", (task_id,))
            self.conn.commit()
            self.log(task_id, "permission_revoked", t["permission"])
            raise PermissionRevoked(t["permission"])
        if t["lease_owner"] and t["lease_until"] and t["lease_until"] > now and t["lease_owner"] != worker:
            raise LeaseHeld(t["lease_owner"])
        self.conn.execute(
            "UPDATE tasks SET lease_owner=?, lease_until=?, state='running' WHERE task_id=?",
            (worker, now + ttl, task_id),
        )
        self.conn.commit()
        self.log(task_id, "lease_acquired", worker)
        return self._row(task_id)

    def release(self, task_id, worker):
        self.conn.execute(
            "UPDATE tasks SET lease_owner=NULL, lease_until=0 WHERE task_id=? AND lease_owner=?",
            (task_id, worker),
        )
        self.conn.commit()

    def _maybe_crash(self, t, step):
        if t["crash_at"] == step:
            # Clear the hook so recovery can proceed.
            self.conn.execute("UPDATE tasks SET crash_at=NULL WHERE task_id=?", (t["task_id"],))
            self.conn.commit()
            self.log(t["task_id"], "crash", step)
            raise Crash(step)

    def retrieve_logs(self, task_id, worker) -> str:
        t = self._row(task_id)
        self._maybe_crash(t, "retrieve_logs")
        body = f"logs-for-{task_id}"
        self.log(task_id, "retrieve_logs", "ok")
        # Advance only if still on this step (replay of a later step is a no-op here).
        if t["step"] == "retrieve_logs":
            self.conn.execute("UPDATE tasks SET step='write_report' WHERE task_id=?", (task_id,))
            self.conn.commit()
        return body  # safe to replay: no durable side effect besides the step pointer

    def write_report(self, task_id, worker, body: str, request_id: str):
        t = self._row(task_id)
        existing = self.conn.execute("SELECT body, request_id FROM reports WHERE task_id=?", (task_id,)).fetchone()
        if existing:
            if existing[0] != body:
                self.log(task_id, "conflicting_report", f"have={existing[1]} got={request_id}")
                raise ConflictingReport(existing[1])
            self.log(task_id, "write_report", "idempotent_replay")
        else:
            self._maybe_crash(t, "write_report")  # crash BEFORE the insert → recovery must write once
            self.conn.execute("INSERT INTO reports(task_id,body,request_id) VALUES(?,?,?)", (task_id, body, request_id))
            self.conn.commit()
            self.log(task_id, "write_report", request_id)
        if t["step"] in {"retrieve_logs", "write_report"}:
            self.conn.execute("UPDATE tasks SET step='publish_index' WHERE task_id=?", (task_id,))
            self.conn.commit()

    def publish_index(self, task_id, worker):
        t = self._row(task_id)
        report = self.conn.execute("SELECT request_id FROM reports WHERE task_id=?", (task_id,)).fetchone()
        if not report:
            raise RuntimeError("index requires an existing report")
        existing = self.conn.execute("SELECT pointer FROM index_entries WHERE task_id=?", (task_id,)).fetchone()
        pointer = f"idx://{task_id}/{report[0]}"
        if existing:
            self.log(task_id, "publish_index", "idempotent_replay")
        else:
            self._maybe_crash(t, "publish_index")
            self.conn.execute("INSERT INTO index_entries(task_id,pointer) VALUES(?,?)", (task_id, pointer))
            self.conn.commit()
            self.log(task_id, "publish_index", pointer)
        self.conn.execute("UPDATE tasks SET step='done', state='completed', lease_owner=NULL, lease_until=0 WHERE task_id=?", (task_id,))
        self.conn.commit()

    def run(self, task_id, worker, body, request_id):
        self.acquire(task_id, worker)
        try:
            t = self._row(task_id)
            if t["step"] == "retrieve_logs":
                body_src = self.retrieve_logs(task_id, worker)
                # Prefer caller-supplied body (deterministic in tests); source is still retrieved.
                body = body or body_src
            if self._row(task_id)["step"] == "write_report":
                self.write_report(task_id, worker, body, request_id)
            if self._row(task_id)["step"] == "publish_index":
                self.publish_index(task_id, worker)
            return self._row(task_id)
        finally:
            # completed tasks already released; failed mid-flight keep the lease until expiry
            # so a second worker cannot interleave, unless we are crashing (lease holder is dead).
            pass

    def counts(self, task_id):
        n_rep = self.conn.execute("SELECT COUNT(*) FROM reports WHERE task_id=?", (task_id,)).fetchone()[0]
        n_idx = self.conn.execute("SELECT COUNT(*) FROM index_entries WHERE task_id=?", (task_id,)).fetchone()[0]
        ev = [r[0] for r in self.conn.execute("SELECT kind FROM events WHERE task_id=? ORDER BY id", (task_id,)).fetchall()]
        return n_rep, n_idx, ev, self._row(task_id)
