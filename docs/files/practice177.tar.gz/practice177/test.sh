#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert len(r["crash_points"])==3
for step, info in r["crash_points"].items():
    assert info["after_recovery"]["reports"]==1 and info["after_recovery"]["index"]==1
assert r["two_workers_conflicting_body_rejected"] and r["surviving_report_body"]=="body-A"
assert r["incompatible_version_paused"] and r["revoked_permission_paused"]
for tid, c in r["report_and_index_counts_after_all_recoveries"].items():
    assert c["reports"]==1 and c["index"]==1, (tid, c)
print("POSTCHECK_OK")
PY
