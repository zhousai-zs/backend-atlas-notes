#!/usr/bin/env python3
"""Three crash points, single valid report/index, two-worker conflict, version/permission gates."""

from __future__ import annotations

import json
from pathlib import Path

from durable import (
    ConflictingReport,
    Crash,
    Durable,
    IncompatibleVersion,
    PermissionRevoked,
)

ROOT = Path(__file__).resolve().parent
DB = ROOT / "reports/durable.db"
d = Durable(DB)

# --- three crash points: retrieve, write, index ---
crashes = {}
for step, tid in [("retrieve_logs", "t-crash-retrieve"),
                  ("write_report", "t-crash-write"),
                  ("publish_index", "t-crash-index")]:
    d.create_task(tid, "alice", version=2, crash_at=step)
    body = f"report-body-{tid}"
    rid = f"req-{tid}"
    try:
        d.run(tid, "worker-A", body, rid)
        raise SystemExit(f"expected crash at {step}")
    except Crash as e:
        assert e.step == step
    # After crash, at most one (usually zero) report/index exists; recovery must converge to one.
    n_rep, n_idx, ev, row = d.counts(tid)
    # recover with the same worker id after "process restart" (lease may still be held by worker-A;
    # we simulate death by clearing the lease, as a real dead process would expire it).
    d.conn.execute("UPDATE tasks SET lease_owner=NULL, lease_until=0 WHERE task_id=?", (tid,))
    d.conn.commit()
    final = d.run(tid, "worker-A-restart", body, rid)
    n_rep2, n_idx2, ev2, row2 = d.counts(tid)
    assert n_rep2 == 1 and n_idx2 == 1, (tid, n_rep2, n_idx2, ev2)
    assert row2["state"] == "completed" and row2["step"] == "done"
    crashes[step] = {
        "after_crash": {"reports": n_rep, "index": n_idx, "step": row["step"], "events": ev},
        "after_recovery": {"reports": n_rep2, "index": n_idx2, "state": row2["state"], "events": ev2},
    }

# --- two workers cannot commit different results ---
d.create_task("t-race", "alice", version=2)
d.acquire("t-race", "worker-A")
d.retrieve_logs("t-race", "worker-A")
d.write_report("t-race", "worker-A", "body-A", "req-A")
# Simulate lease expiry so B can try a conflicting body
d.conn.execute("UPDATE tasks SET lease_owner=NULL, lease_until=0 WHERE task_id='t-race'")
d.conn.commit()
d.acquire("t-race", "worker-B")
conflicted = False
try:
    d.write_report("t-race", "worker-B", "body-B-DIFFERENT", "req-B")
except ConflictingReport:
    conflicted = True
assert conflicted
# Original body stands; B may still publish the existing report (idempotent), not a second one
d.publish_index("t-race", "worker-B")
n_rep, n_idx, ev, row = d.counts("t-race")
assert n_rep == 1 and n_idx == 1
stored = d.conn.execute("SELECT body FROM reports WHERE task_id='t-race'").fetchone()[0]
assert stored == "body-A"

# --- incompatible version pauses ---
d.create_task("t-ver", "alice", version=1)  # code expects 2
ver_paused = False
try:
    d.acquire("t-ver", "worker-A")
except IncompatibleVersion:
    ver_paused = True
assert ver_paused and d._row("t-ver")["state"] == "paused"

# --- revoked permission pauses ---
d.create_task("t-rev", "alice", version=2, permission="revoked")
rev_paused = False
try:
    d.acquire("t-rev", "worker-A")
except PermissionRevoked:
    rev_paused = True
assert rev_paused and d._row("t-rev")["state"] == "paused"

replay_policy = {
    "retrieve_logs": "pure read; safe to replay; only advances step if still on retrieve_logs",
    "write_report": "UNIQUE(task_id) upsert; same body is idempotent, different body is rejected",
    "publish_index": "UNIQUE(task_id) upsert after report exists; pointer derived from request_id",
}

results = {
    "lesson": 177,
    "id": "l-durable",
    "is_live_distributed_cluster": False,
    "crash_points": crashes,
    "two_workers_conflicting_body_rejected": True,
    "surviving_report_body": stored,
    "incompatible_version_paused": ver_paused,
    "revoked_permission_paused": rev_paused,
    "replay_policy": replay_policy,
    "report_and_index_counts_after_all_recoveries": {
        tid: {"reports": d.counts(tid)[0], "index": d.counts(tid)[1]}
        for tid in ["t-crash-retrieve", "t-crash-write", "t-crash-index", "t-race"]
    },
    "verified_on_this_machine": [
        "three_crash_points_recover_to_single_report_and_index",
        "conflicting_second_writer_rejected",
        "incompatible_version_and_revoked_permission_pause",
    ],
    "not_verified_on_this_machine": [
        "multi_process_OS_crash_of_the_Python_interpreter",
        "network-partitioned_SQLite_or_external_queue",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({k: v["after_recovery"] for k, v in crashes.items()}, indent=2))
print("ALL_CHECKS_PASSED")
