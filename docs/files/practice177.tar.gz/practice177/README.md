# 实践 177：持久状态与任务恢复

在解压后的 `practice177/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（标准库 + sqlite3）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

单机 SQLite 租约与幂等写入。不是分布式集群故障演练。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
