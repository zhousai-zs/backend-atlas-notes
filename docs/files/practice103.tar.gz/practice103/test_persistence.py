#!/usr/bin/env python3
"""Acceptance checks for the g-persistence teaching lab."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments

HERE = os.path.dirname(os.path.abspath(__file__))
PERSISTENCE_DOC = "https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/"


def main() -> int:
    data = run_all_experiments()
    data.update(
        {
            "python": sys.version.split()[0],
            "persistence_doc": PERSISTENCE_DOC,
            "docs_checked": "2026-11-12",
        }
    )

    _assert_rdb(data["rdb_window"])
    _assert_fsync(data["fsync_policies"])
    _assert_rewrite(data["aof_rewrite"])
    _assert_cow(data["fork_cow"])
    _assert_both(data["rdb_plus_aof"])
    _assert_backup(data["replica_vs_backup"])
    _assert_trunc(data["truncated_aof"])
    _assert_latency(data["write_latency"])
    _assert_rto(data["rto_compare"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2, default=_roundtrip)
        fh.write("\n")

    rdb = data["rdb_window"]
    fs = data["fsync_policies"]
    rw = data["aof_rewrite"]
    cow = data["fork_cow"]
    both = data["rdb_plus_aof"]
    bak = data["replica_vs_backup"]
    tr = data["truncated_aof"]
    lat = data["write_latency"]
    rto = data["rto_compare"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"rdb_loose_lost={rdb['loose']['lost_writes']} rpo={rdb['loose']['rpo_s']} "
        f"rdb_loose_rto={rdb['loose']['rto_s']:.4f} "
        f"rdb_tight_lost={rdb['tight']['lost_writes']} "
        f"always_lost={fs['always']['power_loss']['lost_writes']} "
        f"everysec_lost={fs['everysec']['power_loss']['lost_writes']} "
        f"everysec_rpo={fs['everysec']['power_loss']['rpo_s']} "
        f"no_lost={fs['no']['power_loss']['lost_writes']} no_rpo={fs['no']['power_loss']['rpo_s']} "
        f"kill9_always_lost={fs['always']['process_kill']['lost_writes']} "
        f"rewrite {rw['before']['bytes']}->{rw['rewrite']['bytes_after']} "
        f"val={rw['recovered_value']} "
        f"cow_idle={cow['idle']['cow_pages']} cow_busy={cow['busy']['cow_pages']} "
        f"both_src={both['default']['source']} both_lost={both['default']['lost_writes']} "
        f"rdb_only_lost={both['rdb_only']['lost_writes']} "
        f"replica_after={bak['replica_after_flushall']} "
        f"backup={bak['backup_restored_dbsize']} "
        f"trunc_lost={tr['lost_writes']} trunc={tr['truncated_aof']} "
        f"lat_always={lat['always']['elapsed_s']}s/{lat['always']['fsync_count']} "
        f"lat_everysec={lat['everysec']['elapsed_s']}s/{lat['everysec']['fsync_count']} "
        f"rto_rdb={rto['rdb']['rto_s']:.4f} rto_aof={rto['long_aof']['rto_s']:.4f} "
        f"rto_rw={rto['rewritten_aof']['rto_s']:.4f}"
    )
    return 0


def _roundtrip(obj):
    if isinstance(obj, float):
        return obj
    raise TypeError(type(obj))


def _assert_rdb(d: dict) -> None:
    loose, tight = d["loose"], d["tight"]
    assert loose["lost_writes"] == d["delta_writes"], loose
    assert loose["rpo_s"] == d["gap_s"], loose
    assert loose["flag"] is None
    assert loose["article_1"] == "draft:1"
    assert loose["source"] == "rdb"
    assert loose["rto_s"] >= 0
    assert tight["lost_writes"] == 0, tight
    assert tight["rpo_s"] == 0.0, tight
    assert tight["flag"] == "late"
    assert tight["article_1"] == "published:1"
    # Never treat "a later snapshot happened to land" as unconditional zero loss.
    assert loose["lost_writes"] > 0


def _assert_fsync(d: dict) -> None:
    always, every, none = d["always"], d["everysec"], d["no"]
    writes = always["power_loss"]["lost_writes"] + always["power_loss"]["recovered_dbsize"]
    assert writes == always["writes"]
    assert always["power_loss"]["lost_writes"] == 0, always
    assert always["power_loss"]["rpo_s"] == 0.0
    assert 0 < every["power_loss"]["lost_writes"] < every["writes"], every
    assert 0 < every["power_loss"]["rpo_s"] <= 1.0 + 1e-9, every
    assert none["power_loss"]["lost_writes"] == none["writes"], none
    assert none["power_loss"]["rpo_s"] >= every["power_loss"]["rpo_s"]
    assert none["power_loss"]["rpo_s"] == d["crash_s"]
    # A process-only kill keeps the page cache, so even 'no' can look lossless.
    # That must not be reported as a durability guarantee against power loss.
    assert always["process_kill"]["lost_writes"] == 0
    assert every["process_kill"]["lost_writes"] == 0
    assert none["process_kill"]["lost_writes"] == 0


def _assert_rewrite(d: dict) -> None:
    assert d["before"]["value"] == d["increments"]
    assert d["recovered_value"] == d["increments"]
    assert d["rewrite"]["bytes_after"] < d["before"]["bytes"]
    assert d["rewrite"]["records_after"] < d["rewrite"]["records_before"]
    assert d["lost_writes"] == 0
    assert d["rpo_s"] == 0.0


def _assert_cow(d: dict) -> None:
    assert d["idle"]["cow_pages"] == 0, d["idle"]
    assert d["busy"]["cow_pages"] == d["parent_writes"], d["busy"]
    assert d["busy"]["cow_bytes"] == d["parent_writes"] * 64
    assert d["rdb_article_1"] == "draft:1"
    assert d["parent_article_1"] == "dirty:article:1"
    assert d["idle"]["keys"] == d["keys"]
    assert d["busy"]["keys"] == d["keys"]


def _assert_both(d: dict) -> None:
    assert d["default"]["source"] == "aof"
    assert d["rdb_only"]["source"] == "rdb"
    assert d["default"]["lost_writes"] < d["rdb_only"]["lost_writes"]
    assert d["rdb_only"]["max_late"] == 0
    assert d["default"]["max_late"] > 0
    assert d["default"]["rpo_s"] <= 1.0 + 1e-9
    assert d["rdb_only"]["lost_writes"] == d["late_writes"]


def _assert_backup(d: dict) -> None:
    assert d["replica_before"] == d["seed"]
    assert d["replica_after_flushall"] == 0
    assert d["primary_after_flushall"] == 0
    assert d["replica_article_1"] is None
    assert d["backup_restored_dbsize"] == d["seed"]
    assert d["backup_article_1"] == "draft:1"


def _assert_trunc(d: dict) -> None:
    assert d["truncated_aof"] is True
    assert d["lost_writes"] == 1
    assert d["recovered_dbsize"] == d["writes"] - 1
    assert d["max_seq"] == d["writes"] - 1


def _assert_latency(d: dict) -> None:
    assert d["always"]["fsync_count"] >= d["n"]
    assert d["everysec"]["fsync_count"] < d["always"]["fsync_count"]
    assert d["always"]["elapsed_s"] > d["everysec"]["elapsed_s"]
    assert d["always"]["elapsed_s"] > d["no"]["elapsed_s"]


def _assert_rto(d: dict) -> None:
    assert d["long_aof"]["views"] == d["increments"], d["long_aof"]
    assert d["rewritten_aof"]["views"] == d["increments"], d["rewritten_aof"]
    assert d["long_aof"]["rto_s"] >= d["rdb"]["rto_s"] - 1e-4
    assert d["rewritten_aof"]["bytes"] < d["long_aof"]["bytes"]
    assert d["rdb"]["dbsize"] == d["seed"] + 1
    assert d["rdb"]["views"] == d["increments"]
    assert d["long_aof"]["dbsize"] == d["seed"] + 1
    assert d["rewritten_aof"]["dbsize"] == d["seed"] + 1
    # Rewritten AOF should replay fewer bytes; RTO is measured but may be close
    # on a small teaching dataset, so we only require it to be a real number.
    assert d["rewritten_aof"]["rto_s"] >= 0


if __name__ == "__main__":
    sys.exit(main())
