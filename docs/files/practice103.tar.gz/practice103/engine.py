#!/usr/bin/env python3
"""Teaching PersistenceEngine — not Redis.

A Python standard-library model of Redis-style persistence: RDB
snapshots, AOF write logs, fsync policies, AOF rewrite, and a
fork/copy-on-write cost account used during background snapshots.

This is not Redis, not redis-py, and not a network server. The
persistence, fsync, rewrite, restart-preference, and backup semantics
follow the Redis persistence documentation checked on 2026-11-12, for
the subset implemented here. Replication protocol, Redis 7 multi-part
AOF manifests, Redis 8 BACKUP commands, evictions, and expiration are
not modeled.
"""
from __future__ import annotations

import copy
import json
import os
import shutil
import threading
import time
from typing import Any, Optional


class Clock:
    """A clock tests can freeze and advance, or run from time.monotonic()."""

    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        # Round so repeated 0.1-second steps land on exact tenths,
        # matching the 1-second fsync timer in the labs.
        self.t = round(self.t + float(seconds), 10)


class DurableFile:
    """A file with an explicit page cache and a durable image.

    write() goes to the OS page cache. fsync() commits that cache to
    the durable image (the bytes that survive a machine/power crash).
    A process-only kill leaves the page cache in place. This is a
    teaching model of fsync, not a claim about one filesystem.
    """

    def __init__(self, path: str, real_fsync: bool = False) -> None:
        self.path = path
        self.real_fsync = bool(real_fsync)
        self.durable = bytearray()
        self.cache = bytearray()
        self.fsync_count = 0
        self.fsync_s = 0.0
        self.write_count = 0
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)

    def write(self, data: bytes) -> None:
        if not data:
            return
        self.cache.extend(data)
        self.write_count += 1
        if self.real_fsync:
            with open(self.path, "ab") as fh:
                fh.write(data)

    def fsync(self) -> None:
        t0 = time.perf_counter()
        if self.cache:
            self.durable.extend(self.cache)
            self.cache.clear()
        if self.real_fsync:
            directory = os.path.dirname(self.path) or "."
            os.makedirs(directory, exist_ok=True)
            with open(self.path, "ab") as fh:
                fh.flush()
                os.fsync(fh.fileno())
        self.fsync_s += time.perf_counter() - t0
        self.fsync_count += 1

    def replace_durable(self, data: bytes, fsync: bool = True) -> None:
        """Atomically replace the file contents (temp + rename teaching model)."""
        self.cache = bytearray()
        self.durable = bytearray(data)
        if self.real_fsync:
            tmp = self.path + ".tmp"
            with open(tmp, "wb") as fh:
                fh.write(data)
                if fsync:
                    fh.flush()
                    os.fsync(fh.fileno())
            os.replace(tmp, self.path)
        if fsync:
            self.fsync_count += 1

    def power_loss(self, truncate_partial_line: bool = False) -> None:
        self.cache = bytearray()
        if truncate_partial_line and self.durable:
            # Tear the last record so recovery must discard it, matching a
            # crash in the middle of the last append.
            if self.durable.endswith(b"\n"):
                self.durable = self.durable[:-1]
            else:
                del self.durable[-min(8, len(self.durable)) :]

    def process_kill(self) -> None:
        # Kernel page cache survives a process-only kill.
        pass

    def durable_bytes(self) -> bytes:
        return bytes(self.durable)

    def cached_bytes(self) -> bytes:
        return bytes(self.durable) + bytes(self.cache)

    def size_durable(self) -> int:
        return len(self.durable)

    def size_cached(self) -> int:
        return len(self.durable) + len(self.cache)


def encode_cmd(op: str, *args: Any) -> bytes:
    payload = [op, *[arg if isinstance(arg, (str, int, float, bool)) or arg is None else json.dumps(arg, ensure_ascii=False) for arg in args]]
    # Values are JSON-encoded so a payload can contain spaces but not confuse the line format.
    parts = [op]
    for arg in args:
        parts.append(json.dumps(arg, ensure_ascii=False))
    return (" ".join(parts) + "\n").encode("utf-8")


def decode_cmds(blob: bytes) -> tuple[list[list[Any]], bool]:
    """Parse complete AOF lines. A trailing partial line is discarded.

    Returns (commands, truncated).
    """
    text = blob.decode("utf-8", errors="replace")
    truncated = bool(text) and not text.endswith("\n")
    if truncated:
        text = text.rsplit("\n", 1)[0] + "\n" if "\n" in text else ""
    commands: list[list[Any]] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split(" ", 1)
        op = parts[0]
        rest = parts[1] if len(parts) > 1 else ""
        args = []
        if rest:
            # Command arguments were each json.dumps()'d and joined by spaces.
            decoder = json.JSONDecoder()
            idx = 0
            while idx < len(rest):
                if rest[idx].isspace():
                    idx += 1
                    continue
                val, end = decoder.raw_decode(rest, idx)
                args.append(val)
                idx = end
        commands.append([op, *args])
    return commands, truncated


class PersistenceEngine:
    """In-process teaching store with RDB / AOF persistence."""

    def __init__(
        self,
        data_dir: str,
        clock: Optional[Clock] = None,
        mode: str = "aof",  # none | rdb | aof | both
        aof_fsync: str = "everysec",  # always | everysec | no
        os_flush_s: float = 30.0,
        save_seconds: float = 0.0,
        save_min_changes: int = 0,
        real_fsync: bool = False,
        page_bytes: int = 64,
    ) -> None:
        if mode not in {"none", "rdb", "aof", "both"}:
            raise ValueError(f"unknown mode: {mode}")
        if aof_fsync not in {"always", "everysec", "no"}:
            raise ValueError(f"unknown aof_fsync: {aof_fsync}")
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.clock = clock or Clock()
        self.mode = mode
        self.aof_fsync = aof_fsync
        self.os_flush_s = float(os_flush_s)
        self.save_seconds = float(save_seconds)
        self.save_min_changes = int(save_min_changes)
        self.real_fsync = bool(real_fsync)
        self.page_bytes = int(page_bytes)

        self.data: dict[str, Any] = {}
        self.pages: dict[str, int] = {}  # key -> page generation
        self.next_page_gen = 1
        self.changes_since_rdb = 0
        self.last_rdb_s = self.clock.now()
        self.last_aof_fsync_s = self.clock.now()
        self.last_os_flush_s = self.clock.now()
        self.acked_seq = 0
        self.write_seq = 0
        self.write_log: list[tuple[int, float, str, tuple]] = []  # seq, t, op, args (acked)
        self.rdb = DurableFile(os.path.join(data_dir, "dump.rdb"), real_fsync=real_fsync)
        self.aof = DurableFile(os.path.join(data_dir, "appendonly.aof"), real_fsync=real_fsync)
        self.replicas: list["PersistenceEngine"] = []

        # fork / COW accounting for an in-progress background snapshot
        self.bgsave_in_progress = False
        self.bgsave_pages: Optional[dict[str, int]] = None
        self.cow_pages = 0
        self.cow_bytes = 0
        self.fork_s = 0.0
        self.child_write_s = 0.0
        self.lock = threading.Lock()

        self.stats = {
            "sets": 0,
            "incrs": 0,
            "dels": 0,
            "flushalls": 0,
            "rdb_saves": 0,
            "aof_rewrites": 0,
            "aof_records": 0,
        }

    # ------------------------------------------------------------------ data
    def get(self, key: str) -> Any:
        with self.lock:
            return copy.deepcopy(self.data.get(key))

    def dbsize(self) -> int:
        with self.lock:
            return len(self.data)

    def snapshot_data(self) -> dict[str, Any]:
        with self.lock:
            return copy.deepcopy(self.data)

    def set(self, key: str, value: Any) -> None:
        self._apply_and_persist("SET", key, value)

    def incr(self, key: str, amount: int = 1) -> int:
        result_box: list[int] = []

        def mutate() -> None:
            current = int(self.data.get(key, 0) or 0) + int(amount)
            self._install(key, current)
            result_box.append(current)
            self.stats["incrs"] += 1

        self._apply_and_persist("INCR", key, amount, mutate=mutate)
        return result_box[0]

    def delete(self, key: str) -> int:
        existed = [0]

        def mutate() -> None:
            if key in self.data:
                self._touch_cow(key)
                del self.data[key]
                self.pages.pop(key, None)
                existed[0] = 1
            self.stats["dels"] += 1

        self._apply_and_persist("DEL", key, mutate=mutate)
        return existed[0]

    def flushall(self) -> None:
        def mutate() -> None:
            for key in list(self.data):
                self._touch_cow(key)
            self.data.clear()
            self.pages.clear()
            self.stats["flushalls"] += 1

        self._apply_and_persist("FLUSHALL", mutate=mutate)

    def _install(self, key: str, value: Any) -> None:
        self._touch_cow(key)
        self.data[key] = value
        self.pages[key] = self.next_page_gen
        self.next_page_gen += 1
        self.stats["sets"] += 1 if key in self.data else self.stats["sets"]

    def _touch_cow(self, key: str) -> None:
        if not self.bgsave_in_progress or self.bgsave_pages is None:
            return
        old = self.pages.get(key)
        # Copy a page if the child still holds this key's current generation.
        if old is not None and self.bgsave_pages.get(key) == old:
            self.cow_pages += 1
            self.cow_bytes += self.page_bytes
            # Child keeps the old generation; parent will bump on write.
            self.bgsave_pages[key] = -1  # already charged

    def _apply_and_persist(
        self,
        op: str,
        *args: Any,
        mutate: Optional[Any] = None,
    ) -> None:
        with self.lock:
            self.write_seq += 1
            seq = self.write_seq
            if mutate is not None:
                mutate()
            elif op == "SET":
                self._install(str(args[0]), args[1])
                # _install increments sets; keep del/incr counters elsewhere
            else:
                raise ValueError(f"unhandled op {op}")
            self.changes_since_rdb += 1
            t = self.clock.now()
            if self.mode in {"aof", "both"}:
                self.aof.write(encode_cmd(op, *args))
                self.stats["aof_records"] += 1
                if self.aof_fsync == "always":
                    self.aof.fsync()
                    self.last_aof_fsync_s = t
            self._maybe_flush_locked()
            self._maybe_autosave_locked()
            # A write is acknowledged only after the configured durability step.
            # always: fsync already happened. everysec/no: the write is in the
            # page cache (and maybe later flushed). Redis still replies after
            # appending, except that always waits for fsync before replies.
            self.acked_seq = seq
            self.write_log.append((seq, t, op, args))
        for replica in list(self.replicas):
            replica._apply_replica(op, *args)

    def _apply_replica(self, op: str, *args: Any) -> None:
        # Replicas receive the same write stream, including deletions.
        if op == "SET":
            self._apply_and_persist("SET", *args)
            return

        def mutate() -> None:
            if op == "INCR":
                key, amount = str(args[0]), int(args[1])
                current = int(self.data.get(key, 0) or 0) + amount
                self._install(key, current)
                self.stats["incrs"] += 1
            elif op == "DEL":
                key = str(args[0])
                if key in self.data:
                    self._touch_cow(key)
                    del self.data[key]
                    self.pages.pop(key, None)
                self.stats["dels"] += 1
            elif op == "FLUSHALL":
                for key in list(self.data):
                    self._touch_cow(key)
                self.data.clear()
                self.pages.clear()
                self.stats["flushalls"] += 1
            else:
                raise ValueError(op)

        self._apply_and_persist(op, *args, mutate=mutate)

    def attach_replica(self, replica: "PersistenceEngine") -> None:
        with self.lock:
            snapshot = copy.deepcopy(self.data)
        for key, value in snapshot.items():
            replica.set(key, value)
        self.replicas.append(replica)

    # ------------------------------------------------------------------ flush / save
    def advance(self, seconds: float) -> None:
        self.clock.advance(seconds)
        with self.lock:
            self._maybe_flush_locked()
            self._maybe_autosave_locked()

    def _maybe_flush_locked(self) -> None:
        if self.mode not in {"aof", "both"}:
            return
        now = self.clock.now()
        if self.aof_fsync == "everysec":
            # Timer-style fsync: whenever a full second has elapsed.
            if now - self.last_aof_fsync_s >= 1.0:
                self.aof.fsync()
                self.last_aof_fsync_s = now
        elif self.aof_fsync == "no":
            if now - self.last_os_flush_s >= self.os_flush_s:
                self.aof.fsync()
                self.last_os_flush_s = now

    def _maybe_autosave_locked(self) -> None:
        if self.mode not in {"rdb", "both"}:
            return
        if self.save_seconds <= 0 or self.save_min_changes <= 0:
            return
        now = self.clock.now()
        if (
            now - self.last_rdb_s >= self.save_seconds
            and self.changes_since_rdb >= self.save_min_changes
        ):
            self._save_rdb_locked()

    def save(self) -> dict[str, Any]:
        with self.lock:
            return self._save_rdb_locked()

    def bgsave(self, parent_writes: int = 0, write_fn: Optional[Any] = None) -> dict[str, Any]:
        """Start a background snapshot, optionally issuing parent writes for COW.

        The snapshot itself is taken at fork time (copy-on-write: the child
        writes the forked image, later parent writes are not in this RDB).
        """
        with self.lock:
            t_fork = time.perf_counter()
            child_data = copy.deepcopy(self.data)
            self.bgsave_in_progress = True
            self.bgsave_pages = dict(self.pages)
            self.cow_pages = 0
            self.cow_bytes = 0
            self.fork_s = time.perf_counter() - t_fork
        if write_fn is not None:
            write_fn()
        elif parent_writes:
            # Deterministic parent mutations used by the COW experiment.
            keys = list(child_data.keys())[:parent_writes]
            for key in keys:
                self.set(key, f"dirty:{key}")
        with self.lock:
            t_child = time.perf_counter()
            payload = json.dumps(
                {"t": self.clock.now(), "data": child_data},
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8")
            self.rdb.replace_durable(payload, fsync=True)
            self.child_write_s = time.perf_counter() - t_child
            self.bgsave_in_progress = False
            self.bgsave_pages = None
            self.changes_since_rdb = 0
            self.last_rdb_s = self.clock.now()
            self.stats["rdb_saves"] += 1
            return {
                "keys": len(child_data),
                "bytes": len(payload),
                "fork_s": self.fork_s,
                "child_write_s": self.child_write_s,
                "cow_pages": self.cow_pages,
                "cow_bytes": self.cow_bytes,
                "parent_writes": parent_writes,
            }

    def _save_rdb_locked(self) -> dict[str, Any]:
        t0 = time.perf_counter()
        payload = json.dumps(
            {"t": self.clock.now(), "data": self.data},
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        self.rdb.replace_durable(payload, fsync=True)
        elapsed = time.perf_counter() - t0
        self.changes_since_rdb = 0
        self.last_rdb_s = self.clock.now()
        self.stats["rdb_saves"] += 1
        return {"keys": len(self.data), "bytes": len(payload), "write_s": elapsed}

    def bgrewriteaof(self) -> dict[str, Any]:
        """Rewrite AOF to the shortest command list that rebuilds current data."""
        with self.lock:
            before = self.aof.size_cached()
            records_before = self.stats["aof_records"]
            t0 = time.perf_counter()
            # Child image is the current dataset; parent keeps appending to the
            # old file until the new one is ready, then we swap (teaching model
            # of a successful rewrite with no concurrent writes mid-swap).
            blob = bytearray()
            for key, value in self.data.items():
                blob.extend(encode_cmd("SET", key, value))
            self.aof.replace_durable(bytes(blob), fsync=True)
            self.stats["aof_records"] = len(self.data)
            self.stats["aof_rewrites"] += 1
            elapsed = time.perf_counter() - t0
            after = self.aof.size_durable()
            return {
                "keys": len(self.data),
                "records_before": records_before,
                "records_after": len(self.data),
                "bytes_before": before,
                "bytes_after": after,
                "rewrite_s": elapsed,
            }

    def copy_rdb_backup(self, dest_dir: str) -> str:
        """Copy the current durable RDB to an independent backup directory."""
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "dump.rdb")
        with self.lock:
            data = self.rdb.durable_bytes()
        with open(dest, "wb") as fh:
            fh.write(data)
        return dest

    def copy_aof_backup(self, dest_dir: str) -> str:
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "appendonly.aof")
        with self.lock:
            data = self.aof.durable_bytes()
        with open(dest, "wb") as fh:
            fh.write(data)
        return dest

    # ------------------------------------------------------------------ crash / recover
    def crash(self, kind: str = "power_loss", truncate_partial: bool = False) -> dict[str, Any]:
        """Destroy the process image.

        kind='power_loss': unflushed page cache is lost (machine/OS crash).
        kind='process_kill': page cache stays (kill -9 of the process only).
        """
        with self.lock:
            # A timer that was already due would have flushed on advance;
            # a crash does not get a last-second fsync.
            if kind == "power_loss":
                self.rdb.power_loss(truncate_partial_line=False)
                self.aof.power_loss(truncate_partial_line=truncate_partial)
            elif kind == "process_kill":
                self.rdb.process_kill()
                self.aof.process_kill()
            else:
                raise ValueError(kind)
            remembered = {
                "kind": kind,
                "acked_seq": self.acked_seq,
                "acked_t": self.write_log[-1][1] if self.write_log else 0.0,
                "dbsize": len(self.data),
                "write_log": list(self.write_log),
                "data": copy.deepcopy(self.data),
                "rdb_durable": self.rdb.durable_bytes(),
                "aof_durable": self.aof.durable_bytes(),
                "rdb_cached": self.rdb.cached_bytes(),
                "aof_cached": self.aof.cached_bytes(),
                "mode": self.mode,
                "aof_fsync": self.aof_fsync,
                "truncate_partial": truncate_partial,
            }
            # Process memory is gone.
            self.data.clear()
            self.pages.clear()
            self.write_log.clear()
            self.acked_seq = 0
            self.bgsave_in_progress = False
            self.bgsave_pages = None
            return remembered

    def recover(self, image: dict[str, Any], prefer: Optional[str] = None) -> dict[str, Any]:
        """Rebuild from durable files. prefer: None (Redis rule), 'rdb', or 'aof'."""
        t0 = time.perf_counter()
        rdb_blob = image["rdb_durable"]
        aof_blob = image["aof_durable"]
        has_rdb = bool(rdb_blob)
        has_aof = bool(aof_blob)
        truncated = False
        source = "empty"
        if prefer == "rdb":
            used = "rdb" if has_rdb else ("aof" if has_aof else "empty")
        elif prefer == "aof":
            used = "aof" if has_aof else ("rdb" if has_rdb else "empty")
        else:
            # Official rule: when both are enabled, AOF is used because it is
            # guaranteed to be the most complete.
            if has_aof and image["mode"] in {"aof", "both"}:
                used = "aof"
            elif has_rdb:
                used = "rdb"
            elif has_aof:
                used = "aof"
            else:
                used = "empty"
        data: dict[str, Any] = {}
        if used == "rdb":
            parsed = json.loads(rdb_blob.decode("utf-8"))
            data = dict(parsed["data"])
            source = "rdb"
        elif used == "aof":
            commands, truncated = decode_cmds(aof_blob)
            for cmd in commands:
                op = cmd[0]
                if op == "SET":
                    data[str(cmd[1])] = cmd[2]
                elif op == "INCR":
                    key, amount = str(cmd[1]), int(cmd[2])
                    data[key] = int(data.get(key, 0) or 0) + amount
                elif op == "DEL":
                    data.pop(str(cmd[1]), None)
                elif op == "FLUSHALL":
                    data.clear()
            source = "aof"
        elapsed = time.perf_counter() - t0
        with self.lock:
            self.data = data
            self.pages = {k: i + 1 for i, k in enumerate(data)}
            self.next_page_gen = len(data) + 1
            self.write_log = []
            self.changes_since_rdb = 0
            # Restored files remain as they were at crash.
            self.rdb.replace_durable(rdb_blob, fsync=False)
            self.aof.replace_durable(aof_blob, fsync=False)

        recovered_seq, recovered_t, lost_writes, rpo_s = self._rpo(image, data)
        return {
            "source": source,
            "has_rdb": has_rdb,
            "has_aof": has_aof,
            "truncated_aof": truncated,
            "dbsize": len(data),
            "data": copy.deepcopy(data),
            "rto_s": elapsed,
            "recovered_seq": recovered_seq,
            "recovered_t": recovered_t,
            "lost_writes": lost_writes,
            "rpo_s": rpo_s,
            "acked_seq": image["acked_seq"],
            "acked_t": image["acked_t"],
            "pre_crash_dbsize": image["dbsize"],
        }

    def _rpo(
        self, image: dict[str, Any], recovered: dict[str, Any]
    ) -> tuple[int, float, int, float]:
        """Compare recovered state with the acknowledged write log.

        RPO is the time between the last acknowledged write whose effect is
        in the recovered store and the last acknowledged write overall.
        """,
        state: dict[str, Any] = {}
        last_ok_seq = 0
        last_ok_t = 0.0
        log: list[tuple[int, float, str, tuple]] = image["write_log"]
        for seq, t, op, args in log:
            if op == "SET":
                state[str(args[0])] = args[1]
            elif op == "INCR":
                key, amount = str(args[0]), int(args[1])
                state[key] = int(state.get(key, 0) or 0) + amount
            elif op == "DEL":
                state.pop(str(args[0]), None)
            elif op == "FLUSHALL":
                state.clear()
            if state == recovered:
                last_ok_seq = seq
                last_ok_t = t
        lost = sum(1 for seq, _, _, _ in log if seq > last_ok_seq)
        acked_t = float(image["acked_t"])
        rpo_s = round(acked_t - last_ok_t, 6)
        return last_ok_seq, last_ok_t, lost, rpo_s



def recover_from_backup(
    engine: PersistenceEngine, backup_dir: str, kind: str = "rdb"
) -> dict[str, Any]:
    """Load an independent backup directory into a (usually empty) engine."""
    image = {
        "rdb_durable": b"",
        "aof_durable": b"",
        "mode": kind,
        "write_log": [],
        "acked_seq": 0,
        "acked_t": 0.0,
        "dbsize": 0,
    }
    rdb_path = os.path.join(backup_dir, "dump.rdb")
    aof_path = os.path.join(backup_dir, "appendonly.aof")
    if os.path.exists(rdb_path):
        image["rdb_durable"] = open(rdb_path, "rb").read()
        image["mode"] = "rdb"
    if os.path.exists(aof_path):
        image["aof_durable"] = open(aof_path, "rb").read()
        image["mode"] = "both" if image["rdb_durable"] else "aof"
    return engine.recover(image, prefer=kind if kind in {"rdb", "aof"} else None)
