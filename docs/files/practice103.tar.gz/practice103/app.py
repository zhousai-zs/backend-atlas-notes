#!/usr/bin/env python3
"""Teaching labs for g-persistence: compare durability strategies, then crash and recover."""
from __future__ import annotations

import os
import shutil
import tempfile
from typing import Any

from engine import Clock, PersistenceEngine, recover_from_backup

HERE = os.path.dirname(os.path.abspath(__file__))

# Article catalog used as the teaching workload (content-backend counters / drafts).
N_SEED = 2000
N_DELTA = 200
N_INCR = 2000
N_COW_KEYS = 2000
N_COW_WRITES = 400
N_LATENCY = 200
AOF_WRITE_STEP_S = 0.1
AOF_CRASH_S = 2.4
OS_FLUSH_S = 30.0


def _fresh(prefix: str, **kwargs: Any) -> tuple[str, PersistenceEngine]:
    data_dir = tempfile.mkdtemp(prefix=f"p103-{prefix}-", dir=HERE)
    clock = kwargs.pop("clock", None) or Clock()
    engine = PersistenceEngine(data_dir, clock=clock, **kwargs)
    return data_dir, engine


def _cleanup(paths: list[str]) -> None:
    for path in paths:
        shutil.rmtree(path, ignore_errors=True)


def _seed(engine: PersistenceEngine, n: int = N_SEED, prefix: str = "article") -> None:
    for i in range(1, n + 1):
        engine.set(f"{prefix}:{i}", f"draft:{i}")


def experiment_rdb_window() -> dict[str, Any]:
    """Snapshot, accept more writes, power-loss crash, recover from RDB."""
    dirs: list[str] = []
    try:
        data_dir, engine = _fresh("rdb", mode="rdb")
        dirs.append(data_dir)
        _seed(engine, N_SEED)
        saved = engine.save()
        # 5 seconds of later edits (titles / counters) are acknowledged but not snapshotted.
        for i in range(1, N_DELTA + 1):
            engine.set(f"article:{i}", f"published:{i}")
        engine.advance(5.0)
        # One more acknowledged write at t=5.0 so the lost window is exact.
        engine.set("article:flag", "late")
        image = engine.crash(kind="power_loss")
        recovered = engine.recover(image)
        # A tighter save point: snapshot again at t=5 just before the crash.
        data_dir2, engine2 = _fresh("rdb-tight", mode="rdb", clock=Clock())
        dirs.append(data_dir2)
        _seed(engine2, N_SEED)
        engine2.save()
        for i in range(1, N_DELTA + 1):
            engine2.set(f"article:{i}", f"published:{i}")
        engine2.advance(5.0)
        engine2.set("article:flag", "late")
        engine2.save()  # snapshot includes the late writes
        image2 = engine2.crash(kind="power_loss")
        recovered2 = engine2.recover(image2)
        return {
            "seed": N_SEED,
            "delta_writes": N_DELTA + 1,
            "gap_s": 5.0,
            "snapshot": saved,
            "loose": {
                "lost_writes": recovered["lost_writes"],
                "rpo_s": recovered["rpo_s"],
                "rto_s": recovered["rto_s"],
                "recovered_dbsize": recovered["dbsize"],
                "pre_crash_dbsize": recovered["pre_crash_dbsize"],
                "source": recovered["source"],
                "flag": recovered["data"].get("article:flag"),
                "article_1": recovered["data"].get("article:1"),
            },
            "tight": {
                "lost_writes": recovered2["lost_writes"],
                "rpo_s": recovered2["rpo_s"],
                "rto_s": recovered2["rto_s"],
                "recovered_dbsize": recovered2["dbsize"],
                "flag": recovered2["data"].get("article:flag"),
                "article_1": recovered2["data"].get("article:1"),
            },
        }
    finally:
        _cleanup(dirs)


def _aof_workload(engine: PersistenceEngine, crash_s: float = AOF_CRASH_S) -> int:
    """Write one new article every 0.1s until crash_s inclusive, then crash."""
    n = 0
    t = 0.0
    # First write at t=0.1, then 0.2, ... up to crash_s.
    while True:
        nxt = round(t + AOF_WRITE_STEP_S, 10)
        if nxt > crash_s + 1e-9:
            break
        engine.advance(AOF_WRITE_STEP_S)
        t = engine.clock.now()
        n += 1
        engine.set(f"seq:{n}", n)
        if abs(t - crash_s) < 1e-9:
            break
    return n


def experiment_fsync_policies() -> dict[str, Any]:
    """Compare always / everysec / no under the same write stream and a power-loss crash."""
    dirs: list[str] = []
    out: dict[str, Any] = {"write_step_s": AOF_WRITE_STEP_S, "crash_s": AOF_CRASH_S, "os_flush_s": OS_FLUSH_S}
    try:
        for policy in ("always", "everysec", "no"):
            data_dir, engine = _fresh(
                f"fsync-{policy}",
                mode="aof",
                aof_fsync=policy,
                os_flush_s=OS_FLUSH_S,
            )
            dirs.append(data_dir)
            n = _aof_workload(engine)
            image = engine.crash(kind="power_loss")
            recovered = engine.recover(image)
            # Same stream, process-only kill (page cache survives).
            data_dir_k, engine_k = _fresh(
                f"fsync-{policy}-kill",
                mode="aof",
                aof_fsync=policy,
                os_flush_s=OS_FLUSH_S,
            )
            dirs.append(data_dir_k)
            _aof_workload(engine_k)
            image_k = engine_k.crash(kind="process_kill")
            # For process_kill the page cache is still there; recover from cached bytes.
            image_k["aof_durable"] = image_k["aof_cached"]
            image_k["rdb_durable"] = image_k["rdb_cached"]
            recovered_k = engine_k.recover(image_k)
            out[policy] = {
                "writes": n,
                "power_loss": {
                    "lost_writes": recovered["lost_writes"],
                    "rpo_s": recovered["rpo_s"],
                    "rto_s": recovered["rto_s"],
                    "recovered_seq": recovered["recovered_seq"],
                    "recovered_dbsize": recovered["dbsize"],
                    "fsync_count": engine.aof.fsync_count,
                    "max_seq": max((int(v) for k, v in recovered["data"].items() if k.startswith("seq:")), default=0),
                },
                "process_kill": {
                    "lost_writes": recovered_k["lost_writes"],
                    "rpo_s": recovered_k["rpo_s"],
                    "recovered_dbsize": recovered_k["dbsize"],
                    "max_seq": max((int(v) for k, v in recovered_k["data"].items() if k.startswith("seq:")), default=0),
                },
            }
        return out
    finally:
        _cleanup(dirs)


def experiment_aof_rewrite() -> dict[str, Any]:
    dirs: list[str] = []
    try:
        data_dir, engine = _fresh("rewrite", mode="aof", aof_fsync="always")
        dirs.append(data_dir)
        engine.set("article:1:views", 0)
        for _ in range(N_INCR):
            engine.incr("article:1:views", 1)
        before = {
            "records": engine.stats["aof_records"],
            "bytes": engine.aof.size_durable(),
            "value": engine.get("article:1:views"),
        }
        rewritten = engine.bgrewriteaof()
        image = engine.crash(kind="power_loss")
        recovered = engine.recover(image)
        return {
            "increments": N_INCR,
            "before": before,
            "rewrite": rewritten,
            "recovered_value": recovered["data"].get("article:1:views"),
            "recovered_dbsize": recovered["dbsize"],
            "lost_writes": recovered["lost_writes"],
            "rpo_s": recovered["rpo_s"],
            "rto_s": recovered["rto_s"],
        }
    finally:
        _cleanup(dirs)


def experiment_fork_cow() -> dict[str, Any]:
    dirs: list[str] = []
    try:
        data_dir, idle = _fresh("cow-idle", mode="rdb")
        dirs.append(data_dir)
        _seed(idle, N_COW_KEYS)
        idle_stats = idle.bgsave(parent_writes=0)
        data_dir2, busy = _fresh("cow-busy", mode="rdb")
        dirs.append(data_dir2)
        _seed(busy, N_COW_KEYS)
        busy_stats = busy.bgsave(parent_writes=N_COW_WRITES)
        parent_now = busy.get("article:1")
        # After a busy snapshot, the RDB must still hold the pre-fork values.
        image = {
            "rdb_durable": busy.rdb.durable_bytes(),
            "aof_durable": b"",
            "mode": "rdb",
            "write_log": [],
            "acked_seq": 0,
            "acked_t": 0.0,
            "dbsize": 0,
        }
        recovered = busy.recover(image, prefer="rdb")
        sample = recovered["data"].get("article:1")
        return {
            "keys": N_COW_KEYS,
            "parent_writes": N_COW_WRITES,
            "idle": idle_stats,
            "busy": busy_stats,
            "rdb_article_1": sample,
            "parent_article_1": parent_now,
        }
    finally:
        _cleanup(dirs)


def experiment_rdb_plus_aof() -> dict[str, Any]:
    """Both enabled: restart prefers AOF; loading only the RDB loses more."""
    dirs: list[str] = []
    try:
        data_dir, engine = _fresh("both", mode="both", aof_fsync="everysec")
        dirs.append(data_dir)
        _seed(engine, 1000)
        engine.save()
        # Writes over 1.5s; last everysec fsync happens at t=1.0 when we advance past it.
        n = 0
        for i in range(1, 16):
            engine.advance(0.1)
            n += 1
            engine.set(f"late:{i}", i)
        # t=1.5, last timer fsync was at t=1.0 (advance 0.1 * 10).
        image = engine.crash(kind="power_loss")
        default = engine.recover(image)
        # Reload the same durable files as if someone forced RDB-only.
        data_dir2, engine2 = _fresh("both-rdbonly", mode="both", aof_fsync="everysec")
        dirs.append(data_dir2)
        rdb_only = engine2.recover(image, prefer="rdb")
        return {
            "seed": 1000,
            "late_writes": n,
            "crash_s": 1.5,
            "default": {
                "source": default["source"],
                "lost_writes": default["lost_writes"],
                "rpo_s": default["rpo_s"],
                "rto_s": default["rto_s"],
                "recovered_dbsize": default["dbsize"],
                "max_late": max((int(v) for k, v in default["data"].items() if k.startswith("late:")), default=0),
            },
            "rdb_only": {
                "source": rdb_only["source"],
                "lost_writes": rdb_only["lost_writes"],
                "rpo_s": rdb_only["rpo_s"],
                "rto_s": rdb_only["rto_s"],
                "recovered_dbsize": rdb_only["dbsize"],
                "max_late": max((int(v) for k, v in rdb_only["data"].items() if k.startswith("late:")), default=0),
            },
        }
    finally:
        _cleanup(dirs)


def experiment_replica_vs_backup() -> dict[str, Any]:
    dirs: list[str] = []
    try:
        data_dir, primary = _fresh("primary", mode="rdb")
        dirs.append(data_dir)
        _seed(primary, 100)
        primary.save()
        backup_dir = tempfile.mkdtemp(prefix="p103-backup-", dir=HERE)
        dirs.append(backup_dir)
        primary.copy_rdb_backup(backup_dir)

        replica_dir, replica = _fresh("replica", mode="none")
        dirs.append(replica_dir)
        primary.attach_replica(replica)
        replica_before = replica.dbsize()

        # An operator mistake (or a corrupted write) is replicated.
        primary.flushall()
        replica_after = replica.dbsize()
        primary_after = primary.dbsize()

        restore_dir, restored = _fresh("restore", mode="rdb")
        dirs.append(restore_dir)
        loaded = recover_from_backup(restored, backup_dir, kind="rdb")
        return {
            "seed": 100,
            "replica_before": replica_before,
            "replica_after_flushall": replica_after,
            "primary_after_flushall": primary_after,
            "backup_restored_dbsize": loaded["dbsize"],
            "backup_article_1": restored.get("article:1"),
            "replica_article_1": replica.get("article:1"),
        }
    finally:
        _cleanup(dirs)


def experiment_truncated_aof() -> dict[str, Any]:
    dirs: list[str] = []
    try:
        data_dir, engine = _fresh("trunc", mode="aof", aof_fsync="always")
        dirs.append(data_dir)
        for i in range(1, 11):
            engine.set(f"seq:{i}", i)
        image = engine.crash(kind="power_loss", truncate_partial=True)
        recovered = engine.recover(image)
        return {
            "writes": 10,
            "truncated_aof": recovered["truncated_aof"],
            "recovered_dbsize": recovered["dbsize"],
            "lost_writes": recovered["lost_writes"],
            "rpo_s": recovered["rpo_s"],
            "rto_s": recovered["rto_s"],
            "max_seq": max((int(v) for k, v in recovered["data"].items() if k.startswith("seq:")), default=0),
        }
    finally:
        _cleanup(dirs)


def experiment_write_latency() -> dict[str, Any]:
    """200 acknowledged SETs with real fsync, always vs everysec vs no."""
    dirs: list[str] = []
    out: dict[str, Any] = {"n": N_LATENCY}
    try:
        import time

        for policy in ("always", "everysec", "no"):
            clock = Clock(live=True)
            data_dir, engine = _fresh(
                f"lat-{policy}",
                mode="aof",
                aof_fsync=policy,
                os_flush_s=OS_FLUSH_S,
                clock=clock,
                real_fsync=True,
            )
            dirs.append(data_dir)
            t0 = time.perf_counter()
            for i in range(1, N_LATENCY + 1):
                engine.set(f"k:{i}", i)
            elapsed = time.perf_counter() - t0
            out[policy] = {
                "elapsed_s": round(elapsed, 6),
                "per_write_ms": round(elapsed / N_LATENCY * 1000, 4),
                "fsync_count": engine.aof.fsync_count,
                "fsync_s": round(engine.aof.fsync_s, 6),
            }
        return out
    finally:
        _cleanup(dirs)


def experiment_rto_compare() -> dict[str, Any]:
    """Load a compact RDB vs replay a long AOF vs a rewritten AOF of the same end state."""
    dirs: list[str] = []
    try:
        # Compact RDB of the same end state: 2000 articles plus 2000 view increments.
        d1, rdb = _fresh("rto-rdb", mode="rdb")
        dirs.append(d1)
        _seed(rdb, N_SEED)
        rdb.set("views:article:1", 0)
        for _ in range(N_INCR):
            rdb.incr("views:article:1", 1)
        rdb.save()
        img_rdb = rdb.crash(kind="power_loss")
        rec_rdb = rdb.recover(img_rdb)

        # Long AOF: one key incremented N_INCR times (plus a 2000-key seed of SETs).
        d2, aof = _fresh("rto-aof", mode="aof", aof_fsync="always")
        dirs.append(d2)
        _seed(aof, N_SEED)
        aof.set("views:article:1", 0)
        for _ in range(N_INCR):
            aof.incr("views:article:1", 1)
        img_aof = aof.crash(kind="power_loss")
        rec_aof = aof.recover(img_aof)

        # Same end state after rewrite.
        d3, rw = _fresh("rto-rw", mode="aof", aof_fsync="always")
        dirs.append(d3)
        _seed(rw, N_SEED)
        rw.set("views:article:1", 0)
        for _ in range(N_INCR):
            rw.incr("views:article:1", 1)
        rw.bgrewriteaof()
        img_rw = rw.crash(kind="power_loss")
        rec_rw = rw.recover(img_rw)

        return {
            "seed": N_SEED,
            "increments": N_INCR,
            "rdb": {
                "rto_s": rec_rdb["rto_s"],
                "dbsize": rec_rdb["dbsize"],
                "bytes": len(img_rdb["rdb_durable"]),
                "views": rec_rdb["data"].get("views:article:1"),
            },
            "long_aof": {
                "rto_s": rec_aof["rto_s"],
                "dbsize": rec_aof["dbsize"],
                "bytes": len(img_aof["aof_durable"]),
                "views": rec_aof["data"].get("views:article:1"),
            },
            "rewritten_aof": {
                "rto_s": rec_rw["rto_s"],
                "dbsize": rec_rw["dbsize"],
                "bytes": len(img_rw["aof_durable"]),
                "views": rec_rw["data"].get("views:article:1"),
            },
        }
    finally:
        _cleanup(dirs)


def run_all_experiments() -> dict[str, Any]:
    return {
        "rdb_window": experiment_rdb_window(),
        "fsync_policies": experiment_fsync_policies(),
        "aof_rewrite": experiment_aof_rewrite(),
        "fork_cow": experiment_fork_cow(),
        "rdb_plus_aof": experiment_rdb_plus_aof(),
        "replica_vs_backup": experiment_replica_vs_backup(),
        "truncated_aof": experiment_truncated_aof(),
        "write_latency": experiment_write_latency(),
        "rto_compare": experiment_rto_compare(),
    }


def main() -> None:
    import json

    data = run_all_experiments()
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
