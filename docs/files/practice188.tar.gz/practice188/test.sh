#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:$PWD/tools:${PATH:-}"
unset OPENAI_API_KEY || true
cmake --version | head -1
./tools/zig-c++ --version | head -3
clang-tidy --version | head -3
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["asan_caught_dangling"] and r["tsan_caught_data_race"]
assert r["asan_fixed_clean"] and r["tsan_fixed_clean"]
assert r["clang_tidy_ran"] and "22.1.8" in r["toolchain"]["clang_tidy_version"]
assert r["concurrency_not_skipped"] and r["cmake_build_succeeded"]
print("POSTCHECK_OK")
PY
