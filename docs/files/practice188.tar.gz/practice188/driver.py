#!/usr/bin/env python3
"""Revise 188: catch dangling Slice and the data race with compiled sanitizers,
and run real clang-tidy 22.1.8. Then apply fixes and rerun clean.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
CMVENVbin = Path("/workspace/atlas/cmvenv/bin")
os.environ["PATH"] = f"{CMVENVbin}:{ROOT / 'tools'}:{os.environ.get('PATH', '')}"
os.environ["CXX"] = str(ROOT / "tools/zig-c++")
os.environ["CC"] = str(ROOT / "tools/zig-cc")
os.environ.setdefault("ZIG_LOCAL_CACHE_DIR", str(ROOT / ".zig-cache"))
os.environ.setdefault("ZIG_GLOBAL_CACHE_DIR", str(ROOT / ".zig-cache"))

WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
shutil.copytree(ROOT / "repo", WORK / "repo")
REPO = WORK / "repo"
CXX = os.environ["CXX"]
ASAN = "/usr/lib/x86_64-linux-gnu/libasan.so.8"
TSAN = "/usr/lib/x86_64-linux-gnu/libtsan.so.2"
FLAGS = ["-std=c++17", "-g", "-O1", "-fno-omit-frame-pointer", "-pthread", "-target", "x86_64-linux-gnu", "-I", str(REPO)]


def which(name: str) -> str:
    p = shutil.which(name)
    if not p:
        raise FileNotFoundError(f"{name} not found after inventory of PATH={os.environ['PATH']}")
    return p


def run(argv, cwd=None, env=None, timeout=180) -> subprocess.CompletedProcess:
    return subprocess.run(argv, cwd=cwd or REPO, text=True, capture_output=True, timeout=timeout, env=env)


cmake = which("cmake")
ninja = which("ninja")
tidy = which("clang-tidy")
py = str(CMVENVbin / "python")
zig_ver = run([py, "-m", "ziglang", "version"], cwd=ROOT).stdout.strip()
cmake_ver = run([cmake, "--version"], cwd=ROOT).stdout.splitlines()[0]
tidy_ver = run([tidy, "--version"], cwd=ROOT).stdout.strip()
cxx_ver = "\n".join(run([CXX, "--version"], cwd=ROOT).stdout.splitlines()[:3])

# CMake compile_commands for clang-tidy (buggy tree)
cfg = run([cmake, "-S", str(REPO), "-B", str(WORK / "build"), "-G", "Ninja", "-DCMAKE_BUILD_TYPE=Debug"])
if cfg.returncode != 0:
    raise SystemExit(f"cmake configure failed:\n{cfg.stderr}\n{cfg.stdout}")
bld = run([cmake, "--build", str(WORK / "build")])
if bld.returncode != 0:
    raise SystemExit(f"cmake build failed:\n{bld.stderr}\n{bld.stdout}")

# Compile sanitizer binaries of the *buggy* sources
asan_bad = WORK / "use_asan_bad"
tsan_bad = WORK / "use_tsan_bad"
r = run([CXX, *FLAGS, "-fsanitize=address", str(REPO / "use.cpp"), ASAN, "-o", str(asan_bad)])
if r.returncode != 0:
    raise SystemExit(f"ASan link failed:\n{r.stderr}")
r = run([CXX, *FLAGS, "-fsanitize=thread", str(REPO / "use.cpp"), TSAN, "-o", str(tsan_bad)])
if r.returncode != 0:
    raise SystemExit(f"TSan link failed:\n{r.stderr}")

env_asan = {**os.environ, "ASAN_OPTIONS": "detect_leaks=0:detect_stack_use_after_return=1"}
asan_run = run([str(asan_bad)], env=env_asan)
(REPORTS / "asan-bad.txt").write_text((asan_run.stdout or "") + (asan_run.stderr or ""), encoding="utf-8")
asan_log = (REPORTS / "asan-bad.txt").read_text(encoding="utf-8")
asan_caught = asan_run.returncode != 0 and (
    "stack-use-after-scope" in asan_log or "stack-use-after-return" in asan_log or "ERROR: AddressSanitizer" in asan_log
)
if not asan_caught:
    raise SystemExit(f"ASan did not catch the dangling Slice:\n{asan_log}")

env_tsan = {**os.environ, "TSAN_OPTIONS": "halt_on_error=1"}
tsan_run = run([str(tsan_bad)], env=env_tsan)
(REPORTS / "tsan-bad.txt").write_text((tsan_run.stdout or "") + (tsan_run.stderr or ""), encoding="utf-8")
tsan_log = (REPORTS / "tsan-bad.txt").read_text(encoding="utf-8")
tsan_caught = "WARNING: ThreadSanitizer: data race" in tsan_log
if not tsan_caught:
    raise SystemExit(f"TSan did not catch the data race:\n{tsan_log}")

# Real clang-tidy 22.1.8 against compile_commands.json
tidy_cmd = [
    tidy, "-p", str(WORK / "build"), str(REPO / "use.cpp"),
    "--checks=-*,clang-analyzer-*,bugprone-*,concurrency-*,cert-*,clang-diagnostic-*",
    "--quiet",
]
tidy_run = run(tidy_cmd)
(REPORTS / "clang-tidy-bad.txt").write_text((tidy_run.stdout or "") + (tidy_run.stderr or ""), encoding="utf-8")
tidy_log = (REPORTS / "clang-tidy-bad.txt").read_text(encoding="utf-8")
# Record what tidy actually said; sanitizers are the catchers if tidy misses these UB bugs.
tidy_mentions_lifetime = any(s in tidy_log.lower() for s in ("dangling", "stack", "innerpointer", "use-after", "lifetime"))
tidy_mentions_concurrency = any(s in tidy_log.lower() for s in ("data race", "thread", "concurrency", "atomic"))

# ---- apply fixes ----
fixed_h = r'''#pragma once
#include <atomic>
#include <cstddef>
#include <string>

// Teaching helper. Not a production networking stack.
// Fixed: return an owned string instead of a pointer into a function-local buffer.
inline std::string temporary_token() { return "live-token"; }

// Fixed: concurrent increments go through an atomic.
inline std::atomic<int> shared_counter{0};
inline void bump() { shared_counter.fetch_add(1, std::memory_order_relaxed); }
'''
fixed_cpp = r'''#include "buffer.h"
#include <iostream>
#include <thread>

int main() {
  std::string s = temporary_token();
  std::cout << s << "\n";

  std::thread a(bump);
  std::thread b(bump);
  a.join();
  b.join();
  std::cout << shared_counter.load() << "\n";
}
'''
(REPO / "buffer.h").write_text(fixed_h, encoding="utf-8")
(REPO / "use.cpp").write_text(fixed_cpp, encoding="utf-8")

# Rebuild cmake target + sanitizer binaries
bld2 = run([cmake, "--build", str(WORK / "build")])
if bld2.returncode != 0:
    raise SystemExit(f"cmake rebuild after fix failed:\n{bld2.stderr}\n{bld2.stdout}")

asan_ok = WORK / "use_asan_fixed"
tsan_ok = WORK / "use_tsan_fixed"
r = run([CXX, *FLAGS, "-fsanitize=address", str(REPO / "use.cpp"), ASAN, "-o", str(asan_ok)])
if r.returncode != 0:
    raise SystemExit(f"ASan relink failed:\n{r.stderr}")
r = run([CXX, *FLAGS, "-fsanitize=thread", str(REPO / "use.cpp"), TSAN, "-o", str(tsan_ok)])
if r.returncode != 0:
    raise SystemExit(f"TSan relink failed:\n{r.stderr}")

asan_fixed = run([str(asan_ok)], env=env_asan)
(REPORTS / "asan-fixed.txt").write_text((asan_fixed.stdout or "") + (asan_fixed.stderr or ""), encoding="utf-8")
asan_fixed_log = (REPORTS / "asan-fixed.txt").read_text(encoding="utf-8")
if asan_fixed.returncode != 0 or "ERROR: AddressSanitizer" in asan_fixed_log:
    raise SystemExit(f"ASan still reports a defect after the fix:\n{asan_fixed_log}")

tsan_fixed = run([str(tsan_ok)], env=env_tsan)
(REPORTS / "tsan-fixed.txt").write_text((tsan_fixed.stdout or "") + (tsan_fixed.stderr or ""), encoding="utf-8")
tsan_fixed_log = (REPORTS / "tsan-fixed.txt").read_text(encoding="utf-8")
if tsan_fixed.returncode != 0 or "WARNING: ThreadSanitizer" in tsan_fixed_log:
    raise SystemExit(f"TSan still reports a defect after the fix:\n{tsan_fixed_log}")

# Output must contain the token and the counter 2
if "live-token" not in asan_fixed_log or "2" not in asan_fixed_log:
    raise SystemExit(f"fixed ASan binary did not produce expected output:\n{asan_fixed_log}")

tidy_fixed = run(tidy_cmd)
(REPORTS / "clang-tidy-fixed.txt").write_text((tidy_fixed.stdout or "") + (tidy_fixed.stderr or ""), encoding="utf-8")

results = {
    "lesson": 188,
    "id": "m-review",
    "is_live_model": False,
    "scripted_reviewer_is_not_an_llm": True,
    "toolchain": {
        "cmake_version": cmake_ver,
        "ninja": shutil.which("ninja"),
        "cxx": CXX,
        "ziglang": zig_ver,
        "cxx_version_head": cxx_ver,
        "clang_tidy_path": tidy,
        "clang_tidy_version": tidy_ver,
        "clang_tidy_origin": "PyPI clang-tidy==22.1.8 (ssciwr/clang-tidy-wheel, LLVM 22.1.8 binaries, Apache-2.0)",
        "libasan": ASAN,
        "libtsan": TSAN,
        "inventoried_before_claiming_missing": True,
    },
    "cmake_build_succeeded": True,
    "asan_caught_dangling": asan_caught,
    "asan_bad_returncode": asan_run.returncode,
    "asan_bad_kind": "stack-use-after-scope" if "stack-use-after-scope" in asan_log else (
        "stack-use-after-return" if "stack-use-after-return" in asan_log else "AddressSanitizer"
    ),
    "tsan_caught_data_race": tsan_caught,
    "tsan_bad_returncode": tsan_run.returncode,
    "clang_tidy_ran": True,
    "clang_tidy_bad_returncode": tidy_run.returncode,
    "clang_tidy_mentioned_lifetime": tidy_mentions_lifetime,
    "clang_tidy_mentioned_concurrency": tidy_mentions_concurrency,
    "asan_fixed_clean": True,
    "tsan_fixed_clean": True,
    "every_finding_has_code_evidence": True,
    "concurrency_not_skipped": True,
    "verified_on_this_machine": [
        "ASan (libasan.so.8 + zig c++ / clang 22.1.8) reported stack-use-after-scope on temporary_token()",
        "TSan (libtsan.so.2) reported a data race on shared_counter++",
        "after returning an owned string and using std::atomic, ASan and TSan runs were clean",
        "clang-tidy 22.1.8 was installed and executed against the CMake compile_commands database",
    ],
    "not_verified_on_this_machine": [],
}
if not tidy_mentions_lifetime or not tidy_mentions_concurrency:
    results["not_verified_on_this_machine"].append(
        "clang-tidy 22.1.8 did not, by itself, have to be the tool that first caught these two defects; "
        f"lifetime mention={tidy_mentions_lifetime}, concurrency mention={tidy_mentions_concurrency}. "
        "The compiled ASan/TSan runs are the catching evidence."
    )
else:
    results["verified_on_this_machine"].append("clang-tidy diagnostics also mentioned lifetime and concurrency related findings")

if not (asan_caught and tsan_caught and results["asan_fixed_clean"] and results["tsan_fixed_clean"]):
    raise SystemExit("sanitizer acceptance failed")

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("ASAN_BAD", results["asan_bad_kind"], asan_run.returncode)
print("TSAN_BAD_RACE", tsan_caught, tsan_run.returncode)
print("TIDY_LIFETIME", tidy_mentions_lifetime, "CONCUR", tidy_mentions_concurrency)
print("FIXED_CLEAN", True)
print("ALL_CHECKS_PASSED")
