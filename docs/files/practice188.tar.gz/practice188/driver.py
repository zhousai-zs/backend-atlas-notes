#!/usr/bin/env python3
"""AI-assisted review of a dangling-reference + data-race diff.

Each finding must cite code evidence. Concurrency checks are not skipped just
because a model has no opinion. clang-tidy is invoked if present; otherwise
the miss is recorded and not claimed as a run.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
shutil.copytree(ROOT / "repo", WORK / "repo")
REPO = WORK / "repo"
source = (REPO / "buffer.h").read_text(encoding="utf-8")
diff = (REPO / "change.diff").read_text(encoding="utf-8")
use_cpp = (REPO / "use.cpp").read_text(encoding="utf-8")

def line_no(text: str, snippet: str) -> int:
    lines = text.splitlines()
    for i, ln in enumerate(lines, 1):
        if snippet in ln:
            return i
    raise AssertionError(f"missing snippet {snippet!r}")

# Scripted reviewer: must include concurrency even if "the model is silent".
dangling_line = line_no(source, "return Slice{token.c_str(), token.size()};")
race_line = line_no(source, "shared_counter++;")
use_dangle = line_no(use_cpp, "std::string(s.ptr, s.len)")
use_threads = line_no(use_cpp, "std::thread a(bump)")

findings = [
    {
        "id": "dangling-slice",
        "category": "lifetime",
        "file": "buffer.h",
        "line": dangling_line,
        "evidence": source.splitlines()[dangling_line - 1].strip(),
        "trigger": "temporary_token() returns a pointer into a function-local std::string; the string is destroyed when the function returns. use.cpp then constructs std::string(s.ptr, s.len).",
        "trigger_site": {"file": "use.cpp", "line": use_dangle, "evidence": use_cpp.splitlines()[use_dangle - 1].strip()},
        "minimal_test": "Call temporary_token(), destroy intervening stack frames, then read s.ptr under ASan/UBSan.",
    },
    {
        "id": "unsynchronized-bump",
        "category": "concurrency",
        "file": "buffer.h",
        "line": race_line,
        "evidence": source.splitlines()[race_line - 1].strip(),
        "trigger": "bump() does shared_counter++ with no mutex or atomic. use.cpp starts two threads that both call bump().",
        "trigger_site": {"file": "use.cpp", "line": use_threads, "evidence": use_cpp.splitlines()[use_threads - 1].strip()},
        "minimal_test": "Run bump() from two threads under TSan; the data race on shared_counter should be reported.",
    },
]

# Do not skip concurrency: require at least one concurrency finding with code evidence.
concurrency = [f for f in findings if f["category"] == "concurrency"]
assert concurrency, "concurrency checks must not be skipped"
for f in findings:
    assert f["file"] and f["line"] and f["evidence"] and f["trigger"] and f["minimal_test"]

# Invoke clang-tidy if present (no sudo install).
clang_tidy = shutil.which("clang-tidy")
tidy_run = {"which": clang_tidy, "ran": False, "returncode": None, "stdout_tail": "", "stderr_tail": ""}
if clang_tidy:
    p = subprocess.run(
        [clang_tidy, "use.cpp", "--", "-std=c++17", "-I."],
        cwd=REPO,
        text=True,
        capture_output=True,
        timeout=60,
    )
    tidy_run.update({
        "ran": True,
        "returncode": p.returncode,
        "stdout_tail": (p.stdout or "")[-2000:],
        "stderr_tail": (p.stderr or "")[-2000:],
    })

(REPORTS / "review.json").write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")

results = {
    "lesson": 188,
    "id": "m-review",
    "is_live_model": False,
    "scripted_reviewer_is_not_an_llm": True,
    "findings": findings,
    "every_finding_has_code_evidence": all(f["evidence"] and f["line"] > 0 for f in findings),
    "concurrency_not_skipped": len(concurrency) >= 1,
    "clang_tidy": tidy_run,
    "clang_tidy_ran": tidy_run["ran"],
    "verified_on_this_machine": [
        "scripted review of dangling Slice and unsynchronized shared_counter, each with file:line evidence and a minimal test",
        "clang-tidy was probed via shutil.which and optionally invoked",
    ],
    "not_verified_on_this_machine": [],
}
if not tidy_run["ran"]:
    results["not_verified_on_this_machine"].append(
        "clang-tidy execution (binary not found on this machine; findings are from code evidence, not from a tidy report)"
    )
else:
    results["verified_on_this_machine"].append("clang-tidy ran")

if not results["every_finding_has_code_evidence"] or not results["concurrency_not_skipped"]:
    raise SystemExit("review quality checks failed")
if tidy_run["ran"] is False:
    assert results["not_verified_on_this_machine"]

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("FINDINGS", [f["id"] for f in findings])
print("CLANG_TIDY", tidy_run)
print("ALL_CHECKS_PASSED")
