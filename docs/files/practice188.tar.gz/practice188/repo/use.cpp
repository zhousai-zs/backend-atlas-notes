#include "buffer.h"
#include <iostream>
#include <thread>

int main() {
  Slice s = temporary_token();
  // Use after the local string's lifetime ended (dangling pointer).
  std::cout << std::string(s.ptr, s.len) << "\n";

  std::thread a(bump);
  std::thread b(bump);
  a.join();
  b.join();
  std::cout << shared_counter << "\n";
}
