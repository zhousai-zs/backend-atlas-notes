#pragma once
#include <cstddef>
#include <string>

// Teaching helper. Not a production networking stack.
struct Slice {
  const char* ptr;
  std::size_t len;
};

inline Slice temporary_token() {
  std::string token = "live-token";
  // BUG: returns a pointer into a function-local string that is destroyed.
  return Slice{token.c_str(), token.size()};
}

inline int shared_counter = 0;

inline void bump() {
  // BUG: unsynchronized write; a data race if called from two threads.
  shared_counter++;
}
