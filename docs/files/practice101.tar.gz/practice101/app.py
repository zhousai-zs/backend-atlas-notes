#!/usr/bin/env python3
"""Teaching lab for g-redis: leaderboard, expiring counters, scan vs KEYS, command cost."""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from engine import Clock, RedisEngine

# Wall-clock blocking uses a 50µs cost per examined item so that
# a 4000-key KEYS holds the command mutex for about 0.20 seconds.
BLOCK_UNIT_S = 0.00005
KEYSPACE = 4000
BIG_FIELDS = 2000
BIG_MEMBERS = 2000
CONCURRENT_INCREMENTS = 200
WINDOW_S = 60.0


def _new(unit_s: float = 0.0, clock: Clock | None = None) -> RedisEngine:
    return RedisEngine(clock=clock, unit_s=unit_s)


def experiment_types_and_leaderboard() -> dict:
    """String counter, hash metadata, sorted-set leaderboard in one account scene."""
    r = _new()
    r.hset("article:42", "title", "Weekly digest")
    r.hset("article:42", "status", "published")
    r.hset("article:42", "author", "editor-a")
    r.incr("views:42")
    r.incr("views:42")
    r.zadd("rank:daily", "42", 2)
    r.hset("article:7", "title", "Draft notes")
    r.hset("article:7", "status", "draft")
    r.zadd("rank:daily", "7", 0)

    # 18 more published articles with increasing views; 42 stays on top after a burst.
    for i in range(1, 21):
        if i in (7, 42):
            continue
        r.hset(f"article:{i}", "title", f"Post {i}")
        r.hset(f"article:{i}", "status", "published")
        views = i * 3
        for _ in range(views):
            r.incr(f"views:{i}")
        r.zadd("rank:daily", str(i), views)

    # A late burst of 80 reads on article 42, applied atomically with ZINCRBY.
    for _ in range(80):
        r.incr("views:42")
        r.zincrby("rank:daily", 1, "42")

    top10 = r.zrevrange("rank:daily", 0, 9, withscores=True)
    full = r.zrange("rank:daily", 0, -1, withscores=True)
    top10_exam = r.command_log[-2]["examined"]
    full_exam = r.command_log[-1]["examined"]
    score_42 = r.zscore("rank:daily", "42")
    rank_42 = r.zrank("rank:daily", "42", reverse=True)
    meta = {
        "title": r.hget("article:42", "title"),
        "status": r.hget("article:42", "status"),
        "views": int(r.get("views:42")),
    }
    return {
        "types": {
            "article:42": r.type("article:42"),
            "views:42": r.type("views:42"),
            "rank:daily": r.type("rank:daily"),
        },
        "meta": meta,
        "members": r.zcard("rank:daily"),
        "top10": [(m, int(s)) for m, s in top10],
        "top10_examined": top10_exam,
        "full_dump_count": len(full),
        "full_dump_examined": full_exam,
        "article_42_score": int(score_42),
        "article_42_revrank": rank_42,
        "views_42": int(r.get("views:42")),
    }


def experiment_atomic_vs_multistep() -> dict:
    """INCR is one atomic command; GET then SET is not, even if each command is atomic."""
    expected = CONCURRENT_INCREMENTS

    naive = _new()
    naive.set("views:naive", "0")
    lock_gap = threading.Barrier(CONCURRENT_INCREMENTS)

    def naive_one(_i: int) -> None:
        # Each client reads, increments locally, writes back. The two
        # commands are individually atomic; the pair is not.
        lock_gap.wait()
        raw = naive.get("views:naive")
        time.sleep(0.002)
        n = int(raw or "0") + 1
        naive.set("views:naive", str(n))

    with ThreadPoolExecutor(max_workers=CONCURRENT_INCREMENTS) as pool:
        list(pool.map(naive_one, range(CONCURRENT_INCREMENTS)))
    naive_final = int(naive.get("views:naive"))

    safe = _new()
    safe.set("views:safe", "0")
    barrier = threading.Barrier(CONCURRENT_INCREMENTS)

    def safe_one(_i: int) -> None:
        barrier.wait()
        safe.incr("views:safe")

    with ThreadPoolExecutor(max_workers=CONCURRENT_INCREMENTS) as pool:
        list(pool.map(safe_one, range(CONCURRENT_INCREMENTS)))
    safe_final = int(safe.get("views:safe"))

    # Same idea on the leaderboard: GET score + ZADD vs ZINCRBY.
    naive_z = _new()
    naive_z.zadd("rank:daily", "42", 0)
    z_barrier = threading.Barrier(CONCURRENT_INCREMENTS)

    def naive_z_one(_i: int) -> None:
        z_barrier.wait()
        score = naive_z.zscore("rank:daily", "42") or 0.0
        time.sleep(0.002)
        naive_z.zadd("rank:daily", "42", score + 1)

    with ThreadPoolExecutor(max_workers=CONCURRENT_INCREMENTS) as pool:
        list(pool.map(naive_z_one, range(CONCURRENT_INCREMENTS)))
    naive_z_final = int(naive_z.zscore("rank:daily", "42") or 0)

    safe_z = _new()
    safe_z.zadd("rank:daily", "42", 0)
    zs_barrier = threading.Barrier(CONCURRENT_INCREMENTS)

    def safe_z_one(_i: int) -> None:
        zs_barrier.wait()
        safe_z.zincrby("rank:daily", 1, "42")

    with ThreadPoolExecutor(max_workers=CONCURRENT_INCREMENTS) as pool:
        list(pool.map(safe_z_one, range(CONCURRENT_INCREMENTS)))
    safe_z_final = int(safe_z.zscore("rank:daily", "42") or 0)

    return {
        "concurrent": expected,
        "naive_get_set": naive_final,
        "safe_incr": safe_final,
        "naive_zscore_zadd": naive_z_final,
        "safe_zincrby": safe_z_final,
        "expected": expected,
    }


def experiment_expire_counter() -> dict:
    """A window counter must set TTL in the same command that creates the key."""
    clock = Clock()
    naive = _new(clock=clock)

    def naive_hit(*, set_expire: bool = True) -> int:
        # The common pattern: only the creator sets TTL. If that EXPIRE
        # never runs, later hits see n > 1 and also skip EXPIRE.
        n = naive.incr("win:naive")
        if n == 1 and set_expire:
            naive.expire("win:naive", WINDOW_S)
        return n

    first = naive_hit(set_expire=False)  # crash between INCR and EXPIRE
    ttl_after_crash = naive.ttl("win:naive")
    for _ in range(9):
        naive_hit()
    clock.advance(WINDOW_S + 1)
    after_window = naive.get("win:naive")
    ttl_after_window = naive.ttl("win:naive")

    clock2 = Clock()
    safe = _new(clock=clock2)

    def safe_hit() -> int:
        # One command creates the key and sets TTL; later hits only INCR.
        created = safe.set("win:safe", "1", ex=WINDOW_S, nx=True)
        if created:
            return 1
        return safe.incr("win:safe")

    safe_first = safe_hit()
    ttl_on_create = safe.ttl("win:safe")
    for _ in range(9):
        safe_hit()
    count_before = int(safe.get("win:safe"))
    clock2.advance(WINDOW_S + 1)
    after_safe = safe.get("win:safe")
    ttl_safe_after = safe.ttl("win:safe")
    # A new window can start cleanly.
    again = safe_hit()
    ttl_new_window = safe.ttl("win:safe")

    return {
        "window_s": WINDOW_S,
        "naive": {
            "first": first,
            "ttl_after_crashed_first_hit": ttl_after_crash,
            "count_after_10_hits": 10,
            "value_after_window": after_window,
            "ttl_after_window": ttl_after_window,
        },
        "safe": {
            "first": safe_first,
            "ttl_on_create": ttl_on_create,
            "count_before_window_end": count_before,
            "value_after_window": after_safe,
            "ttl_after_window": ttl_safe_after,
            "new_window_first": again,
            "ttl_new_window": ttl_new_window,
        },
    }


def _seed_keyspace(r: RedisEngine, n: int = KEYSPACE) -> None:
    # Mix of article hashes, view counters, and a daily rank key.
    r.zadd("rank:daily", "0", 0)
    for i in range(n):
        if i % 2 == 0:
            r.set(f"views:{i}", "0")
        else:
            r.hset(f"article:{i}", "title", f"Post {i}")
    # Other keys that a naive article:* pattern should still have to walk.
    for i in range(50):
        r.set(f"session:{i}", "tok")


def experiment_keys_vs_scan() -> dict:
    r = _new()
    _seed_keyspace(r, KEYSPACE)
    dbsize = r.dbsize()

    r.command_log.clear()
    keys_hits = r.keys("article:*")
    keys_exam = r.command_log[-1]["examined"]
    keys_held = r.command_log[-1]["held_s"]

    r.command_log.clear()
    scanned, calls, scan_exam = r.scan_all(match="article:*", count=20)
    # One SCAN call cost, for comparison with a single KEYS.
    one_cursor, one_batch = r.scan(0, match="article:*", count=20)
    one_exam = r.command_log[-1]["examined"]

    return {
        "dbsize": dbsize,
        "keys": {
            "matches": len(keys_hits),
            "examined": keys_exam,
            "held_s": keys_held,
        },
        "scan_all": {
            "matches": len(scanned),
            "calls": calls,
            "examined": scan_exam,
            "count": 20,
        },
        "scan_one_call": {
            "cursor": one_cursor,
            "batch": len(one_batch),
            "examined": one_exam,
        },
        "same_matches": sorted(keys_hits) == sorted(scanned),
    }


def experiment_big_key_cost() -> dict:
    r = _new()
    for i in range(BIG_FIELDS):
        r.hset("article:hot:stats", f"day:{i}", str(i))
    for i in range(BIG_MEMBERS):
        r.zadd("rank:alltime", f"article:{i}", float(i))

    r.command_log.clear()
    one = r.hget("article:hot:stats", "day:7")
    hget_exam = r.command_log[-1]["examined"]
    some = r.hmget("article:hot:stats", "day:7", "day:8", "day:9")
    hmget_exam = r.command_log[-1]["examined"]
    all_fields = r.hgetall("article:hot:stats")
    hgetall_exam = r.command_log[-1]["examined"]

    top10 = r.zrevrange("rank:alltime", 0, 9)
    top_exam = r.command_log[-1]["examined"]
    full = r.zrange("rank:alltime", 0, -1)
    full_exam = r.command_log[-1]["examined"]

    return {
        "hash_fields": BIG_FIELDS,
        "zset_members": BIG_MEMBERS,
        "hget": {"value": one, "examined": hget_exam},
        "hmget": {"values": some, "examined": hmget_exam},
        "hgetall": {"fields": len(all_fields), "examined": hgetall_exam},
        "zrevrange_top10": {"count": len(top10), "examined": top_exam, "first": top10[0]},
        "zrange_full": {"count": len(full), "examined": full_exam},
    }


def _wait_for_incr_behind(setup_fn, heavy_fn, unit_s: float = BLOCK_UNIT_S) -> dict:
    # Seed with no per-item delay, then turn on unit_s only for the race.
    r = _new(unit_s=0.0)
    setup_fn(r)
    r.set("views:probe", "0")
    r.command_log.clear()
    r.unit_s = unit_s
    started = threading.Event()
    heavy_held = {}

    def heavy() -> None:
        started.set()
        heavy_fn(r)
        if r.command_log:
            heavy_held["held_s"] = r.command_log[-1]["held_s"]
            heavy_held["examined"] = r.command_log[-1]["examined"]
            heavy_held["cmd"] = r.command_log[-1]["cmd"]

    def probe() -> dict:
        started.wait()
        # Give the heavy command a moment to acquire the mutex.
        time.sleep(0.01)
        t0 = time.perf_counter()
        r.incr("views:probe")
        waited = time.perf_counter() - t0
        rec = r.command_log[-1]
        return {
            "wait_s": round(waited, 4),
            "lock_wait_s": rec["lock_wait_s"],
            "examined": rec["examined"],
            "value": int(r.get("views:probe")),
        }

    with ThreadPoolExecutor(max_workers=2) as pool:
        h = pool.submit(heavy)
        p = pool.submit(probe)
        probe_res = p.result()
        h.result()
    probe_res["heavy"] = heavy_held
    return probe_res


def experiment_blocking() -> dict:
    """A heavy command holds the single-threaded mutex; a cheap INCR has to wait."""

    def seed_keys(r: RedisEngine) -> None:
        _seed_keyspace(r, KEYSPACE)

    def seed_hash(r: RedisEngine) -> None:
        for i in range(BIG_FIELDS):
            r.hset("article:hot:stats", f"day:{i}", str(i))

    def seed_zset(r: RedisEngine) -> None:
        for i in range(BIG_MEMBERS):
            r.zadd("rank:alltime", f"article:{i}", float(i))

    def run_keys(r: RedisEngine) -> None:
        r.keys("*")

    def run_scan_one(r: RedisEngine) -> None:
        r.scan(0, match="*", count=20)

    def run_hgetall(r: RedisEngine) -> None:
        r.hgetall("article:hot:stats")

    def run_hget(r: RedisEngine) -> None:
        r.hget("article:hot:stats", "day:7")

    def run_zfull(r: RedisEngine) -> None:
        r.zrange("rank:alltime", 0, -1)

    def run_ztop(r: RedisEngine) -> None:
        r.zrevrange("rank:alltime", 0, 9)

    keys = _wait_for_incr_behind(seed_keys, run_keys)
    scan = _wait_for_incr_behind(seed_keys, run_scan_one)
    hgetall = _wait_for_incr_behind(seed_hash, run_hgetall)
    hget = _wait_for_incr_behind(seed_hash, run_hget)
    zfull = _wait_for_incr_behind(seed_zset, run_zfull)
    ztop = _wait_for_incr_behind(seed_zset, run_ztop)
    return {
        "unit_s": BLOCK_UNIT_S,
        "keyspace": KEYSPACE,
        "big_fields": BIG_FIELDS,
        "big_members": BIG_MEMBERS,
        "behind_keys": keys,
        "behind_scan_one": scan,
        "behind_hgetall": hgetall,
        "behind_hget": hget,
        "behind_zrange_full": zfull,
        "behind_zrevrange_top10": ztop,
    }


def experiment_hot_key() -> dict:
    """One popular key plus a large value: many HGETALL calls serialize and stay expensive."""
    r = _new()
    for i in range(BIG_FIELDS):
        r.hset("article:hot:stats", f"day:{i}", str(i))
    r.hset("article:cold:stats", "day:0", "0")
    r.command_log.clear()
    r.hits.clear()

    # 80 clients read the hot hash in full; 20 read a single field on a cold hash.
    def work(i: int) -> None:
        if i < 80:
            r.hgetall("article:hot:stats")
        else:
            r.hget("article:cold:stats", "day:0")

    with ThreadPoolExecutor(max_workers=20) as pool:
        list(pool.map(work, range(100)))

    hot_hits = r.hits.get("article:hot:stats", 0)
    cold_hits = r.hits.get("article:cold:stats", 0)
    hot_exam = sum(
        rec["examined"]
        for rec in r.command_log
        if rec["key"] == "article:hot:stats" and rec["cmd"] == "HGETALL"
    )
    cold_exam = sum(
        rec["examined"]
        for rec in r.command_log
        if rec["key"] == "article:cold:stats" and rec["cmd"] == "HGET"
    )
    return {
        "requests": 100,
        "hot_hits": hot_hits,
        "cold_hits": cold_hits,
        "hot_examined_total": hot_exam,
        "cold_examined_total": cold_exam,
        "hot_share": round(hot_hits / (hot_hits + cold_hits), 4),
    }


def run_all_experiments() -> dict:
    return {
        "model": "teaching RedisEngine (not Redis)",
        "block_unit_s": BLOCK_UNIT_S,
        "types_and_leaderboard": experiment_types_and_leaderboard(),
        "atomic_vs_multistep": experiment_atomic_vs_multistep(),
        "expire_counter": experiment_expire_counter(),
        "keys_vs_scan": experiment_keys_vs_scan(),
        "big_key_cost": experiment_big_key_cost(),
        "blocking": experiment_blocking(),
        "hot_key": experiment_hot_key(),
    }


if __name__ == "__main__":
    import json
    import sys

    data = run_all_experiments()
    json.dump(data, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
