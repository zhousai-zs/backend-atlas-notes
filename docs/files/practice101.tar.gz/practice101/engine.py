#!/usr/bin/env python3
"""Teaching RedisEngine — not Redis.

A Python standard-library model of a single-command, single-threaded
keyspace with string, hash, and sorted-set types. It accounts for how
many items a command examines and can hold a mutex while sleeping a
fixed cost per item, so a cheap INCR can be seen waiting behind KEYS,
HGETALL, or a full ZRANGE.

This is not Redis, not redis-py, and not a network server. Command
semantics follow the official Redis data-type and command pages that
were checked on 2026-11-11, but only for the subset implemented here.
Internal encodings (ziplist, listpack, skiplist) are not modeled;
sorted sets use a dict plus a bisect-ordered list.
"""
from __future__ import annotations

import fnmatch
import math
import threading
import time
from typing import Any, Callable, Optional


class RedisError(Exception):
    pass


class WrongTypeError(RedisError):
    def __init__(self) -> None:
        super().__init__(
            "WRONGTYPE Operation against a key holding the wrong kind of value"
        )


class Clock:
    """Monotonic clock that tests can freeze and advance."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t += float(seconds)


class _Key:
    __slots__ = ("kind", "value", "expire_at")

    def __init__(self, kind: str, value: Any, expire_at: Optional[float] = None) -> None:
        self.kind = kind
        self.value = value
        self.expire_at = expire_at


class RedisEngine:
    """Single-threaded teaching key-value engine."""

    def __init__(
        self,
        clock: Optional[Clock] = None,
        unit_s: float = 0.0,
    ) -> None:
        self._clock = clock or Clock()
        self.unit_s = float(unit_s)
        self._keys: dict[str, _Key] = {}
        self._lock = threading.Lock()
        self.command_log: list[dict[str, Any]] = []
        self.hits: dict[str, int] = {}

    def now(self) -> float:
        return self._clock.now()

    def dbsize(self) -> int:
        with self._lock:
            self._expire_all()
            return len(self._keys)

    # --- public commands (each is one atomic unit) ---

    def set(
        self,
        key: str,
        value: Any,
        ex: Optional[float] = None,
        nx: bool = False,
        xx: bool = False,
    ) -> Optional[bool]:
        def body() -> tuple[Optional[bool], int]:
            cur = self._get_live(key)
            if nx and cur is not None:
                return None, 1
            if xx and cur is None:
                return None, 1
            expire_at = (self.now() + float(ex)) if ex is not None else None
            self._keys[key] = _Key("string", str(value), expire_at)
            return True, 1

        return self._run("SET", key, body)

    def get(self, key: str) -> Optional[str]:
        def body() -> tuple[Optional[str], int]:
            cur = self._get_live(key)
            if cur is None:
                return None, 1
            self._require(cur, "string")
            return cur.value, 1

        return self._run("GET", key, body)

    def incr(self, key: str, amount: int = 1) -> int:
        def body() -> tuple[int, int]:
            cur = self._get_live(key)
            if cur is None:
                self._keys[key] = _Key("string", str(amount), None)
                return amount, 1
            self._require(cur, "string")
            try:
                n = int(cur.value)
            except ValueError as exc:
                raise RedisError("ERR value is not an integer or out of range") from exc
            n += amount
            cur.value = str(n)
            return n, 1

        return self._run("INCR" if amount == 1 else "INCRBY", key, body)

    def expire(self, key: str, seconds: float) -> int:
        def body() -> tuple[int, int]:
            cur = self._get_live(key)
            if cur is None:
                return 0, 1
            cur.expire_at = self.now() + float(seconds)
            return 1, 1

        return self._run("EXPIRE", key, body)

    def ttl(self, key: str) -> int:
        def body() -> tuple[int, int]:
            cur = self._keys.get(key)
            if cur is None:
                return -2, 1
            if self._expired(cur):
                del self._keys[key]
                return -2, 1
            if cur.expire_at is None:
                return -1, 1
            remaining = int(math.ceil(cur.expire_at - self.now()))
            return remaining, 1

        return self._run("TTL", key, body)

    def delete(self, *keys: str) -> int:
        def body() -> tuple[int, int]:
            n = 0
            for k in keys:
                cur = self._get_live(k)
                if cur is not None:
                    del self._keys[k]
                    n += 1
            return n, max(len(keys), 1)

        primary = keys[0] if keys else ""
        return self._run("DEL", primary, body)

    def type(self, key: str) -> str:
        def body() -> tuple[str, int]:
            cur = self._get_live(key)
            if cur is None:
                return "none", 1
            return cur.kind, 1

        return self._run("TYPE", key, body)

    def hset(self, key: str, field: str, value: Any) -> int:
        def body() -> tuple[int, int]:
            cur = self._hash(key, create=True)
            fields: dict[str, str] = cur.value
            created = 0 if field in fields else 1
            fields[field] = str(value)
            return created, 1

        return self._run("HSET", key, body)

    def hget(self, key: str, field: str) -> Optional[str]:
        def body() -> tuple[Optional[str], int]:
            cur = self._get_live(key)
            if cur is None:
                return None, 1
            self._require(cur, "hash")
            return cur.value.get(field), 1

        return self._run("HGET", key, body)

    def hincrby(self, key: str, field: str, amount: int = 1) -> int:
        def body() -> tuple[int, int]:
            cur = self._hash(key, create=True)
            fields: dict[str, str] = cur.value
            raw = fields.get(field, "0")
            try:
                n = int(raw)
            except ValueError as exc:
                raise RedisError("ERR hash value is not an integer") from exc
            n += amount
            fields[field] = str(n)
            return n, 1

        return self._run("HINCRBY", key, body)

    def hlen(self, key: str) -> int:
        def body() -> tuple[int, int]:
            cur = self._get_live(key)
            if cur is None:
                return 0, 1
            self._require(cur, "hash")
            return len(cur.value), 1

        return self._run("HLEN", key, body)

    def hmget(self, key: str, *fields: str) -> list[Optional[str]]:
        def body() -> tuple[list[Optional[str]], int]:
            cur = self._get_live(key)
            if cur is None:
                return [None] * len(fields), max(len(fields), 1)
            self._require(cur, "hash")
            return [cur.value.get(f) for f in fields], max(len(fields), 1)

        return self._run("HMGET", key, body)

    def hgetall(self, key: str) -> dict[str, str]:
        def body() -> tuple[dict[str, str], int]:
            cur = self._get_live(key)
            if cur is None:
                return {}, 1
            self._require(cur, "hash")
            fields: dict[str, str] = cur.value
            return dict(fields), max(len(fields), 1)

        return self._run("HGETALL", key, body)

    def zadd(self, key: str, member: str, score: float) -> int:
        def body() -> tuple[int, int]:
            z = self._zset(key, create=True)
            created = 0 if member in z["score"] else 1
            self._z_upsert(z, member, float(score))
            n = len(z["score"])
            examined = 1 + int(math.floor(math.log2(max(n, 1))))
            return created, examined

        return self._run("ZADD", key, body)

    def zincrby(self, key: str, amount: float, member: str) -> float:
        def body() -> tuple[float, int]:
            z = self._zset(key, create=True)
            new_score = z["score"].get(member, 0.0) + float(amount)
            self._z_upsert(z, member, new_score)
            n = len(z["score"])
            examined = 1 + int(math.floor(math.log2(max(n, 1))))
            return new_score, examined

        return self._run("ZINCRBY", key, body)

    def zscore(self, key: str, member: str) -> Optional[float]:
        def body() -> tuple[Optional[float], int]:
            cur = self._get_live(key)
            if cur is None:
                return None, 1
            self._require(cur, "zset")
            return cur.value["score"].get(member), 1

        return self._run("ZSCORE", key, body)

    def zcard(self, key: str) -> int:
        def body() -> tuple[int, int]:
            cur = self._get_live(key)
            if cur is None:
                return 0, 1
            self._require(cur, "zset")
            return len(cur.value["score"]), 1

        return self._run("ZCARD", key, body)

    def zrank(self, key: str, member: str, reverse: bool = False) -> Optional[int]:
        def body() -> tuple[Optional[int], int]:
            cur = self._get_live(key)
            if cur is None:
                return None, 1
            self._require(cur, "zset")
            order: list[tuple[float, str]] = cur.value["order"]
            if member not in cur.value["score"]:
                return None, 1
            idx = next(i for i, (_, m) in enumerate(order) if m == member)
            rank = (len(order) - 1 - idx) if reverse else idx
            examined = 1 + int(math.floor(math.log2(max(len(order), 1))))
            return rank, examined

        return self._run("ZREVRANK" if reverse else "ZRANK", key, body)

    def zrange(
        self,
        key: str,
        start: int,
        stop: int,
        desc: bool = False,
        withscores: bool = False,
    ) -> list:
        def body() -> tuple[list, int]:
            cur = self._get_live(key)
            if cur is None:
                return [], 1
            self._require(cur, "zset")
            order: list[tuple[float, str]] = cur.value["order"]
            n = len(order)
            lo, hi = self._bound_index(n, start, stop)
            if lo > hi:
                sliced: list[tuple[float, str]] = []
            else:
                sliced = order[lo : hi + 1]
            if desc:
                sliced = list(reversed(sliced))
            examined = 1 + int(math.floor(math.log2(max(n, 1)))) + len(sliced)
            if withscores:
                return [(m, s) for s, m in sliced], examined
            return [m for s, m in sliced], examined

        name = "ZREVRANGE" if desc else "ZRANGE"
        return self._run(name, key, body)

    def zrevrange(self, key: str, start: int, stop: int, withscores: bool = False) -> list:
        def body() -> tuple[list, int]:
            cur = self._get_live(key)
            if cur is None:
                return [], 1
            self._require(cur, "zset")
            order: list[tuple[float, str]] = cur.value["order"]
            n = len(order)
            lo, hi = self._bound_index(n, start, stop)
            if n == 0 or lo > hi:
                sliced: list[tuple[float, str]] = []
            else:
                # Rank 0 in ZREVRANGE is the highest score (last in ascending order).
                fwd_lo = n - 1 - hi
                fwd_hi = n - 1 - lo
                sliced = list(reversed(order[fwd_lo : fwd_hi + 1]))
            examined = 1 + int(math.floor(math.log2(max(n, 1)))) + len(sliced)
            if withscores:
                return [(m, s) for s, m in sliced], examined
            return [m for s, m in sliced], examined

        return self._run("ZREVRANGE", key, body)

    def keys(self, pattern: str = "*") -> list[str]:
        def body() -> tuple[list[str], int]:
            self._expire_all()
            names = list(self._keys.keys())
            matched = [k for k in names if fnmatch.fnmatch(k, pattern)]
            # KEYS is O(N) over the whole keyspace, not over the matches.
            return matched, max(len(names), 1)

        return self._run("KEYS", "*", body)

    def scan(
        self,
        cursor: int = 0,
        match: str = "*",
        count: int = 10,
    ) -> tuple[int, list[str]]:
        def body() -> tuple[tuple[int, list[str]], int]:
            self._expire_all()
            names = sorted(self._keys.keys())
            n = len(names)
            if n == 0:
                return (0, []), 1
            start = int(cursor)
            if start >= n:
                return (0, []), 1
            end = min(start + max(int(count), 1), n)
            window = names[start:end]
            matched = [k for k in window if fnmatch.fnmatch(k, match)]
            nxt = 0 if end >= n else end
            examined = end - start
            return (nxt, matched), max(examined, 1)

        return self._run("SCAN", "*", body)

    def scan_all(self, match: str = "*", count: int = 10) -> tuple[list[str], int, int]:
        """Walk SCAN until the cursor returns to 0. Returns (keys, calls, examined)."""
        cursor = 0
        found: list[str] = []
        calls = 0
        examined = 0
        while True:
            before = len(self.command_log)
            cursor, batch = self.scan(cursor, match=match, count=count)
            calls += 1
            if self.command_log and len(self.command_log) > before:
                examined += int(self.command_log[-1]["examined"])
            found.extend(batch)
            if cursor == 0:
                break
        return found, calls, examined

    # --- internals ---

    def _run(self, name: str, key: str, body: Callable[[], tuple[Any, int]]) -> Any:
        t0 = time.perf_counter()
        with self._lock:
            t_got = time.perf_counter()
            result, examined = body()
            if key:
                self.hits[key] = self.hits.get(key, 0) + 1
            if self.unit_s > 0 and examined > 0:
                time.sleep(self.unit_s * examined)
            rec = {
                "cmd": name,
                "key": key,
                "examined": int(examined),
                "lock_wait_s": round(t_got - t0, 6),
                "held_s": round(time.perf_counter() - t_got, 6),
            }
            self.command_log.append(rec)
            return result

    def _expired(self, cur: _Key) -> bool:
        return cur.expire_at is not None and cur.expire_at <= self.now()

    def _get_live(self, key: str) -> Optional[_Key]:
        cur = self._keys.get(key)
        if cur is None:
            return None
        if self._expired(cur):
            del self._keys[key]
            return None
        return cur

    def _expire_all(self) -> None:
        dead = [k for k, cur in self._keys.items() if self._expired(cur)]
        for k in dead:
            del self._keys[k]

    def _require(self, cur: _Key, kind: str) -> None:
        if cur.kind != kind:
            raise WrongTypeError()

    def _hash(self, key: str, create: bool) -> _Key:
        cur = self._get_live(key)
        if cur is None:
            if not create:
                raise KeyError(key)
            cur = _Key("hash", {}, None)
            self._keys[key] = cur
            return cur
        self._require(cur, "hash")
        return cur

    def _zset(self, key: str, create: bool) -> dict:
        cur = self._get_live(key)
        if cur is None:
            if not create:
                raise KeyError(key)
            cur = _Key("zset", {"score": {}, "order": []}, None)
            self._keys[key] = cur
            return cur.value
        self._require(cur, "zset")
        return cur.value

    def _z_upsert(self, z: dict, member: str, score: float) -> None:
        scores: dict[str, float] = z["score"]
        order: list[tuple[float, str]] = z["order"]
        if member in scores:
            old = scores[member]
            try:
                order.remove((old, member))
            except ValueError:
                pass
        scores[member] = score
        # Same score: lexicographic member order, matching Redis docs.
        lo, hi = 0, len(order)
        item = (score, member)
        while lo < hi:
            mid = (lo + hi) // 2
            if order[mid] < item:
                lo = mid + 1
            else:
                hi = mid
        order.insert(lo, item)

    @staticmethod
    def _bound_index(n: int, start: int, stop: int) -> tuple[int, int]:
        if start < 0:
            start = n + start
        if stop < 0:
            stop = n + stop
        start = max(0, start)
        stop = min(n - 1, stop)
        return start, stop
