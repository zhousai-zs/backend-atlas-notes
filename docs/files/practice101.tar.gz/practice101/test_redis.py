#!/usr/bin/env python3
"""Acceptance checks for the g-redis teaching lab."""
from __future__ import annotations

import json
import math
import os
import sys

from app import (
    BIG_FIELDS,
    BIG_MEMBERS,
    BLOCK_UNIT_S,
    CONCURRENT_INCREMENTS,
    KEYSPACE,
    WINDOW_S,
    run_all_experiments,
)

HERE = os.path.dirname(os.path.abspath(__file__))

REDIS_DATA_TYPES = "https://redis.io/docs/latest/develop/data-types/"
REDIS_STRINGS = "https://redis.io/docs/latest/develop/data-types/strings/"
REDIS_HASHES = "https://redis.io/docs/latest/develop/data-types/hashes/"
REDIS_ZSETS = "https://redis.io/docs/latest/develop/data-types/sorted-sets/"
REDIS_KEYS = "https://redis.io/docs/latest/commands/keys/"
REDIS_SCAN = "https://redis.io/docs/latest/commands/scan/"


def main() -> int:
    data = run_all_experiments()
    data.update(
        {
            "python": sys.version.split()[0],
            "redis_doc": REDIS_DATA_TYPES,
            "redis_doc_checked": "2026-11-11",
            "strings_doc": REDIS_STRINGS,
            "hashes_doc": REDIS_HASHES,
            "zsets_doc": REDIS_ZSETS,
            "keys_doc": REDIS_KEYS,
            "scan_doc": REDIS_SCAN,
        }
    )

    _assert_leaderboard(data["types_and_leaderboard"])
    _assert_atomic(data["atomic_vs_multistep"])
    _assert_expire(data["expire_counter"])
    _assert_scan(data["keys_vs_scan"])
    _assert_big(data["big_key_cost"])
    _assert_blocking(data["blocking"])
    _assert_hot(data["hot_key"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")

    lb = data["types_and_leaderboard"]
    atom = data["atomic_vs_multistep"]
    exp = data["expire_counter"]
    ks = data["keys_vs_scan"]
    big = data["big_key_cost"]
    blk = data["blocking"]
    hot = data["hot_key"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"types=hash/{lb['types']['article:42']},string/{lb['types']['views:42']},"
        f"zset/{lb['types']['rank:daily']} "
        f"top1={lb['top10'][0][0]}:{lb['top10'][0][1]} "
        f"revrank42={lb['article_42_revrank']} "
        f"top10_exam={lb['top10_examined']} full_exam={lb['full_dump_examined']} "
        f"naive_incr={atom['naive_get_set']} safe_incr={atom['safe_incr']} "
        f"naive_z={atom['naive_zscore_zadd']} safe_z={atom['safe_zincrby']} "
        f"naive_ttl={exp['naive']['ttl_after_crashed_first_hit']} "
        f"naive_after={exp['naive']['value_after_window']} "
        f"safe_after={exp['safe']['value_after_window']} "
        f"keys_exam={ks['keys']['examined']} scan_one_exam={ks['scan_one_call']['examined']} "
        f"hget_exam={big['hget']['examined']} hgetall_exam={big['hgetall']['examined']} "
        f"ztop_exam={big['zrevrange_top10']['examined']} zfull_exam={big['zrange_full']['examined']} "
        f"keys_wait_s={blk['behind_keys']['wait_s']} "
        f"scan_wait_s={blk['behind_scan_one']['wait_s']} "
        f"hgetall_wait_s={blk['behind_hgetall']['wait_s']} "
        f"hget_wait_s={blk['behind_hget']['wait_s']} "
        f"zfull_wait_s={blk['behind_zrange_full']['wait_s']} "
        f"ztop_wait_s={blk['behind_zrevrange_top10']['wait_s']} "
        f"hot_hits={hot['hot_hits']} cold_hits={hot['cold_hits']} "
        f"hot_exam={hot['hot_examined_total']} cold_exam={hot['cold_examined_total']}"
    )
    return 0


def _assert_leaderboard(lb: dict) -> None:
    assert lb["types"] == {
        "article:42": "hash",
        "views:42": "string",
        "rank:daily": "zset",
    }, lb
    assert lb["meta"] == {
        "title": "Weekly digest",
        "status": "published",
        "views": 82,
    }, lb
    assert lb["members"] == 21, lb
    assert lb["views_42"] == 82, lb
    assert lb["article_42_score"] == 82, lb
    assert lb["article_42_revrank"] == 0, lb
    assert lb["top10"][0] == ("42", 82), lb
    assert lb["top10"][1] == ("20", 60), lb
    assert len(lb["top10"]) == 10, lb
    assert lb["full_dump_count"] == 21, lb
    # examined = 1 + floor(log2(N)) + M
    n = 21
    base = 1 + int(math.floor(math.log2(n)))
    assert lb["top10_examined"] == base + 10, lb
    assert lb["full_dump_examined"] == base + 21, lb


def _assert_atomic(atom: dict) -> None:
    assert atom["concurrent"] == CONCURRENT_INCREMENTS == atom["expected"], atom
    assert atom["safe_incr"] == CONCURRENT_INCREMENTS, atom
    assert atom["safe_zincrby"] == CONCURRENT_INCREMENTS, atom
    # Multi-step client paths must lose updates under the same concurrency.
    assert atom["naive_get_set"] < atom["expected"], atom
    assert atom["naive_zscore_zadd"] < atom["expected"], atom
    assert atom["naive_get_set"] >= 1, atom
    assert atom["naive_zscore_zadd"] >= 1, atom


def _assert_expire(exp: dict) -> None:
    assert exp["window_s"] == WINDOW_S, exp
    naive = exp["naive"]
    assert naive["first"] == 1, naive
    assert naive["ttl_after_crashed_first_hit"] == -1, naive
    assert naive["value_after_window"] == "10", naive
    assert naive["ttl_after_window"] == -1, naive
    safe = exp["safe"]
    assert safe["first"] == 1, safe
    assert safe["ttl_on_create"] == int(WINDOW_S), safe
    assert safe["count_before_window_end"] == 10, safe
    assert safe["value_after_window"] is None, safe
    assert safe["ttl_after_window"] == -2, safe
    assert safe["new_window_first"] == 1, safe
    assert safe["ttl_new_window"] == int(WINDOW_S), safe


def _assert_scan(ks: dict) -> None:
    # 4000 views/article keys + 50 sessions + 1 rank key.
    assert ks["dbsize"] == KEYSPACE + 50 + 1, ks
    assert ks["keys"]["matches"] == KEYSPACE // 2, ks
    assert ks["keys"]["examined"] == ks["dbsize"], ks
    assert ks["scan_all"]["matches"] == ks["keys"]["matches"], ks
    assert ks["same_matches"] is True, ks
    assert ks["scan_all"]["examined"] == ks["dbsize"], ks
    expected_calls = math.ceil(ks["dbsize"] / 20)
    assert ks["scan_all"]["calls"] == expected_calls, ks
    assert ks["scan_one_call"]["examined"] == 20, ks
    assert ks["scan_one_call"]["cursor"] != 0, ks


def _assert_big(big: dict) -> None:
    assert big["hash_fields"] == BIG_FIELDS, big
    assert big["zset_members"] == BIG_MEMBERS, big
    assert big["hget"]["examined"] == 1, big
    assert big["hget"]["value"] == "7", big
    assert big["hmget"]["examined"] == 3, big
    assert big["hgetall"]["fields"] == BIG_FIELDS, big
    assert big["hgetall"]["examined"] == BIG_FIELDS, big
    zlog = 1 + int(math.floor(math.log2(BIG_MEMBERS)))
    assert big["zrevrange_top10"]["count"] == 10, big
    assert big["zrevrange_top10"]["examined"] == zlog + 10, big
    assert big["zrevrange_top10"]["first"] == "article:1999", big
    assert big["zrange_full"]["count"] == BIG_MEMBERS, big
    assert big["zrange_full"]["examined"] == zlog + BIG_MEMBERS, big


def _assert_blocking(blk: dict) -> None:
    assert blk["unit_s"] == BLOCK_UNIT_S, blk
    keys = blk["behind_keys"]
    scan = blk["behind_scan_one"]
    hgetall = blk["behind_hgetall"]
    hget = blk["behind_hget"]
    zfull = blk["behind_zrange_full"]
    ztop = blk["behind_zrevrange_top10"]

    assert keys["heavy"]["cmd"] == "KEYS", keys
    assert keys["heavy"]["examined"] == KEYSPACE + 50 + 1 + 1, keys  # + views:probe
    # 4052 * 50µs ≈ 0.203s; the probe sleeps 10ms then waits for the remainder.
    assert keys["wait_s"] >= 0.12, keys
    assert keys["value"] == 1, keys

    assert scan["heavy"]["cmd"] == "SCAN", scan
    assert scan["heavy"]["examined"] == 20, scan
    assert scan["wait_s"] < 0.05, scan

    assert hgetall["heavy"]["cmd"] == "HGETALL", hgetall
    assert hgetall["heavy"]["examined"] == BIG_FIELDS, hgetall
    assert hgetall["wait_s"] >= 0.05, hgetall
    assert hget["heavy"]["cmd"] == "HGET", hget
    assert hget["heavy"]["examined"] == 1, hget
    assert hget["wait_s"] < 0.05, hget

    assert zfull["heavy"]["cmd"] == "ZRANGE", zfull
    zlog = 1 + int(math.floor(math.log2(BIG_MEMBERS)))
    assert zfull["heavy"]["examined"] == zlog + BIG_MEMBERS, zfull
    assert zfull["wait_s"] >= 0.05, zfull
    assert ztop["heavy"]["cmd"] == "ZREVRANGE", ztop
    assert ztop["heavy"]["examined"] == zlog + 10, ztop
    assert ztop["wait_s"] < 0.05, ztop


def _assert_hot(hot: dict) -> None:
    assert hot["requests"] == 100, hot
    assert hot["hot_hits"] == 80, hot
    assert hot["cold_hits"] == 20, hot
    assert hot["hot_share"] == 0.8, hot
    assert hot["hot_examined_total"] == 80 * BIG_FIELDS, hot
    assert hot["cold_examined_total"] == 20, hot


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print("CHECK_FAILED", file=sys.stderr)
        print(exc, file=sys.stderr)
        raise
