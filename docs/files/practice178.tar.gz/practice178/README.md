# 实践 178：工具重试、超时与取消

在解压后的 `practice178/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（标准库）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

远端是进程内模拟存储。is_live_remote_http=false。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
