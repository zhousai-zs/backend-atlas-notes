"""Tool retry, timeout, and cancel with a unified time budget.

Classification:
  remote_failed          — the remote confirmed failure (4xx/5xx after accept)
  not_executed           — we never dispatched (auth, bad params, cancelled, budget exhausted)
  submit_result_unknown  — we dispatched but did not get a conclusive response (timeout after send)

A timeout after submit MUST query by request_id before any retry write.
Auth and parameter errors are never auto-retried.
Cancel and exhausted budget start no new attempt.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


class AuthError(Exception):
    pass


class ParamError(Exception):
    pass


class Cancelled(Exception):
    pass


class BudgetExhausted(Exception):
    pass


@dataclass
class RemoteStore:
    """Simulated remote that can accept a write then go silent, or return errors."""

    records: dict = field(default_factory=dict)  # request_id -> body
    # Hook flags per request_id
    silence_after_accept: set = field(default_factory=set)
    fail_status: dict = field(default_factory=dict)  # request_id -> status
    submitted: list = field(default_factory=list)

    def submit(self, request_id, body, *, timeout_after_accept=False):
        self.submitted.append(request_id)
        if request_id in self.fail_status:
            return {"ok": False, "status": self.fail_status[request_id], "request_id": request_id}
        # Accept (write) first, then optionally go silent — the classic "timeout after write".
        self.records[request_id] = body
        if timeout_after_accept or request_id in self.silence_after_accept:
            return {"ok": None, "status": "timeout", "request_id": request_id, "written": True}
        return {"ok": True, "status": 200, "request_id": request_id}

    def query(self, request_id):
        if request_id in self.records:
            return {"found": True, "body": self.records[request_id], "request_id": request_id}
        return {"found": False, "request_id": request_id}


@dataclass
class Outcome:
    status: str  # remote_failed | not_executed | submit_result_unknown | succeeded
    attempts: int
    request_id: str
    detail: str
    queried: bool = False
    wrote_count: int = 0


class Runner:
    def __init__(self, store: RemoteStore, *, budget_s: float, now=None):
        self.store = store
        self.budget_s = budget_s
        self.started = time.monotonic() if now is None else now
        self.cancelled = False
        self.log = []

    def remaining(self, now=None):
        now = time.monotonic() if now is None else now
        return self.budget_s - (now - self.started)

    def cancel(self):
        self.cancelled = True
        self.log.append({"kind": "cancel"})

    def _classify_and_raise(self, kind, request_id, detail, attempts, queried=False, wrote_count=0):
        self.log.append({"kind": kind, "request_id": request_id, "detail": detail, "attempts": attempts})
        return Outcome(kind, attempts, request_id, detail, queried=queried, wrote_count=wrote_count)

    def submit_report(self, request_id, body, *, user, acl, params_ok=True, retry_on=None, simulate_clock=None):
        """retry_on: set of statuses that may be retried (default {429})."""
        retry_on = retry_on if retry_on is not None else {429}
        attempts = 0
        if user not in acl or "write" not in acl[user]:
            return self._classify_and_raise("not_executed", request_id, "auth", attempts)
        if not params_ok:
            return self._classify_and_raise("not_executed", request_id, "bad_params", attempts)
        if self.cancelled:
            return self._classify_and_raise("not_executed", request_id, "cancelled_before_start", attempts)

        last_unknown = False
        while True:
            now = time.monotonic() if simulate_clock is None else simulate_clock[0]
            if self.cancelled:
                return self._classify_and_raise("not_executed", request_id, "cancelled", attempts)
            if self.remaining(now) <= 0:
                return self._classify_and_raise("not_executed", request_id, "budget_exhausted", attempts)

            # If a previous attempt timed out after submit, QUERY before any new write.
            existing = self.store.query(request_id)
            if existing["found"]:
                self.log.append({"kind": "query_hit", "request_id": request_id})
                return Outcome("succeeded", attempts, request_id, "recovered_by_request_id", queried=True, wrote_count=1)

            attempts += 1
            resp = self.store.submit(request_id, body)
            wrote = 1 if request_id in self.store.records else 0

            if resp["ok"] is True:
                return Outcome("succeeded", attempts, request_id, "ok", wrote_count=wrote)

            if resp["status"] == "timeout":
                # Do not retry-write blindly. Next loop iteration will query.
                self.log.append({"kind": "submit_result_unknown", "request_id": request_id, "attempts": attempts})
                last_unknown = True
                # Simulate spending some budget; in tests the caller can shrink remaining.
                if simulate_clock is not None:
                    simulate_clock[0] += 0.01
                existing = self.store.query(request_id)
                if existing["found"]:
                    self.log.append({"kind": "query_hit_after_timeout", "request_id": request_id})
                    return Outcome("succeeded", attempts, request_id, "timeout_then_query", queried=True, wrote_count=1)
                # truly unknown and not on the remote — only then consider retry, if budget remains
                continue

            status = resp["status"]
            if status in retry_on:
                self.log.append({"kind": "remote_failed", "retryable": True, "status": status, "attempts": attempts})
                if simulate_clock is not None:
                    simulate_clock[0] += 0.01
                continue
            # 401/403/400 etc. — not auto-retried
            self.log.append({"kind": "remote_failed", "retryable": False, "status": status, "attempts": attempts})
            return Outcome("remote_failed", attempts, request_id, str(status), wrote_count=wrote)
