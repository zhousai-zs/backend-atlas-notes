#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from retry import Runner, RemoteStore

ROOT = Path(__file__).resolve().parent
ACL = {"alice": {"read", "write"}, "bob": {"read"}}

# 1) timeout after write → query by request_id, no double write
store = RemoteStore()
store.silence_after_accept.add("req-timeout")
r = Runner(store, budget_s=5.0)
out = r.submit_report("req-timeout", "body-1", user="alice", acl=ACL)
assert out.status == "succeeded" and out.queried and out.wrote_count == 1
assert store.submitted.count("req-timeout") == 1
assert store.records["req-timeout"] == "body-1"
assert any(e["kind"] == "submit_result_unknown" for e in r.log)
assert any(e["kind"] == "query_hit_after_timeout" for e in r.log)

# 2) auth error is not executed and not retried
store2 = RemoteStore()
r2 = Runner(store2, budget_s=5.0)
out2 = r2.submit_report("req-auth", "body", user="bob", acl=ACL)
assert out2.status == "not_executed" and out2.detail == "auth" and out2.attempts == 0
assert store2.submitted == []

# 3) param error is not executed and not retried
store3 = RemoteStore()
r3 = Runner(store3, budget_s=5.0)
out3 = r3.submit_report("req-param", "body", user="alice", acl=ACL, params_ok=False)
assert out3.status == "not_executed" and out3.detail == "bad_params" and out3.attempts == 0
assert store3.submitted == []

# 4) 401 after accept? actually before write — remote_failed, not retried
store4 = RemoteStore()
store4.fail_status["req-401"] = 401
r4 = Runner(store4, budget_s=5.0)
out4 = r4.submit_report("req-401", "body", user="alice", acl=ACL)
assert out4.status == "remote_failed" and out4.attempts == 1
assert store4.submitted == ["req-401"]  # exactly once

# 5) 429 is retried then succeeds (second attempt not silent / not 429)
store5 = RemoteStore()
# first call 429, second 200 — implement by consuming fail_status once
class Once429(RemoteStore):
    def submit(self, request_id, body, *, timeout_after_accept=False):
        self.submitted.append(request_id)
        if request_id not in self.records and self.fail_status.get(request_id) == 429:
            # do not write on 429
            self.fail_status.pop(request_id)
            return {"ok": False, "status": 429, "request_id": request_id}
        self.records[request_id] = body
        return {"ok": True, "status": 200, "request_id": request_id}

store5 = Once429()
store5.fail_status["req-429"] = 429
r5 = Runner(store5, budget_s=5.0)
out5 = r5.submit_report("req-429", "body", user="alice", acl=ACL)
assert out5.status == "succeeded" and out5.attempts == 2
assert any(e.get("status")==429 and e.get("retryable") for e in r5.log)

# 6) cancel before start — no attempt
store6 = RemoteStore()
r6 = Runner(store6, budget_s=5.0)
r6.cancel()
out6 = r6.submit_report("req-cancel", "body", user="alice", acl=ACL)
assert out6.status == "not_executed" and out6.detail == "cancelled_before_start"
assert store6.submitted == []

# 7) budget already exhausted — no attempt
store7 = RemoteStore()
r7 = Runner(store7, budget_s=0.0)  # remaining <= 0 immediately
out7 = r7.submit_report("req-budget", "body", user="alice", acl=ACL)
assert out7.status == "not_executed" and out7.detail == "budget_exhausted"
assert store7.submitted == []

# 8) mid-loop cancel: set cancelled after first unknown? covered by before-start and budget.
# Also: a 400 is remote_failed, not retried
store8 = RemoteStore()
store8.fail_status["req-400"] = 400
r8 = Runner(store8, budget_s=5.0)
out8 = r8.submit_report("req-400", "body", user="alice", acl=ACL)
assert out8.status == "remote_failed" and out8.attempts == 1 and store8.submitted == ["req-400"]

kinds_present = sorted({e["kind"] for e in r.log + r2.log + r4.log + r5.log + r6.log + r7.log + r8.log})

results = {
    "lesson": 178,
    "id": "l-retry",
    "is_live_remote_http": False,
    "timeout_after_write": {
        "status": out.status,
        "queried": out.queried,
        "wrote_count": out.wrote_count,
        "submit_count": store.submitted.count("req-timeout"),
    },
    "auth_not_retried": {"status": out2.status, "attempts": out2.attempts, "submitted": store2.submitted},
    "param_not_retried": {"status": out3.status, "attempts": out3.attempts, "submitted": store3.submitted},
    "http_401_not_retried": {"status": out4.status, "attempts": out4.attempts, "submitted": store4.submitted},
    "http_400_not_retried": {"status": out8.status, "attempts": out8.attempts, "submitted": store8.submitted},
    "http_429_retried_then_ok": {"status": out5.status, "attempts": out5.attempts},
    "cancel_starts_no_attempt": {"status": out6.status, "submitted": store6.submitted},
    "budget_starts_no_attempt": {"status": out7.status, "submitted": store7.submitted},
    "log_kinds_seen": kinds_present,
    "verified_on_this_machine": [
        "timeout_after_accept_queries_request_id_and_does_not_double_write",
        "auth_and_param_and_401_400_not_auto_retried",
        "429_retried",
        "cancel_and_budget_start_no_new_attempt",
        "logs_distinguish_remote_failed_not_executed_submit_result_unknown",
    ],
    "not_verified_on_this_machine": ["real_multi_region_HTTP_timeouts_or_message_bus"],
}
assert "remote_failed" in kinds_present
assert "not_executed" in kinds_present or out2.status == "not_executed"
assert "submit_result_unknown" in kinds_present
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"timeout": results["timeout_after_write"], "kinds": kinds_present}, indent=2))
print("ALL_CHECKS_PASSED")
