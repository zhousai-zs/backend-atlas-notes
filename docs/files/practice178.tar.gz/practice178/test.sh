#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
t=r["timeout_after_write"]
assert t["status"]=="succeeded" and t["queried"] and t["wrote_count"]==1 and t["submit_count"]==1
assert r["auth_not_retried"]["attempts"]==0 and r["param_not_retried"]["attempts"]==0
assert r["http_401_not_retried"]["attempts"]==1 and r["http_400_not_retried"]["attempts"]==1
assert r["http_429_retried_then_ok"]["attempts"]==2
assert r["cancel_starts_no_attempt"]["submitted"]==[] and r["budget_starts_no_attempt"]["submitted"]==[]
for k in ("remote_failed","submit_result_unknown"):
    assert k in r["log_kinds_seen"], r["log_kinds_seen"]
print("POSTCHECK_OK")
PY
