#!/usr/bin/env python3
from __future__ import annotations

import json
import time
from pathlib import Path

from approval import ApprovalError, Store, param_digest

ROOT = Path(__file__).resolve().parent
DB = ROOT / "reports/approvals.db"
now = time.time()
s = Store(DB)
s.set_perm("alice", "granted")
s.put_resource("report-1", 1, "draft-v1")

# Happy path: unique binding of tool+params+resource+version
a = s.prepare(
    "ap-ok",
    tool="publish_report",
    params={"target": "report-1", "channel": "ops"},
    resource_id="report-1",
    user_id="alice",
    expires_at=now + 3600,
)
assert a["state"] == "pending"
assert a["param_digest"] == param_digest({"target": "report-1", "channel": "ops"})
assert a["resource_version"] == 1 and a["tool"] == "publish_report"
r1 = s.approve_and_apply("ap-ok")
assert r1["status"] == "applied" and s.execution_count("ap-ok") == 1

# Duplicate approve does not resubmit
r1b = s.approve_and_apply("ap-ok")
assert r1b["status"] == "already_applied" and r1b["resubmitted"] is False
assert r1b["request_id"] == r1["request_id"]
assert s.execution_count("ap-ok") == 1

# Resource version drift invalidates a previously pending approval
s.prepare("ap-drift", tool="publish_report", params={"target": "report-1", "channel": "ops"}, resource_id="report-1", user_id="alice", expires_at=now+3600)
s.bump_resource("report-1", "draft-v2")
drift = None
try:
    s.approve_and_apply("ap-drift")
except ApprovalError as e:
    drift = e.reason
assert drift == "resource_version_drift"
assert s.execution_count("ap-drift") == 0
assert s._approval("ap-drift")["state"] == "invalid"

# Auth revoke invalidates old approval
s.put_resource("report-2", 1, "other")
s.prepare("ap-rev", tool="publish_report", params={"target": "report-2"}, resource_id="report-2", user_id="alice", expires_at=now+3600)
s.set_perm("alice", "revoked")
revoked = None
try:
    s.approve_and_apply("ap-rev")
except ApprovalError as e:
    revoked = e.reason
assert revoked == "permission_revoked"
assert s.execution_count("ap-rev") == 0
s.set_perm("alice", "granted")  # restore for later cases

# Reject does not execute
s.put_resource("report-3", 1, "body")
s.prepare("ap-rej", tool="publish_report", params={"target": "report-3"}, resource_id="report-3", user_id="alice", expires_at=now+3600)
s.reject("ap-rej")
rej = None
try:
    s.approve_and_apply("ap-rej")
except ApprovalError as e:
    rej = e.reason
assert rej == "rejected" and s.execution_count("ap-rej") == 0

# Expiry does not execute
s.prepare("ap-exp", tool="publish_report", params={"target": "report-3"}, resource_id="report-3", user_id="alice", expires_at=now-1)
exp = None
try:
    s.approve_and_apply("ap-exp", now=now)
except ApprovalError as e:
    exp = e.reason
assert exp == "expired" and s.execution_count("ap-exp") == 0
assert s._approval("ap-exp")["state"] == "expired"

# Pending survives process restart (reopen the same sqlite file)
s.prepare("ap-restart", tool="publish_report", params={"target": "report-3", "n": 1}, resource_id="report-3", user_id="alice", expires_at=now+3600)
assert "ap-restart" in {p["approval_id"] for p in s.pending()}
s.conn.close()
s2 = Store.reopen(DB)
pending = s2.pending()
assert {"approval_id": "ap-restart", "state": "pending"} in pending
applied = s2.approve_and_apply("ap-restart", now=now)
assert applied["status"] == "applied" and s2.execution_count("ap-restart") == 1

# Param binding: a mutated param dict does not match the stored digest
s2.prepare("ap-bind", tool="publish_report", params={"target": "report-3", "channel": "ops"}, resource_id="report-3", user_id="alice", expires_at=now+3600)
mismatch = None
try:
    s2.approve_and_apply("ap-bind", params={"target": "report-3", "channel": "public"})
except ApprovalError as e:
    mismatch = e.reason
assert mismatch == "param_binding_mismatch"
assert s2.execution_count("ap-bind") == 0

results = {
    "lesson": 180,
    "id": "l-human",
    "is_live_pager_or_slack_approval": False,
    "binding": {
        "tool": a["tool"],
        "param_digest": a["param_digest"],
        "resource_id": a["resource_id"],
        "resource_version": a["resource_version"],
    },
    "duplicate_approve_resubmitted": False,
    "duplicate_execution_count": s2.execution_count("ap-ok"),
    "resource_version_drift": drift,
    "permission_revoked": revoked,
    "rejected_does_not_execute": rej,
    "expired_does_not_execute": exp,
    "pending_survived_reopen": True,
    "restart_then_applied": applied["status"],
    "param_binding_mismatch": mismatch,
    "verified_on_this_machine": [
        "approval_binds_tool_param_digest_resource_version",
        "version_drift_and_revoke_invalidate_old_approval",
        "pending_rows_survive_sqlite_reopen",
        "duplicate_approve_does_not_resubmit",
        "reject_and_expiry_do_not_execute",
    ],
    "not_verified_on_this_machine": ["out_of_band_Slack_or_email_approval_channel", "multi_region_leader_election"],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({k: results[k] for k in ["duplicate_execution_count","resource_version_drift","permission_revoked","rejected_does_not_execute","expired_does_not_execute","restart_then_applied"]}, indent=2))
print("ALL_CHECKS_PASSED")
