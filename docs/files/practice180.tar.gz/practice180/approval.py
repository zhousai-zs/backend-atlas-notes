"""Human-in-the-loop approvals: bind tool + param digest + resource + version.

prepare() stages a side effect and records a pending approval.
apply() executes only when the stored binding still matches the live resource
version and the caller still has permission. Reject, expiry, revoke, or a
resource-version drift all refuse to execute. Duplicate approve is idempotent
and does not resubmit. Pending rows live in SQLite so a process restart can
resume the same request.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE resources(
  resource_id TEXT PRIMARY KEY,
  version INTEGER NOT NULL,
  body TEXT NOT NULL
);
CREATE TABLE approvals(
  approval_id TEXT PRIMARY KEY,
  tool TEXT NOT NULL,
  param_digest TEXT NOT NULL,
  params_json TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  resource_version INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  state TEXT NOT NULL,          -- pending|approved|rejected|expired|applied|invalid
  created REAL,
  expires_at REAL,
  applied_request_id TEXT
);
CREATE TABLE executions(
  request_id TEXT PRIMARY KEY,
  approval_id TEXT NOT NULL,
  at REAL,
  result TEXT
);
CREATE TABLE acl(
  user_id TEXT PRIMARY KEY,
  perm TEXT NOT NULL            -- granted | revoked
);
"""


def param_digest(params: dict) -> str:
    blob = json.dumps(params, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode()).hexdigest()


class ApprovalError(Exception):
    def __init__(self, reason, approval_id=None):
        super().__init__(reason)
        self.reason = reason
        self.approval_id = approval_id


class Store:
    def __init__(self, path: Path, *, reset=True):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        if reset and path.exists():
            path.unlink()
        self.conn = sqlite3.connect(path)
        if reset:
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    @classmethod
    def reopen(cls, path: Path):
        """Process restart: open the same file, keep rows."""
        obj = cls.__new__(cls)
        obj.path = path
        obj.conn = sqlite3.connect(path)
        return obj

    def set_perm(self, user_id, perm):
        self.conn.execute("INSERT OR REPLACE INTO acl VALUES(?,?)", (user_id, perm))
        self.conn.commit()

    def put_resource(self, resource_id, version, body):
        self.conn.execute(
            "INSERT OR REPLACE INTO resources VALUES(?,?,?)",
            (resource_id, version, body),
        )
        self.conn.commit()

    def bump_resource(self, resource_id, body):
        row = self.conn.execute("SELECT version FROM resources WHERE resource_id=?", (resource_id,)).fetchone()
        self.put_resource(resource_id, row[0] + 1, body)
        return row[0] + 1

    def _approval(self, approval_id):
        cols = ["approval_id","tool","param_digest","params_json","resource_id","resource_version","user_id","state","created","expires_at","applied_request_id"]
        row = self.conn.execute("SELECT * FROM approvals WHERE approval_id=?", (approval_id,)).fetchone()
        if not row:
            raise ApprovalError("unknown_approval", approval_id)
        return dict(zip(cols, row))

    def prepare(self, approval_id, *, tool, params, resource_id, user_id, expires_at):
        perm = self.conn.execute("SELECT perm FROM acl WHERE user_id=?", (user_id,)).fetchone()
        if not perm or perm[0] != "granted":
            raise ApprovalError("permission_denied", approval_id)
        res = self.conn.execute("SELECT version FROM resources WHERE resource_id=?", (resource_id,)).fetchone()
        if not res:
            raise ApprovalError("unknown_resource", approval_id)
        digest = param_digest(params)
        self.conn.execute(
            "INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?,?,?,NULL)",
            (approval_id, tool, digest, json.dumps(params, sort_keys=True), resource_id, res[0], user_id, "pending", time.time(), expires_at),
        )
        self.conn.commit()
        return self._approval(approval_id)

    def reject(self, approval_id):
        a = self._approval(approval_id)
        if a["state"] == "applied":
            raise ApprovalError("already_applied", approval_id)
        self.conn.execute("UPDATE approvals SET state='rejected' WHERE approval_id=?", (approval_id,))
        self.conn.commit()
        return self._approval(approval_id)

    def approve_and_apply(self, approval_id, *, now=None, params=None):
        """Human approve + apply in one step. Duplicate calls do not resubmit."""
        now = time.time() if now is None else now
        a = self._approval(approval_id)
        if a["state"] == "applied":
            return {"status": "already_applied", "request_id": a["applied_request_id"], "resubmitted": False}
        if a["state"] == "rejected":
            raise ApprovalError("rejected", approval_id)
        if a["expires_at"] <= now:
            self.conn.execute("UPDATE approvals SET state='expired' WHERE approval_id=?", (approval_id,))
            self.conn.commit()
            raise ApprovalError("expired", approval_id)
        perm = self.conn.execute("SELECT perm FROM acl WHERE user_id=?", (a["user_id"],)).fetchone()
        if not perm or perm[0] != "granted":
            self.conn.execute("UPDATE approvals SET state='invalid' WHERE approval_id=?", (approval_id,))
            self.conn.commit()
            raise ApprovalError("permission_revoked", approval_id)
        res = self.conn.execute("SELECT version, body FROM resources WHERE resource_id=?", (a["resource_id"],)).fetchone()
        if not res or res[0] != a["resource_version"]:
            self.conn.execute("UPDATE approvals SET state='invalid' WHERE approval_id=?", (approval_id,))
            self.conn.commit()
            raise ApprovalError("resource_version_drift", approval_id)
        if params is not None and param_digest(params) != a["param_digest"]:
            raise ApprovalError("param_binding_mismatch", approval_id)
        # Apply exactly once.
        request_id = f"exec-{approval_id}"
        self.conn.execute("INSERT INTO executions VALUES(?,?,?,?)", (request_id, approval_id, now, "applied"))
        self.conn.execute(
            "UPDATE approvals SET state='applied', applied_request_id=? WHERE approval_id=?",
            (request_id, approval_id),
        )
        self.conn.commit()
        return {"status": "applied", "request_id": request_id, "resubmitted": False}

    def execution_count(self, approval_id) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM executions WHERE approval_id=?", (approval_id,)).fetchone()[0]

    def pending(self):
        rows = self.conn.execute("SELECT approval_id, state FROM approvals WHERE state='pending'").fetchall()
        return [{"approval_id": r[0], "state": r[1]} for r in rows]
