#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
b=r["binding"]
assert b["tool"]=="publish_report" and b["param_digest"] and b["resource_version"]==1
assert r["duplicate_approve_resubmitted"] is False and r["duplicate_execution_count"]==1
assert r["resource_version_drift"]=="resource_version_drift"
assert r["permission_revoked"]=="permission_revoked"
assert r["rejected_does_not_execute"]=="rejected"
assert r["expired_does_not_execute"]=="expired"
assert r["pending_survived_reopen"] and r["restart_then_applied"]=="applied"
assert r["param_binding_mismatch"]=="param_binding_mismatch"
print("POSTCHECK_OK")
PY
