#pragma once
#include <map>
#include <string>
namespace kvutil {
// 解析 "k=v;k2=v2" 形式的配置串
std::map<std::string, std::string> parse(const std::string& s);
}
