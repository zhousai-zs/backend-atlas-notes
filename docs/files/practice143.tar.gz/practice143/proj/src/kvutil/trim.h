#pragma once
// 库内部头文件：不对外暴露
#include <string>
namespace kvutil { namespace detail {
inline std::string trim(const std::string& s) {
  auto b = s.find_first_not_of(" \t");
  if (b == std::string::npos) return "";
  auto e = s.find_last_not_of(" \t");
  return s.substr(b, e - b + 1);
}
}}
