#!/usr/bin/env bash
# 第143课实践：CMake 目标式构建。运行：bash test.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
export PATH="/workspace/atlas/cmvenv/bin:$PATH"
export CXX="$HERE/tools/zig-c++" CC="$HERE/tools/zig-cc"
chmod +x "$HERE/tools/"*
LOG="$HERE/run.log"; : > "$LOG"
say(){ echo "$@" | tee -a "$LOG"; }
run(){ "$@" 2>&1 | tee -a "$LOG"; return ${PIPESTATUS[0]}; }
FAIL=0; check(){ if eval "$2"; then say "CHECK OK: $1"; else say "CHECK FAIL: $1"; FAIL=1; fi; }
WORK=$(mktemp -d); cp -r "$HERE/proj" "$WORK/src"; cd "$WORK"
say "### 0. 工具版本"; run cmake --version | head -1; run ninja --version; say "CXX=zig c++ (clang) $(python -m ziglang version)"

say; say "### 1. out-of-source 配置与构建（干净目录 build/）"
run cmake -S src -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug >/dev/null; check "configure" "[ -f build/build.ninja ]"
run cmake --build build; check "build" "[ -x build/server ] && [ -x build/kvutil_test ]"
check "源码树未被污染" "[ ! -e src/CMakeCache.txt ] && [ ! -e src/CMakeFiles ]"
run ./build/server
run ./build/server "timeout_ms=300;retry=2"
say; say "### 2. 测试 target"
run ctest --test-dir build --output-on-failure | grep -E 'tests passed|Test #'
check "ctest 通过" "ctest --test-dir build >/dev/null 2>&1"

say; say "### 3. compile_commands.json"
check "生成 compile_commands.json" "[ -f build/compile_commands.json ]"
python3 - "$WORK" <<'EOF' | tee -a "$LOG"
import json,sys,os
w=sys.argv[1]; cc=json.load(open(os.path.join(w,'build/compile_commands.json')))
print("条目数=",len(cc))
for e in cc:
    f=os.path.relpath(e['file'],os.path.join(w,'src')); c=e['command']
    inc=[t.replace(os.path.join(w,'src'),'<src>') for t in c.split() if t.startswith('-I') or t.startswith('-isystem')]
    flags=[t for t in c.split() if t.startswith('-D') or t in('-Wall','-Wextra')]
    print(f"{f}: includes={inc} flags={flags}")
EOF
check "server 自动拿到 PUBLIC 头路径" "grep -A3 -F 'src/server/main.cpp' build/compile_commands.json | grep -q '/include' || python3 -c \"import json;cc=json.load(open('build/compile_commands.json'));import sys;sys.exit(0 if any('main.cpp' in e['file'] and '/src/include' in e['command'] for e in cc) else 1)\""
check "server 拿不到 PRIVATE 内部头路径与宏" "python3 -c \"import json,sys;cc=json.load(open('build/compile_commands.json'));e=[x for x in cc if x['file'].endswith('main.cpp')][0];sys.exit(1 if ('src/kvutil' in e['command'] or 'KVUTIL_INTERNAL' in e['command']) else 0)\""

say; say "### 4. 反例：把 include 改成 PRIVATE，消费者编译失败"
cp -r src src_bad
sed -i 's|PUBLIC  \${CMAKE_CURRENT_SOURCE_DIR}/include|PRIVATE \${CMAKE_CURRENT_SOURCE_DIR}/include|' src_bad/CMakeLists.txt
grep -n 'PRIVATE .*include' src_bad/CMakeLists.txt | tee -a "$LOG"
cmake -S src_bad -B build_bad -G Ninja >/dev/null 2>&1
cmake --build build_bad > bad.log 2>&1; BAD=$?
grep -m1 -E "fatal error|file not found" bad.log | sed "s|$WORK|<work>|g" | tee -a "$LOG"
say "build_bad exit=$BAD"
check "PRIVATE 时 server 编译失败" "[ $BAD -ne 0 ]"

say; say "### 5. 反例：消费者 include 内部头"
cp -r src src_leak
sed -i 's|#include "kvutil/kv.h"|#include "kvutil/kv.h"\n#include "trim.h"|' src_leak/src/server/main.cpp
cmake -S src_leak -B build_leak -G Ninja >/dev/null 2>&1
cmake --build build_leak > leak.log 2>&1; LEAK=$?
grep -m1 -E "fatal error|file not found" leak.log | sed "s|$WORK|<work>|g" | tee -a "$LOG"
say "build_leak exit=$LEAK"
check "内部头不会泄漏给消费者" "[ $LEAK -ne 0 ]"

say; say "### 6. 生成目录不入库"
cd src && git init -q && git add -A && git -c user.name=a -c user.email=a@b commit -qm init && cd ..
cp -r build src/build
say "git status --porcelain (build/ 放进源码树后)：[$(cd src && git status --porcelain)]"
check ".gitignore 忽略 build/" "[ -z \"\$(cd src && git status --porcelain)\" ]"
say "tracked files=$(cd src && git ls-files | wc -l)"
rm -rf src/build

say; say "### 7. 增量构建：只改服务源文件"
echo '// touch' >> src/src/server/main.cpp
cmake --build build -- -d explain 2>&1 | grep -cE '^\[[0-9]+/[0-9]+\]' | sed 's/^/rebuilt steps=/' | tee -a "$LOG"

python3 -c "import json;json.dump({'lesson':143,'id':'j-cmake','failed':$FAIL},open('$HERE/results.json','w'))"
rm -rf "$WORK"
if [ $FAIL -eq 0 ]; then say "ALL_CHECKS_PASSED"; else say "SOME_CHECKS_FAILED"; exit 1; fi
