#include "msgparse/assembler.h"

namespace msgparse {

int FakeSource::read(char* dest, int max_n) {
  if (fault_) {
    return -1;
  }
  if (max_n <= 0) {
    return 0;
  }
  const size_t left = data_.size() - pos_;
  if (left == 0) {
    return 0;
  }
  int n = max_n;
  if (n > max_chunk_) {
    n = max_chunk_;
  }
  if (static_cast<size_t>(n) > left) {
    n = static_cast<int>(left);
  }
  data_.copy(dest, static_cast<size_t>(n), pos_);
  pos_ += static_cast<size_t>(n);
  return n;
}

StreamAssembler::StreamAssembler(ByteSource& src, Clock& clock, int64_t timeout_ms)
    : src_(src), clock_(clock), timeout_ms_(timeout_ms) {}

AssembleResult StreamAssembler::poll() {
  char tmp[kReadChunk];
  const int n = src_.read(tmp, kReadChunk);
  if (n < 0) {
    return {AssembleStatus::kSourceError, {}};
  }
  if (n > 0) {
    buf_.append(tmp, static_cast<size_t>(n));
  }

  const ParseResult parsed = parse_frames(buf_);
  if (parsed.status == Status::kTooLarge) {
    return {AssembleStatus::kTooLarge, {}};
  }
  if (!parsed.messages.empty()) {
    std::string msg = parsed.messages.front();
    buf_.clear();
    for (size_t i = 1; i < parsed.messages.size(); ++i) {
      buf_ += encode_frame(parsed.messages[i]);
    }
    buf_ += parsed.leftover;
    incomplete_since_ms_ = buf_.empty() ? -1 : clock_.now_ms();
    return {AssembleStatus::kGotMessage, std::move(msg)};
  }
  if (buf_.empty()) {
    incomplete_since_ms_ = -1;
    return {AssembleStatus::kNeedMore, {}};
  }
  if (incomplete_since_ms_ < 0) {
    incomplete_since_ms_ = clock_.now_ms();
  }
  if (clock_.now_ms() - incomplete_since_ms_ >= timeout_ms_) {
    return {AssembleStatus::kTimeout, {}};
  }
  return {AssembleStatus::kNeedMore, {}};
}

}  // namespace msgparse
