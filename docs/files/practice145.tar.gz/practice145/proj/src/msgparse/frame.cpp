#include "msgparse/frame.h"

#include <stdexcept>

namespace msgparse {

std::string encode_frame(std::string_view payload) {
  if (payload.size() > kMaxPayload) {
    throw std::invalid_argument("payload exceeds kMaxPayload");
  }
  const auto len = static_cast<uint16_t>(payload.size());
  std::string out;
  out.reserve(2 + payload.size());
  out.push_back(static_cast<char>((len >> 8) & 0xff));
  out.push_back(static_cast<char>(len & 0xff));
  out.append(payload.data(), payload.size());
  return out;
}

ParseResult parse_frames(std::string_view buf) {
  ParseResult result;
  size_t pos = 0;
  while (pos < buf.size()) {
    const size_t remain = buf.size() - pos;
    if (remain < 2) {
      result.leftover.assign(buf.substr(pos));
      return result;
    }
    const auto len = static_cast<uint16_t>(
        (static_cast<unsigned char>(buf[pos]) << 8) |
        static_cast<unsigned char>(buf[pos + 1]));
    // 边界缺陷（MSGPARSE_BUGGY）：把恰好等于上限的合法包也判成超大。
#ifdef MSGPARSE_BUGGY
    if (len >= kMaxPayload) {
#else
    if (len > kMaxPayload) {
#endif
      result.status = Status::kTooLarge;
      result.leftover.assign(buf.substr(pos));
      return result;
    }
    if (remain < static_cast<size_t>(2) + len) {
      result.leftover.assign(buf.substr(pos));
      return result;
    }
    result.messages.emplace_back(buf.substr(pos + 2, len));
    pos += static_cast<size_t>(2) + len;
  }
  return result;
}

}  // namespace msgparse
