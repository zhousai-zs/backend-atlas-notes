#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace msgparse {

// 教学假设：公众号后台内部用的长度前缀帧，不是真实微信协议。
// 帧格式：2 字节大端 payload 长度（不包含头本身）+ payload。
// 空包（len=0，只有两字节 0x00 0x00）合法，得到空字符串消息。
// 最大 payload 为 kMaxPayload 字节，恰好等于该值是合法的。
inline constexpr uint16_t kMaxPayload = 1024;

enum class Status {
  kOk,       // 解析到 0 个或多个完整帧；截断部分放进 leftover
  kTooLarge  // 长度字段超过 kMaxPayload；已解析的完整帧仍会交付
};

struct ParseResult {
  Status status = Status::kOk;
  std::vector<std::string> messages;
  std::string leftover;
};

// 从缓冲区解析尽可能多的完整帧。截断包不算错误，而是留在 leftover 里等后续字节。
ParseResult parse_frames(std::string_view buf);

// 编码一帧。payload.size() 不得超过 kMaxPayload。
std::string encode_frame(std::string_view payload);

}  // namespace msgparse
