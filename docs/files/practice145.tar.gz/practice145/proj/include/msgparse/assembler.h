#pragma once

#include "msgparse/frame.h"

#include <cstdint>
#include <string>
#include <string_view>

namespace msgparse {

// 时间与字节源都是抽象依赖，测试用 Fake 注入，生产环境再接到真实时钟和套接字。
class Clock {
 public:
  virtual ~Clock() = default;
  virtual int64_t now_ms() const = 0;
};

class ByteSource {
 public:
  virtual ~ByteSource() = default;
  // 返回读到的字节数；0 表示暂时无数据；-1 表示故障。
  virtual int read(char* dest, int max_n) = 0;
};

enum class AssembleStatus {
  kGotMessage,
  kNeedMore,
  kTimeout,
  kTooLarge,
  kSourceError,
};

struct AssembleResult {
  AssembleStatus status = AssembleStatus::kNeedMore;
  std::string message;
};

// 单次 poll 最多从源读 kReadChunk 字节，并至多交出一条完整消息。
// 不完整帧从首次出现起超过 timeout_ms 则报超时。
inline constexpr int kReadChunk = 256;

class StreamAssembler {
 public:
  StreamAssembler(ByteSource& src, Clock& clock, int64_t timeout_ms);
  AssembleResult poll();

 private:
  ByteSource& src_;
  Clock& clock_;
  int64_t timeout_ms_;
  std::string buf_;
  int64_t incomplete_since_ms_ = -1;
};

// 可编程时钟：测试里直接拨时间，不必真实 sleep。
class FakeClock : public Clock {
 public:
  explicit FakeClock(int64_t t = 0) : t_(t) {}
  void advance(int64_t d) { t_ += d; }
  int64_t now_ms() const override { return t_; }

 private:
  int64_t t_;
};

// 内存字节源：可追加数据、注入故障、限制单次短读。
class FakeSource : public ByteSource {
 public:
  void append(std::string_view bytes) { data_.append(bytes.data(), bytes.size()); }
  void set_fault(bool v = true) { fault_ = v; }
  void set_max_chunk(int n) { max_chunk_ = n; }
  int read(char* dest, int max_n) override;

 private:
  std::string data_;
  size_t pos_ = 0;
  bool fault_ = false;
  int max_chunk_ = 1 << 20;
};

}  // namespace msgparse
