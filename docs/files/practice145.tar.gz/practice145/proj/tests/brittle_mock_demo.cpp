// 反例：按「每次先 read(2) 再 read(payload)」来规定交互，绑死了实现细节。
// StreamAssembler 实际每次最多 read(kReadChunk)，这个 mock 会失败；
// 同样输入交给 FakeSource，观察行为的测试却能通过。
#include "msgparse/assembler.h"
#include "msgparse/frame.h"

#include <gtest/gtest.h>

#include <algorithm>
#include <string>
#include <vector>

using msgparse::AssembleStatus;
using msgparse::ByteSource;
using msgparse::encode_frame;
using msgparse::FakeClock;
using msgparse::FakeSource;
using msgparse::kReadChunk;
using msgparse::StreamAssembler;

class ScriptedMockSource : public ByteSource {
 public:
  struct Step {
    int expect_n;
    std::string data;
  };

  void Expect(int n, std::string data) { steps_.push_back({n, std::move(data)}); }

  int read(char* dest, int max_n) override {
    if (index_ >= steps_.size()) {
      error_ = "unexpected extra read";
      return -1;
    }
    const Step& step = steps_[index_];
    if (max_n != step.expect_n) {
      error_ = "read size mismatch: got " + std::to_string(max_n) +
               " want " + std::to_string(step.expect_n);
      return -1;
    }
    if (step.data.size() > static_cast<size_t>(max_n)) {
      error_ = "scripted data larger than expect_n";
      return -1;
    }
    std::copy(step.data.begin(), step.data.end(), dest);
    ++index_;
    return static_cast<int>(step.data.size());
  }

  const std::string& error() const { return error_; }

 private:
  std::vector<Step> steps_;
  size_t index_ = 0;
  std::string error_;
};

TEST(BrittleMock, ExpectsHeaderThenPayloadReads) {
  const auto frame = encode_frame("hello");  // 2 字节头 + 5 字节负载
  ScriptedMockSource mock;
  mock.Expect(2, frame.substr(0, 2));
  mock.Expect(5, frame.substr(2));
  FakeClock clock;
  StreamAssembler assembler(mock, clock, 200);
  const auto r = assembler.poll();
  // 实现一次 read(kReadChunk)，与 mock 的分步期望冲突。
  EXPECT_EQ(r.status, AssembleStatus::kGotMessage);
  EXPECT_EQ(r.message, "hello");
  EXPECT_TRUE(mock.error().empty()) << mock.error();
}

TEST(FakeSource, SameBytesAreAssembled) {
  const auto frame = encode_frame("hello");
  FakeSource src;
  src.append(frame);
  FakeClock clock;
  StreamAssembler assembler(src, clock, 200);
  const auto r = assembler.poll();
  ASSERT_EQ(r.status, AssembleStatus::kGotMessage);
  EXPECT_EQ(r.message, "hello");
  (void)kReadChunk;
}
