#include "msgparse/assembler.h"
#include "msgparse/frame.h"

#include <gtest/gtest.h>

using msgparse::AssembleStatus;
using msgparse::encode_frame;
using msgparse::FakeClock;
using msgparse::FakeSource;
using msgparse::kMaxPayload;
using msgparse::StreamAssembler;

class AssemblerTest : public testing::Test {
 protected:
  FakeSource src_;
  FakeClock clock_{1000};
  StreamAssembler assembler_{src_, clock_, /*timeout_ms=*/200};
};

TEST_F(AssemblerTest, EmptyPacketFromStream) {
  src_.append(encode_frame(""));
  const auto r = assembler_.poll();
  ASSERT_EQ(r.status, AssembleStatus::kGotMessage);
  EXPECT_TRUE(r.message.empty());
}

TEST_F(AssemblerTest, TruncatedWaitsThenTimesOut) {
  // 只有不完整的头，时间不拨动时应继续等；拨过超时后才报 timeout。
  src_.append(std::string("\x00", 1));
  auto r = assembler_.poll();
  EXPECT_EQ(r.status, AssembleStatus::kNeedMore);
  clock_.advance(199);
  r = assembler_.poll();
  EXPECT_EQ(r.status, AssembleStatus::kNeedMore);
  clock_.advance(1);
  r = assembler_.poll();
  EXPECT_EQ(r.status, AssembleStatus::kTimeout);
}

TEST_F(AssemblerTest, CompletesAfterSecondChunk) {
  const auto frame = encode_frame("hello");
  src_.append(frame.substr(0, 3));  // 截断
  EXPECT_EQ(assembler_.poll().status, AssembleStatus::kNeedMore);
  src_.append(frame.substr(3));
  const auto r = assembler_.poll();
  ASSERT_EQ(r.status, AssembleStatus::kGotMessage);
  EXPECT_EQ(r.message, "hello");
}

TEST_F(AssemblerTest, ConsecutiveDeliveredOneByOne) {
  src_.append(encode_frame("a") + encode_frame("b") + encode_frame("c"));
  EXPECT_EQ(assembler_.poll().message, "a");
  // 余下的完整帧已经在缓冲里，不必再往源里写数据。
  EXPECT_EQ(assembler_.poll().message, "b");
  EXPECT_EQ(assembler_.poll().message, "c");
  EXPECT_EQ(assembler_.poll().status, AssembleStatus::kNeedMore);
}

TEST_F(AssemblerTest, SourceFaultIsObservable) {
  src_.set_fault(true);
  const auto r = assembler_.poll();
  EXPECT_EQ(r.status, AssembleStatus::kSourceError);
}

TEST_F(AssemblerTest, OversizedFromStream) {
  std::string buf;
  const uint16_t len = static_cast<uint16_t>(kMaxPayload + 1);
  buf.push_back(static_cast<char>((len >> 8) & 0xff));
  buf.push_back(static_cast<char>(len & 0xff));
  src_.append(buf);
  EXPECT_EQ(assembler_.poll().status, AssembleStatus::kTooLarge);
}

TEST_F(AssemblerTest, ShortReadsStillAssemble) {
  src_.set_max_chunk(1);  // 每次只吐 1 字节，模拟网络短读
  src_.append(encode_frame("ok"));
  AssembleStatus st = AssembleStatus::kNeedMore;
  std::string msg;
  for (int i = 0; i < 16 && st == AssembleStatus::kNeedMore; ++i) {
    const auto r = assembler_.poll();
    st = r.status;
    msg = r.message;
  }
  ASSERT_EQ(st, AssembleStatus::kGotMessage);
  EXPECT_EQ(msg, "ok");
}
