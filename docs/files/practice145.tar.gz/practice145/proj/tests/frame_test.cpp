#include "msgparse/frame.h"

#include <gtest/gtest.h>

#include <string>

using msgparse::encode_frame;
using msgparse::kMaxPayload;
using msgparse::parse_frames;
using msgparse::Status;

// 每个 TEST_F 都在新的 fixture 对象上跑：SetUp 里准备的是本测试自己的缓冲，
// 一个测试往 members 里写东西，不会被下一个测试看到。
class FrameTest : public testing::Test {
 protected:
  void SetUp() override { buf_.clear(); scratch_ = 0; }

  std::string buf_;
  int scratch_ = 0;
};

TEST_F(FrameTest, EmptyBufferYieldsNoMessage) {
  const auto r = parse_frames("");
  EXPECT_EQ(r.status, Status::kOk);
  EXPECT_TRUE(r.messages.empty());
  EXPECT_TRUE(r.leftover.empty());
}

TEST_F(FrameTest, EmptyPacketAccepted) {
  const auto r = parse_frames(encode_frame(""));
  ASSERT_EQ(r.status, Status::kOk);
  ASSERT_EQ(r.messages.size(), 1u);
  EXPECT_TRUE(r.messages[0].empty());
  EXPECT_TRUE(r.leftover.empty());
}

TEST_F(FrameTest, TruncatedHeaderStaysInLeftover) {
  buf_.assign("\x00", 1);  // 只有长度字段的第一个字节
  const auto r = parse_frames(buf_);
  EXPECT_EQ(r.status, Status::kOk);
  EXPECT_TRUE(r.messages.empty());
  ASSERT_EQ(r.leftover.size(), 1u);
  EXPECT_EQ(static_cast<unsigned char>(r.leftover[0]), 0u);
}

TEST_F(FrameTest, TruncatedPayloadStaysInLeftover) {
  // 声明 5 字节 payload，只给 4 字节，整帧都算截断。
  buf_.push_back('\x00');
  buf_.push_back('\x05');
  buf_.append("abcd");
  const auto r = parse_frames(buf_);
  EXPECT_EQ(r.status, Status::kOk);
  EXPECT_TRUE(r.messages.empty());
  EXPECT_EQ(r.leftover, buf_);
}

TEST_F(FrameTest, OneByteShortOfCompleteFrame) {
  const std::string payload(8, 'x');
  auto frame = encode_frame(payload);
  frame.pop_back();
  const auto r = parse_frames(frame);
  EXPECT_EQ(r.status, Status::kOk);
  EXPECT_TRUE(r.messages.empty());
  EXPECT_EQ(r.leftover, frame);
}

TEST_F(FrameTest, OversizedRejected) {
  // 1025 超过上限，应直接报太长，不能当截断包留下。
  std::string buf;
  const uint16_t len = static_cast<uint16_t>(kMaxPayload + 1);
  buf.push_back(static_cast<char>((len >> 8) & 0xff));
  buf.push_back(static_cast<char>(len & 0xff));
  const auto r = parse_frames(buf);
  EXPECT_EQ(r.status, Status::kTooLarge);
  EXPECT_TRUE(r.messages.empty());
  EXPECT_EQ(r.leftover, buf);
}

TEST_F(FrameTest, ExactMaxPayloadAccepted) {
  // 恰好 1024 字节是合法边界；带 MSGPARSE_BUGGY 的实现会把 >= 写成拒绝条件，
  // 本测试应当失败，从而发现这处人为注入的边界缺陷。
  const std::string payload(kMaxPayload, 'A');
  const auto r = parse_frames(encode_frame(payload));
  ASSERT_EQ(r.status, Status::kOk) << "payload of exactly kMaxPayload must be accepted";
  ASSERT_EQ(r.messages.size(), 1u);
  EXPECT_EQ(r.messages[0].size(), static_cast<size_t>(kMaxPayload));
  EXPECT_EQ(r.messages[0], payload);
  EXPECT_TRUE(r.leftover.empty());
}

TEST_F(FrameTest, ConsecutiveTwoPackets) {
  buf_ = encode_frame("hi") + encode_frame("ok");
  const auto r = parse_frames(buf_);
  ASSERT_EQ(r.status, Status::kOk);
  ASSERT_EQ(r.messages.size(), 2u);
  EXPECT_EQ(r.messages[0], "hi");
  EXPECT_EQ(r.messages[1], "ok");
  EXPECT_TRUE(r.leftover.empty());
}

TEST_F(FrameTest, ConsecutiveThenTruncated) {
  buf_ = encode_frame("one") + encode_frame("two") + std::string("\x00\x08xxxx", 6);
  const auto r = parse_frames(buf_);
  ASSERT_EQ(r.status, Status::kOk);
  ASSERT_EQ(r.messages.size(), 2u);
  EXPECT_EQ(r.messages[0], "one");
  EXPECT_EQ(r.messages[1], "two");
  EXPECT_EQ(r.leftover.size(), 6u);
}

TEST_F(FrameTest, FixtureMutationDoesNotLeak) {
  // 若框架复用同一个 fixture 对象，后面依赖干净 scratch_ 的测试就会被污染。
  scratch_ = 42;
  buf_ = "dirty";
  SUCCEED();
}

TEST_F(FrameTest, FixtureStartsFresh) {
  EXPECT_EQ(scratch_, 0);
  EXPECT_TRUE(buf_.empty());
}

TEST(EquivalenceHints, SingleNonEmptyPacket) {
  const auto r = parse_frames(encode_frame("cfg"));
  ASSERT_EQ(r.status, Status::kOk);
  ASSERT_EQ(r.messages.size(), 1u);
  EXPECT_EQ(r.messages[0], "cfg");
}
