// 反例：把解析残留放进进程级静态变量，把一帧拆到两个测试里“接力”。
// 默认按注册顺序（先头后负载）能通过；一旦 CompleteWithPayload 先跑就会失败。
#include "msgparse/frame.h"

#include <gtest/gtest.h>

using msgparse::parse_frames;

static std::string g_buf;

TEST(OrderTrap, FeedTruncatedHeader) {
  // 只放入长度为 5 的头，不放 payload。
  g_buf.push_back('\x00');
  g_buf.push_back('\x05');
  const auto r = parse_frames(g_buf);
  EXPECT_TRUE(r.messages.empty());
  EXPECT_EQ(r.leftover.size(), 2u);
  g_buf = r.leftover;
}

TEST(OrderTrap, CompleteWithPayload) {
  g_buf.append("hello");
  const auto r = parse_frames(g_buf);
  ASSERT_EQ(r.messages.size(), 1u) << "shared leftover makes this depend on test order";
  EXPECT_EQ(r.messages[0], "hello");
  g_buf = r.leftover;
}
