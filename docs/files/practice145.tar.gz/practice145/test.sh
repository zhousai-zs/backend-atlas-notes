#!/usr/bin/env bash
# 第145课实践：为消息解析器测试空包、截断包、超大长度和连续包。
# 运行：bash test.sh
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
export PATH="$HERE/tools:$PATH"
if [ -x /workspace/atlas/cmvenv/bin/cmake ]; then
  export PATH="/workspace/atlas/cmvenv/bin:$PATH"
fi

if command -v g++ >/dev/null 2>&1; then
  export CC="$(command -v gcc 2>/dev/null || command -v cc)"
  export CXX="$(command -v g++)"
  COMPILER_NOTE="system g++ ($CXX)"
elif command -v clang++ >/dev/null 2>&1; then
  export CC="$(command -v clang)"
  export CXX="$(command -v clang++)"
  COMPILER_NOTE="system clang++ ($CXX)"
else
  export CC="$HERE/tools/zig-c++"
  export CXX="$HERE/tools/zig-c++"
  chmod +x "$HERE/tools/"*
  COMPILER_NOTE="zig c++ (clang frontend) via $CXX"
fi

LOG="$HERE/run.log"; : > "$LOG"
say(){ echo "$@" | tee -a "$LOG"; }
run(){ "$@" 2>&1 | tee -a "$LOG"; return ${PIPESTATUS[0]}; }
FAIL=0
check(){ if eval "$2"; then say "CHECK OK: $1"; else say "CHECK FAIL: $1"; FAIL=1; fi; }

WORK=$(mktemp -d)
cp -a "$HERE/proj" "$WORK/src"
cd "$WORK/src"
ZIGCACHE="$WORK/zig-cache"
mkdir -p "$ZIGCACHE"
export ZIG_LOCAL_CACHE_DIR="$ZIGCACHE"
export ZIG_GLOBAL_CACHE_DIR="$ZIGCACHE"

CMAKE_BIN="$(command -v cmake)"
NINJA_BIN="$(command -v ninja || true)"
GEN_ARGS=()
if [ -n "$NINJA_BIN" ]; then
  GEN_ARGS=(-G Ninja)
fi

say "### 0. 工具版本"
run "$CMAKE_BIN" --version | head -2
if [ -n "$NINJA_BIN" ]; then
  say "ninja: $($NINJA_BIN --version)"
fi
say "compiler: $COMPILER_NOTE"
if [ -x "$CXX" ] || command -v "$CXX" >/dev/null 2>&1; then
  run "$CXX" --version 2>/dev/null | head -2 || true
fi
say "GoogleTest: vendored 1.16.0"

say
say "### 1. 带边界缺陷构建（MSGPARSE_BUGGY=ON）"
run "$CMAKE_BIN" -S . -B build_buggy "${GEN_ARGS[@]}" -DCMAKE_BUILD_TYPE=Debug -DMSGPARSE_BUGGY=ON
run "$CMAKE_BIN" --build build_buggy --target frame_test assembler_test
check "buggy 构建成功" "[ -x build_buggy/frame_test ]"

say
say "### 2. 有缺陷的解析器应被 ExactMaxPayloadAccepted 抓住"
set +e
./build_buggy/frame_test --gtest_color=no | tee "$WORK/buggy_frame.log" | tee -a "$LOG"
BUGGY_EC=${PIPESTATUS[0]}
set -u
say "buggy frame_test exit=$BUGGY_EC"
check "有缺陷版本测试未能全部通过" "[ $BUGGY_EC -ne 0 ]"
check "失败用例是 ExactMaxPayloadAccepted" "grep -q 'FrameTest.ExactMaxPayloadAccepted' \"$WORK/buggy_frame.log\" && grep -q 'FAILED' \"$WORK/buggy_frame.log\""
check "空包/截断/超大/连续包等其他用例在有缺陷版本上仍通过" "grep -q 'EmptyPacketAccepted' \"$WORK/buggy_frame.log\" && ! grep -E 'FAILED.*EmptyPacket|FAILED.*Truncated|FAILED.*Oversized|FAILED.*Consecutive' \"$WORK/buggy_frame.log\""

say
say "### 3. 修复后构建并跑完全部测试"
run "$CMAKE_BIN" -S . -B build_ok "${GEN_ARGS[@]}" -DCMAKE_BUILD_TYPE=Debug -DMSGPARSE_BUGGY=OFF
run "$CMAKE_BIN" --build build_ok --target frame_test assembler_test order_trap_demo brittle_mock_demo
check "修复后构建成功" "[ -x build_ok/frame_test ] && [ -x build_ok/assembler_test ]"

set +e
./build_ok/frame_test --gtest_color=no | tee "$WORK/ok_frame.log" | tee -a "$LOG"
FRAME_EC=${PIPESTATUS[0]}
./build_ok/assembler_test --gtest_color=no | tee "$WORK/ok_asm.log" | tee -a "$LOG"
ASM_EC=${PIPESTATUS[0]}
set -u
say "fixed frame_test exit=$FRAME_EC"
say "fixed assembler_test exit=$ASM_EC"
check "修复后 frame_test 全部通过" "[ $FRAME_EC -eq 0 ] && grep -q 'PASSED' \"$WORK/ok_frame.log\" && ! grep -q '\[  FAILED  \]' \"$WORK/ok_frame.log\""
check "修复后 assembler_test 全部通过" "[ $ASM_EC -eq 0 ] && grep -q 'PASSED' \"$WORK/ok_asm.log\""
check "frame_test 覆盖空包" "grep -q 'EmptyPacketAccepted' \"$WORK/ok_frame.log\""
check "frame_test 覆盖截断包" "grep -q 'TruncatedHeaderStaysInLeftover' \"$WORK/ok_frame.log\""
check "frame_test 覆盖超大长度" "grep -q 'OversizedRejected' \"$WORK/ok_frame.log\""
check "frame_test 覆盖连续包" "grep -q 'ConsecutiveTwoPackets' \"$WORK/ok_frame.log\""
check "恰好 1024 的边界用例现在通过" "grep -q 'ExactMaxPayloadAccepted' \"$WORK/ok_frame.log\" && ! grep -q 'FAILED' \"$WORK/ok_frame.log\""

say
say "### 4. 不依赖执行顺序：--gtest_shuffle 换种子仍通过"
set +e
./build_ok/frame_test --gtest_color=no --gtest_shuffle --gtest_random_seed=1 | tee "$WORK/shuffle1.log" | tee -a "$LOG"
S1=${PIPESTATUS[0]}
./build_ok/frame_test --gtest_color=no --gtest_shuffle --gtest_random_seed=2 | tee "$WORK/shuffle2.log" | tee -a "$LOG"
S2=${PIPESTATUS[0]}
./build_ok/assembler_test --gtest_color=no --gtest_shuffle --gtest_random_seed=7 | tee "$WORK/shuffle_asm.log" | tee -a "$LOG"
S3=${PIPESTATUS[0]}
set -u
say "shuffle seed1 exit=$S1 seed2 exit=$S2 assembler seed7 exit=$S3"
check "frame_test shuffle seed=1 通过" "[ $S1 -eq 0 ]"
check "frame_test shuffle seed=2 通过" "[ $S2 -eq 0 ]"
check "assembler_test shuffle seed=7 通过" "[ $S3 -eq 0 ]"
check "两次 shuffle 的用例顺序不同" "grep 'Running main\(\) from' -n \"$WORK/shuffle1.log\" >/dev/null; python3 - \"$WORK/shuffle1.log\" \"$WORK/shuffle2.log\" <<'PY'
import re,sys
def names(p):
    t=open(p).read()
    # [ RUN      ] Suite.Name
    return re.findall(r'\[ RUN      \] (\S+)', t)
a,b=names(sys.argv[1]),names(sys.argv[2])
print('seed1 order:', ' '.join(a))
print('seed2 order:', ' '.join(b))
print('same_order', a==b)
raise SystemExit(0 if a and b and a!=b else 1)
PY
"

say
say "### 5. 反例：静态残留使测试依赖顺序"
# GoogleTest 的 --gtest_filter 只筛选、不改顺序；默认按注册顺序（FeedTruncatedHeader 再 CompleteWithPayload）能通过。
set +e
./build_ok/order_trap_demo --gtest_color=no | tee "$WORK/trap_fwd.log" | tee -a "$LOG"
FWD=${PIPESTATUS[0]}
set -u
say "order_trap default order exit=$FWD"
check "默认注册顺序通过" "[ $FWD -eq 0 ]"

# 用 shuffle 找到 CompleteWithPayload 先跑的种子，此时共享残留会让用例失败。
FOUND=0
for seed in $(seq 1 80); do
  set +e
  ./build_ok/order_trap_demo --gtest_color=no --gtest_shuffle --gtest_random_seed=$seed > "$WORK/trap_sh.log" 2>&1
  SEC=${PIPESTATUS[0]}
  set -u
  python3 - "$WORK/trap_sh.log" "$SEC" <<'PY' > "$WORK/trap_sh.meta"
import re, sys
text = open(sys.argv[1]).read()
names = re.findall(r"\[ RUN      \] (\S+)", text)
ec = int(sys.argv[2])
second_first = bool(names) and names[0].endswith("CompleteWithPayload")
print("order", " ".join(names))
print("exit", ec)
print("second_first", second_first)
sys.exit(0 if second_first and ec != 0 else 1)
PY
  if [ $? -eq 0 ]; then
    FOUND=$seed
    cat "$WORK/trap_sh.log" | tee -a "$LOG"
    cat "$WORK/trap_sh.meta" | tee -a "$LOG"
    say "order_trap failing shuffle seed=$FOUND"
    break
  fi
done
check "找到 CompleteWithPayload 先跑且失败的 shuffle 种子" "[ $FOUND -ne 0 ]"

say
say "### 6. 反例：按 read 尺寸写死的 mock 绑到实现细节"
set +e
./build_ok/brittle_mock_demo --gtest_color=no | tee "$WORK/mock.log" | tee -a "$LOG"
MOCK_EC=${PIPESTATUS[0]}
set -u
say "brittle_mock_demo exit=$MOCK_EC"
check "观察行为的 FakeSource 用例通过" "grep -q '\[       OK \] FakeSource.SameBytesAreAssembled' \"$WORK/mock.log\""
check "规定 read(2)+read(payload) 的 mock 失败" "grep -q '\[  FAILED  \] BrittleMock.ExpectsHeaderThenPayloadReads' \"$WORK/mock.log\""
check "mock 失败原因是 read 尺寸不匹配" "grep -q 'read size mismatch' \"$WORK/mock.log\""

# 列出用例，便于课文引用
say
say "### 7. 用例清单"
run ./build_ok/frame_test --gtest_list_tests
run ./build_ok/assembler_test --gtest_list_tests

python3 -c "import json;json.dump({'lesson':145,'id':'j-unit','failed':$FAIL},open('$HERE/results.json','w'))"
rm -rf "$WORK"
if [ $FAIL -eq 0 ]; then say "ALL_CHECKS_PASSED"; else say "SOME_CHECKS_FAILED"; exit 1; fi
