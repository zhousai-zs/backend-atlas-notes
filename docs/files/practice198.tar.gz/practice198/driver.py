from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from slo import load_events, sli, incident_budget

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"
WINDOW = 30 * 24 * 3600
# Business basis: roadside query (lesson 197) may miss at most 0.1% of valid reads
# in a 30-day window, i.e. about 43 minutes. This is an internal SLO, not an SLA.
SLO = 0.999
P99_SLO_MS = 80  # page-query comfort bound, documented as product not "more nines"


def main() -> None:
    events = load_events(ROOT / "events.csv")
    honest = sli(events, include_failures_in_denominator=True, exclude_invalid=True)
    dishonest = sli(events, include_failures_in_denominator=False, exclude_invalid=True)
    # Incident window: 15 min starting 2026-10-29T08:00:00Z (day 12 08:00)
    def in_inc(e):
        ts = e["ts"]
        return "2026-10-29T08:00:00Z" <= ts < "2026-10-29T08:15:00Z"

    inc_events = [e for e in events if in_inc(e) and e["valid"]]
    budget = incident_budget(events, SLO, WINDOW, in_inc)
    # p99 of good baseline should meet SLO; include a check
    checks = [
        ("denominator_includes_failures", honest["total"] > honest["good"] and dishonest["success_ratio"] == 1.0, f"honest={honest} dishonest={dishonest}"),
        ("invalid_client_cancel_excluded", honest["total"] == sum(1 for e in events if e["valid"]), ""),
        ("success_slo_has_business_basis", SLO == 0.999, "roadside query: at most 0.1% of valid reads may fail in 30d"),
        ("p99_defined", honest["p99_ms"] is not None and honest["p99_ms"] <= P99_SLO_MS, f"p99={honest['p99_ms']} slo={P99_SLO_MS}"),
        ("incident_consumed_measurable_budget", budget["incident_failed_events"] > 0 and budget["fraction_of_budget"] is not None, str(budget)),
        ("sla_and_slo_are_distinct", True, "SLO is internal 99.9% over 30d; SLA would be a contractual payout and is not defined here"),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    report = {
        "slo": {"success": SLO, "p99_ms": P99_SLO_MS, "window_days": 30, "basis": "roadside query page: at most 0.1% of valid reads fail in 30 days; p99 80ms keeps the map useful"},
        "sla_note": "No customer SLA is defined in this practice. An SLA would be a legal/payout contract and must not be equated with the internal SLO.",
        "sli": honest,
        "dishonest_sli_if_failures_dropped": dishonest,
        "incident": budget,
        "incident_valid_events": len(inc_events),
    }
    (ROOT / "reports" / "slo.json").write_text(json.dumps(report, indent=2) + "\n")
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 198,
                "id": "n-slo",
                "is_live_model": False,
                "report": report,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "denominator_includes_failures": True,
                "not_verified_on_this_machine": [
                    "a production 30-day SLO dashboard or paging burn-rate policy",
                ],
                "verified_on_this_machine": [
                    "SLI computed as good/valid events over a 30-day teaching trace",
                    "dropping failures from the denominator yields a dishonest 100%",
                    "15-minute incident budget fraction computed against 99.9% / 30d",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")
    print("SLI", honest)
    print("BUDGET_FRACTION", budget["fraction_of_budget"], "BURN", budget["burn"])


if __name__ == "__main__":
    main()
