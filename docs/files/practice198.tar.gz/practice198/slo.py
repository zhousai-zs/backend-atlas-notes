from __future__ import annotations

import csv
from datetime import datetime


def load_events(path):
    rows = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            row["latency_ms"] = int(row["latency_ms"])
            row["valid"] = bool(int(row["valid"]))
            rows.append(row)
    return rows


def percentile(values, p):
    if not values:
        return None
    xs = sorted(values)
    if p <= 0:
        return xs[0]
    idx = min(len(xs) - 1, max(0, int(round((p / 100.0) * (len(xs) - 1)))))
    return xs[idx]


def sli(events, include_failures_in_denominator=True, exclude_invalid=True):
    ev = [e for e in events if e["valid"]] if exclude_invalid else list(events)
    if not include_failures_in_denominator:
        ev = [e for e in ev if e["status"] == "ok"]  # dishonest: denominator only successes
    good = sum(1 for e in ev if e["status"] == "ok")
    total = len(ev)
    lats = [e["latency_ms"] for e in ev if e["status"] == "ok"]
    return {
        "good": good,
        "total": total,
        "success_ratio": (good / total) if total else 0.0,
        "p99_ms": percentile(lats, 99),
        "p50_ms": percentile(lats, 50),
    }


def incident_budget(events, slo, window_seconds, incident_pred):
    ev = [e for e in events if e["valid"]]
    inc = [e for e in ev if incident_pred(e)]
    # Each valid event represents 60s of the teaching trace.
    seconds_per_event = window_seconds / len(events)
    # Error budget in events and in seconds for the 30-day window.
    budget_events = (1.0 - slo) * sum(1 for e in ev)
    consumed = sum(1 for e in inc if e["status"] != "ok")
    # Also count all failing valid events if needed? The practice asks for
    # "一次故障消耗的预算" — the 15-minute incident.
    budget_seconds = (1.0 - slo) * window_seconds
    incident_fail_seconds = consumed * seconds_per_event
    burn = (incident_fail_seconds / budget_seconds) if budget_seconds else None
    return {
        "budget_events": budget_events,
        "incident_failed_events": consumed,
        "budget_seconds": budget_seconds,
        "incident_fail_seconds": incident_fail_seconds,
        "fraction_of_budget": (consumed / budget_events) if budget_events else None,
        "burn_rate_comment": "fraction of a 30-day budget spent inside the 15-minute incident",
        "seconds_per_event": seconds_per_event,
        "burn": burn,
    }
