#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["denominator_includes_failures"]
assert r["report"]["dishonest_sli_if_failures_dropped"]["success_ratio"]==1.0
assert r["report"]["sli"]["success_ratio"]<1.0
assert "SLA" in r["report"]["sla_note"] or "sla" in r["report"]["sla_note"].lower()
assert r["failed"]==[]
print("POSTCHECK_OK")
PY
