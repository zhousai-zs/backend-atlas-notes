#!/usr/bin/env python3
"""Acceptance checks for the lesson 126 history / fault-injection experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    KEY_TITLE,
    LOCAL_S,
    QUORUM_S,
    TIMEOUT_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "VerificationEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_jepsen"] and r["not_knossos"] and r["not_elle"] and r["not_etcd"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["local_s"] == LOCAL_S == 0.05
    assert r["quorum_s"] == QUORUM_S == 0.10
    assert r["timeout_s"] == TIMEOUT_S == 0.20
    assert r["nodes"] == ["n1", "n2", "n3"]

    h = r["healthy"]
    assert h["counts"] == {"invoke": 4, "ok": 4, "fail": 0, "info": 0, "nemesis_info": 0}
    assert h["checker"]["valid"] is True
    assert h["checker"]["witness"]["final"] == TITLE_V3
    assert h["reads"][0]["value"] == TITLE_V2 and h["reads"][1]["value"] == TITLE_V3
    assert h["writes"][0]["latency"] == 0.10 and h["writes"][1]["t"] == 0.50
    assert h["t_end"] == 0.70
    assert h["checksum"] == "7e716acb17f550d2"

    s = r["stale"]
    assert s["writes"][0]["type"] == "ok" and s["writes"][0]["value"] == TITLE_V2
    assert s["writes"][1]["type"] == "ok" and s["writes"][1]["value"] == TITLE_V3
    assert s["writes"][1]["t"] == 0.30 and s["writes"][1]["applied_on"] == ["n1", "n2"]
    assert s["stale_read"]["type"] == "ok" and s["stale_read"]["value"] == TITLE_V2
    assert s["stale_read"]["reason"] == "local" and s["stale_read"]["node"] == "n3"
    assert s["stale_read"]["invoke_t"] == 0.35 and s["stale_read"]["t"] == 0.40
    assert s["checker"]["valid"] is False
    assert "can't read Weekly digest (revised) from register Weekly digest (hotfix)" in s["checker"]["reason"]
    assert s["checksum"] == "5702df2c35c4e2f5"
    q = s["quorum_same_schedule"]
    assert q["read"]["type"] == "info" and q["read"]["reason"] == "timeout_no_majority"
    assert q["read"]["latency"] == 0.20 and q["checker"]["valid"] is True

    t = r["timeout"]
    assert t["timeout_type"] == "info" and t["timeout_reason"] == "timeout_lost_reply"
    assert t["timeout_write"]["t"] == 0.40 and t["timeout_write"]["latency"] == 0.20
    assert t["timeout_applied_on"] == ["n1", "n2", "n3"]
    assert t["later_read"]["type"] == "ok" and t["later_read_value"] == TITLE_V3
    assert t["later_read"]["t"] == 0.60
    assert t["checker_as_info"]["valid"] is True
    assert t["checker_as_fail"]["valid"] is False
    assert "can't read Weekly digest (hotfix) from register Weekly digest (revised)" in t["checker_as_fail"]["reason"]

    p = r["pitfall"]
    assert p["history"] == [] and p["history_recorded"] is False and p["checker_ran"] is False
    assert p["counterexample_seed"] is None
    assert p["kill_notes"] == [
        {"t": 0.25, "node": "n2", "note": "killed n2"},
        {"t": 0.35, "node": "n3", "note": "killed n3"},
    ]

    hunt = r["hunt"]
    assert hunt["reproduced"] is True
    assert hunt["first_failing_seed"] == 1262027
    assert hunt["failing"]["checksum"] == "e7647d6a1f6253a9"
    assert hunt["repro"]["checksum"] == "e7647d6a1f6253a9"
    assert hunt["repro"]["valid"] is False
    assert hunt["other_seed"] == 1262028 and hunt["other_differs"] is True
    assert hunt["other_checksum"] == "901375405fe769b0"
    assert hunt["tried_n"] == 30
    assert hunt["n_invalid_in_window"] == 9 and hunt["n_valid_in_window"] == 21

    assert r["acceptance_timeout_is_info"]
    assert r["acceptance_seed_saved"]
    assert r["practice_history_and_manual_fail_case"]
    assert r["pitfall_kill_without_history"]
    assert r["tradeoff_testing_is_not_proof"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
