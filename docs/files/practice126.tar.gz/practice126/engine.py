#!/usr/bin/env python3
"""Teaching VerificationEngine — not Redis, not Jepsen as a product, not a network service.

A Python 3 standard-library model of a three-node teaching KV that records an
invoke/ok/fail/info history, injects partitions and lost replies through a
teaching nemesis, and checks the history against a single-register
linearizability model. It is used to observe why a timeout must be recorded as
an indeterminate result, how a stale local read becomes a hand-inspectable
counterexample, and why a saved seed is required to reproduce one.

The named source (checked on 2026-11-14) is the Jepsen repository
https://github.com/jepsen-io/jepsen together with the README Design Overview
and the tutorial chapters on clients, checkers, and the nemesis. Those pages
define :invoke / :ok / :fail / :info, a model plus a checker, and fault
injection by a nemesis. This engine is not the Jepsen Clojure library, not
Knossos, not Elle, not etcd, and not a network service. There is no SSH, no
TCP, no WAN, and no real clock. Persistence is a teaching dict flush, not
fsync. Clock is virtual. local_s, quorum_s, and timeout_s are teaching delays,
not production RTT.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
NODES = ("n1", "n2", "n3")
LOCAL_S = 0.05
QUORUM_S = 0.10
TIMEOUT_S = 0.20
NEMESIS_S = 0.05
PROCESS_NODE = {0: "n1", 1: "n2", 2: "n3"}


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


def history_checksum(history: list[dict[str, Any]]) -> str:
    blob = json.dumps(history, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class PairedOp:
    process: int
    f: str
    invoke_t: float
    complete_t: float
    ctype: str
    value: Any
    node: str


class VerificationEngine:
    """Three-node teaching KV with a Jepsen-style history and a register checker."""

    def __init__(
        self,
        *,
        read_mode: str = "quorum",  # quorum | local
        local_s: float = LOCAL_S,
        quorum_s: float = QUORUM_S,
        timeout_s: float = TIMEOUT_S,
        title: str = TITLE_V1,
        seed: Optional[int] = None,
    ) -> None:
        if read_mode not in {"quorum", "local"}:
            raise ValueError("read_mode must be quorum or local")
        self.clock = Clock()
        self.read_mode = read_mode
        self.local_s = float(local_s)
        self.quorum_s = float(quorum_s)
        self.timeout_s = float(timeout_s)
        self.seed = seed
        self.key = KEY_TITLE
        self.history: list[dict[str, Any]] = []
        self.partitioned: set[str] = set()
        self.drop_replies: set[str] = set()
        self.flush_count = 0
        self.nodes: dict[str, dict[str, Any]] = {}
        initial = {"value": title, "version": 1, "t": 0.0}
        for name in NODES:
            self.nodes[name] = {
                "name": name,
                "alive": True,
                "store": {KEY_TITLE: dict(initial)},
            }

    def now(self) -> float:
        return ts(self.clock.now())

    def advance(self, t: float) -> None:
        self.clock.wait_until(float(t))

    def _append(self, rec: dict[str, Any]) -> dict[str, Any]:
        rec = {"t": self.now(), **rec}
        self.history.append(rec)
        return rec

    def _flush(self, node: str) -> None:
        self.flush_count += 1

    def _component(self, node: str) -> list[str]:
        if not self.nodes[node]["alive"]:
            return []
        if node in self.partitioned:
            return [node] if self.nodes[node]["alive"] else []
        return [n for n in NODES if self.nodes[n]["alive"] and n not in self.partitioned]

    def snapshot(self) -> dict[str, Any]:
        return {
            name: {
                "alive": n["alive"],
                "title": n["store"].get(self.key, {}).get("value"),
                "version": n["store"].get(self.key, {}).get("version"),
                "partitioned": name in self.partitioned,
            }
            for name, n in self.nodes.items()
        }

    def nemesis(self, f: str, *, at: Optional[float] = None, node: Optional[str] = None) -> dict[str, Any]:
        """Teaching nemesis: start/stop a partition, drop replies, or crash a node."""
        if at is not None:
            self.advance(at)
        inv = self._append({"type": "invoke", "process": "nemesis", "f": f, "value": node, "node": node})
        self.clock.wait_until(self.clock.now() + NEMESIS_S)
        if f == "start_partition":
            if node is None:
                raise ValueError("start_partition needs a node")
            self.partitioned.add(node)
        elif f == "stop_partition":
            if node is None:
                raise ValueError("stop_partition needs a node")
            self.partitioned.discard(node)
        elif f == "drop_replies":
            if node is None:
                raise ValueError("drop_replies needs a node")
            self.drop_replies.add(node)
        elif f == "restore_replies":
            if node is None:
                raise ValueError("restore_replies needs a node")
            self.drop_replies.discard(node)
        elif f == "crash":
            if node is None:
                raise ValueError("crash needs a node")
            self.nodes[node]["alive"] = False
        elif f == "kill_unlogged":
            # Used only by the pitfall path that deliberately skips history.
            if node is None:
                raise ValueError("kill_unlogged needs a node")
            self.nodes[node]["alive"] = False
            self.history.pop()  # drop the invoke just recorded
            return {"t": self.now(), "type": "unlogged", "f": f, "node": node}
        else:
            raise ValueError(f"unknown nemesis f={f}")
        return self._append({"type": "info", "process": "nemesis", "f": f, "value": node, "node": node, "invoke_t": inv["t"]})

    def invoke(
        self,
        f: str,
        *,
        process: int,
        value: Any = None,
        at: Optional[float] = None,
        node: Optional[str] = None,
        timeout_as: str = "info",
    ) -> dict[str, Any]:
        if at is not None:
            self.advance(at)
        target = node or PROCESS_NODE[process]
        inv = self._append({
            "type": "invoke",
            "process": process,
            "f": f,
            "value": value if f != "read" else None,
            "node": target,
        })
        t_inv = self.clock.now()

        if not self.nodes[target]["alive"]:
            self.clock.wait_until(t_inv + self.local_s)
            return self._complete(inv, "fail", value=None, reason="node_down")

        reachable = self._component(target)

        if f == "write":
            # Apply locally first, then try to reach a majority.
            self._apply(target, value)
            acked = [target]
            for other in reachable:
                if other == target:
                    continue
                self._apply(other, value)
                acked.append(other)
            # Wait the quorum delay (or local if only the origin is reachable).
            wait = self.quorum_s if len(reachable) > 1 else self.local_s
            self.clock.wait_until(t_inv + wait)
            majority = len(acked) >= 2
            lost_reply = target in self.drop_replies
            if (not majority) or lost_reply:
                # Still waiting toward the client timeout before completing.
                deadline = t_inv + self.timeout_s
                if self.clock.now() < deadline:
                    self.clock.wait_until(deadline)
                ctype = timeout_as if timeout_as in {"info", "fail"} else "info"
                reason = "timeout_lost_reply" if lost_reply else "timeout_no_majority"
                return self._complete(inv, ctype, value=value, reason=reason, applied_on=list(acked))
            return self._complete(inv, "ok", value=value, reason="ok", applied_on=list(acked))

        if f == "read":
            if self.read_mode == "local":
                self.clock.wait_until(t_inv + self.local_s)
                got = self.nodes[target]["store"][self.key]["value"]
                return self._complete(inv, "ok", value=got, reason="local")
            # quorum read: need a majority of reachable titles; take highest version.
            if len(reachable) < 2:
                deadline = t_inv + self.timeout_s
                self.clock.wait_until(deadline)
                ctype = timeout_as if timeout_as in {"info", "fail"} else "info"
                return self._complete(inv, ctype, value=None, reason="timeout_no_majority")
            self.clock.wait_until(t_inv + self.quorum_s)
            best = max(
                (self.nodes[n]["store"][self.key] for n in reachable),
                key=lambda item: item["version"],
            )
            return self._complete(inv, "ok", value=best["value"], reason="quorum", observed_on=list(reachable))

        raise ValueError(f"unknown f={f}")

    def _apply(self, node: str, value: str) -> None:
        cur = self.nodes[node]["store"].get(self.key, {"version": 0})
        self.nodes[node]["store"][self.key] = {
            "value": value,
            "version": int(cur.get("version", 0)) + 1,
            "t": self.clock.now(),
        }
        self._flush(node)

    def _complete(self, inv: dict[str, Any], ctype: str, *, value: Any, reason: str, **extra: Any) -> dict[str, Any]:
        rec = self._append({
            "type": ctype,
            "process": inv["process"],
            "f": inv["f"],
            "value": value,
            "node": inv["node"],
            "reason": reason,
            "invoke_t": inv["t"],
            "latency": ts(self.clock.now() - inv["t"]),
            **extra,
        })
        return rec

    def pair_ops(self, history: Optional[list[dict[str, Any]]] = None) -> list[PairedOp]:
        hist = history if history is not None else self.history
        open_inv: dict[Any, dict[str, Any]] = {}
        paired: list[PairedOp] = []
        for ev in hist:
            proc = ev["process"]
            if proc == "nemesis":
                continue
            if ev["type"] == "invoke":
                open_inv[proc] = ev
                continue
            if ev["type"] in {"ok", "fail", "info"} and proc in open_inv:
                inv = open_inv.pop(proc)
                paired.append(PairedOp(
                    process=int(proc),
                    f=inv["f"],
                    invoke_t=float(inv["t"]),
                    complete_t=float(ev["t"]),
                    ctype=ev["type"],
                    value=ev.get("value"),
                    node=str(inv["node"]),
                ))
        return paired

    def check(self, history: Optional[list[dict[str, Any]]] = None, *, initial: str = TITLE_V1) -> dict[str, Any]:
        """Linearizability checker for a single register.

        Fail completions are treated as operations that did not take effect.
        Ok completions must take effect between invoke and complete.
        Info completions may or may not have taken effect; both possibilities
        are explored. This is a teaching enumeration, not Knossos or Elle.
        """
        ops = [op for op in self.pair_ops(history) if op.ctype != "fail"]
        required = [i for i, op in enumerate(ops) if op.ctype == "ok"]
        optional = [i for i, op in enumerate(ops) if op.ctype == "info"]

        def precedes(a: PairedOp, b: PairedOp) -> bool:
            return a.complete_t < b.invoke_t

        found: list[dict[str, Any]] = []

        def legal_prefix(order: list[int], included: set[int]) -> bool:
            # Real-time: if A completes before B invokes, A must appear before B
            # among included ops.
            pos = {idx: p for p, idx in enumerate(order)}
            for i in order:
                for j in order:
                    if i == j:
                        continue
                    if precedes(ops[i], ops[j]) and pos[i] > pos[j]:
                        return False
            return True

        def step_ok(state: str, op: PairedOp) -> Optional[str]:
            if op.f == "write":
                return op.value
            if op.f == "read":
                if op.value == state:
                    return state
                return None
            return state

        def rec(included: set[int]) -> None:
            if found:
                return
            order_ids = sorted(included)
            # Enumerate permutations that respect real-time.
            def perm(remaining: list[int], acc: list[int]) -> None:
                if found:
                    return
                if not remaining:
                    if not legal_prefix(acc, included):
                        return
                    state = initial
                    lin: list[dict[str, Any]] = []
                    for idx in acc:
                        op = ops[idx]
                        nxt = step_ok(state, op)
                        if nxt is None:
                            return
                        lin.append({
                            "process": op.process,
                            "f": op.f,
                            "value": op.value,
                            "ctype": op.ctype,
                            "invoke_t": op.invoke_t,
                            "complete_t": op.complete_t,
                            "state_after": nxt,
                        })
                        state = nxt
                    found.append({"linearization": lin, "final": state})
                    return
                for i, idx in enumerate(remaining):
                    # Prune: do not place idx before a required predecessor.
                    op = ops[idx]
                    ok_place = True
                    for done in acc:
                        if precedes(op, ops[done]):
                            ok_place = False
                            break
                    if not ok_place:
                        continue
                    perm(remaining[:i] + remaining[i + 1 :], acc + [idx])

            perm(order_ids, [])

        # Subsets of optional info ops, smallest first is unnecessary; any witness is enough.
        def subsets(items: list[int]) -> list[set[int]]:
            out: list[set[int]] = []
            n = len(items)
            for mask in range(1 << n):
                s = set(required)
                for b, idx in enumerate(items):
                    if mask & (1 << b):
                        s.add(idx)
                out.append(s)
            return out

        for included in subsets(optional):
            rec(included)
            if found:
                break

        valid = bool(found)
        reason = None
        if not valid:
            # Prefer a short, hand-inspectable explanation for the stale-read case:
            # an ok read that cannot follow a write that already completed.
            reason = self._explain_invalid(ops, initial)
        return {
            "valid": valid,
            "reason": reason,
            "witness": found[0] if found else None,
            "n_ops_checked": len(ops),
            "n_ok": sum(1 for op in ops if op.ctype == "ok"),
            "n_info": sum(1 for op in ops if op.ctype == "info"),
            "n_fail_excluded": sum(1 for ev in (history if history is not None else self.history) if ev.get("type") == "fail" and ev.get("process") != "nemesis"),
            "model": "teaching-register",
            "not_knossos": True,
            "not_elle": True,
        }

    def _explain_invalid(self, ops: list[PairedOp], initial: str) -> str:
        ok_writes = [op for op in ops if op.f == "write" and op.ctype == "ok"]
        ok_reads = [op for op in ops if op.f == "read" and op.ctype == "ok"]
        for w in ok_writes:
            for r in ok_reads:
                if w.complete_t < r.invoke_t and r.value != w.value:
                    later = [x for x in ok_writes if x.complete_t < r.invoke_t]
                    latest = max(later, key=lambda x: x.complete_t)
                    if latest is w or latest.value != r.value:
                        return (
                            f"can't read {r.value} from register {latest.value}: "
                            f"write of {latest.value} completed at {latest.complete_t} "
                            f"before read invoked at {r.invoke_t}"
                        )
        return "no linearization of the ok/info operations respects real-time and the register model"


def relabel_timeouts(history: list[dict[str, Any]], to: str) -> list[dict[str, Any]]:
    """Teaching contrast: rewrite timeout completions from info to fail (or back)."""
    out = []
    for ev in history:
        ev = dict(ev)
        if ev.get("process") != "nemesis" and ev.get("type") in {"info", "fail"} and str(ev.get("reason", "")).startswith("timeout"):
            ev["type"] = to
        out.append(ev)
    return out
