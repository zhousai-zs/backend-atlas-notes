#!/usr/bin/env python3
"""Run the lesson 126 history / fault-injection / checker experiments."""
from __future__ import annotations

import random
from typing import Any

from engine import (
    KEY_TITLE,
    LOCAL_S,
    QUORUM_S,
    TIMEOUT_S,
    TITLE_V1,
    TITLE_V2,
    TITLE_V3,
    VerificationEngine,
    history_checksum,
    relabel_timeouts,
)

FAILING_SEED = 1262026  # saved counterexample seed for the random local-read hunt


def _counts(eng: VerificationEngine) -> dict[str, int]:
    c = {"invoke": 0, "ok": 0, "fail": 0, "info": 0, "nemesis_info": 0}
    for ev in eng.history:
        typ = ev["type"]
        if ev.get("process") == "nemesis":
            if typ == "info":
                c["nemesis_info"] += 1
            continue
        if typ in c:
            c[typ] += 1
    return c


def run_healthy_quorum() -> dict[str, Any]:
    eng = VerificationEngine(read_mode="quorum")
    w1 = eng.invoke("write", process=0, value=TITLE_V2, at=0.00)
    r1 = eng.invoke("read", process=1, at=0.20)
    w2 = eng.invoke("write", process=1, value=TITLE_V3, at=0.40)
    r2 = eng.invoke("read", process=2, at=0.60)
    chk = eng.check()
    return {
        "read_mode": "quorum",
        "writes": [w1, w2],
        "reads": [r1, r2],
        "history": list(eng.history),
        "checksum": history_checksum(eng.history),
        "counts": _counts(eng),
        "checker": chk,
        "snapshot": eng.snapshot(),
        "t_end": eng.now(),
    }


def run_stale_local_read() -> dict[str, Any]:
    """Hand-inspectable counterexample: completed quorum write, then a stale local read."""
    eng = VerificationEngine(read_mode="local")
    w1 = eng.invoke("write", process=0, value=TITLE_V2, at=0.00)
    nem_start = eng.nemesis("start_partition", at=0.15, node="n3")
    w2 = eng.invoke("write", process=0, value=TITLE_V3, at=0.20)
    r_stale = eng.invoke("read", process=2, at=0.35)
    chk = eng.check()
    # The same schedule with quorum reads should not return a stale ok value.
    q = VerificationEngine(read_mode="quorum")
    q.invoke("write", process=0, value=TITLE_V2, at=0.00)
    q.nemesis("start_partition", at=0.15, node="n3")
    q.invoke("write", process=0, value=TITLE_V3, at=0.20)
    r_q = q.invoke("read", process=2, at=0.35)
    chk_q = q.check()
    return {
        "read_mode": "local",
        "writes": [w1, w2],
        "nemesis_start": nem_start,
        "stale_read": r_stale,
        "history": list(eng.history),
        "checksum": history_checksum(eng.history),
        "counts": _counts(eng),
        "checker": chk,
        "snapshot": eng.snapshot(),
        "t_end": eng.now(),
        "quorum_same_schedule": {
            "read": r_q,
            "checker": chk_q,
            "checksum": history_checksum(q.history),
            "t_end": q.now(),
        },
    }


def run_timeout_info_vs_fail() -> dict[str, Any]:
    """A majority write whose reply is dropped must be info, not fail."""
    eng = VerificationEngine(read_mode="quorum")
    w1 = eng.invoke("write", process=0, value=TITLE_V2, at=0.00)
    nem = eng.nemesis("drop_replies", at=0.15, node="n1")
    w2 = eng.invoke("write", process=0, value=TITLE_V3, at=0.20)
    r1 = eng.invoke("read", process=1, at=0.50)
    chk_info = eng.check()
    mislabelled = relabel_timeouts(eng.history, "fail")
    chk_fail = eng.check(mislabelled)
    return {
        "write_revised": w1,
        "nemesis": nem,
        "timeout_write": w2,
        "later_read": r1,
        "history": list(eng.history),
        "checksum": history_checksum(eng.history),
        "counts": _counts(eng),
        "checker_as_info": chk_info,
        "checker_as_fail": chk_fail,
        "timeout_type": w2["type"],
        "timeout_reason": w2["reason"],
        "timeout_applied_on": w2.get("applied_on"),
        "later_read_value": r1["value"],
        "snapshot": eng.snapshot(),
        "t_end": eng.now(),
    }


def run_pitfall_kill_without_history() -> dict[str, Any]:
    """Randomly crash nodes but do not journal a client history — nothing to check."""
    eng = VerificationEngine(read_mode="quorum")
    # Apply one unlogged write so the store is not empty, then crash without a history.
    eng.invoke("write", process=0, value=TITLE_V2, at=0.00)
    # The pitfall is to throw the history away and only keep crash notes.
    crashes = []
    for node, t in (("n2", 0.20), ("n3", 0.30)):
        rec = eng.nemesis("kill_unlogged", at=t, node=node)
        crashes.append({"t": rec["t"], "node": node, "note": f"killed {node}"})
    discarded = list(eng.history)
    eng.history = []  # operator kept only the kill notes
    return {
        "kill_notes": crashes,
        "history": list(eng.history),
        "history_recorded": False,
        "history_discarded_len": len(discarded),
        "checker_ran": False,
        "counterexample_seed": None,
        "snapshot": eng.snapshot(),
        "t_end": eng.now(),
    }


def _random_run(seed: int, read_mode: str, n_ops: int = 8) -> tuple[VerificationEngine, dict[str, Any]]:
    rng = random.Random(seed)
    titles = [TITLE_V2, TITLE_V3, "Weekly digest (east)", "Weekly digest (west)"]
    eng = VerificationEngine(read_mode=read_mode, seed=seed)
    t = 0.00
    partitioned = False
    for _ in range(n_ops):
        # Occasionally inject or heal a partition of n3.
        roll = rng.random()
        if roll < 0.25 and not partitioned:
            eng.nemesis("start_partition", at=round(t, 2), node="n3")
            partitioned = True
            t += 0.10
        elif roll > 0.85 and partitioned:
            eng.nemesis("stop_partition", at=round(t, 2), node="n3")
            partitioned = False
            t += 0.10
        proc = rng.choice([0, 1, 2])
        if rng.random() < 0.45:
            eng.invoke("write", process=proc, value=rng.choice(titles), at=round(t, 2))
        else:
            eng.invoke("read", process=proc, at=round(t, 2))
        t = eng.clock.now() + 0.05
    chk = eng.check()
    return eng, chk


def run_seed_hunt(start_seed: int = FAILING_SEED, limit: int = 30) -> dict[str, Any]:
    """Search a small window of seeds under local reads; save and reproduce a failure."""
    tried = []
    found = None
    for i in range(limit):
        seed = start_seed + i
        eng, chk = _random_run(seed, "local")
        tried.append({"seed": seed, "valid": chk["valid"], "n_history": len(eng.history), "checksum": history_checksum(eng.history)})
        if not chk["valid"] and found is None:
            found = {
                "seed": seed,
                "history": list(eng.history),
                "checksum": history_checksum(eng.history),
                "checker": chk,
                "counts": _counts(eng),
                "snapshot": eng.snapshot(),
                "t_end": eng.now(),
            }
    if found is None:
        # Fall back: still report the hunt, but the scripted stale-read seed is the saved one.
        return {"tried": tried, "found": None, "reproduced": False}

    # Reproduce with the same seed.
    eng2, chk2 = _random_run(found["seed"], "local")
    checksum2 = history_checksum(eng2.history)
    reproduced = (
        checksum2 == found["checksum"]
        and chk2["valid"] is False
        and chk2["reason"] == found["checker"]["reason"]
    )
    # A different seed should not be silently treated as the same history.
    other_seed = found["seed"] + 1
    eng3, chk3 = _random_run(other_seed, "local")
    return {
        "tried_n": len(tried),
        "first_failing_seed": found["seed"],
        "failing": found,
        "repro": {
            "seed": found["seed"],
            "checksum": checksum2,
            "valid": chk2["valid"],
            "reason": chk2["reason"],
        },
        "reproduced": reproduced,
        "other_seed": other_seed,
        "other_checksum": history_checksum(eng3.history),
        "other_differs": history_checksum(eng3.history) != found["checksum"],
        "n_invalid_in_window": sum(1 for t in tried if not t["valid"]),
        "n_valid_in_window": sum(1 for t in tried if t["valid"]),
    }


def run() -> dict[str, Any]:
    healthy = run_healthy_quorum()
    stale = run_stale_local_read()
    timeout = run_timeout_info_vs_fail()
    pitfall = run_pitfall_kill_without_history()
    hunt = run_seed_hunt()

    acceptance_timeout_is_info = (
        timeout["timeout_type"] == "info"
        and timeout["checker_as_info"]["valid"] is True
        and timeout["checker_as_fail"]["valid"] is False
        and timeout["later_read"]["type"] == "ok"
        and timeout["later_read_value"] == TITLE_V3
    )
    acceptance_seed_saved = (
        hunt["reproduced"] is True
        and hunt["first_failing_seed"] is not None
        and hunt["other_differs"] is True
        and stale["checker"]["valid"] is False
    )
    return {
        "engine": "VerificationEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_jepsen": True,
        "not_knossos": True,
        "not_elle": True,
        "not_etcd": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "local_s": LOCAL_S,
        "quorum_s": QUORUM_S,
        "timeout_s": TIMEOUT_S,
        "nodes": ["n1", "n2", "n3"],
        "healthy": healthy,
        "stale": stale,
        "timeout": timeout,
        "pitfall": pitfall,
        "hunt": hunt,
        "acceptance_timeout_is_info": acceptance_timeout_is_info,
        "acceptance_seed_saved": acceptance_seed_saved,
        "practice_history_and_manual_fail_case": (
            healthy["checker"]["valid"]
            and stale["checker"]["valid"] is False
            and stale["stale_read"]["value"] == TITLE_V2
            and stale["writes"][1]["type"] == "ok"
            and stale["writes"][1]["value"] == TITLE_V3
            and stale["quorum_same_schedule"]["checker"]["valid"]
            and stale["quorum_same_schedule"]["read"]["type"] == "info"
        ),
        "pitfall_kill_without_history": (
            (not pitfall["history_recorded"])
            and (not pitfall["checker_ran"])
            and pitfall["counterexample_seed"] is None
            and pitfall["history"] == []
        ),
        "tradeoff_testing_is_not_proof": (
            hunt.get("n_valid_in_window", 0) + hunt.get("n_invalid_in_window", 0) == hunt.get("tried_n", -1)
            and hunt.get("tried_n", 0) < 1_000
            and healthy["checker"]["valid"] is True
        ),
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
