#!/usr/bin/env python3
"""Acceptance checks for practice113 (distributed failure models)."""
from __future__ import annotations

import json
import os
import sys

from app import TITLE_V1, TITLE_V2, TITLE_HOTFIX, run_all_experiments
from engine import DELAY_S, TIMEOUT_S


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert(data["title_v1"] == TITLE_V1, "title v1 is Weekly digest")
    _assert(data["title_v2"] == TITLE_V2, "title v2 is Weekly digest (revised)")
    _assert(data["timeout_s"] == TIMEOUT_S, "timeout is 0.05s")
    _assert(data["delay_s"] == DELAY_S, "delay is 0.08s")

    t = data["timeout_vs_commit"]
    _assert(t["drop_reply"]["client"]["status"] == "timeout", "drop reply: client times out")
    _assert(t["drop_reply"]["client"]["elapsed_s"] == TIMEOUT_S, "drop reply waits the full budget")
    _assert(t["drop_reply"]["title_committed"] is True, "drop reply: server already committed")
    _assert(t["drop_reply"]["server"]["value"] == TITLE_V2, "drop reply: server has revised title")
    _assert(t["drop_reply"]["server"]["applied_count"] == 1, "drop reply: one SET applied")
    _assert(t["drop_request"]["client"]["status"] == "timeout", "drop request: client times out")
    _assert(t["drop_request"]["title_committed"] is False, "drop request: server did not apply")
    _assert(t["drop_request"]["server"]["value"] == TITLE_V1, "drop request: server keeps v1")
    _assert(t["drop_request"]["server"]["applied_count"] == 0, "drop request: nothing applied")
    _assert(t["client_timeout_observations_identical"] is True, "client sees the same timeout")
    _assert(t["server_observations_differ"] is True, "server observations differ")
    _assert(t["cannot_distinguish_drop_reply_from_drop_request"] is True, "timeout does not tell the two cases apart")
    _assert(t["timeout_is_not_proof_of_rollback"] is True, "pitfall: timeout is not rollback proof")
    _assert(t["delay_reply"]["title_committed"] is True, "delayed reply: already committed")
    _assert(t["delay_reply"]["client"]["status"] == "timeout", "delayed reply: client times out")
    _assert(t["delay_reply_arrives_late"] is True, "delayed reply arrives after timeout")
    _assert(t["delay_request"]["client"]["status"] == "timeout", "delayed request: client times out first")
    _assert(t["delay_request_commits_after_timeout"] is True, "delayed request commits after timeout")
    _assert(t["delay_request_delivered_late"] is True, "delayed request is delivered late")
    _assert(t["cannot_distinguish_delay_from_loss_at_timeout"] is True, "at timeout, delay looks like loss")
    _assert(t["acceptance_timeout_may_already_be_committed"] is True, "acceptance 1")

    r = data["retry_safety_vs_availability"]
    _assert(r["blind_retry"]["first"]["status"] == "timeout", "blind: first INCR times out")
    _assert(r["blind_retry"]["second"]["status"] == "ok", "blind: retry returns ok")
    _assert(r["blind_retry"]["views"] == 2, "blind retry applied INCR twice")
    _assert(r["blind_retry"]["safety_violation"] is True, "blind retry is a safety violation")
    _assert(r["no_retry"]["views"] == 1, "no retry: INCR applied once")
    _assert(r["no_retry"]["safety_violation"] is False, "no retry preserves safety")
    _assert(r["no_retry"]["availability_reduced"] is True, "no retry reduces availability")
    _assert(r["idempotent_retry"]["views"] == 1, "idempotent retry applied once")
    _assert(r["idempotent_retry"]["applied_count"] == 1, "idempotent key is reused, not re-applied")
    _assert(r["idempotent_retry"]["second"]["status"] == "ok", "idempotent retry is confirmed")
    _assert(r["idempotent_retry"]["second"]["value"] == 1, "idempotent retry returns the first result")
    _assert(r["acceptance_distinguish_safety_vs_availability"] is True, "acceptance 2 via retry")

    p = data["partition_and_failure_detection"]
    _assert(p["initial_get"]["status"] == "ok", "initial GET works")
    _assert(p["partitioned_write"]["status"] == "timeout", "partitioned SET times out")
    _assert(p["r1_crashed"] is False, "r1 is not crashed")
    _assert(p["r1_title_after_partitioned_client_write"] == TITLE_V1, "partitioned SET did not reach r1")
    _assert(p["suspects_after_partitioned_write"] == ["r1"], "detector suspects only partitioned r1")
    _assert(p["false_suspicion"] is True, "suspicion is false: r1 is alive")
    _assert(p["cannot_distinguish_crash_from_partition"] is True, "crash and partition look the same")
    _assert(p["conservative"]["split_brain"] is False, "conservative has no split brain")
    _assert(p["conservative"]["r1_title"] == TITLE_V1, "conservative r1 stays v1")
    _assert(p["conservative"]["r2_title"] == TITLE_V1, "conservative r2 stays v1")
    _assert(p["conservative"]["availability_reduced"] is True, "conservative reduces availability")
    _assert(p["aggressive"]["promoted_write"]["status"] == "ok", "aggressive write to r2 succeeds")
    _assert(p["aggressive"]["r1_title"] == TITLE_V2, "aggressive r1 has revised title")
    _assert(p["aggressive"]["r2_title"] == TITLE_HOTFIX, "aggressive r2 has hotfix")
    _assert(p["aggressive"]["split_brain"] is True, "aggressive has split brain")
    _assert(p["aggressive"]["safety_violation"] is True, "split brain is a safety violation")
    _assert(p["conservative_preserves_safety"] is True, "conservative preserves safety")
    _assert(p["aggressive_violates_safety"] is True, "aggressive violates safety")
    _assert(p["acceptance_distinguish_safety_vs_availability"] is True, "acceptance 2 via partition")

    m = data["crash_vs_byzantine"]
    _assert(m["crash"]["r1_times_out"] is True, "crashed r1 times out")
    _assert(m["crash"]["r2_returns_real"] is True, "honest r2 returns v2 after crash")
    _assert(m["crash"]["does_not_lie"] is True, "a crash replica does not invent a title")
    _assert(m["byzantine"]["r1_replies_quickly"] is True, "Byzantine r1 replies inside the budget")
    _assert(m["byzantine"]["r1_lies"] is True, "Byzantine r1 returns a stale lie, store still v2")
    _assert(m["byzantine"]["r2_returns_real"] is True, "honest r2 returns v2")
    _assert(m["byzantine"]["clients_see_different_values"] is True, "two GETs see different titles")
    _assert(m["byzantine"]["timeout_does_not_detect_the_lie"] is True, "the lie is not a timeout")
    _assert(m["crash_is_fail_stop"] is True, "crash is fail-stop")
    _assert(m["byzantine_is_outside_crash_model"] is True, "Byzantine lies are outside the crash model")
    _assert(m["teaching_limited_to_crash_failures"] is True, "tradeoff: teaching limits to crash")
    _assert(m["does_not_claim_to_cover_malicious_replicas"] is True, "does not claim to cover malice")

    _assert(data["acceptance_timeout_may_already_be_committed"] is True, "acceptance 1 overall")
    _assert(data["acceptance_distinguish_safety_vs_availability"] is True, "acceptance 2 overall")
    _assert(data["pitfall_timeout_is_not_rollback_proof"] is True, "pitfall recorded")
    _assert(data["tradeoff_teaching_limits_to_crash"] is True, "tradeoff recorded")
    _assert(data["title_hotfix"] == TITLE_HOTFIX, "hotfix title constant")

    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        sys.exit(1)
