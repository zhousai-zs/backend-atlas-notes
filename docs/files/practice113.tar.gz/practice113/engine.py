#!/usr/bin/env python3
"""Teaching FailureEngine — not Redis, not a real network, not BFT.

A Python 3 standard-library model of crash (fail-stop) replicas, a
proxy that can delay or drop a request or a reply, network partitions,
an unreliable failure detector, and a Byzantine stub used only to show
the teaching boundary.

This is not Redis, not redis-py, and not a network server. There is no
TCP, no Raft implementation, no PBFT, and no shared physical clock.
The Clock is a simulation scheduler so experiments are deterministic;
it is not a clock the replicas would share in a real deployment. The
node summary is the contract: a timeout only means the client's wait
budget is exhausted, and does not prove the remote did not execute.

Semantics follow MIT 6.5840 Spring 2026 lecture notes checked on
2026-11-13 (l01.txt, l-rpc.txt, l-raft.txt, plus l-vm-ft.txt and
l-bft.txt still linked from the Spring 2026 schedule), for the subset
implemented here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_HOTFIX = "Weekly digest (hotfix)"
TITLE_LIE = "Weekly digest"
KEY_TITLE = "article:01:title"
KEY_VIEWS = "article:01:views"
TIMEOUT_S = 0.05
DELAY_S = 0.08
SUSPECT_S = 0.05


class Clock:
    """A virtual clock tests can freeze and advance. Not a shared wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t = round(self.t + float(seconds), 10)


@dataclass
class Op:
    kind: str  # SET, GET, INCR
    key: str
    value: Optional[str] = None
    idempotency_key: Optional[str] = None

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"kind": self.kind, "key": self.key}
        if self.value is not None:
            d["value"] = self.value
        if self.idempotency_key is not None:
            d["idempotency_key"] = self.idempotency_key
        return d


@dataclass
class ClientObservation:
    status: str  # ok, timeout, unavailable
    value: Optional[str] = None
    elapsed_s: float = 0.0
    replica_id: str = ""
    timeout_s: float = 0.0
    applied_unknown: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "value": self.value,
            "elapsed_s": self.elapsed_s,
            "replica_id": self.replica_id,
            "timeout_s": self.timeout_s,
            "applied_unknown": self.applied_unknown,
        }


@dataclass
class ServerObservation:
    replica_id: str
    key: str
    value: Optional[str]
    applied_count: int
    crashed: bool
    byzantine: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "replica_id": self.replica_id,
            "key": self.key,
            "value": self.value,
            "applied_count": self.applied_count,
            "crashed": self.crashed,
            "byzantine": self.byzantine,
        }


@dataclass
class ProxyPolicy:
    drop_request: bool = False
    drop_reply: bool = False
    delay_request_s: float = 0.0
    delay_reply_s: float = 0.0
    partitioned: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "drop_request": self.drop_request,
            "drop_reply": self.drop_reply,
            "delay_request_s": self.delay_request_s,
            "delay_reply_s": self.delay_reply_s,
            "partitioned": self.partitioned,
        }


@dataclass
class Replica:
    replica_id: str
    store: dict[str, Any] = field(default_factory=dict)
    applied: list[dict[str, Any]] = field(default_factory=list)
    idempotency: dict[str, Any] = field(default_factory=dict)
    crashed: bool = False
    byzantine: bool = False
    lie_value: Optional[str] = None

    def apply(self, op: Op) -> Any:
        if self.crashed:
            raise RuntimeError("crashed replica cannot apply")
        if op.idempotency_key and op.idempotency_key in self.idempotency:
            return self.idempotency[op.idempotency_key]
        if op.kind == "SET":
            self.store[op.key] = op.value
            result = op.value
        elif op.kind == "GET":
            result = self.store.get(op.key)
        elif op.kind == "INCR":
            current = int(self.store.get(op.key, 0))
            current += 1
            self.store[op.key] = current
            result = current
        else:
            raise ValueError(f"unknown op {op.kind}")
        self.applied.append(op.as_dict())
        if op.idempotency_key:
            self.idempotency[op.idempotency_key] = result
        return result

    def visible_get(self, key: str) -> Optional[str]:
        """What a client would read if this replica answered GET.

        A crash replica does not answer. A Byzantine stub may lie.
        The real store is still available via store[key] for the
        server-side observation.
        """
        if self.crashed:
            return None
        if self.byzantine and self.lie_value is not None and key in self.store:
            return self.lie_value
        return self.store.get(key)


class FailureEngine:
    """A teaching cluster: crash replicas, a fault-injecting proxy, a client."""

    def __init__(self, replica_ids: list[str], clock: Optional[Clock] = None) -> None:
        self.clock = clock or Clock()
        self.replicas: dict[str, Replica] = {rid: Replica(rid) for rid in replica_ids}
        self.policies: dict[str, ProxyPolicy] = {rid: ProxyPolicy() for rid in replica_ids}
        self.last_heard: dict[str, float] = {rid: self.clock.now() for rid in replica_ids}
        self.late_replies: list[dict[str, Any]] = []
        self.pending_requests: list[dict[str, Any]] = []

    def seed(self, key: str, value: Any, replica_ids: Optional[list[str]] = None) -> None:
        ids = replica_ids or list(self.replicas)
        for rid in ids:
            self.replicas[rid].store[key] = value

    def set_policy(self, replica_id: str, **kwargs: Any) -> ProxyPolicy:
        policy = self.policies[replica_id]
        for k, v in kwargs.items():
            if not hasattr(policy, k):
                raise AttributeError(k)
            setattr(policy, k, v)
        return policy

    def crash(self, replica_id: str) -> None:
        self.replicas[replica_id].crashed = True

    def set_byzantine(self, replica_id: str, lie_value: str) -> None:
        r = self.replicas[replica_id]
        r.byzantine = True
        r.lie_value = lie_value

    def direct_apply(self, replica_id: str, op: Op) -> Any:
        """Apply on a replica without the client-side proxy.

        Used to model a client that is on the other side of a partition.
        """
        return self.replicas[replica_id].apply(op)

    def server_view(self, replica_id: str, key: str) -> ServerObservation:
        r = self.replicas[replica_id]
        applied = sum(1 for rec in r.applied if rec.get("key") == key)
        return ServerObservation(
            replica_id=replica_id,
            key=key,
            value=r.store.get(key),
            applied_count=applied,
            crashed=r.crashed,
            byzantine=r.byzantine,
        )

    def heartbeat_reachable(self) -> list[str]:
        """A teaching stand-in for heartbeats from replicas the proxy can still reach."""
        heard = []
        now = self.clock.now()
        for rid, r in self.replicas.items():
            policy = self.policies[rid]
            if r.crashed or policy.partitioned:
                continue
            self.last_heard[rid] = now
            heard.append(rid)
        return heard

    def suspects(self, timeout_s: float = SUSPECT_S) -> list[str]:
        now = self.clock.now()
        return [rid for rid, t in self.last_heard.items() if now - t >= timeout_s]

    def _apply_if_up(self, replica_id: str, op: Op) -> tuple[bool, Any]:
        """Deliver a request that has already passed the proxy."""
        r = self.replicas[replica_id]
        if r.crashed:
            return False, None
        if op.kind == "GET" and r.byzantine:
            result = r.visible_get(op.key)
            r.applied.append(op.as_dict())
            return True, result
        return True, r.apply(op)

    def pump_pending(self) -> list[dict[str, Any]]:
        """Deliver requests still in flight and late replies, advancing the clock."""
        arrived: list[dict[str, Any]] = []
        events = list(self.pending_requests) + list(self.late_replies)
        events.sort(key=lambda e: e["at"])
        self.pending_requests = []
        self.late_replies = []
        for item in events:
            if item["at"] > self.clock.now():
                self.clock.advance(item["at"] - self.clock.now())
            if item["kind"] == "request":
                reached, result = self._apply_if_up(item["replica_id"], item["op"])
                item = {
                    "kind": item["kind"],
                    "at": item["at"],
                    "replica_id": item["replica_id"],
                    "op": item["op"].as_dict(),
                    "request_reached": reached,
                    "value": result,
                }
                if reached:
                    policy = self.policies[item["replica_id"]]
                    if not policy.drop_reply and not policy.partitioned:
                        reply_at = round(self.clock.now() + float(policy.delay_reply_s), 10)
                        self.late_replies.append(
                            {
                                "kind": "reply",
                                "at": reply_at,
                                "reply_at": reply_at,
                                "replica_id": item["replica_id"],
                                "value": result,
                                "request_reached": True,
                            }
                        )
            arrived.append(item)
        # Flush any replies queued by the requests we just delivered.
        if self.late_replies:
            arrived.extend(self.pump_pending())
        return arrived

    def client_call(self, replica_id: str, op: Op, timeout_s: float = TIMEOUT_S) -> ClientObservation:
        t0 = self.clock.now()
        deadline = round(t0 + float(timeout_s), 10)
        policy = self.policies[replica_id]

        def _timeout() -> ClientObservation:
            remaining = deadline - self.clock.now()
            if remaining > 0:
                self.clock.advance(remaining)
            self.heartbeat_reachable()
            return ClientObservation(
                status="timeout",
                value=None,
                elapsed_s=round(self.clock.now() - t0, 10),
                replica_id=replica_id,
                timeout_s=timeout_s,
                applied_unknown=True,
            )

        if policy.partitioned or policy.drop_request:
            return _timeout()

        request_at = round(t0 + float(policy.delay_request_s), 10)
        if request_at > deadline:
            # The client gives up while the request is still in flight.
            obs = _timeout()
            self.pending_requests.append(
                {"kind": "request", "at": request_at, "replica_id": replica_id, "op": op}
            )
            return obs

        if request_at > t0:
            self.clock.advance(request_at - t0)

        reached, result = self._apply_if_up(replica_id, op)
        if not reached:
            return _timeout()

        if policy.drop_reply or policy.partitioned:
            return _timeout()

        reply_at = round(self.clock.now() + float(policy.delay_reply_s), 10)
        if reply_at > deadline:
            obs = _timeout()
            self.late_replies.append(
                {
                    "kind": "reply",
                    "at": reply_at,
                    "reply_at": reply_at,
                    "replica_id": replica_id,
                    "value": result,
                    "request_reached": True,
                }
            )
            return obs

        if reply_at > self.clock.now():
            self.clock.advance(reply_at - self.clock.now())
        self.last_heard[replica_id] = self.clock.now()
        return ClientObservation(
            status="ok",
            value=result,
            elapsed_s=round(self.clock.now() - t0, 10),
            replica_id=replica_id,
            timeout_s=timeout_s,
            applied_unknown=False,
        )
