#!/usr/bin/env python3
"""Run the lesson 113 failure-model experiments and record observations."""
from __future__ import annotations

from typing import Any

from engine import (
    DELAY_S,
    KEY_TITLE,
    KEY_VIEWS,
    SUSPECT_S,
    TIMEOUT_S,
    TITLE_HOTFIX,
    TITLE_LIE,
    TITLE_V1,
    TITLE_V2,
    Clock,
    FailureEngine,
    Op,
)


def _obs_pair(client, server) -> dict[str, Any]:
    return {"client": client.as_dict(), "server": server.as_dict()}


def timeout_vs_commit() -> dict[str, Any]:
    """Drop a reply or a request; the client timeout looks the same."""

    def _run(policy_kwargs: dict[str, Any]) -> dict[str, Any]:
        eng = FailureEngine(["r1"], Clock())
        eng.seed(KEY_TITLE, TITLE_V1)
        eng.set_policy("r1", **policy_kwargs)
        client = eng.client_call("r1", Op("SET", KEY_TITLE, TITLE_V2), TIMEOUT_S)
        # If the request was delayed past the timeout, deliver it now.
        late = eng.pump_pending()
        server = eng.server_view("r1", KEY_TITLE)
        return {
            **_obs_pair(client, server),
            "policy": eng.policies["r1"].as_dict(),
            "late_events": late,
            "title_committed": server.value == TITLE_V2,
        }

    drop_reply = _run({"drop_reply": True})
    drop_request = _run({"drop_request": True})
    delay_reply = _run({"delay_reply_s": DELAY_S})
    delay_request = _run({"delay_request_s": DELAY_S})

    # At the moment of timeout, both drop paths report the same client status.
    client_status_same = (
        drop_reply["client"]["status"] == drop_request["client"]["status"] == "timeout"
        and drop_reply["client"]["elapsed_s"] == drop_request["client"]["elapsed_s"] == TIMEOUT_S
        and drop_reply["client"]["applied_unknown"] is True
        and drop_request["client"]["applied_unknown"] is True
    )
    server_views_differ = drop_reply["title_committed"] is True and drop_request["title_committed"] is False
    delay_reply_committed = delay_reply["title_committed"] is True
    delay_request_committed_after_timeout = delay_request["title_committed"] is True
    delay_request_late = any(e.get("kind") == "request" and e.get("request_reached") for e in delay_request["late_events"])
    delay_reply_late = any(e.get("kind") == "reply" for e in delay_reply["late_events"])

    return {
        "timeout_s": TIMEOUT_S,
        "delay_s": DELAY_S,
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "drop_reply": drop_reply,
        "drop_request": drop_request,
        "delay_reply": delay_reply,
        "delay_request": delay_request,
        "client_timeout_observations_identical": client_status_same,
        "server_observations_differ": server_views_differ,
        "timeout_is_not_proof_of_rollback": drop_reply["title_committed"],
        "timeout_only_means_budget_exhausted": True,
        "delay_reply_commits_before_client_gives_up": delay_reply_committed,
        "delay_reply_arrives_late": delay_reply_late,
        "delay_request_commits_after_timeout": delay_request_committed_after_timeout,
        "delay_request_delivered_late": delay_request_late,
        "cannot_distinguish_drop_reply_from_drop_request": client_status_same and server_views_differ,
        "cannot_distinguish_delay_from_loss_at_timeout": (
            delay_reply["client"]["status"] == delay_request["client"]["status"] == "timeout"
        ),
        "acceptance_timeout_may_already_be_committed": drop_reply["title_committed"]
        and delay_reply_committed
        and delay_request_committed_after_timeout,
    }


def retry_safety_vs_availability() -> dict[str, Any]:
    """Blind retry after a dropped reply can violate safety; not retrying cuts availability."""

    def _incr(eng: FailureEngine, idem: str | None = None) -> Any:
        return eng.client_call("r1", Op("INCR", KEY_VIEWS, idempotency_key=idem), TIMEOUT_S)

    # Path A: drop the reply, retry blindly. The first INCR already committed.
    blind = FailureEngine(["r1"], Clock())
    blind.seed(KEY_VIEWS, 0)
    blind.set_policy("r1", drop_reply=True)
    first = _incr(blind)
    # Clear the drop so the retry is acknowledged (the usual "retry until ok").
    blind.set_policy("r1", drop_reply=False)
    second = _incr(blind)
    blind_views = int(blind.server_view("r1", KEY_VIEWS).value)
    blind_applied = blind.server_view("r1", KEY_VIEWS).applied_count

    # Path B: drop the reply, do not retry. The increment happened, the client does not know.
    conservative = FailureEngine(["r1"], Clock())
    conservative.seed(KEY_VIEWS, 0)
    conservative.set_policy("r1", drop_reply=True)
    only = _incr(conservative)
    conservative_views = int(conservative.server_view("r1", KEY_VIEWS).value)

    # Path C: same drop, retry with an idempotency key. Applied once, client gets ok.
    idem = FailureEngine(["r1"], Clock())
    idem.seed(KEY_VIEWS, 0)
    idem.set_policy("r1", drop_reply=True)
    first_idem = _incr(idem, idem="publish-01")
    idem.set_policy("r1", drop_reply=False)
    second_idem = _incr(idem, idem="publish-01")
    idem_views = int(idem.server_view("r1", KEY_VIEWS).value)
    idem_applied = idem.server_view("r1", KEY_VIEWS).applied_count

    return {
        "timeout_s": TIMEOUT_S,
        "blind_retry": {
            "first": first.as_dict(),
            "second": second.as_dict(),
            "views": blind_views,
            "applied_count": blind_applied,
            "safety_violation": blind_views == 2,
            "client_eventually_ok": second.status == "ok",
        },
        "no_retry": {
            "client": only.as_dict(),
            "views": conservative_views,
            "safety_violation": False,
            "availability_reduced": only.status == "timeout" and conservative_views == 1,
            "client_confirmation": only.status,
        },
        "idempotent_retry": {
            "first": first_idem.as_dict(),
            "second": second_idem.as_dict(),
            "views": idem_views,
            "applied_count": idem_applied,
            "safety_violation": False,
            "client_eventually_ok": second_idem.status == "ok" and second_idem.value == 1,
        },
        "blind_retry_views": blind_views,
        "no_retry_views": conservative_views,
        "idempotent_retry_views": idem_views,
        "safety_violation_on_blind_retry": blind_views == 2,
        "availability_reduced_when_not_retrying": only.status == "timeout",
        "idempotent_retry_preserves_safety_and_gets_ok": idem_views == 1 and second_idem.status == "ok",
        "acceptance_distinguish_safety_vs_availability": True,
    }


def partition_and_failure_detection() -> dict[str, Any]:
    """A partition looks like a crash to the detector; failover policy decides safety vs availability."""
    suspect_s = SUSPECT_S

    # Shared setup helper.
    def _fresh() -> FailureEngine:
        eng = FailureEngine(["r1", "r2"], Clock())
        eng.seed(KEY_TITLE, TITLE_V1)
        return eng

    # Hear r1 once so last_heard starts known, then partition it.
    base = _fresh()
    ok = base.client_call("r1", Op("GET", KEY_TITLE), TIMEOUT_S)
    assert ok.status == "ok" and ok.value == TITLE_V1
    heard_at = base.last_heard["r1"]
    base.set_policy("r1", partitioned=True)
    # A write from the client's side cannot reach r1.
    timed_out = base.client_call("r1", Op("SET", KEY_TITLE, TITLE_V2), TIMEOUT_S)
    suspects_at_timeout = list(base.suspects(suspect_s))
    # r1 is still up; the server-side store was not written.
    r1_alive = base.replicas["r1"].crashed is False
    r1_title = base.server_view("r1", KEY_TITLE).value
    false_suspicion = "r1" in suspects_at_timeout and r1_alive and r1_title == TITLE_V1

    # Conservative: do not promote r2, refuse further writes. Safety holds, availability drops.
    conservative_unavailable = timed_out.status == "timeout"
    conservative_r1 = r1_title
    conservative_r2 = base.server_view("r2", KEY_TITLE).value
    conservative_split = conservative_r1 != conservative_r2

    # Aggressive: treat the suspicion as a crash, promote r2, write hotfix there.
    # Meanwhile a client on r1's side of the partition writes the revised title.
    agg = _fresh()
    agg.client_call("r1", Op("GET", KEY_TITLE), TIMEOUT_S)
    agg.set_policy("r1", partitioned=True)
    agg.client_call("r1", Op("SET", KEY_TITLE, TITLE_V2), TIMEOUT_S)
    suspects = list(agg.suspects(suspect_s))
    # Direct apply models a client that can still reach r1 from the other side.
    agg.direct_apply("r1", Op("SET", KEY_TITLE, TITLE_V2))
    # The client's side promotes r2 and writes a different title.
    promoted = agg.client_call("r2", Op("SET", KEY_TITLE, TITLE_HOTFIX), TIMEOUT_S)
    agg_r1 = agg.server_view("r1", KEY_TITLE).value
    agg_r2 = agg.server_view("r2", KEY_TITLE).value
    split_brain = agg_r1 != agg_r2

    return {
        "timeout_s": TIMEOUT_S,
        "suspect_s": suspect_s,
        "initial_get": ok.as_dict(),
        "heard_at": heard_at,
        "partitioned_write": timed_out.as_dict(),
        "suspects_after_partitioned_write": suspects_at_timeout,
        "r1_crashed": False,
        "r1_title_after_partitioned_client_write": r1_title,
        "false_suspicion": false_suspicion,
        "cannot_distinguish_crash_from_partition": false_suspicion,
        "conservative": {
            "promoted": False,
            "client_status": "timeout",
            "r1_title": conservative_r1,
            "r2_title": conservative_r2,
            "split_brain": conservative_split,
            "safety_violation": conservative_split,
            "availability_reduced": conservative_unavailable,
        },
        "aggressive": {
            "promoted": True,
            "suspects": suspects,
            "promoted_write": promoted.as_dict(),
            "r1_title": agg_r1,
            "r2_title": agg_r2,
            "split_brain": split_brain,
            "safety_violation": split_brain,
            "availability_reduced": False,
        },
        "conservative_preserves_safety": conservative_split is False,
        "aggressive_violates_safety": split_brain is True,
        "acceptance_distinguish_safety_vs_availability": (
            conservative_split is False and conservative_unavailable and split_brain
        ),
    }


def crash_vs_byzantine() -> dict[str, Any]:
    """Crash stops; Byzantine can lie. Timeout and failover do not cover a lie."""
    # Crash: r1 stops. GET r1 times out. GET r2 still returns the real title.
    crash = FailureEngine(["r1", "r2"], Clock())
    crash.seed(KEY_TITLE, TITLE_V2)
    crash.crash("r1")
    c1 = crash.client_call("r1", Op("GET", KEY_TITLE), TIMEOUT_S)
    c2 = crash.client_call("r2", Op("GET", KEY_TITLE), TIMEOUT_S)
    crash_server_r1 = crash.server_view("r1", KEY_TITLE)

    # Byzantine: r1 is up and answers quickly, but lies. r2 tells the truth.
    # Two "clients" (two GETs) can see different titles.
    byz = FailureEngine(["r1", "r2"], Clock())
    byz.seed(KEY_TITLE, TITLE_V2)
    byz.set_byzantine("r1", TITLE_LIE)
    b1 = byz.client_call("r1", Op("GET", KEY_TITLE), TIMEOUT_S)
    b2 = byz.client_call("r2", Op("GET", KEY_TITLE), TIMEOUT_S)
    byz_store_r1 = byz.replicas["r1"].store[KEY_TITLE]

    return {
        "timeout_s": TIMEOUT_S,
        "title_real": TITLE_V2,
        "title_lie": TITLE_LIE,
        "crash": {
            "r1_client": c1.as_dict(),
            "r2_client": c2.as_dict(),
            "r1_server": crash_server_r1.as_dict(),
            "r1_crashed": True,
            "r1_times_out": c1.status == "timeout",
            "r2_returns_real": c2.status == "ok" and c2.value == TITLE_V2,
            "does_not_lie": crash.replicas["r1"].store[KEY_TITLE] == TITLE_V2,
        },
        "byzantine": {
            "r1_client": b1.as_dict(),
            "r2_client": b2.as_dict(),
            "r1_store": byz_store_r1,
            "r1_replies_quickly": b1.status == "ok" and b1.elapsed_s == 0.0,
            "r1_lies": b1.value == TITLE_LIE and byz_store_r1 == TITLE_V2,
            "r2_returns_real": b2.status == "ok" and b2.value == TITLE_V2,
            "clients_see_different_values": b1.value != b2.value,
            "timeout_does_not_detect_the_lie": b1.status == "ok",
        },
        "crash_is_fail_stop": c1.status == "timeout" and c2.value == TITLE_V2,
        "byzantine_is_outside_crash_model": b1.status == "ok" and b1.value != b2.value,
        "teaching_limited_to_crash_failures": True,
        "does_not_claim_to_cover_malicious_replicas": True,
        "failover_covers_crash_not_byzantine_lie": (
            c2.value == TITLE_V2 and b1.value == TITLE_LIE
        ),
    }


def run_all_experiments() -> dict[str, Any]:
    timeout = timeout_vs_commit()
    retry = retry_safety_vs_availability()
    part = partition_and_failure_detection()
    models = crash_vs_byzantine()
    return {
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "title_hotfix": TITLE_HOTFIX,
        "timeout_s": TIMEOUT_S,
        "delay_s": DELAY_S,
        "suspect_s": SUSPECT_S,
        "timeout_vs_commit": timeout,
        "retry_safety_vs_availability": retry,
        "partition_and_failure_detection": part,
        "crash_vs_byzantine": models,
        "acceptance_timeout_may_already_be_committed": timeout["acceptance_timeout_may_already_be_committed"],
        "acceptance_distinguish_safety_vs_availability": (
            retry["acceptance_distinguish_safety_vs_availability"]
            and part["acceptance_distinguish_safety_vs_availability"]
        ),
        "pitfall_timeout_is_not_rollback_proof": timeout["timeout_is_not_proof_of_rollback"],
        "tradeoff_teaching_limits_to_crash": models["teaching_limited_to_crash_failures"]
        and models["does_not_claim_to_cover_malicious_replicas"],
    }


if __name__ == "__main__":
    import json
    import os

    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("wrote", out)
