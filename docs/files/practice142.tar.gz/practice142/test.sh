#!/usr/bin/env bash
# 第 142 课 j-git 动手实践：功能分支 -> 文本冲突 -> 解决 -> revert -> 找某行引入提交 -> 公开分支变基风险
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
export GIT_AUTHOR_NAME=lab GIT_AUTHOR_EMAIL=lab@example.com GIT_COMMITTER_NAME=lab GIT_COMMITTER_EMAIL=lab@example.com
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1
t=0; tick(){ t=$((t+60)); export GIT_AUTHOR_DATE="@$((1794621600+t)) +0800" GIT_COMMITTER_DATE="@$((1794621600+t)) +0800"; }
say(){ echo; echo "### $*"; }
cd "$W"; git init -q -b main origin.git --bare; git clone -q origin.git dev 2>/dev/null; cd dev
git config pull.rebase false

say "1. 三个区：工作区 / 暂存区 / 提交"
printf 'timeout_ms=200\nretry=1\nfeature_x=off\n' > config.ini
git status --short
git add config.ini; git status --short
tick; git commit -qm "init config"; git status --short; echo "(干净)"
echo "lines in HEAD: $(git show HEAD:config.ini | wc -l)"
echo 'retry=2' >> config.ini   # 只改工作区
echo "diff(工作区 vs 暂存区):"; git diff --stat
git restore config.ini
tick; git push -q origin main

say "2. 功能分支 + main 上并行修改同一行 -> 冲突"
git switch -q -c feature/timeout
sed -i 's/timeout_ms=200/timeout_ms=500/' config.ini; tick; git commit -qam "feature: timeout 500"
git switch -q main
sed -i 's/timeout_ms=200/timeout_ms=300/' config.ini; tick; git commit -qam "hotfix: timeout 300"
set +e; git merge feature/timeout > merge.out 2>&1; rc=$?; set -e
cat merge.out; rm merge.out; echo "merge exit=$rc"
git status --short
echo "--- 冲突标记 ---"; cat config.ini
CONFLICT_RC=$rc

say "3. 解决冲突：取 400，add 标记解决，commit 生成合并提交"
printf 'timeout_ms=400\nretry=1\nfeature_x=off\n' > config.ini
git add config.ini; tick; git commit -qm "merge feature/timeout: settle on 400"
PARENTS=$(git log -1 --format=%P | wc -w)
echo "合并提交父提交数=$PARENTS"; git log --graph --oneline --all | cat
tick; git push -q origin main

say "4. 引入一个错误提交，再 revert（新增反向提交，不改历史）"
sed -i 's/retry=1/retry=100/' config.ini; tick; git commit -qam "tune: retry 100 (bad)"
BAD=$(git rev-parse --short HEAD)
echo "x" > notes.txt; git add notes.txt; tick; git commit -qm "docs: notes"
tick; git push -q origin main
BEFORE=$(git rev-list --count HEAD)
tick; git revert --no-edit "$BAD" >/dev/null
AFTER=$(git rev-list --count HEAD)
echo "revert 前提交数=$BEFORE 后=$AFTER"; grep retry config.ini; git log --oneline -3 | cat
RETRY_AFTER=$(grep retry config.ini)

say "5. 用 log 找到某行引入的提交"
echo "git log -S'timeout_ms=400' --oneline（默认不看合并提交的 diff）:"; S_PLAIN=$(git log -S'timeout_ms=400' --oneline | wc -l); echo "  命中 $S_PLAIN 条"
echo "加 --diff-merges=first-parent:"; git log -S'timeout_ms=400' --diff-merges=first-parent --oneline | cat
echo "git log -L1,1:config.ini 最近一条:"; git log -L1,1:config.ini --format='%h %s' -1 --no-patch | cat
echo "git blame -L1,1:"; git blame -L1,1 --abbrev=7 config.ini | cat
LINE_COMMIT=$(git log -S'timeout_ms=400' --diff-merges=first-parent --format=%s | head -1)

say "6. reset 对比：reset --hard 移动分支指针，丢弃未推送的提交"
echo "tmp" > tmp.txt; git add tmp.txt; tick; git commit -qm "wip tmp"
WIP=$(git rev-parse --short HEAD)
git reset -q --hard HEAD~1
echo "reset 后 HEAD=$(git log -1 --format='%h %s'); tmp.txt 存在? $([ -e tmp.txt ] && echo yes || echo no)"
echo "reflog 仍记得: $(git reflog -2 --format='%h %gs' | tail -1)"
echo "未提交的修改被 reset --hard 丢弃后无处可找回:"
echo 'retry=9' >> config.ini; git reset -q --hard; echo "  retry=9 还在? $(grep -c 'retry=9' config.ini || true)"

say "7. 公开分支变基风险：同事基于旧提交工作，作者 rebase 后强推"
git switch -q -c feature/shared main~2 ; echo a > a.txt; git add a.txt; tick; git commit -qm "shared: a"
git push -q origin feature/shared
OLD=$(git rev-parse --short HEAD)
cd "$W"; git clone -q origin.git peer; cd peer; git switch -q feature/shared; echo b > b.txt; git add b.txt; tick; git commit -qm "peer: b"
cd "$W/dev"; tick; git rebase -q main; NEW=$(git rev-parse --short HEAD)
echo "rebase 前 shared: a = $OLD, 之后 = $NEW（内容相同，哈希不同）"
set +e; git push -q origin feature/shared 2>push.err; prc=$?; set -e; echo "普通 push exit=$prc"; head -2 push.err; rm -f push.err
git push -q --force-with-lease origin feature/shared; echo "force-with-lease 推送完成"
cd "$W/peer"; git fetch -q
echo "同事本地与远端分叉: $(git rev-list --left-right --count HEAD...origin/feature/shared)  (左=只在本地, 右=只在远端)"
set +e; git pull -q --no-rebase origin feature/shared >/dev/null 2>&1; set -e
DUP=$(git log --format=%s | grep -c '^shared: a$')
echo "同事 pull(merge) 后历史里 'shared: a' 出现次数=$DUP"
cd "$W/dev"

python3 - "$CONFLICT_RC" "$PARENTS" "$BEFORE" "$AFTER" "$RETRY_AFTER" "$LINE_COMMIT" "$OLD" "$NEW" "$prc" "$DUP" "$S_PLAIN" > "$HERE/results.json" <<'EOF'
import json,sys
a=sys.argv[1:]
r=dict(git_version=__import__('subprocess').check_output(['git','--version']).decode().strip(),
 merge_conflict_exit=int(a[0]), merge_commit_parents=int(a[1]), commits_before_revert=int(a[2]), commits_after_revert=int(a[3]),
 retry_line_after_revert=a[4], line_introduced_by=a[5], shared_old=a[6], shared_new=a[7], plain_push_exit=int(a[8]), peer_duplicate_commits=int(a[9]), log_S_plain_hits=int(a[10]))
r['checks']=dict(conflict_happened=r['merge_conflict_exit']!=0, merge_commit_has_2_parents=r['merge_commit_parents']==2,
 revert_adds_commit=r['commits_after_revert']==r['commits_before_revert']+1, revert_restores_retry=r['retry_line_after_revert']=='retry=1',
 log_finds_line=r['line_introduced_by'].startswith('merge feature/timeout'), rebase_changes_hash=r['shared_old']!=r['shared_new'],
 plain_push_rejected=r['plain_push_exit']!=0, peer_gets_duplicate=r['peer_duplicate_commits']==2)
print(json.dumps(r,ensure_ascii=False,indent=1))
EOF
echo; cat "$HERE/results.json"
python3 -c "import json,sys;c=json.load(open('$HERE/results.json'))['checks'];sys.exit(0 if all(c.values()) else 1)" && echo ALL_CHECKS_PASSED
