#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <string>
#include <unordered_map>

// Teaching server: one request line, then a reply.
// BUG: after reading a complete line, the server waits for more input and
// does not treat read()==0 / peer half-close as "request complete, reply now".
// A client that sends "PING\n" and shutdown(SHUT_WR) therefore never gets PONG.

#ifndef FIX
#define FIX 0
#endif

static int listen_port(int port) {
  int fd = ::socket(AF_INET, SOCK_STREAM, 0);
  int opt = 1;
  setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  addr.sin_port = htons(static_cast<uint16_t>(port));
  if (bind(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) return -1;
  if (port == 0) {
    socklen_t len = sizeof(addr);
    getsockname(fd, reinterpret_cast<sockaddr*>(&addr), &len);
    port = ntohs(addr.sin_port);
  }
  if (listen(fd, 16) != 0) return -1;
  std::cout << "READY " << port << std::endl;
  std::cout.flush();
  return fd;
}

int main(int argc, char** argv) {
  int port = (argc >= 2) ? std::stoi(argv[1]) : 0;
  int lfd = listen_port(port);
  if (lfd < 0) return 1;
  int ep = epoll_create1(0);
  epoll_event ev{};
  ev.events = EPOLLIN;
  ev.data.fd = lfd;
  epoll_ctl(ep, EPOLL_CTL_ADD, lfd, &ev);
  std::unordered_map<int, std::string> buf;
  while (true) {
    epoll_event evs[8];
    int n = epoll_wait(ep, evs, 8, -1);
    for (int i = 0; i < n; i++) {
      int fd = evs[i].data.fd;
      if (fd == lfd) {
        int c = accept(lfd, nullptr, nullptr);
        if (c < 0) continue;
        epoll_event cev{};
        // Intentionally do not add EPOLLRDHUP in the buggy build.
        cev.events = EPOLLIN;
        cev.data.fd = c;
        epoll_ctl(ep, EPOLL_CTL_ADD, c, &cev);
        buf[c] = "";
        continue;
      }
      char tmp[256];
      ssize_t r = ::recv(fd, tmp, sizeof(tmp), 0);
      bool peer_closed = (r == 0);
      if (r < 0) {
        close(fd);
        buf.erase(fd);
        continue;
      }
      if (r > 0) buf[fd].append(tmp, tmp + r);
      auto pos = buf[fd].find('\n');
      bool complete = pos != std::string::npos;
#if FIX
      if (complete || peer_closed) {
        std::string line = complete ? buf[fd].substr(0, pos) : buf[fd];
        std::string resp = (line == "PING") ? "PONG\n" : "ERR\n";
        ::send(fd, resp.data(), resp.size(), 0);
        epoll_ctl(ep, EPOLL_CTL_DEL, fd, nullptr);
        close(fd);
        buf.erase(fd);
      }
#else
      // BUG: a complete line is not enough; the server waits for a later read.
      // When the client already half-closed, that later read never comes as a
      // new request, and we also ignore r==0 here.
      (void)peer_closed;
      if (complete && false) {
        std::string resp = "PONG\n";
        ::send(fd, resp.data(), resp.size(), 0);
        close(fd);
        buf.erase(fd);
      }
#endif
    }
  }
}
