# 新人任务包：epoll 半关闭缺陷定位（渐进，不代做）

## 阶段 1 — 复现（不给补丁）
运行 `python3 pack/reproduce.py --bin ./workspace/build/echo_server`。
客户发送 `PING\n` 后 `shutdown(SHUT_WR)`，在 1 秒内应收到 `PONG`。
起始二进制会超时。把 `reports/reproduce.log` 留下来。

## 阶段 2 — 证据链（仍不给补丁）
只根据复现日志和源码阅读，写 `reports/evidence.md`，必须包括：
- 你实际观察到的现象（超时、未收到 PONG）
- 客户端做了半关闭（SHUT_WR）这一事实
- 服务端在完整一行之后仍等待后续输入、并忽略 `read()==0` 的代码位置
不要只背诵 “epoll 是 ET/LT” 或只写改了多少行。

## 阶段 3 — 修复并回归
在理解证据后再改 `FIX` 路径：完整一行或对端半关闭时立即回复并关闭。
重新编译带 `-DFIX=1` 的二进制，复现脚本必须在超时前收到 `PONG`。

评分标准在 `pack/rubric.yaml`。不以代码行数评价。
