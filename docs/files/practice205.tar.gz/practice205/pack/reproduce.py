from __future__ import annotations

import argparse
import socket
import subprocess
import sys
import time
from pathlib import Path


def run(bin_path: Path, timeout=1.0) -> dict:
    proc = subprocess.Popen([str(bin_path), "0"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    assert proc.stdout
    line = proc.stdout.readline().strip()
    if not line.startswith("READY "):
        proc.kill()
        return {"ok": False, "error": f"start failed: {line}"}
    port = int(line.split()[1])
    s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
    s.sendall(b"PING\n")
    s.shutdown(socket.SHUT_WR)
    s.settimeout(timeout)
    t0 = time.time()
    try:
        data = s.recv(64)
        elapsed = time.time() - t0
        s.close()
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
        return {"ok": data == b"PONG\n", "data": data.decode("utf-8", "replace"), "elapsed": elapsed, "timeout": False}
    except socket.timeout:
        s.close()
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
        return {"ok": False, "data": "", "elapsed": timeout, "timeout": True, "error": "no PONG before timeout after SHUT_WR"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bin", required=True)
    ap.add_argument("--expect-fail", action="store_true")
    args = ap.parse_args()
    r = run(Path(args.bin))
    print(r)
    if args.expect_fail:
        sys.exit(0 if (not r["ok"] and r.get("timeout")) else 1)
    sys.exit(0 if r["ok"] else 1)


if __name__ == "__main__":
    main()
