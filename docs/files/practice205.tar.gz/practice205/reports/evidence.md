观察到 reproduce.py 在 SHUT_WR 之后 1 秒超时，未收到 PONG（见 reports/reproduce.log）。
客户端发送 PING 后半关闭写端。echo_server.cpp 在完整一行后仍把 complete && false，并忽略 read()==0 / peer_closed，因此永远等下一轮输入。
