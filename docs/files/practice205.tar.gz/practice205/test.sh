#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:$PWD/tools:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
echo "INVENTORY cmake=$(command -v cmake) clang-tidy=$(command -v clang-tidy)"
cmake --version | head -1
./tools/zig-c++ --version | head -1
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["failed"]==[]
assert r["evidence_scores"]["good"]["passed"]
assert not r["evidence_scores"]["loc_only"]["passed"]
print("POSTCHECK_OK")
PY
