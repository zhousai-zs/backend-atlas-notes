from __future__ import annotations

import re
from pathlib import Path


def score_evidence(text: str, reproduce_log: str) -> dict:
    reasons = []
    ok_timeout = ("timeout" in text.lower() or "超时" in text) and ("timeout" in reproduce_log.lower() or "SHUT_WR" in reproduce_log or "no PONG" in reproduce_log)
    ok_half = any(k in text.lower() or k in text for k in ["half-close", "half close", "半关闭", "shut_wr", "shutdown"])
    ok_code = any(k in text.lower() or k in text for k in ["read()==0", "recv", "eof", "peer_closed", "忽略", "echo_server.cpp"])
    loc_only = bool(re.search(r"改了?\s*\d+\s*行", text)) and not (ok_half and ok_timeout)
    recite = ("epoll 是边缘触发" in text or "epoll is edge-triggered" in text.lower()) and not ok_timeout
    passed = ok_timeout and ok_half and ok_code and not loc_only and not recite
    if not ok_timeout:
        reasons.append("missing_observed_timeout")
    if not ok_half:
        reasons.append("missing_half_close")
    if not ok_code:
        reasons.append("missing_code_or_eof")
    if loc_only:
        reasons.append("score_by_lines_of_code")
    if recite:
        reasons.append("recite_concepts_without_evidence")
    return {"passed": passed, "reasons": reasons}
