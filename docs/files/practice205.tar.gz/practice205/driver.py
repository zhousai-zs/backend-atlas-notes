from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from score import score_evidence

ROOT = Path(__file__).resolve().parent
CM = Path("/workspace/atlas/cmvenv")
RESULTS = ROOT / "results.json"


def cmake_build(flag: str, outdir: Path) -> Path:
    cmake = str(CM / "bin" / "cmake")
    ninja = str(CM / "bin" / "ninja")
    cxx = ROOT / "tools" / "zig-c++"
    if not Path(cmake).exists() or not cxx.exists():
        raise SystemExit(f"toolchain missing after inventory cmake={cmake} cxx={cxx}")
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    env = os.environ.copy()
    env["PATH"] = f"{CM/'bin'}:{ROOT/'tools'}:{env.get('PATH','')}"
    env["CXX"] = str(cxx)
    env["CC"] = str(ROOT / "tools" / "zig-cc")
    env["CMAKE_MAKE_PROGRAM"] = ninja
    subprocess.check_call([cmake, "-S", str(ROOT / "repo"), "-B", str(outdir), "-G", "Ninja", f"-DCMAKE_CXX_FLAGS={flag}"], env=env)
    subprocess.check_call([cmake, "--build", str(outdir)], env=env)
    return outdir / "echo_server"


def repro(bin_path: Path, expect_fail=False) -> dict:
    cmd = [str(CM / "bin" / "python3"), str(ROOT / "pack" / "reproduce.py"), "--bin", str(bin_path)]
    if expect_fail:
        cmd.append("--expect-fail")
    p = subprocess.run(cmd, text=True, capture_output=True)
    return {"rc": p.returncode, "out": (p.stdout + p.stderr).strip()}


def main() -> None:
    checks = []

    def check(name, ok, detail=""):
        checks.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f" {detail}" if detail else ""))

    # Inventory
    cxx_ver = subprocess.check_output([str(ROOT / "tools" / "zig-c++"), "--version"], text=True).splitlines()[0]
    check("toolchain_inventoried", "clang" in cxx_ver.lower() or "Clang" in cxx_ver or "clang version" in cxx_ver, cxx_ver)

    buggy = cmake_build("-DFIX=0", ROOT / "workspace" / "build-buggy")
    bad = repro(buggy, expect_fail=True)
    (ROOT / "reports" / "reproduce.log").write_text(bad["out"] + "\n")
    check("stage1_buggy_times_out", bad["rc"] == 0 and "timeout" in bad["out"], bad["out"])

    # Stage 2: a good evidence chain vs a LOC-only / recite-only chain
    good_ev = """观察到 reproduce.py 在 SHUT_WR 之后 1 秒超时，未收到 PONG（见 reports/reproduce.log）。
客户端发送 PING 后半关闭写端。echo_server.cpp 在完整一行后仍把 complete && false，并忽略 read()==0 / peer_closed，因此永远等下一轮输入。
"""
    bad_loc = "我改了 25 行，所以已经掌握 epoll。"
    bad_recite = "epoll 是边缘触发，所以需要 EPOLLET。本次没有看日志。"
    g = score_evidence(good_ev, bad["out"])
    b1 = score_evidence(bad_loc, bad["out"])
    b2 = score_evidence(bad_recite, bad["out"])
    (ROOT / "reports" / "evidence.md").write_text(good_ev)
    check("good_evidence_passes", g["passed"], str(g))
    check("loc_only_rejected", not b1["passed"] and "score_by_lines_of_code" in b1["reasons"], str(b1))
    check("recite_without_evidence_rejected", not b2["passed"], str(b2))

    # Pack stages 1-2 do not contain the patch flag as a giveaway in TASK.md? They mention FIX in stage 3 only — OK.
    task = (ROOT / "pack" / "TASK.md").read_text()
    stage12 = task.split("## 阶段 3")[0]
    check("no_over_help_in_stage12", "-DFIX=1" not in stage12 and "立即回复并关闭" not in stage12, "")

    fixed = cmake_build("-DFIX=1", ROOT / "workspace" / "build-fixed")
    good = repro(fixed, expect_fail=False)
    (ROOT / "reports" / "fixed.log").write_text(good["out"] + "\n")
    check("stage3_fixed_gets_pong", good["rc"] == 0 and "PONG" in good["out"] and "timeout': False" in good["out"], good["out"])

    failed = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(json.dumps({
        "lesson": 205, "id": "n-mentoring", "is_live_model": False,
        "cxx": cxx_ver,
        "buggy": bad, "fixed": good,
        "evidence_scores": {"good": g, "loc_only": b1, "recite": b2},
        "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        "failed": failed,
        "not_verified_on_this_machine": [
            "a live newcomer mentoring session or growth over weeks",
            "strace (not installed on this machine; reproduction used a timeout after SHUT_WR instead)",
        ],
        "verified_on_this_machine": [
            "compiled buggy epoll server times out after client half-close; -DFIX=1 replies PONG",
            "rubric accepts an evidence chain and rejects LOC-only or concept-recitation answers",
        ],
    }, ensure_ascii=False, indent=2) + "\n")
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
