#include <cstdio>
#include <array>
#include <cstdint>
#include <optional>
#include <span>

constexpr std::size_t kHeaderSize = 12;
constexpr std::uint16_t kMagic = 0x5758;

struct Header {
    std::uint16_t magic;
    std::uint8_t version;
    std::uint8_t type;
    std::uint32_t body_len;
    std::uint32_t seq;
};

std::uint16_t read_u16_be(const std::uint8_t* p) {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(p[0]) << 8) |
        static_cast<std::uint16_t>(p[1]));
}

std::uint32_t read_u32_be(const std::uint8_t* p) {
    return (static_cast<std::uint32_t>(p[0]) << 24) |
           (static_cast<std::uint32_t>(p[1]) << 16) |
           (static_cast<std::uint32_t>(p[2]) << 8) |
           static_cast<std::uint32_t>(p[3]);
}

std::optional<Header> parse_header(std::span<const std::uint8_t> input) {
    if (input.size() < kHeaderSize) {
        return std::nullopt;
    }

    auto raw = input.first<kHeaderSize>();
    Header header{};
    header.magic = read_u16_be(raw.data());
    header.version = raw[2];
    header.type = raw[3];
    header.body_len = read_u32_be(raw.data() + 4);
    header.seq = read_u32_be(raw.data() + 8);

    if (header.magic != kMagic) {
        return std::nullopt;
    }

    return header;
}
#include <array>
#include <cassert>
#include <cstdint>
#include <span>

void test_parse_header() {
    std::array<std::uint8_t, 12> full{
        0x57, 0x58, 0x01, 0x02,
        0x00, 0x00, 0x00, 0x10,
        0x00, 0x00, 0x00, 0x2A
    };

    auto header = parse_header(full);
    assert(header.has_value());
    assert(header->magic == 0x5758);
    assert(header->version == 1);
    assert(header->type == 2);
    assert(header->body_len == 16);
    assert(header->seq == 42);

    for (std::size_t n = 0; n < 12; ++n) {
        std::span<const std::uint8_t> truncated(full.data(), n);
        assert(!parse_header(truncated).has_value());
    }

    std::array<std::uint8_t, 12> wrong_magic{};
    assert(!parse_header(wrong_magic).has_value());
}
bool body_len_is_valid(const Header& header,
                       std::span<const std::uint8_t> input) {
    if (input.size() < kHeaderSize) {
        return false;
    }
    return header.body_len <= input.size() - kHeaderSize;
}

int main(){test_parse_header();std::puts("LESSON_REF_OK");}
