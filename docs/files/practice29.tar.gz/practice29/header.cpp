// 定长协议头：magic(2B) version(1B) flags(1B) cmd(2B) length(4B) uid(8B) = 18B，大端
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

struct Header {            // 独立值：不持有任何指向缓冲区的指针/视图
    uint16_t magic;
    uint8_t version;
    uint8_t flags;
    uint16_t cmd;
    uint32_t length;
    uint64_t uid;
};
constexpr std::size_t kHeaderSize = 18;
constexpr uint16_t kMagic = 0xCAFE;

template <class T>
T read_be(std::span<const std::byte> s) {     // 调用方保证 s.size() == sizeof(T)
    T v = 0;
    for (std::byte b : s) v = static_cast<T>((v << 8) | std::to_integer<uint8_t>(b));
    return v;
}

enum class ParseError { Truncated, BadMagic, BodyTooLarge };

struct Result { std::optional<Header> h; ParseError err{}; };

Result parse_header(std::span<const std::byte> buf) {
    if (buf.size() < kHeaderSize) return {std::nullopt, ParseError::Truncated};
    auto h = buf.first<kHeaderSize>();              // 静态长度子视图
    Header out{
        read_be<uint16_t>(h.subspan<0, 2>()),
        read_be<uint8_t>(h.subspan<2, 1>()),
        read_be<uint8_t>(h.subspan<3, 1>()),
        read_be<uint16_t>(h.subspan<4, 2>()),
        read_be<uint32_t>(h.subspan<6, 4>()),
        read_be<uint64_t>(h.subspan<10, 8>()),
    };
    if (out.magic != kMagic) return {std::nullopt, ParseError::BadMagic};
    if (out.length > 1u << 20) return {std::nullopt, ParseError::BodyTooLarge};
    return {out, {}};
}

std::vector<std::byte> make_packet() {
    unsigned char raw[kHeaderSize] = {0xCA,0xFE, 1, 0x02, 0x00,0x10, 0,0,0,0x2A,
                                      0,0,0,0,0,0,0x30,0x39};
    std::vector<std::byte> v(kHeaderSize);
    std::memcpy(v.data(), raw, kHeaderSize);
    return v;
}

// string_view 不以零结尾的演示
void sv_not_null_terminated() {
    std::string line = "GET /api/user?id=42 HTTP/1.1";
    std::string_view path = std::string_view(line).substr(4, 15);   // "/api/user?id=42"
    std::printf("path.size()=%zu, printf %%.*s => %.*s\n", path.size(), (int)path.size(), path.data());
    // 错误示范：std::printf("%s", path.data()) 会一直打印到 line 的 '\0'
    std::printf("data() as C string (wrong) => %s\n", path.data());
    std::string owned(path);   // 需要传给 C API 时复制成 std::string
    std::printf("c_str() correct => %s\n", owned.c_str());
}

int main() {
    sv_not_null_terminated();
    Header saved{};
    {
        auto pkt = make_packet();
        auto r = parse_header(pkt);
        if (!r.h) { std::puts("FAIL: valid packet rejected"); return 1; }
        saved = *r.h;   // 拷贝出独立值
    }                   // pkt 已释放，saved 仍然有效
    std::printf("magic=%#x ver=%u flags=%u cmd=%u len=%u uid=%llu\n", saved.magic, saved.version,
                saved.flags, saved.cmd, saved.length, (unsigned long long)saved.uid);
    bool ok = saved.magic == 0xCAFE && saved.cmd == 16 && saved.length == 42 && saved.uid == 12345;

    auto pkt = make_packet();
    for (std::size_t n = 0; n < kHeaderSize; ++n) {          // 所有截断长度都必须被拒
        auto r = parse_header(std::span<const std::byte>(pkt).first(n));
        if (r.h || r.err != ParseError::Truncated) { std::printf("FAIL truncated n=%zu\n", n); ok = false; }
    }
    std::puts("truncated 0..17 bytes all rejected");
    pkt[0] = std::byte{0x00};
    auto bad = parse_header(pkt);
    if (bad.h || bad.err != ParseError::BadMagic) ok = false; else std::puts("bad magic rejected");
    std::puts(ok ? "ALL_CHECKS_PASSED" : "SOME_CHECKS_FAILED");
    return ok ? 0 : 1;
}
