#!/bin/bash
set -u
cd "$(dirname "$0")"
F="-std=c++20 -g -fsanitize=address,undefined -fno-omit-frame-pointer"
g++ $F -Wall -Wextra header.cpp -o header && ./header || exit 1
echo "--- dangling string_view (expect ASan heap-use-after-free) ---"
g++ $F dangling.cpp -o dangling 2>&1 | grep -i warn
./dangling 2>&1 | grep -m1 -o "heap-use-after-free" || echo "NOT DETECTED"
echo "--- span after vector growth (expect ASan heap-use-after-free) ---"
g++ $F invalidate.cpp -o invalidate && ./invalidate 2>&1 | grep -m1 -o "heap-use-after-free" || echo "NOT DETECTED"
