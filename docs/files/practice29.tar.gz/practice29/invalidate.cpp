#include <span>
#include <vector>
#include <cstdio>
int main() {
    std::vector<int> ids{1, 2, 3};
    std::span<int> s(ids);
    ids.push_back(4);                    // 扩容，s 指向旧缓冲区
    std::printf("%d\n", s[0]);
}
