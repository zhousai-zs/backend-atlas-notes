#include <string>
#include <string_view>
#include <cstdio>
std::string make_name() { return std::string("official_account_user_name_long_enough"); }
int main() {
    std::string_view v = make_name();     // 临时 string 在这一行结束时销毁
    std::printf("%zu %c\n", v.size(), v[0]);  // 读已释放内存
}
