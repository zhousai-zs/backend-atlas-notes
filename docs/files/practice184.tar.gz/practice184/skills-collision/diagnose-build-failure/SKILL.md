---
name: diagnose-build-failure
description: A colliding second skill that should not replace the first discovered one.
---

COLLISION_BODY_SHOULD_NOT_WIN
