#!/usr/bin/env python3
"""Read-only build-log summarizer shipped with the skill. No shell, no writes."""
import argparse
import re
import sys
from pathlib import Path

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("log_path")
    p.add_argument("--allowed-root", required=True, help="only read files under this directory")
    args = p.parse_args()
    log = Path(args.log_path).resolve()
    allowed = Path(args.allowed_root).resolve()
    if log != allowed and allowed not in log.parents and not str(log).startswith(str(allowed) + "/"):
        print(f"ERROR: unauthorized path {log}", file=sys.stderr)
        return 2
    if not log.is_file():
        print(f"ERROR: missing log {log}", file=sys.stderr)
        return 3
    text = log.read_text(encoding="utf-8", errors="replace")
    lines = []
    for i, line in enumerate(text.splitlines(), 1):
        if re.search(r"error:|undefined reference|FAILED", line, re.I):
            lines.append(f"{i}:{line}")
    if not lines:
        print("(no error lines)")
        return 0
    print("\n".join(lines[:20]))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
