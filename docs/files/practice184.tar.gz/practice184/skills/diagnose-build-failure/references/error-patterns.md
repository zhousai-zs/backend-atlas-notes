# Common linker patterns (loaded on demand)

REF_MARKER_UNDEFINED_REFERENCE

`undefined reference to exists` usually means a command or symbol was declared or called but not compiled into the archive. Check the source that should define the symbol and the list of objects passed to the linker. This note is intentionally longer than the skill body so it should not appear in the advertised skill metadata.
