#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
unset OPENAI_API_KEY ANTHROPIC_API_KEY GOOGLE_API_KEY GEMINI_API_KEY || true
if [[ ! -d node_modules/@earendil-works/pi-coding-agent ]]; then
  npm install --ignore-scripts --no-fund --no-audit
fi
node driver.mjs 2>&1 | tee run.log
node --input-type=module - <<'JS'
import fs from "node:fs";
const log = fs.readFileSync("run.log", "utf8");
const r = JSON.parse(fs.readFileSync("results.json", "utf8"));
if (!log.includes("ALL_CHECKS_PASSED")) throw new Error("missing ALL_CHECKS_PASSED");
if (r.package_version !== "1.5.2" || r.is_live_model !== false) throw new Error("package/live");
if (!r.advertised_excludes_body || r.case_unrelated.activated) throw new Error("progressive load");
if (!r.case_ok.activated || !r.output_has_retrievable_log_location) throw new Error("ok case");
if (!String(r.case_missing.error||"").includes("missing log")) throw new Error("missing log");
if (!r.unauthorized_rejected || r.injection_became_host_rule) throw new Error("inject/authz");
if (!r.paths_still_under_skill_dir) throw new Error("cwd resolve");
if (!String(r.case_missing_dep.error||"").includes("missing dependency")) throw new Error("dep");
if (!r.update_loaded_v2 || !r.update_unrelated_still_inactive) throw new Error("update");
if (r.collision_kept_count !== 1 || !r.collision_has_diagnostic) throw new Error("collision");
if (r.official_skill_type_has_allowed_tools !== false) throw new Error("allowed-tools enforcement");
console.log("POSTCHECK_OK");
JS
