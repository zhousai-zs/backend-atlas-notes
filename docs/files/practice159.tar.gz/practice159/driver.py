#!/usr/bin/env python3
from __future__ import annotations

import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

try:
    import tiktoken
except ImportError:
    sys.stderr.write("Need tiktoken==0.14.0 (pinned). Checked this interpreter.\n")
    raise

assert tiktoken.__version__ == "0.14.0", tiktoken.__version__

log = (ROOT / "samples/kv.log").read_text(encoding="utf-8")
cpp = (ROOT / "samples/cache.cpp").read_text(encoding="utf-8")
encodings = ["cl100k_base", "o200k_base", "p50k_base"]


def count(enc_name, text):
    enc = tiktoken.get_encoding(enc_name)
    ids = enc.encode(text)
    return {"tokens": len(ids), "chars": len(text), "bytes": len(text.encode())}


def ratio(rec):
    return None if rec["chars"] == 0 else round(rec["tokens"] / rec["chars"], 4)

table = {}
for enc in encodings:
    table[enc] = {"log": count(enc, log), "cpp": count(enc, cpp)}
    table[enc]["log"]["tokens_per_char"] = ratio(table[enc]["log"])
    table[enc]["cpp"]["tokens_per_char"] = ratio(table[enc]["cpp"])

# Character count is a bad universal budget: same text, different encodings differ.
log_counts = [table[e]["log"]["tokens"] for e in encodings]
cpp_counts = [table[e]["cpp"]["tokens"] for e in encodings]
assert len(set(log_counts)) >= 2, log_counts  # not all models share a tokenizer

# Truncation policy: keep the error stack and the task constraint; drop heartbeats first.
keep_markers = ["调用栈", "service.cpp", "任务约束"]
drop_markers = ["心跳", "定期指标"]


def clip(text, enc_name, budget):
    enc = tiktoken.get_encoding(enc_name)
    # split into lines, score, keep required lines first, then fill remaining budget
    lines = text.splitlines(keepends=True)
    required, optional, dropped_always = [], [], []
    for ln in lines:
        if any(m in ln for m in keep_markers) or ln.startswith("  #"):
            required.append(ln)
        elif any(m in ln for m in drop_markers):
            dropped_always.append(ln)
        else:
            optional.append(ln)
    # Required lines (stack + task constraints) are always kept, even if they
    # exceed the soft budget; only optional lines are clipped.
    kept = list(required)
    used = sum(len(enc.encode(ln)) for ln in kept)
    required_tokens = used
    for ln in optional:
        n = len(enc.encode(ln))
        if used + n <= budget:
            kept.append(ln)
            used += n
        else:
            dropped_always.append(ln)
    out = "".join(kept)
    assert all(m in out for m in ("调用栈", "service.cpp:7", "任务约束"))
    assert "心跳" not in out and "定期指标" not in out
    return {"text": out, "tokens": len(enc.encode(out)), "budget": budget,
            "required_tokens": required_tokens, "dropped_lines": len(dropped_always)}

clipped = clip(log, "cl100k_base", 80)

# naive char budget would treat Chinese and C++ the same ratio; show mismatch
results = {
    "lesson": 159,
    "id": "k-tokens",
    "is_live_model": False,
    "tiktoken": tiktoken.__version__,
    "encodings": encodings,
    "counts": table,
    "char_count_is_not_a_universal_budget": True,
    "log_token_counts_differ_across_encodings": len(set(log_counts)) >= 2,
    "cpp_token_counts": {e: table[e]["cpp"]["tokens"] for e in encodings},
    "log_token_counts": {e: table[e]["log"]["tokens"] for e in encodings},
    "log_chars": table["cl100k_base"]["log"]["chars"],
    "clip_cl100k_budget_80": {k: clipped[k] for k in clipped if k != "text"},
    "clip_kept_stack_and_constraints": True,
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
(REPORTS / "clip.txt").write_text(clipped["text"])
print(json.dumps(results, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
