#include <cstdint>
#include <cstring>
struct Slot { char* data; int len; };
void cache_set(Slot& s, const char* v) {
    s.len = static_cast<int>(std::strlen(v));
    s.data = new char[s.len + 1];
    std::memcpy(s.data, v, static_cast<size_t>(s.len) + 1);
}
int cache_sum(const Slot& s) {
    int total = 0;
    for (int i = 0; i < s.len; ++i) total += static_cast<unsigned char>(s.data[i]);
    return total;
}
