#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
pick_python() {
  if python3 -c 'import tiktoken,sys; assert tiktoken.__version__=="0.14.0"' 2>/dev/null; then
    echo python3; return
  fi
  if [[ -x /workspace/atlas/cmvenv/bin/python ]] && /workspace/atlas/cmvenv/bin/python -c 'import tiktoken,sys; assert tiktoken.__version__=="0.14.0"' 2>/dev/null; then
    echo /workspace/atlas/cmvenv/bin/python; return
  fi
  echo "Need tiktoken==0.14.0 in python3 or /workspace/atlas/cmvenv" >&2
  exit 1
}
PY=$(pick_python)
echo "using $PY"
"$PY" -c 'import tiktoken; print("tiktoken", tiktoken.__version__)'
"$PY" driver.py 2>&1 | tee run.log
