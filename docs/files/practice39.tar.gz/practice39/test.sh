#!/usr/bin/env bash
# 第39课实践：Unix 域 socket 父子任务通信（含对端退出 EOF/EPIPE）+ 共享内存同步传大块数据
set -u; cd "$(dirname "$0")"
gcc -O1 -pthread -w -o ipc ipc.c || exit 1
out=$(./ipc); echo "$out"; fail=0
chk(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
v(){ echo "$out" | grep "^$1 " | grep -o "$2=[0-9.]*" | cut -d= -f2; }
chk "pipe 是字节流：3 次 write 被 1 次 read 读成 6 字节" '[ "$(v pipe_3writes_1read bytes)" = 6 ]'
chk "SOCK_SEQPACKET 保留边界：两次 read 得 2 和 4" 'echo "$out" | grep -q "seqpacket reads=2,4"'
chk "正常任务分发 100 个，平方和 338350" '[ "$(v tasks_normal ok)" = 100 ] && [ "$(v tasks_normal sum)" = 338350 ]'
chk "worker 崩溃：父进程读到 EOF 而非卡死，再写得 EPIPE，子进程退出码 9" '[ "$(v tasks_crash ok)" = 10 ] && [ "$(v tasks_crash eof)" = 1 ] && [ "$(v tasks_crash epipe)" = 1 ] && [ "$(v tasks_crash child_exit)" = 9 ]'
chk "共享内存在锁+条件变量同步下结果正确" 'echo "$out" | grep -q "^shm_sum=4194304 " && echo "$out" | grep -q "^sock_sum=4194304$"'
chk "加锁计数严格等于 2000000" '[ "$(v race_locked counter)" = 2000000 ]'
n=$(v race_nolock counter); echo "INFO 无锁计数=$n（通常小于 2000000，说明共享内存不自带互斥）"
[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED
