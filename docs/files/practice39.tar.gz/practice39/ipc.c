/* 第39课实践：Unix 域 socket 父子任务通信 + 共享内存大块数据对比 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <sys/wait.h>

static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
/* 读满/写满：处理短读短写与 EINTR；返回 0 表示对端关闭(EOF) */
static ssize_t read_full(int fd,void*b,size_t n){size_t g=0;while(g<n){ssize_t r=read(fd,(char*)b+g,n-g);
 if(r<0){if(errno==EINTR)continue;return -1;} if(r==0)return g; g+=r;} return g;}
static int write_full(int fd,const void*b,size_t n){size_t g=0;while(g<n){ssize_t r=write(fd,(const char*)b+g,n-g);
 if(r<0){if(errno==EINTR)continue;return -1;} g+=r;} return 0;}
/* 长度前缀帧：4 字节长度 + 负载，在字节流上自己定义消息边界 */
static int send_msg(int fd,const void*p,uint32_t n){if(write_full(fd,&n,4))return -1;return write_full(fd,p,n);}
static int recv_msg(int fd,void*p,uint32_t cap,uint32_t*n){ssize_t r=read_full(fd,n,4); if(r==0)return 0; if(r!=4)return -1;
 if(*n>cap)return -1; return read_full(fd,p,*n)==(ssize_t)*n?1:-1;}

/* 1. pipe 是字节流：三次 write 可能被一次 read 读走 */
static void demo_pipe(void){int p[2];pipe(p);write(p[1],"aa",2);write(p[1],"bb",2);write(p[1],"cc",2);
 char b[64];ssize_t r=read(p[0],b,sizeof b);printf("pipe_3writes_1read bytes=%zd\n",r);close(p[0]);close(p[1]);}
/* 2. SOCK_SEQPACKET 保留消息边界 */
static void demo_seqpacket(void){int s[2];socketpair(AF_UNIX,SOCK_SEQPACKET,0,s);write(s[0],"aa",2);write(s[0],"bbbb",4);
 char b[64];ssize_t r1=read(s[1],b,64),r2=read(s[1],b,64);printf("seqpacket reads=%zd,%zd\n",r1,r2);close(s[0]);close(s[1]);}

/* 3. master/worker：任务分发 + 对端退出 EOF/EPIPE */
static void worker(int fd,int crash_after){char buf[256];uint32_t n;int done=0;
 for(;;){int r=recv_msg(fd,buf,sizeof buf-1,&n); if(r<=0)break; buf[n]=0;
  if(crash_after&&done==crash_after)_exit(9); /* 模拟 worker 崩溃 */
  long x=atol(buf); char out[64]; int k=snprintf(out,sizeof out,"%ld",x*x); send_msg(fd,out,k); done++;}
 _exit(0);}
static void demo_tasks(int crash_after,const char*tag){int s[2];socketpair(AF_UNIX,SOCK_STREAM|SOCK_CLOEXEC,0,s);
 pid_t pid=fork(); if(pid==0){close(s[0]);worker(s[1],crash_after);} close(s[1]);
 int ok=0,eof=0,epipe=0; long sum=0;
 for(int i=1;i<=100;i++){char t[32];int k=snprintf(t,sizeof t,"%d",i);
  if(send_msg(s[0],t,k)){if(errno==EPIPE)epipe=1;break;}
  char r[64];uint32_t n;int rr=recv_msg(s[0],r,63,&n); if(rr==0){eof=1;break;} if(rr<0)break; r[n]=0; sum+=atol(r); ok++;}
 /* 对端已死时再写一次：忽略 SIGPIPE 后得到 EPIPE 而不是进程被杀 */
 if(eof){usleep(10000); if(send_msg(s[0],"1",1)&&errno==EPIPE)epipe=1;}
 close(s[0]); int st; waitpid(pid,&st,0);
 printf("%s ok=%d sum=%ld eof=%d epipe=%d child_exit=%d\n",tag,ok,sum,eof,epipe,WIFEXITED(st)?WEXITSTATUS(st):-1);}

/* 4. 共享内存：进程共享互斥锁+条件变量做同步 */
struct shm{pthread_mutex_t mu;pthread_cond_t cv;int ready;size_t len;uint64_t sum;char data[];};
static void demo_shm(size_t sz,double*t_shm,double*t_sock){
 struct shm*m=mmap(NULL,sizeof *m+sz,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,-1,0);
 pthread_mutexattr_t ma;pthread_mutexattr_init(&ma);pthread_mutexattr_setpshared(&ma,PTHREAD_PROCESS_SHARED);pthread_mutex_init(&m->mu,&ma);
 pthread_condattr_t ca;pthread_condattr_init(&ca);pthread_condattr_setpshared(&ca,PTHREAD_PROCESS_SHARED);pthread_cond_init(&m->cv,&ca);
 m->ready=0;
 pid_t pid=fork();
 if(pid==0){pthread_mutex_lock(&m->mu);while(m->ready!=1)pthread_cond_wait(&m->cv,&m->mu);
  uint64_t s=0;for(size_t i=0;i<m->len;i+=64)s+=(unsigned char)m->data[i]; m->sum=s;m->ready=2;
  pthread_cond_signal(&m->cv);pthread_mutex_unlock(&m->mu);_exit(0);}
 double t0=now(); memset(m->data,1,sz);
 pthread_mutex_lock(&m->mu);m->len=sz;m->ready=1;pthread_cond_signal(&m->cv);
 while(m->ready!=2)pthread_cond_wait(&m->cv,&m->mu); pthread_mutex_unlock(&m->mu);
 *t_shm=now()-t0; waitpid(pid,NULL,0);
 printf("shm_sum=%llu expect=%zu\n",(unsigned long long)m->sum,sz/64);
 /* 同样数据走 socket：多两次拷贝(用户->内核->用户) */
 int s[2];socketpair(AF_UNIX,SOCK_STREAM,0,s); pid=fork();
 if(pid==0){close(s[0]);char*b=malloc(1<<16);size_t got=0;uint64_t sm=0;ssize_t r;
  while((r=read(s[1],b,1<<16))>0){for(ssize_t i=0;i<r;i++)if(((got+i)&63)==0)sm+=(unsigned char)b[i];got+=r;}
  write_full(s[1],&sm,8);_exit(0);}
 close(s[1]); t0=now(); char*src=malloc(sz);memset(src,1,sz); write_full(s[0],src,sz); shutdown(s[0],SHUT_WR);
 uint64_t sm=0; read_full(s[0],&sm,8); *t_sock=now()-t0; waitpid(pid,NULL,0); close(s[0]); free(src);
 printf("sock_sum=%llu\n",(unsigned long long)sm); munmap(m,sizeof *m+sz);}

/* 5. 反例：共享内存无同步，两个进程各加 100 万次 */
static void demo_race(int locked){struct{pthread_mutex_t mu;volatile long c;}*m=mmap(NULL,4096,PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,-1,0);
 pthread_mutexattr_t ma;pthread_mutexattr_init(&ma);pthread_mutexattr_setpshared(&ma,PTHREAD_PROCESS_SHARED);pthread_mutex_init(&m->mu,&ma);m->c=0;
 pid_t p[2];for(int k=0;k<2;k++)if((p[k]=fork())==0){for(int i=0;i<1000000;i++){if(locked)pthread_mutex_lock(&m->mu);m->c++;if(locked)pthread_mutex_unlock(&m->mu);}_exit(0);}
 waitpid(p[0],NULL,0);waitpid(p[1],NULL,0); printf("%s counter=%ld expect=2000000\n",locked?"race_locked":"race_nolock",m->c); munmap(m,4096);}

int main(void){signal(SIGPIPE,SIG_IGN); setvbuf(stdout,NULL,_IONBF,0);
 demo_pipe(); demo_seqpacket(); demo_tasks(0,"tasks_normal"); demo_tasks(10,"tasks_crash");
 double a,b; demo_shm(256UL<<20,&a,&b); printf("bulk_256MB shm=%.3fs sock=%.3fs\n",a,b);
 demo_race(0); demo_race(1); return 0;}
