#!/usr/bin/env python3
"""验收用例：长尾分位数对比；分位数不可加；日志估算带单位与假设。"""
from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from math_tools import (
    demo_quantile_not_additive,
    estimate_log_storage,
    generate_latency_samples,
    percentile,
    summarize_latency,
)


def test_latency_mean_median_p99() -> None:
    """生成长尾样本，比较均值、中位数与 p99，并报告 n。"""
    samples = generate_latency_samples(10000, dist="lognormal", seed=42)
    s = summarize_latency(samples)
    assert s["n"] == 10000, s
    assert s["units"] == "ms"
    # 长尾：p99 应显著大于中位数；均值通常也 > 中位数
    assert s["p99_ms"] > s["median_ms"], s
    assert s["mean_ms"] > s["median_ms"], s
    # 与直接 percentile 一致
    assert math.isclose(s["p99_ms"], percentile(samples, 99))
    print(
        f"OK latency stats: n={s['n']} mean={s['mean_ms']:.2f} "
        f"median={s['median_ms']:.2f} p99={s['p99_ms']:.2f} {s['units']}"
    )

    # mixture 分布也应呈现长尾关系
    mix = summarize_latency(generate_latency_samples(8000, "mixture", seed=2))
    assert mix["p99_ms"] > mix["median_ms"]
    print(f"OK mixture: n={mix['n']} p99={mix['p99_ms']:.2f} median={mix['median_ms']:.2f}")


def test_quantile_not_additive() -> None:
    """验收：能解释分位数不能直接相加。"""
    demo = demo_quantile_not_additive(n=20000, seed=7)
    assert demo["n"] == 20000
    assert demo["gateway_p99_ms"] > 0 and demo["business_p99_ms"] > 0
    assert math.isclose(
        demo["sum_of_p99_ms"],
        demo["gateway_p99_ms"] + demo["business_p99_ms"],
    )
    # 核心断言：相加 ≠ 端到端真实 p99
    assert demo["equal"] is False
    assert not math.isclose(
        demo["sum_of_p99_ms"],
        demo["end_to_end_p99_ms"],
        rel_tol=1e-3,
        abs_tol=0.01,
    ), demo
    print(
        f"OK quantile not additive: "
        f"g_p99+b_p99={demo['sum_of_p99_ms']:.2f} "
        f"e2e_p99={demo['end_to_end_p99_ms']:.2f} "
        f"(n={demo['n']})"
    )


def test_log_storage_units_and_assumptions() -> None:
    """验收：容量估算明确单位与假设。"""
    est = estimate_log_storage(
        qps=5000,
        avg_bytes_per_log=800,
        retention_days=30,
        compression_ratio=0.3,
    )
    a = est["assumptions"]
    assert a["qps"] == 5000
    assert a["qps_unit"] == "requests/second"
    assert a["avg_bytes_per_log"] == 800
    assert a["avg_bytes_per_log_unit"] == "bytes/request"
    assert a["retention_days"] == 30
    assert a["retention_unit"] == "days"
    assert a["compression_ratio"] == 0.3

    expected_raw = 5000 * 800 * 86400 * 30
    assert math.isclose(est["raw"]["bytes"], expected_raw)
    assert math.isclose(est["stored"]["bytes"], expected_raw * 0.3)
    assert "GB" in est["raw"] and "TB" in est["raw"]
    assert "GiB" in est["raw"] and "TiB" in est["raw"]
    assert est["raw"]["GB"] == est["raw"]["bytes"] / 1e9
    assert "units_note" in est

    # 零保留 → 零存储
    z = estimate_log_storage(100, 100, 0)
    assert z["raw"]["bytes"] == 0

    print(
        f"OK log storage: raw_bytes={est['raw']['bytes']:.3e} "
        f"raw_TB={est['raw']['TB']:.2f} stored_TB={est['stored']['TB']:.2f} "
        f"assumptions={list(a.keys())}"
    )


def test_percentile_edges_and_small_n_reported() -> None:
    """小样本时 p99 仍可计算，但必须暴露 n（pitfalls）。"""
    xs = [10.0, 20.0, 30.0, 40.0, 100.0]
    p99 = percentile(xs, 99)
    # n=5 时 ceil(0.99*5)-1 = ceil(4.95)-1 = 5-1 = 4 → 100
    assert p99 == 100.0
    summary = summarize_latency(xs)
    assert summary["n"] == 5
    assert summary["p99_ms"] == 100.0
    print(f"OK small-n p99 reported with n={summary['n']} p99={summary['p99_ms']}")


def main() -> None:
    test_latency_mean_median_p99()
    test_quantile_not_additive()
    test_log_storage_units_and_assumptions()
    test_percentile_edges_and_small_n_reported()
    print("ALL_TESTS_PASSED")


if __name__ == "__main__":
    main()
