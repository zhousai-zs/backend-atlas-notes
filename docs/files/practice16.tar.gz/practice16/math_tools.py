#!/usr/bin/env python3
"""长尾延迟样本、分位数对比与日志容量估算。

对应 Backend Atlas 节点 a-math 实践：
- 生成长尾延迟样本，比较均值、中位数与 p99
- 演示分位数不能直接相加
- 估算日志存储量（明确单位与假设）
"""
from __future__ import annotations

import math
import random
import statistics
from typing import Any, Dict, List, Sequence, Tuple


def percentile(xs: Sequence[float], p: float) -> float:
    """经验分位数：p 为 0～100。

    使用「最近秩」：索引 = ceil(p/100 * n) - 1，夹在 [0, n-1]。
    小样本时偏保守（更靠近尾部），并要求调用方报告 n。
    """
    if not xs:
        raise ValueError("empty sample")
    if not 0.0 <= p <= 100.0:
        raise ValueError(f"p out of range: {p}")
    ordered = sorted(xs)
    n = len(ordered)
    if p == 0:
        return float(ordered[0])
    # ceil(p/100 * n) - 1
    rank = math.ceil(p / 100.0 * n)
    idx = min(n - 1, max(0, rank - 1))
    return float(ordered[idx])


def generate_latency_samples(
    n: int = 10000,
    dist: str = "lognormal",
    seed: int = 42,
) -> List[float]:
    """生成长尾延迟样本（单位：毫秒）。

    dist:
      - lognormal: 对数正态（常见延迟模型）
      - pareto: Pareto 重尾
      - mixture: 90% 快路径 + 10% 慢路径（模拟下游偶发超时）
    """
    if n <= 0:
        raise ValueError("n must be positive")
    rng = random.Random(seed)
    samples: List[float] = []

    if dist == "lognormal":
        # mu/sigma 取对数空间参数，使中位数约 e^3 ≈ 20ms，带长尾
        for _ in range(n):
            samples.append(rng.lognormvariate(3.0, 0.85))
    elif dist == "pareto":
        # xmin=10ms, alpha=1.5 → 均值存在但方差很大
        xm, alpha = 10.0, 1.5
        for _ in range(n):
            u = rng.random()
            samples.append(xm / (u ** (1.0 / alpha)))
    elif dist == "mixture":
        for _ in range(n):
            if rng.random() < 0.90:
                samples.append(rng.lognormvariate(2.5, 0.4))  # 快
            else:
                samples.append(rng.lognormvariate(5.5, 0.6))  # 慢尾
    else:
        raise ValueError(f"unknown dist: {dist}")

    return samples


def summarize_latency(samples: Sequence[float]) -> Dict[str, Any]:
    """比较均值、中位数与 p99，并报告样本数量。"""
    if not samples:
        raise ValueError("empty sample")
    n = len(samples)
    mean = float(statistics.mean(samples))
    median = float(statistics.median(samples))
    p99 = percentile(samples, 99)
    return {
        "n": n,
        "mean_ms": mean,
        "median_ms": median,
        "p99_ms": p99,
        "units": "ms",
    }


def demo_quantile_not_additive(
    n: int = 20000,
    seed: int = 7,
) -> Dict[str, Any]:
    """演示：两段延迟各自 p99 之和 ≠ 串联后真实 p99。

    构造正相关：同一请求共享一个「负载因子」，使尾部更容易叠在一起，
    同时仍可见「相加」与「真实端到端」的差异（一般情况下不相等）。
    """
    rng = random.Random(seed)
    gateway: List[float] = []
    business: List[float] = []
    end_to_end: List[float] = []

    for _ in range(n):
        # 共享负载因子 → 正相关（机房抖动时两段一起变慢）
        load = rng.lognormvariate(0.0, 0.5)
        g = rng.lognormvariate(2.8, 0.5) * load
        b = rng.lognormvariate(3.2, 0.55) * load
        gateway.append(g)
        business.append(b)
        end_to_end.append(g + b)

    g_p99 = percentile(gateway, 99)
    b_p99 = percentile(business, 99)
    sum_p99 = g_p99 + b_p99
    e2e_p99 = percentile(end_to_end, 99)

    return {
        "n": n,
        "gateway_p99_ms": g_p99,
        "business_p99_ms": b_p99,
        "sum_of_p99_ms": sum_p99,
        "end_to_end_p99_ms": e2e_p99,
        "equal": math.isclose(sum_p99, e2e_p99, rel_tol=1e-9, abs_tol=1e-6),
        "note": "分位数不能直接相加：sum_of_p99 与 end_to_end_p99 一般不相等",
        "units": "ms",
    }


def estimate_log_storage(
    qps: float,
    avg_bytes_per_log: float,
    retention_days: float,
    compression_ratio: float = 1.0,
    seconds_per_day: float = 86400.0,
) -> Dict[str, Any]:
    """估算日志存储量；返回原始/压缩体积，并附带假设与单位。

    compression_ratio: 存盘体积 / 原始体积，1.0 表示不压缩，0.3 表示压到 30%。
    """
    if qps < 0 or avg_bytes_per_log < 0 or retention_days < 0:
        raise ValueError("qps / avg_bytes_per_log / retention_days must be >= 0")
    if compression_ratio <= 0:
        raise ValueError("compression_ratio must be > 0")

    assumptions = {
        "qps": qps,
        "qps_unit": "requests/second",
        "avg_bytes_per_log": avg_bytes_per_log,
        "avg_bytes_per_log_unit": "bytes/request",
        "retention_days": retention_days,
        "retention_unit": "days",
        "seconds_per_day": seconds_per_day,
        "compression_ratio": compression_ratio,
        "compression_note": "stored_bytes = raw_bytes * compression_ratio",
    }

    raw_bytes = qps * avg_bytes_per_log * seconds_per_day * retention_days
    stored_bytes = raw_bytes * compression_ratio

    def _scale(b: float) -> Dict[str, float]:
        return {
            "bytes": b,
            "GB": b / (1000 ** 3),
            "GiB": b / (1024 ** 3),
            "TB": b / (1000 ** 4),
            "TiB": b / (1024 ** 4),
        }

    return {
        "assumptions": assumptions,
        "raw": _scale(raw_bytes),
        "stored": _scale(stored_bytes),
        "units_note": "GB/TB 用十进制(1000^n)；GiB/TiB 用二进制(1024^n)",
    }


def _self_check() -> None:
    samples = generate_latency_samples(5000, "lognormal", seed=1)
    summary = summarize_latency(samples)
    assert summary["n"] == 5000
    assert summary["p99_ms"] >= summary["median_ms"]
    assert summary["mean_ms"] > 0

    demo = demo_quantile_not_additive(8000, seed=3)
    assert demo["n"] == 8000
    assert not demo["equal"], "expected sum of p99 != e2e p99"

    est = estimate_log_storage(
        qps=5000,
        avg_bytes_per_log=800,
        retention_days=30,
        compression_ratio=0.3,
    )
    assert est["assumptions"]["qps"] == 5000
    assert est["raw"]["bytes"] == 5000 * 800 * 86400 * 30
    assert math.isclose(est["stored"]["bytes"], est["raw"]["bytes"] * 0.3)

    print("latency summary:", {k: (round(v, 2) if isinstance(v, float) else v) for k, v in summary.items()})
    print(
        "quantile demo:",
        {
            "sum_p99": round(demo["sum_of_p99_ms"], 2),
            "e2e_p99": round(demo["end_to_end_p99_ms"], 2),
            "equal": demo["equal"],
        },
    )
    print(
        "log storage:",
        f"raw_TB={est['raw']['TB']:.2f} stored_TB={est['stored']['TB']:.2f}",
    )
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    _self_check()
