#!/usr/bin/env python3
"""practice89 本地服务目录：POST /register /deregister，GET /endpoints?service=x -> {version, endpoints}"""
import argparse, json, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

LOCK = threading.Lock()
VERSION = 0
SERVICES = {}  # service -> set(addr)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlparse(self.path)
        if u.path != "/endpoints":
            return self._send(404, {"error": "not found"})
        svc = parse_qs(u.query).get("service", [""])[0]
        with LOCK:
            self._send(200, {"service": svc, "version": VERSION, "endpoints": sorted(SERVICES.get(svc, set()))})
    def do_POST(self):
        global VERSION
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}"); svc, addr = body["service"], body["addr"]
        except Exception:
            return self._send(400, {"error": "need service and addr"})
        with LOCK:
            s = SERVICES.setdefault(svc, set())
            if self.path == "/register":
                s.add(addr)
            elif self.path == "/deregister":
                s.discard(addr)
            else:
                return self._send(404, {"error": "not found"})
            VERSION += 1  # 每次变更单调递增
            self._send(200, {"version": VERSION, "endpoints": sorted(s)})

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--port", type=int, default=18089)
    a = ap.parse_args()
    print(f"directory listening :{a.port}", flush=True)
    ThreadingHTTPServer(("127.0.0.1", a.port), H).serve_forever()
