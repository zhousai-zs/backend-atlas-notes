#!/usr/bin/env python3
"""practice89 后端实例：按行协议。'PING' -> '<name>'，'SLOW s' -> 睡 s 秒后 '<name>'。
预热（--ready-delay）期间回复 'NOTREADY'。默认预热完成后才注册到目录；--register-early 演示误区：一启动就注册。"""
import argparse, json, socket, threading, time, urllib.request

def post(directory, path, obj):
    req = urllib.request.Request(f"http://{directory}{path}", data=json.dumps(obj).encode(),
                                 headers={"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(req, timeout=2))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, required=True); ap.add_argument("--name", default=None)
    ap.add_argument("--ready-delay", type=float, default=0); ap.add_argument("--directory", default=None)
    ap.add_argument("--service", default="storage"); ap.add_argument("--register-early", action="store_true")
    a = ap.parse_args(); name = a.name or f"b{a.port}"; addr = f"127.0.0.1:{a.port}"
    t0 = time.time(); ready = lambda: time.time() - t0 >= a.ready_delay
    ls = socket.socket(); ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    ls.bind(("127.0.0.1", a.port)); ls.listen(128)

    def serve(c):
        f = c.makefile("rwb")
        try:
            for line in f:
                cmd = line.decode().split()
                if not ready():
                    f.write(b"NOTREADY\n"); f.flush(); continue
                if cmd and cmd[0] == "SLOW":
                    time.sleep(float(cmd[1]))
                f.write((name + "\n").encode()); f.flush()
        except OSError:
            pass
        finally:
            c.close()

    def register():
        if not a.register_early:
            while not ready(): time.sleep(0.05)   # 正确做法：就绪后再注册
        post(a.directory, "/register", {"service": a.service, "addr": addr})
        print(f"{name} registered ready={ready()}", flush=True)
    if a.directory:
        threading.Thread(target=register, daemon=True).start()
    print(f"{name} listening {addr}", flush=True)
    while True:
        c, _ = ls.accept(); threading.Thread(target=serve, args=(c,), daemon=True).start()

if __name__ == "__main__":
    main()
