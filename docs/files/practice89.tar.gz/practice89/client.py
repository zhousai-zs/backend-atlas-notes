#!/usr/bin/env python3
"""practice89 带缓存的客户端发现：周期拉取目录，版本号检查，空列表策略，原子替换快照，
被摘除实例的连接在在途请求完成后才关闭（引用计数）。"""
import argparse, itertools, json, socket, sys, threading, time, urllib.request

def log(*a): print(time.strftime("%H:%M:%S"), *a, flush=True)

class Endpoint:
    def __init__(self, addr):
        self.addr = addr; self.lock = threading.Lock(); self.idle = []; self.inflight = 0
        self.closing = False; self.closed = False; self.inflight_at_remove = 0
    def acquire(self):
        with self.lock:
            if self.closing: return None          # 已摘除：不再分配新请求
            self.inflight += 1
            s = self.idle.pop() if self.idle else None
        if s is None:
            h, p = self.addr.split(":"); s = socket.create_connection((h, int(p)), timeout=3)
        return s
    def release(self, s, broken=False):
        with self.lock:
            self.inflight -= 1
            if broken or self.closing: s.close()
            else: self.idle.append(s)
            self._maybe_close()
    def retire(self):
        with self.lock:
            self.closing = True; self.inflight_at_remove = self.inflight
            log(f"removed addr={self.addr} inflight={self.inflight}")
            self._maybe_close()
    def _maybe_close(self):
        if self.closing and self.inflight == 0 and not self.closed:
            for s in self.idle: s.close()
            self.idle.clear(); self.closed = True
            log(f"closed addr={self.addr} closed_after_inflight={self.inflight_at_remove}")

class Resolver:
    def __init__(self, directory, service, empty_policy):
        self.url = f"http://{directory}/endpoints?service={service}"; self.policy = empty_policy
        self.lock = threading.Lock(); self.version = -1; self.snapshot = ()   # 不可变元组，原子替换
        self.eps = {}; self.degraded = False; self.rr = itertools.count()
    def apply(self, version, addrs):
        with self.lock:
            if version == self.version: return       # 没变化
            if version < self.version:               # 乱序到达的旧版本
                log(f"stale_update ignored version={version} current={self.version}"); return
            if not addrs and self.policy == "keep" and self.snapshot:
                if not self.degraded: log(f"empty endpoints degraded=1 keep_last={len(self.snapshot)}")
                self.degraded = True; self.version = version; return
            self.degraded = False
            new = {a: self.eps.get(a) or Endpoint(a) for a in addrs}
            removed = [e for a, e in self.eps.items() if a not in new]
            self.eps = new; self.snapshot = tuple(new.values()); self.version = version
        log(f"update version={version} endpoints={','.join(addrs) or '-'}")
        for e in removed: e.retire()   # 在锁外摘除；正在用的连接不被立即销毁
    def poll_once(self):
        try:
            d = json.load(urllib.request.urlopen(self.url, timeout=1))
            self.apply(d["version"], d["endpoints"])
        except Exception as ex:
            log(f"directory error {type(ex).__name__}: keep cache version={self.version}")
    def pick(self):
        snap = self.snapshot
        if not snap: raise RuntimeError("UNAVAILABLE: no endpoints")
        for _ in range(len(snap)):
            e = snap[next(self.rr) % len(snap)]
            s = e.acquire() if not e.closing else None
            if s: return e, s
        raise RuntimeError("UNAVAILABLE: all endpoints retiring")

def call(res, cmd):
    e, s = res.pick(); broken = False
    try:
        s.sendall((cmd + "\n").encode()); buf = b""
        while not buf.endswith(b"\n"):
            chunk = s.recv(64)
            if not chunk: raise ConnectionError("eof")
            buf += chunk
        return e.addr, buf.decode().strip()
    except Exception:
        broken = True; raise
    finally:
        e.release(s, broken)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--directory", default="127.0.0.1:18089"); ap.add_argument("--service", default="storage")
    ap.add_argument("--empty-policy", choices=["keep", "fail"], default="keep")
    ap.add_argument("--interval", type=float, default=0.2); ap.add_argument("--duration", type=float, default=10)
    ap.add_argument("--workers", type=int, default=4); ap.add_argument("--slow", type=float, default=0.4)
    a = ap.parse_args()
    res = Resolver(a.directory, a.service, a.empty_policy); stop = time.time() + a.duration
    stats = {"ok": 0, "unavailable": 0, "conn_error": 0, "notready": 0}; sl = threading.Lock()
    def poller():
        while time.time() < stop: res.poll_once(); time.sleep(a.interval)
    def worker():
        while time.time() < stop:
            try:
                addr, r = call(res, f"SLOW {a.slow}")
                k = "notready" if r == "NOTREADY" else "ok"
                if k == "notready": log(f"notready addr={addr}"); time.sleep(0.05)
            except RuntimeError as ex:
                k = "unavailable"; log(f"call failed {ex}"); time.sleep(0.2)
            except Exception as ex:
                k = "conn_error"; log(f"conn_error {type(ex).__name__}"); time.sleep(0.1)
            with sl: stats[k] += 1
    res.poll_once()
    ts = [threading.Thread(target=poller, daemon=True)] + [threading.Thread(target=worker, daemon=True) for _ in range(a.workers)]
    for t in ts: t.start()
    for t in ts: t.join()
    log("summary " + " ".join(f"{k}={v}" for k, v in stats.items()))

if __name__ == "__main__":
    main()
