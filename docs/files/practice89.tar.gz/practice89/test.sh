#!/usr/bin/env bash
# practice89 自动验收
set -u
cd "$(dirname "$0")"
D=127.0.0.1:18089; fail=0; PIDS=()
ok(){ echo "PASS: $1"; }; bad(){ echo "FAIL: $1"; fail=1; }
reg(){ curl -s -X POST $D/$1 -H 'Content-Type: application/json' -d "{\"service\":\"storage\",\"addr\":\"127.0.0.1:$2\"}" >/dev/null; }
cleanup(){ for p in "${PIDS[@]}"; do kill $p 2>/dev/null; done; wait 2>/dev/null; }
trap cleanup EXIT
python3 directory.py --port 18089 >/tmp/p89dir.log 2>&1 & PIDS+=($!)
for i in $(seq 50); do curl -s "$D/endpoints?service=storage" >/dev/null && break; sleep 0.1; done
for p in 18189 18190 18191; do python3 backend.py --port $p >/tmp/p89b$p.log 2>&1 & PIDS+=($!); done
sleep 0.5
reg register 18189; reg register 18190
j=$(curl -s "$D/endpoints?service=storage"); echo "  $j"
echo "$j" | grep -q '"endpoints": \["127.0.0.1:18189", "127.0.0.1:18190"\]' && ok "注册两个实例" || bad "注册 $j"

# 场景 A：keep 策略，扩容、缩容、全部摘除、恢复
python3 client.py --empty-policy keep --duration 7 >/tmp/p89a.log 2>&1 & C=$!
sleep 1;   reg register 18191        # 扩容
sleep 1;   reg deregister 18189      # 缩容
sleep 1.5; reg deregister 18190; reg deregister 18191   # 空端点
sleep 1.5; reg register 18190        # 恢复
wait $C; cat /tmp/p89a.log | grep -v '^.\{8\} \(notready\)' | grep -E 'update|removed|closed|degraded|summary' | sed 's/^/  /'
grep -q 'endpoints=127.0.0.1:18189,127.0.0.1:18190,127.0.0.1:18191' /tmp/p89a.log && ok "扩容后客户端拿到 3 个实例" || bad "扩容"
grep -q 'closed addr=127.0.0.1:18189 closed_after_inflight=[1-9]' /tmp/p89a.log && ok "更新不销毁正在使用的对象：在途请求完成后才关闭旧连接" || bad "缩容 drain"
grep -q 'degraded=1' /tmp/p89a.log && ok "空端点时受控降级（keep 最后已知列表）" || bad "keep 降级"
grep -q 'endpoints=127.0.0.1:18190$' /tmp/p89a.log && ok "恢复后客户端切回新列表" || bad "恢复"
grep -q 'summary.*conn_error=0' /tmp/p89a.log && ok "全程无连接错误" || bad "出现连接错误: $(grep summary /tmp/p89a.log)"

# 场景 B：fail 策略
reg deregister 18190
python3 client.py --empty-policy fail --duration 1.5 >/tmp/p89b.log 2>&1
grep -q 'UNAVAILABLE' /tmp/p89b.log && grep -q 'summary ok=0' /tmp/p89b.log && ok "空端点时明确失败 UNAVAILABLE" || bad "fail 策略"

# 场景 C：注册成功不代表就绪
python3 backend.py --port 18192 --ready-delay 1.5 --directory $D --register-early >/tmp/p89e.log 2>&1 & PIDS+=($!)
sleep 0.3; python3 client.py --duration 1 --slow 0.05 >/tmp/p89c.log 2>&1
grep -q 'notready=[1-9]' /tmp/p89c.log && ok "反例：一启动就注册，预热期收到 NOTREADY ($(grep -o 'notready=[0-9]*' /tmp/p89c.log))" || bad "反例未复现"
reg deregister 18192
python3 backend.py --port 18193 --ready-delay 1.5 --directory $D >/tmp/p89f.log 2>&1 & PIDS+=($!)
sleep 0.3; python3 client.py --empty-policy fail --duration 2.5 --slow 0.05 >/tmp/p89d.log 2>&1
grep -q 'notready=0' /tmp/p89d.log && grep -q 'ok=[1-9]' /tmp/p89d.log && ok "就绪后才注册：0 个 NOTREADY" || bad "就绪注册 $(grep summary /tmp/p89d.log)"

# 场景 D：乱序旧版本被丢弃
python3 - <<'PY' && ok "旧版本更新被丢弃" || bad "版本检查"
import client
r = client.Resolver("x", "s", "keep"); r.apply(5, ["127.0.0.1:1"]); r.apply(3, [])
assert r.version == 5 and len(r.snapshot) == 1
PY
[ $fail = 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
