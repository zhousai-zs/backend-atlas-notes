#!/usr/bin/env python3
import argparse, json, threading, urllib.request, urllib.error, uuid

def post(port, key, body, user="u1"):
    req = urllib.request.Request(f"http://127.0.0.1:{port}/tasks", data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "Idempotency-Key": key, "X-User": user})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--port", type=int, default=18088)
    ap.add_argument("--concurrency", type=int, default=20); ap.add_argument("--same-key", action="store_true")
    a = ap.parse_args()
    shared = str(uuid.uuid4()); results = []; lock = threading.Lock()
    def work():
        k = shared if a.same_key else str(uuid.uuid4())
        s, b = post(a.port, k, {"title": "群发任务", "payload": {"article": 42}})
        with lock: results.append((s, b.get("task_id")))
    ts = [threading.Thread(target=work) for _ in range(a.concurrency)]
    [t.start() for t in ts]; [t.join() for t in ts]
    with urllib.request.urlopen(f"http://127.0.0.1:{a.port}/stats") as r:
        n = json.loads(r.read())["tasks_in_db"]
    ids = {t for s, t in results if t}
    print(f"statuses={sorted(set(s for s,_ in results))} distinct_task_ids={len(ids)} tasks_in_db={n}")

if __name__ == "__main__":
    main()
