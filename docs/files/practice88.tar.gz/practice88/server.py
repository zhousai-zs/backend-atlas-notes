#!/usr/bin/env python3
"""practice88: 带幂等键的创建任务接口（只用标准库）。
POST /tasks  头 Idempotency-Key  body {"title":..,"payload":..}
幂等记录与业务写入在同一个 sqlite 事务里原子提交。"""
import argparse, hashlib, json, os, sqlite3, sys, threading, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

TTL_SECONDS = 24 * 3600

def fingerprint(body: dict) -> str:
    canon = json.dumps({"title": body.get("title"), "payload": body.get("payload")},
                       sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(canon.encode()).hexdigest()

def init_db(path):
    c = sqlite3.connect(path)
    c.executescript("""
    PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, owner TEXT, title TEXT, payload TEXT, created_at REAL);
    CREATE TABLE IF NOT EXISTS idempotency_keys(
      scope TEXT, key TEXT, fingerprint TEXT, status TEXT, response TEXT,
      created_at REAL, expires_at REAL, PRIMARY KEY(scope, key));
    """)
    c.close()

def handle_create(db, owner, key, body):
    """返回 (http_status, response_dict)。"""
    scope = f"{owner}:create_task"
    fp = fingerprint(body)
    conn = sqlite3.connect(db, timeout=10, isolation_level=None)
    try:
        conn.execute("BEGIN IMMEDIATE")          # 拿写锁：同库并发写串行化
        row = conn.execute("SELECT fingerprint,status,response,expires_at FROM idempotency_keys "
                           "WHERE scope=? AND key=?", (scope, key)).fetchone()
        now = time.time()
        if row and row[3] < now:                 # 过期：按契约视为新请求
            conn.execute("DELETE FROM idempotency_keys WHERE scope=? AND key=?", (scope, key))
            row = None
        if row:
            conn.execute("COMMIT")
            if row[0] != fp:
                return 422, {"error": "idempotency key reused with different parameters"}
            return 201, json.loads(row[2])       # 重放：返回首次结果
        task_id = str(uuid.uuid4())
        conn.execute("INSERT INTO tasks VALUES(?,?,?,?,?)",
                     (task_id, owner, body.get("title"), json.dumps(body.get("payload")), now))
        if os.environ.get("CRASH_AFTER_BUSINESS") == "1":
            print("simulated crash before commit", file=sys.stderr, flush=True)
            os._exit(1)                          # 未提交 -> 事务随进程消失
        resp = {"task_id": task_id}
        conn.execute("INSERT INTO idempotency_keys VALUES(?,?,?,?,?,?,?)",
                     (scope, key, fp, "DONE", json.dumps(resp), now, now + TTL_SECONDS))
        conn.execute("COMMIT")                   # 业务 + 幂等记录 一起提交
        return 201, resp
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        if self.path != "/tasks":
            return self._send(404, {"error": "not found"})
        key = self.headers.get("Idempotency-Key")
        if not key:
            return self._send(400, {"error": "missing Idempotency-Key"})
        owner = self.headers.get("X-User", "u1")
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        except ValueError:
            return self._send(400, {"error": "bad json"})
        code, resp = handle_create(self.server.db, owner, key, body)
        self._send(code, resp)
    def do_GET(self):
        if self.path == "/stats":
            c = sqlite3.connect(self.server.db)
            n = c.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]; c.close()
            return self._send(200, {"tasks_in_db": n})
        self._send(404, {"error": "not found"})

def main(handler=H):
    ap = argparse.ArgumentParser(); ap.add_argument("--port", type=int, default=18088)
    ap.add_argument("--db", default="tasks.db"); a = ap.parse_args()
    init_db(a.db)
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", a.port), handler)
    except OSError as e:
        print(f"bind failed: {e}", file=sys.stderr); sys.exit(2)
    srv.db = a.db
    print(f"LISTEN :{a.port} db={a.db}", flush=True)
    srv.serve_forever()

if __name__ == "__main__":
    main()
