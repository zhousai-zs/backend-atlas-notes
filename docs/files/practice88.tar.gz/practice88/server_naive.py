#!/usr/bin/env python3
"""反例：先查键 -> 执行业务 -> 再记键（无事务、无唯一抢占），并发下会重复创建。"""
import json, sqlite3, time, uuid
import server

def naive_create(db, owner, key, body):
    scope = f"{owner}:create_task"
    conn = sqlite3.connect(db, timeout=10)
    row = conn.execute("SELECT response FROM idempotency_keys WHERE scope=? AND key=?", (scope, key)).fetchone()
    if row:
        conn.close(); return 201, json.loads(row[0])
    time.sleep(0.2)                       # 放大"查完到记键"之间的窗口
    task_id = str(uuid.uuid4())
    conn.execute("INSERT INTO tasks VALUES(?,?,?,?,?)", (task_id, owner, body.get("title"), json.dumps(body.get("payload")), time.time()))
    conn.commit()
    resp = {"task_id": task_id}
    conn.execute("INSERT OR REPLACE INTO idempotency_keys VALUES(?,?,?,?,?,?,?)",
                 (scope, key, server.fingerprint(body), "DONE", json.dumps(resp), time.time(), time.time() + 3600))
    conn.commit(); conn.close()
    return 201, resp

server.handle_create = naive_create
if __name__ == "__main__":
    server.main()
