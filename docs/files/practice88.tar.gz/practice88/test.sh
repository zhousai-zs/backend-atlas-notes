#!/usr/bin/env bash
# practice88 自动验收
set -u
cd "$(dirname "$0")"
PORT=18088; fail=0
ok(){ echo "PASS: $1"; }; bad(){ echo "FAIL: $1"; fail=1; }
start(){ rm -f "$2" "$2"-wal "$2"-shm; python3 "$1" --port $PORT --db "$2" >/tmp/p88.log 2>&1 & PID=$!; for i in $(seq 50); do curl -s localhost:$PORT/stats >/dev/null && return; sleep 0.1; done; }
stop(){ kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
req(){ curl -s -o /tmp/p88.body -w '%{http_code}' -X POST localhost:$PORT/tasks -H "Idempotency-Key: $1" -H 'Content-Type: application/json' -d "$2"; }

start server.py t1.db
c=$(req k1 '{"title":"A","payload":1}'); id1=$(python3 -c 'import json;print(json.load(open("/tmp/p88.body"))["task_id"])')
[ "$c" = 201 ] && ok "首次创建 201" || bad "首次创建 $c"
c=$(req k1 '{"payload":1,"title":"A"}'); id2=$(python3 -c 'import json;print(json.load(open("/tmp/p88.body")).get("task_id"))')
[ "$c" = 201 ] && [ "$id1" = "$id2" ] && ok "重放（字段顺序不同）返回同一 task_id" || bad "重放 $c $id2"
c=$(req k1 '{"title":"B","payload":1}'); [ "$c" = 422 ] && ok "同键不同参数被拒绝 422" || bad "同键不同参数 $c"
c=$(curl -s -o /dev/null -w '%{http_code}' -X POST localhost:$PORT/tasks -d '{}'); [ "$c" = 400 ] && ok "缺键 400" || bad "缺键 $c"
out=$(python3 client.py --port $PORT --concurrency 20 --same-key); echo "  $out"
echo "$out" | grep -q 'distinct_task_ids=1 tasks_in_db=2' && ok "20 并发同键只产生 1 个任务" || bad "并发同键"
stop

start server_naive.py t2.db
out=$(python3 client.py --port $PORT --concurrency 20 --same-key); echo "  naive: $out"
n=$(echo "$out" | sed -n 's/.*tasks_in_db=\([0-9]*\).*/\1/p')
[ "${n:-0}" -gt 1 ] && ok "反例：先查后做后记键 并发下重复创建 $n 个" || bad "反例未复现"
stop

rm -f t3.db*; CRASH_AFTER_BUSINESS=1 python3 server.py --port $PORT --db t3.db >/tmp/p88c.log 2>&1 & PID=$!
for i in $(seq 50); do curl -s localhost:$PORT/stats >/dev/null && break; sleep 0.1; done
c=$(req kc '{"title":"C","payload":3}'); wait $PID 2>/dev/null
[ "$c" != 201 ] && ok "模拟提交前崩溃，请求失败（$c）" || bad "崩溃未生效"
python3 server.py --port $PORT --db t3.db >/tmp/p88.log 2>&1 & PID=$!
for i in $(seq 50); do curl -s localhost:$PORT/stats >/dev/null && break; sleep 0.1; done
c=$(req kc '{"title":"C","payload":3}'); a=$(python3 -c 'import json;print(json.load(open("/tmp/p88.body"))["task_id"])')
req kc '{"title":"C","payload":3}' >/dev/null; b=$(python3 -c 'import json;print(json.load(open("/tmp/p88.body"))["task_id"])')
n=$(curl -s localhost:$PORT/stats | python3 -c 'import json,sys;print(json.load(sys.stdin)["tasks_in_db"])')
[ "$c" = 201 ] && [ "$a" = "$b" ] && [ "$n" = 1 ] && ok "崩溃恢复后重试只建 1 个任务且重放一致" || bad "崩溃恢复 c=$c n=$n"
python3 server.py --port $PORT --db t3.db >/dev/null 2>&1; [ $? = 2 ] && ok "端口占用 rc=2" || bad "端口占用"
stop
rm -f t1.db* t2.db* t3.db*
[ $fail = 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
