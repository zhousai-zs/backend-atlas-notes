#!/usr/bin/env python3
"""Two official SDK clients against one MCPServer. FastMCP is not used."""

from __future__ import annotations

import asyncio
import importlib.metadata
import json
from pathlib import Path

from mcp import Client
from mcp.shared.exceptions import MCPError
from mcp.shared.inbound import classify_inbound_request
from mcp.shared.memory import create_client_server_memory_streams
from mcp.shared.message import SessionMessage
from mcp.types.version import KNOWN_PROTOCOL_VERSIONS, LATEST_MODERN_VERSION, MODERN_PROTOCOL_VERSIONS
from mcp.types import Implementation, JSONRPCRequest

from server import STORE, build_server

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

SDK = importlib.metadata.version("mcp")
assert SDK == "2.3.0"
assert LATEST_MODERN_VERSION == "2026-07-28"
assert "2026-07-28" in list(KNOWN_PROTOCOL_VERSIONS)

# FastMCP must not import on mcp 2.x
fastmcp_error = None
try:
    from mcp.server.fastmcp import FastMCP  # noqa: F401
    fastmcp_imported = True
except Exception as e:
    fastmcp_imported = False
    fastmcp_error = f"{type(e).__name__}: {e}"
assert fastmcp_imported is False
assert "MCPServer" in (fastmcp_error or "")


def _text(result) -> str:
    return "".join(getattr(c, "text", "") or "" for c in (result.content or []))


async def call_as(server, name: str, fn):
    async with Client(server, client_info=Implementation(name=name, version="1.0")) as client:
        proto = client.session.protocol_version
        tools = await client.list_tools()
        tool_names = [t.name for t in tools.tools]
        guide = await client.read_resource("resource://guide")
        return await fn(client, {"protocol": proto, "tools": tool_names, "guide": str(guide)})


async def unsupported_version_on_wire(server) -> dict:
    actual = server._lowlevel_server
    async with create_client_server_memory_streams() as (client_streams, server_streams):
        cr, cw = client_streams
        sr, sw = server_streams

        async def run():
            await actual.run(sr, sw, actual.create_initialization_options(), raise_exceptions=False)

        task = asyncio.create_task(run())
        await asyncio.sleep(0.05)
        req = JSONRPCRequest.model_validate(
            {
                "jsonrpc": "2.0",
                "id": 7,
                "method": "tools/list",
                "params": {
                    "_meta": {
                        "io.modelcontextprotocol/protocolVersion": "1999-01-01",
                        "io.modelcontextprotocol/clientCapabilities": {},
                        "io.modelcontextprotocol/clientInfo": {"name": "probe", "version": "0"},
                    }
                },
            }
        )
        await cw.send(SessionMessage(message=req))
        msg = await asyncio.wait_for(cr.receive(), timeout=2)
        err = msg.message.error
        await cw.aclose()
        await sw.aclose()
        await asyncio.sleep(0.05)
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass
        return {"code": err.code, "message": err.message, "data": err.data}


async def main():
    server = build_server()

    async def alice_flow(client, meta):
        shared = await client.call_tool("kv_get", {"key": "shared"})
        priv = await client.call_tool("kv_get", {"key": "alice-private"})
        missing = await client.call_tool("kv_get", {})
        return {
            **meta,
            "shared": {"is_error": shared.is_error, "text": _text(shared), "structured": shared.structured_content},
            "private": {"is_error": priv.is_error, "text": _text(priv), "structured": priv.structured_content},
            "missing_params": {"is_error": missing.is_error, "text": _text(missing)[:400]},
        }

    async def bob_flow(client, meta):
        shared = await client.call_tool("kv_get", {"key": "shared"})
        try:
            priv = await client.call_tool("kv_get", {"key": "alice-private"})
            private = {"is_error": priv.is_error, "text": _text(priv)[:400], "rpc_error": None}
        except MCPError as e:
            # Authorization is a JSON-RPC request error, not a successful tool result.
            private = {
                "is_error": True,
                "text": e.message,
                "rpc_error": {"code": e.code, "message": e.message},
            }
        return {
            **meta,
            "shared": {"is_error": shared.is_error, "text": _text(shared), "structured": shared.structured_content},
            "private": private,
        }

    alice = await call_as(server, "alice-client", alice_flow)
    bob = await call_as(server, "bob-client", bob_flow)

    assert alice["protocol"] == "2026-07-28" and bob["protocol"] == "2026-07-28"
    assert "kv_get" in alice["tools"] and "kv_get" in bob["tools"]
    # Listing is the same; authorization is not.
    assert alice["shared"]["is_error"] is False and alice["shared"]["text"] == STORE["shared"]
    assert bob["shared"]["is_error"] is False and bob["shared"]["text"] == STORE["shared"]
    assert alice["shared"]["text"] == bob["shared"]["text"] == "kv-shared-ok"
    assert alice["private"]["is_error"] is False and alice["private"]["text"] == STORE["alice-private"]
    assert bob["private"]["is_error"] is True and "unauthorized" in bob["private"]["text"]
    assert alice["missing_params"]["is_error"] is True
    assert "Field required" in alice["missing_params"]["text"] or "key" in alice["missing_params"]["text"].lower()

    wire = await unsupported_version_on_wire(server)
    assert wire["code"] == -32022
    assert wire["data"]["requested"] == "1999-01-01"
    assert "2026-07-28" in wire["data"]["supported"]

    # Official classifier agrees, including a handshake-era version on the modern path.
    body = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/list",
        "params": {
            "_meta": {
                "io.modelcontextprotocol/protocolVersion": "2025-11-25",
                "io.modelcontextprotocol/clientCapabilities": {},
            }
        },
    }
    classified = classify_inbound_request(body)
    assert classified.code == -32022
    assert classified.data["requested"] == "2025-11-25"

    results = {
        "lesson": 171,
        "id": "l-mcp",
        "sdk": "mcp",
        "sdk_version": SDK,
        "server_class": "MCPServer",
        "fastmcp_imported": False,
        "fastmcp_error": fastmcp_error[:240],
        "migration": "https://py.sdk.modelcontextprotocol.io/v2/migration/",
        "protocol_latest_modern": LATEST_MODERN_VERSION,
        "known_protocol_versions": list(KNOWN_PROTOCOL_VERSIONS),
        "modern_protocol_versions": list(MODERN_PROTOCOL_VERSIONS),
        "transport": "create_client_server_memory_streams / Client(MCPServer) in-process",
        "alice": alice,
        "bob": bob,
        "same_business_result_on_shared_key": alice["shared"]["text"] == bob["shared"]["text"],
        "listing_tools_is_not_authorization": True,
        "missing_params_is_error": True,
        "unsupported_version_live": wire,
        "handshake_era_on_modern_path": {
            "requested": "2025-11-25",
            "code": classified.code,
            "message": classified.message,
            "data": classified.data,
            "note": "2025-11-25 is a known handshake-era version; the 2026-07-28 per-request envelope rejects it with UNSUPPORTED_PROTOCOL_VERSION. Old initialize-handshake examples are not interchangeable.",
        },
        "tool_calling_vs_mcp": {
            "tool_calling": "model-facing structured intent (e.g. OpenAI tools/call_id) inside one app",
            "mcp": "application protocol between a host/client and an external server, with its own version, discovery, and authorization",
        },
        "verified_on_this_machine": [
            "mcp_2_3_0_MCPServer_two_clients_memory_transport",
            "shared_key_same_result_private_key_authorized_per_client",
            "missing_params_and_unsupported_version_are_explicit_errors",
            "listing_kv_get_does_not_authorize_alice_private_for_bob",
        ],
        "not_verified_on_this_machine": [
            "remote_HTTP_authorization_with_OAuth",
            "legacy_handshake_clients_beyond_the_classifier_and_error_path_shown",
        ],
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
    (REPORTS / "mcp.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(json.dumps(
        {
            "sdk": SDK,
            "protocol": alice["protocol"],
            "shared": alice["shared"]["text"],
            "bob_private_error": bob["private"]["is_error"],
            "unsupported": wire,
        },
        indent=2,
    ))
    print("ALL_CHECKS_PASSED")


asyncio.run(main())
