#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["sdk_version"]=="2.3.0" and r["server_class"]=="MCPServer" and r["fastmcp_imported"] is False
assert r["protocol_latest_modern"]=="2026-07-28"
assert r["same_business_result_on_shared_key"] is True
assert r["listing_tools_is_not_authorization"] is True
assert r["alice"]["private"]["is_error"] is False
assert r["bob"]["private"]["is_error"] is True
assert r["unsupported_version_live"]["code"]==-32022
assert r["handshake_era_on_modern_path"]["requested"]=="2025-11-25"
print("POSTCHECK_OK")
PY
