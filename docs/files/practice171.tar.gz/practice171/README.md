# practice171 — MCP 角色与协议

官方 mcp 2.3.0 的 MCPServer（FastMCP 已更名），内存传输，双客户端。列出工具不等于授权。现场验证 -32022 与缺参错误。

```bash
bash test.sh
```
