"""Official mcp 2.3.0 MCPServer (FastMCP was renamed). In-process memory transport."""

from __future__ import annotations

from mcp.server import MCPServer
from mcp.server.mcpserver import Context
from mcp.shared.exceptions import MCPError
from mcp_types.jsonrpc import INVALID_REQUEST

STORE = {
    "shared": "kv-shared-ok",
    "alice-private": "kv-alice-ok",
}

# Authorization is server-side and key-scoped. Seeing kv_get in tools/list is not a grant.
ACL = {
    "alice-client": {"shared", "alice-private"},
    "bob-client": {"shared"},
}

GUIDE = (
    "Read-only KV. Call kv_get with a key in your tenant scope. "
    "Listing the tool does not authorize a key."
)


def _client_name(ctx: Context) -> str:
    info = (ctx.request_context.meta or {}).get("io.modelcontextprotocol/clientInfo") or {}
    name = info.get("name")
    if not name and getattr(ctx.session, "client_params", None):
        name = getattr(ctx.session.client_params.client_info, "name", None)
    return name or ""


def build_server() -> MCPServer:
    server = MCPServer("kv-reader", version="2.3.0")

    @server.tool(description="Read-only KV lookup. Authorization is enforced per key.")
    async def kv_get(key: str, ctx: Context) -> str:
        who = _client_name(ctx)
        allowed = ACL.get(who, set())
        if key not in allowed:
            raise MCPError(
                INVALID_REQUEST,
                f"unauthorized: {who or 'unknown'} cannot read key {key!r}",
            )
        if key not in STORE:
            raise MCPError(INVALID_REQUEST, f"unknown key {key!r}")
        return STORE[key]

    @server.resource("resource://guide", description="How to use the KV tool")
    def guide() -> str:
        return GUIDE

    return server
