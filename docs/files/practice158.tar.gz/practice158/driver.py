#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
from attention import positions, self_attention, self_attention_causal

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

rng = np.random.default_rng(0)
# four token embeddings in d=4, plus learned-looking projection
# tokens: [QUERY, HOST, DISK] then add CONTEXT "full"
vocab = {
    "query": np.array([1.0, 0.2, 0.0, 0.1]),
    "host":  np.array([0.2, 1.0, 0.1, 0.0]),
    "disk":  np.array([0.0, 0.2, 1.0, 0.2]),
    "full":  np.array([0.1, 0.0, 0.4, 1.0]),
}
wq = rng.normal(0, 0.5, (4, 4))
wk = rng.normal(0, 0.5, (4, 4))
wv = rng.normal(0, 0.5, (4, 4))

def run(names):
    x = np.stack([vocab[n] for n in names]) + positions(len(names), 4)
    scores, weights, out = self_attention(x, wq, wk, wv)
    return {"tokens": names, "weights": weights.round(4).tolist(), "out0": out[0].round(4).tolist()}

short = run(["query", "host"])
long = run(["query", "host", "disk", "full"])
# output of the query token changes after context is added
changed = short["out0"] != long["out0"]

# training-style parallel (teacher forcing, all positions at once) vs generation serial
names = ["query", "host", "disk", "full"]
x = np.stack([vocab[n] for n in names]) + positions(4, 4)
_, w_par, out_par = self_attention_causal(x, wq, wk, wv)
# autoregressive: grow the prefix one token at a time
serial_outs = []
for t in range(1, 5):
    xt = x[:t]
    _, _, ot = self_attention_causal(xt, wq, wk, wv)
    serial_outs.append(ot[-1].round(6).tolist())
results = {
    "lesson": 158,
    "id": "k-transformer",
    "is_live_model": False,
    "d_model": 4,
    "short": short,
    "long": long,
    "query_output_changed_with_context": changed,
    "parallel_last": out_par[-1].round(4).tolist(),
    "serial_last": serial_outs[-1],
    "serial_matches_parallel_given_same_inputs": bool(np.allclose(out_par[-1], np.array(serial_outs[-1]), atol=1e-5)),
    "generation_is_serial": True,
    "training_can_be_parallel_teacher_forced": True,
    "attention_weights_are_not_a_causal_explanation": True,
    "parameter_memory_vs_retrieval": {
        "parameters_store_patterns": True,
        "this_example_has_no_external_index": True,
        "retrieval_would_be_a_separate_system": True,
    },
    "numpy": np.__version__,
}
assert changed
assert results["serial_matches_parallel_given_same_inputs"]
(ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
(REPORTS / "weights.txt").write_text(json.dumps({"short": short, "long": long}, indent=2))
print(json.dumps(results, indent=2))
print("ALL_CHECKS_PASSED")
