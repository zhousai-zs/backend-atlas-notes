"""Minimal self-attention for teaching. Not a trained Transformer."""
from __future__ import annotations

import numpy as np


def softmax(x, axis=-1):
    z = x - np.max(x, axis=axis, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=axis, keepdims=True)


def positions(n, d, scale=0.15):
    # simple even/odd sinusoid, not a claimed official implementation
    p = np.zeros((n, d))
    for i in range(n):
        for k in range(d):
            p[i, k] = np.sin((i + 1) * (k + 1) * scale)
    return p


def self_attention(x, wq, wk, wv):
    q, k, v = x @ wq, x @ wk, x @ wv
    d = q.shape[-1]
    scores = (q @ k.T) / np.sqrt(d)
    weights = softmax(scores)
    out = weights @ v
    return scores, weights, out


def causal_mask(n):
    m = np.triu(np.ones((n, n)) * -1e9, k=1)
    return m


def self_attention_causal(x, wq, wk, wv):
    q, k, v = x @ wq, x @ wk, x @ wv
    d = q.shape[-1]
    scores = (q @ k.T) / np.sqrt(d) + causal_mask(len(x))
    weights = softmax(scores)
    out = weights @ v
    return scores, weights, out
