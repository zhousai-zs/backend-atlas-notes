#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert "2026-11-15T16:03:00Z" in r["missing_ts"]
assert r["sampling_gap_not_treated_as_zero"] and r["naive_zero_counterexample"]["value"]==0
assert r["next_verification"]=="lock_wait_ms"
assert r["observation_vs_inference_separated"]
print("POSTCHECK_OK")
PY
