#!/usr/bin/env python3
"""Metrics investigation: sampling gaps are not zero load; observation vs inference.

A lock-contention-like pattern is injected. The scripted agent must choose a
next verification rather than treat correlation as causation.
"""
from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
ROOT = Path(__file__).resolve().parent
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)

DATA = json.loads((ROOT / "data/metrics.json").read_text(encoding="utf-8"))
STEP = DATA["step_s"]


def parse(ts: str) -> datetime:
    return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def query_range(metric: str, start: str, end: str) -> dict:
    t0, t1 = parse(start), parse(end)
    points = []
    for p in DATA["points"]:
        ts = parse(p["ts"])
        if t0 <= ts <= t1:
            points.append({"ts": p["ts"], "value": p[metric]})
    # Expected timestamps at STEP intervals
    expected = []
    t = t0
    # align to first point or start
    while t <= t1:
        expected.append(t)
        t += timedelta(seconds=STEP)
    have = {p["ts"] for p in points}
    missing = [t.strftime("%Y-%m-%dT%H:%M:%SZ") for t in expected if t.strftime("%Y-%m-%dT%H:%M:%SZ") not in have
               and any(parse(p["ts"]) <= t <= parse(DATA["points"][-1]["ts"]) for p in DATA["points"])]
    # Only mark missing inside the observed overall span
    span0 = parse(DATA["points"][0]["ts"])
    span1 = parse(DATA["points"][-1]["ts"])
    missing = [m for m in missing if span0 <= parse(m) <= span1 and m not in have]
    naive_zero = [{"ts": p["ts"], "value": p["value"]} for p in points]
    # A naive filler that would treat gaps as 0 — we compute it only as a counterexample.
    filled_as_zero = []
    for t in expected:
        key = t.strftime("%Y-%m-%dT%H:%M:%SZ")
        if span0 <= t <= span1:
            hit = next((p["value"] for p in points if p["ts"] == key), None)
            filled_as_zero.append({"ts": key, "value": 0 if hit is None else hit, "was_missing": hit is None})
    return {
        "metric": metric,
        "points": points,
        "missing_ts": missing,
        "naive_zero_fill": filled_as_zero,
    }


def list_changes(start: str, end: str) -> list[dict]:
    t0, t1 = parse(start), parse(end)
    return [c for c in DATA["changes"] if t0 <= parse(c["ts"]) <= t1]


# Agent tools in sequence: first p99, then it chooses the next verification.
p99 = query_range("latency_p99_ms", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z")
# Next verification chosen because p99 rose while we must not assume CPU:
next_check = "lock_wait_ms"
lock = query_range("lock_wait_ms", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z")
cpu = query_range("cpu_pct", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z")
inflight = query_range("in_flight", "2026-11-15T16:00:00Z", "2026-11-15T16:05:00Z")
# Include a slightly wider window so the deploy change is visible as context, but
# mark times carefully.
changes = list_changes("2026-11-15T15:58:00Z", "2026-11-15T16:06:00Z")

gap = "2026-11-15T16:03:00Z"
assert gap in p99["missing_ts"]
naive = next(x for x in p99["naive_zero_fill"] if x["ts"] == gap)
assert naive["was_missing"] and naive["value"] == 0
# Honest series keeps the gap, does not report 0 load.
assert all(p["value"] != 0 or p["ts"] != gap for p in p99["points"])
assert gap not in {p["ts"] for p in p99["points"]}

report = {
    "observations": [
        {"metric": "latency_p99_ms", "text": "p99 rose from 12ms at 16:00 to 110ms at 16:02, then 108ms at 16:04.", "kind": "observation"},
        {"metric": "in_flight", "text": "in_flight rose from 3 to 21 over the same samples.", "kind": "observation"},
        {"metric": "cpu_pct", "text": "cpu_pct stayed near 18–22%.", "kind": "observation"},
        {"metric": "lock_wait_ms", "text": "lock_wait_ms rose from 1ms to 55ms in the same window (chosen as the next verification after p99).", "kind": "observation"},
        {"metric": "sampling", "text": f"No sample is present at {gap}. This is a missing sample, not a measured zero.", "kind": "observation"},
        {"metric": "change", "text": "A deploy of kv 2.0 is recorded at 15:59 and a rollback at 16:05:30.", "kind": "observation"},
    ],
    "inferences": [
        {
            "text": "The combination of rising p99, rising in_flight, modest CPU, and rising lock_wait_ms is consistent with lock contention, but it is not proof. A deploy is temporally aligned and is a candidate contributor, not a demonstrated cause.",
            "kind": "inference",
            "confidence": "low-medium",
            "not_causation": True,
        }
    ],
    "next_verification": {
        "chosen": next_check,
        "why": "After seeing p99 and in_flight rise, the next check was lock_wait_ms rather than declaring a CPU or deploy root cause. Follow-up would be traces or contended lock profiles around 16:01–16:04.",
    },
    "sampling_gap_not_treated_as_zero": True,
    "naive_zero_would_have_reported": naive,
}

# Distinguish observation vs inference in the artifact.
assert all(o["kind"] == "observation" for o in report["observations"])
assert all(i["kind"] == "inference" and i["not_causation"] for i in report["inferences"])

results = {
    "lesson": 192,
    "id": "m-metrics",
    "is_live_model": False,
    "missing_ts": p99["missing_ts"],
    "sampling_gap_not_treated_as_zero": True,
    "naive_zero_counterexample": naive,
    "next_verification": next_check,
    "lock_wait_rose": lock["points"][0]["value"] < lock["points"][2]["value"],
    "cpu_not_saturating": max(p["value"] for p in cpu["points"]) < 40,
    "changes": changes,
    "report": report,
    "observation_vs_inference_separated": True,
    "verified_on_this_machine": [
        "synthetic series with an explicit sampling gap not treated as zero",
        "lock-contention-style pattern (p99/in_flight/lock_wait up, cpu modest)",
        "scripted agent chose lock_wait_ms as the next verification",
        "report separates observations from inferences and refuses causation from correlation",
    ],
    "not_verified_on_this_machine": [
        "a live Prometheus server or production lock profile",
        "live-model metric interpretation quality",
    ],
}
if not (results["sampling_gap_not_treated_as_zero"] and results["next_verification"] == "lock_wait_ms" and results["lock_wait_rose"] and results["cpu_not_saturating"]):
    raise SystemExit("192 checks failed")

(REPORTS / "investigation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("MISSING", p99["missing_ts"])
print("NEXT", next_check)
print("ALL_CHECKS_PASSED")
