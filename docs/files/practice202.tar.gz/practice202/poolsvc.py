"""Tiny connection-pool service used for an incident drill."""
from __future__ import annotations

import threading
import time


class PoolExhausted(Exception):
    pass


class ConnectionPool:
    def __init__(self, size: int, checkout_timeout: float | None):
        self.size = size
        self.checkout_timeout = checkout_timeout
        self._free = size
        self._cv = threading.Condition()
        self._in_use = 0
        self.timeouts = 0
        self.checkouts = 0
        self.checkins = 0

    def snapshot(self) -> dict:
        with self._cv:
            return {
                "size": self.size,
                "free": self._free,
                "in_use": self._in_use,
                "timeouts": self.timeouts,
                "checkouts": self.checkouts,
                "checkins": self.checkins,
            }

    def checkout(self):
        deadline = None if self.checkout_timeout is None else time.monotonic() + self.checkout_timeout
        with self._cv:
            while self._free <= 0:
                if deadline is None:
                    self._cv.wait()
                    continue
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self.timeouts += 1
                    raise PoolExhausted("checkout_timeout")
                self._cv.wait(timeout=remaining)
                if self._free <= 0 and time.monotonic() >= deadline:
                    self.timeouts += 1
                    raise PoolExhausted("checkout_timeout")
            self._free -= 1
            self._in_use += 1
            self.checkouts += 1
            return object()

    def checkin(self, conn) -> None:
        with self._cv:
            self._free += 1
            self._in_use -= 1
            self.checkins += 1
            self._cv.notify()
