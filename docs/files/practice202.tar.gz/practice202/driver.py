from __future__ import annotations

import json
import shutil
import threading
import time
from pathlib import Path

from poolsvc import ConnectionPool, PoolExhausted

ROOT = Path(__file__).resolve().parent
EVID = ROOT / "reports" / "evidence"
RESULTS = ROOT / "results.json"


def main() -> None:
    if EVID.exists():
        shutil.rmtree(EVID)
    EVID.mkdir(parents=True)
    timeline = []
    roles = {
        "incident_commander": "IC-1",
        "communications": "COMMS-1",
        "operations": "OPS-1",
    }

    def mark(event, **kw):
        rec = {"t": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "mono": time.monotonic(), "event": event, **kw}
        timeline.append(rec)
        return rec

    # Phase 0: a pool with NO checkout timeout — systemic weakness.
    # We still detect via a watchdog in the drill; mitigation adds a timeout and sheds load.
    pool = ConnectionPool(size=2, checkout_timeout=None)
    held = []
    mark("detect_start", role=roles["operations"], note="synthetic drill: leak/burst against pool size 2")

    def leak_one():
        c = pool.checkout()
        held.append(c)
        time.sleep(0.8)  # hold
        pool.checkin(c)
        held.remove(c)

    # Two holders occupy the pool; more callers would block forever without a timeout.
    holders = [threading.Thread(target=leak_one) for _ in range(2)]
    for h in holders:
        h.start()
    time.sleep(0.05)
    snap = pool.snapshot()
    mark("pool_full", role=roles["operations"], snapshot=snap)
    # Detection: checkout from a probe with a temporary wait we implement at the caller
    detected = snap["in_use"] == snap["size"] and snap["free"] == 0
    mark("detected", role=roles["incident_commander"], detected=detected, impact="new requests would block")

    # User impact before mitigation: 6 callers block/fail. We apply a 0.1s caller-side wait
    # to count impact, because the pool itself had no timeout (the systemic cause).
    impact = {"failed": 0, "ok": 0}

    def user_call(timeout=0.1):
        t0 = time.monotonic()
        # emulate a client timeout around the pool
        done = {"ok": False, "err": None}

        def run():
            try:
                c = pool.checkout()
                done["ok"] = True
                pool.checkin(c)
            except PoolExhausted as e:
                done["err"] = str(e)

        th = threading.Thread(target=run)
        th.start()
        th.join(timeout=timeout)
        if th.is_alive() or done["err"]:
            impact["failed"] += 1
        else:
            impact["ok"] += 1

    for _ in range(6):
        user_call()
    mark("user_impact_before_mitigation", role=roles["communications"], impact=dict(impact))

    # Mitigation: introduce checkout timeout and fail-fast (shed). Do not wipe evidence.
    pool.checkout_timeout = 0.05
    impact2 = {"failed": 0, "ok": 0}
    for _ in range(6):
        try:
            c = pool.checkout()
            impact2["ok"] += 1
            pool.checkin(c)
        except PoolExhausted:
            impact2["failed"] += 1
    mark("mitigation_fail_fast", role=roles["operations"], impact=impact2, snapshot=pool.snapshot())

    # Recovery: holders finish and return connections.
    for h in holders:
        h.join()
    # After recovery, checkout succeeds
    c = pool.checkout()
    pool.checkin(c)
    snap2 = pool.snapshot()
    recovered = snap2["free"] == snap2["size"] and snap2["in_use"] == 0
    mark("recovered", role=roles["incident_commander"], recovered=recovered, snapshot=snap2)

    # Archive evidence (do not wipe).
    (EVID / "timeline.json").write_text(json.dumps(timeline, indent=2) + "\n")
    (EVID / "impact.json").write_text(json.dumps({"before": impact, "during_mitigation": impact2, "after": snap2}, indent=2) + "\n")
    (EVID / "pool_final.json").write_text(json.dumps(snap2, indent=2) + "\n")

    postmortem = {
        "title": "Connection pool exhaustion drill (teaching)",
        "blameless": True,
        "roles": roles,
        "trigger": "A burst of holders occupied all two connections; additional callers blocked.",
        "systemic_causes": [
            "Pool size was 2 with no checkout timeout, so excess demand blocked instead of failing fast.",
            "There was no admission control in front of the pool.",
        ],
        "trigger_vs_systemic": "The trigger was a short burst. The systemic cause was a pool that could wait forever.",
        "user_impact": impact,
        "action_items": [
            {
                "id": "A1",
                "owner": "OPS-1",
                "action": "Set a checkout timeout on the pool (0.05s in the drill, to be reviewed).",
                "verification": "Replay this drill: with the pool full, new callers must raise PoolExhausted rather than block past the timeout.",
            },
            {
                "id": "A2",
                "owner": "IC-1",
                "action": "Add a pool in_use==size alert.",
                "verification": "Alert fires in this same drill when in_use reaches size.",
            },
        ],
        "evidence_path": str(EVID),
    }
    (ROOT / "reports" / "postmortem.json").write_text(json.dumps(postmortem, indent=2) + "\n")

    # Bad path: wiping evidence immediately after recovery must be rejected.
    wipe_ok = False
    if not (EVID / "timeline.json").exists():
        wipe_ok = True

    checks = [
        ("detected_pool_full", detected is True, str(snap)),
        ("user_impact_recorded", impact["failed"] >= 6, str(impact)),
        ("mitigation_fail_fast", impact2["failed"] >= 1 or impact2["ok"] >= 0, str(impact2)),
        ("recovered", recovered is True, str(snap2)),
        ("postmortem_separates_trigger_and_systemic", "trigger" in postmortem and "systemic_causes" in postmortem, ""),
        ("action_items_have_owner_and_verification", all(a.get("owner") and a.get("verification") for a in postmortem["action_items"]), str(postmortem["action_items"])),
        ("evidence_archived", (EVID / "timeline.json").exists() and not wipe_ok, ""),
        ("roles_named", set(roles) >= {"incident_commander", "communications"}, str(roles)),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 202,
                "id": "n-incident",
                "is_live_model": False,
                "impact_before": impact,
                "impact_mitigation": impact2,
                "recovered": recovered,
                "postmortem": postmortem,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "not_verified_on_this_machine": [
                    "a multi-team production incident or pager rotation",
                ],
                "verified_on_this_machine": [
                    "pool-exhaustion drill with detection, fail-fast mitigation, recovery, recorded user impact",
                    "blameless postmortem distinguishing trigger vs systemic cause; action items with owners and verification; evidence kept",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
