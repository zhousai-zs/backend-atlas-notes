"""Scripted operations diagnoser. is_live_model=false.

Builds an explicit evidence graph: observations -> hypotheses -> tests
(exclusions) -> suggestion. Does not mark recovered unless a repair was
executed and a post-check passed.
"""
from __future__ import annotations

from typing import Any


def diagnose(case: dict[str, Any], repair: dict[str, Any] | None = None) -> dict[str, Any]:
    m = case["metrics"]
    logs = list(case["logs"])
    evidence = []
    exclusions = []
    open_q = []

    def ev(kind, stmt, src):
        evidence.append({"kind": kind, "statement": stmt, "source": src})

    ev("metric", f"http_5xx_rate={m.get('http_5xx_rate')}", "metrics")
    ev("metric", f"cpu_pct={m.get('cpu_pct')}", "metrics")
    ev("metric", f"disk_pct={m.get('disk_pct')}", "metrics")
    ev("metric", f"checkout_wait_ms_p99={m.get('checkout_wait_ms_p99')} in_use={m.get('in_use_conns')}/{m.get('pool_size')}", "metrics")
    for line in logs:
        ev("log", line, "logs")

    # Hypotheses tested against evidence (SRE: hypothesize, then try to disprove).
    cause = None
    if m.get("config_hash_ok") is False or any("hash mismatch" in x for x in logs):
        cause = "bad_config_hash"
        ev("test", "config hash is not ok", "metrics.config_hash_ok")
    elif m.get("disk_pct", 0) >= 95 or any("no space left" in x for x in logs):
        cause = "disk_full"
        ev("test", "disk is at or above 95% or a write failed with ENOSPC", "metrics/logs")
        exclusions.append("connection_pool_exhaustion: wait is low and pool is not full")
    elif m.get("in_use_conns") == m.get("pool_size") and m.get("checkout_wait_ms_p99", 0) >= 500:
        cause = "connection_pool_exhaustion"
        ev("test", "pool is fully checked out and checkout wait is high", "metrics")
        exclusions.append("cpu_saturation: cpu_pct is not in saturation range" if m.get("cpu_pct", 0) < 80 else "cpu may be a contributor; pool evidence is stronger")
    elif m.get("dep_timeout_rate", 0) >= 0.1 or any("deadline exceeded" in x or "504" in x for x in logs):
        cause = "dependency_timeout"
        ev("test", "dependency timeout rate or 504/deadline logs", "metrics/logs")
        exclusions.append("connection_pool_exhaustion: local pool is not full")
    elif m.get("cpu_pct", 0) >= 90:
        cause = "cpu_saturation"
        ev("test", "cpu_pct >= 90", "metrics")
        exclusions.append("disk_full: disk_pct is not critical")
    else:
        open_q.append("insufficient evidence to pick a single root cause")

    if cause != "disk_full" and m.get("disk_pct", 0) < 80:
        exclusions.append("disk_full: disk_pct is not critical")
    if cause != "bad_config_hash" and m.get("config_hash_ok", True):
        exclusions.append("bad_config_hash: config hash matches")
    if cause != "dependency_timeout" and m.get("dep_timeout_rate", 0) == 0 and not any("deadline exceeded" in x for x in logs):
        exclusions.append("dependency_timeout: no dependency timeout signal")

    suggestions = []
    if cause == "connection_pool_exhaustion":
        suggestions.append("raise pool size or cap concurrency; first verify leak vs genuine load")
    elif cause == "disk_full":
        suggestions.append("free disk or expand volume; do not only restart the process")
    elif cause == "bad_config_hash":
        suggestions.append("roll back or republish the expected config hash")
    elif cause == "cpu_saturation":
        suggestions.append("scale the service or reduce expensive handlers")
    elif cause == "dependency_timeout":
        suggestions.append("raise or isolate the payment gateway; add a fallback")

    recovered = False
    recovery_claim = "not_recovered"
    if repair:
        tool_ok = bool(repair.get("tool_ok"))
        executed = bool(repair.get("executed"))
        verified = bool(repair.get("postcheck_ok"))
        if tool_ok and not executed:
            recovery_claim = "tool_returned_ok_but_repair_not_executed"
        elif executed and not verified:
            recovery_claim = "repair_executed_but_not_verified"
        elif executed and verified:
            recovered = True
            recovery_claim = "recovered_after_verified_repair"
        else:
            recovery_claim = "not_recovered"

    return {
        "service": case["service"],
        "window": case["window"],
        "evidence": evidence,
        "exclusions": exclusions,
        "suggestions": suggestions,
        "open_questions": open_q,
        "hypothesized_root_cause": cause,
        "recovered": recovered,
        "recovery_claim": recovery_claim,
    }
