from __future__ import annotations

import json
from pathlib import Path

from diagnose import diagnose

ROOT = Path(__file__).resolve().parent
HIDDEN = json.loads((ROOT / "hidden_faults.json").read_text())
RESULTS = ROOT / "results.json"


def main() -> None:
    reports = []
    hits = 0
    total = 0
    for path in sorted((ROOT / "fixtures").glob("c*.json")):
        case = json.loads(path.read_text())
        cid = case["id"]
        # Diagnoser never reads hidden_faults.json.
        hidden = HIDDEN[cid]
        repair = None
        if cid == "c6":
            # A restart tool returns success; the repair was not executed and the pool is still full.
            repair = {"tool_ok": True, "executed": False, "postcheck_ok": False, "tool": "restart"}
        report = diagnose(case, repair)
        total += 1
        hit = report["hypothesized_root_cause"] == hidden["cause"]
        hits += int(hit)
        reports.append({"id": cid, "hit": hit, "got": report["hypothesized_root_cause"], "hidden": hidden["cause"], "report": report})

    hit_rate = hits / total if total else 0.0
    c6 = next(x for x in reports if x["id"] == "c6")
    checks = [
        ("hidden_set_size", total == 6, str(total)),
        ("hit_rate_at_least_5_of_6", hits >= 5, f"{hits}/{total}={hit_rate:.3f}"),
        ("c6_not_declared_recovered", c6["report"]["recovered"] is False, c6["report"]["recovery_claim"]),
        ("c6_explains_tool_ok", c6["report"]["recovery_claim"] == "tool_returned_ok_but_repair_not_executed", c6["report"]["recovery_claim"]),
        ("every_report_has_evidence", all(len(x["report"]["evidence"]) >= 3 for x in reports), ""),
        ("every_report_has_exclusions_or_open_q", all(x["report"]["exclusions"] or x["report"]["open_questions"] for x in reports), ""),
        ("suggestions_not_empty_when_cause", all(x["report"]["suggestions"] for x in reports if x["report"]["hypothesized_root_cause"]), ""),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    (ROOT / "reports" / "p10.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 195,
                "id": "m-ops",
                "is_live_model": False,
                "hit_rate": hit_rate,
                "hits": hits,
                "total": total,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "did_not_claim_recovered_without_repair": True,
                "not_verified_on_this_machine": [
                    "a live-model operations agent or production runbook quality",
                    "root-cause quality on a production incident (this set is a hidden teaching catalog)",
                ],
                "verified_on_this_machine": [
                    f"scripted diagnoser hit rate {hits}/{total} on the hidden teaching set",
                    "restart tool success is not treated as recovered",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
