#!/usr/bin/env python3
"""Teaching PaxosEngine — not Redis, not a network service, not complete Paxos.

A Python 3 standard-library model of single-decree Paxos (the consensus
algorithm in Lamport, "Paxos Made Simple"): proposal numbers, the
prepare / promise and accept / accepted two phases, majority
intersection, and the rule that a new proposal must inherit the
highest-numbered accepted value reported by a prepare majority.

Servers talk over an in-process mailbox driven by a virtual clock.
This is not Redis, not redis-py, and not a network server. There is no
TCP and no real message loss. It is not a complete Paxos, Multi-Paxos,
Raft, or Jepsen implementation. There is no leader election, no no-op
gap fill, no α-ahead proposal window, and no reconfiguration (paper
§3). pause() is an omniscient freeze; isolate() is an omniscient
partition; a real asynchronous network has no such signal. Persistent
state is a teaching dict flushed before a prepare or accept reply is
sent, not a disk or fsync. Clock is a virtual clock. rpc_delay_s is a
teaching delay, not a measured production RTT.

A Multi-Paxos teaching contrast (same proposal number, one prepare
covering many instances, then phase 2 only) is provided to compare
message cost with single-decree Paxos. That contrast is the state-
machine construction in §3, not the single-decree core of §2.

Definitions follow Leslie Lamport, "Paxos Made Simple", checked on
2026-11-14.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_DRAFT = "Weekly digest (draft)"
TITLE_V2 = "Weekly digest (revised)"
TITLE_HOTFIX = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
RPC_DELAY_S = 0.01


def ts(t: float) -> float:
    """Round a virtual-clock time to two decimals for stable records."""
    return round(float(t) + 1e-12, 2)


def majority_size(n: int) -> int:
    return n // 2 + 1


def command_for(value: str, key: str = KEY_TITLE) -> dict[str, str]:
    return {"op": "SET", "key": key, "value": value}


def value_of(command: Any) -> Any:
    if isinstance(command, dict):
        return command.get("value", command)
    return command


class Clock:
    """A virtual clock tests can freeze and advance. Not a wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class AcceptorPersist:
    """Acceptor stable storage for one Paxos instance (paper §2.2, §2.5)."""

    promised_n: int = 0
    accepted_n: Optional[int] = None
    accepted_v: Any = None

    def clone(self) -> "AcceptorPersist":
        return AcceptorPersist(
            promised_n=self.promised_n,
            accepted_n=self.accepted_n,
            accepted_v=self.accepted_v,
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "promised_n": self.promised_n,
            "accepted_n": self.accepted_n,
            "accepted_v": value_of(self.accepted_v) if self.accepted_v is not None else None,
        }


@dataclass
class ProposerPersist:
    """Highest proposal number this proposer has tried, per instance."""

    highest_n: dict[int, int] = field(default_factory=dict)

    def clone(self) -> "ProposerPersist":
        return ProposerPersist(highest_n=dict(self.highest_n))


@dataclass
class Message:
    src: str
    dst: str
    kind: str
    payload: dict[str, Any]
    send_at: float
    deliver_at: float
    seq: int
    dropped: bool = False


@dataclass
class ProposerBallot:
    """Volatile state for one in-flight proposal of one instance."""

    n: int
    intended_value: Any
    acceptor_ids: list[str]
    promises: dict[str, dict[str, Any]] = field(default_factory=dict)
    accepted_from: dict[str, dict[str, Any]] = field(default_factory=dict)
    nacks_prepare: list[str] = field(default_factory=list)
    nacks_accept: list[str] = field(default_factory=list)
    phase1_complete: bool = False
    inherited: bool = False
    inherit_from_n: Optional[int] = None
    inherit_from_acceptor: Optional[str] = None
    issued_value: Any = None
    abandoned: bool = False


class PaxosEngine:
    """Single-process mailbox simulation of teaching single-decree Paxos."""

    def __init__(
        self,
        proposers: Optional[list[str]] = None,
        acceptors: Optional[list[str]] = None,
        rpc_delay_s: float = RPC_DELAY_S,
    ) -> None:
        self.clock = Clock()
        self.rpc_delay_s = float(rpc_delay_s)
        self.proposer_ids = list(proposers or ["p1", "p2"])
        self.acceptor_ids = list(acceptors or ["a1", "a2", "a3"])
        self.majority = majority_size(len(self.acceptor_ids))
        self.proposer_index = {pid: i + 1 for i, pid in enumerate(self.proposer_ids)}
        self.n_proposers = len(self.proposer_ids)

        self.acceptor_persist: dict[str, dict[int, AcceptorPersist]] = {
            aid: {} for aid in self.acceptor_ids
        }
        self.proposer_persist: dict[str, ProposerPersist] = {
            pid: ProposerPersist() for pid in self.proposer_ids
        }
        # ballots[pid][instance] = ProposerBallot
        self.ballots: dict[str, dict[int, ProposerBallot]] = {
            pid: {} for pid in self.proposer_ids
        }

        self.paused: set[str] = set()
        self.isolated: set[str] = set()
        self.crashed: set[str] = set()

        self.mailbox: list[Message] = []
        self.seq = 0
        self.flush_count = 0
        self.rpc_count = 0
        self.events: list[dict[str, Any]] = []
        self._event(
            "init",
            proposers=list(self.proposer_ids),
            acceptors=list(self.acceptor_ids),
            majority=self.majority,
            rpc_delay_s=self.rpc_delay_s,
        )

    # ------------------------------------------------------------------
    # Observability
    # ------------------------------------------------------------------

    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def _persist_for(self, aid: str, instance: int) -> AcceptorPersist:
        slot = self.acceptor_persist[aid]
        if instance not in slot:
            slot[instance] = AcceptorPersist()
        return slot[instance]

    def _flush(self, agent: str, reason: str, instance: Optional[int] = None) -> None:
        """Teaching flush of durable state before a reply is sent. Not fsync."""
        self.flush_count += 1
        payload: dict[str, Any] = {"agent": agent, "reason": reason, "flush_count": self.flush_count}
        if instance is not None:
            payload["instance"] = instance
        self._event("persist_flushed", **payload)

    def durable_snapshot(self, instance: int = 1) -> dict[str, dict[str, Any]]:
        out = {}
        for aid in self.acceptor_ids:
            state = self.acceptor_persist[aid].get(instance)
            if state is None:
                out[aid] = AcceptorPersist().as_dict()
            else:
                out[aid] = state.as_dict()
        return out

    def durable_snapshot_all(self) -> dict[int, dict[str, dict[str, Any]]]:
        instances = set()
        for slot in self.acceptor_persist.values():
            instances.update(slot.keys())
        return {i: self.durable_snapshot(i) for i in sorted(instances)}

    def format_acceptors(self, instance: int = 1) -> str:
        lines = []
        for aid, st in self.durable_snapshot(instance).items():
            v = st["accepted_v"] if st["accepted_v"] is not None else "None"
            an = st["accepted_n"] if st["accepted_n"] is not None else "None"
            lines.append(f"{aid}  promised={st['promised_n']}  accepted_n={an}  accepted_v={v}")
        return "\n".join(lines)

    def chosen_proposals(self, instance: int = 1) -> list[dict[str, Any]]:
        """Proposals accepted by a majority of acceptors (paper: a value is chosen)."""
        counts: dict[tuple[int, str], list[str]] = {}
        for aid in self.acceptor_ids:
            state = self.acceptor_persist[aid].get(instance)
            if state is None or state.accepted_n is None:
                continue
            key = (state.accepted_n, value_of(state.accepted_v))
            counts.setdefault(key, []).append(aid)
        chosen = []
        for (n, v), holders in sorted(counts.items()):
            if len(holders) >= self.majority:
                chosen.append({"n": n, "value": v, "holders": holders, "holder_count": len(holders)})
        return chosen

    def chosen_value(self, instance: int = 1) -> Optional[Any]:
        props = self.chosen_proposals(instance)
        if not props:
            return None
        values = {p["value"] for p in props}
        # Safety: all chosen proposals in one instance must share a value.
        if len(values) != 1:
            return {"__safety_violation__": sorted(values)}
        return props[-1]["value"] if props else None

    def chosen_majority(self, instance: int = 1) -> Optional[list[str]]:
        props = self.chosen_proposals(instance)
        if not props:
            return None
        return list(props[0]["holders"])

    def safety_ok(self, instance: Optional[int] = None) -> bool:
        """At most one value is chosen per instance (paper safety requirement)."""
        if instance is not None:
            instances = [instance]
        else:
            found = set()
            for slot in self.acceptor_persist.values():
                found.update(slot.keys())
            instances = sorted(found) or [1]
        for inst in instances:
            props = self.chosen_proposals(inst)
            values = {p["value"] for p in props}
            if len(values) > 1:
                return False
        return True

    # ------------------------------------------------------------------
    # Network controls (omniscient teaching signals)
    # ------------------------------------------------------------------

    def isolate(self, agent: str) -> None:
        self.isolated.add(agent)
        self._event("isolated", agent=agent)

    def heal(self, agent: str) -> None:
        self.isolated.discard(agent)
        self._event("healed", agent=agent)

    def heal_all(self) -> None:
        self.isolated.clear()
        self._event("healed_all")

    def pause(self, agent: str) -> None:
        self.paused.add(agent)
        self._event("paused", agent=agent)

    def unpause(self, agent: str) -> None:
        self.paused.discard(agent)
        self._event("unpaused", agent=agent)

    def crash(self, agent: str) -> None:
        self.crashed.add(agent)
        self.paused.discard(agent)
        # In-flight messages to/from a crashed agent are dropped.
        for msg in self.mailbox:
            if not msg.dropped and (msg.src == agent or msg.dst == agent):
                msg.dropped = True
        self._event("crashed", agent=agent)

    def restart(self, agent: str) -> None:
        """Restart keeps durable state; volatile ballot state of a proposer is cleared."""
        self.crashed.discard(agent)
        self.paused.discard(agent)
        if agent in self.ballots:
            self.ballots[agent] = {}
        self._event("restarted", agent=agent)

    def _reachable(self, src: str, dst: str) -> bool:
        if src in self.crashed or dst in self.crashed:
            return False
        if src in self.isolated or dst in self.isolated:
            return False
        if src in self.paused or dst in self.paused:
            return False
        return True

    # ------------------------------------------------------------------
    # Mailbox
    # ------------------------------------------------------------------

    def _send(self, src: str, dst: str, kind: str, payload: dict[str, Any]) -> Message:
        self.seq += 1
        send_at = self.clock.now()
        deliver_at = round(send_at + self.rpc_delay_s, 10)
        msg = Message(
            src=src,
            dst=dst,
            kind=kind,
            payload=dict(payload),
            send_at=send_at,
            deliver_at=deliver_at,
            seq=self.seq,
        )
        if not self._reachable(src, dst):
            msg.dropped = True
            self._event("message_dropped", src=src, dst=dst, kind=kind, payload=dict(payload))
        self.mailbox.append(msg)
        self.rpc_count += 1
        self._event("rpc_send", src=src, dst=dst, kind=kind, payload=dict(payload), rpc_count=self.rpc_count)
        return msg

    def _pending(self) -> list[Message]:
        return [m for m in self.mailbox if not m.dropped and m.deliver_at >= -1]

    def run_until_quiet(self) -> None:
        """Deliver every outstanding message in deliver_at / seq order.

        Messages whose destination is paused stay in the mailbox and are
        not delivered; if only those remain, this method returns so the
        caller can unpause. Crashed or isolated endpoints drop the message.
        """
        while True:
            due = [
                m
                for m in self.mailbox
                if not m.dropped and m.dst not in self.paused
            ]
            if not due:
                self.mailbox = [m for m in self.mailbox if not m.dropped]
                return
            due.sort(key=lambda m: (m.deliver_at, m.seq))
            msg = due[0]
            self.clock.wait_until(msg.deliver_at)
            self.mailbox.remove(msg)
            if msg.src in self.crashed or msg.dst in self.crashed:
                self._event(
                    "message_dropped",
                    src=msg.src,
                    dst=msg.dst,
                    kind=msg.kind,
                    reason="crashed_at_delivery",
                )
                continue
            if msg.src in self.isolated or msg.dst in self.isolated:
                self._event(
                    "message_dropped",
                    src=msg.src,
                    dst=msg.dst,
                    kind=msg.kind,
                    reason="isolated_at_delivery",
                )
                continue
            if msg.dst in self.paused:
                self.mailbox.append(msg)
                continue
            self._deliver(msg)

    def _deliver(self, msg: Message) -> None:
        self._event("rpc_deliver", src=msg.src, dst=msg.dst, kind=msg.kind, payload=dict(msg.payload))
        kind = msg.kind
        if kind == "prepare":
            self._on_prepare(msg)
        elif kind == "promise":
            self._on_promise(msg)
        elif kind == "prepare_nack":
            self._on_prepare_nack(msg)
        elif kind == "accept":
            self._on_accept(msg)
        elif kind == "accepted":
            self._on_accepted(msg)
        elif kind == "accept_nack":
            self._on_accept_nack(msg)
        else:
            raise ValueError(f"unknown message kind: {kind}")

    # ------------------------------------------------------------------
    # Proposal numbers (paper §2.5: disjoint sets, never reuse)
    # ------------------------------------------------------------------

    def next_proposal_number(self, proposer_id: str, instance: int = 1) -> int:
        idx = self.proposer_index[proposer_id]
        step = self.n_proposers
        used = self.proposer_persist[proposer_id].highest_n.get(instance, 0)
        n = idx
        while n <= used:
            n += step
        return n

    def allocate_proposal_number(self, proposer_id: str, instance: int, n: Optional[int] = None) -> int:
        persist = self.proposer_persist[proposer_id]
        used = persist.highest_n.get(instance, 0)
        if n is None:
            n = self.next_proposal_number(proposer_id, instance)
        if n <= used:
            raise ValueError(
                f"{proposer_id} cannot reuse or go backwards on instance {instance}: "
                f"requested n={n}, already used {used}"
            )
        # Disjoint-set check: n ≡ index (mod n_proposers)
        idx = self.proposer_index[proposer_id]
        if (n - idx) % self.n_proposers != 0:
            raise ValueError(
                f"{proposer_id} must choose n from its disjoint set "
                f"(n ≡ {idx} mod {self.n_proposers}), got n={n}"
            )
        persist.highest_n[instance] = n
        self._flush(proposer_id, "allocate_proposal_number", instance)
        return n

    # ------------------------------------------------------------------
    # Phase 1: prepare / promise
    # ------------------------------------------------------------------

    def start_prepare(
        self,
        proposer_id: str,
        value: Any,
        instance: int = 1,
        n: Optional[int] = None,
        acceptor_ids: Optional[list[str]] = None,
        instances: Optional[list[int]] = None,
    ) -> dict[str, Any]:
        inst_list = list(instances) if instances is not None else [instance]
        if not inst_list:
            raise ValueError("instances must not be empty")
        # One proposal number shared across the instance list (paper §3).
        # Track allocation against the first instance plus any others that
        # have not yet seen this n from this proposer.
        primary = inst_list[0]
        allocated = self.allocate_proposal_number(proposer_id, primary, n)
        for inst in inst_list[1:]:
            used = self.proposer_persist[proposer_id].highest_n.get(inst, 0)
            if allocated < used:
                raise ValueError(
                    f"{proposer_id} n={allocated} is behind instance {inst} used={used}"
                )
            if allocated > used:
                self.proposer_persist[proposer_id].highest_n[inst] = allocated
                self._flush(proposer_id, "allocate_proposal_number", inst)
            elif allocated == used:
                # Same n already reserved for this instance (range prepare after
                # a prior allocation of this n). Allowed.
                pass
        targets = list(acceptor_ids or self.acceptor_ids)
        for inst in inst_list:
            self.ballots[proposer_id][inst] = ProposerBallot(
                n=allocated,
                intended_value=value if inst == primary else value,
                acceptor_ids=list(targets),
            )
            # For a range prepare, intended value applies only when that
            # instance's promise majority reports no accepted value. Callers
            # that propose different values per instance should call
            # start_accept(..., value=...) per instance after phase 1.
            if inst != primary:
                self.ballots[proposer_id][inst].intended_value = None
        payload = {"n": allocated, "instances": list(inst_list)}
        self._event(
            "prepare_send",
            proposer=proposer_id,
            n=allocated,
            instances=list(inst_list),
            value=value_of(value),
            acceptors=list(targets),
        )
        for aid in targets:
            self._send(proposer_id, aid, "prepare", payload)
        return {"n": allocated, "instances": list(inst_list), "acceptors": list(targets)}

    def _on_prepare(self, msg: Message) -> None:
        aid = msg.dst
        n = int(msg.payload["n"])
        inst_list = list(msg.payload["instances"])
        accepted_report: dict[str, Any] = {}
        promised: list[int] = []
        ignored: list[dict[str, Any]] = []
        # The paper's optimization: ignore a prepare if we already responded
        # to a higher-numbered one, or if we already accepted this proposal.
        # Durable state is written before the reply (paper §2.5).
        changed = False
        for inst in inst_list:
            state = self._persist_for(aid, inst)
            if n <= state.promised_n or state.accepted_n == n:
                ignored.append(
                    {
                        "instance": inst,
                        "promised_n": state.promised_n,
                        "accepted_n": state.accepted_n,
                        "reason": "accepted_already" if state.accepted_n == n else "promised_ge",
                    }
                )
                accepted_report[str(inst)] = None
                continue
            state.promised_n = n
            changed = True
            promised.append(inst)
            if state.accepted_n is not None:
                accepted_report[str(inst)] = {
                    "accepted_n": state.accepted_n,
                    "accepted_v": state.accepted_v,
                }
            else:
                accepted_report[str(inst)] = None
        if changed:
            self._flush(aid, "promise", inst_list[0] if inst_list else None)
        if promised:
            self._event(
                "promise",
                acceptor=aid,
                proposer=msg.src,
                n=n,
                instances=promised,
                accepted= {
                    int(k): (
                        None
                        if v is None
                        else {"accepted_n": v["accepted_n"], "accepted_v": value_of(v["accepted_v"])}
                    )
                    for k, v in accepted_report.items()
                    if int(k) in promised
                },
            )
            self._send(
                aid,
                msg.src,
                "promise",
                {"n": n, "instances": promised, "accepted": accepted_report, "ignored": ignored},
            )
        else:
            self._event(
                "prepare_ignored",
                acceptor=aid,
                proposer=msg.src,
                n=n,
                instances=inst_list,
                ignored=ignored,
            )
            # Inform the proposer (paper §2.2: a performance optimization).
            self._send(
                aid,
                msg.src,
                "prepare_nack",
                {"n": n, "instances": inst_list, "ignored": ignored},
            )

    def _on_promise(self, msg: Message) -> None:
        pid = msg.dst
        n = int(msg.payload["n"])
        inst_list = list(msg.payload["instances"])
        accepted = msg.payload.get("accepted") or {}
        for inst in inst_list:
            ballot = self.ballots.get(pid, {}).get(inst)
            if ballot is None or ballot.n != n or ballot.abandoned:
                continue
            report = accepted.get(str(inst))
            ballot.promises[msg.src] = report
            if len(ballot.promises) >= self.majority and not ballot.phase1_complete:
                self._complete_phase1(pid, inst, ballot)

    def _complete_phase1(self, pid: str, inst: int, ballot: ProposerBallot) -> None:
        highest_n = -1
        highest_v = None
        from_acc = None
        for aid, report in ballot.promises.items():
            if not report:
                continue
            an = report["accepted_n"]
            if an is not None and an > highest_n:
                highest_n = an
                highest_v = report["accepted_v"]
                from_acc = aid
        if highest_n >= 0:
            ballot.inherited = True
            ballot.inherit_from_n = highest_n
            ballot.inherit_from_acceptor = from_acc
            ballot.issued_value = highest_v
        else:
            ballot.inherited = False
            ballot.issued_value = ballot.intended_value
        ballot.phase1_complete = True
        self._event(
            "phase1_complete",
            proposer=pid,
            instance=inst,
            n=ballot.n,
            promises=sorted(ballot.promises),
            promise_count=len(ballot.promises),
            majority=self.majority,
            inherited=ballot.inherited,
            inherit_from_n=ballot.inherit_from_n,
            inherit_from_acceptor=ballot.inherit_from_acceptor,
            issued_value=value_of(ballot.issued_value) if ballot.issued_value is not None else None,
            intended_value=value_of(ballot.intended_value) if ballot.intended_value is not None else None,
        )

    def _on_prepare_nack(self, msg: Message) -> None:
        pid = msg.dst
        n = int(msg.payload["n"])
        inst_list = list(msg.payload["instances"])
        for inst in inst_list:
            ballot = self.ballots.get(pid, {}).get(inst)
            if ballot is None or ballot.n != n:
                continue
            ballot.nacks_prepare.append(msg.src)
            self._event(
                "prepare_nack",
                proposer=pid,
                acceptor=msg.src,
                instance=inst,
                n=n,
                ignored=msg.payload.get("ignored"),
            )

    # ------------------------------------------------------------------
    # Phase 2: accept / accepted
    # ------------------------------------------------------------------

    def start_accept(
        self,
        proposer_id: str,
        instance: int = 1,
        value: Any = None,
        acceptor_ids: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        ballot = self.ballots.get(proposer_id, {}).get(instance)
        if ballot is None:
            raise ValueError(f"{proposer_id} has no ballot for instance {instance}")
        if not ballot.phase1_complete:
            raise ValueError(
                f"{proposer_id} cannot start phase 2 on instance {instance} "
                f"n={ballot.n}: no prepare majority yet"
            )
        if ballot.abandoned:
            raise ValueError(f"{proposer_id} ballot n={ballot.n} was abandoned")
        # If phase 1 inherited a value, the proposer must issue that value
        # (P2c). A conflicting caller-supplied value is ignored and recorded.
        ignored_own = False
        if ballot.inherited:
            issued = ballot.issued_value
            if value is not None and value_of(value) != value_of(issued):
                ignored_own = True
        else:
            if value is not None:
                ballot.issued_value = value
            issued = ballot.issued_value
            if issued is None:
                raise ValueError(
                    f"{proposer_id} instance {instance} is unconstrained but no value was provided"
                )
        targets = list(acceptor_ids or ballot.acceptor_ids)
        self._event(
            "accept_send",
            proposer=proposer_id,
            instance=instance,
            n=ballot.n,
            value=value_of(issued),
            inherited=ballot.inherited,
            ignored_own_value=ignored_own,
            acceptors=list(targets),
        )
        payload = {"n": ballot.n, "instance": instance, "value": issued}
        for aid in targets:
            self._send(proposer_id, aid, "accept", payload)
        return {
            "n": ballot.n,
            "instance": instance,
            "value": value_of(issued),
            "inherited": ballot.inherited,
            "ignored_own_value": ignored_own,
            "acceptors": list(targets),
        }

    def _on_accept(self, msg: Message) -> None:
        aid = msg.dst
        n = int(msg.payload["n"])
        inst = int(msg.payload["instance"])
        value = msg.payload["value"]
        state = self._persist_for(aid, inst)
        # P1a: accept n iff the acceptor has not responded to a prepare > n.
        if state.promised_n > n:
            self._event(
                "accept_rejected",
                acceptor=aid,
                proposer=msg.src,
                instance=inst,
                n=n,
                promised_n=state.promised_n,
                value=value_of(value),
            )
            self._send(
                aid,
                msg.src,
                "accept_nack",
                {"n": n, "instance": inst, "promised_n": state.promised_n},
            )
            return
        state.accepted_n = n
        state.accepted_v = value
        # Remember the highest numbered proposal accepted. promised_n is
        # already >= n if this acceptor promised n; if the accept set is a
        # different majority (paper §2.2), promised_n may still be lower.
        # Bumping it to n prevents later accepting a lower number.
        if state.promised_n < n:
            state.promised_n = n
        self._flush(aid, "accepted", inst)
        self._event(
            "accepted",
            acceptor=aid,
            proposer=msg.src,
            instance=inst,
            n=n,
            value=value_of(value),
        )
        self._send(
            aid,
            msg.src,
            "accepted",
            {"n": n, "instance": inst, "value": value},
        )

    def _on_accepted(self, msg: Message) -> None:
        pid = msg.dst
        n = int(msg.payload["n"])
        inst = int(msg.payload["instance"])
        ballot = self.ballots.get(pid, {}).get(inst)
        if ballot is None or ballot.n != n:
            return
        ballot.accepted_from[msg.src] = {"n": n, "value": msg.payload["value"]}
        holders = self.chosen_proposals(inst)
        if holders:
            self._event(
                "chosen",
                proposer=pid,
                instance=inst,
                n=holders[-1]["n"],
                value=holders[-1]["value"],
                holders=holders[-1]["holders"],
                holder_count=holders[-1]["holder_count"],
            )

    def _on_accept_nack(self, msg: Message) -> None:
        pid = msg.dst
        n = int(msg.payload["n"])
        inst = int(msg.payload["instance"])
        ballot = self.ballots.get(pid, {}).get(inst)
        if ballot is None or ballot.n != n:
            return
        ballot.nacks_accept.append(msg.src)
        self._event(
            "accept_nack",
            proposer=pid,
            acceptor=msg.src,
            instance=inst,
            n=n,
            promised_n=msg.payload.get("promised_n"),
        )

    def abandon(self, proposer_id: str, instance: int = 1) -> None:
        ballot = self.ballots.get(proposer_id, {}).get(instance)
        if ballot is not None:
            ballot.abandoned = True
            self._event("abandoned", proposer=proposer_id, instance=instance, n=ballot.n)

    def ballot_view(self, proposer_id: str, instance: int = 1) -> Optional[dict[str, Any]]:
        ballot = self.ballots.get(proposer_id, {}).get(instance)
        if ballot is None:
            return None
        return {
            "n": ballot.n,
            "intended_value": value_of(ballot.intended_value) if ballot.intended_value is not None else None,
            "issued_value": value_of(ballot.issued_value) if ballot.issued_value is not None else None,
            "promises": sorted(ballot.promises),
            "promise_count": len(ballot.promises),
            "phase1_complete": ballot.phase1_complete,
            "inherited": ballot.inherited,
            "inherit_from_n": ballot.inherit_from_n,
            "inherit_from_acceptor": ballot.inherit_from_acceptor,
            "accepted_from": sorted(ballot.accepted_from),
            "nacks_prepare": list(ballot.nacks_prepare),
            "nacks_accept": list(ballot.nacks_accept),
            "abandoned": ballot.abandoned,
        }
