#!/usr/bin/env python3
"""Acceptance checks for the lesson 119 Paxos experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import TITLE_DRAFT, TITLE_V1, TITLE_V2


def main() -> None:
    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    inter = result["interleave_two_proposers"]
    partial = result["partial_accept_not_chosen"]
    bounds = result["proposal_number_bounds"]
    live = result["livelock_vs_safety"]
    pit = result["pitfall_instances_are_not_replicas"]
    tr = result["tradeoff_paper_vs_multipaxos"]

    assert result["engine"] == "PaxosEngine"
    assert result["not_redis"] and result["not_a_network_service"]
    assert result["not_full_paxos"] and result["not_full_multipaxos"]
    assert result["not_raft"] and result["not_jepsen"]
    assert result["majority_of_three"] == 2

    # Main practice: two proposers interleave; durable state is listed;
    # a new proposer must inherit the already-chosen value.
    assert len(inter["trace"]) >= 5
    assert inter["chosen_after_p1"] == TITLE_DRAFT
    assert inter["p2_inherited"] is True
    assert inter["p2_inherited_value"] == TITLE_DRAFT
    assert inter["p2_intended"] == TITLE_V2
    assert inter["ignored_own_value"] is True
    assert inter["chosen_is_draft"] is True
    assert inter["revised_never_chosen"] is True
    assert inter["majority_intersection"]
    assert "a2" in inter["majority_intersection"]
    assert sorted(inter["p2_prepare_majority"]) == ["a2", "a3"]
    assert sorted(inter["chosen_majority_after_p1"]) == ["a1", "a2"]
    assert inter["restart_preserved"] is True
    assert inter["safety_ok"] is True
    final = inter["final_acceptors"]
    assert final["a1"]["accepted_v"] == TITLE_DRAFT
    assert final["a2"]["accepted_v"] == TITLE_DRAFT
    assert final["a3"]["accepted_v"] == TITLE_DRAFT
    assert final["a2"]["accepted_n"] == 2
    assert final["a3"]["accepted_n"] == 2
    assert final["a1"]["accepted_n"] == 1

    # Contrast: a minority accept does not force inheritance.
    assert partial["not_chosen_after_partial"] is True
    assert partial["p2_inherited"] is False
    assert partial["chosen_is_revised"] is True
    assert partial["draft_never_chosen"] is True
    assert partial["intersection_with_partial_acceptor"] == []
    assert partial["safety_ok"] is True

    # Proposal number bounds.
    assert bounds["prepare_ignored_count"] >= 3
    assert bounds["accept_rejected_count"] >= 3
    assert bounds["reuse_rejected"] is True
    assert bounds["wrong_set_rejected"] is True
    assert bounds["chosen_is_draft"] is True
    assert bounds["hotfix_never_chosen"] is True
    assert bounds["safety_ok"] is True

    # Livelock vs safety.
    assert live["livelock_no_value_chosen"] is True
    assert live["chosen_during_livelock"] is None
    assert live["accept_rejected_during_livelock"] >= 12  # 4 rejected accepts × 3 acceptors
    assert live["safety_during_livelock"] is True
    assert live["chosen_after_distinguished"] == TITLE_DRAFT
    assert live["chosen_is_draft"] is True
    assert live["safety_ok"] is True
    assert live["election_is_for_progress_not_safety"] is True

    # Pitfall: instances ≠ replicas.
    assert pit["acceptor_count"] == 3
    assert pit["instance_count"] == 2
    assert pit["command_count"] == 2
    assert pit["instances_equal_replicas"] is False
    assert pit["instances_equal_commands"] is True
    assert pit["wrong_model_rejected"] is True
    assert pit["commands"][0]["value"] == TITLE_V1
    assert pit["commands"][1]["value"] == TITLE_V2
    assert pit["each_acceptor_holds_all_instances"] is True
    assert pit["safety_ok"] is True

    # Tradeoff: Multi-Paxos teaching contrast saves Phase 1 RPCs.
    assert tr["multipaxos_fewer_rpcs_for_same_commands"] is True
    assert tr["multipaxos_faster_on_virtual_clock"] is True
    assert tr["stable_leader_skips_phase1"] is True
    for key in ("single_5", "multi_5", "single_20", "multi_20"):
        case = tr["cases"][key]
        assert case["all_chosen"] is True
        assert case["safety_ok"] is True
        assert case["elapsed_s"] is not None
    assert tr["cases"]["multi_20"]["rpc_count"] < tr["cases"]["single_20"]["rpc_count"]
    assert tr["rpc_saved_20"] > 0

    assert result["acceptance_new_proposer_inherits_chosen_value"] is True
    assert result["acceptance_livelock_vs_safety"] is True
    assert result["pitfall_instances_not_equal_replicas"] is True
    assert result["tradeoff_stable_leader_saves_phase1"] is True

    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
