#!/usr/bin/env python3
"""Run the lesson 119 Paxos experiments and record observations."""
from __future__ import annotations

from typing import Any, Optional

from engine import (
    KEY_TITLE,
    RPC_DELAY_S,
    TITLE_DRAFT,
    TITLE_HOTFIX,
    TITLE_V1,
    TITLE_V2,
    PaxosEngine,
    command_for,
    ts,
    value_of,
)


def _set(value: str) -> dict[str, str]:
    return command_for(value)


def _step(engine: PaxosEngine, name: str, instance: int = 1, **extra: Any) -> dict[str, Any]:
    rec: dict[str, Any] = {
        "t": engine.now(),
        "step": name,
        "instance": instance,
        "acceptors": engine.durable_snapshot(instance),
        "acceptor_diagram": engine.format_acceptors(instance),
        "chosen": engine.chosen_value(instance),
        "chosen_proposals": engine.chosen_proposals(instance),
        "safety_ok": engine.safety_ok(instance),
    }
    rec.update(extra)
    return rec


def _first(engine: PaxosEngine, event: str, **cond: Any) -> Optional[dict[str, Any]]:
    for e in engine.events:
        if e["event"] != event:
            continue
        if all(e.get(k) == v for k, v in cond.items()):
            return e
    return None


def _all(engine: PaxosEngine, event: str, **cond: Any) -> list[dict[str, Any]]:
    out = []
    for e in engine.events:
        if e["event"] != event:
            continue
        if all(e.get(k) == v for k, v in cond.items()):
            out.append(e)
    return out


def run_interleave_two_proposers() -> dict[str, Any]:
    """Hand-simulate two proposers; record acceptor durable state after each step.

    p1 tries to choose Weekly digest (draft). After that proposal is accepted
    by a majority, p2 tries to choose Weekly digest (revised) with a higher
    proposal number, and must inherit the already-chosen draft.
    """
    eng = PaxosEngine()
    trace: list[dict[str, Any]] = []
    trace.append(_step(eng, "初始：三台 acceptor 持久状态为空"))

    eng.start_prepare("p1", _set(TITLE_DRAFT), acceptor_ids=["a1", "a2", "a3"])
    eng.run_until_quiet()
    p1_ph1 = eng.ballot_view("p1")
    trace.append(
        _step(
            eng,
            "p1 完成 n=1 的 Phase 1（prepare/promise），三台 promise，尚无 accepted value",
            proposer="p1",
            ballot=p1_ph1,
        )
    )

    # Phase 2 only to {a1, a2}, so the chosen majority is a proper subset.
    # This makes the later intersection with p2's prepare majority visible.
    eng.start_accept("p1", acceptor_ids=["a1", "a2"])
    eng.run_until_quiet()
    chosen_majority = eng.chosen_majority()
    trace.append(
        _step(
            eng,
            "p1 完成 n=1 的 Phase 2，{a1,a2} 接受 Weekly digest (draft)，该提案被选中；a3 未接受",
            proposer="p1",
            ballot=eng.ballot_view("p1"),
            chosen_majority=chosen_majority,
        )
    )
    chosen_after_p1 = eng.chosen_value()

    # p2 wants a different title, prepares a higher number to {a2, a3}.
    eng.start_prepare("p2", _set(TITLE_V2), acceptor_ids=["a2", "a3"])
    eng.run_until_quiet()
    p2_ph1 = eng.ballot_view("p2")
    intersection = sorted(set(p2_ph1["promises"]) & set(chosen_majority or []))
    trace.append(
        _step(
            eng,
            "p2 完成 n=2 的 Phase 1，prepare 多数派 {a2,a3} 与选中多数派相交，必须继承 draft",
            proposer="p2",
            ballot=p2_ph1,
            intended_value=TITLE_V2,
            inherited=p2_ph1["inherited"],
            inherited_value=p2_ph1["issued_value"],
            inherit_from_n=p2_ph1["inherit_from_n"],
            inherit_from_acceptor=p2_ph1["inherit_from_acceptor"],
            prepare_majority=p2_ph1["promises"],
            chosen_majority=chosen_majority,
            majority_intersection=intersection,
        )
    )

    accept_info = eng.start_accept("p2", value=_set(TITLE_V2), acceptor_ids=["a2", "a3"])
    eng.run_until_quiet()
    trace.append(
        _step(
            eng,
            "p2 完成 n=2 的 Phase 2，发出的是继承来的 draft，而不是自己的 revised；值仍然是 draft",
            proposer="p2",
            ballot=eng.ballot_view("p2"),
            accept_info=accept_info,
        )
    )

    # Durable state survives restart (paper §2.5).
    before_restart = eng.durable_snapshot()
    eng.crash("a2")
    eng.restart("a2")
    after_restart = eng.durable_snapshot()
    restart_preserved = after_restart["a2"] == before_restart["a2"]
    trace.append(
        _step(
            eng,
            "a2 crash 后 restart，promised / accepted 持久状态仍然在（教学 dict，不是磁盘）",
            restart_preserved=restart_preserved,
            a2_before=before_restart["a2"],
            a2_after=after_restart["a2"],
        )
    )

    final = eng.durable_snapshot()
    return {
        "rpc_delay_s": RPC_DELAY_S,
        "majority": eng.majority,
        "proposers": eng.proposer_ids,
        "acceptors": eng.acceptor_ids,
        "proposal_sets": {"p1": "奇数 1,3,5,…", "p2": "偶数 2,4,6,…"},
        "trace": trace,
        "final_acceptors": final,
        "final_diagram": eng.format_acceptors(),
        "chosen_after_p1": chosen_after_p1,
        "chosen_after_p2": eng.chosen_value(),
        "chosen_majority_after_p1": chosen_majority,
        "p2_intended": TITLE_V2,
        "p2_inherited": p2_ph1["inherited"],
        "p2_inherited_value": p2_ph1["issued_value"],
        "p2_inherit_from_n": p2_ph1["inherit_from_n"],
        "p2_inherit_from_acceptor": p2_ph1["inherit_from_acceptor"],
        "p2_prepare_majority": p2_ph1["promises"],
        "majority_intersection": intersection,
        "ignored_own_value": accept_info["ignored_own_value"],
        "chosen_is_draft": eng.chosen_value() == TITLE_DRAFT,
        "revised_never_chosen": all(p["value"] != TITLE_V2 for p in eng.chosen_proposals()),
        "restart_preserved": restart_preserved,
        "safety_ok": eng.safety_ok(),
        "flush_count": eng.flush_count,
        "t_end": eng.now(),
        "phase1_events": _all(eng, "phase1_complete"),
        "chosen_events": _all(eng, "chosen"),
        "accept_rejected": _all(eng, "accept_rejected"),
    }


def run_partial_accept_not_chosen() -> dict[str, Any]:
    """If a value was accepted only by a minority, another majority may propose a different value."""
    eng = PaxosEngine()
    trace: list[dict[str, Any]] = []
    trace.append(_step(eng, "初始"))

    eng.start_prepare("p1", _set(TITLE_DRAFT), acceptor_ids=["a1", "a2", "a3"])
    eng.run_until_quiet()
    eng.start_accept("p1", acceptor_ids=["a1"])  # minority only
    eng.run_until_quiet()
    trace.append(
        _step(
            eng,
            "p1 只让 a1 接受 n=1 的 draft，未形成多数派，draft 尚未被选中",
            chosen_majority=eng.chosen_majority(),
        )
    )
    not_chosen_after_partial = eng.chosen_value() is None

    eng.start_prepare("p2", _set(TITLE_V2), acceptor_ids=["a2", "a3"])
    eng.run_until_quiet()
    p2 = eng.ballot_view("p2")
    intersection_with_a1 = sorted(set(p2["promises"]) & {"a1"})
    trace.append(
        _step(
            eng,
            "p2 向 {a2,a3} 做 Phase 1，与唯一接受 draft 的 a1 不相交，因此不必继承 draft",
            ballot=p2,
            intersection_with_a1=intersection_with_a1,
        )
    )

    eng.start_accept("p2", acceptor_ids=["a2", "a3"])
    eng.run_until_quiet()
    trace.append(
        _step(
            eng,
            "p2 用自己的 revised 完成 Phase 2，{a2,a3} 接受后 revised 被选中",
            ballot=eng.ballot_view("p2"),
        )
    )

    return {
        "trace": trace,
        "final_diagram": eng.format_acceptors(),
        "final_acceptors": eng.durable_snapshot(),
        "not_chosen_after_partial": not_chosen_after_partial,
        "p2_inherited": p2["inherited"],
        "p2_issued_value": p2["issued_value"],
        "p2_prepare_majority": p2["promises"],
        "intersection_with_partial_acceptor": intersection_with_a1,
        "chosen": eng.chosen_value(),
        "chosen_is_revised": eng.chosen_value() == TITLE_V2,
        "draft_never_chosen": all(p["value"] != TITLE_DRAFT for p in eng.chosen_proposals()),
        "safety_ok": eng.safety_ok(),
        "t_end": eng.now(),
        "contrast": (
            "部分接受不是选中。只有当某个提案已被多数派接受，"
            "任意新的 prepare 多数派才会与之相交，从而被迫继承该值。"
        ),
    }


def run_proposal_number_bounds() -> dict[str, Any]:
    """Proposal numbers come from disjoint sets, are never reused, and lower n is ignored."""
    eng = PaxosEngine()
    events_of_interest: list[dict[str, Any]] = []

    def rec(name: str, **extra: Any) -> None:
        events_of_interest.append(_step(eng, name, **extra))

    rec("初始")

    # p2 first claims n=2, so later p1 n=1 prepare is stale.
    r = eng.start_prepare("p2", _set(TITLE_HOTFIX), n=2)
    eng.run_until_quiet()
    rec("p2 用属于自己的偶数编号 n=2 完成 Phase 1，三台 promised=2", prepare=r, ballot=eng.ballot_view("p2"))

    # p1 tries a lower number from its own set.
    r = eng.start_prepare("p1", _set(TITLE_DRAFT), n=1)
    eng.run_until_quiet()
    ignored = _all(eng, "prepare_ignored")
    rec(
        "p1 用更小的 n=1 发 prepare，三台都忽略（已 promise 过 2）",
        prepare=r,
        prepare_ignored_count=len(ignored),
        prepare_ignored=[{"t": e["t"], "acceptor": e["acceptor"], "n": e["n"]} for e in ignored],
        ballot=eng.ballot_view("p1"),
    )

    # p1 retries with a legal higher number from its set.
    r = eng.start_prepare("p1", _set(TITLE_DRAFT), n=3)
    eng.run_until_quiet()
    rec("p1 改用 n=3 完成 Phase 1，三台 promised=3", prepare=r, ballot=eng.ballot_view("p1"))

    # p2's stale phase 2 for n=2 is rejected.
    r = eng.start_accept("p2")
    eng.run_until_quiet()
    rejected = _all(eng, "accept_rejected")
    rec(
        "p2 仍用 n=2 发 accept，三台拒绝（promised=3 > 2）",
        accept=r,
        accept_rejected_count=len(rejected),
        accept_rejected=[{"t": e["t"], "acceptor": e["acceptor"], "n": e["n"], "promised_n": e["promised_n"]} for e in rejected],
        chosen=eng.chosen_value(),
    )

    reuse_error = None
    try:
        eng.start_prepare("p1", _set(TITLE_DRAFT), n=3)
    except ValueError as exc:
        reuse_error = str(exc)
    rec("p1 试图再次使用已经用过的 n=3，引擎拒绝（提案编号不可复用）", reuse_error=reuse_error)

    wrong_set_error = None
    try:
        eng.start_prepare("p1", _set(TITLE_DRAFT), n=4)
    except ValueError as exc:
        wrong_set_error = str(exc)
    rec("p1 试图使用属于 p2 集合的 n=4，引擎拒绝（不同 proposer 使用不相交编号集合）", wrong_set_error=wrong_set_error)

    # p1 completes with n=3.
    r = eng.start_accept("p1")
    eng.run_until_quiet()
    rec("p1 用 n=3 完成 Phase 2，draft 被选中", accept=r, ballot=eng.ballot_view("p1"))

    return {
        "trace": events_of_interest,
        "final_diagram": eng.format_acceptors(),
        "final_acceptors": eng.durable_snapshot(),
        "prepare_ignored_count": len(ignored),
        "accept_rejected_count": len(rejected),
        "reuse_rejected": reuse_error is not None,
        "reuse_error": reuse_error,
        "wrong_set_rejected": wrong_set_error is not None,
        "wrong_set_error": wrong_set_error,
        "chosen": eng.chosen_value(),
        "chosen_is_draft": eng.chosen_value() == TITLE_DRAFT,
        "hotfix_never_chosen": all(p["value"] != TITLE_HOTFIX for p in eng.chosen_proposals()),
        "p1_numbers": "1,3,5,…",
        "p2_numbers": "2,4,6,…",
        "safety_ok": eng.safety_ok(),
        "t_end": eng.now(),
    }


def run_livelock_vs_safety() -> dict[str, Any]:
    """Two proposers keep completing phase 1 with higher numbers; no value is chosen, but safety holds."""
    eng = PaxosEngine()
    trace: list[dict[str, Any]] = []

    def rec(name: str, **extra: Any) -> None:
        trace.append(_step(eng, name, **extra))

    rec("初始")

    # Cycle 1: p1 phase 1 n=1, then p2 phase 1 n=2 preempts p1's phase 2.
    eng.start_prepare("p1", _set(TITLE_DRAFT))
    eng.run_until_quiet()
    rec("p1 完成 n=1 的 Phase 1", ballot=eng.ballot_view("p1"))

    eng.start_prepare("p2", _set(TITLE_V2))
    eng.run_until_quiet()
    rec("p2 完成更高编号 n=2 的 Phase 1，三台改 promise 为 2", ballot=eng.ballot_view("p2"))

    eng.start_accept("p1")
    eng.run_until_quiet()
    rec(
        "p1 的 n=1 accept 被拒绝（promised=2 > 1）",
        ballot=eng.ballot_view("p1"),
        nacks=eng.ballot_view("p1")["nacks_accept"],
    )

    # Cycle 2: p1 raises to n=3, preempts p2's phase 2.
    eng.start_prepare("p1", _set(TITLE_DRAFT))
    eng.run_until_quiet()
    rec("p1 放弃 n=1，完成 n=3 的 Phase 1，三台改 promise 为 3", ballot=eng.ballot_view("p1"))

    eng.start_accept("p2")
    eng.run_until_quiet()
    rec(
        "p2 的 n=2 accept 被拒绝（promised=3 > 2）",
        ballot=eng.ballot_view("p2"),
        nacks=eng.ballot_view("p2")["nacks_accept"],
    )

    # Cycle 3: p2 raises to n=4, preempts p1 again.
    eng.start_prepare("p2", _set(TITLE_V2))
    eng.run_until_quiet()
    rec("p2 放弃 n=2，完成 n=4 的 Phase 1，三台改 promise 为 4", ballot=eng.ballot_view("p2"))

    eng.start_accept("p1")
    eng.run_until_quiet()
    rec(
        "p1 的 n=3 accept 被拒绝（promised=4 > 3）",
        ballot=eng.ballot_view("p1"),
        nacks=eng.ballot_view("p1")["nacks_accept"],
    )

    # One more raise so both sides have failed twice; then stop the race.
    eng.start_prepare("p1", _set(TITLE_DRAFT))
    eng.run_until_quiet()
    rec("p1 完成 n=5 的 Phase 1，三台改 promise 为 5", ballot=eng.ballot_view("p1"))

    eng.start_accept("p2")
    eng.run_until_quiet()
    rec(
        "p2 的 n=4 accept 被拒绝（promised=5 > 4）；到此仍无值被选中",
        ballot=eng.ballot_view("p2"),
        nacks=eng.ballot_view("p2")["nacks_accept"],
    )

    t_livelock_end = eng.now()
    chosen_during_livelock = eng.chosen_value()
    rejected_during = list(_all(eng, "accept_rejected"))
    safety_during = eng.safety_ok()

    # Distinguished proposer: only p1 continues (paper §2.4). It already
    # holds a phase-1 majority for n=5, so it can issue phase 2.
    eng.start_accept("p1")
    eng.run_until_quiet()
    rec(
        "停止交错，只让 p1 作为 distinguished proposer 发出 n=5 的 Phase 2，draft 被选中",
        ballot=eng.ballot_view("p1"),
    )

    return {
        "trace": trace,
        "final_diagram": eng.format_acceptors(),
        "final_acceptors": eng.durable_snapshot(),
        "t_livelock_end": t_livelock_end,
        "chosen_during_livelock": chosen_during_livelock,
        "livelock_no_value_chosen": chosen_during_livelock is None,
        "accept_rejected_during_livelock": len(rejected_during),
        "rejected_rounds": [
            {"t": e["t"], "acceptor": e["acceptor"], "n": e["n"], "promised_n": e["promised_n"]}
            for e in rejected_during
        ],
        "safety_during_livelock": safety_during,
        "chosen_after_distinguished": eng.chosen_value(),
        "chosen_is_draft": eng.chosen_value() == TITLE_DRAFT,
        "safety_ok": eng.safety_ok(),
        "t_end": eng.now(),
        "progress_needs_distinguished_proposer": True,
        "election_is_for_progress_not_safety": True,
    }


def run_pitfall_instances_are_not_replicas() -> dict[str, Any]:
    """The number of Paxos instances is the command sequence length, not the replica count."""
    eng = PaxosEngine(proposers=["p1", "p2"])
    commands = [TITLE_V1, TITLE_V2]
    per_instance: list[dict[str, Any]] = []

    for i, title in enumerate(commands, start=1):
        eng.start_prepare("p1", _set(title), instance=i)
        eng.run_until_quiet()
        eng.start_accept("p1", instance=i)
        eng.run_until_quiet()
        per_instance.append(
            _step(
                eng,
                f"实例 {i} 选中第 {i} 条命令：SET {KEY_TITLE} = {title}",
                instance=i,
            )
        )

    snapshots = eng.durable_snapshot_all()
    acceptor_count = len(eng.acceptor_ids)
    instance_count = len(snapshots)
    # Wrong mental model: "3 acceptors means 3 Paxos instances".
    wrong_model_instance_count = acceptor_count
    return {
        "acceptor_ids": list(eng.acceptor_ids),
        "acceptor_count": acceptor_count,
        "majority": eng.majority,
        "instance_count": instance_count,
        "command_count": len(commands),
        "commands": [
            {"instance": i, "command": f"SET {KEY_TITLE} = {title}", "value": title, "chosen": eng.chosen_value(i)}
            for i, title in enumerate(commands, start=1)
        ],
        "per_instance": per_instance,
        "snapshots": snapshots,
        "diagrams": {str(i): eng.format_acceptors(i) for i in snapshots},
        "instances_equal_replicas": instance_count == acceptor_count,
        "instances_equal_commands": instance_count == len(commands),
        "wrong_model_instance_count": wrong_model_instance_count,
        "wrong_model_rejected": instance_count != wrong_model_instance_count,
        "each_acceptor_holds_all_instances": all(
            inst in eng.acceptor_persist[aid] for aid in eng.acceptor_ids for inst in snapshots
        ),
        "safety_ok": eng.safety_ok(),
        "t_end": eng.now(),
        "note": (
            "论文 §3：用一串互相独立的 Paxos 实例实现状态机，第 i 个实例选出第 i 条命令。"
            "实例数量随命令序列增长，与 acceptor / 数据副本的数量不是一回事。"
            "本实验 3 个 acceptor 上跑了 2 个实例，选出 2 条命令；再来第 3 条命令会是实例 3，"
            "仍然是这 3 个 acceptor，而不是再复制出一套新的集群。"
        ),
    }


def _command_values(n: int) -> list[str]:
    return [f"Weekly digest (cmd {i})" for i in range(1, n + 1)]


def run_single_decree_commands(n_commands: int) -> dict[str, Any]:
    eng = PaxosEngine(proposers=["p1", "p2"])
    t0 = eng.now()
    rpc0 = eng.rpc_count
    values = _command_values(n_commands)
    for i, title in enumerate(values, start=1):
        eng.start_prepare("p1", _set(title), instance=i)
        eng.run_until_quiet()
        eng.start_accept("p1", instance=i)
        eng.run_until_quiet()
        if eng.chosen_value(i) != title:
            raise RuntimeError(f"instance {i} did not choose {title}: {eng.chosen_value(i)}")
    return {
        "mode": "single_decree",
        "n_commands": n_commands,
        "elapsed_s": ts(eng.now() - t0),
        "t_end": eng.now(),
        "rpc_count": eng.rpc_count - rpc0,
        "flush_count": eng.flush_count,
        "phases_per_command": 2,
        "all_chosen": all(eng.chosen_value(i) == values[i - 1] for i in range(1, n_commands + 1)),
        "safety_ok": eng.safety_ok(),
    }


def run_multipaxos_commands(n_commands: int) -> dict[str, Any]:
    """Teaching Multi-Paxos contrast: one Phase 1 for many instances, then Phase 2 only.

    This models the paper §3 observation that a stable leader can use the same
    proposal number and a single reasonably short Phase-1 message for many
    instances, after which a new command costs only Phase 2. It is not a full
    Multi-Paxos implementation: no leader election, no no-op gap fill, no
    α-ahead window, no reconfiguration.
    """
    eng = PaxosEngine(proposers=["p1", "p2"])
    t0 = eng.now()
    rpc0 = eng.rpc_count
    values = _command_values(n_commands)
    instances = list(range(1, n_commands + 1))
    # Range prepare: one message per acceptor, same n, covering all instances.
    # Intended value is left unconstrained; each start_accept supplies the command.
    eng.start_prepare("p1", value=None, instances=instances)
    eng.run_until_quiet()
    t_after_prepare = eng.now()
    rpc_after_prepare = eng.rpc_count - rpc0
    for i, title in enumerate(values, start=1):
        view = eng.ballot_view("p1", instance=i)
        if not view or not view["phase1_complete"] or view["inherited"]:
            raise RuntimeError(f"instance {i} was not unconstrained after range prepare: {view}")
        eng.start_accept("p1", instance=i, value=_set(title))
        eng.run_until_quiet()
        if eng.chosen_value(i) != title:
            raise RuntimeError(f"instance {i} did not choose {title}: {eng.chosen_value(i)}")
    return {
        "mode": "multipaxos_teaching_contrast",
        "n_commands": n_commands,
        "elapsed_s": ts(eng.now() - t0),
        "t_end": eng.now(),
        "t_after_prepare": t_after_prepare,
        "rpc_count": eng.rpc_count - rpc0,
        "rpc_phase1": rpc_after_prepare,
        "rpc_phase2": (eng.rpc_count - rpc0) - rpc_after_prepare,
        "flush_count": eng.flush_count,
        "phases_for_first_command": 2,
        "phases_for_later_commands": 1,
        "all_chosen": all(eng.chosen_value(i) == values[i - 1] for i in range(1, n_commands + 1)),
        "safety_ok": eng.safety_ok(),
        "not_full_multipaxos": True,
        "paper_section": "§3",
    }


def run_tradeoff_paper_vs_multipaxos() -> dict[str, Any]:
    cases = {}
    for n in (5, 20):
        cases[f"single_{n}"] = run_single_decree_commands(n)
        cases[f"multi_{n}"] = run_multipaxos_commands(n)
    s20 = cases["single_20"]
    m20 = cases["multi_20"]
    s5 = cases["single_5"]
    m5 = cases["multi_5"]
    return {
        "cases": cases,
        "table": [
            {
                "mode": "single_decree",
                "n_commands": 5,
                "elapsed_s": s5["elapsed_s"],
                "rpc_count": s5["rpc_count"],
                "phases_per_command": 2,
            },
            {
                "mode": "multipaxos_teaching_contrast",
                "n_commands": 5,
                "elapsed_s": m5["elapsed_s"],
                "rpc_count": m5["rpc_count"],
                "phases_per_command": "2 then 1",
            },
            {
                "mode": "single_decree",
                "n_commands": 20,
                "elapsed_s": s20["elapsed_s"],
                "rpc_count": s20["rpc_count"],
                "phases_per_command": 2,
            },
            {
                "mode": "multipaxos_teaching_contrast",
                "n_commands": 20,
                "elapsed_s": m20["elapsed_s"],
                "rpc_count": m20["rpc_count"],
                "phases_per_command": "2 then 1",
            },
        ],
        "multipaxos_fewer_rpcs_for_same_commands": m20["rpc_count"] < s20["rpc_count"]
        and m5["rpc_count"] < s5["rpc_count"],
        "multipaxos_faster_on_virtual_clock": m20["elapsed_s"] < s20["elapsed_s"]
        and m5["elapsed_s"] < s5["elapsed_s"],
        "rpc_saved_20": s20["rpc_count"] - m20["rpc_count"],
        "elapsed_saved_20_s": ts(s20["elapsed_s"] - m20["elapsed_s"]),
        "stable_leader_skips_phase1": True,
        "rpc_delay_s": RPC_DELAY_S,
        "note": (
            "这些时间是教学虚拟时钟上的数字：每次 RPC 单向延迟 0.01 秒，不是生产 RTT。"
            "Multi-Paxos 对比只实现了「稳定领导复用 Phase 1」这一条，不是完整 Multi-Paxos。"
        ),
    }


def run() -> dict[str, Any]:
    interleave = run_interleave_two_proposers()
    partial = run_partial_accept_not_chosen()
    bounds = run_proposal_number_bounds()
    livelock = run_livelock_vs_safety()
    pitfall = run_pitfall_instances_are_not_replicas()
    tradeoff = run_tradeoff_paper_vs_multipaxos()
    return {
        "engine": "PaxosEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_full_paxos": True,
        "not_full_multipaxos": True,
        "not_raft": True,
        "not_jepsen": True,
        "majority_of_three": 2,
        "rpc_delay_s": RPC_DELAY_S,
        "key": KEY_TITLE,
        "interleave_two_proposers": interleave,
        "partial_accept_not_chosen": partial,
        "proposal_number_bounds": bounds,
        "livelock_vs_safety": livelock,
        "pitfall_instances_are_not_replicas": pitfall,
        "tradeoff_paper_vs_multipaxos": tradeoff,
        "acceptance_new_proposer_inherits_chosen_value": interleave["p2_inherited"]
        and interleave["chosen_is_draft"]
        and interleave["ignored_own_value"],
        "acceptance_livelock_vs_safety": livelock["livelock_no_value_chosen"]
        and livelock["safety_during_livelock"]
        and livelock["chosen_after_distinguished"] == TITLE_DRAFT,
        "pitfall_instances_not_equal_replicas": pitfall["wrong_model_rejected"]
        and pitfall["instances_equal_commands"],
        "tradeoff_stable_leader_saves_phase1": tradeoff["multipaxos_fewer_rpcs_for_same_commands"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("wrote", path)
