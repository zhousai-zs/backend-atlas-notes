#!/usr/bin/env bash
# Backend Atlas 第50课实践验证：UDP 报文边界/截断、丢包重试、请求ID匹配、超时上限
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18050
fuser -k ${PORT}/udp 2>/dev/null || true
sleep 0.2

python3 server.py "$PORT" > /tmp/udp50-srv.log 2>&1 &
SRV=$!
cleanup(){ kill $SRV 2>/dev/null; wait $SRV 2>/dev/null; }
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/udp50-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

SSOUT=$(ss -uan "sport = :$PORT" 2>/dev/null || ss -uan | grep ":$PORT" || true)
echo "$SSOUT" | head -5
echo "$SSOUT" | grep -q ":$PORT" && ok "ss -uan 可见 UDP 监听 :$PORT" || bad "ss 未见 UDP :$PORT"

# 1) 基本请求响应
OUT=$(python3 client.py --port "$PORT" --payload 'echo:hello' --timeout 0.5 --retries 1 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "基本 REQ/RSP 成功" || bad "基本请求失败: $OUT"
echo "$OUT" | grep -q "body_prefix='hello'" && ok "响应 body 正确" || bad "响应 body 不对"

# 2) 截断检测（MSG_TRUNC）
TOUT=$(python3 trunc_probe.py 127.0.0.1 "$PORT" 80 4000 2>&1) || true
echo "$TOUT"
echo "$TOUT" | grep -q "truncated=1" && ok "能检测接收缓冲区截断 (MSG_TRUNC)" || bad "截断未检出: $TOUT"

TOUT2=$(python3 trunc_probe.py 127.0.0.1 "$PORT" 20000 4000 2>&1) || true
echo "$TOUT2"
echo "$TOUT2" | grep -q "truncated=0" && ok "足够大的 recvbuf 不截断" || bad "大缓冲仍报截断: $TOUT2"

# 3) 服务端丢包注入 + 有限重试
OUT=$(python3 client.py --port "$PORT" --payload 'drop:2' --timeout 0.25 --retries 5 --max-sends 6 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "丢包后有限重试最终成功" || bad "丢包重试失败: $OUT"
SENDS=$(echo "$OUT" | grep "RESULT ok" | sed -n 's/.*sends=\([0-9]*\).*/\1/p')
if [ "${SENDS:-0}" -ge 3 ] && [ "${SENDS:-0}" -le 6 ]; then
  ok "重试次数受控 sends=$SENDS (期望约3, 上限6)"
else
  bad "重试次数异常 sends=$SENDS"
fi

# 4) 超时后不会无限发送
OUT=$(python3 client.py --port "$PORT" --payload 'delay:800:late' --timeout 0.15 --retries 2 --max-sends 3 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -qE "RESULT (fail_timeout|abort_max_sends)" && ok "超时/上限后停止发送（不无限重试）" || bad "未按预期停止: $OUT"
SENDS=$(echo "$OUT" | grep -E "RESULT " | sed -n 's/.*sends=\([0-9]*\).*/\1/p' | tail -1)
if [ "${SENDS:-99}" -le 3 ]; then
  ok "总发送次数受硬上限约束 sends=$SENDS <=3"
else
  bad "发送次数过多 sends=$SENDS"
fi
# drain late responses
sleep 1.0

# 5) 请求ID：同 socket 先收错 id 再收对 id，必须忽略错配
OUT=$(python3 - <<PY
import socket, time
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(1.0)
s.sendto(b"REQ|AAA00001|echo:A", ("127.0.0.1", $PORT))
s.sendto(b"REQ|BBB00002|echo:B", ("127.0.0.1", $PORT))
want = "BBB00002"
deadline = time.time() + 1.5
mismatched = 0
matched = None
while time.time() < deadline:
    try:
        data, _ = s.recvfrom(4096)
    except socket.timeout:
        break
    text = data.decode()
    parts = text.split("|", 2)
    if len(parts) != 3 or parts[0] != "RSP":
        mismatched += 1
        continue
    if parts[1] != want:
        mismatched += 1
        print(f"ignore_mismatch {parts[1]}", flush=True)
        continue
    matched = parts[2]
    break
print(f"match={matched} mismatched={mismatched}")
s.close()
PY
)
echo "$OUT"
echo "$OUT" | grep -q "match=B" && ok "只接受匹配 req_id 的响应 (got B)" || bad "未正确匹配 B: $OUT"
echo "$OUT" | grep -qE "mismatched=[1-9]" && ok "错配响应被计数忽略 (mismatched>=1)" || bad "未见错配计数: $OUT"

# 5b) 快请求不被慢响应误配（同客户端过滤）
OUT=$(python3 - <<PY
import socket, time
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(0.3)
# slow then fast on same socket
s.sendto(b"REQ|slow0001|delay:500:SLOW", ("127.0.0.1", $PORT))
time.sleep(0.05)
s.sendto(b"REQ|fast0001|echo:FAST", ("127.0.0.1", $PORT))
want = "fast0001"
deadline = time.time() + 0.8
mismatched = 0
matched = None
while time.time() < deadline:
    remain = deadline - time.time()
    if remain <= 0:
        break
    s.settimeout(max(remain, 0.01))
    try:
        data, _ = s.recvfrom(4096)
    except socket.timeout:
        continue
    parts = data.decode().split("|", 2)
    if len(parts) != 3:
        mismatched += 1
        continue
    if parts[1] != want:
        mismatched += 1
        continue
    matched = parts[2]
    break
print(f"match={matched} mismatched={mismatched}")
# also wait and ensure SLOW eventually arrives but we already matched FAST
s.settimeout(1.0)
try:
    data, _ = s.recvfrom(4096)
    print("later", data.decode())
except Exception as e:
    print("later_err", e)
s.close()
PY
)
echo "$OUT"
echo "$OUT" | grep -q "match=FAST" && ok "请求ID匹配：快请求配到 FAST 而非迟到慢响应" || bad "请求ID误配: $OUT"

# 6) 重复响应：接受首个匹配
OUT=$(python3 client.py --port "$PORT" --payload 'dup2' --timeout 0.5 --retries 0 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && echo "$OUT" | grep -q "body_prefix='first'" && ok "重复响应：接受首个匹配，body=first" || bad "重复响应处理失败: $OUT"

# 7) 客户端注入丢包
OUT=$(python3 client.py --port "$PORT" --payload 'echo:lossy' --timeout 0.3 --retries 8 --inject-loss 0.7 --max-sends 9 2>&1) || true
echo "$OUT"
echo "$OUT" | grep -q "RESULT ok" && ok "客户端注入丢包后有限重试仍可成功" || {
  OUT=$(python3 client.py --port "$PORT" --payload 'echo:lossy' --timeout 0.3 --retries 10 --inject-loss 0.4 --max-sends 11 2>&1) || true
  echo "$OUT"
  echo "$OUT" | grep -q "RESULT ok" && ok "客户端注入丢包后有限重试仍可成功(二次)" || bad "注入丢包最终失败: $OUT"
}

# 8) 报文边界
OUT=$(python3 - <<PY
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(1)
s.sendto(b"REQ|BND00001|echo:PART1", ("127.0.0.1", $PORT))
s.sendto(b"REQ|BND00002|echo:PART2", ("127.0.0.1", $PORT))
a,_ = s.recvfrom(4096)
b,_ = s.recvfrom(4096)
print(a.decode())
print(b.decode())
assert b"PART1PART2" not in a and b"PART1PART2" not in b
assert b"PART1" in a or b"PART1" in b
assert b"PART2" in a or b"PART2" in b
print("boundary_ok")
s.close()
PY
) || true
echo "$OUT"
echo "$OUT" | grep -q "boundary_ok" && ok "UDP 保留报文边界：两次 sendto 不会粘成一段" || bad "报文边界失败: $OUT"

echo "--- ss -uan ---"; ss -uan | head -20 || true
echo "--- /proc/sys/net/ipv4/udp_mem ---"; cat /proc/sys/net/ipv4/udp_mem 2>/dev/null || true
echo "NOTE: box 若无 tcpdump，抓包步骤请在有权限的机器上按课文执行。"

[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
