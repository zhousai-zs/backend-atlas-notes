#!/usr/bin/env python3
"""UDP request-response client with req_id, timeout, retry, truncation detect.

Usage examples:
  python3 client.py --port 18050 --payload 'echo:hi' --timeout 0.3 --retries 3
  python3 client.py --port 18050 --payload 'big:8000' --recvbuf 100
  python3 client.py --port 18050 --payload 'drop:2' --retries 5 --timeout 0.2
  python3 client.py --inject-loss 0.5 ...   # client-side: randomly skip send
  python3 client.py --inject-dup 1 ...     # client-side: send twice
"""
import argparse
import os
import random
import socket
import struct
import sys
import time
import uuid


def parse_rsp(data: bytes):
    text = data.decode("utf-8", errors="replace")
    parts = text.split("|", 2)
    if len(parts) != 3 or parts[0] != "RSP":
        return None, None, text
    return parts[1], parts[2], text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18050)
    ap.add_argument("--payload", required=True)
    ap.add_argument("--req-id", default=None)
    ap.add_argument("--timeout", type=float, default=0.5)
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--recvbuf", type=int, default=65535)
    ap.add_argument("--inject-loss", type=float, default=0.0,
                    help="probability to skip sending a datagram (simulate loss)")
    ap.add_argument("--inject-dup", type=int, default=0,
                    help="extra duplicate sends per attempt")
    ap.add_argument("--max-sends", type=int, default=None,
                    help="hard cap on total sendto calls (anti infinite retry)")
    args = ap.parse_args()

    req_id = args.req_id or uuid.uuid4().hex[:8]
    msg = f"REQ|{req_id}|{args.payload}".encode()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # intentionally small recv buffer size for truncation test via recvfrom(n)
    # Note: SO_RCVBUF is kernel queue; truncation is about the user buffer size
    # passed to recvfrom.
    sock.settimeout(args.timeout)

    max_sends = args.max_sends if args.max_sends is not None else (args.retries + 1)
    sends = 0
    attempt = 0
    matched = None
    truncated = False
    mismatched = 0
    late_or_extra = 0

    while attempt <= args.retries:
        if sends >= max_sends:
            print(f"RESULT abort_max_sends sends={sends} attempts={attempt}")
            sys.exit(2)

        # inject loss: skip this send
        do_send = True
        if args.inject_loss > 0 and random.random() < args.inject_loss:
            do_send = False
            print(f"inject_loss skip attempt={attempt}", flush=True)

        if do_send:
            sock.sendto(msg, (args.host, args.port))
            sends += 1
            for _ in range(args.inject_dup):
                if sends >= max_sends:
                    break
                sock.sendto(msg, (args.host, args.port))
                sends += 1
                print(f"inject_dup send attempt={attempt}", flush=True)

        # wait for matching response within timeout window for this attempt
        deadline = time.monotonic() + args.timeout
        got_match = False
        while time.monotonic() < deadline:
            remain = deadline - time.monotonic()
            if remain <= 0:
                break
            sock.settimeout(remain)
            try:
                data, addr = sock.recvfrom(args.recvbuf)
            except socket.timeout:
                break
            except Exception as e:
                print(f"recv_err {e}", flush=True)
                break

            # truncation detection: if we asked for small buf and got exactly
            # buf size, it MAY be truncated. Use MSG_TRUNC via recvmsg if available.
            # Python: sock.recvmsg with MSG_TRUNC on Linux.
            # For the simple path: if len(data)==recvbuf and payload asked big,
            # treat as suspect; better check with a second probe using MSG_TRUNC.
            rid, body, raw = parse_rsp(data)
            if rid is None:
                mismatched += 1
                print(f"bad_rsp {raw[:80]!r}", flush=True)
                continue
            if rid != req_id:
                mismatched += 1
                print(f"mismatch want={req_id} got={rid}", flush=True)
                continue

            # matched req_id
            # detect truncation with MSG_TRUNC on a known-large reply is done
            # in test.sh via a dedicated path; here mark if filled buffer.
            if len(data) >= args.recvbuf:
                truncated = True
            matched = body
            got_match = True
            print(
                f"RESULT ok req_id={req_id} sends={sends} attempts={attempt} "
                f"truncated={int(truncated)} mismatched={mismatched} "
                f"body_len={len(body)} body_prefix={body[:40]!r}",
                flush=True,
            )
            sock.close()
            sys.exit(0)

        attempt += 1
        print(f"timeout attempt={attempt-1} sends={sends}", flush=True)

    print(
        f"RESULT fail_timeout req_id={req_id} sends={sends} attempts={attempt} "
        f"mismatched={mismatched}",
        flush=True,
    )
    sock.close()
    sys.exit(1)


if __name__ == "__main__":
    main()
