#!/usr/bin/env python3
"""Probe UDP truncation with MSG_TRUNC (Linux)."""
import socket
import sys
import uuid

host = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
port = int(sys.argv[2]) if len(sys.argv) > 2 else 18050
recvbuf = int(sys.argv[3]) if len(sys.argv) > 3 else 100
big_n = int(sys.argv[4]) if len(sys.argv) > 4 else 5000

req_id = uuid.uuid4().hex[:8]
msg = f"REQ|{req_id}|big:{big_n}".encode()

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(2.0)
s.sendto(msg, (host, port))

# recvmsg with MSG_TRUNC: flags in return will include MSG_TRUNC if truncated
MSG_TRUNC = getattr(socket, "MSG_TRUNC", 0x20)
data, ancdata, flags, addr = s.recvmsg(recvbuf, 0, MSG_TRUNC)
text = data.decode("utf-8", errors="replace")
parts = text.split("|", 2)
ok_id = parts[1] if len(parts) == 3 else "?"
truncated = bool(flags & MSG_TRUNC)
print(
    f"trunc_probe req_id={req_id} got_id={ok_id} recv_len={len(data)} "
    f"recvbuf={recvbuf} flags=0x{flags:x} truncated={int(truncated)}"
)
s.close()
sys.exit(0 if truncated else 1)
