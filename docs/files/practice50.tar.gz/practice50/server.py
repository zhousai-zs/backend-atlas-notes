#!/usr/bin/env python3
"""UDP demo server for Backend Atlas lesson 50 (d-udp)."""
import socket
import sys
import threading
import time

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18050
drop_map = {}
drop_lock = threading.Lock()

srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 256 * 1024)
srv.bind((HOST, PORT))
print(f"udp listening on {HOST}:{PORT}", flush=True)


def send_later(sock, data, addr, delay_ms):
    time.sleep(max(0, delay_ms) / 1000.0)
    try:
        sock.sendto(data, addr)
    except Exception as e:
        print("send_later err", e, flush=True)


while True:
    try:
        data, addr = srv.recvfrom(65535)
    except Exception as e:
        print("recv err", e, flush=True)
        continue
    try:
        text = data.decode("utf-8", errors="replace")
        parts = text.split("|", 2)
        if len(parts) != 3 or parts[0] != "REQ":
            srv.sendto(b"RSP|0|ERR:bad-format", addr)
            continue
        _, req_id, payload = parts

        if payload.startswith("drop:"):
            n = int(payload.split(":", 1)[1] or "1")
            with drop_lock:
                left = drop_map.get(req_id, n)
                if left > 0:
                    drop_map[req_id] = left - 1
                    print(f"drop req_id={req_id} left={left-1}", flush=True)
                    continue
                drop_map.pop(req_id, None)
            resp = f"RSP|{req_id}|dropped-then-ok"
            srv.sendto(resp.encode(), addr)
            continue

        if payload.startswith("delay:"):
            rest = payload[len("delay:"):]
            ms_s, _, body = rest.partition(":")
            resp = f"RSP|{req_id}|{body}".encode()
            threading.Thread(
                target=send_later, args=(srv, resp, addr, int(ms_s)), daemon=True
            ).start()
            continue

        if payload.startswith("big:"):
            n = int(payload.split(":", 1)[1])
            n = max(0, min(n, 60000))
            body = "B" * n
            resp = f"RSP|{req_id}|{body}"
            srv.sendto(resp.encode(), addr)
            continue

        if payload.startswith("echo:"):
            body = payload[len("echo:"):]
            resp = f"RSP|{req_id}|{body}"
            srv.sendto(resp.encode(), addr)
            continue

        if payload == "dup2":
            srv.sendto(f"RSP|{req_id}|first".encode(), addr)
            srv.sendto(f"RSP|{req_id}|second".encode(), addr)
            continue

        resp = f"RSP|{req_id}|{payload}"
        srv.sendto(resp.encode(), addr)
    except Exception as e:
        print("handle err", e, flush=True)
        try:
            srv.sendto(b"RSP|0|ERR:exception", addr)
        except Exception:
            pass
