#!/bin/bash
set -e
cd "$(dirname "$0")"
gcc -O1 -g -Wall -fsanitize=address,undefined rw.c -o rw
./rw | tee out.txt
grep -Eq '^single_read=(1000|2000|3000) ' out.txt
grep -Eq '^read_full_rest=3000 calls=[2-9]' out.txt
grep -q '^after_eof_read=0$' out.txt
grep -Eq '^nonblock_short_write=[0-9]+ of 1048576' out.txt
! grep -q 'nonblock_short_write=1048576' out.txt
grep -q 'full_pipe_write=-1 errno=Resource temporarily unavailable' out.txt
grep -q 'raw_read_interrupted=-1 errno=Interrupted system call' out.txt
grep -Eq 'read_full_after_eintr=5 eintr=[1-9] data=hello' out.txt
grep -q 'stale_errno=No such file or directory' out.txt
echo ALL_CHECKS_PASSED
