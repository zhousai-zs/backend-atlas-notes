#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

/* 返回已读字节数（可能 < n 表示 EOF）；出错返回 -1，errno 保留原值 */
ssize_t read_full(int fd, void *buf, size_t n, int *eintr_cnt, int *calls) {
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(fd, (char *)buf + got, n - got);
        if (calls) (*calls)++;
        if (r > 0) { got += (size_t)r; continue; }
        if (r == 0) break;                       /* EOF：不是错误 */
        if (errno == EINTR) { if (eintr_cnt) (*eintr_cnt)++; continue; }
        return -1;                               /* 其他错误：不重试，交给调用者 */
    }
    return (ssize_t)got;
}
ssize_t write_full(int fd, const void *buf, size_t n, int *calls) {
    size_t put = 0;
    while (put < n) {
        ssize_t w = write(fd, (const char *)buf + put, n - put);
        if (calls) (*calls)++;
        if (w >= 0) { put += (size_t)w; continue; }
        if (errno == EINTR) continue;
        return -1;
    }
    return (ssize_t)put;
}
static void on_alrm(int s) { (void)s; }

int main(void) {
    /* 1. 短读：子进程分 4 次每次写 1000 字节，父进程一次 read(4000) 只拿到一部分 */
    int p[2]; if (pipe(p)) return 1;
    pid_t c = fork();
    if (c == 0) { close(p[0]); char b[1000]; memset(b, 'x', sizeof b);
        for (int i = 0; i < 4; i++) { write(p[1], b, sizeof b); usleep(50000); } _exit(0); }
    close(p[1]);
    char buf[8192];
    usleep(10000);
    ssize_t once = read(p[0], buf, 4000);
    printf("single_read=%zd (asked 4000)\n", once);
    int calls = 0;
    ssize_t rest = read_full(p[0], buf, 3000, NULL, &calls);
    printf("read_full_rest=%zd calls=%d\n", rest, calls);
    ssize_t eof = read(p[0], buf, 10);
    printf("after_eof_read=%zd\n", eof);
    close(p[0]); waitpid(c, NULL, 0);

    /* 2. 非阻塞管道写满 -> 短写/EAGAIN */
    int q[2]; if (pipe2(q, O_NONBLOCK)) return 1;
    static char big[1 << 20]; memset(big, 'y', sizeof big);
    ssize_t w = write(q[1], big, sizeof big);
    printf("nonblock_short_write=%zd of %zu\n", w, sizeof big);
    errno = 0; ssize_t w2 = write(q[1], big, 10);
    printf("full_pipe_write=%zd errno=%s\n", w2, w2 < 0 ? strerror(errno) : "none");
    close(q[0]); close(q[1]);

    /* 3. EINTR：无 SA_RESTART 的 SIGALRM 打断阻塞 read */
    struct sigaction sa = {0}; sa.sa_handler = on_alrm; sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, NULL);
    int r2[2]; pipe(r2);
    pid_t c2 = fork();
    if (c2 == 0) { close(r2[0]); sleep(1); write(r2[1], "hello", 5); _exit(0); }
    close(r2[1]);
    alarm(0); ualarm(200000, 0);
    errno = 0; ssize_t raw = read(r2[0], buf, 5);
    int saved = errno;
    printf("raw_read_interrupted=%zd errno=%s\n", raw, raw < 0 ? strerror(saved) : "none");
    ualarm(200000, 0);
    int eintr = 0; calls = 0;
    ssize_t ok = read_full(r2[0], buf, 5, &eintr, &calls);
    printf("read_full_after_eintr=%zd eintr=%d data=%.5s\n", ok, eintr, buf);
    close(r2[0]); waitpid(c2, NULL, 0);

    /* 4. 成功调用后 errno 可能是旧值 */
    errno = 0; open("/nonexistent/x", O_RDONLY);
    int fd = open("/dev/null", O_RDONLY);
    printf("success_fd=%d stale_errno=%s\n", fd, strerror(errno));
    close(fd);
    return 0;
}
