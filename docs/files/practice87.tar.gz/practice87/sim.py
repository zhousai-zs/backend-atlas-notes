#!/usr/bin/env python3
"""practice87: 离散时间模拟下游短暂故障下不同重试策略的请求峰值（教学示例，仅标准库）。"""
import argparse, heapq, json, random

BUCKET = 0.010          # 10ms 统计桶
CAPACITY = 200          # 每 10ms 桶下游最多成功处理的请求数，超过视为过载失败
OUTAGE_END = 0.8        # [0, 0.8s) 下游故障，返回 UNAVAILABLE

def next_delay(strategy, attempt, rng, base=0.2, mult=2.0, cap=2.0):
    """attempt: 已经失败的次数(1 起)。返回下一次重试前的等待秒数。"""
    if strategy == "immediate":
        return 0.010
    b = min(base * mult ** (attempt - 1), cap)
    if strategy == "backoff":
        return b
    if strategy == "backoff_jitter":          # full jitter: random(0, b)
        return rng.uniform(0, b)
    raise ValueError(strategy)

def simulate(strategy, n=1000, max_attempts=5, deadline=4.0, seed=42, outage_end=OUTAGE_END):
    rng = random.Random(seed)
    buckets = {}; retry_buckets = {}
    events = [(rng.uniform(0, 0.005), cid, 1) for cid in range(n)]   # 同一瞬间失败的一批在途请求 (时间, 客户端, 第几次尝试)
    heapq.heapify(events)
    ok = give_up = total = 0
    max_used_attempts = 0; max_elapsed = 0.0
    while events:
        t, cid, att = heapq.heappop(events)
        k = int(t / BUCKET)
        buckets[k] = buckets.get(k, 0) + 1
        if att > 1:
            retry_buckets[k] = retry_buckets.get(k, 0) + 1
        total += 1
        max_used_attempts = max(max_used_attempts, att)
        success = t >= outage_end and buckets[k] <= CAPACITY
        if success:
            ok += 1; max_elapsed = max(max_elapsed, t); continue
        if att >= max_attempts:
            give_up += 1; max_elapsed = max(max_elapsed, t); continue
        nt = t + next_delay(strategy, att, rng)
        if nt >= deadline:                       # 总时限：不够再试一次就放弃
            give_up += 1; max_elapsed = max(max_elapsed, t); continue
        heapq.heappush(events, (nt, cid, att + 1))
    peak_k = max(retry_buckets, key=retry_buckets.get)
    after = [v for kk, v in buckets.items() if kk * BUCKET >= outage_end]
    return dict(strategy=strategy, retry_peak_per_10ms=retry_buckets[peak_k], peak_at_ms=peak_k * 10,
                peak_after_recovery=max(after) if after else 0,
                total_attempts=total, amplification=round(total / n, 2),
                success_rate=round(ok / n, 3), give_up=give_up,
                max_attempts_used=max_used_attempts, max_elapsed_s=round(max_elapsed, 3))

def layers(k, depth, retry_layers):
    """下游完全故障时，最底层收到的请求数（每个用户请求）。retry_layers: 哪些层会重试。"""
    total = 1
    for layer in range(depth):
        total *= k if layer in retry_layers else 1
    return total

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategy", default="all", choices=["all", "immediate", "backoff", "backoff_jitter"])
    ap.add_argument("--layers", type=int, default=0)
    ap.add_argument("--attempts", type=int, default=3)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    if a.layers:
        allr = layers(a.attempts, a.layers, set(range(a.layers)))
        one = layers(a.attempts, a.layers, {0})
        print(f"layers={a.layers} attempts_per_layer={a.attempts} every_layer_retry={allr}x only_one_layer={one}x")
    else:
        ss = ["immediate", "backoff", "backoff_jitter"] if a.strategy == "all" else [a.strategy]
        for s in ss:
            r = simulate(s)
            print(json.dumps(r) if a.json else
                  f"{s:15s} retry_peak_per_10ms={r['retry_peak_per_10ms']:5d} @{r['peak_at_ms']:4d}ms after_recovery_peak={r['peak_after_recovery']:4d} "
                  f"total={r['total_attempts']:5d} amp={r['amplification']:.2f} "
                  f"success={r['success_rate']:.3f} give_up={r['give_up']:4d} "
                  f"max_att={r['max_attempts_used']} max_t={r['max_elapsed_s']}s")
