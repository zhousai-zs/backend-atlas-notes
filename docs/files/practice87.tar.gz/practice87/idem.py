#!/usr/bin/env python3
"""practice87: 非幂等写不盲目重试 + 幂等键（教学示例）。"""
import uuid

RETRYABLE = {"UNAVAILABLE", "RESOURCE_EXHAUSTED"}          # 显式白名单
NEVER = {"INVALID_ARGUMENT", "NOT_FOUND", "PERMISSION_DENIED"}

def is_retryable(code, idempotent, sent):
    """code: 错误码；idempotent: 操作是否幂等(或带幂等键)；sent: 请求是否可能已到达服务端。"""
    if code in NEVER:
        return False
    if not sent:                     # 请求从未离开客户端：重试安全
        return True
    if code in RETRYABLE or code in ("DEADLINE_EXCEEDED", "RESPONSE_LOST"):
        return idempotent            # 结果未知：只有幂等操作可以重试
    return False

class CounterServer:
    """模拟阅读数服务：第一次调用处理成功但响应丢失。"""
    def __init__(self):
        self.count = 0; self.seen = set(); self.calls = 0
    def incr(self, idem_key=None):
        self.calls += 1
        if idem_key is not None:
            if idem_key in self.seen:
                return "OK(dup)"
            self.seen.add(idem_key)
        self.count += 1
        if self.calls == 1:
            raise TimeoutError("RESPONSE_LOST")   # 已执行，但客户端没收到响应
        return "OK"

def client_call(server, max_attempts, use_key, respect_classify):
    key = str(uuid.uuid4()) if use_key else None
    for attempt in range(1, max_attempts + 1):
        try:
            return server.incr(key), attempt
        except TimeoutError:
            if respect_classify and not is_retryable("RESPONSE_LOST", idempotent=use_key, sent=True):
                return "FAILED_NO_RETRY", attempt
    return "GAVE_UP", max_attempts

if __name__ == "__main__":
    for name, use_key, respect in [("blind_retry", False, False),
                                   ("classify_no_key", False, True),
                                   ("idempotency_key", True, True)]:
        s = CounterServer()
        res, att = client_call(s, 3, use_key, respect)
        print(f"{name:16s} result={res:16s} attempts={att} server_calls={s.calls} count={s.count}")
    print("classify:", {c: is_retryable(c, idempotent=False, sent=True) for c in
          ["UNAVAILABLE", "INVALID_ARGUMENT", "DEADLINE_EXCEEDED"]},
          "unsent:", is_retryable("UNAVAILABLE", idempotent=False, sent=False))
