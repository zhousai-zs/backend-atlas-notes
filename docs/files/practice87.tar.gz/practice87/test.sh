#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 sim.py
python3 sim.py --layers 3
python3 idem.py
python3 budget.py
python3 - <<'PY'
import sim, idem, budget
r = {s: sim.simulate(s) for s in ["immediate", "backoff", "backoff_jitter"]}
imm, bo, jit = r["immediate"], r["backoff"], r["backoff_jitter"]
assert jit["retry_peak_per_10ms"] * 2 < imm["retry_peak_per_10ms"], "jitter 重试峰值应低于立即重试的一半"
assert jit["retry_peak_per_10ms"] * 2 < bo["retry_peak_per_10ms"], "jitter 应打散无抖动退避的同步波峰"
assert jit["success_rate"] > bo["success_rate"] > imm["success_rate"], "成功率顺序 jitter > backoff > immediate"
for s, x in r.items():
    assert x["max_attempts_used"] <= 5, f"{s} 超过最大尝试次数"
    assert x["max_elapsed_s"] <= 4.0, f"{s} 超过总时限"
assert sim.layers(3, 3, {0, 1, 2}) == 27 and sim.layers(3, 4, {0, 1, 2, 3}) == 81 and sim.layers(3, 3, {0}) == 3
s = idem.CounterServer(); idem.client_call(s, 3, False, False); assert s.count == 2, "盲重试应重复计数（演示问题）"
s = idem.CounterServer(); res, att = idem.client_call(s, 3, False, True); assert att == 1 and s.count == 1, "非幂等写不应重试"
s = idem.CounterServer(); res, att = idem.client_call(s, 3, True, True); assert s.count == 1 and res == "OK(dup)", "幂等键去重"
assert not idem.is_retryable("INVALID_ARGUMENT", True, True) and idem.is_retryable("UNAVAILABLE", False, False)
t = budget.RetryThrottle(); n = 0
for _ in range(100):
    t.on_result(False)
    while t.allow_retry(): n += 1; t.on_result(False)
assert n <= 5, f"令牌限流后重试应很少, got {n}"
print("ALL_CHECKS_PASSED")
PY
