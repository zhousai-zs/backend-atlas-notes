#!/usr/bin/env python3
"""practice87: gRPC 文档式 retryThrottling 令牌规则的教学模拟（以所用版本文档为准）。
失败: tokens -= 1；成功: tokens += token_ratio（不超过 max_tokens）；tokens <= max_tokens/2 时不再重试。"""
class RetryThrottle:
    def __init__(self, max_tokens=10, token_ratio=0.1):
        self.max = max_tokens; self.ratio = token_ratio; self.tokens = float(max_tokens)
    def on_result(self, ok):
        self.tokens = min(self.max, self.tokens + self.ratio) if ok else max(0.0, self.tokens - 1)
    def allow_retry(self):
        return self.tokens > self.max / 2

if __name__ == "__main__":
    t = RetryThrottle()
    retries = 0; requests = 0
    for i in range(100):                     # 下游完全故障：100 个请求全部失败
        requests += 1; t.on_result(False)
        while t.allow_retry():
            retries += 1; t.on_result(False)
    print(f"outage: requests={requests} retries={retries} tokens={t.tokens:.1f} "
          f"(without throttle, 3 attempts each => retries={requests*2})")
    ok = 0
    while not t.allow_retry():
        t.on_result(True); ok += 1
    print(f"recovery: successes_needed_to_reenable_retry={ok} tokens={t.tokens:.1f}")
