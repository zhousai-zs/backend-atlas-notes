#!/usr/bin/env python3
"""Official openai-agents 0.24.0: ScriptedModel, SQLiteSession, local redacted traces.

No live model, no paid API, no default trace exporter (we replace processors
with an in-memory LocalProcessor so nothing is uploaded even if an API key
were present in the environment). We also drop OPENAI_API_KEY from this
process environ and never print its value.
"""

from __future__ import annotations

import asyncio
import json
import os
from importlib.metadata import version
from pathlib import Path

# Do not read or print any key value. Just make sure this process will not
# accidentally export traces through the default processor + key combo.
os.environ.pop("OPENAI_API_KEY", None)

from agents import (  # noqa: E402
    Agent,
    RunConfig,
    RunContextWrapper,
    Runner,
    SQLiteSession,
    function_tool,
    set_trace_processors,
)
from agents.testing import ScriptedModel, assistant_message, function_call  # noqa: E402
from agents.tracing.processor_interface import TracingProcessor  # noqa: E402

ROOT = Path(__file__).resolve().parent
PKG = version("openai-agents")
assert PKG == "0.24.0", PKG


class LocalProcessor(TracingProcessor):
    """In-memory processor. Replaces the default BatchTraceProcessor."""

    def __init__(self):
        self.spans: list[dict] = []
        self.trace_ids: list[str] = []

    def on_trace_start(self, trace):
        self.trace_ids.append(trace.trace_id)

    def on_trace_end(self, trace):
        pass

    def on_span_start(self, span):
        pass

    def on_span_end(self, span):
        data = span.span_data.export() if hasattr(span.span_data, "export") else {"type": type(span.span_data).__name__}
        data["_span_id"] = span.span_id
        data["_trace_id"] = span.trace_id
        self.spans.append(data)

    def shutdown(self):
        pass

    def force_flush(self):
        pass


proc = LocalProcessor()
set_trace_processors([proc])  # drop the default uploader

# ---------- tool server (authorization lives here, not in a guardrail) ----------
class NoteServer:
    def __init__(self):
        self.notes: list[dict] = []
        self.denied: list[str] = []

    def write(self, user: str, text: str) -> str:
        acl = {"alice": {"read", "write"}, "bob": {"read"}}
        if "write" not in acl.get(user, set()):
            self.denied.append(user)
            return "ERROR: unauthorized"
        self.notes.append({"user": user, "text": text})
        return f"wrote:{text}"


SERVER = NoteServer()


@function_tool
def write_note(ctx: RunContextWrapper[dict], text: str, api_token: str) -> str:
    """Write a note. Authorization is enforced by the tool server, not by a guardrail."""
    user = ctx.context["user"]
    # api_token is a sensitive parameter; the server also checks the user in context.
    if api_token != "TOKEN-ALICE-999" and user != "alice":
        SERVER.denied.append(user)
        return "ERROR: unauthorized"
    return SERVER.write(user, text)


@function_tool
def boom(query: str) -> str:
    """Always fails. Used to exercise the SDK tool-error loop."""
    raise RuntimeError(f"lookup failed for {query}")


cfg_no_trace = RunConfig(tracing_disabled=True, trace_include_sensitive_data=False)

# 1) Happy tool loop, no external model
model_loop = ScriptedModel([
    [function_call("write_note", {"text": "q3-forecast", "api_token": "TOKEN-ALICE-999"}, call_id="c-ok")],
    [assistant_message("Saved the q3-forecast note.")],
])
agent_loop = Agent(name="Notes", model=model_loop, tools=[write_note], instructions="write notes")
# input/output guardrails left empty ("guardrails off")
assert agent_loop.input_guardrails == [] and agent_loop.output_guardrails == []
res_ok = Runner.run_sync(
    agent_loop,
    "please save q3-forecast",
    context={"user": "alice"},
    run_config=cfg_no_trace,
)
assert res_ok.final_output == "Saved the q3-forecast note."
assert SERVER.notes == [{"user": "alice", "text": "q3-forecast"}]
model_loop.assert_complete()

# 2) Tool error is surfaced to the next model step; the loop continues
model_err = ScriptedModel([
    [function_call("boom", {"query": "missing-row"}, call_id="c-boom")],
    [assistant_message("The lookup tool failed; I will not invent a row.")],
])
agent_err = Agent(name="Lookup", model=model_err, tools=[boom])
res_err = Runner.run_sync(agent_err, "look up missing-row", run_config=cfg_no_trace)
assert "will not invent" in res_err.final_output
# The tool output item is the SDK's generic error (we do not rely on it as model evidence).
outputs = [getattr(it, "output", None) or (it.raw_item if hasattr(it, "raw_item") else None) for it in res_err.new_items]
assert any("error occurred while running the tool" in str(o).lower() or "error" in str(o).lower() for o in outputs)
model_err.assert_complete()

# 3) Unauthorized is rejected by the server even with guardrails off
before = list(SERVER.notes)
model_unauth = ScriptedModel([
    [function_call("write_note", {"text": "should-not-land", "api_token": "TOKEN-BOB-000"}, call_id="c-bob")],
    [assistant_message("Write was rejected by the server.")],
])
agent_unauth = Agent(name="Notes", model=model_unauth, tools=[write_note], input_guardrails=[], output_guardrails=[])
res_unauth = Runner.run_sync(
    agent_unauth,
    "save should-not-land",
    context={"user": "bob"},
    run_config=cfg_no_trace,
)
assert res_unauth.final_output.startswith("Write was rejected")
assert SERVER.notes == before, "unauthorized write must not land"
assert "bob" in SERVER.denied
model_unauth.assert_complete()

# 4) SQLiteSession: same session resumes, different session does not mix
db = ROOT / "reports/sessions.db"
db.parent.mkdir(parents=True, exist_ok=True)
if db.exists():
    db.unlink()
s_alice = SQLiteSession("alice", db_path=str(db))
s_bob = SQLiteSession("bob", db_path=str(db))
model_sess = ScriptedModel([
    [assistant_message("Hello Alice, noted your report id R-1.")],
    [assistant_message("You previously mentioned report id R-1.")],
    [assistant_message("Hello Bob, I have no prior reports from you.")],
])
agent_sess = Agent(name="Mem", model=model_sess, instructions="remember user facts")
Runner.run_sync(agent_sess, "my report is R-1", session=s_alice, run_config=cfg_no_trace)
# "process restart": reopen the same file and session_id
s_alice_re = SQLiteSession("alice", db_path=str(db))
Runner.run_sync(agent_sess, "what did I mention?", session=s_alice_re, run_config=cfg_no_trace)
Runner.run_sync(agent_sess, "what did I mention?", session=s_bob, run_config=cfg_no_trace)
items_alice = asyncio.run(s_alice_re.get_items())
items_bob = asyncio.run(s_bob.get_items())
blob_a = json.dumps(items_alice, default=str)
blob_b = json.dumps(items_bob, default=str)
assert "R-1" in blob_a and len(items_alice) >= 4
assert "R-1" not in blob_b
model_sess.assert_complete()

# 5) Local traces: tool span shares a trace_id; sensitive params are omitted
proc.spans.clear()
proc.trace_ids.clear()
model_tr = ScriptedModel([
    [function_call("write_note", {"text": "trace-me", "api_token": "TOKEN-ALICE-999"}, call_id="c-tr")],
    [assistant_message("Traced write done.")],
])
agent_tr = Agent(name="Notes", model=model_tr, tools=[write_note])
cfg_tr = RunConfig(
    tracing_disabled=False,
    trace_include_sensitive_data=False,
    workflow_name="notes-write",
)
res_tr = Runner.run_sync(agent_tr, "save trace-me", context={"user": "alice"}, run_config=cfg_tr)
assert res_tr.final_output == "Traced write done."
model_tr.assert_complete()
fn_spans = [s for s in proc.spans if s.get("type") == "function" and s.get("name") == "write_note"]
assert fn_spans, proc.spans
assert all(s.get("_trace_id") in proc.trace_ids for s in fn_spans)
trace_blob = json.dumps(proc.spans, default=str)
assert "TOKEN-ALICE-999" not in trace_blob
# Official behavior: with trace_include_sensitive_data=False, function input/output stay None
assert all(s.get("input") in {None, "", "[REDACTED]"} and s.get("output") in {None, "", "[REDACTED]"} for s in fn_spans)

results = {
    "lesson": 181,
    "id": "l-sdk",
    "openai_agents": PKG,
    "is_live_model": False,
    "scripted_model_is_not_an_llm": True,
    "default_trace_exporter_replaced": True,
    "openai_api_key_used": False,
    "tool_loop_final": res_ok.final_output,
    "tool_error_final": res_err.final_output,
    "unauthorized_rejected": True,
    "unauthorized_did_not_write": SERVER.notes[-1] != {"user": "bob", "text": "should-not-land"},
    "server_notes": SERVER.notes,
    "server_denied": SERVER.denied,
    "session_alice_has_R1": "R-1" in blob_a,
    "session_bob_has_R1": "R-1" in blob_b,
    "session_alice_item_count": len(items_alice),
    "session_bob_item_count": len(items_bob),
    "trace_function_spans": fn_spans,
    "trace_ids": proc.trace_ids,
    "sensitive_token_in_traces": "TOKEN-ALICE-999" in trace_blob,
    "verified_on_this_machine": [
        "ScriptedModel_tool_loop_and_tool_error_without_external_model",
        "SQLiteSession_same_id_resumes_different_id_does_not_mix",
        "tool_server_rejects_unauthorized_with_guardrails_off",
        "local_processor_correlates_function_span_with_trace_id_and_omits_sensitive_io",
    ],
    "not_verified_on_this_machine": [
        "live_OpenAI_Responses_or_Chat_Completions_model_quality",
        "OpenAI_Traces_dashboard_upload",
        "hosted_OpenAI_Conversations_or_Sessions_store",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({
    "pkg": PKG,
    "loop": res_ok.final_output,
    "error": res_err.final_output,
    "denied": SERVER.denied,
    "notes": SERVER.notes,
    "alice_n": len(items_alice),
    "bob_has_R1": "R-1" in blob_b,
    "fn_spans": len(fn_spans),
    "token_in_traces": results["sensitive_token_in_traces"],
}, indent=2, ensure_ascii=False))
print("ALL_CHECKS_PASSED")
