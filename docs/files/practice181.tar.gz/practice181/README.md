# 实践 181：OpenAI Agents SDK 实践

在解压后的 `practice181/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv 中锁定的 openai-agents==0.24.0
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

使用官方 ScriptedModel，不调用外部模型。测试进程会去掉默认 trace 导出器，也不读取 API 密钥值。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
