#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
# Do not pass a live key into the test process.
unset OPENAI_API_KEY || true
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["openai_agents"]=="0.24.0" and r["is_live_model"] is False
assert r["unauthorized_rejected"] and r["unauthorized_did_not_write"]
assert r["session_alice_has_R1"] and r["session_bob_has_R1"] is False
assert r["trace_function_spans"] and r["sensitive_token_in_traces"] is False
assert r["openai_api_key_used"] is False and r["default_trace_exporter_replaced"] is True
print("POSTCHECK_OK")
PY
