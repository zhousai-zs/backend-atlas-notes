#!/usr/bin/env python3
"""Checks for lesson 117 practice. Prints ALL_CHECKS_PASSED on success."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import TITLE_V2

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def _write_and_load() -> dict:
    data = run()
    RESULTS.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return json.loads(RESULTS.read_text(encoding="utf-8"))


def main() -> None:
    data = _write_and_load()
    assert data["engine"] == "RaftElectionEngine"
    assert data["not_redis"] is True
    assert data["not_a_network_service"] is True
    assert data["not_full_raft"] is True
    assert data["not_paxos"] is True
    assert data["not_jepsen"] is True
    assert data["majority_of_three"] == 2
    assert data["majority_of_two"] == 2
    assert data["rpc_delay_s"] == 0.01
    assert data["heartbeat_interval_s"] == 0.05
    assert data["election_timeout_min_s"] == 0.15
    assert data["election_timeout_max_s"] == 0.30
    assert data["local_step_s"] == 0.01

    pause = data["pause_leader"]
    leaders = pause["become_leader_events"]
    assert leaders[0]["t"] == 0.17
    assert leaders[0]["server"] == "s1"
    assert leaders[0]["term"] == 1
    assert leaders[0]["votes"] == ["s1", "s2"]
    assert leaders[0]["vote_count"] == 2
    assert leaders[0]["majority"] == 2
    assert leaders[1]["t"] == 0.52
    assert leaders[1]["server"] == "s2"
    assert leaders[1]["term"] == 2
    assert leaders[1]["votes"] == ["s2", "s3"]
    assert pause["leaders_by_term"] == {"1": ["s1"], "2": ["s2"]}
    grants = {(e["t"], e["server"], e["candidate"]) for e in pause["vote_granted_events"]}
    assert (0.16, "s2", "s1") in grants
    assert (0.16, "s3", "s1") in grants
    assert (0.51, "s3", "s2") in grants
    timeouts = [e for e in pause["vote_log"] if e["event"] == "election_timeout"]
    assert timeouts[0]["t"] == 0.15 and timeouts[0]["server"] == "s1"
    assert any(e["t"] == 0.5 and e["server"] == "s2" for e in timeouts)
    assert pause["after_first_election"]["leaders"] == ["s1"]
    assert pause["after_failover"]["leaders"] == ["s2"]
    assert pause["after_failover"]["servers"]["s1"]["state"] == "leader"
    assert pause["after_failover"]["servers"]["s1"]["current_term"] == 1
    assert pause["after_failover"]["servers"]["s1"]["paused"] is True
    assert pause["after_failover"]["servers"]["s2"]["current_term"] == 2

    pv = data["persistent_vote"]
    assert pv["persisted_rejects_second_vote"] is True
    assert pv["not_persisted_grants_second_vote"] is True
    persisted = pv["persisted"]
    assert persisted["after_restart"]["servers"]["s2"]["voted_for"] == "s1"
    assert persisted["after_restart"]["servers"]["s2"]["durable_voted_for"] == "s1"
    assert persisted["s2_vote_events"][0]["t"] == 0.16
    assert persisted["s2_vote_events"][0]["candidate"] == "s1"
    assert persisted["s2_vote_events"][0]["granted"] is True
    assert persisted["s2_vote_events"][1]["t"] == 0.18
    assert persisted["s2_vote_events"][1]["candidate"] == "s3"
    assert persisted["s2_vote_events"][1]["reason"] == "already_voted"
    assert persisted["s2_vote_events"][1]["durable_voted_for"] == "s1"
    buggy = pv["not_persisted"]
    assert buggy["after_restart"]["servers"]["s2"]["voted_for"] is None
    assert buggy["after_restart"]["servers"]["s2"]["durable_voted_for"] is None
    assert buggy["s2_vote_events"][1]["t"] == 0.18
    assert buggy["s2_vote_events"][1]["candidate"] == "s3"
    assert buggy["s2_vote_events"][1]["granted"] is True

    split = data["split_vote"]
    assert split["leaders_in_term_2"] == []
    assert split["leaders_by_term"] == {"1": ["s1"], "3": ["s2"]}
    assert split["at_most_one_leader_per_term"] is True
    assert any(
        e["t"] == 0.5 and e["server"] == "s2" and e["event"] == "become_candidate" and e["term"] == 2
        for e in split["vote_log"]
    )
    assert any(
        e["t"] == 0.5 and e["server"] == "s3" and e["event"] == "become_candidate" and e["term"] == 2
        for e in split["vote_log"]
    )
    denials = [e for e in split["vote_log"] if e["event"] == "vote_denied" and e["t"] == 0.51]
    assert {e["server"] for e in denials} == {"s2", "s3"}
    assert all(e["reason"] == "already_voted" for e in denials)
    assert any(
        e["event"] == "become_leader" and e["t"] == 0.71 and e["server"] == "s2" and e["term"] == 3
        for e in split["vote_log"]
    )

    fresh = data["log_freshness"]
    assert fresh["s2_title"] == TITLE_V2
    assert fresh["s3_title"] is None
    assert fresh["s2_last_log"] == {"index": 1, "term": 1}
    assert fresh["s3_last_log"] == {"index": 0, "term": 0}
    assert fresh["leaders_by_term"] == {"1": ["s1"], "3": ["s2"]}
    denials = fresh["log_not_up_to_date_denials"]
    assert denials[0]["t"] == 0.47
    assert denials[0]["server"] == "s2"
    assert denials[0]["candidate"] == "s3"
    assert denials[0]["reason"] == "log_not_up_to_date"
    assert fresh["after_write"]["servers"]["s1"]["commit_index"] == 1
    assert fresh["after_write"]["servers"]["s2"]["title"] == TITLE_V2
    assert fresh["after_write"]["servers"]["s3"]["last_log_index"] == 0
    assert fresh["after_election"]["leaders"] == ["s2"]

    two = data["two_node"]
    assert two["n"] == 2
    assert two["majority"] == 2
    assert two["cannot_tolerate_single_failure"] is True
    assert two["live_leader_after_pause"] == []
    assert two["new_leaders_after_pause"] == []
    assert len(two["candidate_rounds_after_pause"]) == 4
    assert two["candidate_rounds_after_pause"][0]["t"] == 0.5
    assert two["candidate_rounds_after_pause"][0]["term"] == 2
    assert two["candidate_rounds_after_pause"][1]["t"] == 0.72
    assert two["candidate_rounds_after_pause"][2]["t"] == 0.94
    assert two["candidate_rounds_after_pause"][3]["t"] == 1.16
    assert two["candidate_rounds_after_pause"][3]["term"] == 5
    assert two["after_first_election"]["leaders"] == ["s1"]

    dual = data["dual_leader_observation"]
    assert dual["two_leaders_observed"] is True
    observed = dual["observed_leaders_during"]
    assert {L["id"] for L in observed} == {"s1", "s2"}
    terms = {L["id"]: L["term"] for L in observed}
    assert terms["s1"] == 1
    assert terms["s2"] == 2
    assert dual["terms_during"] == [1, 2]
    assert dual["leaders_after_heal"] == ["s2"]
    assert dual["s1_state_after_heal"] == "follower"
    assert dual["s1_term_after_heal"] == 2
    assert len(dual["dropped_heartbeats"]) == 20
    assert dual["dropped_heartbeats"][0]["t"] == 0.32
    assert dual["dropped_heartbeats"][0]["term"] == 1
    assert dual["leaders_by_term"] == {"1": ["s1"], "2": ["s2"]}

    trade = data["timeout_tradeoff"]
    short = trade["short_timeout_failover"]
    long = trade["long_timeout_failover"]
    assert short["paused_at"] == 0.3
    assert short["new_leader_at"] == 0.45
    assert short["detection_s"] == 0.15
    assert long["paused_at"] == 0.3
    assert long["new_leader_at"] == 0.6
    assert long["detection_s"] == 0.3
    assert trade["faster_detection"] is True
    sp = trade["spurious_with_short_timeout"]
    assert sp["spurious_election"] is True
    assert sp["follower_timeout_s"] == 0.12
    assert sp["rpc_delay_s"] == 0.08
    assert sp["heartbeat_interval_s"] == 0.1
    assert len(sp["spurious_candidates"]) == 5
    assert sp["spurious_candidates"][0]["t"] == 0.24
    assert sp["spurious_candidates"][0]["term"] == 2
    stable = trade["stable_with_long_timeout"]
    assert stable["spurious_election"] is False
    assert stable["spurious_candidates"] == []
    assert stable["follower_timeout_s"] == 0.3

    assert data["acceptance_at_most_one_majority_leader_per_term"] is True
    assert data["acceptance_two_node_cannot_tolerate_single_failure"] is True
    assert data["pitfall_heartbeat_does_not_prevent_dual_leader_observation"] is True
    assert data["tradeoff_short_timeout_faster_but_easier_to_mis_elect"] is True

    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
