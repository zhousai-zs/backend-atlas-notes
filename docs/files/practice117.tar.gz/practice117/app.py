#!/usr/bin/env python3
"""Run the lesson 117 Raft election experiments and record observations."""
from __future__ import annotations

from typing import Any

from engine import (
    ELECTION_TIMEOUT_MAX_S,
    ELECTION_TIMEOUT_MIN_S,
    HEARTBEAT_INTERVAL_S,
    KEY_TITLE,
    LOCAL_STEP_S,
    RPC_DELAY_S,
    TITLE_V1,
    TITLE_V2,
    Clock,
    RaftElectionEngine,
    ts,
)


def _vote_events(cluster: RaftElectionEngine) -> list[dict[str, Any]]:
    kinds = (
        "init",
        "election_timeout",
        "become_candidate",
        "vote_granted",
        "vote_denied",
        "vote_received",
        "become_leader",
        "become_follower",
        "paused",
        "unpaused",
        "crashed",
        "restarted",
        "isolated",
        "healed",
        "healed_all",
        "append_local",
        "commit",
        "message_dropped",
    )
    return [e for e in cluster.events if e["event"] in kinds]


def _leaders_by_term(cluster: RaftElectionEngine) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for e in cluster.events:
        if e["event"] == "become_leader":
            out.setdefault(str(e["term"]), []).append(e["server"])
    return out


def run_pause_leader() -> dict[str, Any]:
    """Three nodes, elect a leader, pause it, watch term and votes."""
    clock = Clock()
    c = RaftElectionEngine(
        n=3,
        clock=clock,
        timeouts={"s1": 0.15, "s2": 0.22, "s3": 0.28},
        rpc_delay_s=RPC_DELAY_S,
        heartbeat_interval_s=HEARTBEAT_INTERVAL_S,
    )
    # First election should finish shortly after 0.15 + two RPC delays.
    c.run_until(0.20)
    after_first = c.inspect()
    first_leader = after_first["leaders"]
    # Let a few heartbeats go out, then pause the leader.
    c.run_until(0.30)
    before_pause = c.inspect()
    leader = before_pause["leaders"][0] if before_pause["leaders"] else None
    assert leader == "s1"
    c.pause("s1")
    # s2's timer is last heartbeat delivery + 0.22. Wait long enough
    # for a new election (and a bit more to see the new leader settle).
    c.run_until(0.70)
    after_failover = c.inspect()
    return {
        "timeouts": {"s1": 0.15, "s2": 0.22, "s3": 0.28},
        "rpc_delay_s": RPC_DELAY_S,
        "heartbeat_interval_s": HEARTBEAT_INTERVAL_S,
        "after_first_election": after_first,
        "before_pause": before_pause,
        "paused": "s1",
        "after_failover": after_failover,
        "leaders_by_term": _leaders_by_term(c),
        "vote_log": _vote_events(c),
        "become_leader_events": c.events_of("become_leader"),
        "vote_granted_events": c.events_of("vote_granted"),
        "vote_denied_events": c.events_of("vote_denied"),
    }


def run_persistent_vote() -> dict[str, Any]:
    """A voter that persisted votedFor will not vote twice in the same term."""

    def scenario(persist: bool) -> dict[str, Any]:
        clock = Clock()
        c = RaftElectionEngine(
            n=3,
            clock=clock,
            timeouts={"s1": 0.15, "s2": 0.50, "s3": 0.50},
            persist_votes={"s1": True, "s2": persist, "s3": True},
        )
        # s1 times out, becomes candidate in term 1, s2 and s3 grant.
        c.run_until(0.17)
        # Crash s2 after it has voted, then restart from durable state.
        c.crash("s2")
        c.restart("s2")
        after_restart = c.inspect()
        # Now s3 starts a competing candidacy in the SAME term by
        # forcing an election from a follower that has not voted? s3
        # already voted for s1 in term 1. Instead, have a new candidate
        # request a vote: we send a RequestVote from a fake restart of
        # s3 as candidate in term 1... but s3 already voted and is a
        # follower. Better: after restart, s3 (still in term 1, voted
        # for s1) cannot start term 1 again. We need s3 to *request*
        # s2's vote in term 1 without incrementing term.
        # Teaching injection: s3 (or a recovered candidate) re-sends
        # RequestVote for term 1 after s2 restarts.
        c.send(
            "s3",
            "s2",
            "RequestVote",
            {
                "term": 1,
                "candidate_id": "s3",
                "last_log_index": 0,
                "last_log_term": 0,
            },
        )
        c.run_until(0.20)
        after = c.inspect()
        denials = [e for e in c.events_of("vote_denied", "vote_granted") if e["server"] == "s2"]
        return {
            "persist_votes": persist,
            "after_restart": after_restart,
            "after_second_request": after,
            "s2_vote_events": denials,
            "s2_durable_voted_for": after["servers"]["s2"]["durable_voted_for"],
            "s2_memory_voted_for": after["servers"]["s2"]["voted_for"],
            "leaders_by_term": _leaders_by_term(c),
        }

    safe = scenario(True)
    buggy = scenario(False)
    return {
        "persisted": safe,
        "not_persisted": buggy,
        "persisted_rejects_second_vote": any(
            e.get("reason") == "already_voted" for e in safe["s2_vote_events"]
        ),
        "not_persisted_grants_second_vote": any(
            e.get("event") == "vote_granted" and e.get("candidate") == "s3"
            for e in buggy["s2_vote_events"]
        ),
    }


def run_split_vote_and_single_leader() -> dict[str, Any]:
    """Same-term split vote elects nobody; a later term elects at most one."""
    clock = Clock()
    # Identical timeouts so s2 and s3 start together after s1 is paused.
    # Give s1 a short timeout so it wins term 1 first.
    c = RaftElectionEngine(
        n=3,
        clock=clock,
        timeouts={"s1": 0.15, "s2": 0.22, "s3": 0.22},
    )
    c.run_until(0.30)
    c.pause("s1")
    # Last heartbeat ~0.27 sent, ~0.28 delivered; both s2 and s3 have
    # timeout 0.22, so both fire at ~0.50 and split term 2.
    c.run_until(0.54)
    mid = c.inspect()
    leaders_term2_at_mid = [
        L for L in mid["observed_leaders"] if L["term"] == 2
    ]
    # Now give s2 a head start on the next timeout by unpausing? They
    # already picked 0.22 again. To resolve the split, change s3's
    # remaining timeout so s2 wins term 3 alone. (Paper: randomized
    # retry at the start of each new election.)
    c.servers["s3"].election_timeout_s = 0.28
    c.servers["s3"].reset_election_timer(0.28)
    c.servers["s2"].reset_election_timer(0.15)
    # Current time ~0.54; s2 will fire at 0.69, s3 at 0.82.
    c.run_until(0.90)
    end = c.inspect()
    return {
        "after_split": mid,
        "leaders_in_term_2": leaders_term2_at_mid,
        "after_retry": end,
        "leaders_by_term": _leaders_by_term(c),
        "vote_log": _vote_events(c),
        "at_most_one_leader_per_term": all(
            len(v) <= 1 for v in _leaders_by_term(c).values()
        ),
    }


def run_log_freshness() -> dict[str, Any]:
    """A stale-log candidate is refused; the up-to-date node wins."""
    clock = Clock()
    c = RaftElectionEngine(
        n=3,
        clock=clock,
        timeouts={"s1": 0.15, "s2": 0.40, "s3": 0.28},
    )
    c.run_until(0.20)
    # Isolate s3 so it misses the committed title update.
    c.isolate("s3")
    leader = c.servers["s1"]
    leader.append_and_replicate(
        {"op": "SET", "key": KEY_TITLE, "value": TITLE_V2}
    )
    c.run_until(0.30)
    after_write = c.inspect()
    # Pause the leader first so it cannot catch s3 up, then heal s3 so
    # its RequestVote can reach s2. The isolation was only to skip the write.
    c.pause("s1")
    c.heal("s3")
    # s3 (stale, timeout 0.28) should time out first and be denied by
    # s2, whose log has the committed entry. Then s2 (timeout 0.40) wins.
    c.run_until(1.10)
    after = c.inspect()
    denials = [
        e
        for e in c.events_of("vote_denied")
        if e.get("reason") == "log_not_up_to_date"
    ]
    return {
        "after_write": after_write,
        "after_election": after,
        "log_not_up_to_date_denials": denials,
        "leaders_by_term": _leaders_by_term(c),
        "s2_title": after["servers"]["s2"]["title"],
        "s3_title": after["servers"]["s3"]["title"],
        "s2_last_log": {
            "index": after["servers"]["s2"]["last_log_index"],
            "term": after["servers"]["s2"]["last_log_term"],
        },
        "s3_last_log": {
            "index": after["servers"]["s3"]["last_log_index"],
            "term": after["servers"]["s3"]["last_log_term"],
        },
        "vote_log": _vote_events(c),
    }


def run_two_node() -> dict[str, Any]:
    """A two-node cluster cannot elect a new leader after one fails."""
    clock = Clock()
    c = RaftElectionEngine(
        n=2,
        clock=clock,
        timeouts={"s1": 0.15, "s2": 0.22},
    )
    c.run_until(0.30)
    after_first = c.inspect()
    c.pause("s1")
    # Several election timeouts on the surviving node: 0.22, then again
    # and again. Majority of 2 is 2, so one vote is never enough.
    c.run_until(1.20)
    after = c.inspect()
    candidates = [e for e in c.events if e["event"] == "become_candidate" and e["t"] >= 0.30]
    leaders_after_pause = [
        e for e in c.events_of("become_leader") if e["t"] >= 0.30
    ]
    return {
        "n": 2,
        "majority": c.majority,
        "after_first_election": after_first,
        "after_leader_paused": after,
        "candidate_rounds_after_pause": candidates,
        "new_leaders_after_pause": leaders_after_pause,
        "live_leader_after_pause": after["leaders"],
        "cannot_tolerate_single_failure": len(leaders_after_pause) == 0
        and after["leaders"] == [],
        "vote_log": _vote_events(c),
    }


def run_dual_leader_observation() -> dict[str, Any]:
    """Heartbeats do not prevent observing two leaders across a partition."""
    clock = Clock()
    c = RaftElectionEngine(
        n=3,
        clock=clock,
        timeouts={"s1": 0.15, "s2": 0.22, "s3": 0.28},
    )
    c.run_until(0.30)
    before = c.inspect()
    # Partition the leader away. It keeps sending heartbeats that drop.
    c.isolate("s1")
    # It remains a leader in term 1; s2/s3 elect a new one.
    c.run_until(0.70)
    during = c.inspect()
    c.heal("s1")
    c.run_until(0.90)
    after = c.inspect()
    return {
        "before_partition": before,
        "during_partition": during,
        "observed_leaders_during": during["observed_leaders"],
        "two_leaders_observed": len(during["observed_leaders"]) >= 2,
        "terms_during": sorted({L["term"] for L in during["observed_leaders"]}),
        "after_heal": after,
        "leaders_after_heal": after["leaders"],
        "s1_state_after_heal": after["servers"]["s1"]["state"],
        "s1_term_after_heal": after["servers"]["s1"]["current_term"],
        "vote_log": _vote_events(c),
        "dropped_heartbeats": [
            e for e in c.events if e["event"] == "message_dropped" and e.get("typ") == "AppendEntries"
        ],
        "leaders_by_term": _leaders_by_term(c),
    }


def run_timeout_tradeoff() -> dict[str, Any]:
    """A short timeout detects a pause faster, but can elect while the leader is alive."""

    def failover(timeout_s: float, pause_at: float = 0.30, until: float = 1.20) -> dict[str, Any]:
        clock = Clock()
        c = RaftElectionEngine(
            n=3,
            clock=clock,
            timeouts={"s1": 0.15, "s2": timeout_s, "s3": timeout_s + 0.08},
            rpc_delay_s=RPC_DELAY_S,
            heartbeat_interval_s=HEARTBEAT_INTERVAL_S,
        )
        c.run_until(pause_at)
        c.pause("s1")
        paused_at = ts(clock.now())
        c.run_until(until)
        new_leaders = [e for e in c.events_of("become_leader") if e["t"] >= paused_at]
        new_t = new_leaders[0]["t"] if new_leaders else None
        return {
            "follower_timeout_s": timeout_s,
            "paused_at": paused_at,
            "new_leader": new_leaders[0] if new_leaders else None,
            "new_leader_at": new_t,
            "detection_s": ts(new_t - paused_at) if new_t is not None else None,
            "leaders_by_term": _leaders_by_term(c),
        }

    def spurious(timeout_s: float, delay_s: float, heartbeat_s: float) -> dict[str, Any]:
        clock = Clock()
        c = RaftElectionEngine(
            n=3,
            clock=clock,
            timeouts={"s1": 0.15, "s2": timeout_s, "s3": timeout_s + 0.08},
            rpc_delay_s=delay_s,
            heartbeat_interval_s=heartbeat_s,
        )
        # Leader stays up. If timeout < heartbeat + delay, a follower
        # may start an election while s1 is still leader.
        c.run_until(0.80)
        extra_terms = [
            e for e in c.events_of("become_candidate") if e["t"] > 0.20 and e["server"] != "s1"
        ]
        return {
            "follower_timeout_s": timeout_s,
            "rpc_delay_s": delay_s,
            "heartbeat_interval_s": heartbeat_s,
            "spurious_candidates": extra_terms,
            "spurious_election": len(extra_terms) > 0,
            "leaders_by_term": _leaders_by_term(c),
            "final": c.inspect(),
        }

    short = failover(0.15)
    long = failover(0.30)
    # heartbeat 0.10 + delay 0.08 = 0.18, timeout 0.12 will fire first
    spurious_short = spurious(0.12, delay_s=0.08, heartbeat_s=0.10)
    # timeout 0.30 > 0.18, heartbeats arrive in time
    stable_long = spurious(0.30, delay_s=0.08, heartbeat_s=0.10)
    return {
        "short_timeout_failover": short,
        "long_timeout_failover": long,
        "faster_detection": short["detection_s"] is not None
        and long["detection_s"] is not None
        and short["detection_s"] < long["detection_s"],
        "spurious_with_short_timeout": spurious_short,
        "stable_with_long_timeout": stable_long,
    }


def run() -> dict[str, Any]:
    pause = run_pause_leader()
    persistent = run_persistent_vote()
    split = run_split_vote_and_single_leader()
    freshness = run_log_freshness()
    two = run_two_node()
    dual = run_dual_leader_observation()
    tradeoff = run_timeout_tradeoff()

    acceptance_one_leader = (
        split["at_most_one_leader_per_term"]
        and all(len(v) <= 1 for v in pause["leaders_by_term"].values())
        and all(len(v) <= 1 for v in freshness["leaders_by_term"].values())
        and all(len(v) <= 1 for v in dual["leaders_by_term"].values())
    )
    return {
        "engine": "RaftElectionEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_full_raft": True,
        "not_paxos": True,
        "not_jepsen": True,
        "key_title": KEY_TITLE,
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "local_step_s": LOCAL_STEP_S,
        "rpc_delay_s": RPC_DELAY_S,
        "heartbeat_interval_s": HEARTBEAT_INTERVAL_S,
        "election_timeout_min_s": ELECTION_TIMEOUT_MIN_S,
        "election_timeout_max_s": ELECTION_TIMEOUT_MAX_S,
        "majority_of_three": 2,
        "majority_of_two": 2,
        "pause_leader": pause,
        "persistent_vote": persistent,
        "split_vote": split,
        "log_freshness": freshness,
        "two_node": two,
        "dual_leader_observation": dual,
        "timeout_tradeoff": tradeoff,
        "acceptance_at_most_one_majority_leader_per_term": acceptance_one_leader,
        "acceptance_two_node_cannot_tolerate_single_failure": two["cannot_tolerate_single_failure"],
        "pitfall_heartbeat_does_not_prevent_dual_leader_observation": dual["two_leaders_observed"],
        "tradeoff_short_timeout_faster_but_easier_to_mis_elect": tradeoff["faster_detection"]
        and tradeoff["spurious_with_short_timeout"]["spurious_election"]
        and (not tradeoff["stable_with_long_timeout"]["spurious_election"]),
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    data = run()
    path = Path(__file__).resolve().parent / "results.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {path}")
