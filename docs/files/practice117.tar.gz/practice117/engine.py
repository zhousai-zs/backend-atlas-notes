#!/usr/bin/env python3
"""Teaching RaftElectionEngine — not Redis, not a network service, not a full Raft.

A Python 3 standard-library model of Raft leader election: terms,
persistent votes, majority, the log up-to-date check, heartbeats, and
randomized election timeouts. Servers talk over an in-process mailbox
driven by a virtual clock.

This is not Redis, not redis-py, and not a network server. There is no
TCP and no real message loss. It is not a complete Raft, Paxos, or
Jepsen implementation: there is no snapshot transfer, no membership
change, and log replication exists only so RequestVote can apply the
election restriction in §5.4.1. pause() is an omniscient freeze; a
real network has no such signal. Persistent state is a teaching dict
flushed before RPC replies, not a disk or fsync. Definitions of terms,
votes, Election Safety, and the log comparison follow Ongaro &
Ousterhout, "In Search of an Understandable Consensus Algorithm
(Extended Version)", checked on 2026-11-13.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from random import Random
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
TITLE_V3 = "Weekly digest (hotfix)"
KEY_TITLE = "article:01:title"
LOCAL_STEP_S = 0.01
RPC_DELAY_S = 0.01
HEARTBEAT_INTERVAL_S = 0.05
ELECTION_TIMEOUT_MIN_S = 0.15
ELECTION_TIMEOUT_MAX_S = 0.30


def ts(t: float) -> float:
    """Round a virtual-clock time to two decimals for stable records."""
    return round(float(t) + 1e-12, 2)


class Clock:
    """A virtual clock tests can freeze and advance. Not a wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class LogEntry:
    index: int
    term: int
    command: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {"index": self.index, "term": self.term, "command": dict(self.command)}


@dataclass
class Persist:
    """Persistent state. Must be copied before an RPC reply is sent."""

    current_term: int = 0
    voted_for: Optional[str] = None
    log: list[LogEntry] = field(default_factory=list)

    def clone(self) -> "Persist":
        return Persist(
            current_term=self.current_term,
            voted_for=self.voted_for,
            log=[LogEntry(e.index, e.term, dict(e.command)) for e in self.log],
        )


@dataclass
class Message:
    src: str
    dst: str
    typ: str
    body: dict[str, Any]
    send_at: float
    deliver_at: float
    dropped: bool = False


class Server:
    """One Raft server in the teaching cluster."""

    def __init__(
        self,
        server_id: str,
        cluster: "RaftElectionEngine",
        election_timeout_s: float,
        persist_votes: bool = True,
    ) -> None:
        self.server_id = server_id
        self.cluster = cluster
        self.election_timeout_s = float(election_timeout_s)
        self.persist_votes = persist_votes
        self.persist = Persist()
        self.durable: Optional[Persist] = None
        self.flush_persist()
        self.state = "follower"
        self.commit_index = 0
        self.last_applied = 0
        self.votes_got: set[str] = set()
        self.leader_id: Optional[str] = None
        self.election_deadline = 0.0
        self.heartbeat_deadline = 0.0
        self.paused = False
        self.crashed = False
        self.kv: dict[str, str] = {}
        self.reset_election_timer()

    def flush_persist(self) -> None:
        self.durable = self.persist.clone()

    def load_persist(self) -> None:
        assert self.durable is not None
        self.persist = self.durable.clone()

    def last_log_index(self) -> int:
        return self.persist.log[-1].index if self.persist.log else 0

    def last_log_term(self) -> int:
        return self.persist.log[-1].term if self.persist.log else 0

    def log_is_up_to_date(self, cand_last_term: int, cand_last_index: int) -> bool:
        """True if the candidate's log is at least as up-to-date as ours (§5.4.1)."""
        my_term = self.last_log_term()
        my_index = self.last_log_index()
        if cand_last_term != my_term:
            return cand_last_term > my_term
        return cand_last_index >= my_index

    def reset_election_timer(self, timeout_s: Optional[float] = None) -> None:
        duration = self.election_timeout_s if timeout_s is None else float(timeout_s)
        self.election_deadline = ts(self.cluster.clock.now() + duration)

    def snapshot(self) -> dict[str, Any]:
        return {
            "id": self.server_id,
            "state": self.state,
            "current_term": self.persist.current_term,
            "voted_for": self.persist.voted_for,
            "durable_term": self.durable.current_term if self.durable else None,
            "durable_voted_for": self.durable.voted_for if self.durable else None,
            "log": [e.as_dict() for e in self.persist.log],
            "last_log_index": self.last_log_index(),
            "last_log_term": self.last_log_term(),
            "commit_index": self.commit_index,
            "leader_id": self.leader_id,
            "paused": self.paused,
            "crashed": self.crashed,
            "title": self.kv.get(KEY_TITLE),
        }

    def maybe_step_down(self, term: int) -> None:
        if term > self.persist.current_term:
            self.persist.current_term = term
            self.persist.voted_for = None
            self.flush_persist()
            # A higher term in a RequestVote we later deny must not
            # reset the election timer; only an AppendEntries from the
            # current leader or a granted vote does (Figure 2).
            self.become_follower(leader_id=None, reset_timer=False)

    def become_follower(self, leader_id: Optional[str], *, reset_timer: bool = True) -> None:
        was = self.state
        was_leader = self.leader_id
        self.state = "follower"
        self.leader_id = leader_id
        self.votes_got.clear()
        if reset_timer:
            self.reset_election_timer()
        if was != "follower" or was_leader != leader_id:
            self.cluster.log_event(
                self.server_id,
                "become_follower",
                term=self.persist.current_term,
                leader_id=leader_id,
                previous_state=was,
            )

    def start_election(self) -> None:
        self.persist.current_term += 1
        self.state = "candidate"
        self.persist.voted_for = self.server_id
        self.leader_id = None
        self.votes_got = {self.server_id}
        self.flush_persist()
        self.reset_election_timer()
        self.cluster.log_event(
            self.server_id,
            "become_candidate",
            term=self.persist.current_term,
            voted_for=self.server_id,
            last_log_index=self.last_log_index(),
            last_log_term=self.last_log_term(),
        )
        for other in self.cluster.peer_ids(self.server_id):
            self.cluster.send(
                self.server_id,
                other,
                "RequestVote",
                {
                    "term": self.persist.current_term,
                    "candidate_id": self.server_id,
                    "last_log_index": self.last_log_index(),
                    "last_log_term": self.last_log_term(),
                },
            )

    def become_leader(self) -> None:
        self.state = "leader"
        self.leader_id = self.server_id
        self.cluster.log_event(
            self.server_id,
            "become_leader",
            term=self.persist.current_term,
            votes=sorted(self.votes_got),
            vote_count=len(self.votes_got),
            majority=self.cluster.majority,
        )
        self.broadcast_heartbeats()
        self.heartbeat_deadline = ts(
            self.cluster.clock.now() + self.cluster.heartbeat_interval_s
        )

    def broadcast_heartbeats(self) -> None:
        for other in self.cluster.peer_ids(self.server_id):
            self.send_append_entries(other, heartbeat=True)

    def send_append_entries(self, dst: str, heartbeat: bool = False) -> None:
        entries: list[dict[str, Any]] = []
        # Teaching shortcut: send any entries the leader has that are
        # beyond a conservative prev (full nextIndex tracking is the
        # next lesson). For experiments in this lesson the follower is
        # either caught up or completely missing the suffix.
        if not heartbeat:
            # send the whole suffix; prev is the entry before the first
            # uncopied one. We still include prev of the last entry when
            # used as a replication call from append_client.
            pass
        prev_index = self.last_log_index()
        prev_term = self.last_log_term()
        # For a real AE that carries entries, the caller sets them.
        self.cluster.send(
            self.server_id,
            dst,
            "AppendEntries",
            {
                "term": self.persist.current_term,
                "leader_id": self.server_id,
                "prev_log_index": prev_index,
                "prev_log_term": prev_term,
                "entries": entries,
                "leader_commit": self.commit_index,
            },
        )

    def append_and_replicate(self, command: dict[str, Any]) -> dict[str, Any]:
        """Leader appends a command and sends it to every peer."""
        if self.state != "leader":
            return {"status": "not_leader", "leader_id": self.leader_id}
        entry = LogEntry(self.last_log_index() + 1, self.persist.current_term, dict(command))
        self.persist.log.append(entry)
        self.flush_persist()
        self.cluster.log_event(
            self.server_id,
            "append_local",
            term=self.persist.current_term,
            index=entry.index,
            command=dict(command),
        )
        for other in self.cluster.peer_ids(self.server_id):
            prev = self.persist.log[-2] if len(self.persist.log) >= 2 else None
            self.cluster.send(
                self.server_id,
                other,
                "AppendEntries",
                {
                    "term": self.persist.current_term,
                    "leader_id": self.server_id,
                    "prev_log_index": prev.index if prev else 0,
                    "prev_log_term": prev.term if prev else 0,
                    "entries": [entry.as_dict()],
                    "leader_commit": self.commit_index,
                },
            )
        self.try_commit()
        return {"status": "appended", "index": entry.index, "term": entry.term}

    def try_commit(self) -> None:
        # An entry from the current term is committed once it is on a majority.
        for entry in reversed(self.persist.log):
            if entry.term != self.persist.current_term:
                break
            if entry.index <= self.commit_index:
                break
            holders = 1  # self
            for other in self.cluster.servers.values():
                if other.server_id == self.server_id:
                    continue
                if any(e.index == entry.index and e.term == entry.term for e in other.persist.log):
                    holders += 1
            if holders >= self.cluster.majority:
                self.commit_index = entry.index
                self.apply_committed()
                self.cluster.log_event(
                    self.server_id,
                    "commit",
                    term=self.persist.current_term,
                    commit_index=self.commit_index,
                    holders=holders,
                )
                # notify followers of the new commit via heartbeat
                self.broadcast_heartbeats()
                break

    def apply_committed(self) -> None:
        while self.last_applied < self.commit_index:
            self.last_applied += 1
            entry = next(e for e in self.persist.log if e.index == self.last_applied)
            cmd = entry.command
            if cmd.get("op") == "SET":
                self.kv[str(cmd["key"])] = str(cmd["value"])

    def on_request_vote(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        candidate = str(body["candidate_id"])
        last_idx = int(body["last_log_index"])
        last_term = int(body["last_log_term"])
        self.maybe_step_down(term)
        granted = False
        reason = ""
        if term < self.persist.current_term:
            reason = "stale_term"
        elif self.persist.voted_for not in (None, candidate):
            reason = "already_voted"
        elif not self.log_is_up_to_date(last_term, last_idx):
            reason = "log_not_up_to_date"
        else:
            granted = True
            reason = "granted"
            self.persist.voted_for = candidate
            if self.persist_votes:
                self.flush_persist()
            # granting a vote resets the election timer (Figure 2)
            self.reset_election_timer()
        if self.persist_votes:
            self.flush_persist()
        else:
            # Buggy teaching mode: currentTerm is persisted, votedFor is not.
            term_only = Persist(
                current_term=self.persist.current_term,
                voted_for=self.durable.voted_for if self.durable else None,
                log=[LogEntry(e.index, e.term, dict(e.command)) for e in self.persist.log],
            )
            self.durable = term_only
        self.cluster.log_event(
            self.server_id,
            "vote_granted" if granted else "vote_denied",
            term=self.persist.current_term,
            voted_for=self.persist.voted_for,
            candidate=candidate,
            granted=granted,
            reason=reason,
            durable_voted_for=self.durable.voted_for if self.durable else None,
        )
        self.cluster.send(
            self.server_id,
            src,
            "RequestVoteReply",
            {
                "term": self.persist.current_term,
                "vote_granted": granted,
                "voter": self.server_id,
                "reason": reason,
            },
        )

    def on_request_vote_reply(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        self.maybe_step_down(term)
        if self.state != "candidate":
            return
        if term != self.persist.current_term:
            return
        if body.get("vote_granted"):
            self.votes_got.add(src)
            self.cluster.log_event(
                self.server_id,
                "vote_received",
                term=self.persist.current_term,
                from_id=src,
                votes=sorted(self.votes_got),
                vote_count=len(self.votes_got),
            )
            if len(self.votes_got) >= self.cluster.majority:
                self.become_leader()

    def on_append_entries(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        if term < self.persist.current_term:
            self.cluster.send(
                self.server_id,
                src,
                "AppendEntriesReply",
                {
                    "term": self.persist.current_term,
                    "success": False,
                    "reason": "stale_term",
                    "match_index": self.last_log_index(),
                },
            )
            return
        self.maybe_step_down(term)
        # Legitimate leader for this term (or higher, already stepped down).
        self.become_follower(leader_id=str(body["leader_id"]))
        self.reset_election_timer()
        prev_index = int(body["prev_log_index"])
        prev_term = int(body["prev_log_term"])
        success = True
        reason = "ok"
        if prev_index == 0:
            pass
        else:
            match = next((e for e in self.persist.log if e.index == prev_index), None)
            if match is None or match.term != prev_term:
                success = False
                reason = "log_inconsistency"
        if success:
            for raw in body.get("entries") or []:
                idx = int(raw["index"])
                term_e = int(raw["term"])
                existing = next((e for e in self.persist.log if e.index == idx), None)
                if existing is not None:
                    if existing.term != term_e:
                        self.persist.log = [e for e in self.persist.log if e.index < idx]
                        existing = None
                    else:
                        continue
                if existing is None:
                    self.persist.log.append(
                        LogEntry(idx, term_e, dict(raw["command"]))
                    )
            self.flush_persist()
            leader_commit = int(body["leader_commit"])
            if leader_commit > self.commit_index:
                last = self.last_log_index()
                self.commit_index = min(leader_commit, last)
                self.apply_committed()
        self.cluster.send(
            self.server_id,
            src,
            "AppendEntriesReply",
            {
                "term": self.persist.current_term,
                "success": success,
                "reason": reason,
                "match_index": self.last_log_index(),
            },
        )

    def on_append_entries_reply(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        self.maybe_step_down(term)
        if self.state != "leader":
            return
        if body.get("success"):
            self.try_commit()

    def on_election_timeout(self) -> None:
        if self.state == "leader":
            return
        self.cluster.log_event(
            self.server_id,
            "election_timeout",
            term=self.persist.current_term,
            state=self.state,
        )
        self.start_election()

    def on_heartbeat_due(self) -> None:
        if self.state != "leader":
            return
        self.broadcast_heartbeats()
        self.heartbeat_deadline = ts(
            self.cluster.clock.now() + self.cluster.heartbeat_interval_s
        )


class RaftElectionEngine:
    """A teaching cluster with an in-process mailbox and a virtual clock."""

    def __init__(
        self,
        n: int = 3,
        clock: Optional[Clock] = None,
        timeouts: Optional[dict[str, float]] = None,
        rpc_delay_s: float = RPC_DELAY_S,
        heartbeat_interval_s: float = HEARTBEAT_INTERVAL_S,
        election_timeout_min_s: float = ELECTION_TIMEOUT_MIN_S,
        election_timeout_max_s: float = ELECTION_TIMEOUT_MAX_S,
        rng: Optional[Random] = None,
        persist_votes: Optional[dict[str, bool]] = None,
    ) -> None:
        self.clock = clock or Clock()
        self.rpc_delay_s = float(rpc_delay_s)
        self.heartbeat_interval_s = float(heartbeat_interval_s)
        self.election_timeout_min_s = float(election_timeout_min_s)
        self.election_timeout_max_s = float(election_timeout_max_s)
        self.rng = rng or Random(0)
        self.n = int(n)
        self.majority = self.n // 2 + 1
        self.servers: dict[str, Server] = {}
        self.messages: list[Message] = []
        self.events: list[dict[str, Any]] = []
        self.partitions: set[frozenset[str]] = set()
        ids = [f"s{i}" for i in range(1, self.n + 1)]
        for sid in ids:
            if timeouts and sid in timeouts:
                to = float(timeouts[sid])
            else:
                to = self._random_timeout()
            persist = True
            if persist_votes is not None:
                persist = persist_votes.get(sid, True)
            self.servers[sid] = Server(sid, self, to, persist_votes=persist)
        # Record initial deadlines after all servers exist.
        for sid, srv in self.servers.items():
            self.log_event(
                sid,
                "init",
                term=0,
                state="follower",
                election_deadline=ts(srv.election_deadline),
                election_timeout_s=srv.election_timeout_s,
            )

    def _random_timeout(self) -> float:
        lo = self.election_timeout_min_s
        hi = self.election_timeout_max_s
        return ts(lo + (hi - lo) * self.rng.random())

    def peer_ids(self, server_id: str) -> list[str]:
        return [s for s in self.servers if s != server_id]

    def log_event(self, server_id: str, event: str, **kwargs: Any) -> None:
        rec: dict[str, Any] = {
            "t": ts(self.clock.now()),
            "server": server_id,
            "event": event,
        }
        rec.update(kwargs)
        self.events.append(rec)

    def partitioned(self, a: str, b: str) -> bool:
        return frozenset({a, b}) in self.partitions

    def isolate(self, server_id: str) -> None:
        for other in self.peer_ids(server_id):
            self.partitions.add(frozenset({server_id, other}))
        self.log_event(server_id, "isolated")

    def heal(self, server_id: Optional[str] = None) -> None:
        if server_id is None:
            self.partitions.clear()
            self.log_event("cluster", "healed_all")
        else:
            self.partitions = {p for p in self.partitions if server_id not in p}
            self.log_event(server_id, "healed")

    def pause(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.paused = True
        self.log_event(server_id, "paused", term=srv.persist.current_term, state=srv.state)

    def unpause(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.paused = False
        now = ts(self.clock.now())
        for m in self.messages:
            if m.dst == server_id and not m.dropped:
                m.deliver_at = ts(max(m.deliver_at, now))
        self.log_event(server_id, "unpaused", term=srv.persist.current_term, state=srv.state)

    def crash(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.crashed = True
        srv.paused = True
        # Volatile state is gone; durable state remains.
        self.log_event(
            server_id,
            "crashed",
            term=srv.persist.current_term,
            durable_term=srv.durable.current_term if srv.durable else None,
            durable_voted_for=srv.durable.voted_for if srv.durable else None,
        )

    def restart(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.load_persist()
        srv.state = "follower"
        srv.commit_index = 0
        srv.last_applied = 0
        srv.votes_got.clear()
        srv.leader_id = None
        srv.kv = {}
        srv.crashed = False
        srv.paused = False
        srv.reset_election_timer()
        self.log_event(
            server_id,
            "restarted",
            term=srv.persist.current_term,
            voted_for=srv.persist.voted_for,
            durable_voted_for=srv.durable.voted_for if srv.durable else None,
            last_log_index=srv.last_log_index(),
        )

    def send(self, src: str, dst: str, typ: str, body: dict[str, Any]) -> None:
        now = self.clock.now()
        msg = Message(
            src=src,
            dst=dst,
            typ=typ,
            body=dict(body),
            send_at=ts(now),
            deliver_at=ts(now + self.rpc_delay_s),
        )
        if self.partitioned(src, dst):
            msg.dropped = True
            self.log_event(src, "message_dropped", typ=typ, dst=dst, term=body.get("term"))
        self.messages.append(msg)

    def leaders(self) -> list[str]:
        return [
            s.server_id
            for s in self.servers.values()
            if s.state == "leader" and not s.paused and not s.crashed
        ]

    def observed_leaders(self) -> list[dict[str, Any]]:
        """Leaders as an observer would see them, including a paused old leader."""
        out = []
        for s in self.servers.values():
            if s.state == "leader" and not s.crashed:
                out.append(
                    {
                        "id": s.server_id,
                        "term": s.persist.current_term,
                        "paused": s.paused,
                        "title": s.kv.get(KEY_TITLE),
                    }
                )
        return out

    def inspect(self) -> dict[str, Any]:
        return {
            "t": ts(self.clock.now()),
            "majority": self.majority,
            "n": self.n,
            "leaders": self.leaders(),
            "observed_leaders": self.observed_leaders(),
            "servers": {sid: s.snapshot() for sid, s in self.servers.items()},
        }

    def _next_event_time(self) -> Optional[float]:
        times: list[float] = []
        for m in self.messages:
            if m.dropped:
                continue
            dst = self.servers[m.dst]
            if dst.paused or dst.crashed:
                continue
            if m.deliver_at >= self.clock.now() - 1e-12:
                times.append(m.deliver_at)
        for s in self.servers.values():
            if s.paused or s.crashed:
                continue
            if s.state != "leader":
                times.append(s.election_deadline)
            if s.state == "leader":
                times.append(s.heartbeat_deadline)
        pending = [t for t in times if t > self.clock.now() + 1e-12]
        return min(pending) if pending else None

    def _deliver_due(self) -> None:
        now = self.clock.now()
        due = [
            m
            for m in self.messages
            if (not m.dropped) and m.deliver_at <= now + 1e-12
        ]
        # Deliver in a stable order: time, typ, src, dst
        due.sort(key=lambda m: (m.deliver_at, m.typ, m.src, m.dst))
        # Remove them first so replies are new messages
        for m in due:
            m.dropped = True  # consumed
        for m in due:
            dst = self.servers[m.dst]
            if dst.paused or dst.crashed:
                # Held while frozen; re-queue to the same deliver time? For
                # pause (SIGSTOP) hold the message. For crash, drop it.
                if dst.crashed:
                    continue
                m.dropped = False
                # Hold: deliver as soon as we can after unpause, next step.
                m.deliver_at = ts(max(m.deliver_at, now))
                continue
            if self.partitioned(m.src, m.dst):
                continue
            self._dispatch(m)

    def _dispatch(self, m: Message) -> None:
        srv = self.servers[m.dst]
        if m.typ == "RequestVote":
            srv.on_request_vote(m.src, m.body)
        elif m.typ == "RequestVoteReply":
            srv.on_request_vote_reply(m.src, m.body)
        elif m.typ == "AppendEntries":
            srv.on_append_entries(m.src, m.body)
        elif m.typ == "AppendEntriesReply":
            srv.on_append_entries_reply(m.src, m.body)
        else:
            raise ValueError(f"unknown typ {m.typ}")

    def _fire_timeouts(self) -> None:
        now = self.clock.now()
        # Stable order by id
        for sid in sorted(self.servers):
            s = self.servers[sid]
            if s.paused or s.crashed:
                continue
            if s.state != "leader" and s.election_deadline <= now + 1e-12:
                s.on_election_timeout()
            if s.state == "leader" and s.heartbeat_deadline <= now + 1e-12:
                s.on_heartbeat_due()

    def run_until(self, t_end: float) -> None:
        """Advance the virtual clock, delivering messages and firing timeouts."""
        t_end = float(t_end)
        while True:
            self._deliver_due()
            self._fire_timeouts()
            nxt = self._next_event_time()
            if nxt is None or nxt > t_end + 1e-12:
                self.clock.wait_until(t_end)
                self._deliver_due()
                self._fire_timeouts()
                return
            self.clock.wait_until(nxt)

    def run_for(self, seconds: float) -> None:
        self.run_until(ts(self.clock.now() + float(seconds)))

    def events_of(self, *kinds: str) -> list[dict[str, Any]]:
        return [e for e in self.events if e["event"] in kinds]
