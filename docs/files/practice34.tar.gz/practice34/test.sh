#!/bin/bash
# 第34课实践自测：线程栈预留 vs 驻留、TLS、join 回收、detach 寿命
set -u; cd "$(dirname "$0")"; fail=0
gcc -O2 -pthread threads.c -o threads || exit 1
gcc -g -O0 -fsanitize=address -pthread detach_bad.c -o detach_bad || exit 1
gcc -g -O0 -fsanitize=address -pthread detach_ok.c -o detach_ok || exit 1
kb(){ echo "$1" | grep "\[$2\]" | sed -E "s/.*$3:[[:space:]]*([0-9]+) kB.*/\1/"; }
a=$(./threads 100 8192 0); echo "$a"
b=$(./threads 100 8192 1024); echo "$b"
vs=$(kb "$a" running VmSize); rss=$(kb "$a" running VmRSS); rss2=$(kb "$b" running VmRSS)
[ "$vs" -gt 800000 ] && [ "$rss" -lt 20000 ] && echo "OK 栈预留(VmSize ${vs}kB) 远大于驻留(RSS ${rss}kB)" || { echo FAIL1; fail=1; }
[ "$rss2" -gt 100000 ] && echo "OK 每线程触碰1MB后 RSS=${rss2}kB" || { echo FAIL2; fail=1; }
echo "$a" | grep -q "tls_ok=100/100 shared=100000 expected=100000" && echo "OK TLS 各自计数、共享计数加锁正确" || { echo FAIL3; fail=1; }
echo "$a" | grep "\[joined\]" | grep -q "Threads:	1" && echo "OK join 后只剩主线程" || { echo FAIL4; fail=1; }
ASAN_OPTIONS=detect_stack_use_after_return=1 ./detach_bad 2>&1 | grep -q stack-use-after-return && echo "OK detach 反例被 ASan 检出 stack-use-after-return" || { echo FAIL5; fail=1; }
ASAN_OPTIONS=detect_stack_use_after_return=1 ./detach_ok | grep -q user=alice && echo "OK 堆对象交给线程拥有后正常" || { echo FAIL6; fail=1; }
[ $fail = 0 ] && echo ALL_CHECKS_PASSED
