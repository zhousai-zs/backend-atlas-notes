#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
struct req { char user[32]; };
static void *log_later(void *arg) {
    usleep(100 * 1000);                       // 模拟异步写日志
    struct req *r = arg;
    printf("user=%s\n", r->user);             // r 指向已经失效的栈对象
    return NULL;
}
static void handle(void) {
    struct req r; strcpy(r.user, "alice");
    pthread_t t; pthread_create(&t, NULL, log_later, &r);
    pthread_detach(t);                        // detach 了，但 r 的寿命没变
}                                             // r 在这里就没了
int main(void) { handle(); usleep(300 * 1000); return 0; }
