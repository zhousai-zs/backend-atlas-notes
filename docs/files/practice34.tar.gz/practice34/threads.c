// 用法: ./threads <线程数> <每线程栈KB> <touchKB>
#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/resource.h>

static __thread int tls_counter;          // 每线程一份
static int shared_counter;                // 全进程一份
static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t ready, go;
static size_t touch_kb;

static void print_status(const char *tag) {
    FILE *f = fopen("/proc/self/status", "r"); char line[256];
    printf("[%s]", tag);
    while (fgets(line, sizeof line, f))
        if (!strncmp(line,"VmSize",6)||!strncmp(line,"VmRSS",5)||!strncmp(line,"Threads",7)) {
            line[strcspn(line,"\n")]=0; printf(" %s", line); }
    fclose(f); printf("\n");
}

static void *worker(void *arg) {
    (void)arg;
    volatile char buf[touch_kb ? touch_kb * 1024 : 1];
    for (size_t i = 0; i < sizeof buf; i += 4096) buf[i] = 1;   // 真正触碰栈页
    for (int i = 0; i < 1000; i++) {
        tls_counter++;
        pthread_mutex_lock(&mu); shared_counter++; pthread_mutex_unlock(&mu);
        if (i % 100 == 0) sched_yield();
    }
    pthread_barrier_wait(&ready);   // 等主线程测量
    pthread_barrier_wait(&go);
    return (void *)(long)tls_counter;
}

int main(int argc, char **argv) {
    int n = argc > 1 ? atoi(argv[1]) : 100;
    size_t stack_kb = argc > 2 ? atol(argv[2]) : 8192;
    touch_kb = argc > 3 ? atol(argv[3]) : 0;
    pthread_t *t = calloc(n, sizeof *t);
    pthread_attr_t attr; pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, stack_kb * 1024);
    pthread_barrier_init(&ready, NULL, n + 1); pthread_barrier_init(&go, NULL, n + 1);
    print_status("before");
    for (long i = 0; i < n; i++) {
        int rc = pthread_create(&t[i], &attr, worker, (void *)i);
        if (rc) { fprintf(stderr, "pthread_create #%ld: %s\n", i, strerror(rc)); return 1; }
    }
    pthread_barrier_wait(&ready);
    print_status("running");
    pthread_barrier_wait(&go);
    long ok = 0;
    for (int i = 0; i < n; i++) { void *r; pthread_join(t[i], &r); if ((long)r == 1000) ok++; }
    struct rusage ru; getrusage(RUSAGE_SELF, &ru);
    print_status("joined");
    printf("tls_ok=%ld/%d shared=%d expected=%d vol_cs=%ld invol_cs=%ld\n",
           ok, n, shared_counter, n * 1000, ru.ru_nvcsw, ru.ru_nivcsw);
    pthread_attr_destroy(&attr); free(t); return 0;
}
