#!/usr/bin/env python3
"""Run the lesson 132 teaching flame-graph experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import (
    FREQ,
    KEY_TITLE,
    N_REQUESTS,
    PROCESS,
    TITLE_V1,
    FlameEngine,
)


def _public_profile(prof: dict[str, Any]) -> dict[str, Any]:
    """Drop the raw folded dict's redundancy; keep lines plus layout summary."""
    layout = prof["layout"]
    out = {
        "mode": prof["mode"],
        "kind": prof["kind"],
        "sampling_event": prof["sampling_event"],
        "key": prof["key"],
        "title": prof["title"],
        "n_requests_offered": prof["n_requests_offered"],
        "n_requests_completed": prof["n_requests_completed"],
        "n_requests_incomplete": prof["n_requests_incomplete"],
        "freq": prof["freq"],
        "unwind": prof["unwind"],
        "symbols_complete": prof["symbols_complete"],
        "wall_s": prof["wall_s"],
        "window_s": prof["window_s"],
        "times_are_teaching_virtual_clock": prof["times_are_teaching_virtual_clock"],
        "summary": {
            "total": prof["summary"]["total"],
            "syscall_exclusive": prof["summary"]["syscall_exclusive"],
            "serialize_exclusive": prof["summary"]["serialize_exclusive"],
            "serialize_title_exclusive": prof["summary"]["serialize_title_exclusive"],
            "json_write_exclusive": prof["summary"]["json_write_exclusive"],
            "serialize_title_inclusive": prof["summary"]["serialize_title_inclusive"],
            "syscall_share": prof["summary"]["syscall_share"],
            "serialize_share": prof["summary"]["serialize_share"],
            "serialize_title_inclusive_share": prof["summary"]["serialize_title_inclusive_share"],
            "by_leaf": prof["summary"]["by_leaf"],
            "lines": prof["summary"]["lines"],
        },
        "layout": {
            "order": layout["order"],
            "x_axis_is_time": layout["x_axis_is_time"],
            "total_samples": layout["total_samples"],
            "n_frames": layout["n_frames"],
            "sibling_order_under_process": layout["sibling_order_under_process"],
            "widest_non_root": layout["widest_non_root"],
            "deepest": layout["deepest"],
            "frames": layout["frames"],
        },
    }
    if "flamechart" in prof:
        out["flamechart"] = prof["flamechart"]
    return out


def _public_diff(diff: dict[str, Any]) -> dict[str, Any]:
    return {
        "normalize": diff["normalize"],
        "negate": diff["negate"],
        "widths_from": diff["widths_from"],
        "total1": diff["total1"],
        "total2": diff["total2"],
        "total1_after_normalize": diff["total1_after_normalize"],
        "exclusive_colors": diff["exclusive_colors"],
        "vanished_stacks_in_width_file": diff["vanished_stacks_in_width_file"],
        "n_vanished_in_2": diff["n_vanished_in_2"],
        "layout_x_axis_is_time": diff["layout_x_axis_is_time"],
        "width_total": diff["width_total"],
        "rows": [
            {
                "stack": r["stack"],
                "leaf": r["leaf"],
                "count1": r["count1"],
                "count2": r["count2"],
                "count1_raw": r["count1_raw"],
                "count2_raw": r["count2_raw"],
                "delta": r["delta"],
                "hue": r["hue"],
                "vanished_in_2": r["vanished_in_2"],
            }
            for r in diff["rows"]
        ],
    }


def run() -> dict[str, Any]:
    eng = FlameEngine()
    cmp = eng.compare_same_load()
    truncated = eng.truncated_unequal_load()
    broken = eng.broken_symbols_profile()

    short_on = cmp["short_oncpu"]
    long_on = cmp["long_oncpu"]
    short_off = cmp["short_offcpu"]
    long_off = cmp["long_offcpu"]

    acceptance_wide_and_deep = (
        short_on["layout"]["widest_non_root"] is not None
        and short_on["layout"]["deepest"] is not None
        and short_on["layout"]["deepest"]["name"] == "json_write"
        and short_on["layout"]["deepest"]["depth"] == 3
        and short_on["layout"]["x_axis_is_time"] is False
    )
    acceptance_same_load = (
        cmp["same_request_count"]
        and cmp["serialize_inclusive_equal"]
        and not truncated["same_request_count"]
        and truncated["unequal_load_serialize_counts_differ"]
    )
    pitfall = (
        cmp["pitfall_x_axis_is_not_time"]
        and cmp["pitfall_conn_close_left_of_handle_get"]
        and short_on["flamechart"]["x_axis_is_time"] is True
    )
    tradeoff = (
        cmp["percent_only_serialize_misleading"]
        and cmp["serialize_inclusive_equal"]
        and cmp["normalize_makes_serialize_look_like_growth"]
    )

    return {
        "engine": "FlameEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "freq": FREQ,
        "n_requests": N_REQUESTS,
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_flamegraph_product": True,
        "not_host_flamegraph_pl": True,
        "not_host_stackcollapse": True,
        "not_host_difffolded_pl": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "practice": {
            "short_oncpu": _public_profile(short_on),
            "long_oncpu": _public_profile(long_on),
            "short_wall_s": short_on["wall_s"],
            "long_wall_s": long_on["wall_s"],
            "same_request_count": cmp["same_request_count"],
            "syscall_exclusive_short": cmp["syscall_exclusive_short"],
            "syscall_exclusive_long": cmp["syscall_exclusive_long"],
            "syscall_delta_long_minus_short": cmp["syscall_delta_long_minus_short"],
            "serialize_inclusive_short": cmp["serialize_inclusive_short"],
            "serialize_inclusive_long": cmp["serialize_inclusive_long"],
            "serialize_inclusive_equal": cmp["serialize_inclusive_equal"],
            "serialize_share_short": short_on["summary"]["serialize_title_inclusive_share"],
            "serialize_share_long": long_on["summary"]["serialize_title_inclusive_share"],
            "syscall_share_short": short_on["summary"]["syscall_share"],
            "syscall_share_long": long_on["summary"]["syscall_share"],
        },
        "oncpu_offcpu": {
            "short_offcpu": _public_profile(short_off),
            "long_offcpu": _public_profile(long_off),
            "short_oncpu_total": short_on["summary"]["total"],
            "short_offcpu_total": short_off["summary"]["total"],
            "long_oncpu_total": long_on["summary"]["total"],
            "long_offcpu_total": long_off["summary"]["total"],
            "events_are_distinct": (
                short_on["sampling_event"] == "on-cpu"
                and short_off["sampling_event"] == "off-cpu"
            ),
        },
        "differential": {
            "diff2": _public_diff(cmp["diff2"]),
            "diff1": _public_diff(cmp["diff1"]),
            "diff2_normalized": _public_diff(cmp["diff2_normalized"]),
            "percent_only_serialize_misleading": cmp["percent_only_serialize_misleading"],
            "normalize_makes_serialize_look_like_growth": cmp[
                "normalize_makes_serialize_look_like_growth"
            ],
            "serialize_hue_unnormalized": cmp["serialize_hue_unnormalized"],
            "sys_accept_hue_unnormalized": cmp["sys_accept_hue_unnormalized"],
            "sys_close_hue_unnormalized": cmp["sys_close_hue_unnormalized"],
            "serialize_hue_normalized": cmp["serialize_hue_normalized"],
            "json_hue_normalized": cmp["json_hue_normalized"],
            "sys_accept_in_diff1": cmp["sys_accept_in_diff1"],
        },
        "pitfall": {
            "alpha_sibling_order": cmp["alpha_sibling_order"],
            "time_sibling_order": cmp["time_sibling_order"],
            "flamechart_first_leaf_order": cmp["flamechart_first_leaf_order"],
            "x_axis_of_flame_is_not_time": short_on["layout"]["x_axis_is_time"] is False,
            "x_axis_of_flamechart_is_time": short_on["flamechart"]["x_axis_is_time"] is True,
            "conn_close_left_of_handle_get": cmp["pitfall_conn_close_left_of_handle_get"],
            "pitfall_x_axis_is_not_time": cmp["pitfall_x_axis_is_not_time"],
        },
        "truncated_window": {
            "window_s": truncated["window_s"],
            "short_completed": truncated["short_truncated"]["n_requests_completed"],
            "short_incomplete": truncated["short_truncated"]["n_requests_incomplete"],
            "long_completed": truncated["long"]["n_requests_completed"],
            "same_window": truncated["same_window"],
            "same_request_count": truncated["same_request_count"],
            "serialize_inclusive_short": truncated["serialize_inclusive_short"],
            "serialize_inclusive_long": truncated["serialize_inclusive_long"],
            "unequal_load_serialize_counts_differ": truncated[
                "unequal_load_serialize_counts_differ"
            ],
            "short_oncpu_total": truncated["short_truncated"]["summary"]["total"],
            "long_oncpu_total": truncated["long"]["summary"]["total"],
            "short_wall_s": truncated["short_truncated"]["wall_s"],
            "long_wall_s": truncated["long"]["wall_s"],
        },
        "broken_symbols": {
            "only_unknown_frame": broken["only_unknown_frame"],
            "n_frames": broken["n_frames"],
            "total": broken["profile"]["summary"]["total"],
            "folded_lines": broken["profile"]["summary"]["lines"],
            "deepest": broken["profile"]["layout"]["deepest"],
            "do_not_interpret_unknown_as_hotspot": broken[
                "do_not_interpret_unknown_as_hotspot"
            ],
            "symbols_complete": broken["profile"]["symbols_complete"],
        },
        "acceptance_explains_wide_and_deep": acceptance_wide_and_deep,
        "acceptance_same_load_comparison": acceptance_same_load,
        "pitfall_x_axis_not_time_order": pitfall,
        "tradeoff_picture_needs_raw_counts": tradeoff,
    }
