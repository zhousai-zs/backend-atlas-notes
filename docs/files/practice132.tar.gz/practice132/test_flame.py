#!/usr/bin/env python3
"""Acceptance checks for the lesson 132 teaching flame-graph experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import FREQ, KEY_TITLE, N_REQUESTS, PROCESS, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "FlameEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["freq"] == FREQ == 1000
    assert r["n_requests"] == N_REQUESTS == 2000
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_flamegraph_product"]
    assert r["not_host_flamegraph_pl"] and r["not_host_stackcollapse"]
    assert r["not_host_difffolded_pl"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]

    p = r["practice"]
    assert p["same_request_count"]
    assert p["short_wall_s"] == 30.0 and p["long_wall_s"] == 16.0
    short = p["short_oncpu"]
    long = p["long_oncpu"]
    assert short["n_requests_completed"] == long["n_requests_completed"] == 2000
    assert short["n_requests_incomplete"] == long["n_requests_incomplete"] == 0
    assert short["key"] == KEY_TITLE and short["title"] == TITLE_V1
    assert short["sampling_event"] == "on-cpu" and long["sampling_event"] == "on-cpu"
    assert short["freq"] == 1000 and short["unwind"] == "fp" and short["symbols_complete"]
    assert short["times_are_teaching_virtual_clock"]
    ss, ls = short["summary"], long["summary"]
    assert ss["total"] == 20000 and ls["total"] == 12000
    assert ss["lines"] == [
        "teachkv;accept_loop;sys_accept 4000",
        "teachkv;conn_close;sys_close 4000",
        "teachkv;conn_read;sys_recv 2000",
        "teachkv;conn_write;sys_send 2000",
        "teachkv;handle_get;parse_cmd 2000",
        "teachkv;handle_get;serialize_title 4000",
        "teachkv;handle_get;serialize_title;json_write 2000",
    ]
    assert ls["lines"] == [
        "teachkv;conn_read;sys_recv 2000",
        "teachkv;conn_write;sys_send 2000",
        "teachkv;handle_get;parse_cmd 2000",
        "teachkv;handle_get;serialize_title 4000",
        "teachkv;handle_get;serialize_title;json_write 2000",
    ]
    assert p["syscall_exclusive_short"] == 12000
    assert p["syscall_exclusive_long"] == 4000
    assert p["syscall_delta_long_minus_short"] == -8000
    assert p["serialize_inclusive_short"] == 6000
    assert p["serialize_inclusive_long"] == 6000
    assert p["serialize_inclusive_equal"]
    assert ss["serialize_title_exclusive"] == ls["serialize_title_exclusive"] == 4000
    assert ss["json_write_exclusive"] == ls["json_write_exclusive"] == 2000
    assert p["serialize_share_short"] == 0.3 and p["serialize_share_long"] == 0.5
    assert p["syscall_share_short"] == 0.6 and p["syscall_share_long"] == 0.3333
    assert ss["by_leaf"]["sys_accept"] == 4000 and "sys_accept" not in ls["by_leaf"]
    assert ss["by_leaf"]["sys_close"] == 4000 and "sys_close" not in ls["by_leaf"]

    sl = short["layout"]
    assert sl["order"] == "alpha" and sl["x_axis_is_time"] is False
    assert sl["total_samples"] == 20000
    assert sl["sibling_order_under_process"] == [
        "accept_loop",
        "conn_close",
        "conn_read",
        "conn_write",
        "handle_get",
    ]
    assert sl["widest_non_root"]["name"] == "handle_get"
    assert sl["widest_non_root"]["inclusive"] == 8000
    assert sl["widest_non_root"]["width_share"] == 0.4
    assert sl["widest_non_root"]["depth"] == 1
    assert sl["deepest"]["name"] == "json_write"
    assert sl["deepest"]["depth"] == 3
    assert sl["deepest"]["inclusive"] == 2000
    assert sl["deepest"]["width_share"] == 0.1
    by_name = {(f["name"], f["depth"]): f for f in sl["frames"]}
    assert by_name[("teachkv", 0)]["inclusive"] == 20000
    assert by_name[("sys_accept", 2)]["inclusive"] == 4000
    assert by_name[("sys_accept", 2)]["width_share"] == 0.2
    assert by_name[("serialize_title", 2)]["inclusive"] == 6000
    assert by_name[("serialize_title", 2)]["exclusive"] == 4000
    assert by_name[("serialize_title", 2)]["width_share"] == 0.3
    # conn_close is packed left of handle_get (alphabetical), not last in time.
    assert by_name[("conn_close", 1)]["x0"] == 4000
    assert by_name[("handle_get", 1)]["x0"] == 12000

    ll = long["layout"]
    assert ll["x_axis_is_time"] is False
    long_ser = next(f for f in ll["frames"] if f["name"] == "serialize_title")
    assert long_ser["inclusive"] == 6000 and long_ser["width_share"] == 0.5

    oo = r["oncpu_offcpu"]
    assert oo["events_are_distinct"]
    assert oo["short_oncpu_total"] == 20000 and oo["short_offcpu_total"] == 10000
    assert oo["long_oncpu_total"] == 12000 and oo["long_offcpu_total"] == 4000
    soff, loff = oo["short_offcpu"], oo["long_offcpu"]
    assert soff["sampling_event"] == "off-cpu" and loff["sampling_event"] == "off-cpu"
    assert soff["summary"]["lines"] == [
        "teachkv;accept_loop;wait_accept 6000",
        "teachkv;conn_read;wait_recv 4000",
    ]
    assert loff["summary"]["lines"] == ["teachkv;conn_read;wait_recv 4000"]
    wait_a = next(f for f in soff["layout"]["frames"] if f["name"] == "wait_accept")
    assert wait_a["inclusive"] == 6000 and wait_a["width_share"] == 0.6
    # Same wait_recv exclusive count under both modes; short has extra wait_accept.
    assert soff["summary"]["by_leaf"]["wait_recv"] == 4000
    assert loff["summary"]["by_leaf"]["wait_recv"] == 4000
    assert soff["summary"]["by_leaf"]["wait_accept"] == 6000

    d = r["differential"]
    d2 = d["diff2"]
    assert d2["normalize"] is False and d2["negate"] is False and d2["widths_from"] == 2
    assert d2["total1"] == 20000 and d2["total2"] == 12000
    assert d2["n_vanished_in_2"] == 2
    assert d2["vanished_stacks_in_width_file"] == [
        "teachkv;accept_loop;sys_accept",
        "teachkv;conn_close;sys_close",
    ]
    assert d["percent_only_serialize_misleading"]
    assert d["serialize_hue_unnormalized"]["delta"] == 0
    assert d["serialize_hue_unnormalized"]["hue"] == "gray"
    assert d["serialize_hue_unnormalized"]["exclusive1"] == 4000
    assert d["serialize_hue_unnormalized"]["exclusive2"] == 4000
    assert d["sys_accept_hue_unnormalized"]["delta"] == -4000
    assert d["sys_accept_hue_unnormalized"]["hue"] == "blue"
    assert d["sys_accept_hue_unnormalized"]["vanished_in_2"]
    assert d["sys_close_hue_unnormalized"]["delta"] == -4000
    assert d["sys_close_hue_unnormalized"]["hue"] == "blue"
    # Official -n on this same-load pair wrongly paints serialize as growth.
    assert d["normalize_makes_serialize_look_like_growth"]
    assert d["diff2_normalized"]["normalize"] is True
    assert d["diff2_normalized"]["total1_after_normalize"] == 12000
    assert d["serialize_hue_normalized"]["exclusive1"] == 2400
    assert d["serialize_hue_normalized"]["exclusive2"] == 4000
    assert d["serialize_hue_normalized"]["delta"] == 1600
    assert d["serialize_hue_normalized"]["hue"] == "red"
    assert d["json_hue_normalized"]["delta"] == 800
    assert d["json_hue_normalized"]["hue"] == "red"
    # diff1: widths from the short (before) profile, hues negated.
    d1 = d["diff1"]
    assert d1["negate"] is True and d1["widths_from"] == 2
    assert d1["total2"] == 20000  # widths come from short, the 2nd file here
    assert d["sys_accept_in_diff1"]["exclusive2"] == 4000
    assert d["sys_accept_in_diff1"]["exclusive1"] == 0
    assert d["sys_accept_in_diff1"]["delta"] == 4000
    assert d["sys_accept_in_diff1"]["hue"] == "blue"

    pit = r["pitfall"]
    assert pit["alpha_sibling_order"] == [
        "accept_loop",
        "conn_close",
        "conn_read",
        "conn_write",
        "handle_get",
    ]
    assert pit["time_sibling_order"] == [
        "accept_loop",
        "conn_read",
        "handle_get",
        "conn_write",
        "conn_close",
    ]
    assert pit["flamechart_first_leaf_order"] == [
        "sys_accept",
        "sys_recv",
        "parse_cmd",
        "serialize_title",
        "json_write",
        "sys_send",
        "sys_close",
    ]
    assert pit["x_axis_of_flame_is_not_time"]
    assert pit["x_axis_of_flamechart_is_time"]
    assert pit["conn_close_left_of_handle_get"]
    assert pit["pitfall_x_axis_is_not_time"]

    tr = r["truncated_window"]
    assert tr["window_s"] == 16.0 and tr["same_window"]
    assert tr["long_completed"] == 2000
    assert tr["short_completed"] == 1066 and tr["short_incomplete"] == 1
    assert tr["same_request_count"] is False
    assert tr["serialize_inclusive_short"] == 3199
    assert tr["serialize_inclusive_long"] == 6000
    assert tr["unequal_load_serialize_counts_differ"]
    assert tr["short_oncpu_total"] == 10665
    assert tr["long_oncpu_total"] == 12000
    assert tr["short_wall_s"] == 16.0 and tr["long_wall_s"] == 16.0

    br = r["broken_symbols"]
    assert br["only_unknown_frame"] and br["n_frames"] == 1
    assert br["total"] == 20000
    assert br["folded_lines"] == ["[unknown] 20000"]
    assert br["deepest"]["name"] == "[unknown]" and br["deepest"]["depth"] == 0
    assert br["do_not_interpret_unknown_as_hotspot"]
    assert br["symbols_complete"] is False

    assert r["acceptance_explains_wide_and_deep"]
    assert r["acceptance_same_load_comparison"]
    assert r["pitfall_x_axis_not_time_order"]
    assert r["tradeoff_picture_needs_raw_counts"]


if __name__ == "__main__":
    main()
