#!/usr/bin/env python3
"""Teaching FlameEngine — not Redis, not a real flame-graph product, not a network service.

A Python 3 standard-library model of folding teaching stacks from a
content-backend KV, laying out a flame graph (width = cumulative sample
weight, y-axis = stack depth, x-axis alphabetically ordered and not a
time axis), contrasting on-CPU with off-CPU profiles, and building a
red/blue differential of two folded files.

The named source (checked on 2026-11-14) is Brendan Gregg's FlameGraph
repository at https://github.com/brendangregg/FlameGraph. Its README
describes the three-step pipeline (capture stacks, fold stacks with
stackcollapse-*, render with flamegraph.pl) and the folded line format
"frame1;frame2;frame3 count". The header of flamegraph.pl states that
the x-axis ordering has no meaning and that frames are sorted
alphabetically; --flamechart is the variant that sorts by time and
does not merge stacks. difffolded.pl emits two count columns and,
with flamegraph.pl, colors red for growth and blue for reductions;
widths come from the second folded file; -n normalizes the first
profile's counts to the second total; --negate flips the hues.

The README does not itself define on-CPU versus off-CPU flame graphs.
Those definitions, and the official wording that the x-axis is the
stack-profile population (not the passage of time) and that frame
width is how often a frame was present in the stacks, are on the
repository homepage and the CPU / Off-CPU / Differential pages that
the README and homepage name. This engine is not Brendan Gregg's
Perl scripts, not a host invocation of flamegraph.pl / stackcollapse-*
/ difffolded.pl, not Linux perf, and not a wall-clock measurement.
Times are teaching virtual-clock values, not production RTT.
"""
from __future__ import annotations

from typing import Any, Iterable, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"
FREQ = 1000
PERIOD_US = 1_000_000 // FREQ  # 1000 us
N_REQUESTS = 2000
TRUNCATED_WINDOW_S = 16.00

# Per-request stages. Durations are integer milliseconds so that a
# 1000 Hz virtual sampler lands on exact integer sample counts.
# Stacks are root-to-leaf, matching the folded format in the README.
SHORT_STAGES: tuple[dict[str, Any], ...] = (
    {"stack": (PROCESS, "accept_loop", "sys_accept"), "ms": 2, "kind": "oncpu"},
    {"stack": (PROCESS, "accept_loop", "wait_accept"), "ms": 3, "kind": "offcpu"},
    {"stack": (PROCESS, "conn_read", "sys_recv"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "conn_read", "wait_recv"), "ms": 2, "kind": "offcpu"},
    {"stack": (PROCESS, "handle_get", "parse_cmd"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "handle_get", "serialize_title"), "ms": 2, "kind": "oncpu"},
    {"stack": (PROCESS, "handle_get", "serialize_title", "json_write"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "conn_write", "sys_send"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "conn_close", "sys_close"), "ms": 2, "kind": "oncpu"},
)

LONG_STAGES: tuple[dict[str, Any], ...] = (
    {"stack": (PROCESS, "conn_read", "sys_recv"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "conn_read", "wait_recv"), "ms": 2, "kind": "offcpu"},
    {"stack": (PROCESS, "handle_get", "parse_cmd"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "handle_get", "serialize_title"), "ms": 2, "kind": "oncpu"},
    {"stack": (PROCESS, "handle_get", "serialize_title", "json_write"), "ms": 1, "kind": "oncpu"},
    {"stack": (PROCESS, "conn_write", "sys_send"), "ms": 1, "kind": "oncpu"},
)

SYSCALL_LEAVES = frozenset({"sys_accept", "sys_recv", "sys_send", "sys_close"})
SERIALIZE_LEAVES = frozenset({"serialize_title", "json_write"})


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def fold_key(frames: Iterable[str]) -> str:
    return ";".join(frames)


class _Node:
    __slots__ = ("name", "exclusive", "inclusive", "children")

    def __init__(self, name: str) -> None:
        self.name = name
        self.exclusive = 0
        self.inclusive = 0
        self.children: dict[str, _Node] = {}

    def child(self, name: str) -> "_Node":
        node = self.children.get(name)
        if node is None:
            node = _Node(name)
            self.children[name] = node
        return node


class FlameEngine:
    """Fold, layout, and differentially compare teaching KV profiles."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1

    def stages_for(self, mode: str) -> tuple[dict[str, Any], ...]:
        if mode == "short":
            return SHORT_STAGES
        if mode == "long":
            return LONG_STAGES
        raise ValueError(f"unknown mode: {mode}")

    def capture(
        self,
        mode: str,
        *,
        n_requests: int = N_REQUESTS,
        window_s: Optional[float] = None,
        symbols_complete: bool = True,
        unwind: str = "fp",
    ) -> dict[str, Any]:
        """Walk a virtual-clock request loop and emit 1000 Hz samples.

        If window_s is set, only samples with timestamp in [0, window_s)
        are kept (a truncated wall window). Otherwise the run lasts until
        all n_requests complete. This is a teaching virtual clock, not a
        host perf record -- sleep window and not production RTT.
        """
        stages = self.stages_for(mode)
        deadline_us: Optional[int] = None
        if window_s is not None:
            deadline_us = int(round(window_s * 1_000_000))

        on_samples: list[tuple[int, tuple[str, ...]]] = []
        off_samples: list[tuple[int, tuple[str, ...]]] = []
        t_us = 0
        completed = 0
        incomplete = 0

        def accept(t_sample: int) -> bool:
            if deadline_us is None:
                return True
            return 0 <= t_sample < deadline_us

        stop = False
        for _ in range(n_requests):
            if stop:
                break
            started = False
            finished = True
            for stage in stages:
                dur_us = int(stage["ms"]) * 1000
                start = t_us
                end = t_us + dur_us
                # Samples at k * PERIOD_US for integer k, half-open [start, end).
                k0 = (start + PERIOD_US - 1) // PERIOD_US if start else 0
                if start == 0:
                    k0 = 0
                else:
                    k0 = (start + PERIOD_US - 1) // PERIOD_US
                    if start % PERIOD_US == 0:
                        k0 = start // PERIOD_US
                k = k0
                while k * PERIOD_US < end:
                    t_sample = k * PERIOD_US
                    if not accept(t_sample):
                        finished = False
                        stop = True
                        break
                    started = True
                    frames = stage["stack"]
                    if not symbols_complete or unwind not in {"fp", "dwarf"}:
                        frames = ("[unknown]",)
                    rec = (t_sample, frames)
                    if stage["kind"] == "oncpu":
                        on_samples.append(rec)
                    else:
                        off_samples.append(rec)
                    k += 1
                t_us = end
                if stop:
                    # Remaining time in this stage is not sampled; the
                    # virtual clock still ends at the window bound.
                    break
            if finished and started and not stop:
                completed += 1
            elif started:
                incomplete += 1

        wall_end_us = t_us if deadline_us is None else min(t_us, deadline_us)
        # If we stopped mid-request, wall time is the window.
        if deadline_us is not None:
            wall_end_us = deadline_us if (completed + incomplete) else min(t_us, deadline_us)
            # When the full run is shorter than the window, the clock
            # stops at completion; the caller asked for a cap, not padding.
            if t_us < deadline_us and incomplete == 0 and completed == n_requests:
                wall_end_us = t_us

        return {
            "mode": mode,
            "key": self.key,
            "title": self.title,
            "n_requests_offered": n_requests,
            "n_requests_completed": completed,
            "n_requests_incomplete": incomplete,
            "freq": FREQ,
            "period_us": PERIOD_US,
            "unwind": unwind,
            "symbols_complete": symbols_complete,
            "wall_s": ts(wall_end_us / 1_000_000),
            "window_s": None if window_s is None else ts(window_s),
            "oncpu_samples": on_samples,
            "offcpu_samples": off_samples,
            "times_are_teaching_virtual_clock": True,
        }

    def fold_samples(self, samples: list[tuple[int, tuple[str, ...]]]) -> dict[str, int]:
        folded: dict[str, int] = {}
        for _, frames in samples:
            key = fold_key(frames)
            folded[key] = folded.get(key, 0) + 1
        return folded

    def folded_lines(self, folded: dict[str, int]) -> list[str]:
        return [f"{k} {folded[k]}" for k in sorted(folded)]

    def _build_tree(self, folded: dict[str, int]) -> _Node:
        root = _Node("")
        for key, count in folded.items():
            frames = tuple(key.split(";")) if key else tuple()
            node = root
            root.inclusive += count
            for i, name in enumerate(frames):
                node = node.child(name)
                node.inclusive += count
                if i == len(frames) - 1:
                    node.exclusive += count
        return root

    def layout_flame(
        self,
        folded: dict[str, int],
        *,
        order: str = "alpha",
        total: Optional[int] = None,
    ) -> dict[str, Any]:
        """Pack frames along x.

        order='alpha' matches flamegraph.pl: siblings are sorted by
        name, identical stacks are merged, and the x-axis is not time.
        order='time' is the teaching analogue of --flamechart and is
        handled by layout_flamechart instead.
        """
        if order != "alpha":
            raise ValueError("layout_flame only implements alphabetical merge")
        tree = self._build_tree(folded)
        if total is None:
            total = tree.inclusive
        frames: list[dict[str, Any]] = []

        def walk(node: _Node, depth: int, x0: int) -> None:
            if node.name != "" or depth > 0:
                frames.append(
                    {
                        "name": node.name,
                        "depth": depth,
                        "x0": x0,
                        "x1": x0 + node.inclusive,
                        "exclusive": node.exclusive,
                        "inclusive": node.inclusive,
                        "width_share": share(node.inclusive, total),
                        "exclusive_share": share(node.exclusive, total),
                    }
                )
            cursor = x0
            for name in sorted(node.children):
                child = node.children[name]
                walk(child, depth + (0 if node.name == "" and depth == 0 else 1) if node.name == "" else depth + 1, cursor)
                cursor += child.inclusive

        # Root teaching frames sit at depth 0 (official: count from zero at the bottom).
        cursor = 0
        for name in sorted(tree.children):
            child = tree.children[name]
            walk(child, 0, cursor)
            cursor += child.inclusive

        widest = max((f for f in frames if f["depth"] > 0), key=lambda f: f["inclusive"], default=None)
        deepest = max(frames, key=lambda f: (f["depth"], f["inclusive"]), default=None)
        sibling_order = []
        if tree.children:
            # Immediate children of the process root, if present.
            proc = tree.children.get(PROCESS)
            if proc is not None:
                sibling_order = sorted(proc.children)
            else:
                sibling_order = sorted(tree.children)
        return {
            "order": "alpha",
            "x_axis_is_time": False,
            "total_samples": total,
            "n_frames": len(frames),
            "frames": frames,
            "sibling_order_under_process": sibling_order,
            "widest_non_root": None
            if widest is None
            else {
                "name": widest["name"],
                "depth": widest["depth"],
                "inclusive": widest["inclusive"],
                "width_share": widest["width_share"],
            },
            "deepest": None
            if deepest is None
            else {
                "name": deepest["name"],
                "depth": deepest["depth"],
                "inclusive": deepest["inclusive"],
                "width_share": deepest["width_share"],
            },
        }

    def layout_flamechart(self, samples: list[tuple[int, tuple[str, ...]]]) -> dict[str, Any]:
        """Teaching analogue of --flamechart: sort by time, do not merge stacks."""
        ordered = sorted(samples, key=lambda r: r[0])
        slots: list[dict[str, Any]] = []
        for i, (t_sample, frames) in enumerate(ordered):
            slots.append(
                {
                    "t_us": t_sample,
                    "stack": list(frames),
                    "x0": i,
                    "x1": i + 1,
                    "leaf": frames[-1] if frames else "",
                }
            )
        time_leaf_order = [s["leaf"] for s in slots]
        # First occurrence of each unique leaf along the time axis.
        first_leaf: list[str] = []
        seen = set()
        for leaf in time_leaf_order:
            if leaf not in seen:
                first_leaf.append(leaf)
                seen.add(leaf)
        return {
            "order": "time",
            "x_axis_is_time": True,
            "merged": False,
            "total_samples": len(ordered),
            "first_leaf_order": first_leaf,
            # Keep the raw first-request slice only; the full list is long.
            "first_request_leaves": first_leaf,
        }

    def summarize_folded(self, folded: dict[str, int]) -> dict[str, Any]:
        total = sum(folded.values())
        syscall = 0
        serialize = 0
        by_leaf: dict[str, int] = {}
        for key, count in folded.items():
            leaf = key.split(";")[-1] if key else ""
            by_leaf[leaf] = by_leaf.get(leaf, 0) + count
            if leaf in SYSCALL_LEAVES:
                syscall += count
            if leaf in SERIALIZE_LEAVES:
                serialize += count
        # Inclusive serialize_title = exclusive serialize_title + json_write
        ser_excl = by_leaf.get("serialize_title", 0)
        json_ex = by_leaf.get("json_write", 0)
        return {
            "total": total,
            "syscall_exclusive": syscall,
            "serialize_exclusive": serialize,
            "serialize_title_exclusive": ser_excl,
            "json_write_exclusive": json_ex,
            "serialize_title_inclusive": ser_excl + json_ex,
            "syscall_share": share(syscall, total),
            "serialize_share": share(serialize, total),
            "serialize_title_inclusive_share": share(ser_excl + json_ex, total),
            "by_leaf": by_leaf,
            "lines": self.folded_lines(folded),
        }

    def profile(
        self,
        mode: str,
        *,
        n_requests: int = N_REQUESTS,
        window_s: Optional[float] = None,
        symbols_complete: bool = True,
        unwind: str = "fp",
        kind: str = "oncpu",
    ) -> dict[str, Any]:
        cap = self.capture(
            mode,
            n_requests=n_requests,
            window_s=window_s,
            symbols_complete=symbols_complete,
            unwind=unwind,
        )
        samples = cap["oncpu_samples"] if kind == "oncpu" else cap["offcpu_samples"]
        folded = self.fold_samples(samples)
        summary = self.summarize_folded(folded)
        layout = self.layout_flame(folded)
        # Drop the raw sample list from the returned profile (it is large).
        out = {
            "mode": mode,
            "kind": kind,
            "sampling_event": "on-cpu" if kind == "oncpu" else "off-cpu",
            "key": cap["key"],
            "title": cap["title"],
            "n_requests_offered": cap["n_requests_offered"],
            "n_requests_completed": cap["n_requests_completed"],
            "n_requests_incomplete": cap["n_requests_incomplete"],
            "freq": cap["freq"],
            "period_us": cap["period_us"],
            "unwind": cap["unwind"],
            "symbols_complete": cap["symbols_complete"],
            "wall_s": cap["wall_s"],
            "window_s": cap["window_s"],
            "times_are_teaching_virtual_clock": True,
            "folded": folded,
            "summary": summary,
            "layout": {
                "order": layout["order"],
                "x_axis_is_time": layout["x_axis_is_time"],
                "total_samples": layout["total_samples"],
                "n_frames": layout["n_frames"],
                "sibling_order_under_process": layout["sibling_order_under_process"],
                "widest_non_root": layout["widest_non_root"],
                "deepest": layout["deepest"],
                "frames": layout["frames"],
            },
        }
        if kind == "oncpu" and symbols_complete:
            chart = self.layout_flamechart(samples)
            out["flamechart"] = {
                "order": chart["order"],
                "x_axis_is_time": chart["x_axis_is_time"],
                "merged": chart["merged"],
                "total_samples": chart["total_samples"],
                "first_leaf_order": chart["first_leaf_order"],
            }
        return out

    def diff_folded(
        self,
        folded1: dict[str, int],
        folded2: dict[str, int],
        *,
        normalize: bool = False,
        negate: bool = False,
        widths_from: int = 2,
    ) -> dict[str, Any]:
        """Teaching analogue of difffolded.pl plus flamegraph.pl coloring.

        widths_from=2 matches the default 'diff2' (widths from the second
        file, colors = what DID happen). widths_from=1 plus negate matches
        the official 'diff1' recipe: difffolded.pl folded2 folded1 piped
        to flamegraph.pl --negate, so widths show the first profile and
        colors show what WILL happen. Passing normalize=True applies the
        official -n integer scaling of column 1 onto total 2.
        """
        keys = set(folded1) | set(folded2)
        total1 = sum(folded1.values())
        total2 = sum(folded2.values())
        rows = []
        for key in sorted(keys):
            c1 = folded1.get(key, 0)
            c2 = folded2.get(key, 0)
            c1_raw, c2_raw = c1, c2
            if normalize and total1 != total2 and total1 != 0:
                c1 = int(c1 * total2 / total1)
            delta = c2 - c1
            hue = "red" if delta > 0 else "blue" if delta < 0 else "gray"
            if negate:
                hue = {"red": "blue", "blue": "red", "gray": "gray"}[hue]
            rows.append(
                {
                    "stack": key,
                    "leaf": key.split(";")[-1] if key else "",
                    "count1": c1,
                    "count2": c2,
                    "count1_raw": c1_raw,
                    "count2_raw": c2_raw,
                    "delta": delta,
                    "hue": hue,
                    "vanished_in_2": c2 == 0 and c1_raw > 0,
                    "vanished_in_1": c1_raw == 0 and c2 > 0,
                }
            )
        width_source = folded2 if widths_from == 2 else folded1
        # Exclusive color at each frame name (official: color is the
        # difference that function directly contributed, not children).
        # Rebuild exclusive deltas from the (possibly normalized) columns.
        col1 = {r["stack"]: r["count1"] for r in rows}
        col2 = {r["stack"]: r["count2"] for r in rows}
        tree1 = self._build_tree(col1)
        tree2 = self._build_tree(col2)

        def collect_exclusive(node: _Node, acc: dict[str, int]) -> None:
            if node.name:
                acc[node.name] = acc.get(node.name, 0) + node.exclusive
            for ch in node.children.values():
                collect_exclusive(ch, acc)

        ex1: dict[str, int] = {}
        ex2: dict[str, int] = {}
        collect_exclusive(tree1, ex1)
        collect_exclusive(tree2, ex2)
        names = set(ex1) | set(ex2)
        exclusive_colors = []
        for name in sorted(names):
            d = ex2.get(name, 0) - ex1.get(name, 0)
            hue = "red" if d > 0 else "blue" if d < 0 else "gray"
            if negate:
                hue = {"red": "blue", "blue": "red", "gray": "gray"}[hue]
            exclusive_colors.append(
                {
                    "name": name,
                    "exclusive1": ex1.get(name, 0),
                    "exclusive2": ex2.get(name, 0),
                    "delta": d,
                    "hue": hue,
                    "vanished_in_2": ex2.get(name, 0) == 0 and ex1.get(name, 0) > 0,
                }
            )
        vanished = [r for r in rows if r["vanished_in_2"]]
        layout = self.layout_flame(width_source)
        return {
            "normalize": normalize,
            "negate": negate,
            "widths_from": widths_from,
            "total1": total1,
            "total2": total2,
            "total1_after_normalize": sum(r["count1"] for r in rows),
            "rows": rows,
            "exclusive_colors": exclusive_colors,
            "vanished_stacks_in_width_file": [r["stack"] for r in vanished],
            "n_vanished_in_2": len(vanished),
            "layout_x_axis_is_time": layout["x_axis_is_time"],
            "width_total": layout["total_samples"],
        }


    def compare_same_load(self) -> dict[str, Any]:
        short_on = self.profile("short", kind="oncpu")
        long_on = self.profile("long", kind="oncpu")
        short_off = self.profile("short", kind="offcpu")
        long_off = self.profile("long", kind="offcpu")
        # Same offered load: both complete N_REQUESTS. Do not normalize
        # by default — on-CPU totals differ because short connections
        # do extra accept/close work, not because the request count differs.
        diff2 = self.diff_folded(short_on["folded"], long_on["folded"], normalize=False, negate=False, widths_from=2)
        diff1 = self.diff_folded(long_on["folded"], short_on["folded"], normalize=False, negate=True, widths_from=2)
        # Official -n on this pair is the wrong tool: it scales the
        # short profile down to the long total and makes the shared
        # serialize path look like growth.
        diff2_n = self.diff_folded(short_on["folded"], long_on["folded"], normalize=True, negate=False, widths_from=2)

        def leaf_hue(diff: dict[str, Any], name: str) -> dict[str, Any]:
            for row in diff["exclusive_colors"]:
                if row["name"] == name:
                    return row
            return {}

        ser_short = short_on["summary"]["serialize_title_inclusive"]
        ser_long = long_on["summary"]["serialize_title_inclusive"]
        sys_short = short_on["summary"]["syscall_exclusive"]
        sys_long = long_on["summary"]["syscall_exclusive"]
        same_serialize_raw = ser_short == ser_long
        # Percentage-only reading would say serialize got "wider".
        percent_misleading = (
            short_on["summary"]["serialize_title_inclusive_share"]
            < long_on["summary"]["serialize_title_inclusive_share"]
            and same_serialize_raw
        )
        # Alphabetical sibling order vs time order of a request.
        alpha = short_on["layout"]["sibling_order_under_process"]
        time_order = short_on.get("flamechart", {}).get("first_leaf_order", [])
        # Map leaves back to the parent sibling under teachkv for the pitfall.
        # Time order of siblings: accept_loop, conn_read, handle_get, conn_write, conn_close
        time_siblings = ["accept_loop", "conn_read", "handle_get", "conn_write", "conn_close"]
        pitfall_xaxis_not_time = alpha != time_siblings and "conn_close" in alpha and "accept_loop" in alpha
        # conn_close is left of handle_get alphabetically but last in time.
        close_left_of_handle = False
        if "conn_close" in alpha and "handle_get" in alpha:
            close_left_of_handle = alpha.index("conn_close") < alpha.index("handle_get")

        return {
            "n_requests": N_REQUESTS,
            "same_request_count": short_on["n_requests_completed"]
            == long_on["n_requests_completed"]
            == N_REQUESTS,
            "short_oncpu": short_on,
            "long_oncpu": long_on,
            "short_offcpu": short_off,
            "long_offcpu": long_off,
            "diff2": diff2,
            "diff1": diff1,
            "diff2_normalized": diff2_n,
            "serialize_inclusive_short": ser_short,
            "serialize_inclusive_long": ser_long,
            "serialize_inclusive_equal": same_serialize_raw,
            "syscall_exclusive_short": sys_short,
            "syscall_exclusive_long": sys_long,
            "syscall_delta_long_minus_short": sys_long - sys_short,
            "percent_only_serialize_misleading": percent_misleading,
            "normalize_makes_serialize_look_like_growth": (
                leaf_hue(diff2_n, "serialize_title").get("delta", 0) > 0
                or leaf_hue(diff2_n, "json_write").get("delta", 0) > 0
            ),
            "serialize_hue_unnormalized": leaf_hue(diff2, "serialize_title"),
            "sys_accept_hue_unnormalized": leaf_hue(diff2, "sys_accept"),
            "sys_close_hue_unnormalized": leaf_hue(diff2, "sys_close"),
            "serialize_hue_normalized": leaf_hue(diff2_n, "serialize_title"),
            "json_hue_normalized": leaf_hue(diff2_n, "json_write"),
            "sys_accept_in_diff1": leaf_hue(diff1, "sys_accept"),
            "alpha_sibling_order": alpha,
            "time_sibling_order": time_siblings,
            "flamechart_first_leaf_order": time_order,
            "pitfall_x_axis_is_not_time": pitfall_xaxis_not_time,
            "pitfall_conn_close_left_of_handle_get": close_left_of_handle,
        }

    def truncated_unequal_load(self) -> dict[str, Any]:
        """Cut both profiles at the long-connection completion time.

        The long run has finished 2000 requests; the short run has not.
        This is the same wall window, not the same load.
        """
        long_full = self.profile("long", kind="oncpu")
        window_s = long_full["wall_s"]
        short_cut = self.profile("short", kind="oncpu", window_s=window_s)
        return {
            "window_s": window_s,
            "long": long_full,
            "short_truncated": short_cut,
            "same_window": short_cut["wall_s"] == long_full["wall_s"],
            "same_request_count": short_cut["n_requests_completed"] == long_full["n_requests_completed"],
            "serialize_inclusive_short": short_cut["summary"]["serialize_title_inclusive"],
            "serialize_inclusive_long": long_full["summary"]["serialize_title_inclusive"],
            "unequal_load_serialize_counts_differ": (
                short_cut["summary"]["serialize_title_inclusive"]
                != long_full["summary"]["serialize_title_inclusive"]
            ),
        }

    def broken_symbols_profile(self) -> dict[str, Any]:
        prof = self.profile("short", kind="oncpu", symbols_complete=False, unwind="fp")
        layout = prof["layout"]
        only_unknown = list(prof["folded"].keys()) == ["[unknown]"]
        return {
            "profile": prof,
            "only_unknown_frame": only_unknown,
            "n_frames": layout["n_frames"],
            "widest": layout["widest_non_root"],
            "deepest": layout["deepest"],
            "do_not_interpret_unknown_as_hotspot": only_unknown
            and prof["summary"]["total"] > 0,
        }
