"""Helpers for the order-index teaching lab. See engine.py and test_index.py."""
from __future__ import annotations

from engine import OrderTable, generate_orders


class OrderStore:
    """Tiny facade used by the lesson text. mode is 'safe' or 'naive'."""

    def __init__(self, table: OrderTable, mode: str):
        self.table = table
        self.mode = mode

    def find_paid_in_window(self, user_id, status, lo, hi, select):
        equals = {"user_id": user_id, "status": status}
        ranges = {"created_at": (lo, hi)}
        if self.mode == "safe":
            plan = self.table.plan_safe(equals, ranges, select)
        else:
            plan = self.table.plan_naive(equals, ranges, select)
        return self.table.execute(plan, equals, ranges, select)


def load_demo():
    rows = generate_orders()
    table = OrderTable(split_mode="safe")
    table.add_index("idx_ust", ["user_id", "status", "created_at"])
    for r in rows:
        table.insert(r)
    return OrderStore(table, "safe")
