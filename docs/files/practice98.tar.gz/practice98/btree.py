"""Page-based B+Tree teaching model (stdlib only).

This is not InnoDB. Page capacity is kept tiny so splits and fill
factor are visible. Counters (pages_read / pages_written / splits)
are exact for this model and must not be quoted as MySQL numbers.
"""
from __future__ import annotations


class _Inf:
    """Sentinel for open ends of a range query. Only used on the query side."""

    __slots__ = ("sign",)

    def __init__(self, sign: int):
        self.sign = sign

    def __repr__(self):
        return "+inf" if self.sign > 0 else "-inf"

    def __eq__(self, other):
        return isinstance(other, _Inf) and self.sign == other.sign

    def __lt__(self, other):
        if isinstance(other, _Inf):
            return self.sign < other.sign
        return self.sign < 0

    def __gt__(self, other):
        if isinstance(other, _Inf):
            return self.sign > other.sign
        return self.sign > 0

    def __le__(self, other):
        return self == other or self < other

    def __ge__(self, other):
        return self == other or self > other


NEG_INF = _Inf(-1)
POS_INF = _Inf(1)

# Tiny on purpose: 16 keys/page makes splits show up after a few dozen inserts.
MAX_KEYS = 16


class Page:
    __slots__ = ("page_id", "is_leaf", "keys", "payloads", "children", "next_leaf")

    def __init__(self, page_id: int, is_leaf: bool):
        self.page_id = page_id
        self.is_leaf = is_leaf
        self.keys = []       # leaf: full keys; internal: separator keys
        self.payloads = []   # leaf only, parallel to keys
        self.children = []   # internal only; len = len(keys) + 1
        self.next_leaf = None


class Stats:
    def __init__(self):
        self.reset()

    def reset(self):
        self.pages_read = 0
        self.pages_written = 0
        self.splits = 0
        self.rows_examined = 0

    def as_dict(self):
        return {
            "pages_read": self.pages_read,
            "pages_written": self.pages_written,
            "splits": self.splits,
            "rows_examined": self.rows_examined,
        }


class BPlusTree:
    def __init__(self, name: str, split_mode: str = "safe"):
        if split_mode not in ("safe", "naive"):
            raise ValueError(split_mode)
        self.name = name
        self.split_mode = split_mode
        self.pages = {}
        self._next_id = 1
        self.stats = Stats()
        root = self._new_page(is_leaf=True)
        self.root_id = root.page_id

    def _new_page(self, is_leaf: bool) -> Page:
        page = Page(self._next_id, is_leaf)
        self._next_id += 1
        self.pages[page.page_id] = page
        return page

    def _get(self, page_id: int, count_read: bool) -> Page:
        if count_read:
            self.stats.pages_read += 1
        return self.pages[page_id]

    def height(self) -> int:
        h = 1
        page = self.pages[self.root_id]
        while not page.is_leaf:
            h += 1
            page = self.pages[page.children[0]]
        return h

    def leaf_count(self) -> int:
        return sum(1 for p in self.pages.values() if p.is_leaf)

    def page_count(self) -> int:
        return len(self.pages)

    def key_count(self) -> int:
        return sum(len(p.keys) for p in self.pages.values() if p.is_leaf)

    def fill_factor(self) -> float:
        leaves = [p for p in self.pages.values() if p.is_leaf]
        if not leaves:
            return 0.0
        return sum(len(p.keys) for p in leaves) / (len(leaves) * MAX_KEYS)

    def _child_index(self, page: Page, key) -> int:
        # first i such that key < page.keys[i]; that child is children[i]
        i = 0
        while i < len(page.keys) and key >= page.keys[i]:
            i += 1
        return i

    def _leaf_insert_pos(self, page: Page, key) -> int:
        i = 0
        while i < len(page.keys) and page.keys[i] < key:
            i += 1
        return i

    def _descend(self, key, count_read: bool):
        """Return (leaf, path) where path is [(parent, child_index), ...]."""
        path = []
        page = self._get(self.root_id, count_read)
        while not page.is_leaf:
            idx = self._child_index(page, key)
            path.append((page, idx))
            page = self._get(page.children[idx], count_read)
        return page, path

    def insert(self, key, payload) -> None:
        dirty = set()
        leaf, path = self._descend(key, count_read=True)
        pos = self._leaf_insert_pos(leaf, key)
        if pos < len(leaf.keys) and leaf.keys[pos] == key:
            raise ValueError(f"duplicate key {key} in {self.name}")
        leaf.keys.insert(pos, key)
        leaf.payloads.insert(pos, payload)
        dirty.add(leaf.page_id)

        if len(leaf.keys) <= MAX_KEYS:
            self.stats.pages_written += len(dirty)
            return

        self._split_leaf(leaf, path, dirty)
        self.stats.pages_written += len(dirty)

    def _is_rightmost_path(self, page: Page, path) -> bool:
        """True if this leaf is the rightmost leaf (sequential append target)."""
        if page.next_leaf is not None:
            return False
        # every hop on the path must have taken the last child
        for parent, idx in path:
            if idx != len(parent.children) - 1:
                return False
        return True

    def _split_point(self, nkeys: int, right_biased: bool) -> int:
        # mid = number of keys that stay on the left page
        if right_biased and self.split_mode == "safe":
            # InnoDB-like: sequential inserts leave pages nearly full
            # (docs: about 15/16 full). Keep 15 keys on the left.
            return min(nkeys - 1, (MAX_KEYS * 15) // 16)
        return nkeys // 2

    def _split_leaf(self, leaf: Page, path, dirty: set) -> None:
        self.stats.splits += 1
        right_biased = self._is_rightmost_path(leaf, path)
        mid = self._split_point(len(leaf.keys), right_biased)
        new = self._new_page(is_leaf=True)
        new.keys = leaf.keys[mid:]
        new.payloads = leaf.payloads[mid:]
        new.next_leaf = leaf.next_leaf
        leaf.keys = leaf.keys[:mid]
        leaf.payloads = leaf.payloads[:mid]
        leaf.next_leaf = new.page_id
        dirty.add(leaf.page_id)
        dirty.add(new.page_id)
        sep = new.keys[0]
        self._insert_into_parent(path, sep, new.page_id, dirty)

    def _insert_into_parent(self, path, sep, right_id: int, dirty: set) -> None:
        if not path:
            # grow a new root
            new_root = self._new_page(is_leaf=False)
            left_id = self.root_id
            new_root.keys = [sep]
            new_root.children = [left_id, right_id]
            self.root_id = new_root.page_id
            dirty.add(new_root.page_id)
            return

        parent, idx = path[-1]
        # right sibling goes at idx+1; separator at idx
        parent.keys.insert(idx, sep)
        parent.children.insert(idx + 1, right_id)
        dirty.add(parent.page_id)
        if len(parent.keys) <= MAX_KEYS:
            return

        self._split_internal(parent, path[:-1], dirty)

    def _split_internal(self, node: Page, path, dirty: set) -> None:
        self.stats.splits += 1
        mid = len(node.keys) // 2
        # promote keys[mid]; left keeps [:mid], right keeps [mid+1:]
        promote = node.keys[mid]
        new = self._new_page(is_leaf=False)
        new.keys = node.keys[mid + 1:]
        new.children = node.children[mid + 1:]
        node.keys = node.keys[:mid]
        node.children = node.children[: mid + 1]
        dirty.add(node.page_id)
        dirty.add(new.page_id)
        self._insert_into_parent(path, promote, new.page_id, dirty)

    def search(self, key):
        """Exact match. Returns payload or None. Counts pages_read + 1 examined on hit or miss at leaf."""
        leaf, _ = self._descend(key, count_read=True)
        for i, k in enumerate(leaf.keys):
            self.stats.rows_examined += 1
            if k == key:
                return leaf.payloads[i]
            if k > key:
                break
        return None

    def range_scan(self, lo, hi, residual=None):
        """Yield (key, payload) for lo <= key <= hi.

        residual(key, payload) -> bool, if given, is applied after the key
        range; rejected rows still count as examined.
        """
        leaf, _ = self._descend(lo, count_read=True)
        visited = {leaf.page_id}
        while leaf is not None:
            for k, p in zip(leaf.keys, leaf.payloads):
                if k < lo:
                    continue
                if k > hi:
                    return
                self.stats.rows_examined += 1
                if residual is not None and not residual(k, p):
                    continue
                yield k, p
            if leaf.next_leaf is None:
                return
            if leaf.next_leaf in visited:
                raise RuntimeError("leaf cycle")
            visited.add(leaf.next_leaf)
            leaf = self._get(leaf.next_leaf, count_read=True)

    def full_scan(self, residual=None):
        """Leaf-chain scan from the left-most leaf (index or table scan)."""
        page = self._get(self.root_id, count_read=True)
        while not page.is_leaf:
            page = self._get(page.children[0], count_read=True)
        visited = {page.page_id}
        while page is not None:
            for k, p in zip(page.keys, page.payloads):
                self.stats.rows_examined += 1
                if residual is not None and not residual(k, p):
                    continue
                yield k, p
            if page.next_leaf is None:
                return
            if page.next_leaf in visited:
                raise RuntimeError("leaf cycle")
            visited.add(page.next_leaf)
            page = self._get(page.next_leaf, count_read=True)
