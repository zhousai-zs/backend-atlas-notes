#!/usr/bin/env python3
"""Acceptance checks for the g-index teaching lab."""
from __future__ import annotations

import json
import os
import sys

from engine import run_experiments

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    data = run_experiments()
    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    p = data["prefix"]
    c = data["covering"]
    w = data["write"]
    s = data["sqlite"]

    # 1. Leftmost prefix / column order
    assert p["ids_match"] is True, p
    assert p["gold_count"] == p["safe_hits"] == p["wrong_hits"] == p["naive_hits"]
    assert p["gold_count"] > 0, p
    # Correct (user_id, status, created_at) examines about the hit count,
    # not the whole table. Wrong leading column examines far more.
    assert p["safe_examined"] == p["gold_count"], p
    assert "COVERING" in p["safe_explain"], p
    assert p["wrong_examined"] >= 10 * p["safe_examined"], p
    assert p["wrong_examined"] > 100, p
    assert "SEARCH" in p["safe_explain"] and "user_id,status,created_at" in p["safe_explain"].replace(" ", "")
    # Status-only cannot use a (user_id, ...) prefix; safe does a clustered
    # scan and examines every row. Naive "uses" the secondary and still
    # walks about as many index rows.
    assert p["status_only_safe_examined"] == data["n_rows"], p
    assert "SCAN" in p["status_only_safe_explain"], p
    assert p["status_only_naive_examined"] >= p["paid_count"], p
    # Gap: user_id + created_at with status in the middle uses only user_id
    # and therefore examines all of that user's orders.
    assert p["gap_examined"] == p["user_count"], p
    assert p["gap_hits"] <= p["gap_examined"], p
    assert "user_id" in p["gap_explain"]

    # 2. Covering vs 回表
    assert c["ids_match"] is True, c
    assert c["hits"] == c["gold_hits"] > 0, c
    assert c["cover_lookups"] == 0, c
    assert c["noncover_lookups"] == c["hits"], c
    assert c["naive_lookups"] == c["hits"], c
    assert "COVERING" in c["cover_explain"], c
    assert "回表" in c["noncover_explain"], c
    assert c["cover_pages"] < c["noncover_pages"], c
    assert c["cover_pages"] < c["naive_pages"], c

    # 3. Selectivity, splits, write amplification
    assert w["n_rows"] == 2000, w
    pk = w["pk_only"]
    one = w["one_secondary"]
    three = w["three_secondaries"]
    naive_split = w["naive_split_pk"]
    safe_split = w["safe_split_pk"]
    # Each extra secondary index is another B+Tree to maintain.
    assert one["pages_written"] > pk["pages_written"], (pk, one)
    assert three["pages_written"] > one["pages_written"], (one, three)
    assert three["pages_written"] >= 2 * pk["pages_written"], (pk, three)
    assert three["splits"] > pk["splits"], (pk, three)
    assert three["index_pages"] > one["index_pages"] > 0, w
    # Sequential PK + 50/50 split leaves leaves about half full;
    # right-biased (safe) fill is clearly higher, so fewer pages.
    assert naive_split["pk_fill"] < 0.65, naive_split
    assert safe_split["pk_fill"] >= 0.85, safe_split
    assert safe_split["pk_leaf_pages"] < naive_split["pk_leaf_pages"], (safe_split, naive_split)
    # "Using the status index" still examines every paid row (~half the table).
    assert w["status_hits"] == w["paid_count"], w
    assert w["status_examined"] == w["paid_count"], w
    assert w["status_examined"] >= 8 * w["user_examined"], w
    assert w["user_hits"] == w["user_count"], w
    assert w["paid_count"] >= 800, w

    # 4. sqlite3 EXPLAIN QUERY PLAN confirms the same access-path story
    assert s["results_match"] is True, s
    assert s["result_count"] == p["gold_count"], s
    safe_txt = " ".join(s["plan_safe"]).lower()
    no_txt = " ".join(s["plan_no_index"]).lower()
    status_txt = " ".join(s["plan_status_only"]).lower()
    cover_txt = " ".join(s["plan_covered"]).lower()
    assert "idx_safe" in safe_txt, s["plan_safe"]
    assert "idx_safe" not in no_txt, s["plan_no_index"]
    # No useful prefix on (user_id, status, created_at) for status-only.
    assert "idx_safe" not in status_txt, s["plan_status_only"]
    assert "idx_cover" in cover_txt, s["plan_covered"]

    print("ALL_CHECKS_PASSED")
    print(f"prefix: safe_examined={p['safe_examined']} wrong_examined={p['wrong_examined']} gold={p['gold_count']}")
    print(f"covering: lookups {c['noncover_lookups']} -> {c['cover_lookups']}; pages {c['noncover_pages']} -> {c['cover_pages']}")
    print(f"write: pk_written={pk['pages_written']} one={one['pages_written']} three={three['pages_written']}")
    print(f"fill: naive={naive_split['pk_fill']} safe={safe_split['pk_fill']} leaves {naive_split['pk_leaf_pages']}->{safe_split['pk_leaf_pages']}")
    print(f"selectivity: status_examined={w['status_examined']} user_examined={w['user_examined']}")
    print(f"sqlite safe plan: {s['plan_safe']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
