"""Order-table teaching engine on a page-based B+Tree (stdlib + sqlite3).

Models clustered PK + secondary indexes, leftmost-prefix planning,
covering vs bookmark lookup (回表), and write amplification from
extra indexes / split policy. Not InnoDB and not a MySQL planner.
"""
from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass, field

from btree import BPlusTree, NEG_INF, POS_INF, MAX_KEYS


N_ORDERS = 2000
N_USERS = 100
STATUSES = ("pending", "paid", "cancelled", "refunded")

# Query used across the labs (a typical "my paid orders in a window").
Q_USER = 42
Q_STATUS = "paid"
Q_LO = 10000
Q_HI = 15000


def _status_for(i: int) -> str:
    # Roughly 50% paid, 30% pending, 15% cancelled, 5% refunded.
    r = i % 20
    if r < 10:
        return "paid"
    if r < 16:
        return "pending"
    if r < 19:
        return "cancelled"
    return "refunded"


def generate_orders(n: int = N_ORDERS):
    rows = []
    for i in range(1, n + 1):
        user_id = ((i - 1) % N_USERS) + 1
        status = _status_for(i)
        created_at = 1000 + (i * 13) % 28000
        amount = 10 + (i * 17) % 990
        rows.append(
            {
                "order_id": i,
                "user_id": user_id,
                "status": status,
                "created_at": created_at,
                "amount": amount,
            }
        )
    return rows


@dataclass
class Plan:
    kind: str  # "search" | "scan"
    index: str
    start_key: tuple | None
    end_key: tuple | None
    used_prefix: list
    covering: bool
    residual_cols: list
    explain: str


@dataclass
class ExecResult:
    rows: list
    plan: Plan
    pages_read: int
    rows_examined: int
    bookmark_lookups: int
    elapsed_ms: float
    tree_stats: dict = field(default_factory=dict)


class OrderTable:
    """Clustered PK on order_id plus optional secondary B+Trees."""

    def __init__(self, split_mode: str = "safe"):
        self.split_mode = split_mode
        self.pk = BPlusTree("pk_order_id", split_mode=split_mode)
        # name -> {"columns": [...], "tree": BPlusTree}
        self.secondaries = {}
        self.n = 0

    def add_index(self, name: str, columns: list):
        if name in self.secondaries:
            raise ValueError(name)
        if "order_id" not in columns:
            # InnoDB secondary indexes include the PK columns; we do the same
            # so keys are unique and SELECT order_id can be covering.
            key_cols = list(columns) + ["order_id"]
        else:
            key_cols = list(columns)
        self.secondaries[name] = {"columns": key_cols, "tree": BPlusTree(name, split_mode=self.split_mode)}

    def _sec_key(self, columns, row):
        return tuple(row[c] for c in columns)

    def _sec_payload(self, columns, row):
        # Extra row fields not already in the key, so a covering check can
        # see them without a bookmark lookup. PK is already in the key.
        extra = {}
        for c in ("user_id", "status", "created_at", "amount", "order_id"):
            if c not in columns:
                extra[c] = row[c]
        return extra

    def insert(self, row: dict):
        pk_key = (row["order_id"],)
        self.pk.insert(pk_key, dict(row))
        for spec in self.secondaries.values():
            key = self._sec_key(spec["columns"], row)
            payload = self._sec_payload(spec["columns"], row)
            spec["tree"].insert(key, payload)
        self.n += 1

    def reset_stats(self):
        self.pk.stats.reset()
        for spec in self.secondaries.values():
            spec["tree"].stats.reset()

    def snapshot_stats(self):
        out = {"pk": self.pk.stats.as_dict()}
        for name, spec in self.secondaries.items():
            out[name] = spec["tree"].stats.as_dict()
        return out

    def write_cost(self):
        pages_written = self.pk.stats.pages_written
        splits = self.pk.stats.splits
        for spec in self.secondaries.values():
            pages_written += spec["tree"].stats.pages_written
            splits += spec["tree"].stats.splits
        index_pages = sum(s["tree"].page_count() for s in self.secondaries.values())
        return {
            "pages_written": pages_written,
            "splits": splits,
            "pk_pages": self.pk.page_count(),
            "pk_leaf_pages": self.pk.leaf_count(),
            "pk_fill": round(self.pk.fill_factor(), 4),
            "pk_height": self.pk.height(),
            "index_pages": index_pages,
            "total_pages": self.pk.page_count() + index_pages,
            "n_secondary": len(self.secondaries),
        }

    def _row_matches(self, row, equals, ranges):
        for c, v in equals.items():
            if row[c] != v:
                return False
        for c, (lo, hi) in ranges.items():
            if row[c] < lo or row[c] > hi:
                return False
        return True

    def plan_safe(self, equals: dict, ranges: dict, select: list) -> Plan:
        needed = set(select) | set(equals) | set(ranges)
        candidates = []

        def consider(name, columns, is_pk):
            used = []
            saw_range = False
            for c in columns:
                if c == "order_id" and not is_pk and c not in equals and c not in ranges:
                    break
                if c in equals and not saw_range:
                    used.append(c)
                    continue
                if c in ranges and not saw_range:
                    used.append(c)
                    saw_range = True
                    continue
                break
            if not used and not is_pk:
                return
            covering = all(col in columns or col == "order_id" for col in needed)
            # Prefer longer prefix, then covering, then fewer indexed columns
            # (smaller keys). Clustered scan (used empty on PK) is the fallback.
            score = (len(used), 1 if covering else 0, -len(columns))
            start, end = self._bounds(columns, equals, ranges, used)
            residual = [c for c in list(equals) + list(ranges) if c not in used]
            kind = "search" if used else "scan"
            if is_pk:
                label = "PRIMARY (clustered order_id)"
            else:
                label = f"SECONDARY {name} ({', '.join(columns)})"
            access = "SEARCH" if used else "SCAN"
            cov = "COVERING" if covering else "回表"
            residual_s = ",".join(residual) if residual else "-"
            used_s = ",".join(used) if used else "-"
            explain = (
                f"{access} {label}; used_prefix=({used_s}); "
                f"{cov}; residual=({residual_s})"
            )
            candidates.append(
                (
                    score,
                    Plan(
                        kind=kind,
                        index="pk" if is_pk else name,
                        start_key=start,
                        end_key=end,
                        used_prefix=used,
                        covering=covering,
                        residual_cols=residual,
                        explain=explain,
                    ),
                )
            )

        consider("pk", ["order_id"], True)
        for name, spec in self.secondaries.items():
            consider(name, spec["columns"], False)
        candidates.sort(key=lambda x: x[0], reverse=True)
        return candidates[0][1]

    def plan_naive(self, equals: dict, ranges: dict, select: list) -> Plan:
        # Picks the first secondary that mentions ANY predicate column,
        # even if it is not a leftmost prefix. Always 回表.
        pred = set(equals) | set(ranges)
        for name, spec in self.secondaries.items():
            cols = spec["columns"]
            if pred & set(cols):
                # If the first column is not in the predicate, this is not a
                # real prefix — the naive planner still "uses the index"
                # by walking the whole leaf chain and filtering.
                leftmost_ok = bool(cols) and cols[0] in pred
                start, end = (None, None)
                prefix = []
                if leftmost_ok:
                    saw_range = False
                    for c in cols:
                        if c in equals and not saw_range:
                            prefix.append(c)
                            continue
                        if c in ranges and not saw_range:
                            prefix.append(c)
                            saw_range = True
                            continue
                        break
                    start, end = self._bounds(cols, equals, ranges, prefix)
                    kind = "search"
                else:
                    kind = "scan"
                    start, end = None, None
                residual = [c for c in pred if c not in prefix]
                explain = (
                    f"{'SEARCH' if kind == 'search' else 'SCAN'} SECONDARY {name} "
                    f"({', '.join(cols)}); naive_any_column; ALWAYS 回表; "
                    f"residual=({','.join(residual) if residual else '-'})"
                )
                return Plan(
                    kind=kind,
                    index=name,
                    start_key=start,
                    end_key=end,
                    used_prefix=prefix,
                    covering=False,
                    residual_cols=residual,
                    explain=explain,
                )
        return Plan(
            kind="scan",
            index="pk",
            start_key=None,
            end_key=None,
            used_prefix=[],
            covering=False,
            residual_cols=list(pred),
            explain="SCAN PRIMARY (clustered order_id); naive fallback; residual all predicates",
        )

    def _bounds(self, columns, equals, ranges, used):
        if not used:
            return None, None
        width = len(columns)
        lo = []
        hi = []
        for c in columns:
            if c in used and c in equals:
                lo.append(equals[c])
                hi.append(equals[c])
            elif c in used and c in ranges:
                lo.append(ranges[c][0])
                hi.append(ranges[c][1])
            else:
                lo.append(NEG_INF)
                hi.append(POS_INF)
        return tuple(lo[:width]), tuple(hi[:width])

    def execute(self, plan: Plan, equals: dict, ranges: dict, select: list) -> ExecResult:
        self.reset_stats()
        bookmark_lookups = 0
        t0 = time.perf_counter()

        def project(row):
            return {c: row[c] for c in select}

        def residual_row(row):
            return self._row_matches(row, equals, ranges)

        rows = []
        if plan.index == "pk":
            tree = self.pk
            if plan.kind == "search":
                it = tree.range_scan(plan.start_key, plan.end_key)
            else:
                it = tree.full_scan()
            for _k, payload in it:
                row = payload
                if residual_row(row):
                    rows.append(project(row))
        else:
            spec = self.secondaries[plan.index]
            tree = spec["tree"]
            cols = spec["columns"]
            if plan.kind == "search":
                it = tree.range_scan(plan.start_key, plan.end_key)
            else:
                it = tree.full_scan()
            for key, extra in it:
                key_map = {c: key[i] for i, c in enumerate(cols)}
                # Residual predicates that can be checked from the index tuple
                # still count as examined (already counted by the tree).
                probe = dict(key_map)
                probe.update(extra)
                if not residual_row(probe):
                    continue
                if plan.covering:
                    row = probe
                else:
                    pk_key = (key_map["order_id"],)
                    found = self.pk.search(pk_key)
                    bookmark_lookups += 1
                    if found is None:
                        raise RuntimeError("bookmark miss")
                    row = found
                rows.append(project(row))

        elapsed = (time.perf_counter() - t0) * 1000.0
        # pages_read / rows_examined are summed across trees touched
        pages_read = self.pk.stats.pages_read
        rows_examined = self.pk.stats.rows_examined
        for spec in self.secondaries.values():
            pages_read += spec["tree"].stats.pages_read
            rows_examined += spec["tree"].stats.rows_examined
        return ExecResult(
            rows=rows,
            plan=plan,
            pages_read=pages_read,
            rows_examined=rows_examined,
            bookmark_lookups=bookmark_lookups,
            elapsed_ms=round(elapsed, 3),
            tree_stats=self.snapshot_stats(),
        )


def build_table(index_cols_by_name: dict, split_mode: str, rows=None) -> OrderTable:
    table = OrderTable(split_mode=split_mode)
    for name, cols in index_cols_by_name.items():
        table.add_index(name, cols)
    if rows is None:
        rows = generate_orders()
    for r in rows:
        table.insert(r)
    return table


def expected_q1(rows=None):
    if rows is None:
        rows = generate_orders()
    out = []
    for r in rows:
        if r["user_id"] == Q_USER and r["status"] == Q_STATUS and Q_LO <= r["created_at"] <= Q_HI:
            out.append(r)
    return out


# ---------------------------------------------------------------------------
# sqlite3 confirmation lab (EXPLAIN QUERY PLAN). Same 2000 rows.
# ---------------------------------------------------------------------------

def _sqlite_explain(conn, sql, params):
    cur = conn.execute("EXPLAIN QUERY PLAN " + sql, params)
    lines = []
    for rec in cur.fetchall():
        # SQLite 3.x: selectid, order, from, detail
        lines.append(rec[-1] if not isinstance(rec[-1], tuple) else str(rec))
    return lines


def run_sqlite_lab(rows=None):
    if rows is None:
        rows = generate_orders()
    conn = sqlite3.connect(":memory:")
    conn.execute(
        """
        CREATE TABLE orders (
            order_id INTEGER PRIMARY KEY,
            user_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            amount INTEGER NOT NULL
        )
        """
    )
    conn.executemany(
        "INSERT INTO orders(order_id, user_id, status, created_at, amount) VALUES (?,?,?,?,?)",
        [(r["order_id"], r["user_id"], r["status"], r["created_at"], r["amount"]) for r in rows],
    )
    q = (
        "SELECT order_id, amount FROM orders "
        "WHERE user_id = ? AND status = ? AND created_at BETWEEN ? AND ?"
    )
    params = (Q_USER, Q_STATUS, Q_LO, Q_HI)
    plan_no_idx = _sqlite_explain(conn, q, params)
    cur = conn.execute(q, params)
    rows_no_idx = cur.fetchall()

    conn.execute(
        "CREATE INDEX idx_wrong ON orders(created_at, user_id, status)"
    )
    plan_wrong = _sqlite_explain(conn, q, params)

    conn.execute("DROP INDEX idx_wrong")
    conn.execute(
        "CREATE INDEX idx_safe ON orders(user_id, status, created_at)"
    )
    plan_safe = _sqlite_explain(conn, q, params)
    cur = conn.execute(q, params)
    rows_safe = cur.fetchall()

    # Covering: amount is in the index, so SQLite can skip the table.
    q_cover = (
        "SELECT amount FROM orders WHERE user_id = ? AND status = ?"
    )
    params_cover = (Q_USER, Q_STATUS)
    plan_uncovered = _sqlite_explain(conn, q_cover, params_cover)
    q_status = "SELECT order_id FROM orders WHERE status = ?"
    plan_status_before_cover = _sqlite_explain(conn, q_status, (Q_STATUS,))
    conn.execute(
        "CREATE INDEX idx_cover ON orders(user_id, status, amount)"
    )
    plan_covered = _sqlite_explain(conn, q_cover, params_cover)

    # Status-only cannot SEARCH a (user_id, ...) prefix. After idx_cover
    # exists SQLite may still SCAN that covering index — "using an index"
    # is not the same as a prefix search.
    plan_status = _sqlite_explain(conn, q_status, (Q_STATUS,))

    conn.close()
    return {
        "plan_no_index": plan_no_idx,
        "plan_wrong_order": plan_wrong,
        "plan_safe": plan_safe,
        "plan_uncovered": plan_uncovered,
        "plan_covered": plan_covered,
        "plan_status_only": plan_status,
        "plan_status_only_before_cover": plan_status_before_cover,
        "result_count": len(rows_safe),
        "results_match": rows_no_idx == rows_safe,
    }


def run_experiments():
    rows = generate_orders()
    gold_q1 = expected_q1(rows)
    gold_ids = sorted(r["order_id"] for r in gold_q1)
    gold_q1_count = len(gold_q1)

    equals = {"user_id": Q_USER, "status": Q_STATUS}
    ranges = {"created_at": (Q_LO, Q_HI)}
    select_q1 = ["order_id", "user_id", "status", "created_at"]

    # --- 1. column order / leftmost prefix ---
    t_safe = build_table({"idx_ust": ["user_id", "status", "created_at"]}, "safe", rows)
    t_wrong = build_table({"idx_tus": ["created_at", "user_id", "status"]}, "safe", rows)
    # naive planner on the CORRECT index still always 回表; also build a
    # table whose only index has the wrong leading column, planned naively.
    plan_safe = t_safe.plan_safe(equals, ranges, select_q1)
    exec_safe = t_safe.execute(plan_safe, equals, ranges, select_q1)
    plan_wrong = t_wrong.plan_safe(equals, ranges, select_q1)
    exec_wrong = t_wrong.execute(plan_wrong, equals, ranges, select_q1)
    plan_naive = t_wrong.plan_naive(equals, ranges, select_q1)
    exec_naive = t_wrong.execute(plan_naive, equals, ranges, select_q1)

    safe_ids = sorted(r["order_id"] for r in exec_safe.rows)
    wrong_ids = sorted(r["order_id"] for r in exec_wrong.rows)
    naive_ids = sorted(r["order_id"] for r in exec_naive.rows)

    # status-only: safe will not use (user_id, status, created_at)
    st_equals = {"status": Q_STATUS}
    st_select = ["order_id"]
    plan_st_safe = t_safe.plan_safe(st_equals, {}, st_select)
    exec_st_safe = t_safe.execute(plan_st_safe, st_equals, {}, st_select)
    plan_st_naive = t_safe.plan_naive(st_equals, {}, st_select)
    exec_st_naive = t_safe.execute(plan_st_naive, st_equals, {}, st_select)
    paid_count = sum(1 for r in rows if r["status"] == Q_STATUS)

    # gap: user_id + created_at, status in the middle of the index
    gap_eq = {"user_id": Q_USER}
    gap_rg = {"created_at": (Q_LO, Q_HI)}
    plan_gap = t_safe.plan_safe(gap_eq, gap_rg, ["order_id"])
    exec_gap = t_safe.execute(plan_gap, gap_eq, gap_rg, ["order_id"])
    user_count = sum(1 for r in rows if r["user_id"] == Q_USER)

    prefix = {
        "gold_count": gold_q1_count,
        "safe_explain": exec_safe.plan.explain,
        "safe_examined": exec_safe.rows_examined,
        "safe_pages": exec_safe.pages_read,
        "safe_ms": exec_safe.elapsed_ms,
        "safe_hits": len(exec_safe.rows),
        "wrong_explain": exec_wrong.plan.explain,
        "wrong_examined": exec_wrong.rows_examined,
        "wrong_pages": exec_wrong.pages_read,
        "wrong_ms": exec_wrong.elapsed_ms,
        "wrong_hits": len(exec_wrong.rows),
        "naive_explain": exec_naive.plan.explain,
        "naive_examined": exec_naive.rows_examined,
        "naive_pages": exec_naive.pages_read,
        "naive_hits": len(exec_naive.rows),
        "ids_match": safe_ids == gold_ids == wrong_ids == naive_ids,
        "status_only_safe_explain": exec_st_safe.plan.explain,
        "status_only_safe_examined": exec_st_safe.rows_examined,
        "status_only_naive_explain": exec_st_naive.plan.explain,
        "status_only_naive_examined": exec_st_naive.rows_examined,
        "paid_count": paid_count,
        "gap_explain": exec_gap.plan.explain,
        "gap_examined": exec_gap.rows_examined,
        "gap_hits": len(exec_gap.rows),
        "user_count": user_count,
    }

    # --- 2. covering vs 回表 ---
    # Same predicates, select amount. Non-covering index vs covering index.
    t_nc = build_table({"idx_us": ["user_id", "status"]}, "safe", rows)
    t_cv = build_table({"idx_usa": ["user_id", "status", "amount"]}, "safe", rows)
    eq_c = {"user_id": Q_USER, "status": Q_STATUS}
    sel_c = ["order_id", "amount"]
    plan_nc_safe = t_nc.plan_safe(eq_c, {}, sel_c)
    exec_nc = t_nc.execute(plan_nc_safe, eq_c, {}, sel_c)
    plan_cv_safe = t_cv.plan_safe(eq_c, {}, sel_c)
    exec_cv = t_cv.execute(plan_cv_safe, eq_c, {}, sel_c)
    # naive planner on the covering index still 回表
    plan_cv_naive = t_cv.plan_naive(eq_c, {}, sel_c)
    exec_cv_naive = t_cv.execute(plan_cv_naive, eq_c, {}, sel_c)
    cover_gold = [r for r in rows if r["user_id"] == Q_USER and r["status"] == Q_STATUS]
    covering = {
        "hits": len(exec_cv.rows),
        "gold_hits": len(cover_gold),
        "ids_match": sorted(r["order_id"] for r in exec_cv.rows)
        == sorted(r["order_id"] for r in exec_nc.rows)
        == sorted(r["order_id"] for r in exec_cv_naive.rows)
        == sorted(r["order_id"] for r in cover_gold),
        "noncover_explain": exec_nc.plan.explain,
        "noncover_lookups": exec_nc.bookmark_lookups,
        "noncover_pages": exec_nc.pages_read,
        "noncover_examined": exec_nc.rows_examined,
        "noncover_ms": exec_nc.elapsed_ms,
        "cover_explain": exec_cv.plan.explain,
        "cover_lookups": exec_cv.bookmark_lookups,
        "cover_pages": exec_cv.pages_read,
        "cover_examined": exec_cv.rows_examined,
        "cover_ms": exec_cv.elapsed_ms,
        "naive_explain": exec_cv_naive.plan.explain,
        "naive_lookups": exec_cv_naive.bookmark_lookups,
        "naive_pages": exec_cv_naive.pages_read,
        "naive_examined": exec_cv_naive.rows_examined,
        "naive_ms": exec_cv_naive.elapsed_ms,
    }

    # --- 3. selectivity / page split / write amplification ---
    # Rebuild stats from a fresh insert (write_cost is cumulative from build).
    def _cost_for(indexes, split_mode):
        t = build_table(indexes, split_mode, rows)
        return t.write_cost()

    cost_pk = _cost_for({}, "safe")
    cost_one = _cost_for({"idx_ust": ["user_id", "status", "created_at"]}, "safe")
    cost_three = _cost_for(
        {
            "idx_ust": ["user_id", "status", "created_at"],
            "idx_status": ["status"],
            "idx_amount": ["amount"],
        },
        "safe",
    )
    cost_naive_split = _cost_for({}, "naive")
    cost_safe_split = cost_pk

    # Low-selectivity "use the status index" vs high-selectivity user_id.
    t_sel = build_table(
        {"idx_status": ["status"], "idx_user": ["user_id"]},
        "safe",
        rows,
    )
    plan_by_status = t_sel.plan_safe({"status": Q_STATUS}, {}, ["order_id"])
    exec_by_status = t_sel.execute(plan_by_status, {"status": Q_STATUS}, {}, ["order_id"])
    plan_by_user = t_sel.plan_safe({"user_id": Q_USER}, {}, ["order_id"])
    exec_by_user = t_sel.execute(plan_by_user, {"user_id": Q_USER}, {}, ["order_id"])

    write = {
        "max_keys": MAX_KEYS,
        "n_rows": len(rows),
        "pk_only": cost_pk,
        "one_secondary": cost_one,
        "three_secondaries": cost_three,
        "naive_split_pk": cost_naive_split,
        "safe_split_pk": cost_safe_split,
        "status_explain": exec_by_status.plan.explain,
        "status_examined": exec_by_status.rows_examined,
        "status_hits": len(exec_by_status.rows),
        "status_pages": exec_by_status.pages_read,
        "user_explain": exec_by_user.plan.explain,
        "user_examined": exec_by_user.rows_examined,
        "user_hits": len(exec_by_user.rows),
        "user_pages": exec_by_user.pages_read,
        "paid_count": paid_count,
        "user_count": user_count,
    }

    sqlite = run_sqlite_lab(rows)
    return {
        "n_rows": len(rows),
        "q1": {"user_id": Q_USER, "status": Q_STATUS, "created_at": [Q_LO, Q_HI]},
        "prefix": prefix,
        "covering": covering,
        "write": write,
        "sqlite": sqlite,
    }


if __name__ == "__main__":
    import json
    import os

    data = run_experiments()
    path = os.path.join(os.path.dirname(__file__), "results.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(json.dumps(data, ensure_ascii=False, indent=2))
