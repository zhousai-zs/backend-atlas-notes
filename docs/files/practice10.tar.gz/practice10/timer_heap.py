#!/usr/bin/env python3
# 最小堆定时任务队列：按到期时间取出。

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple


@dataclass(order=True)
class Task:
    # 比较时只看 due；name/payload 不参与比较。
    due: int
    name: str = field(compare=False)
    payload: Any = field(default=None, compare=False)


class TimerMinHeap:
    def __init__(self) -> None:
        self._a: List[Task] = []

    def __len__(self) -> int:
        return len(self._a)

    def peek(self) -> Optional[Task]:
        return self._a[0] if self._a else None

    def push(self, task: Task) -> None:
        self._a.append(task)
        self._sift_up(len(self._a) - 1)

    def pop(self) -> Optional[Task]:
        if not self._a:
            return None
        if len(self._a) == 1:
            return self._a.pop()
        top = self._a[0]
        self._a[0] = self._a.pop()
        self._sift_down(0)
        return top

    def as_array_names(self) -> List[Tuple[int, str]]:
        # 暴露内部数组，用于证明「不是已排序」。
        return [(t.due, t.name) for t in self._a]

    def _sift_up(self, i: int) -> None:
        a = self._a
        while i > 0:
            p = (i - 1) // 2
            if a[p] <= a[i]:
                break
            a[p], a[i] = a[i], a[p]
            i = p

    def _sift_down(self, i: int) -> None:
        a = self._a
        n = len(a)
        while True:
            l, r = 2 * i + 1, 2 * i + 2
            best = i
            if l < n and a[l] < a[best]:
                best = l
            if r < n and a[r] < a[best]:
                best = r
            if best == i:
                break
            a[i], a[best] = a[best], a[i]
            i = best


def demo() -> None:
    # 模拟公众号后台：插入顺序乱序，取出必须按 due 升序
    jobs = [
        Task(due=1730000005, name="群发图文A", payload={"appid": "wx1"}),
        Task(due=1730000001, name="回调重试", payload={"msgid": "m42"}),
        Task(due=1730000003, name="刷新token", payload={"appid": "wx1"}),
        Task(due=1730000002, name="延迟模板消息", payload={"openid": "oABC"}),
        Task(due=1730000004, name="清理过期会话", payload=None),
    ]

    heap = TimerMinHeap()
    print("=== 插入（乱序）===")
    for t in jobs:
        heap.push(t)
        print(f"  push due={t.due} {t.name}")
        print(f"    内部数组: {heap.as_array_names()}")

    print("\n=== 验证：内部数组通常不是按 due 全序 ===")
    arr = heap.as_array_names()
    dues = [d for d, _ in arr]
    print(f"  内部 dues: {dues}")
    print(f"  是否已排序: {dues == sorted(dues)}")

    print("\n=== 依次 pop（删除堆顶）===")
    got = []
    while len(heap):
        t = heap.pop()
        assert t is not None
        got.append(t.due)
        print(f"  pop due={t.due} {t.name}")

    expect = sorted(j.due for j in jobs)
    print("\n=== 校验删除顺序 ===")
    print(f"  得到: {got}")
    print(f"  期望: {expect}")
    assert got == expect, "pop 顺序必须按 due 升序"
    print("  OK: 插入乱序，删除（取出）按到期时间有序。")


if __name__ == "__main__":
    demo()
