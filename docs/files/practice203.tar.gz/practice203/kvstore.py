"""Tiny durable KV used to verify milestones. Not a production cluster."""
from __future__ import annotations

import json
import os
from pathlib import Path


class WalKv:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data: dict[str, str] = {}
        self._replay()

    def _replay(self) -> None:
        self.data = {}
        if not self.path.exists():
            return
        with self.path.open() as f:
            for line in f:
                rec = json.loads(line)
                self.data[rec["k"]] = rec["v"]

    def set(self, key: str, value: str) -> None:
        rec = json.dumps({"k": key, "v": value}, ensure_ascii=False)
        with self.path.open("a") as f:
            f.write(rec + "\n")
            f.flush()
            os.fsync(f.fileno())
        self.data[key] = value

    def get(self, key: str) -> str | None:
        return self.data.get(key)
