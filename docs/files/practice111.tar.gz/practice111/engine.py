#!/usr/bin/env python3
"""In-process teaching backup/restore engine for g-recovery.

This is not RocksDB, not Redis, and not a network service. It models a
subset of RocksDB BackupEngine: CreateNewBackup, VerifyBackup,
RestoreDBFromBackup, PurgeOldBackups, file sharing for incremental
backups, and size-vs-checksum verification. Teaching SST files are
JSON payloads with a CRC32, not RocksDB block-based tables. There is
no Checkpoint object, no Env/FileSystem abstraction, no rate limiter,
no backup_env, no multi-thread copy, no blob files, and no real
MANIFEST log format.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import zlib
from dataclasses import dataclass, field
from typing import Any, Optional


# --------------------------------------------------------------------------- Status


class Status:
    """Teaching stand-in for rocksdb::Status / IOStatus."""

    def __init__(self, code: str = "ok", message: str = "", value: Optional[str] = None) -> None:
        self.code = code
        self.message = message
        self.value = value

    def ok(self) -> bool:
        return self.code == "ok"

    def IsNotFound(self) -> bool:
        return self.code == "not_found"

    def IsCorruption(self) -> bool:
        return self.code == "corruption"

    def IsInvalidArgument(self) -> bool:
        return self.code == "invalid_argument"

    def IsIncomplete(self) -> bool:
        return self.code == "incomplete"

    def ToString(self) -> str:
        if self.code == "ok":
            return "OK"
        if self.message:
            return f"{self.code}: {self.message}"
        return self.code

    @staticmethod
    def OK(value: Optional[str] = None) -> "Status":
        return Status("ok", value=value)

    @staticmethod
    def NotFound(message: str = "") -> "Status":
        return Status("not_found", message)

    @staticmethod
    def Corruption(message: str = "") -> "Status":
        return Status("corruption", message)

    @staticmethod
    def InvalidArgument(message: str = "") -> "Status":
        return Status("invalid_argument", message)

    @staticmethod
    def Incomplete(message: str = "") -> "Status":
        return Status("incomplete", message)

    @staticmethod
    def IOError(message: str = "") -> "Status":
        return Status("io_error", message)


# --------------------------------------------------------------------------- durable files (teaching fsync)


class DurableFile:
    """A file with a visible view and a last-synced prefix.

    Reads in the same process see the visible bytes. power_loss() reverts
    each file to its last fsync, which is how the lesson models
    BackupEngineOptions.sync=false after a machine crash.
    """

    def __init__(self) -> None:
        self.visible = b""
        self.synced = b""

    def write(self, data: bytes, sync: bool) -> None:
        self.visible = data
        if sync:
            self.synced = data

    def append(self, data: bytes, sync: bool) -> None:
        self.visible += data
        if sync:
            self.synced = self.visible

    def fsync(self) -> None:
        self.synced = self.visible


class DurableFS:
    def __init__(self) -> None:
        self.files: dict[str, DurableFile] = {}

    def write_file(self, path: str, data: bytes, sync: bool) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        # Materialize the visible view on the real filesystem so Open/Restore
        # can use ordinary file reads. power_loss() rewrites from .synced.
        rec = self.files.get(path) or DurableFile()
        rec.write(data, sync)
        self.files[path] = rec
        with open(path, "wb") as fh:
            fh.write(rec.visible)
        if sync:
            fh_sync(path)

    def delete(self, path: str) -> None:
        self.files.pop(path, None)
        if os.path.exists(path):
            os.remove(path)

    def power_loss(self) -> None:
        """Drop unsynced bytes and restore the last fsync image."""
        gone = []
        for path, rec in list(self.files.items()):
            if rec.synced == b"" and rec.visible != b"":
                # never fsynced: the file disappears after a crash
                if os.path.exists(path):
                    os.remove(path)
                gone.append(path)
            elif rec.synced != rec.visible:
                with open(path, "wb") as fh:
                    fh.write(rec.synced)
                rec.visible = rec.synced
        for path in gone:
            self.files.pop(path, None)

    def forget(self, path: str) -> None:
        self.files.pop(path, None)


def fh_sync(path: str) -> None:
    with open(path, "rb") as fh:
        os.fsync(fh.fileno())
    parent = os.path.dirname(path) or "."
    try:
        fd = os.open(parent, os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def file_crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def crc_hex(data: bytes) -> str:
    return f"{file_crc32(data):08x}"


# --------------------------------------------------------------------------- KV engine (SST + WAL)


def _atomic_write(path: str, data: bytes, sync: bool, fs: Optional[DurableFS] = None) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if fs is not None:
        fs.write_file(path, data, sync)
        return
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        if sync:
            os.fsync(fh.fileno())
    os.replace(tmp, path)
    if sync:
        fh_sync(path)


@dataclass
class LiveFile:
    name: str
    kind: str  # sst | manifest | current | options | wal
    size: int
    crc32: int
    path: str


class KVEngine:
    """A tiny durable KV used as the source and target of backups.

    Writes go to a memtable and a WAL. flush() builds an immutable teaching
    SST and updates CURRENT + MANIFEST. Recovery replays SST files in
    MANIFEST order, then the WAL. This is not RocksDB's LSM.
    """

    def __init__(self, db_dir: str, wal_dir: Optional[str] = None, sync: bool = True) -> None:
        self.db_dir = db_dir
        self.wal_dir = wal_dir or db_dir
        self.sync = sync
        self.memtable: dict[str, Optional[str]] = {}
        self.data: dict[str, str] = {}
        self.manifest_files: list[str] = []  # SST names in apply order
        self.next_file_number = 1
        self.wal_seq = 0
        self.wal_name = "000001.log"
        self.deletions_disabled = False
        self.pending_obsolete: list[str] = []
        os.makedirs(self.db_dir, exist_ok=True)
        os.makedirs(self.wal_dir, exist_ok=True)

    # -- open / close -------------------------------------------------------

    @classmethod
    def open(cls, db_dir: str, wal_dir: Optional[str] = None, sync: bool = True, create_if_missing: bool = True) -> tuple["KVEngine", Status]:
        wal_dir = wal_dir or db_dir
        os.makedirs(db_dir, exist_ok=True)
        os.makedirs(wal_dir, exist_ok=True)
        db = cls(db_dir, wal_dir, sync=sync)
        current = os.path.join(db_dir, "CURRENT")
        if not os.path.exists(current):
            if not create_if_missing:
                return db, Status.InvalidArgument("db does not exist")
            db._write_options()
            db._write_manifest()
            db._write_current()
            return db, Status.OK()
        try:
            manifest_name = open(current, "r", encoding="utf-8").read().strip()
            manifest_path = os.path.join(db_dir, manifest_name)
            man = json.loads(open(manifest_path, "r", encoding="utf-8").read())
        except (OSError, ValueError) as exc:
            return db, Status.Corruption(f"cannot read CURRENT/MANIFEST: {exc}")
        db.manifest_files = list(man.get("sst_files", []))
        db.next_file_number = int(man.get("next_file_number", 1))
        db.wal_name = str(man.get("wal_name", "000001.log"))
        db.data = {}
        for name in db.manifest_files:
            path = os.path.join(db_dir, name)
            st = db._apply_sst(path)
            if not st.ok():
                return db, st
        wal_path = os.path.join(db.wal_dir, db.wal_name)
        if os.path.exists(wal_path):
            st = db._replay_wal(wal_path)
            if not st.ok():
                return db, st
        return db, Status.OK()

    def close(self) -> None:
        if self.sync:
            self._flush_wal()

    # -- reads / writes -----------------------------------------------------

    def put(self, key: str, value: str) -> Status:
        return self._append_wal("put", key, value)

    def delete(self, key: str) -> Status:
        return self._append_wal("del", key, None)

    def get(self, key: str) -> Status:
        if key in self.memtable:
            val = self.memtable[key]
            if val is None:
                return Status.NotFound(key)
            return Status.OK(val)
        if key in self.data:
            return Status.OK(self.data[key])
        return Status.NotFound(key)

    def items(self) -> dict[str, str]:
        out = dict(self.data)
        for k, v in self.memtable.items():
            if v is None:
                out.pop(k, None)
            else:
                out[k] = v
        return out

    def key_count(self) -> int:
        return len(self.items())

    def flush(self) -> Status:
        if not self.memtable:
            return Status.OK()
        name = f"{self.next_file_number:06d}.sst"
        self.next_file_number += 1
        path = os.path.join(self.db_dir, name)
        payload = self._sst_bytes_from_memtable()
        _atomic_write(path, payload, self.sync)
        # Each flush writes an immutable delta SST (memtable only) and
        # appends it to MANIFEST. Older SSTs stay live, which is what lets
        # incremental backups share unchanged table files. compact() builds
        # a full snapshot and drops the superseded files.
        for k, v in self.memtable.items():
            if v is None:
                self.data.pop(k, None)
            else:
                self.data[k] = v
        self.memtable.clear()
        self.manifest_files.append(name)
        self._rotate_wal()
        self._write_manifest()
        self._write_current()
        return Status.OK()

    def compact(self) -> Status:
        """Write one snapshot SST and obsolete the previous table files."""
        if self.memtable:
            st = self.flush()
            if not st.ok():
                return st
        if len(self.manifest_files) <= 1 and not self.memtable:
            # still rewrite a snapshot so callers get a fresh file number
            if not self.data and not self.manifest_files:
                return Status.OK()
        name = f"{self.next_file_number:06d}.sst"
        self.next_file_number += 1
        path = os.path.join(self.db_dir, name)
        payload = self._sst_bytes_from_state()
        _atomic_write(path, payload, self.sync)
        old = list(self.manifest_files)
        self.manifest_files = [name]
        self._write_manifest()
        self._write_current()
        for prev in old:
            self._maybe_delete(os.path.join(self.db_dir, prev))
        return Status.OK()

    def disable_file_deletions(self) -> None:
        self.deletions_disabled = True

    def enable_file_deletions(self) -> None:
        self.deletions_disabled = False
        for path in list(self.pending_obsolete):
            if os.path.exists(path):
                os.remove(path)
        self.pending_obsolete.clear()

    def live_files(self, include_wal: bool) -> list[LiveFile]:
        files: list[LiveFile] = []
        for name in ("CURRENT", "OPTIONS"):
            path = os.path.join(self.db_dir, name)
            if os.path.exists(path):
                files.append(self._describe(path, name, "current" if name == "CURRENT" else "options"))
        current = open(os.path.join(self.db_dir, "CURRENT"), "r", encoding="utf-8").read().strip()
        man_path = os.path.join(self.db_dir, current)
        files.append(self._describe(man_path, current, "manifest"))
        for name in self.manifest_files:
            path = os.path.join(self.db_dir, name)
            files.append(self._describe(path, name, "sst"))
        if include_wal:
            wal_path = os.path.join(self.wal_dir, self.wal_name)
            if os.path.exists(wal_path) and os.path.getsize(wal_path) > 0:
                files.append(self._describe(wal_path, self.wal_name, "wal"))
        return files

    def _describe(self, path: str, name: str, kind: str) -> LiveFile:
        data = open(path, "rb").read()
        return LiveFile(name=name, kind=kind, size=len(data), crc32=file_crc32(data), path=path)

    # -- internals ----------------------------------------------------------

    def _sst_bytes_from_memtable(self) -> bytes:
        recs = [[k, self.memtable[k]] for k in sorted(self.memtable)]
        return self._pack_sst(recs)

    def _sst_bytes_from_state(self) -> bytes:
        merged = self.items()
        recs = [[k, merged[k]] for k in sorted(merged)]
        return self._pack_sst(recs)

    def _pack_sst(self, recs: list) -> bytes:
        body = json.dumps({"records": recs}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        header = {"magic": "TCHSST1", "crc32": file_crc32(body), "size": len(body)}
        return json.dumps(header, separators=(",", ":")).encode("utf-8") + b"\n" + body

    def _apply_sst(self, path: str) -> Status:
        try:
            raw = open(path, "rb").read()
            head, body = raw.split(b"\n", 1)
            header = json.loads(head.decode("utf-8"))
        except (OSError, ValueError) as exc:
            return Status.Corruption(f"sst unreadable: {path}: {exc}")
        if header.get("crc32") != file_crc32(body) or header.get("size") != len(body):
            return Status.Corruption(f"sst checksum mismatch: {os.path.basename(path)}")
        payload = json.loads(body.decode("utf-8"))
        for k, v in payload["records"]:
            if v is None:
                self.data.pop(k, None)
            else:
                self.data[k] = v
        return Status.OK()

    def _append_wal(self, op: str, key: str, value: Optional[str]) -> Status:
        rec = {"op": op, "key": key, "value": value}
        line = (json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        path = os.path.join(self.wal_dir, self.wal_name)
        os.makedirs(self.wal_dir, exist_ok=True)
        with open(path, "ab") as fh:
            fh.write(line)
            fh.flush()
            if self.sync:
                os.fsync(fh.fileno())
        if op == "put":
            assert value is not None
            self.memtable[key] = value
        else:
            self.memtable[key] = None
        self.wal_seq += 1
        return Status.OK()

    def _replay_wal(self, path: str) -> Status:
        try:
            text = open(path, "r", encoding="utf-8").read()
        except OSError as exc:
            return Status.IOError(str(exc))
        for line in text.splitlines():
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
            except ValueError as exc:
                return Status.Corruption(f"wal parse: {exc}")
            if rec["op"] == "put":
                self.memtable[rec["key"]] = rec["value"]
            else:
                self.memtable[rec["key"]] = None
        return Status.OK()

    def _flush_wal(self) -> None:
        path = os.path.join(self.wal_dir, self.wal_name)
        if os.path.exists(path):
            fh_sync(path)

    def _rotate_wal(self) -> None:
        old = os.path.join(self.wal_dir, self.wal_name)
        new_name = f"{self.next_file_number:06d}.log"
        self.next_file_number += 1
        self.wal_name = new_name
        # start a fresh WAL
        open(os.path.join(self.wal_dir, new_name), "ab").close()
        if os.path.exists(old):
            self._maybe_delete(old)

    def _maybe_delete(self, path: str) -> None:
        if not os.path.exists(path):
            return
        if self.deletions_disabled:
            self.pending_obsolete.append(path)
            return
        os.remove(path)

    def _write_options(self) -> None:
        payload = json.dumps({"engine": "teaching-kv", "sync": self.sync}, indent=2).encode("utf-8")
        _atomic_write(os.path.join(self.db_dir, "OPTIONS"), payload, self.sync)

    def _write_manifest(self) -> None:
        name = f"MANIFEST-{self.next_file_number:06d}"
        self.next_file_number += 1
        payload = json.dumps({
            "sst_files": self.manifest_files,
            "next_file_number": self.next_file_number,
            "wal_name": self.wal_name,
        }, indent=2).encode("utf-8")
        _atomic_write(os.path.join(self.db_dir, name), payload, self.sync)
        # drop older manifests unless deletions are disabled
        for fname in os.listdir(self.db_dir):
            if fname.startswith("MANIFEST-") and fname != name:
                self._maybe_delete(os.path.join(self.db_dir, fname))
        self._current_manifest = name

    def _write_current(self) -> None:
        name = getattr(self, "_current_manifest", None)
        if not name:
            # discover
            for fname in sorted(os.listdir(self.db_dir)):
                if fname.startswith("MANIFEST-"):
                    name = fname
        if not name:
            name = "MANIFEST-000001"
        _atomic_write(os.path.join(self.db_dir, "CURRENT"), (name + "\n").encode("utf-8"), self.sync)


# --------------------------------------------------------------------------- BackupEngine


@dataclass
class BackupEngineOptions:
    backup_dir: str
    share_table_files: bool = True
    share_files_with_checksum: bool = True
    sync: bool = True
    destroy_old_data: bool = False
    backup_log_files: bool = True


@dataclass
class BackupInfo:
    backup_id: int
    timestamp: float
    size: int
    number_files: int
    app_metadata: str = ""
    files: list[dict[str, Any]] = field(default_factory=list)
    corrupt: bool = False


class BackupEngine:
    """Teaching stand-in for rocksdb::BackupEngine / BackupEngineReadOnly."""

    def __init__(self, options: BackupEngineOptions, fs: Optional[DurableFS] = None, read_only: bool = False) -> None:
        self.options = options
        self.fs = fs or DurableFS()
        self.read_only = read_only
        self.backups: dict[int, dict[str, Any]] = {}
        self.corrupted: list[int] = []
        self.next_id = 1

    @classmethod
    def open(cls, options: BackupEngineOptions, fs: Optional[DurableFS] = None, read_only: bool = False) -> tuple["BackupEngine", Status]:
        os.makedirs(options.backup_dir, exist_ok=True)
        eng = cls(options, fs=fs, read_only=read_only)
        if options.destroy_old_data and not read_only:
            shutil.rmtree(options.backup_dir, ignore_errors=True)
            os.makedirs(options.backup_dir, exist_ok=True)
            for sub in ("meta", "private", "shared_checksum", "shared"):
                os.makedirs(os.path.join(options.backup_dir, sub), exist_ok=True)
            return eng, Status.OK()
        for sub in ("meta", "private", "shared_checksum", "shared"):
            os.makedirs(os.path.join(options.backup_dir, sub), exist_ok=True)
        meta_dir = os.path.join(options.backup_dir, "meta")
        ids = []
        if os.path.isdir(meta_dir):
            for name in os.listdir(meta_dir):
                if name.isdigit():
                    ids.append(int(name))
        ids.sort()
        for bid in ids:
            meta = _read_json(os.path.join(meta_dir, str(bid)))
            if meta is None:
                eng.corrupted.append(bid)
                continue
            # Open() essentially VerifyBackup without checksums.
            st = eng._verify_from_meta(meta, check_checksums=False)
            if st.ok():
                eng.backups[bid] = meta
                eng.next_id = max(eng.next_id, bid + 1)
            else:
                eng.corrupted.append(bid)
        if ids:
            eng.next_id = max(eng.next_id, max(ids) + 1)
        return eng, Status.OK()

    def CreateNewBackup(self, db: KVEngine, flush_before_backup: bool = False, app_metadata: str = "") -> tuple[Status, int]:
        if self.read_only:
            return Status.InvalidArgument("read-only"), 0
        if flush_before_backup:
            st = db.flush()
            if not st.ok():
                return st, 0
        db.disable_file_deletions()
        try:
            include_wal = self.options.backup_log_files and not flush_before_backup
            live = db.live_files(include_wal=include_wal)
            bid = self.next_id
            self.next_id += 1
            private = os.path.join(self.options.backup_dir, "private", str(bid))
            os.makedirs(private, exist_ok=True)
            recorded: list[dict[str, Any]] = []
            bytes_copied = 0
            files_copied = 0
            files_shared = 0
            for lf in live:
                dest, shared = self._dest_path(bid, lf)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                data = open(lf.path, "rb").read()
                already = (
                    os.path.exists(dest)
                    and os.path.getsize(dest) == lf.size
                    and file_crc32(open(dest, "rb").read()) == lf.crc32
                )
                copied = not (already and shared)
                if copied:
                    self.fs.write_file(dest, data, self.options.sync)
                    bytes_copied += len(data)
                    files_copied += 1
                else:
                    files_shared += 1
                recorded.append({
                    "name": lf.name,
                    "kind": lf.kind,
                    "size": lf.size,
                    "crc32": lf.crc32,
                    "backup_path": os.path.relpath(dest, self.options.backup_dir),
                    "shared": shared,
                    "copied": copied,
                })
            logical_size = sum(r["size"] for r in recorded)
            meta = {
                "backup_id": bid,
                "timestamp": time.time(),
                "app_metadata": app_metadata,
                "flush_before_backup": flush_before_backup,
                "share_table_files": self.options.share_table_files,
                "share_files_with_checksum": self.options.share_files_with_checksum,
                "files": recorded,
                "logical_size": logical_size,
                "bytes_copied": bytes_copied,
                "files_copied": files_copied,
                "files_shared_hit": files_shared,
            }
            meta_path = os.path.join(self.options.backup_dir, "meta", str(bid))
            payload = json.dumps(meta, ensure_ascii=False, indent=2).encode("utf-8")
            self.fs.write_file(meta_path, payload, self.options.sync)
            self.backups[bid] = meta
            return Status.OK(), bid
        finally:
            db.enable_file_deletions()

    def _dest_path(self, bid: int, lf: LiveFile) -> tuple[str, bool]:
        root = self.options.backup_dir
        if lf.kind == "sst" and self.options.share_table_files:
            if self.options.share_files_with_checksum:
                name = f"{os.path.splitext(lf.name)[0]}_{lf.size}_{lf.crc32:08x}.sst"
                return os.path.join(root, "shared_checksum", name), True
            # DEPRECATED: name only, can collide across histories
            return os.path.join(root, "shared", lf.name), True
        return os.path.join(root, "private", str(bid), lf.name), False

    def GetBackupInfo(self) -> list[BackupInfo]:
        out: list[BackupInfo] = []
        for bid in sorted(self.backups):
            m = self.backups[bid]
            out.append(BackupInfo(
                backup_id=bid,
                timestamp=float(m["timestamp"]),
                size=int(m["logical_size"]),
                number_files=len(m["files"]),
                app_metadata=str(m.get("app_metadata") or ""),
                files=list(m["files"]),
                corrupt=False,
            ))
        return out

    def GetCorruptedBackups(self) -> list[int]:
        return list(self.corrupted)

    def VerifyBackup(self, backup_id: int, verify_with_checksum: bool = False) -> Status:
        meta = self.backups.get(backup_id)
        if meta is None:
            # maybe on disk but marked corrupt, or missing
            path = os.path.join(self.options.backup_dir, "meta", str(backup_id))
            meta = _read_json(path)
            if meta is None:
                return Status.NotFound(f"backup {backup_id}")
        return self._verify_from_meta(meta, check_checksums=verify_with_checksum)

    def _verify_from_meta(self, meta: dict[str, Any], check_checksums: bool) -> Status:
        for info in meta.get("files", []):
            path = os.path.join(self.options.backup_dir, info["backup_path"])
            if not os.path.exists(path):
                return Status.Corruption(f"missing file {info['name']}")
            size = os.path.getsize(path)
            if size != int(info["size"]):
                return Status.Corruption(f"size mismatch {info['name']}: {size} != {info['size']}")
            if check_checksums:
                data = open(path, "rb").read()
                if file_crc32(data) != int(info["crc32"]):
                    return Status.Corruption(f"checksum mismatch {info['name']}")
        return Status.OK()

    def RestoreDBFromBackup(self, backup_id: int, db_dir: str, wal_dir: Optional[str] = None, check_checksums: bool = True) -> Status:
        """Restore into an isolated directory. Official restore always checks checksums.

        check_checksums=False is a teaching 'naive restore' hook, not an official option.
        """
        wal_dir = wal_dir or db_dir
        meta = self.backups.get(backup_id)
        if meta is None:
            path = os.path.join(self.options.backup_dir, "meta", str(backup_id))
            meta = _read_json(path)
            if meta is None:
                return Status.NotFound(f"backup {backup_id}")
        if check_checksums:
            st = self._verify_from_meta(meta, check_checksums=True)
            if not st.ok():
                return st
        os.makedirs(db_dir, exist_ok=True)
        os.makedirs(wal_dir, exist_ok=True)
        for info in meta["files"]:
            src = os.path.join(self.options.backup_dir, info["backup_path"])
            if not os.path.exists(src):
                return Status.Corruption(f"missing file {info['name']}")
            data = open(src, "rb").read()
            if check_checksums and file_crc32(data) != int(info["crc32"]):
                return Status.Corruption(f"checksum mismatch {info['name']}")
            dest_dir = wal_dir if info["kind"] == "wal" else db_dir
            dest = os.path.join(dest_dir, info["name"])
            _atomic_write(dest, data, sync=True)
        return Status.OK()

    def RestoreDBFromLatestBackup(self, db_dir: str, wal_dir: Optional[str] = None, check_checksums: bool = True) -> Status:
        if not self.backups:
            return Status.NotFound("no backup")
        latest = max(self.backups)
        return self.RestoreDBFromBackup(latest, db_dir, wal_dir, check_checksums=check_checksums)

    def PurgeOldBackups(self, num_backups_to_keep: int) -> Status:
        if self.read_only:
            return Status.InvalidArgument("read-only")
        ids = sorted(self.backups)
        drop = ids[: max(0, len(ids) - num_backups_to_keep)]
        for bid in drop:
            st = self.DeleteBackup(bid)
            if not st.ok():
                return st
        return Status.OK()

    def DeleteBackup(self, backup_id: int) -> Status:
        if self.read_only:
            return Status.InvalidArgument("read-only")
        meta = self.backups.pop(backup_id, None)
        if meta is None:
            return Status.NotFound(f"backup {backup_id}")
        private = os.path.join(self.options.backup_dir, "private", str(backup_id))
        if os.path.isdir(private):
            shutil.rmtree(private)
        meta_path = os.path.join(self.options.backup_dir, "meta", str(backup_id))
        if os.path.exists(meta_path):
            self.fs.delete(meta_path)
        self._gc_shared()
        return Status.OK()

    def _gc_shared(self) -> None:
        referenced = set()
        for meta in self.backups.values():
            for info in meta["files"]:
                referenced.add(os.path.join(self.options.backup_dir, info["backup_path"]))
        for folder in ("shared_checksum", "shared"):
            root = os.path.join(self.options.backup_dir, folder)
            if not os.path.isdir(root):
                continue
            for name in os.listdir(root):
                path = os.path.join(root, name)
                if os.path.isfile(path) and path not in referenced:
                    self.fs.delete(path)


def _read_json(path: str) -> Optional[dict[str, Any]]:
    if not os.path.exists(path):
        return None
    try:
        return json.loads(open(path, "r", encoding="utf-8").read())
    except (OSError, ValueError):
        return None


def naive_copy_db(src_dir: str, dst_dir: str, mid_hook=None) -> dict[str, Any]:
    """Copy whatever files are visible, optionally mutating the source mid-copy.

    This is not BackupEngine. It does not disable file deletions, does not
    freeze the live file set, and does not record checksums.
    """
    os.makedirs(dst_dir, exist_ok=True)
    names = [n for n in os.listdir(src_dir) if os.path.isfile(os.path.join(src_dir, n))]
    copied = []
    hook_at = max(0, len(names) // 2)
    for i, name in enumerate(names):
        if mid_hook is not None and i == hook_at:
            mid_hook()
        src = os.path.join(src_dir, name)
        if not os.path.exists(src):
            continue
        data = open(src, "rb").read()
        _atomic_write(os.path.join(dst_dir, name), data, sync=True)
        copied.append(name)
    # After the hook, CURRENT may reference a file we never copied.
    return {"listed": names, "copied": copied}


def fingerprint(items: dict[str, str]) -> str:
    blob = json.dumps(items, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def check_invariants(items: dict[str, str]) -> dict[str, Any]:
    """Application-level invariants for the teaching content-backend keys."""
    titles = {k: v for k, v in items.items() if k.startswith("article:") and k.endswith(":title")}
    views = {k: v for k, v in items.items() if k.startswith("article:") and k.endswith(":views")}
    broken: list[str] = []
    for k, v in titles.items():
        if not v:
            broken.append(f"empty title {k}")
    for k, v in views.items():
        title_key = k[: -len(":views")] + ":title"
        if title_key not in titles:
            broken.append(f"views without title {k}")
        try:
            if int(v) < 0:
                broken.append(f"negative views {k}")
        except ValueError:
            broken.append(f"non-integer views {k}")
    published = items.get("meta:published_count")
    title_count = len(titles)
    if published is not None and published != str(title_count):
        broken.append(f"published_count={published} title_count={title_count}")
    return {
        "ok": not broken,
        "key_count": len(items),
        "title_count": title_count,
        "views_count": len(views),
        "published_count": published,
        "fingerprint": fingerprint(items),
        "broken": broken,
        "sample_title": titles.get("article:001:title"),
    }
