#!/usr/bin/env python3
"""Acceptance checks for practice111 (backup, verify, restore)."""
from __future__ import annotations

import json
import os
import sys

from app import TITLE_V1, TITLE_V2, run_all_experiments


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    inc = data["full_incremental_retention"]
    _assert(inc["after_first"]["title_count"] == 200, "wave 1 has 200 titles")
    _assert(inc["after_first"]["sample_title"] == TITLE_V1, "wave 1 title")
    _assert(inc["after_first"]["invariants_ok"] is True, "wave 1 invariants")
    _assert(inc["incremental"]["second_shared_hit"] >= 1, "incremental backup 2 reused a shared SST")
    _assert(inc["incremental"]["second_copied_less_than_full"] is True, "incremental copied less than a full backup")
    _assert(inc["incremental"]["second_copied_less_than_logical"] is True, "backup 2 copied less than its logical size")
    _assert(inc["incremental"]["third_copied_less_than_logical"] is True, "backup 3 copied less than its logical size")
    _assert(inc["incremental"]["backup_2"]["bytes_copied"] < inc["full"]["backup_2"]["bytes_copied"], "numeric copy gap")
    _assert(inc["full"]["second_shared_hit"] == 0, "full backups do not share table files")
    ret = inc["retention"]
    _assert(ret["before_ids"] == [1, 2, 3], "three incremental backups exist before purge")
    _assert(ret["after_ids"] == [2, 3], "PurgeOldBackups(2) keeps the two newest")
    _assert(ret["restore_purged_not_found"] is True, "purged backup 1 cannot be restored")
    _assert(ret["restore_kept_ok"] is True, "kept backup 2 restores")
    _assert(ret["kept_matches_wave2"] is True, "restored backup 2 has 400 v1 titles")
    _assert(ret["bytes_dropped"] > 0, "purge frees some unique files")
    _assert(ret["purge_freed_less_than_backup1_logical"] is True, "shared SST still referenced is not freed")

    chk = data["checksum_and_consistency"]
    _assert(chk["backup_job_succeeded"] is True, "CreateNewBackup returned OK")
    _assert(chk["verify_before"]["size_only_ok"] is True, "size verify passes on a clean backup")
    _assert(chk["verify_before"]["with_checksum_ok"] is True, "checksum verify passes on a clean backup")
    _assert(chk["bit_rot"]["size_unchanged"] is True, "bit rot keeps the file size")
    _assert(chk["bit_rot"]["crc_changed"] is True, "bit rot changes the CRC")
    _assert(chk["verify_after_rot"]["size_only_ok"] is True, "size-only verify still passes after bit rot")
    _assert(chk["verify_after_rot"]["with_checksum_ok"] is False, "checksum verify detects bit rot")
    _assert(chk["backup_success_does_not_mean_usable"] is True, "job success is not usability")
    _assert(chk["official_restore_aborted"] is True, "official restore aborts on checksum mismatch")
    _assert(chk["naive_restore"]["copy_ok"] is True, "naive restore copies anyway")
    _assert(chk["naive_restore"]["open_ok"] is False, "naive restore is not a usable DB")
    _assert(chk["inconsistent_copy"]["open_ok"] is False, "torn directory copy does not open")
    _assert(chk["consistent_backup_restore"]["restore_ok"] is True, "consistent backup restores")
    _assert(chk["consistent_backup_restore"]["title_count"] == 100, "consistent restore has 100 titles")
    _assert(chk["consistent_backup_restore"]["sample_title"] == TITLE_V1, "consistent restore title")
    _assert(chk["consistent_backup_restore"]["restore_seconds"] > 0, "restore time recorded")

    dep = data["deprecated_shared_naming"]
    _assert(dep["deprecated_can_corrupt_earlier_backup"] is True, "name-only sharing can corrupt backup 2")
    _assert(dep["checksum_keeps_backup2_intact"] is True, "checksum naming keeps backup 2 intact")
    _assert(dep["checksum_naming"]["title_intact"] is True, "checksum path restores Weekly digest + 100 titles")
    _assert(dep["deprecated_shared_naming"]["title_intact"] is False, "deprecated path does not keep backup 2 intact")
    _assert(len(dep["deprecated_shared_naming"]["overlapping_shared_names"]) >= 1, "deprecated scheme reused a shared name")
    # Checksum naming may share the original, identical SST (same size and CRC
    # in the filename). That is incremental sharing, not an overwrite.
    _assert(dep["checksum_naming"]["fork_leaked_into_b2"] is False, "checksum naming does not leak the fork into backup 2")

    uns = data["unsynced_backup_crash"]
    _assert(uns["sync_true"]["newer_survived"] is True, "sync=true newer backup survives a crash")
    _assert(uns["sync_true"]["older_survived"] is True, "sync=true older backup survives")
    _assert(uns["sync_false"]["older_survived"] is True, "an already-synced older backup is not modified")
    _assert(uns["sync_false"]["newer_survived"] is False, "sync=false newer backup may be lost after a crash")

    drill = data["rpo_rto_drill"]
    _assert(drill["point_in_time"]["title_count"] == 100, "backup point is 100 titles")
    _assert(drill["point_in_time"]["sample_title"] == TITLE_V1, "backup point title is v1")
    _assert(drill["live_after_extra_writes"]["title_count"] == 120, "20 titles added after backup")
    _assert(drill["live_after_extra_writes"]["sample_title"] == TITLE_V2, "article 001 revised after backup")
    _assert(drill["backup_only"]["matches_backup_point"] is True, "backup-only restore lands on the backup point")
    _assert(drill["backup_only"]["rpo_writes"] == 21, "backup-only RPO is 21 logical writes")
    _assert(drill["backup_only"]["restore_point_title"] == TITLE_V1, "backup-only title")
    _assert(drill["backup_only"]["restore_seconds"] > 0, "backup-only restore time recorded")
    _assert(drill["backup_and_wal"]["matches_pre_disaster_live"] is True, "backup+WAL reaches the pre-disaster live state")
    _assert(drill["backup_and_wal"]["rpo_writes"] == 0, "backup+WAL RPO is 0")
    _assert(drill["backup_and_wal"]["restore_point_title"] == TITLE_V2, "backup+WAL title is revised")
    _assert(drill["backup_and_wal"]["view"]["title_count"] == 120, "backup+WAL has 120 titles")
    _assert(drill["backup_and_wal"]["restore_seconds"] > 0, "backup+WAL restore time recorded")

    rep = data["replica_is_not_backup"]
    _assert(rep["replica_before_matches_primary"] is True, "replica was caught up before the bug")
    _assert(rep["after_bug"]["replica_matches_primary"] is True, "bug was replicated")
    _assert(rep["after_bug"]["replica_invariants_ok"] is False, "replica invariants broken")
    _assert(rep["after_bug"]["empty_titles"] is True, "titles were emptied")
    _assert(rep["using_replica_as_restore"]["invariants_ok"] is False, "online replica cannot be used as a restore")
    _assert(rep["independent_backup_isolated_restore"]["invariants_ok"] is True, "isolated backup restore is clean")
    _assert(rep["independent_backup_isolated_restore"]["sample_title"] == TITLE_V1, "isolated restore has Weekly digest")
    _assert(rep["independent_backup_isolated_restore"]["matches_pre_bug_backup"] is True, "isolated restore matches the backup point")
    _assert(rep["independent_backup_isolated_restore"]["not_using_online_replica"] is True, "restore used an isolated directory")
    _assert(rep["replica_cannot_replace_independent_backup"] is True, "replica is not a substitute for backup")
    _assert(rep["independent_backup_isolated_restore"]["restore_seconds"] > 0, "drill recorded restore time")

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"inc_b2_copied={inc['incremental']['backup_2']['bytes_copied']} "
        f"full_b2_copied={inc['full']['backup_2']['bytes_copied']} "
        f"inc_b2_logical={inc['incremental']['backup_2']['logical_size']} "
        f"inc_b2_shared={inc['incremental']['second_shared_hit']} "
        f"inc_b3_copied={inc['incremental']['backup_3']['bytes_copied']} "
        f"purge_ids={ret['after_ids']} "
        f"purge_dropped={ret['bytes_dropped']} "
        f"size_only_after_rot={int(chk['verify_after_rot']['size_only_ok'])} "
        f"crc_after_rot={int(chk['verify_after_rot']['with_checksum_ok'])} "
        f"official_abort={int(chk['official_restore_aborted'])} "
        f"naive_open={int(chk['naive_restore']['open_ok'])} "
        f"torn_open={int(chk['inconsistent_copy']['open_ok'])} "
        f"consistent_titles={chk['consistent_backup_restore']['title_count']} "
        f"deprecated_corrupt={int(dep['deprecated_can_corrupt_earlier_backup'])} "
        f"checksum_intact={int(dep['checksum_keeps_backup2_intact'])} "
        f"unsync_newer={int(uns['sync_false']['newer_survived'])} "
        f"sync_newer={int(uns['sync_true']['newer_survived'])} "
        f"backup_only_rpo={drill['backup_only']['rpo_writes']} "
        f"backup_only_s={drill['backup_only']['restore_seconds']} "
        f"backup_wal_rpo={drill['backup_and_wal']['rpo_writes']} "
        f"backup_wal_s={drill['backup_and_wal']['restore_seconds']} "
        f"backup_only_title={drill['backup_only']['restore_point_title']!r} "
        f"replica_ok={int(rep['using_replica_as_restore']['invariants_ok'])} "
        f"isolated_ok={int(rep['independent_backup_isolated_restore']['invariants_ok'])} "
        f"isolated_s={rep['independent_backup_isolated_restore']['restore_seconds']}"
    )
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        sys.exit(1)
