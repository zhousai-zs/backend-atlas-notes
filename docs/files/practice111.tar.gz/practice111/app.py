#!/usr/bin/env python3
"""Experiments for practice111: backup, verify, restore, retention, RPO/RTO."""
from __future__ import annotations

import os
import shutil
import tempfile
import time
from typing import Any

from engine import (
    BackupEngine,
    BackupEngineOptions,
    DurableFS,
    KVEngine,
    Status,
    check_invariants,
    file_crc32,
    fingerprint,
    naive_copy_db,
)


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"
BUG_TITLE = ""  # empty title: breaks the published-article invariant


def _fresh(root: str, name: str) -> str:
    path = os.path.join(root, name)
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path, exist_ok=True)
    return path


def write_article(db: KVEngine, n: int, title: str, views: int = 0) -> Status:
    st = db.put(f"article:{n:03d}:title", title)
    if not st.ok():
        return st
    return db.put(f"article:{n:03d}:views", str(views))


def seed_articles(db: KVEngine, start: int, count: int, title: str, views: int = 0) -> None:
    for n in range(start, start + count):
        st = write_article(db, n, title, views)
        assert st.ok(), st.ToString()
    # published_count covers every title currently in the DB
    items = db.items()
    titles = sum(1 for k in items if k.endswith(":title"))
    st = db.put("meta:published_count", str(titles))
    assert st.ok(), st.ToString()


def open_restored(db_dir: str, wal_dir: str | None = None) -> tuple[KVEngine, Status]:
    return KVEngine.open(db_dir, wal_dir=wal_dir, create_if_missing=False)


def snapshot_view(db: KVEngine) -> dict[str, Any]:
    items = db.items()
    inv = check_invariants(items)
    return {
        "key_count": inv["key_count"],
        "title_count": inv["title_count"],
        "published_count": inv["published_count"],
        "sample_title": inv["sample_title"],
        "fingerprint": inv["fingerprint"],
        "invariants_ok": inv["ok"],
        "broken_count": len(inv["broken"]),
        "broken_sample": inv["broken"][:3],
    }


# --------------------------------------------------------------------------- 1. full / incremental / retention


def exp_full_incremental_retention(root: str) -> dict[str, Any]:
    db_dir = _fresh(root, "inc/db")
    inc_dir = _fresh(root, "inc/backup_shared")
    full_dir = _fresh(root, "inc/backup_full")

    db, st = KVEngine.open(db_dir)
    assert st.ok()
    seed_articles(db, 1, 200, TITLE_V1)
    db.flush()
    after_first = snapshot_view(db)

    inc_opts = BackupEngineOptions(backup_dir=inc_dir, share_table_files=True, share_files_with_checksum=True, sync=True)
    full_opts = BackupEngineOptions(backup_dir=full_dir, share_table_files=False, share_files_with_checksum=False, sync=True)
    inc, st = BackupEngine.open(inc_opts)
    assert st.ok()
    full, st = BackupEngine.open(full_opts)
    assert st.ok()

    st, inc1 = inc.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-1")
    assert st.ok()
    st, full1 = full.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-1")
    assert st.ok()
    inc_info1 = next(i for i in inc.GetBackupInfo() if i.backup_id == inc1)
    full_info1 = next(i for i in full.GetBackupInfo() if i.backup_id == full1)
    inc_meta1 = inc.backups[inc1]
    full_meta1 = full.backups[full1]

    seed_articles(db, 201, 200, TITLE_V1)
    db.flush()
    after_second = snapshot_view(db)

    st, inc2 = inc.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-2")
    assert st.ok()
    st, full2 = full.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-2")
    assert st.ok()
    inc_meta2 = inc.backups[inc2]
    full_meta2 = full.backups[full2]

    seed_articles(db, 401, 50, TITLE_V2)
    db.flush()
    st, inc3 = inc.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-3")
    assert st.ok()
    st, full3 = full.CreateNewBackup(db, flush_before_backup=True, app_metadata="wave-3")
    assert st.ok()
    inc_meta3 = inc.backups[inc3]
    full_meta3 = full.backups[full3]

    before_purge_ids = [i.backup_id for i in inc.GetBackupInfo()]
    before_purge_bytes = _backup_dir_bytes(inc_dir)
    st = inc.PurgeOldBackups(2)
    assert st.ok()
    after_purge_ids = [i.backup_id for i in inc.GetBackupInfo()]
    after_purge_bytes = _backup_dir_bytes(inc_dir)

    missing = inc.RestoreDBFromBackup(inc1, _fresh(root, "inc/restore_purged"))
    st_keep = inc.RestoreDBFromBackup(inc2, _fresh(root, "inc/restore_kept"))
    db_kept, st_open = open_restored(os.path.join(root, "inc/restore_kept"))
    assert st_open.ok(), st_open.ToString()
    kept_view = snapshot_view(db_kept)
    db_kept.close()

    return {
        "setup": "200 titles, flush, backup; +200 titles, flush, backup; +50 revised titles, flush, backup; PurgeOldBackups(2)",
        "after_first": after_first,
        "after_second": after_second,
        "incremental": {
            "backup_1": _meta_brief(inc_meta1),
            "backup_2": _meta_brief(inc_meta2),
            "backup_3": _meta_brief(inc_meta3),
            "second_copied_less_than_first": inc_meta2["bytes_copied"] < inc_meta1["bytes_copied"],
            "second_shared_hit": inc_meta2["files_shared_hit"],
            "second_copied_less_than_logical": inc_meta2["bytes_copied"] < inc_meta2["logical_size"],
            "second_copied_less_than_full": inc_meta2["bytes_copied"] < full_meta2["bytes_copied"],
            "third_copied_less_than_logical": inc_meta3["bytes_copied"] < inc_meta3["logical_size"],
        },
        "full": {
            "backup_1": _meta_brief(full_meta1),
            "backup_2": _meta_brief(full_meta2),
            "backup_3": _meta_brief(full_meta3),
            "second_shared_hit": full_meta2["files_shared_hit"],
        },
        "retention": {
            "before_ids": before_purge_ids,
            "after_ids": after_purge_ids,
            "purged_id": inc1,
            "kept_ids": after_purge_ids,
            "before_bytes": before_purge_bytes,
            "after_bytes": after_purge_bytes,
            "bytes_dropped": before_purge_bytes - after_purge_bytes,
            "restore_purged": missing.ToString(),
            "restore_purged_not_found": missing.IsNotFound(),
            "restore_kept_ok": st_keep.ok(),
            "kept_view": kept_view,
            "kept_matches_wave2": kept_view["title_count"] == 400 and kept_view["sample_title"] == TITLE_V1,
            "purge_freed_less_than_backup1_logical": (before_purge_bytes - after_purge_bytes) < inc_meta1["logical_size"],
        },
        "info_sizes": {
            "inc1_logical": inc_info1.size,
            "full1_logical": full_info1.size,
            "inc1_files": inc_info1.number_files,
        },
    }


def _meta_brief(meta: dict[str, Any]) -> dict[str, Any]:
    return {
        "backup_id": meta["backup_id"],
        "logical_size": meta["logical_size"],
        "bytes_copied": meta["bytes_copied"],
        "files_copied": meta["files_copied"],
        "files_shared_hit": meta["files_shared_hit"],
        "file_count": len(meta["files"]),
        "sst_files": [f["name"] for f in meta["files"] if f["kind"] == "sst"],
        "app_metadata": meta.get("app_metadata", ""),
    }


def _backup_dir_bytes(path: str) -> int:
    total = 0
    for dirpath, _, files in os.walk(path):
        for name in files:
            fp = os.path.join(dirpath, name)
            total += os.path.getsize(fp)
    return total


# --------------------------------------------------------------------------- 2. checksums and consistent backup


def exp_checksum_and_consistency(root: str) -> dict[str, Any]:
    db_dir = _fresh(root, "chk/db")
    bdir = _fresh(root, "chk/backup")
    db, st = KVEngine.open(db_dir)
    assert st.ok()
    seed_articles(db, 1, 100, TITLE_V1)
    db.flush()
    eng, st = BackupEngine.open(BackupEngineOptions(backup_dir=bdir, sync=True))
    assert st.ok()
    st, bid = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="clean")
    assert st.ok()
    job_succeeded = st.ok()

    size_ok = eng.VerifyBackup(bid, verify_with_checksum=False)
    crc_ok = eng.VerifyBackup(bid, verify_with_checksum=True)

    # Bit-rot a shared SST: flip one byte, keep the size unchanged.
    sst = next(f for f in eng.backups[bid]["files"] if f["kind"] == "sst")
    sst_path = os.path.join(bdir, sst["backup_path"])
    raw = bytearray(open(sst_path, "rb").read())
    original_crc = file_crc32(bytes(raw))
    # Flip a byte in the body (last byte is almost certainly payload).
    raw[-1] = raw[-1] ^ 0xFF
    open(sst_path, "wb").write(raw)
    flipped_crc = file_crc32(bytes(raw))
    size_after = os.path.getsize(sst_path)

    size_after_rot = eng.VerifyBackup(bid, verify_with_checksum=False)
    crc_after_rot = eng.VerifyBackup(bid, verify_with_checksum=True)

    # Official restore always checksums and must abort.
    isolated = _fresh(root, "chk/restore_official")
    official = eng.RestoreDBFromBackup(bid, isolated, check_checksums=True)

    # Teaching naive restore: skip checksums, copy files anyway.
    naive_dir = _fresh(root, "chk/restore_naive")
    naive = eng.RestoreDBFromBackup(bid, naive_dir, check_checksums=False)
    naive_open_db, naive_open = open_restored(naive_dir)
    naive_view = None
    if naive_open.ok():
        naive_view = snapshot_view(naive_open_db)
        naive_open_db.close()
    else:
        naive_view = {"open": naive_open.ToString(), "invariants_ok": False}

    # Inconsistent naive live copy: mid-copy flush, then pick up new CURRENT
    # without the new SST.
    live_dir = _fresh(root, "chk/live")
    live, st = KVEngine.open(live_dir)
    assert st.ok()
    seed_articles(live, 1, 80, TITLE_V1)
    live.flush()
    listed_before = sorted(os.listdir(live_dir))

    def mid_flush() -> None:
        seed_articles(live, 81, 20, TITLE_V2)
        live.flush()

    dst = _fresh(root, "chk/naive_copy")
    copy_info = naive_copy_db(live_dir, dst, mid_hook=mid_flush)
    # After the hook, CURRENT in the live DB points at a new MANIFEST / SST.
    # Copy the *new* CURRENT over the destination so the copy names files
    # it never actually took — the classic torn directory.
    shutil.copy2(os.path.join(live_dir, "CURRENT"), os.path.join(dst, "CURRENT"))
    new_manifest = open(os.path.join(live_dir, "CURRENT"), "r", encoding="utf-8").read().strip()
    if os.path.exists(os.path.join(live_dir, new_manifest)):
        shutil.copy2(os.path.join(live_dir, new_manifest), os.path.join(dst, new_manifest))
    torn_open_db, torn_open = open_restored(dst)
    torn_view = {"open": torn_open.ToString(), "ok": torn_open.ok()}
    if torn_open.ok():
        torn_view.update(snapshot_view(torn_open_db))
        torn_open_db.close()

    # A consistent backup taken after the same writes restores cleanly.
    cdir = _fresh(root, "chk/consistent_backup")
    ceng, st = BackupEngine.open(BackupEngineOptions(backup_dir=cdir, sync=True))
    assert st.ok()
    st, cid = ceng.CreateNewBackup(live, flush_before_backup=True)
    assert st.ok()
    cdst = _fresh(root, "chk/consistent_restore")
    t0 = time.perf_counter()
    cst = ceng.RestoreDBFromBackup(cid, cdst)
    consistent_restore_s = time.perf_counter() - t0
    cdb, cst_open = open_restored(cdst)
    consistent_view = snapshot_view(cdb) if cst_open.ok() else {"open": cst_open.ToString(), "invariants_ok": False}
    if cst_open.ok():
        cdb.close()

    return {
        "setup": "100 titles, backup job returns OK, then one SST byte is flipped in the backup directory",
        "backup_job_succeeded": job_succeeded,
        "backup_id": bid,
        "verify_before": {
            "size_only": size_ok.ToString(),
            "size_only_ok": size_ok.ok(),
            "with_checksum": crc_ok.ToString(),
            "with_checksum_ok": crc_ok.ok(),
        },
        "bit_rot": {
            "file": sst["name"],
            "size_unchanged": size_after == sst["size"],
            "size": size_after,
            "crc_before": original_crc,
            "crc_after": flipped_crc,
            "crc_changed": original_crc != flipped_crc,
        },
        "verify_after_rot": {
            "size_only": size_after_rot.ToString(),
            "size_only_ok": size_after_rot.ok(),
            "with_checksum": crc_after_rot.ToString(),
            "with_checksum_ok": crc_after_rot.ok(),
        },
        "backup_success_does_not_mean_usable": job_succeeded and size_after_rot.ok() and (not crc_after_rot.ok()),
        "official_restore": official.ToString(),
        "official_restore_aborted": official.IsCorruption(),
        "naive_restore": {
            "copy_status": naive.ToString(),
            "copy_ok": naive.ok(),
            "open": naive_open.ToString() if not naive_open.ok() else "OK",
            "open_ok": naive_open.ok(),
            "view": naive_view,
        },
        "inconsistent_copy": {
            "listed_before": listed_before,
            "copy": copy_info,
            "new_manifest": new_manifest,
            "open": torn_open.ToString(),
            "open_ok": torn_open.ok(),
            "view": torn_view,
        },
        "consistent_backup_restore": {
            "restore_ok": cst.ok() and cst_open.ok(),
            "restore_seconds": round(consistent_restore_s, 6),
            "view": consistent_view,
            "title_count": consistent_view.get("title_count"),
            "sample_title": consistent_view.get("sample_title"),
        },
    }


# --------------------------------------------------------------------------- 2b. deprecated shared naming


def exp_deprecated_shared_naming(root: str) -> dict[str, Any]:
    def run(with_checksum: bool, label: str) -> dict[str, Any]:
        db_dir = _fresh(root, f"share/{label}/db")
        bdir = _fresh(root, f"share/{label}/backup")
        db, st = KVEngine.open(db_dir)
        assert st.ok()
        seed_articles(db, 1, 50, TITLE_V1)
        db.flush()
        opts = BackupEngineOptions(
            backup_dir=bdir,
            share_table_files=True,
            share_files_with_checksum=with_checksum,
            sync=True,
        )
        eng, st = BackupEngine.open(opts)
        assert st.ok()
        st, b1 = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="v1")
        assert st.ok()
        seed_articles(db, 51, 50, TITLE_V2)
        db.flush()
        st, b2 = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="v2")
        assert st.ok()

        # Restore backup 1 (not latest) into a new history and keep writing.
        r1 = _fresh(root, f"share/{label}/restored_b1")
        st = eng.RestoreDBFromBackup(b1, r1)
        assert st.ok(), st.ToString()
        db1, st = open_restored(r1)
        assert st.ok(), st.ToString()
        # New SST will reuse the next file number from backup 1's MANIFEST,
        # which collides with backup 2's later SST number.
        seed_articles(db1, 1, 50, "forked-history-title")
        db1.flush()
        st, b3 = eng.CreateNewBackup(db1, flush_before_backup=True, app_metadata="fork")
        assert st.ok()
        db1.close()

        # Restore backup 2 (the one taken before the fork) and see if it is intact.
        r2 = _fresh(root, f"share/{label}/restored_b2")
        st = eng.RestoreDBFromBackup(b2, r2)
        open_st = None
        view = None
        if st.ok():
            db2, open_st = open_restored(r2)
            if open_st.ok():
                view = snapshot_view(db2)
                db2.close()
            else:
                view = {"open": open_st.ToString(), "invariants_ok": False}
        else:
            view = {"restore": st.ToString(), "invariants_ok": False}

        b2_files = [f["backup_path"] for f in eng.backups[b2]["files"] if f["kind"] == "sst"]
        b3_files = [f["backup_path"] for f in eng.backups[b3]["files"] if f["kind"] == "sst"]
        return {
            "share_files_with_checksum": with_checksum,
            "backup_ids": [b1, b2, b3],
            "b2_sst_paths": b2_files,
            "b3_sst_paths": b3_files,
            "overlapping_shared_names": sorted(set(b2_files) & set(b3_files)),
            "restore_b2": st.ToString(),
            "restore_b2_ok": st.ok() and (open_st.ok() if open_st is not None else False),
            "view": view,
            "title_intact": bool(view and view.get("sample_title") == TITLE_V1 and view.get("title_count") == 100),
            "fork_leaked_into_b2": bool(view and view.get("sample_title") == "forked-history-title"),
        }

    dangerous = run(False, "deprecated")
    safe = run(True, "checksum")
    return {
        "setup": "backup 1 then 2; restore 1, write a forked history, backup 3; restore backup 2",
        "deprecated_shared_naming": dangerous,
        "checksum_naming": safe,
        "deprecated_can_corrupt_earlier_backup": dangerous["fork_leaked_into_b2"] or (not dangerous["title_intact"]),
        "checksum_keeps_backup2_intact": safe["title_intact"],
    }


# --------------------------------------------------------------------------- 2c. sync=false crash


def exp_unsynced_backup_crash(root: str) -> dict[str, Any]:
    results = {}
    for sync in (True, False):
        label = "sync" if sync else "unsync"
        db_dir = _fresh(root, f"sync/{label}/db")
        bdir = _fresh(root, f"sync/{label}/backup")
        fs = DurableFS()
        db, st = KVEngine.open(db_dir, sync=True)
        assert st.ok()
        seed_articles(db, 1, 40, TITLE_V1)
        db.flush()
        eng, st = BackupEngine.open(BackupEngineOptions(backup_dir=bdir, sync=sync), fs=fs)
        assert st.ok()
        # First backup, then simulate a later unsynced backup + crash.
        st, first = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="synced-base")
        assert st.ok()
        # Make the first backup durable even in the unsync run, so we can
        # contrast "older synced backups survive" with "newer unsynced ones
        # may not". Official comment: if sync is false, previously synced
        # backups are not modified while creating a new one — we model that
        # by fsync'ing the first backup's files before the second write.
        if not sync:
            for path, rec in list(fs.files.items()):
                rec.fsync()
                if os.path.exists(path):
                    # already on disk
                    pass
        seed_articles(db, 41, 40, TITLE_V2)
        db.flush()
        st, second = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="newer")
        assert st.ok()
        fs.power_loss()
        # Re-open as a new BackupEngine, the way a process would after a crash.
        eng2, st = BackupEngine.open(BackupEngineOptions(backup_dir=bdir, sync=True), fs=DurableFS())
        assert st.ok()
        ids = [i.backup_id for i in eng2.GetBackupInfo()]
        corrupted = eng2.GetCorruptedBackups()
        results[label] = {
            "sync": sync,
            "created": [first, second],
            "valid_after_crash": ids,
            "corrupted_after_crash": corrupted,
            "newer_survived": second in ids,
            "older_survived": first in ids,
        }
    return {
        "setup": "two backups; power_loss drops unsynced bytes; re-open BackupEngine",
        "sync_true": results["sync"],
        "sync_false": results["unsync"],
    }


# --------------------------------------------------------------------------- 3. RPO / RTO / drill, and replica is not a backup


def exp_rpo_rto_drill(root: str) -> dict[str, Any]:
    db_dir = _fresh(root, "drill/db")
    bdir = _fresh(root, "drill/backup")
    wal_archive = _fresh(root, "drill/wal_archive")

    db, st = KVEngine.open(db_dir, sync=True)
    assert st.ok()
    seed_articles(db, 1, 100, TITLE_V1, views=3)
    db.flush()
    point_in_time = snapshot_view(db)

    eng, st = BackupEngine.open(BackupEngineOptions(backup_dir=bdir, sync=True, backup_log_files=True))
    assert st.ok()
    t_backup = time.perf_counter()
    st, bid = eng.CreateNewBackup(db, flush_before_backup=True, app_metadata="drill-pit")
    backup_seconds = time.perf_counter() - t_backup
    assert st.ok()

    # 21 writes after the backup: revise article 001 and add 20 articles.
    st = write_article(db, 1, TITLE_V2, views=8)
    assert st.ok()
    seed_articles(db, 101, 20, TITLE_V2, views=1)
    post_backup_writes = 1 + 20 * 2 + 1  # title+views for 001 already counted as 1 put*2? let's record explicitly
    # Be precise: write_article(1) = 2 puts; seed_articles 101-120 = 20*2 puts + 1 published_count; seed also rewrites published_count
    # For RPO we count logical operations the user cares about: 1 title revision + 20 new articles.
    rpo_logical_writes = 21
    live_after = snapshot_view(db)
    # Archive the post-backup WAL (isolated, not the online replica).
    wal_src = os.path.join(db_dir, db.wal_name)
    assert os.path.exists(wal_src), db.wal_name
    shutil.copy2(wal_src, os.path.join(wal_archive, db.wal_name))
    archived_wal_name = db.wal_name

    # Disaster: wipe the live directory.
    db.close()
    shutil.rmtree(db_dir)
    os.makedirs(db_dir, exist_ok=True)

    # Path A: restore backup only, into an isolated directory.
    only_dir = _fresh(root, "drill/restore_backup_only")
    t0 = time.perf_counter()
    st = eng.RestoreDBFromBackup(bid, only_dir)
    assert st.ok(), st.ToString()
    only_db, st = open_restored(only_dir)
    assert st.ok(), st.ToString()
    only_seconds = time.perf_counter() - t0
    only_view = snapshot_view(only_db)
    only_db.close()

    # Path B: restore backup + archived WAL into another isolated directory.
    both_dir = _fresh(root, "drill/restore_backup_and_wal")
    t0 = time.perf_counter()
    st = eng.RestoreDBFromBackup(bid, both_dir)
    assert st.ok(), st.ToString()
    # Drop the archived WAL next to the restored CURRENT so open() replays it.
    # The restored MANIFEST names the (empty, post-flush) WAL; replace by
    # copying the archived log into that name after rewriting CURRENT's wal,
    # or simply put the archived file and point MANIFEST at it.
    man_name = open(os.path.join(both_dir, "CURRENT"), "r", encoding="utf-8").read().strip()
    man_path = os.path.join(both_dir, man_name)
    import json
    man = json.loads(open(man_path, "r", encoding="utf-8").read())
    shutil.copy2(os.path.join(wal_archive, archived_wal_name), os.path.join(both_dir, archived_wal_name))
    man["wal_name"] = archived_wal_name
    open(man_path, "w", encoding="utf-8").write(json.dumps(man, indent=2))
    both_db, st = open_restored(both_dir)
    assert st.ok(), st.ToString()
    both_seconds = time.perf_counter() - t0
    both_view = snapshot_view(both_db)
    both_db.close()

    return {
        "setup": "backup 100 titles (Weekly digest); then revise article 001 and add 20 titles; wipe live DB; restore in isolated dirs",
        "backup_id": bid,
        "backup_seconds": round(backup_seconds, 6),
        "point_in_time": point_in_time,
        "live_after_extra_writes": live_after,
        "rpo_logical_writes": rpo_logical_writes,
        "backup_only": {
            "isolated_dir": "drill/restore_backup_only",
            "restore_seconds": round(only_seconds, 6),
            "view": only_view,
            "rpo_writes": rpo_logical_writes if only_view["title_count"] == 100 else None,
            "restore_point_title": only_view["sample_title"],
            "matches_backup_point": only_view["fingerprint"] == point_in_time["fingerprint"],
        },
        "backup_and_wal": {
            "isolated_dir": "drill/restore_backup_and_wal",
            "restore_seconds": round(both_seconds, 6),
            "view": both_view,
            "rpo_writes": 0 if both_view["fingerprint"] == live_after["fingerprint"] else None,
            "restore_point_title": both_view["sample_title"],
            "matches_pre_disaster_live": both_view["fingerprint"] == live_after["fingerprint"],
        },
    }


def exp_replica_is_not_backup(root: str) -> dict[str, Any]:
    primary_dir = _fresh(root, "repl/primary")
    replica_dir = _fresh(root, "repl/replica")
    bdir = _fresh(root, "repl/backup")

    primary, st = KVEngine.open(primary_dir)
    assert st.ok()
    replica, st = KVEngine.open(replica_dir)
    assert st.ok()

    def replicate() -> None:
        # Teaching "online replica": copy current items, not an independent backup.
        for k in list(replica.items()):
            replica.delete(k)
        for k, v in primary.items().items():
            replica.put(k, v)
        replica.flush()

    seed_articles(primary, 1, 80, TITLE_V1, views=2)
    primary.flush()
    replicate()
    eng, st = BackupEngine.open(BackupEngineOptions(backup_dir=bdir, sync=True))
    assert st.ok()
    st, bid = eng.CreateNewBackup(primary, flush_before_backup=True, app_metadata="before-bug")
    assert st.ok()
    before = snapshot_view(primary)
    replica_before = snapshot_view(replica)

    # A logic bug / bad deploy writes empty titles and a wrong published_count,
    # then the replica applies the same writes (logical replication).
    for n in range(1, 81):
        write_article(primary, n, BUG_TITLE, views=2)
    primary.put("meta:published_count", "80")
    primary.flush()
    replicate()
    after_bug_primary = snapshot_view(primary)
    after_bug_replica = snapshot_view(replica)

    # "Restore from the online replica" — there is nothing good left there.
    replica_as_restore = after_bug_replica

    isolated = _fresh(root, "repl/isolated_restore")
    t0 = time.perf_counter()
    st = eng.RestoreDBFromBackup(bid, isolated)
    assert st.ok(), st.ToString()
    rdb, st = open_restored(isolated)
    assert st.ok(), st.ToString()
    restore_seconds = time.perf_counter() - t0
    from_backup = snapshot_view(rdb)
    rdb.close()

    return {
        "setup": "independent backup of 80 titles; a bug empties every title and is replicated; restore from backup in an isolated directory",
        "backup_id": bid,
        "before": before,
        "replica_before_matches_primary": replica_before["fingerprint"] == before["fingerprint"],
        "after_bug": {
            "primary": after_bug_primary,
            "replica": after_bug_replica,
            "replica_matches_primary": after_bug_replica["fingerprint"] == after_bug_primary["fingerprint"],
            "replica_invariants_ok": after_bug_replica["invariants_ok"],
            "empty_titles": after_bug_primary["sample_title"] == "",
        },
        "using_replica_as_restore": {
            "view": replica_as_restore,
            "invariants_ok": replica_as_restore["invariants_ok"],
            "recovered_titles": replica_as_restore["sample_title"],
        },
        "independent_backup_isolated_restore": {
            "restore_seconds": round(restore_seconds, 6),
            "view": from_backup,
            "invariants_ok": from_backup["invariants_ok"],
            "sample_title": from_backup["sample_title"],
            "matches_pre_bug_backup": from_backup["fingerprint"] == before["fingerprint"],
            "not_using_online_replica": True,
        },
        "replica_cannot_replace_independent_backup": (
            (not replica_as_restore["invariants_ok"]) and from_backup["invariants_ok"]
        ),
    }


def run_all_experiments(work_root: str | None = None) -> dict[str, Any]:
    root = work_root or os.path.join(os.path.dirname(os.path.abspath(__file__)), "work")
    if os.path.exists(root):
        shutil.rmtree(root)
    os.makedirs(root, exist_ok=True)
    data = {
        "title_v1": TITLE_V1,
        "title_v2": TITLE_V2,
        "full_incremental_retention": exp_full_incremental_retention(root),
        "checksum_and_consistency": exp_checksum_and_consistency(root),
        "deprecated_shared_naming": exp_deprecated_shared_naming(root),
        "unsynced_backup_crash": exp_unsynced_backup_crash(root),
        "rpo_rto_drill": exp_rpo_rto_drill(root),
        "replica_is_not_backup": exp_replica_is_not_backup(root),
    }
    return data


if __name__ == "__main__":
    import json
    result = run_all_experiments()
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
