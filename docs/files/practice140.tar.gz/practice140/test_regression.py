#!/usr/bin/env python3
"""Acceptance checks for the lesson 140 performance-regression experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    ALPHA,
    COMMITS,
    ENGINE_NAME,
    KEY_TITLE,
    MEASURE_REPS,
    MEM_BASELINE,
    MEM_BUDGET,
    MEM_C3,
    N_KEYS,
    N_REQUESTS,
    NARROW_REPS,
    TITLE_V1,
    TRACE_SEED,
    UTEST_MIN_REPETITIONS,
    UTEST_OPTIMAL_REPETITIONS,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    assert r["engine"] == ENGINE_NAME == "RegressionEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_benchmark_product"] and r["not_google_benchmark"]
    assert r["not_compare_py"] and r["not_scipy"] and r["cycles_are_teaching"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["n_keys"] == N_KEYS == 200
    assert r["n_requests"] == N_REQUESTS == 2000
    assert r["get_count"] == 1800 and r["set_count"] == 200
    assert r["hot_count"] == 1600
    assert r["get_ratio"] == 0.9 and r["set_ratio"] == 0.1
    assert r["hot_key_count"] == 20 and r["hot_key_share"] == 0.8
    assert r["trace_seed"] == TRACE_SEED == 42
    assert r["dataset_hash"] == "0f48bbc37e78af58"
    assert r["measure_reps"] == MEASURE_REPS == 9
    assert r["narrow_reps"] == NARROW_REPS == 2
    assert r["timeout_us"] == 2000
    assert r["alpha"] == ALPHA == 0.05
    assert r["utest_min_repetitions"] == UTEST_MIN_REPETITIONS == 2
    assert r["utest_optimal_repetitions"] == UTEST_OPTIMAL_REPETITIONS == 9
    assert r["mem_baseline"] == MEM_BASELINE == 4096
    assert r["mem_c3"] == MEM_C3 == 65536
    assert r["mem_budget"] == MEM_BUDGET == 8192
    assert r["commits"]["c0"]["id"] == COMMITS["c0"]["id"] == "c0e1a01"
    assert r["commits"]["c1"]["id"] == "c1e1a02"
    assert r["commits"]["c2"]["id"] == "c2e1b03"
    assert r["commits"]["c3"]["id"] == "c3e1c04"

    env0 = r["environment_c0_isolated"]
    assert env0["hostname"] == "atlas-teach-ci-1"
    assert env0["cpus"] == 8
    assert env0["governor"] == "performance"
    assert env0["kernel"] == "Linux 6.8.0-teach"
    assert env0["dataset_hash"] == "0f48bbc37e78af58"
    assert env0["commit_id"] == "c0e1a01"
    assert env0["ci_class"] == "isolated"
    assert r["environment_c0_shared"]["governor"] == "schedutil"
    assert r["environment_c2_isolated"]["commit_id"] == "c2e1b03"
    assert r["environment_c3_isolated"]["commit_id"] == "c3e1c04"

    b0 = r["baseline_isolated_a"]["stats"]
    assert b0["p99_all"]["mean"] == 200.0
    assert b0["p99_all"]["values"] == [198, 200, 202, 196, 204, 200, 198, 202, 200]
    assert b0["p99_all"]["stdev"] == 2.4495
    assert b0["p99_all"]["cv"] == 0.012247
    assert b0["throughput_qps"]["mean"] == 10110.8465
    assert b0["error_rate"]["mean"] == 0.0
    assert b0["cpu_per_req"]["mean"] == 55.0
    assert b0["memory_per_conn"]["mean"] == 4096.0

    same = r["compare_same_commit_isolated"]["p99_all"]
    assert same["rel_mean"] == 0.0
    assert same["utest"]["pvalue"] == 1.0
    assert same["statistically_different"] is False
    assert same["utest"]["reliable"] is True

    ref = r["compare_c0_c1_refactor"]["p99_all"]
    assert ref["rel_mean"] == 0.0 and ref["utest"]["pvalue"] == 1.0
    assert ref["statistically_different"] is False

    scan = r["compare_c0_c2_scan"]
    assert r["commit_c2_isolated"]["stats"]["p99_all"]["mean"] == 600.0
    assert r["commit_c2_isolated"]["stats"]["p99_all"]["values"] == [594, 600, 606, 588, 612, 600, 594, 606, 600]
    assert scan["p99_all"]["rel_mean"] == 2.0
    assert scan["p99_all"]["utest"]["pvalue"] == 4.1e-05
    assert scan["p99_all"]["statistically_different"] is True
    assert scan["throughput_qps"]["new"]["mean"] == 7199.507
    assert scan["throughput_qps"]["rel_mean"] == -0.287942
    assert scan["cpu_per_req"]["new"]["mean"] == 95.0
    assert scan["cpu_per_req"]["rel_mean"] == 0.727273
    assert scan["error_rate"]["new"]["mean"] == 0.0

    cache = r["compare_c0_c3_cache"]
    assert r["commit_c3_isolated"]["stats"]["p99_all"]["mean"] == 2000.0
    assert r["commit_c3_isolated"]["stats"]["p99_success"]["mean"] == 40.0
    assert r["commit_c3_isolated"]["stats"]["error_rate"]["mean"] == 0.02
    assert r["commit_c3_isolated"]["stats"]["throughput_qps"]["mean"] == 12626.6923
    assert r["commit_c3_isolated"]["stats"]["ok_throughput_qps"]["mean"] == 12374.1585
    assert r["commit_c3_isolated"]["stats"]["cpu_per_req"]["mean"] == 20.6
    assert r["commit_c3_isolated"]["stats"]["memory_per_conn"]["mean"] == 65536.0
    assert cache["p99_all"]["rel_mean"] == 9.0
    assert cache["p99_success"]["rel_mean"] == -0.8
    assert cache["throughput_qps"]["rel_mean"] == 0.248826
    assert cache["ok_throughput_qps"]["rel_mean"] == 0.22385
    assert cache["cpu_per_req"]["rel_mean"] == -0.625455
    assert cache["memory_per_conn"]["rel_mean"] == 15.0
    assert cache["p99_all"]["statistically_different"] is True
    assert cache["error_rate"]["statistically_different"] is True

    shared = r["compare_same_commit_shared"]["p99_all"]
    assert shared["old"]["mean"] == 200.0 and shared["new"]["mean"] == 200.0
    assert shared["old"]["values"] == [170, 180, 190, 200, 200, 210, 220, 230, 200]
    assert shared["new"]["values"] == [160, 176, 192, 208, 224, 240, 180, 200, 220]
    assert shared["old"]["stdev"] == 18.7083
    assert shared["new"]["stdev"] == 25.6905
    assert shared["rel_mean"] == 0.0
    assert shared["utest"]["pvalue"] == 1.0
    assert shared["statistically_different"] is False
    assert r["compare_same_commit_shared"]["throughput_qps"]["old"]["mean"] == 10189.2105
    assert r["compare_same_commit_shared"]["throughput_qps"]["new"]["mean"] == 10262.9531
    assert r["compare_same_commit_shared"]["throughput_qps"]["rel_mean"] == 0.007237

    hot = r["compare_c0_c2_hot_get"]["p99_all"]
    assert r["baseline_hot_get"]["runs"][0]["n_requests"] == 1454
    assert hot["old"]["mean"] == 80.0 and hot["new"]["mean"] == 80.0
    assert hot["rel_mean"] == 0.0
    assert hot["statistically_different"] is False

    two = r["compare_same_commit_isolated_2rep_p99"]
    assert two["old"]["values"] == [198, 200] and two["new"]["values"] == [202, 198]
    assert two["old"]["mean"] == 199.0 and two["new"]["mean"] == 200.0
    assert two["rel_mean"] == 0.005025
    assert two["utest"]["pvalue"] == 1.0
    assert two["utest"]["reliable"] is False
    assert two["utest"]["ran"] is True
    assert "9+" in two["utest"]["warning"]

    narrow_iso = r["narrow_0_5pct_isolated_p99"]
    assert narrow_iso["false_positives"] == 7 and narrow_iso["pairs"] == 9
    narrow_sh = r["narrow_0_5pct_shared_p99"]
    assert narrow_sh["false_positives"] == 9
    assert r["threshold_10pct_isolated_p99"]["false_positives"] == 0
    assert r["threshold_10pct_shared_p99"]["false_positives"] == 4

    budgets = r["budgets"]
    assert budgets["p99_all"] == 220.0
    assert budgets["error_rate"] == 0.0
    assert budgets["memory_per_conn"] == 8192
    assert budgets["throughput_qps"] == 9099.7619
    assert budgets["cpu_per_req"] == 60.5
    assert r["gate_same_commit_isolated_b"]["passed"] is True
    assert r["gate_c1_refactor"]["passed"] is True
    assert r["gate_c2_scan"]["passed"] is False
    assert r["gate_c2_scan"]["failed"] == ["p99_all", "throughput_qps", "cpu_per_req"]
    assert r["gate_c3_cache"]["passed"] is False
    assert r["gate_c3_cache"]["failed"] == ["p99_all", "error_rate", "memory_per_conn"]
    assert r["gate_c3_cache"]["optimistic_success_only"]["passed"] is True
    assert r["gate_same_commit_shared_b"]["passed"] is True

    assert r["acceptance_distinguish_noise_from_regression"] is True
    assert r["acceptance_report_p99_and_error_rate"] is True
    assert r["practice_fixed_dataset_and_metadata"] is True
    assert r["pitfall_narrow_threshold_on_shared_ci"] is True
    assert r["tradeoff_strict_gate_vs_false_positive"] is True
    assert r["representative_load_catches_set_regression"] is True
    assert r["two_rep_utest_unreliable"] is True
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
