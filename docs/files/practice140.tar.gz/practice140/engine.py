#!/usr/bin/env python3
"""Teaching RegressionEngine — not Redis, not a real benchmark product, not a network service.

A Python 3 standard-library model of a KV performance-regression harness.
It stores a fixed article-title dataset, replays a fixed request trace
across several teaching commits, records environment metadata, and
compares repetitions with a teaching Mann-Whitney U test.

The named source (checked on 2026-11-14) is the Google Benchmark User
Guide at https://github.com/google/benchmark/blob/main/docs/user_guide.md
and the follow-through page docs/tools.md, which the Guide's "Result
comparison" section points to as Additional Tooling Documentation.
tools.md describes compare.py, the relative change (new-old)/|old|, the
Mann-Whitney U test, default significance level alpha=0.05 in compare.py,
and the warning that the test needs a LARGE number of repetitions (no
less than 9) to be meaningful. tools/gbench/report.py sets
UTEST_MIN_REPETITIONS=2 and UTEST_OPTIMAL_REPETITIONS=9. The User Guide
also documents --benchmark_context / AddCustomContext for extra
environment metadata, --benchmark_repetitions, and (via reducing_variance.md)
shared-machine variance. This engine is not Google Benchmark, not
compare.py, and not scipy. Costs are teaching virtual microseconds, not
production RTT and not wall-clock measurements from a host KV.
"""
from __future__ import annotations

import hashlib
import math
import statistics
from itertools import combinations
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
N_KEYS = 200
N_REQUESTS = 2000
GET_RATIO_HUNDREDTHS = 90  # 90% GET, 10% SET
HOT_KEYS = 20
HOT_SHARE_HUNDREDTHS = 80  # 80% of traffic lands on the first 20 keys
TRACE_SEED = 42
MEASURE_REPS = 9
NARROW_REPS = 2
TIMEOUT_US = 2000
ALPHA = 0.05
UTEST_MIN_REPETITIONS = 2
UTEST_OPTIMAL_REPETITIONS = 9

# Teaching service times, virtual microseconds. Not host wall-clock.
GET_HOT_US = 80
GET_COLD_US = 120
SET_US = 200
# c2 expire-scan: extra 2 us per key on every SET.
SCAN_PER_KEY_US = 2
# c3 fast-path GET, but a fixed 2% of requests wait until timeout and error.
C3_GET_US = 40
C3_SET_US = 40
C3_ERROR_EVERY = 50  # 1/50 = 2%

# Teaching CPU cycles per request and memory per connection (bytes).
GET_CPU = 50
SET_CPU = 100
SCAN_CPU_PER_KEY = 2
C3_GET_CPU = 20
C3_SET_CPU = 20
MEM_BASELINE = 4096
MEM_C3 = 65536
MEM_BUDGET = 8192

# Isolated CI multipliers, hundredths, mean 100. Two jobs are
# permutations of the same multiset, so means match exactly.
ISOLATED_A = (99, 100, 101, 98, 102, 100, 99, 101, 100)
ISOLATED_B = (101, 99, 100, 102, 98, 100, 101, 99, 100)
# Shared CI: same mean 100, much wider spread.
SHARED_A = (85, 90, 95, 100, 100, 105, 110, 115, 100)
SHARED_B = (80, 88, 96, 104, 112, 120, 90, 100, 110)

# Teaching commit ids. Not real git objects.
COMMITS = {
    "c0": {
        "id": "c0e1a01",
        "message": "baseline: hash-map KV for article titles",
    },
    "c1": {
        "id": "c1e1a02",
        "message": "refactor: rename helpers, no behavior change",
    },
    "c2": {
        "id": "c2e1b03",
        "message": "debug: full expire scan on every SET",
    },
    "c3": {
        "id": "c3e1c04",
        "message": "opt: speculative title cache",
    },
}

ENGINE_NAME = "RegressionEngine"
TEACHING_HOST = "atlas-teach-ci-1"
TEACHING_CPUS = 8
TEACHING_KERNEL = "Linux 6.8.0-teach"
TEACHING_GOV_ISOLATED = "performance"
TEACHING_GOV_SHARED = "schedutil"


def ts(t: float, nd: int = 4) -> float:
    return round(float(t) + 1e-12, nd)


def dataset_entries() -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    for i in range(1, N_KEYS + 1):
        key = f"article:{i:02d}:title"
        title = f"{TITLE_V1} #{i}"
        entries.append((key, title))
    return entries


def dataset_hash(entries: list[tuple[str, str]]) -> str:
    h = hashlib.sha256()
    for key, title in entries:
        h.update(f"{key}\t{title}\n".encode())
    return h.hexdigest()[:16]


def build_trace(entries: list[tuple[str, str]]) -> list[tuple[str, str, str]]:
    """Fixed request trace. Deterministic from TRACE_SEED, not random at run time.

    A very small linear congruential generator picks op and key so the
    mix is exact and reproducible: 90% GET, 10% SET; 80% of requests
    hit the first HOT_KEYS keys.
    """
    keys = [k for k, _ in entries]
    n_get = N_REQUESTS * GET_RATIO_HUNDREDTHS // 100
    n_set = N_REQUESTS - n_get
    n_hot = N_REQUESTS * HOT_SHARE_HUNDREDTHS // 100
    # Build a fixed pool then permute with the teaching LCG so the
    # sequence is stable and the counts are exact.
    ops: list[str] = ["GET"] * n_get + ["SET"] * n_set
    hot_keys = keys[:HOT_KEYS]
    cold_keys = keys[HOT_KEYS:]
    key_pool: list[str] = []
    # First n_hot requests (before shuffle) reserved as hot; the rest
    # cycle over cold keys. The LCG shuffle then mixes their order.
    for i in range(n_hot):
        key_pool.append(hot_keys[i % len(hot_keys)])
    for i in range(N_REQUESTS - n_hot):
        key_pool.append(cold_keys[i % len(cold_keys)])

    def lcg_shuffle(seq: list, seed: int) -> list:
        x = seed & 0xFFFFFFFF
        out = list(seq)
        for i in range(len(out) - 1, 0, -1):
            x = (1103515245 * x + 12345) & 0xFFFFFFFF
            j = x % (i + 1)
            out[i], out[j] = out[j], out[i]
        return out

    ops = lcg_shuffle(ops, TRACE_SEED)
    key_pool = lcg_shuffle(key_pool, TRACE_SEED + 1)
    titles = {k: t for k, t in entries}
    return [(op, key, titles[key]) for op, key in zip(ops, key_pool)]


def _costs(commit: str, op: str) -> tuple[int, int]:
    """Return (service_us, cpu_cycles) before timeout or noise."""
    if commit == "c3":
        if op == "GET":
            return C3_GET_US, C3_GET_CPU
        return C3_SET_US, C3_SET_CPU
    if op == "GET":
        # caller will distinguish hot/cold
        return 0, GET_CPU
    # SET
    if commit == "c2":
        return SET_US + SCAN_PER_KEY_US * N_KEYS, SET_CPU + SCAN_CPU_PER_KEY * N_KEYS
    return SET_US, SET_CPU


def run_once(
    trace: list[tuple[str, str, str]],
    commit: str,
    multiplier_hundredths: int,
    hot_keys: set[str],
    load: str = "full",
) -> dict[str, Any]:
    """Replay the (or a sliced) trace once. load='full' or 'hot_get'."""
    if load == "hot_get":
        work = [(op, key, title) for op, key, title in trace if op == "GET" and key in hot_keys]
    else:
        work = list(trace)

    latencies_all: list[int] = []
    latencies_ok: list[int] = []
    errors = 0
    cpu_total = 0
    for i, (op, key, _title) in enumerate(work):
        if commit == "c3" and (i + 1) % C3_ERROR_EVERY == 0:
            # Fast path bug: wait until the teaching timeout, then error.
            service = TIMEOUT_US
            cpu = GET_CPU
            is_err = True
        else:
            is_err = False
            if op == "GET":
                if commit == "c3":
                    service, cpu = C3_GET_US, C3_GET_CPU
                else:
                    service = GET_HOT_US if key in hot_keys else GET_COLD_US
                    cpu = GET_CPU
            else:
                service, cpu = _costs(commit, op)
        # Apply the repetition's teaching noise as an integer hundredths
        # scale, rounding to a whole teaching microsecond.
        scaled = (service * multiplier_hundredths + 50) // 100
        if scaled > TIMEOUT_US and not is_err:
            # Isolated/shared noise does not itself create timeouts in
            # this teaching model; cap is only reached on the c3 error path.
            scaled = min(scaled, TIMEOUT_US)
        if is_err:
            scaled = TIMEOUT_US
            errors += 1
        else:
            latencies_ok.append(scaled)
        latencies_all.append(scaled)
        cpu_total += cpu

    n = len(work)
    def pct(vals: list[int], p: float) -> int:
        if not vals:
            return 0
        s = sorted(vals)
        # Nearest upward rank: ceil(p * n), 1-based, then 0-based index.
        idx = max(0, min(len(s) - 1, math.ceil(p * len(s)) - 1))
        return s[idx]

    total_us = sum(latencies_all)
    ok = n - errors
    mem = MEM_C3 if commit == "c3" else MEM_BASELINE
    return {
        "n_requests": n,
        "errors": errors,
        "error_rate": ts(errors / n, 6) if n else 0.0,
        "total_us": total_us,
        "throughput_qps": ts(n * 1_000_000 / total_us, 4) if total_us else 0.0,
        "ok_throughput_qps": ts(ok * 1_000_000 / total_us, 4) if total_us else 0.0,
        "p50_all": pct(latencies_all, 0.50),
        "p99_all": pct(latencies_all, 0.99),
        "p99_success": pct(latencies_ok, 0.99),
        "cpu_per_req": ts(cpu_total / n, 4) if n else 0.0,
        "memory_per_conn": mem,
        "multiplier_hundredths": multiplier_hundredths,
        "commit": commit,
        "load": load,
    }


def run_reps(
    trace: list[tuple[str, str, str]],
    commit: str,
    table: tuple[int, ...],
    hot_keys: set[str],
    load: str = "full",
    reps: Optional[int] = None,
) -> list[dict[str, Any]]:
    use = table[: reps or len(table)]
    return [run_once(trace, commit, m, hot_keys, load=load) for m in use]


def summarize(runs: list[dict[str, Any]], field: str) -> dict[str, Any]:
    vals = [r[field] for r in runs]
    mean = statistics.fmean(vals)
    median = statistics.median(vals)
    if len(vals) >= 2:
        stdev = statistics.stdev(vals)
    else:
        stdev = 0.0
    cv = (stdev / mean) if mean else 0.0
    return {
        "values": vals,
        "mean": ts(mean, 4),
        "median": ts(median, 4) if not isinstance(median, int) else median if field.startswith("p") or field in {"memory_per_conn", "errors"} else ts(float(median), 4),
        "stdev": ts(stdev, 4),
        "cv": ts(cv, 6),
        "min": min(vals),
        "max": max(vals),
    }


def u_stat(x: list[float], y: list[float]) -> float:
    """Mann-Whitney U for sample x (number of wins of x against y, ties=0.5)."""
    u = 0.0
    for a in x:
        for b in y:
            if a > b:
                u += 1.0
            elif a == b:
                u += 0.5
    return u


def mannwhitney_pvalue(x: list[float], y: list[float]) -> dict[str, Any]:
    """Two-sided exact (enumeration) teaching U test. Not scipy, not compare.py.

    Null hypothesis, as in tools.md: no difference in performance. Default
    alpha is 0.05, matching compare.py. If either sample is shorter than
    UTEST_OPTIMAL_REPETITIONS (9), the result is flagged unreliable, matching
    the warning in tools.md and tools/gbench/report.py.
    """
    n1, n2 = len(x), len(y)
    observed = u_stat(x, y)
    n = n1 * n2
    mean_u = n / 2.0
    # Exact two-sided p-value by assigning the pooled observations to
    # two groups of the original sizes. Feasible for 9+9 (C(18,9)=48620).
    pooled = list(x) + list(y)
    extreme = 0
    total = 0
    dev = abs(observed - mean_u)
    for idx in combinations(range(n1 + n2), n1):
        xs = [pooled[i] for i in idx]
        # y gets the complement; U depends only on the two bags.
        chosen = set(idx)
        ys = [pooled[i] for i in range(n1 + n2) if i not in chosen]
        u = u_stat(xs, ys)
        total += 1
        if abs(u - mean_u) >= dev - 1e-12:
            extreme += 1
    p = extreme / total if total else 1.0
    reps_ok = n1 >= UTEST_OPTIMAL_REPETITIONS and n2 >= UTEST_OPTIMAL_REPETITIONS
    ran = n1 >= UTEST_MIN_REPETITIONS and n2 >= UTEST_MIN_REPETITIONS
    return {
        "u": ts(observed, 4),
        "u_mean_h0": ts(mean_u, 4),
        "n1": n1,
        "n2": n2,
        "pvalue": ts(p, 6),
        "alpha": ALPHA,
        "significant": bool(p < ALPHA),
        "ran": ran,
        "reliable": reps_ok,
        "warning": None if reps_ok else (
            f"WARNING: Results unreliable! {UTEST_OPTIMAL_REPETITIONS}+ "
            "repetitions are required for a meaningful U test "
            "(tools.md / report.py UTEST_OPTIMAL_REPETITIONS)."
        ),
        "method": "exact-enumeration-teaching",
        "not_scipy": True,
        "not_compare_py": True,
    }


def relative_change(old: float, new: float) -> float:
    """(new - old) / |old|, as tools.md documents for compare.py Time/CPU columns."""
    if old == 0:
        return 0.0
    return ts((new - old) / abs(old), 6)


def compare_field(old_runs: list[dict[str, Any]], new_runs: list[dict[str, Any]], field: str) -> dict[str, Any]:
    old_s = summarize(old_runs, field)
    new_s = summarize(new_runs, field)
    ut = mannwhitney_pvalue(old_s["values"], new_s["values"])
    rel = relative_change(old_s["mean"], new_s["mean"])
    return {
        "field": field,
        "old": old_s,
        "new": new_s,
        "rel_mean": rel,
        "utest": ut,
        # compare.py colors: green = statistically different, red = similar.
        "statistically_different": ut["significant"] and ut["reliable"],
        "unreliable_significant": ut["significant"] and not ut["reliable"],
    }


def environment(commit: str, ci_class: str, entries: list[tuple[str, str]]) -> dict[str, Any]:
    gov = TEACHING_GOV_ISOLATED if ci_class == "isolated" else TEACHING_GOV_SHARED
    return {
        "hostname": TEACHING_HOST,
        "cpus": TEACHING_CPUS,
        "governor": gov,
        "kernel": TEACHING_KERNEL,
        "dataset_hash": dataset_hash(entries),
        "dataset_keys": N_KEYS,
        "n_requests": N_REQUESTS,
        "get_ratio": ts(GET_RATIO_HUNDREDTHS / 100, 2),
        "set_ratio": ts(1 - GET_RATIO_HUNDREDTHS / 100, 2),
        "hot_key_count": HOT_KEYS,
        "hot_key_share": ts(HOT_SHARE_HUNDREDTHS / 100, 2),
        "trace_seed": TRACE_SEED,
        "commit_id": COMMITS[commit]["id"],
        "commit_message": COMMITS[commit]["message"],
        "ci_class": ci_class,
        "timeout_us": TIMEOUT_US,
        "cycles_are_teaching": True,
        "host_is_teaching": True,
        # Teaching analogue of --benchmark_context / AddCustomContext.
        "context_is_teaching": True,
    }


def narrow_false_positives(old_runs: list[dict[str, Any]], new_runs: list[dict[str, Any]], field: str, threshold: float) -> dict[str, Any]:
    """Apply a hard relative threshold to each paired single-run comparison."""
    hits = 0
    pairs = []
    for a, b in zip(old_runs, new_runs):
        rel = relative_change(a[field], b[field])
        fire = abs(rel) > threshold
        if fire:
            hits += 1
        pairs.append({"old": a[field], "new": b[field], "rel": rel, "fired": fire})
    return {
        "field": field,
        "threshold": threshold,
        "pairs": len(pairs),
        "false_positives": hits,
        "any_fired": hits > 0,
        "examples": pairs,
    }


def evaluate_gate(baseline_mean: dict[str, float], run_mean: dict[str, float], budgets: dict[str, float]) -> dict[str, Any]:
    """Blocking gate. A change fails if it misses any budget.

    Budgets are teaching values: p99 may grow by at most 10% of the
    isolated baseline mean; error rate must stay at 0; memory/conn
    must stay at or below MEM_BUDGET; throughput must stay at or
    above 90% of baseline; CPU/request may grow by at most 10%.
    """
    checks = {
        "p99_all": run_mean["p99_all"] <= budgets["p99_all"],
        "error_rate": run_mean["error_rate"] <= budgets["error_rate"],
        "memory_per_conn": run_mean["memory_per_conn"] <= budgets["memory_per_conn"],
        "throughput_qps": run_mean["throughput_qps"] >= budgets["throughput_qps"],
        "cpu_per_req": run_mean["cpu_per_req"] <= budgets["cpu_per_req"],
    }
    # A report that only looks at success-path p99 and ok-throughput.
    optimistic = {
        "p99_success": run_mean["p99_success"] <= budgets["p99_all"],
        "ok_throughput_qps": run_mean["ok_throughput_qps"] >= budgets["throughput_qps"],
    }
    return {
        "checks": checks,
        "passed": all(checks.values()),
        "failed": [k for k, v in checks.items() if not v],
        "optimistic_success_only": {
            "checks": optimistic,
            "passed": all(optimistic.values()),
        },
    }
