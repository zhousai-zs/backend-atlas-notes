#!/usr/bin/env python3
"""Run the lesson 140 teaching KV regression experiments and return results."""
from __future__ import annotations

from typing import Any

from engine import (
    ALPHA,
    COMMITS,
    ENGINE_NAME,
    GET_RATIO_HUNDREDTHS,
    HOT_KEYS,
    HOT_SHARE_HUNDREDTHS,
    ISOLATED_A,
    ISOLATED_B,
    KEY_TITLE,
    MEM_BASELINE,
    MEM_BUDGET,
    MEM_C3,
    MEASURE_REPS,
    N_KEYS,
    N_REQUESTS,
    NARROW_REPS,
    SHARED_A,
    SHARED_B,
    TEACHING_CPUS,
    TEACHING_GOV_ISOLATED,
    TEACHING_GOV_SHARED,
    TEACHING_HOST,
    TEACHING_KERNEL,
    TIMEOUT_US,
    TITLE_V1,
    TRACE_SEED,
    UTEST_MIN_REPETITIONS,
    UTEST_OPTIMAL_REPETITIONS,
    compare_field,
    dataset_entries,
    dataset_hash,
    environment,
    evaluate_gate,
    build_trace,
    narrow_false_positives,
    relative_change,
    run_reps,
    summarize,
    ts,
)


FIELDS = (
    "p99_all",
    "p99_success",
    "throughput_qps",
    "ok_throughput_qps",
    "error_rate",
    "cpu_per_req",
    "memory_per_conn",
)


def _pack(runs: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "reps": len(runs),
        "runs": runs,
        "stats": {f: summarize(runs, f) for f in FIELDS},
    }


def _compare_all(old_runs: list[dict[str, Any]], new_runs: list[dict[str, Any]]) -> dict[str, Any]:
    return {f: compare_field(old_runs, new_runs, f) for f in FIELDS}


def _means(pack: dict[str, Any]) -> dict[str, float]:
    return {f: pack["stats"][f]["mean"] for f in FIELDS}


def run() -> dict[str, Any]:
    entries = dataset_entries()
    trace = build_trace(entries)
    hot_keys = {k for k, _ in entries[:HOT_KEYS]}
    n_get = sum(1 for op, _, _ in trace if op == "GET")
    n_set = len(trace) - n_get
    n_hot = sum(1 for _op, key, _t in trace if key in hot_keys)
    dhash = dataset_hash(entries)

    c0_iso_a = run_reps(trace, "c0", ISOLATED_A, hot_keys)
    c0_iso_b = run_reps(trace, "c0", ISOLATED_B, hot_keys)
    c1_iso_b = run_reps(trace, "c1", ISOLATED_B, hot_keys)
    c2_iso_a = run_reps(trace, "c2", ISOLATED_A, hot_keys)
    c3_iso_a = run_reps(trace, "c3", ISOLATED_A, hot_keys)
    c0_shared_a = run_reps(trace, "c0", SHARED_A, hot_keys)
    c0_shared_b = run_reps(trace, "c0", SHARED_B, hot_keys)
    c0_hot = run_reps(trace, "c0", ISOLATED_A, hot_keys, load="hot_get")
    c2_hot = run_reps(trace, "c2", ISOLATED_A, hot_keys, load="hot_get")

    pack_c0a = _pack(c0_iso_a)
    pack_c0b = _pack(c0_iso_b)
    pack_c1 = _pack(c1_iso_b)
    pack_c2 = _pack(c2_iso_a)
    pack_c3 = _pack(c3_iso_a)
    pack_sha = _pack(c0_shared_a)
    pack_shb = _pack(c0_shared_b)
    pack_c0_hot = _pack(c0_hot)
    pack_c2_hot = _pack(c2_hot)

    cmp_same_iso = _compare_all(c0_iso_a, c0_iso_b)
    cmp_c0_c1 = _compare_all(c0_iso_a, c1_iso_b)
    cmp_c0_c2 = _compare_all(c0_iso_a, c2_iso_a)
    cmp_c0_c3 = _compare_all(c0_iso_a, c3_iso_a)
    cmp_same_shared = _compare_all(c0_shared_a, c0_shared_b)
    cmp_hot = _compare_all(c0_hot, c2_hot)
    cmp_2rep = compare_field(c0_iso_a[:NARROW_REPS], c0_iso_b[:NARROW_REPS], "p99_all")

    narrow_iso = narrow_false_positives(c0_iso_a, c0_iso_b, "p99_all", 0.005)
    narrow_shared = narrow_false_positives(c0_shared_a, c0_shared_b, "p99_all", 0.005)
    # A 10% budget-style threshold on the same paired single runs.
    budgetish_iso = narrow_false_positives(c0_iso_a, c0_iso_b, "p99_all", 0.10)
    budgetish_shared = narrow_false_positives(c0_shared_a, c0_shared_b, "p99_all", 0.10)

    base_means = _means(pack_c0a)
    budgets = {
        "p99_all": ts(base_means["p99_all"] * 1.10, 4),
        "error_rate": 0.0,
        "memory_per_conn": MEM_BUDGET,
        "throughput_qps": ts(base_means["throughput_qps"] * 0.90, 4),
        "cpu_per_req": ts(base_means["cpu_per_req"] * 1.10, 4),
    }
    gate_c0b = evaluate_gate(base_means, _means(pack_c0b), budgets)
    gate_c1 = evaluate_gate(base_means, _means(pack_c1), budgets)
    gate_c2 = evaluate_gate(base_means, _means(pack_c2), budgets)
    gate_c3 = evaluate_gate(base_means, _means(pack_c3), budgets)
    gate_shared_b = evaluate_gate(base_means, _means(pack_shb), budgets)

    return {
        "engine": ENGINE_NAME,
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_benchmark_product": True,
        "not_google_benchmark": True,
        "not_compare_py": True,
        "not_scipy": True,
        "cycles_are_teaching": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "n_keys": N_KEYS,
        "n_requests": N_REQUESTS,
        "get_count": n_get,
        "set_count": n_set,
        "hot_count": n_hot,
        "get_ratio": ts(GET_RATIO_HUNDREDTHS / 100, 2),
        "set_ratio": ts(1 - GET_RATIO_HUNDREDTHS / 100, 2),
        "hot_key_count": HOT_KEYS,
        "hot_key_share": ts(HOT_SHARE_HUNDREDTHS / 100, 2),
        "trace_seed": TRACE_SEED,
        "dataset_hash": dhash,
        "measure_reps": MEASURE_REPS,
        "narrow_reps": NARROW_REPS,
        "timeout_us": TIMEOUT_US,
        "alpha": ALPHA,
        "utest_min_repetitions": UTEST_MIN_REPETITIONS,
        "utest_optimal_repetitions": UTEST_OPTIMAL_REPETITIONS,
        "mem_baseline": MEM_BASELINE,
        "mem_c3": MEM_C3,
        "mem_budget": MEM_BUDGET,
        "teaching_host": TEACHING_HOST,
        "teaching_cpus": TEACHING_CPUS,
        "teaching_kernel": TEACHING_KERNEL,
        "teaching_governor_isolated": TEACHING_GOV_ISOLATED,
        "teaching_governor_shared": TEACHING_GOV_SHARED,
        "commits": COMMITS,
        "environment_c0_isolated": environment("c0", "isolated", entries),
        "environment_c0_shared": environment("c0", "shared", entries),
        "environment_c1_isolated": environment("c1", "isolated", entries),
        "environment_c2_isolated": environment("c2", "isolated", entries),
        "environment_c3_isolated": environment("c3", "isolated", entries),
        "baseline_isolated_a": pack_c0a,
        "baseline_isolated_b": pack_c0b,
        "commit_c1_isolated": pack_c1,
        "commit_c2_isolated": pack_c2,
        "commit_c3_isolated": pack_c3,
        "baseline_shared_a": pack_sha,
        "baseline_shared_b": pack_shb,
        "baseline_hot_get": pack_c0_hot,
        "commit_c2_hot_get": pack_c2_hot,
        "compare_same_commit_isolated": cmp_same_iso,
        "compare_c0_c1_refactor": cmp_c0_c1,
        "compare_c0_c2_scan": cmp_c0_c2,
        "compare_c0_c3_cache": cmp_c0_c3,
        "compare_same_commit_shared": cmp_same_shared,
        "compare_c0_c2_hot_get": cmp_hot,
        "compare_same_commit_isolated_2rep_p99": cmp_2rep,
        "narrow_0_5pct_isolated_p99": narrow_iso,
        "narrow_0_5pct_shared_p99": narrow_shared,
        "threshold_10pct_isolated_p99": budgetish_iso,
        "threshold_10pct_shared_p99": budgetish_shared,
        "budgets": budgets,
        "gate_same_commit_isolated_b": gate_c0b,
        "gate_c1_refactor": gate_c1,
        "gate_c2_scan": gate_c2,
        "gate_c3_cache": gate_c3,
        "gate_same_commit_shared_b": gate_shared_b,
        "acceptance_distinguish_noise_from_regression": (
            (not cmp_same_iso["p99_all"]["statistically_different"])
            and (cmp_same_iso["p99_all"]["rel_mean"] == 0.0)
            and cmp_c0_c2["p99_all"]["statistically_different"]
            and (cmp_c0_c2["p99_all"]["rel_mean"] > 0.10)
            and gate_c0b["passed"]
            and (not gate_c2["passed"])
        ),
        "acceptance_report_p99_and_error_rate": (
            pack_c3["stats"]["error_rate"]["mean"] > 0.0
            and pack_c0a["stats"]["error_rate"]["mean"] == 0.0
            and (not gate_c3["passed"])
            and "error_rate" in gate_c3["failed"]
            and gate_c3["optimistic_success_only"]["passed"]
        ),
        "practice_fixed_dataset_and_metadata": (
            dhash == dataset_hash(entries)
            and environment("c0", "isolated", entries)["dataset_hash"] == dhash
            and environment("c0", "isolated", entries)["commit_id"] == COMMITS["c0"]["id"]
            and environment("c2", "isolated", entries)["commit_id"] == COMMITS["c2"]["id"]
            and environment("c3", "isolated", entries)["commit_id"] == COMMITS["c3"]["id"]
        ),
        "pitfall_narrow_threshold_on_shared_ci": (
            narrow_iso["any_fired"]
            and narrow_shared["any_fired"]
            and narrow_shared["false_positives"] >= narrow_iso["false_positives"]
            and (not budgetish_iso["any_fired"])
            and (not cmp_same_shared["p99_all"]["statistically_different"])
        ),
        "tradeoff_strict_gate_vs_false_positive": (
            narrow_iso["false_positives"] > 0
            and (not budgetish_iso["any_fired"])
            and gate_c2["passed"] is False
            and gate_c1["passed"] is True
        ),
        "representative_load_catches_set_regression": (
            (not cmp_hot["p99_all"]["statistically_different"])
            and cmp_hot["p99_all"]["rel_mean"] == 0.0
            and cmp_c0_c2["p99_all"]["statistically_different"]
        ),
        "two_rep_utest_unreliable": (
            (not cmp_2rep["utest"]["reliable"])
            and cmp_2rep["utest"]["ran"]
            and cmp_2rep["utest"]["warning"] is not None
        ),
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print("wrote results.json")
