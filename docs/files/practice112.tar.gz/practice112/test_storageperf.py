#!/usr/bin/env python3
"""Acceptance checks for practice112 (storage performance, amplification, tail latency)."""
from __future__ import annotations

import json
import os
import sys

from app import TITLE_V1, run_all_experiments


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert(data["title_v1"] == TITLE_V1, "title is Weekly digest")

    w = data["warmup_vs_steady"]
    _assert(w["dataset_keys"] == 800, "steady dataset is 800 keys")
    _assert(w["logical_live_bytes"] == 112000, "800 titles × 140 bytes")
    _assert(w["cache_bytes"] == 16384, "small cache is 16KiB")
    _assert(w["data_to_cache_ratio"] > 1, "report includes data size / cache size")
    _assert(w["acceptance_reports_data_vs_memory"] is True, "acceptance 1")
    _assert(w["sprint"]["still_in_memtable"] is True, "sprint working set stays in memtable")
    _assert(w["sprint"]["read_latency"]["p99_us"] == 0, "sprint p99 is 0 (no device IO)")
    _assert(w["hot_working_set"]["cache_hit_ratio"] == 1.0, "hot working set is a cache hit")
    _assert(w["hot_working_set"]["p99_us"] == 0, "hot working set p99 is 0")
    _assert(w["steady_full_random"]["p99_us"] > w["sprint"]["read_latency"]["p99_us"], "steady p99 exceeds sprint")
    _assert(w["steady_full_random"]["cache_hit_ratio"] < w["hot_working_set"]["cache_hit_ratio"], "full-set hit ratio is lower")
    _assert(w["sprint_p99_vs_steady_p99"]["steady_slower"] is True, "sprint is not steady state")
    _assert(w["hot_p99_vs_steady_p99"]["hot_faster"] is True, "a fitting working set is faster after warmup")

    s = data["write_stall_and_bg_io"]
    _assert(s["slow_has_stall"] is True, "slow compaction hits write stall")
    _assert(s["slow"]["stall_count"] > 0, "slowdown events exist")
    _assert(s["slow"]["stop_count"] > 0, "stop events exist")
    _assert("slowdown" in s["slow"]["reason_kinds"], "L0 slowdown reason")
    _assert("stop" in s["slow"]["reason_kinds"], "L0 stop reason")
    _assert(s["fast"]["stall_count"] + s["fast"]["stop_count"] == 0, "fast compaction avoids stall")
    _assert(s["fast_fewer_stalls"] is True, "fast path has fewer stalls")
    _assert(s["slow_p99_higher"] is True, "stalls raise write p99")
    _assert(s["slow"]["write_latency"]["p99_us"] >= 1000, "slow p99 includes delayed_write_sleep")
    _assert(s["official_defaults"]["level0_slowdown_writes_trigger"] == 20, "official slowdown default")
    _assert(s["official_defaults"]["level0_stop_writes_trigger"] == 36, "official stop default")

    m = data["mixed_load_compaction_fsync"]
    _assert(m["wal_sync"]["contract"]["durable_on_ack"] is True, "sync WAL is durable on ack")
    _assert(m["wal_sync"]["keys_lost_on_crash"] == 0, "sync WAL loses 0 keys on crash")
    _assert(m["wal_async"]["keys_lost_on_crash"] == 3, "async WAL loses unsynced dirty keys")
    _assert(m["disableWAL"]["keys_lost_on_crash"] == 3, "disableWAL loses unflushed keys")
    _assert(m["disableWAL_qps_higher"] is True, "disableWAL has higher virtual QPS")
    _assert(m["contract_disableWAL_changed"] is True, "disableWAL changes the persistence contract")
    _assert(m["fair_compare_sync_vs_disableWAL"] is False, "QPS is not comparable across contracts")
    _assert(m["annotation"]["sync_fsyncs"] > 0, "sync path issues fsyncs")
    _assert(m["annotation"]["async_fsyncs"] == 0, "async path issues no per-write fsync")
    _assert(m["annotation"]["sync_compact_higher_than_fsync_only"] is True, "compaction windows have higher write p99 than fsync-only")
    _assert(m["annotation"]["async_compact_higher"] is True, "compaction windows raise async write p99")
    _assert(m["wal_sync"]["data_to_cache_ratio"] > 1, "mixed-load report includes data/cache ratio")

    a = data["amplification_and_p99"]
    _assert(a["before_space_amp"] == 6.0, "six overlapping L0 files give space amp 6")
    _assert(a["after_space_amp"] == 1.0, "compaction drops space amp to 1")
    _assert(a["space_amp_dropped"] is True, "space amplification dropped")
    _assert(a["write_amp_rose_or_held"] is True, "compaction writes extra bytes (write amp)")
    _assert(a["before_missing_read_amp"] == 6.0, "missing get consults 6 L0 files")
    _assert(a["after_missing_read_amp"] == 1.0, "after compact, missing get consults 1 file")
    _assert(a["missing_read_amp_dropped"] is True, "read amp dropped")
    _assert(a["before_missing_p99_us"] == 504, "missing p99 is 6 index reads")
    _assert(a["after_missing_p99_us"] == 84, "missing p99 after compact is 1 index read")
    _assert(a["missing_read_p99_dropped"] is True, "read p99 dropped with read amp")

    p = data["persistence_contract"]
    _assert(p["fair_contract_unchanged"] is True, "larger cache keeps the same WAL/sync contract")
    _assert(p["unfair_contract_changed"] is True, "disableWAL changes the contract")
    _assert(p["baseline_lost_keys"] == 0, "baseline sync loses 0")
    _assert(p["fair_lost_keys"] == 0, "fair opt loses 0")
    _assert(p["unfair_lost_keys"] > 0, "unfair opt loses unflushed keys")
    _assert(p["unfair_qps_higher"] is True, "unfair QPS looks better")
    _assert(p["cannot_equate_disableWAL_qps_with_sync"] is True, "pitfall: not an equivalent comparison")
    _assert(p["acceptance_persistence_contract_not_silently_changed"] is True, "acceptance 2")
    _assert(p["data_to_cache_ratio_baseline"] > 1, "baseline data exceeds cache")
    _assert(p["data_to_cache_ratio_fair"] < 1, "fair opt fits the live set in cache")
    _assert(
        p["fair_opt_larger_cache"]["cache_hit_ratio"] > p["baseline_wal_sync_small_cache"]["cache_hit_ratio"],
        "fair opt improves cache hit ratio",
    )
    _assert(
        p["fair_opt_larger_cache"]["read_latency"]["avg_us"]
        < p["baseline_wal_sync_small_cache"]["read_latency"]["avg_us"],
        "fair opt lowers average read latency",
    )

    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        sys.exit(1)
