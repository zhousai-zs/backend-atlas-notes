#!/usr/bin/env python3
"""Run teaching experiments for lesson 112 and return a structured report."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from engine import (
    OFFICIAL_HARD_PENDING_BYTES,
    OFFICIAL_LEVEL0_COMPACTION_TRIGGER,
    OFFICIAL_LEVEL0_SLOWDOWN_TRIGGER,
    OFFICIAL_LEVEL0_STOP_TRIGGER,
    OFFICIAL_MAX_WRITE_BUFFER_NUMBER,
    OFFICIAL_SOFT_PENDING_BYTES,
    Options,
    ReadOptions,
    StoragePerfEngine,
    WriteOptions,
    contracts_equivalent,
    percentile,
    summarize_latencies,
)

TITLE_V1 = "Weekly digest"
VALUE_SIZE = 128
N_DATASET = 800
CACHE_SMALL = 16 * 1024
CACHE_LARGE = 256 * 1024


def pad_value(title: str, size: int = VALUE_SIZE) -> str:
    raw = title.encode("utf-8")
    if len(raw) > size:
        return title
    return title + ("." * (size - len(raw)))


VALUE_V1 = pad_value(TITLE_V1)


def article_key(i: int) -> str:
    return f"article:{i:04d}"


def official_defaults() -> Dict[str, Any]:
    return {
        "level0_file_num_compaction_trigger": OFFICIAL_LEVEL0_COMPACTION_TRIGGER,
        "level0_slowdown_writes_trigger": OFFICIAL_LEVEL0_SLOWDOWN_TRIGGER,
        "level0_stop_writes_trigger": OFFICIAL_LEVEL0_STOP_TRIGGER,
        "soft_pending_compaction_bytes_limit": OFFICIAL_SOFT_PENDING_BYTES,
        "hard_pending_compaction_bytes_limit": OFFICIAL_HARD_PENDING_BYTES,
        "max_write_buffer_number": OFFICIAL_MAX_WRITE_BUFFER_NUMBER,
        "note": (
            "教学触发阈值已缩小，以便短跑就能碰到 slowdown/stop；"
            "这些是 2026-11-13 从 main 的 advanced_options.h 核到的官方默认值。"
        ),
    }


def _base_options(**kwargs: Any) -> Options:
    opts = Options(
        write_buffer_size=1024,
        max_write_buffer_number=2,
        level0_file_num_compaction_trigger=2,
        level0_slowdown_writes_trigger=4,
        level0_stop_writes_trigger=8,
        soft_pending_compaction_bytes_limit=24_000,
        hard_pending_compaction_bytes_limit=48_000,
        cache_size=CACHE_SMALL,
        block_size=512,
        max_background_jobs=1,
        background_quota_us=180,
        device_read_us=80,
        device_write_us=40,
        device_fsync_us=1000,
        device_us_per_256b=4,
    )
    for key, value in kwargs.items():
        setattr(opts, key, value)
    return opts


def _fill(engine: StoragePerfEngine, n: int, wopts: WriteOptions, start: int = 1) -> None:
    value = VALUE_V1
    for i in range(start, start + n):
        engine.put(article_key(i), value, wopts)


def _random_order(n: int, seed: int) -> List[int]:
    # Deterministic LCG so we do not depend on random module reproducibility.
    x = seed & 0xFFFFFFFF
    idx = list(range(1, n + 1))
    for i in range(n - 1, 0, -1):
        x = (1664525 * x + 1013904223) & 0xFFFFFFFF
        j = x % (i + 1)
        idx[i], idx[j] = idx[j], idx[i]
    return idx


def _gets(engine: StoragePerfEngine, keys: List[int], ropts: Optional[ReadOptions] = None) -> None:
    ropts = ropts or ReadOptions()
    for i in keys:
        engine.get(article_key(i), ropts)


def _cut_latency(engine: StoragePerfEngine) -> None:
    engine.write_latencies.clear()
    engine.read_latencies.clear()


def warmup_vs_steady() -> Dict[str, Any]:
    wopts = WriteOptions(sync=False, disableWAL=False)
    # --- sprint: tiny working set still in memtable ---
    sprint = StoragePerfEngine(_base_options(
        cache_size=CACHE_SMALL,
        background_quota_us=0,
        write_buffer_size=10**6,
        max_write_buffer_number=8,
        auto_compact=False,
    ))
    _fill(sprint, 80, wopts)
    _cut_latency(sprint)
    _gets(sprint, _random_order(80, 1))
    sprint_stats = sprint.snapshot_stats()
    sprint_read = summarize_latencies(sprint.read_latencies)

    # --- steady dataset: 800 titles, cache 16KiB ---
    eng = StoragePerfEngine(_base_options(cache_size=CACHE_SMALL, background_quota_us=400))
    _fill(eng, N_DATASET, wopts)
    eng.compact_all()
    eng.cache = type(eng.cache)(eng.options.cache_size)  # drop cache after load
    live = eng.logical_live_bytes()
    cache = eng.options.cache_size
    ratio = live / cache

    # cold random reads (no warmup)
    _cut_latency(eng)
    eng.cache.reset_counters()
    eng.sst_touched = 0
    eng.user_reads = 0
    _gets(eng, _random_order(N_DATASET, 2)[:200])
    cold = {
        **summarize_latencies(eng.read_latencies),
        "cache_hits": eng.cache.hits,
        "cache_misses": eng.cache.misses,
        "cache_hit_ratio": round(eng.cache.hits / max(eng.cache.hits + eng.cache.misses, 1), 4),
        "read_amp": round(eng.sst_touched / max(eng.user_reads, 1), 4),
    }

    # "warmup" of a 40-key working set that fits in cache, then measure it
    hot_keys = list(range(1, 41))
    _gets(eng, hot_keys)  # warmup, fill cache
    _cut_latency(eng)
    eng.cache.reset_counters()
    eng.sst_touched = 0
    eng.user_reads = 0
    _gets(eng, hot_keys * 5)  # 200 gets on the hot set
    hot = {
        **summarize_latencies(eng.read_latencies),
        "cache_hits": eng.cache.hits,
        "cache_misses": eng.cache.misses,
        "cache_hit_ratio": round(eng.cache.hits / max(eng.cache.hits + eng.cache.misses, 1), 4),
        "read_amp": round(eng.sst_touched / max(eng.user_reads, 1), 4),
        "working_set_keys": 40,
    }

    # after a partial warmup, random gets over the FULL 800-key set stay miss-heavy
    _cut_latency(eng)
    eng.cache.reset_counters()
    eng.sst_touched = 0
    eng.user_reads = 0
    _gets(eng, _random_order(N_DATASET, 3)[:200])
    steady = {
        **summarize_latencies(eng.read_latencies),
        "cache_hits": eng.cache.hits,
        "cache_misses": eng.cache.misses,
        "cache_hit_ratio": round(eng.cache.hits / max(eng.cache.hits + eng.cache.misses, 1), 4),
        "read_amp": round(eng.sst_touched / max(eng.user_reads, 1), 4),
    }

    return {
        "title": TITLE_V1,
        "dataset_keys": N_DATASET,
        "value_bytes": VALUE_SIZE,
        "logical_live_bytes": live,
        "cache_bytes": cache,
        "data_to_cache_ratio": round(ratio, 4),
        "acceptance_reports_data_vs_memory": True,
        "sprint": {
            "keys": 80,
            "still_in_memtable": sprint.l0_count() == 0 and not sprint.levels[1],
            "logical_live_bytes": sprint.logical_live_bytes(),
            "read_latency": sprint_read,
            "cache_misses": sprint.cache.misses,
            "note": "短跑数据还在 memtable 里，几乎不走设备，不能代表稳态。",
        },
        "cold_random": cold,
        "hot_working_set": hot,
        "steady_full_random": steady,
        "sprint_p99_vs_steady_p99": {
            "sprint_p99_us": sprint_read["p99_us"],
            "steady_p99_us": steady["p99_us"],
            "steady_slower": steady["p99_us"] > sprint_read["p99_us"],
        },
        "hot_p99_vs_steady_p99": {
            "hot_p99_us": hot["p99_us"],
            "steady_p99_us": steady["p99_us"],
            "hot_faster": hot["p99_us"] < steady["p99_us"],
            "hot_hit_ratio": hot["cache_hit_ratio"],
            "steady_hit_ratio": steady["cache_hit_ratio"],
        },
    }


def write_stall_and_bg_io() -> Dict[str, Any]:
    wopts = WriteOptions(sync=False, disableWAL=False)
    n_writes = 120

    def run(label: str, quota: int, auto_compact: bool) -> Dict[str, Any]:
        eng = StoragePerfEngine(_base_options(
            background_quota_us=quota,
            cache_size=CACHE_SMALL,
            auto_compact=auto_compact,
        ))
        reasons: List[str] = []
        for i in range(1, n_writes + 1):
            res = eng.put(article_key(i), VALUE_V1, wopts)
            if res.get("reason"):
                reasons.append(res["reason"])
        stats = eng.snapshot_stats()
        return {
            "label": label,
            "background_quota_us": quota,
            "auto_compact": auto_compact,
            "writes": n_writes,
            "l0_files_end": stats["l0_files"],
            "flushes": stats["flushes"],
            "compactions": stats["compactions"],
            "stall_count": stats["stall_count"],
            "stop_count": stats["stop_count"],
            "stall_us": stats["stall_us"],
            "pending_compaction_bytes": stats["pending_compaction_bytes"],
            "write_latency": stats["write_latency"],
            "sample_reasons": reasons[:3],
            "reason_kinds": sorted(set(
                "stop" if r.startswith("Stopping") else "slowdown" for r in reasons
            )),
        }

    # 只刷盘不自动压实，L0 会堆到 slowdown=4 / stop=8；stop 时才会压实让写入继续。
    slow = run("slow-compaction", quota=200, auto_compact=False)
    fast = run("fast-compaction", quota=8000, auto_compact=True)
    return {
        "teaching_triggers": {
            "level0_slowdown_writes_trigger": 4,
            "level0_stop_writes_trigger": 8,
            "soft_pending_compaction_bytes_limit": 24_000,
            "hard_pending_compaction_bytes_limit": 48_000,
        },
        "official_defaults": official_defaults(),
        "n_writes": n_writes,
        "slow": slow,
        "fast": fast,
        "slow_has_stall": slow["stall_count"] + slow["stop_count"] > 0,
        "fast_fewer_stalls": (fast["stall_count"] + fast["stop_count"])
        < (slow["stall_count"] + slow["stop_count"]),
        "slow_p99_higher": slow["write_latency"]["p99_us"] > fast["write_latency"]["p99_us"],
        "slow_p99_us": slow["write_latency"]["p99_us"],
        "fast_p99_us": fast["write_latency"]["p99_us"],
    }


def _mixed_windows(engine: StoragePerfEngine, marks: List[int], lat_write: List[int], lat_read: List[int]) -> List[Dict[str, Any]]:
    windows = []
    # marks are clock times at the start of each 50-op chunk, plus end.
    for i in range(len(marks) - 1):
        start, end = marks[i], marks[i + 1]
        meta = engine.window_report(start, end)
        # latencies recorded in this window: we also store per-op times alongside
        windows.append(meta)
    return windows


def mixed_load_compaction_fsync() -> Dict[str, Any]:
    """Sustained mixed get/put; annotate compaction and fsync vs tail latency."""
    n_pre = 400
    n_ops = 400
    order = _random_order(n_pre, 9)

    def run(name: str, wopts: WriteOptions, quota: int = 200) -> Dict[str, Any]:
        eng = StoragePerfEngine(_base_options(background_quota_us=quota, cache_size=CACHE_SMALL))
        _fill(eng, n_pre, WriteOptions(sync=False, disableWAL=wopts.disableWAL))
        eng.compact_all()
        _cut_latency(eng)
        eng.cache.reset_counters()
        start_us = eng.clock.now()
        write_samples: List[int] = []
        read_samples: List[int] = []
        chunk = 50
        marks = [start_us]
        chunk_writes: List[int] = []
        chunk_reads: List[int] = []
        window_rows: List[Dict[str, Any]] = []
        for step in range(n_ops):
            if step % 5 != 0:
                key_i = order[step % n_pre]
                res = eng.get(article_key(key_i))
                read_samples.append(res["latency_us"])
                chunk_reads.append(res["latency_us"])
            else:
                key_i = 1000 + step
                res = eng.put(article_key(key_i), VALUE_V1, wopts)
                write_samples.append(res["latency_us"])
                chunk_writes.append(res["latency_us"])
            if (step + 1) % chunk == 0:
                end = eng.clock.now()
                start = marks[-1]
                meta = eng.window_report(start, end)
                meta["write_p99_us"] = percentile(chunk_writes, 99) if chunk_writes else 0
                meta["read_p99_us"] = percentile(chunk_reads, 99) if chunk_reads else 0
                meta["writes"] = len(chunk_writes)
                meta["reads"] = len(chunk_reads)
                meta["has_fsync"] = meta["fsyncs"] > 0
                meta["has_compaction"] = meta["compaction_us"] > 0
                meta["has_stall"] = meta["stall_us"] > 0
                meta["busy"] = meta["has_compaction"] or meta["has_stall"]
                # "fsync-only" windows still pay per-write sync, but no compaction/stall.
                window_rows.append(meta)
                marks.append(end)
                chunk_writes = []
                chunk_reads = []

        # Leave a few puts in the memtable (and unsynced WAL, if any) before crash.
        dirty_keys = []
        for j in range(3):
            k = f"article:dirty:{j}"
            eng.put(k, VALUE_V1, wopts)
            dirty_keys.append(k)
        stats = eng.snapshot_stats()
        recovered = eng.crash_and_recover()
        live_before = len(eng.live_map())
        live_after = len(recovered.live_map())
        lost = live_before - live_after
        busy = [w for w in window_rows if w["busy"]]
        quiet = [w for w in window_rows if not w["busy"]]
        fsync_only = [w for w in window_rows if w["has_fsync"] and not w["has_compaction"] and not w["has_stall"]]
        compact_windows = [w for w in window_rows if w["has_compaction"]]
        busy_write_p99 = max((w["write_p99_us"] for w in busy), default=0)
        quiet_write_p99 = max((w["write_p99_us"] for w in quiet), default=0)
        busy_read_p99 = max((w["read_p99_us"] for w in busy), default=0)
        quiet_read_p99 = max((w["read_p99_us"] for w in quiet), default=0)
        fsync_only_write_p99 = max((w["write_p99_us"] for w in fsync_only), default=0)
        compact_write_p99 = max((w["write_p99_us"] for w in compact_windows), default=0)
        duration_us = eng.clock.now() - start_us
        return {
            "name": name,
            "contract": wopts and Persistence_contract(wopts),
            "prefill_keys": n_pre,
            "mixed_ops": n_ops,
            "logical_live_bytes": stats["logical_live_bytes"],
            "cache_bytes": stats["cache_size"],
            "data_to_cache_ratio": stats["data_to_cache_ratio"],
            "write_latency": summarize_latencies(write_samples),
            "read_latency": summarize_latencies(read_samples),
            "ops_per_sec_virtual": round((n_ops / duration_us) * 1_000_000, 2) if duration_us else 0.0,
            "duration_us": duration_us,
            "device_fsyncs": stats["device_fsyncs"],
            "compactions_total": stats["compactions"],
            "stall_count": stats["stall_count"],
            "stop_count": stats["stop_count"],
            "stall_us": stats["stall_us"],
            "write_amp_storage": stats["write_amp_storage"],
            "write_amp_sst": stats["write_amp_sst"],
            "space_amp": stats["space_amp"],
            "windows": window_rows,
            "busy_windows": len(busy),
            "quiet_windows": len(quiet),
            "busy_write_p99_us": busy_write_p99,
            "quiet_write_p99_us": quiet_write_p99,
            "busy_read_p99_us": busy_read_p99,
            "quiet_read_p99_us": quiet_read_p99,
            "busy_write_p99_higher": busy_write_p99 >= quiet_write_p99,
            "fsync_only_windows": len(fsync_only),
            "compact_windows": len(compact_windows),
            "fsync_only_write_p99_us": fsync_only_write_p99,
            "compact_write_p99_us": compact_write_p99,
            "compact_p99_higher_than_fsync_only": (
                compact_write_p99 > fsync_only_write_p99 if fsync_only else compact_write_p99 > 0
            ),
            "dirty_keys_before_crash": 3,
            "live_keys_before_crash": live_before,
            "live_keys_after_crash": live_after,
            "keys_lost_on_crash": lost,
        }

    def Persistence_contract(wopts: WriteOptions) -> Dict[str, Any]:
        from engine import PersistenceContract

        return PersistenceContract(wopts.disableWAL, wopts.sync).as_dict()

    sync = run("wal-sync", WriteOptions(sync=True, disableWAL=False))
    async_wal = run("wal-async", WriteOptions(sync=False, disableWAL=False))
    no_wal = run("disableWAL", WriteOptions(sync=False, disableWAL=True))

    return {
        "mix": "每 5 个操作里 4 次随机读、1 次写入（约 80% 读 / 20% 写）",
        "dataset_keys_prefill": n_pre,
        "mixed_ops": n_ops,
        "wal_sync": sync,
        "wal_async": async_wal,
        "disableWAL": no_wal,
        "qps_sync": sync["ops_per_sec_virtual"],
        "qps_async": async_wal["ops_per_sec_virtual"],
        "qps_disableWAL": no_wal["ops_per_sec_virtual"],
        "disableWAL_qps_higher": no_wal["ops_per_sec_virtual"] > sync["ops_per_sec_virtual"],
        "disableWAL_lost_keys": no_wal["keys_lost_on_crash"],
        "sync_lost_keys": sync["keys_lost_on_crash"],
        "async_lost_keys": async_wal["keys_lost_on_crash"],
        "contract_disableWAL_changed": not contracts_equivalent(
            sync["contract"], no_wal["contract"]
        ),
        "fair_compare_sync_vs_disableWAL": False,
        "annotation": {
            "sync_fsyncs": sync["device_fsyncs"],
            "async_fsyncs": async_wal["device_fsyncs"],
            "sync_fsync_only_write_p99_us": sync["fsync_only_write_p99_us"],
            "sync_compact_write_p99_us": sync["compact_write_p99_us"],
            "sync_compact_higher_than_fsync_only": sync["compact_p99_higher_than_fsync_only"],
            "async_quiet_write_p99_us": async_wal["quiet_write_p99_us"],
            "async_compact_write_p99_us": async_wal["compact_write_p99_us"],
            "async_compact_higher": async_wal["compact_write_p99_us"] > async_wal["quiet_write_p99_us"],
        },
    }


def amplification_and_p99() -> Dict[str, Any]:
    wopts = WriteOptions(sync=False, disableWAL=False)
    n_keys = 200
    rounds = 6
    value_bytes = _kv_payload()
    write_buffer = n_keys * value_bytes + 16
    piled = StoragePerfEngine(
        _base_options(
            write_buffer_size=write_buffer,
            background_quota_us=50_000,
            auto_compact=False,
            level0_file_num_compaction_trigger=100,
            level0_slowdown_writes_trigger=100,
            level0_stop_writes_trigger=200,
            soft_pending_compaction_bytes_limit=10**12,
            hard_pending_compaction_bytes_limit=10**12,
            cache_size=CACHE_SMALL,
        )
    )
    for _ in range(rounds):
        for i in range(1, n_keys + 1):
            piled.put(article_key(i), VALUE_V1, wopts)
        piled.flush()

    missing_keys = [f"article:01{i:02d}z" for i in range(80)]

    def measure_reads(eng: StoragePerfEngine, existing: bool) -> Dict[str, Any]:
        _cut_latency(eng)
        eng.cache = type(eng.cache)(eng.options.cache_size)
        eng.sst_touched = 0
        reads_before = eng.user_reads
        if existing:
            _gets(eng, _random_order(n_keys, 4)[:80])
        else:
            # Do not fill cache: each missing get must consult every overlapping
            # SST, which is the read-amplification we want to show.
            ropts = ReadOptions(fill_cache=False)
            for k in missing_keys:
                eng.get(k, ropts)
        window_reads = eng.user_reads - reads_before
        return {
            "l0_files": eng.l0_count(),
            "sst_bytes": eng.sst_bytes(),
            "logical_live_bytes": eng.logical_live_bytes(),
            "space_amp": round(eng.sst_bytes() / max(eng.logical_live_bytes(), 1), 4),
            "write_amp_sst": eng.snapshot_stats()["write_amp_sst"],
            "write_amp_storage": eng.snapshot_stats()["write_amp_storage"],
            "read_amp": round(eng.sst_touched / max(window_reads, 1), 4),
            "files_per_get": round(eng.sst_touched / max(window_reads, 1), 4),
            "read_latency": summarize_latencies(eng.read_latencies),
            "cache_hits": eng.cache.hits,
            "cache_misses": eng.cache.misses,
        }

    before_exist = measure_reads(piled, True)
    before_miss = measure_reads(piled, False)
    piled.compact_all()
    after_exist = measure_reads(piled, True)
    after_miss = measure_reads(piled, False)
    return {
        "keys": n_keys,
        "overwrite_rounds": rounds,
        "logical_write_bytes": piled.logical_write_bytes,
        "before_compact_existing": before_exist,
        "before_compact_missing": before_miss,
        "after_compact_existing": after_exist,
        "after_compact_missing": after_miss,
        "space_amp_dropped": before_miss["space_amp"] > after_miss["space_amp"],
        "write_amp_rose_or_held": after_miss["write_amp_sst"] >= before_miss["write_amp_sst"],
        "missing_read_amp_dropped": after_miss["read_amp"] < before_miss["read_amp"],
        "missing_read_p99_dropped": after_miss["read_latency"]["p99_us"] < before_miss["read_latency"]["p99_us"],
        "before_space_amp": before_miss["space_amp"],
        "after_space_amp": after_miss["space_amp"],
        "before_write_amp_sst": before_miss["write_amp_sst"],
        "after_write_amp_sst": after_miss["write_amp_sst"],
        "before_missing_read_amp": before_miss["read_amp"],
        "after_missing_read_amp": after_miss["read_amp"],
        "before_missing_p99_us": before_miss["read_latency"]["p99_us"],
        "after_missing_p99_us": after_miss["read_latency"]["p99_us"],
        "before_existing_p99_us": before_exist["read_latency"]["p99_us"],
        "after_existing_p99_us": after_exist["read_latency"]["p99_us"],
    }


def _kv_payload() -> int:
    return len(article_key(1).encode("utf-8")) + len(VALUE_V1.encode("utf-8"))


def persistence_contract() -> Dict[str, Any]:
    n_pre = 400
    n_ops = 300

    def run(cache: int, wopts: WriteOptions) -> Dict[str, Any]:
        eng = StoragePerfEngine(_base_options(cache_size=cache, background_quota_us=400))
        _fill(eng, n_pre, WriteOptions(sync=False, disableWAL=wopts.disableWAL))
        eng.compact_all()
        if cache >= CACHE_LARGE:
            # 工作集已能放进缓存：先预热再测量，才是「加大缓存」这条公平优化的稳态。
            _gets(eng, list(range(1, n_pre + 1)))
        _cut_latency(eng)
        eng.cache.reset_counters()
        start = eng.clock.now()
        for step in range(n_ops):
            if step % 5 != 0:
                eng.get(article_key((step % n_pre) + 1))
            else:
                eng.put(article_key(2000 + step), VALUE_V1, wopts)
        duration = max(eng.clock.now() - start, 1)
        stats = eng.snapshot_stats()
        recovered = eng.crash_and_recover()
        lost = len(eng.live_map()) - len(recovered.live_map())
        contract = stats["contract"]
        return {
            "cache_bytes": cache,
            "contract": contract,
            "data_to_cache_ratio": stats["data_to_cache_ratio"],
            "logical_live_bytes": stats["logical_live_bytes"],
            "write_latency": stats["write_latency"],
            "read_latency": stats["read_latency"],
            "ops_per_sec_virtual": round((n_ops / duration) * 1_000_000, 2),
            "device_fsyncs": stats["device_fsyncs"],
            "cache_hit_ratio": stats["cache_hit_ratio"],
            "cache_hits": stats["cache_hits"],
            "cache_misses": stats["cache_misses"],
            "keys_lost_on_crash": lost,
            "live_before": len(eng.live_map()),
            "live_after": len(recovered.live_map()),
        }

    baseline = run(CACHE_SMALL, WriteOptions(sync=True, disableWAL=False))
    fair = run(CACHE_LARGE, WriteOptions(sync=True, disableWAL=False))
    unfair = run(CACHE_SMALL, WriteOptions(sync=False, disableWAL=True))
    return {
        "baseline_wal_sync_small_cache": baseline,
        "fair_opt_larger_cache": fair,
        "unfair_opt_disableWAL": unfair,
        "fair_contract_unchanged": contracts_equivalent(baseline["contract"], fair["contract"]),
        "unfair_contract_changed": not contracts_equivalent(baseline["contract"], unfair["contract"]),
        "fair_lost_keys": fair["keys_lost_on_crash"],
        "baseline_lost_keys": baseline["keys_lost_on_crash"],
        "unfair_lost_keys": unfair["keys_lost_on_crash"],
        "unfair_qps_higher": unfair["ops_per_sec_virtual"] > baseline["ops_per_sec_virtual"],
        "acceptance_persistence_contract_not_silently_changed": True,
        "cannot_equate_disableWAL_qps_with_sync": True,
        "data_to_cache_ratio_baseline": baseline["data_to_cache_ratio"],
        "data_to_cache_ratio_fair": fair["data_to_cache_ratio"],
    }


def run_all_experiments() -> Dict[str, Any]:
    # Prefer the fixed amplification helper; keep name stable in results.
    return {
        "title_v1": TITLE_V1,
        "value_bytes": VALUE_SIZE,
        "official_defaults": official_defaults(),
        "warmup_vs_steady": warmup_vs_steady(),
        "write_stall_and_bg_io": write_stall_and_bg_io(),
        "mixed_load_compaction_fsync": mixed_load_compaction_fsync(),
        "amplification_and_p99": amplification_and_p99(),
        "persistence_contract": persistence_contract(),
    }


if __name__ == "__main__":
    import json
    import os

    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("wrote", out)
