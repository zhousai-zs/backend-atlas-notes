#!/usr/bin/env python3
"""Teaching storage engine for lesson 112: warmup, stalls, amplification, tail latency.

This is a Python 3 standard-library model, not RocksDB. Latencies come from a
virtual device queue, not from a real SSD. Stall triggers are scaled down so a
short teaching run can hit slowdown and stop; official default numbers are
recorded on Options for comparison.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple


# Official RocksDB defaults (advanced_options.h / options.h on main, 2026-11-13).
OFFICIAL_LEVEL0_COMPACTION_TRIGGER = 4
OFFICIAL_LEVEL0_SLOWDOWN_TRIGGER = 20
OFFICIAL_LEVEL0_STOP_TRIGGER = 36
OFFICIAL_SOFT_PENDING_BYTES = 64 * 1073741824
OFFICIAL_HARD_PENDING_BYTES = 256 * 1073741824
OFFICIAL_MAX_WRITE_BUFFER_NUMBER = 2
OFFICIAL_DELAYED_WRITE_SLEEP_US = 1000  # wiki Write Stalls: typically 1ms


@dataclass
class Options:
    write_buffer_size: int = 4096
    max_write_buffer_number: int = 2
    min_write_buffer_number_to_merge: int = 1
    level0_file_num_compaction_trigger: int = 2
    level0_slowdown_writes_trigger: int = 4
    level0_stop_writes_trigger: int = 8
    soft_pending_compaction_bytes_limit: int = 24_000
    hard_pending_compaction_bytes_limit: int = 48_000
    delayed_write_sleep_us: int = OFFICIAL_DELAYED_WRITE_SLEEP_US
    cache_size: int = 64 * 1024
    block_size: int = 512
    max_background_jobs: int = 1
    # How much device time a foreground op donates to background compaction.
    background_quota_us: int = 200
    # When False, background work only flushes; compaction runs on compact_all
    # or when a write stop must make progress (quota_us < 0).
    auto_compact: bool = True
    # Device service times (virtual microseconds).
    device_read_us: int = 80
    device_write_us: int = 40
    device_fsync_us: int = 1000
    # Extra service per 256 bytes to make amplification visible in latency.
    device_us_per_256b: int = 4


@dataclass
class WriteOptions:
    sync: bool = True
    disableWAL: bool = False
    no_slowdown: bool = False


@dataclass
class ReadOptions:
    fill_cache: bool = True


@dataclass
class Clock:
    now_us: int = 0

    def now(self) -> int:
        return self.now_us

    def advance(self, us: int) -> None:
        if us > 0:
            self.now_us += us

    def advance_to(self, us: int) -> None:
        if us > self.now_us:
            self.now_us = us


class Device:
    """A single shared queue: user reads/writes/fsync and compaction all wait."""

    def __init__(self, clock: Clock, options: Options) -> None:
        self.clock = clock
        self.options = options
        self.busy_until = 0
        self.read_ops = 0
        self.write_ops = 0
        self.fsync_ops = 0
        self.bytes_read = 0
        self.bytes_written = 0
        self.queue_wait_us = 0

    def _service(self, base_us: int, nbytes: int) -> int:
        extra = ((max(nbytes, 1) + 255) // 256) * self.options.device_us_per_256b
        service = base_us + extra
        issued = self.clock.now()
        start = max(issued, self.busy_until)
        wait = start - issued
        self.queue_wait_us += wait
        end = start + service
        self.busy_until = end
        self.clock.advance_to(end)
        return end - issued

    def read(self, nbytes: int) -> int:
        self.read_ops += 1
        self.bytes_read += nbytes
        return self._service(self.options.device_read_us, nbytes)

    def write(self, nbytes: int) -> int:
        self.write_ops += 1
        self.bytes_written += nbytes
        return self._service(self.options.device_write_us, nbytes)

    def fsync(self) -> int:
        self.fsync_ops += 1
        return self._service(self.options.device_fsync_us, 0)


class LRUCache:
    def __init__(self, capacity: int) -> None:
        self.capacity = capacity
        self._order: List[str] = []
        self._sizes: Dict[str, int] = {}
        self.used = 0
        self.hits = 0
        self.misses = 0

    def _touch(self, key: str) -> None:
        if key in self._sizes:
            self._order.remove(key)
        self._order.append(key)

    def _evict(self) -> None:
        while self.used > self.capacity and self._order:
            old = self._order.pop(0)
            self.used -= self._sizes.pop(old)

    def lookup(self, key: str) -> bool:
        if key in self._sizes:
            self.hits += 1
            self._touch(key)
            return True
        self.misses += 1
        return False

    def insert(self, key: str, size: int) -> None:
        if self.capacity <= 0 or size > self.capacity:
            return
        if key in self._sizes:
            self._touch(key)
            return
        self._sizes[key] = size
        self.used += size
        self._order.append(key)
        self._evict()

    def drop_prefix(self, prefix: str) -> None:
        keep_order = []
        for key in self._order:
            if key.startswith(prefix):
                self.used -= self._sizes.pop(key)
            else:
                keep_order.append(key)
        self._order = keep_order

    def reset_counters(self) -> None:
        self.hits = 0
        self.misses = 0


@dataclass
class SST:
    sst_id: int
    level: int
    records: Dict[str, str]
    size: int
    blocks: List[List[str]]
    smallest: str
    largest: str

    def may_contain(self, key: str) -> bool:
        return self.smallest <= key <= self.largest


@dataclass
class MemTable:
    records: Dict[str, str] = field(default_factory=dict)
    size: int = 0
    immutable: bool = False

    def put(self, key: str, value: str) -> None:
        old = self.records.get(key)
        self.records[key] = value
        self.size += _kv_size(key, value)
        if old is not None:
            self.size -= _kv_size(key, old)

    def get(self, key: str) -> Optional[str]:
        if key in self.records:
            return self.records[key]
        return None


@dataclass
class Event:
    at_us: int
    kind: str
    detail: str
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PersistenceContract:
    disableWAL: bool
    sync: bool

    def as_dict(self) -> Dict[str, Any]:
        if self.disableWAL:
            label = "memory-only-until-flush"
            durable_on_ack = False
        elif self.sync:
            label = "wal-sync-on-every-write"
            durable_on_ack = True
        else:
            label = "wal-async-no-fsync-per-write"
            durable_on_ack = False
        return {
            "disableWAL": self.disableWAL,
            "sync": self.sync,
            "label": label,
            "durable_on_ack": durable_on_ack,
        }


def _kv_size(key: str, value: str) -> int:
    return len(key.encode("utf-8")) + len(value.encode("utf-8"))


def percentile(samples: List[int], p: float) -> int:
    if not samples:
        return 0
    ordered = sorted(samples)
    if p <= 0:
        return ordered[0]
    if p >= 100:
        return ordered[-1]
    # nearest-rank, 1-indexed
    rank = int(round((p / 100.0) * len(ordered)))
    rank = min(max(rank, 1), len(ordered))
    return ordered[rank - 1]


def summarize_latencies(samples: List[int]) -> Dict[str, Any]:
    if not samples:
        return {"count": 0, "p50_us": 0, "p99_us": 0, "p999_us": 0, "max_us": 0, "avg_us": 0.0}
    return {
        "count": len(samples),
        "p50_us": percentile(samples, 50),
        "p99_us": percentile(samples, 99),
        "p999_us": percentile(samples, 99.9),
        "max_us": max(samples),
        "avg_us": round(sum(samples) / len(samples), 2),
    }


class StoragePerfEngine:
    """Teaching KV with WAL, memtables, leveled SST, block cache, and write stalls."""

    def __init__(self, options: Optional[Options] = None) -> None:
        self.options = options or Options()
        self.clock = Clock()
        self.device = Device(self.clock, self.options)
        self.cache = LRUCache(self.options.cache_size)
        self.mem = MemTable()
        self.immutables: List[MemTable] = []
        self.levels: List[List[SST]] = [[], []]  # L0, L1
        self._next_sst = 1
        self.wal_records: List[Tuple[str, str]] = []
        self.wal_synced = 0
        self.wal_bytes = 0
        self.flush_bytes = 0
        self.compaction_read_bytes = 0
        self.compaction_write_bytes = 0
        self.logical_write_bytes = 0
        self.user_writes = 0
        self.user_reads = 0
        self.sst_touched = 0
        self.blocks_read = 0
        self.stall_count = 0
        self.stop_count = 0
        self.stall_us = 0
        self.write_latencies: List[int] = []
        self.read_latencies: List[int] = []
        self.events: List[Event] = []
        self.fsync_times: List[int] = []
        self.compaction_windows: List[Tuple[int, int]] = []
        self.stall_windows: List[Tuple[int, int, str]] = []
        self.last_contract: Optional[PersistenceContract] = None
        self.flushes = 0
        self.compactions = 0

    def _emit(self, kind: str, detail: str, **extra: Any) -> None:
        self.events.append(Event(self.clock.now(), kind, detail, extra))

    def live_map(self) -> Dict[str, str]:
        merged: Dict[str, str] = {}
        for sst in self.levels[1]:
            merged.update(sst.records)
        for sst in self.levels[0]:
            merged.update(sst.records)
        for mt in self.immutables:
            merged.update(mt.records)
        merged.update(self.mem.records)
        return merged

    def logical_live_bytes(self) -> int:
        return sum(_kv_size(k, v) for k, v in self.live_map().items())

    def sst_bytes(self) -> int:
        return sum(s.size for lv in self.levels for s in lv)

    def l0_count(self) -> int:
        return len(self.levels[0])

    def pending_compaction_bytes(self) -> int:
        # Teaching estimate: bytes a compaction would rewrite. An already-compacted
        # last level is not "pending"; otherwise a large L1 would stall forever.
        if self.l0_count() < self.options.level0_file_num_compaction_trigger:
            return 0
        l0 = sum(s.size for s in self.levels[0])
        l1 = sum(s.size for s in self.levels[1])
        return l0 + l1

    def memtable_count(self) -> int:
        return 1 + len(self.immutables)

    def _stall_reason(self) -> Optional[Tuple[str, str]]:
        """Return (kind, reason) where kind is 'stop' or 'slowdown'."""
        imm = len(self.immutables)
        max_wb = self.options.max_write_buffer_number
        if imm >= max_wb:
            return (
                "stop",
                f"Stopping writes because we have {imm} immutable memtables "
                f"(waiting for flush), max_write_buffer_number is set to {max_wb}",
            )
        if max_wb > 3 and imm >= max_wb - 1:
            return (
                "slowdown",
                f"Stalling writes because we have {imm} immutable memtables "
                f"(waiting for flush), max_write_buffer_number is set to {max_wb}",
            )
        l0 = self.l0_count()
        if l0 >= self.options.level0_stop_writes_trigger:
            return ("stop", f"Stopping writes because we have {l0} level-0 files")
        if l0 >= self.options.level0_slowdown_writes_trigger:
            return ("slowdown", f"Stalling writes because we have {l0} level-0 files")
        pending = self.pending_compaction_bytes()
        if pending >= self.options.hard_pending_compaction_bytes_limit:
            return (
                "stop",
                f"Stopping writes because of estimated pending compaction bytes {pending}",
            )
        if pending >= self.options.soft_pending_compaction_bytes_limit:
            return (
                "slowdown",
                f"Stalling writes because of estimated pending compaction bytes {pending}",
            )
        return None

    def _run_background(self, quota_us: int) -> int:
        """Spend up to quota_us of device time on flush/compaction. Returns used us."""
        start = self.clock.now()
        deadline = start + max(0, quota_us)
        while self.clock.now() < deadline or quota_us < 0:
            if self.immutables:
                self._flush_one()
            elif self.options.auto_compact or quota_us < 0:
                if (
                    self.l0_count() >= self.options.level0_file_num_compaction_trigger
                    or self.pending_compaction_bytes()
                    >= self.options.soft_pending_compaction_bytes_limit
                ):
                    if not self.levels[0]:
                        break
                    self._compact_one()
                else:
                    break
            else:
                break
            if quota_us >= 0 and self.clock.now() >= deadline:
                break
        return self.clock.now() - start

    def maybe_background(self) -> None:
        if self.options.max_background_jobs <= 0:
            return
        self._run_background(self.options.background_quota_us)

    def _apply_stall(self, wopts: WriteOptions) -> Tuple[int, Optional[str], bool]:
        """Maybe stall or reject a write. Returns (stall_us, reason, rejected)."""
        charged = 0
        last_reason = None
        start = self.clock.now()
        while True:
            self.maybe_background()
            hit = self._stall_reason()
            if hit is None:
                return charged, last_reason, False
            kind, reason = hit
            last_reason = reason
            if wopts.no_slowdown:
                self._emit("incomplete", reason, kind=kind)
                return charged, reason, True
            if kind == "slowdown":
                self.stall_count += 1
                sleep = self.options.delayed_write_sleep_us
                stall_start = self.clock.now()
                self.clock.advance(sleep)
                charged += sleep
                self.stall_us += sleep
                self.stall_windows.append((stall_start, self.clock.now(), reason))
                self._emit("slowdown", reason, sleep_us=sleep)
                return charged, reason, False
            # stop: must run background until the condition clears
            self.stop_count += 1
            stall_start = self.clock.now()
            self._emit("stop", reason)
            progressed = self._run_background(-1)
            if progressed <= 0:
                # no background work possible; advance a token so we cannot spin
                self.clock.advance(self.options.delayed_write_sleep_us)
            charged += self.clock.now() - stall_start
            self.stall_us += self.clock.now() - stall_start
            self.stall_windows.append((stall_start, self.clock.now(), reason))
            if self._stall_reason() is None:
                return charged, reason, False
            if self.clock.now() - start > 10_000_000:
                self._emit("stall_give_up", reason)
                return charged, reason, False

    def put(self, key: str, value: str, wopts: Optional[WriteOptions] = None) -> Dict[str, Any]:
        wopts = wopts or WriteOptions()
        start = self.clock.now()
        self.maybe_background()
        stall_us, reason, rejected = self._apply_stall(wopts)
        if rejected:
            latency = self.clock.now() - start
            self.write_latencies.append(latency)
            return {"ok": False, "status": "Incomplete", "reason": reason, "latency_us": latency}

        contract = PersistenceContract(wopts.disableWAL, wopts.sync)
        self.last_contract = contract

        if not wopts.disableWAL:
            self.wal_records.append((key, value))
            payload = _kv_size(key, value)
            self.wal_bytes += payload
            self.device.write(payload)
            if wopts.sync:
                fs = self.device.fsync()
                self.wal_synced = len(self.wal_records)
                self.fsync_times.append(self.clock.now())
                self._emit("fsync", "WAL sync", cost_us=fs)

        self.mem.put(key, value)
        self.logical_write_bytes += _kv_size(key, value)
        self.user_writes += 1

        if self.mem.size >= self.options.write_buffer_size:
            self.mem.immutable = True
            self.immutables.append(self.mem)
            self.mem = MemTable()
            self._emit("memtable_full", f"immutable={len(self.immutables)}")
            if self.options.max_background_jobs > 0:
                self._run_background(self.options.background_quota_us)

        latency = self.clock.now() - start
        self.write_latencies.append(latency)
        return {
            "ok": True,
            "status": "OK",
            "latency_us": latency,
            "stall_us": stall_us,
            "reason": reason,
            "contract": contract.as_dict(),
        }

    def get(self, key: str, ropts: Optional[ReadOptions] = None) -> Dict[str, Any]:
        ropts = ropts or ReadOptions()
        start = self.clock.now()
        self.maybe_background()
        self.user_reads += 1

        found = self.mem.get(key)
        if found is None:
            for mt in reversed(self.immutables):
                found = mt.get(key)
                if found is not None:
                    break

        files_touched = 0
        if found is None:
            search_order = list(reversed(self.levels[0])) + list(self.levels[1])
            for sst in search_order:
                if not sst.may_contain(key):
                    continue
                files_touched += 1
                self.sst_touched += 1
                # Teaching index/filter block: every overlapping SST is consulted.
                index_key = f"{sst.sst_id}:index"
                index_size = 64
                if not self.cache.lookup(index_key):
                    self.device.read(index_size)
                    self.blocks_read += 1
                    if ropts.fill_cache:
                        self.cache.insert(index_key, index_size)
                if key not in sst.records:
                    continue
                block_idx = self._block_index(sst, key)
                cache_key = f"{sst.sst_id}:{block_idx}"
                block_keys = sst.blocks[block_idx]
                block_size = sum(_kv_size(k, sst.records[k]) for k in block_keys)
                hit = self.cache.lookup(cache_key)
                if not hit:
                    self.device.read(block_size)
                    self.blocks_read += 1
                    if ropts.fill_cache:
                        self.cache.insert(cache_key, block_size)
                found = sst.records[key]
                break

        latency = self.clock.now() - start
        self.read_latencies.append(latency)
        return {
            "ok": True,
            "value": found,
            "found": found is not None,
            "latency_us": latency,
            "files_touched": files_touched,
        }

    def _block_index(self, sst: SST, key: str) -> int:
        for i, block in enumerate(sst.blocks):
            if key in block:
                return i
        # range may overlap; fall back to last block
        return max(0, len(sst.blocks) - 1)

    def _flush_one(self) -> None:
        if not self.immutables:
            return
        mt = self.immutables.pop(0)
        sst = self._build_sst(0, mt.records)
        self.device.write(sst.size)
        self.flush_bytes += sst.size
        self.flushes += 1
        self.levels[0].append(sst)
        self._emit("flush", f"sst={sst.sst_id} size={sst.size} l0={self.l0_count()}")

    def _build_sst(self, level: int, records: Dict[str, str]) -> SST:
        keys = sorted(records)
        size = sum(_kv_size(k, records[k]) for k in keys)
        blocks: List[List[str]] = []
        current: List[str] = []
        used = 0
        for k in keys:
            step = _kv_size(k, records[k])
            if current and used + step > self.options.block_size:
                blocks.append(current)
                current = []
                used = 0
            current.append(k)
            used += step
        if current:
            blocks.append(current)
        sst = SST(
            sst_id=self._next_sst,
            level=level,
            records=dict(records),
            size=size,
            blocks=blocks or [[]],
            smallest=keys[0] if keys else "",
            largest=keys[-1] if keys else "",
        )
        self._next_sst += 1
        return sst

    def _compact_one(self) -> None:
        if not self.levels[0]:
            return
        start = self.clock.now()
        # Take all current L0 plus overlapping L1 (teaching: all L1, single file target).
        inputs = list(self.levels[0]) + list(self.levels[1])
        merged: Dict[str, str] = {}
        for sst in self.levels[1]:
            merged.update(sst.records)
        for sst in self.levels[0]:
            merged.update(sst.records)
        read_bytes = sum(s.size for s in inputs)
        if read_bytes:
            self.device.read(read_bytes)
        self.compaction_read_bytes += read_bytes
        out = self._build_sst(1, merged)
        if out.size:
            self.device.write(out.size)
        self.compaction_write_bytes += out.size
        for sst in inputs:
            self.cache.drop_prefix(f"{sst.sst_id}:")
        self.levels[0] = []
        self.levels[1] = [out] if out.records else []
        self.compactions += 1
        self.compaction_windows.append((start, self.clock.now()))
        self._emit(
            "compaction",
            f"inputs={len(inputs)} out={out.size} write_amp_piece={out.size}",
            read_bytes=read_bytes,
            write_bytes=out.size,
        )

    def flush(self) -> None:
        if self.mem.records:
            self.mem.immutable = True
            self.immutables.append(self.mem)
            self.mem = MemTable()
        while self.immutables:
            self._flush_one()

    def compact_all(self) -> None:
        self.flush()
        if self.levels[0] or self.pending_compaction_bytes() > 0:
            self._compact_one()

    def crash_and_recover(self) -> "StoragePerfEngine":
        """Rebuild from durable state: fsynced WAL prefix + SSTs (not memtable)."""
        twin = StoragePerfEngine(self.options)
        # SSTs are already on disk (flush/compaction called device.write; teaching
        # treats completed SST writes as durable).
        for level, files in enumerate(self.levels):
            twin.levels[level] = [
                SST(
                    sst_id=s.sst_id,
                    level=s.level,
                    records=dict(s.records),
                    size=s.size,
                    blocks=[list(b) for b in s.blocks],
                    smallest=s.smallest,
                    largest=s.largest,
                )
                for s in files
            ]
        twin._next_sst = self._next_sst
        durable = list(self.wal_records[: self.wal_synced])
        for key, value in durable:
            # Replay without WAL (already durable); do not charge as new user write.
            twin.mem.put(key, value)
            if twin.mem.size >= twin.options.write_buffer_size:
                twin.mem.immutable = True
                twin.immutables.append(twin.mem)
                twin.mem = MemTable()
                twin._flush_one()
        twin.wal_records = list(durable)
        twin.wal_synced = len(durable)
        return twin

    def snapshot_stats(self) -> Dict[str, Any]:
        live = self.logical_live_bytes()
        sst = self.sst_bytes()
        write_amp_sst = (
            (self.flush_bytes + self.compaction_write_bytes) / self.logical_write_bytes
            if self.logical_write_bytes
            else 0.0
        )
        write_amp_storage = (
            (self.wal_bytes + self.flush_bytes + self.compaction_write_bytes)
            / self.logical_write_bytes
            if self.logical_write_bytes
            else 0.0
        )
        space_amp = (sst / live) if live else 0.0
        read_amp = (self.sst_touched / self.user_reads) if self.user_reads else 0.0
        cache_total = self.cache.hits + self.cache.misses
        return {
            "now_us": self.clock.now(),
            "user_writes": self.user_writes,
            "user_reads": self.user_reads,
            "logical_write_bytes": self.logical_write_bytes,
            "logical_live_bytes": live,
            "sst_bytes": sst,
            "wal_bytes": self.wal_bytes,
            "flush_bytes": self.flush_bytes,
            "compaction_read_bytes": self.compaction_read_bytes,
            "compaction_write_bytes": self.compaction_write_bytes,
            "write_amp_sst": round(write_amp_sst, 4),
            "write_amp_storage": round(write_amp_storage, 4),
            "space_amp": round(space_amp, 4),
            "read_amp": round(read_amp, 4),
            "l0_files": self.l0_count(),
            "l1_files": len(self.levels[1]),
            "flushes": self.flushes,
            "compactions": self.compactions,
            "pending_compaction_bytes": self.pending_compaction_bytes(),
            "stall_count": self.stall_count,
            "stop_count": self.stop_count,
            "stall_us": self.stall_us,
            "device_bytes_written": self.device.bytes_written,
            "device_bytes_read": self.device.bytes_read,
            "device_fsyncs": self.device.fsync_ops,
            "device_queue_wait_us": self.device.queue_wait_us,
            "cache_size": self.cache.capacity,
            "cache_used": self.cache.used,
            "cache_hits": self.cache.hits,
            "cache_misses": self.cache.misses,
            "cache_hit_ratio": round(self.cache.hits / cache_total, 4) if cache_total else 0.0,
            "data_to_cache_ratio": round(live / self.cache.capacity, 4) if self.cache.capacity else 0.0,
            "write_latency": summarize_latencies(self.write_latencies),
            "read_latency": summarize_latencies(self.read_latencies),
            "contract": self.last_contract.as_dict() if self.last_contract else None,
        }

    def reset_latency_and_cache_counters(self) -> None:
        self.write_latencies.clear()
        self.read_latencies.clear()
        self.cache.reset_counters()
        self.sst_touched = 0
        # keep user_reads for amplification over the whole life unless caller
        # wants a window; window helpers pass a copy of lists instead.

    def window_report(self, start_us: int, end_us: int) -> Dict[str, Any]:
        fsyncs = sum(1 for t in self.fsync_times if start_us <= t < end_us)
        comp_us = 0
        for a, b in self.compaction_windows:
            overlap = max(0, min(b, end_us) - max(a, start_us))
            comp_us += overlap
        stall_us = 0
        stall_n = 0
        for a, b, _ in self.stall_windows:
            overlap = max(0, min(b, end_us) - max(a, start_us))
            if overlap:
                stall_n += 1
                stall_us += overlap
        return {
            "start_us": start_us,
            "end_us": end_us,
            "fsyncs": fsyncs,
            "compaction_us": comp_us,
            "stall_us": stall_us,
            "stall_events": stall_n,
        }


def contracts_equivalent(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    return a["disableWAL"] == b["disableWAL"] and a["sync"] == b["sync"]
