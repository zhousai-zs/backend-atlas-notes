#!/usr/bin/env python3
"""Teaching PerfEngine — not Redis, not a real perf product, not a network service.

A Python 3 standard-library model of building a teaching KV binary and
profiling it with teaching analogues of perf stat / record / report. It
is used to watch how symbols, stack-unwind strategy, sampling frequency
and dropped samples change what a 30-second profile can say about a
hotspot.

The named source (checked on 2026-11-14) is the Linux perf Tutorial,
originally at https://perf.wiki.kernel.org/index.php/Tutorial, which
redirects to the wiki now published at
https://perfwiki.github.io/main/tutorial/. That page defines perf stat,
perf record and perf report, sampling period versus rate (default
1000 Hz), user and kernel modifiers, and the fact that stripped binaries
print hexadecimal addresses instead of symbol names. It uses `perf
record -g` in examples but does not define frame-pointer versus DWARF
unwind. Those options, and a mention of LOST events, are in the
perf-record(1) manual page linked from the wiki's Man pages index.
This engine is not the Linux perf tool, not a host g++ / clang
invocation, and not a 30-second wall-clock measurement. Times are
teaching virtual-clock values, not production RTT and not the
Tutorial's Ubuntu 11.04 example counters copied into results.
"""
from __future__ import annotations

from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
COMPILER_ID = "AtlasTeachCC"
COMPILER_VERSION = "1.0"
MEASURE_S = 30.00
DEFAULT_FREQ = 1000
# Teaching drain rate of the sampling ring buffer, in samples/sec.
# At the Tutorial default 1000 Hz it keeps up; a much higher rate overflows.
DRAIN_PER_S = 2000
# Workload self-share of teaching cycles (sums to 1.00).
WORKLOAD = (
    {
        "symbol": "kv_get",
        "level": "user",
        "share": 0.70,
        "stack": ("main", "handle_get", "kv_get"),
        "addr": "0x401000",
    },
    {
        "symbol": "hash_mix",
        "level": "user",
        "share": 0.10,
        "stack": ("main", "handle_get", "kv_get", "hash_mix"),
        "addr": "0x401200",
    },
    {
        "symbol": "copy_to_user",
        "level": "kernel",
        "share": 0.15,
        "stack": ("main", "handle_get", "kv_get", "copy_to_user"),
        "addr": "0xffffffff81001000",
    },
    {
        "symbol": "sys_recv",
        "level": "kernel",
        "share": 0.05,
        "stack": ("main", "handle_get", "sys_recv"),
        "addr": "0xffffffff81002000",
    },
)
PERTURB_SYMBOL = {
    "symbol": "perf_overflow_handler",
    "level": "kernel",
    "stack": ("perf_overflow_handler",),
    "addr": "0xffffffff8100f000",
}


def ts(t: float, nd: int = 4) -> float:
    return round(float(t) + 1e-12, nd)


def allocate(n: int, shares: list[float]) -> list[int]:
    """Largest-remainder allocation so counts sum to n."""
    raw = [s * n for s in shares]
    base = [int(x) for x in raw]
    rem = n - sum(base)
    order = sorted(range(len(raw)), key=lambda i: (raw[i] - base[i], -i), reverse=True)
    out = list(base)
    for i in order[:rem]:
        out[i] += 1
    return out


class PerfEngine:
    """Teaching compiler + stat/record/report for a KV get loop."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1

    def compile(
        self,
        *,
        debug_symbols: bool = True,
        frame_pointers: bool = True,
        flags: Optional[str] = None,
    ) -> dict[str, Any]:
        if flags is None:
            parts = []
            if debug_symbols:
                parts.append("-g")
            if frame_pointers:
                parts.append("-fno-omit-frame-pointer")
            else:
                parts.append("-fomit-frame-pointer")
            flags = " ".join(parts) if parts else ""
        return {
            "compiler_id": COMPILER_ID,
            "compiler_version": COMPILER_VERSION,
            "compiler_is_teaching": True,
            "compiler_note": (
                "AtlasTeachCC is a teaching compiler used by this engine. "
                "It is not a host g++ or clang, and no real object file is produced."
            ),
            "flags": flags,
            "debug_symbols": debug_symbols,
            "frame_pointers": frame_pointers,
            "key": self.key,
            "title": self.title,
            "binary": "teach-kv",
        }

    def _leaf_name(self, item: dict[str, Any], debug_symbols: bool) -> str:
        return item["symbol"] if debug_symbols else item["addr"]

    def _stack(
        self,
        item: dict[str, Any],
        *,
        debug_symbols: bool,
        frame_pointers: bool,
        unwind: str,
    ) -> list[str]:
        # Kernel frames keep their names when symbols are on; user frames
        # become teaching addresses without -g.
        names = []
        for frame in item["stack"]:
            meta = next((w for w in WORKLOAD if w["symbol"] == frame), None)
            if meta is None:
                names.append(frame)
            elif debug_symbols or meta["level"] == "kernel":
                # Kernel names come from teaching kallsyms even without -g,
                # matching the Tutorial's [kernel.kallsyms] column. User
                # symbols need the teaching -g symbol table.
                names.append(meta["symbol"] if (debug_symbols or meta["level"] == "kernel") else meta["addr"])
            else:
                names.append(meta["addr"])
        if unwind == "fp":
            if not frame_pointers:
                return []  # bogus / empty, as --fomit-frame-pointer warns
            return names
        if unwind == "dwarf":
            # DWARF CFI is emitted with teaching -g; without it, unwind fails.
            if not debug_symbols:
                return []
            return names
        raise ValueError(f"unknown unwind {unwind}")

    def stat(self, binary: dict[str, Any], *, measure_s: float = MEASURE_S) -> dict[str, Any]:
        user = sum(w["share"] for w in WORKLOAD if w["level"] == "user")
        kernel = sum(w["share"] for w in WORKLOAD if w["level"] == "kernel")
        return {
            "command": "teach-perf stat",
            "binary": binary["binary"],
            "measure_s": ts(measure_s),
            "task_clock_s": ts(measure_s),
            "cpus_utilized": 1.0,
            "cycles_are_teaching": True,
            "user_share": ts(user),
            "kernel_share": ts(kernel),
            "user_cycles": int(round(user * 1_000_000 * measure_s)),
            "kernel_cycles": int(round(kernel * 1_000_000 * measure_s)),
        }

    def record_and_report(
        self,
        binary: dict[str, Any],
        *,
        measure_s: float = MEASURE_S,
        freq: int = DEFAULT_FREQ,
        unwind: str = "fp",
        call_graph: bool = True,
    ) -> dict[str, Any]:
        intended = int(freq * measure_s)
        capacity = int(DRAIN_PER_S * measure_s)
        lost = max(0, intended - capacity)
        recorded = intended - lost
        # Teaching perturbation: only when the ring is overflowing.
        perturb = 0.05 if lost > 0 else 0.0
        shares = [w["share"] * (1.0 - perturb) for w in WORKLOAD]
        items = list(WORKLOAD)
        if perturb > 0:
            items = list(WORKLOAD) + [PERTURB_SYMBOL]
            shares.append(perturb)
        counts = allocate(recorded, shares)
        rows = []
        n_empty = 0
        user_n = 0
        kernel_n = 0
        for item, n in zip(items, counts):
            if n == 0:
                continue
            stack = (
                self._stack(
                    item,
                    debug_symbols=binary["debug_symbols"],
                    frame_pointers=binary["frame_pointers"],
                    unwind=unwind,
                )
                if call_graph
                else [self._leaf_name(item, binary["debug_symbols"])]
            )
            if call_graph and not stack:
                n_empty += n
                leaf = "[unknown]"
                stack_out: list[str] = []
            else:
                leaf = stack[-1] if stack else self._leaf_name(item, binary["debug_symbols"])
                stack_out = list(stack)
            if item["level"] == "user":
                user_n += n
            else:
                kernel_n += n
            rows.append(
                {
                    "symbol": leaf,
                    "true_symbol": item["symbol"],
                    "level": item["level"],
                    "tag": "[.]" if item["level"] == "user" else "[k]",
                    "self_samples": n,
                    "self_share": ts(n / recorded) if recorded else 0.0,
                    "stack": stack_out,
                    "stack_complete": bool(stack_out) and item["symbol"] in stack_out
                    or (bool(stack_out) and leaf == item["symbol"]),
                }
            )
        rows.sort(key=lambda r: (-r["self_samples"], r["true_symbol"]))
        named = {r["true_symbol"]: r for r in rows}
        kv = named.get("kv_get")
        hotspot_named = bool(
            kv and kv["symbol"] == "kv_get" and kv["self_share"] >= 0.60
        )
        return {
            "command_record": "teach-perf record",
            "command_report": "teach-perf report",
            "binary": binary["binary"],
            "flags": binary["flags"],
            "measure_s": ts(measure_s),
            "freq": freq,
            "unwind": unwind,
            "call_graph": call_graph,
            "cycles_are_teaching": True,
            "n_intended": intended,
            "n_recorded": recorded,
            "n_lost": lost,
            "lost_share": ts(lost / intended) if intended else 0.0,
            "n_empty_stacks": n_empty,
            "empty_stack_share": ts(n_empty / recorded) if recorded else 0.0,
            "user_samples": user_n,
            "kernel_samples": kernel_n,
            "user_share": ts(user_n / recorded) if recorded else 0.0,
            "kernel_share": ts(kernel_n / recorded) if recorded else 0.0,
            "perturb_share": ts(perturb),
            "drain_per_s": DRAIN_PER_S,
            "rows": rows,
            "hotspot": rows[0]["symbol"] if rows else None,
            "hotspot_true": rows[0]["true_symbol"] if rows else None,
            "hotspot_named": hotspot_named,
            "hotspot_is_kv_get": hotspot_named,
        }


