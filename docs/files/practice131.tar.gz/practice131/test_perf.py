#!/usr/bin/env python3
"""Acceptance checks for the lesson 131 teaching perf experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import DEFAULT_FREQ, KEY_TITLE, MEASURE_S, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "PerfEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_perf_product"] and r["not_host_perf"] and r["not_host_gxx"]
    assert r["cycles_are_teaching"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["measure_s"] == MEASURE_S == 30.00

    p = r["practice"]
    b = p["binary"]
    assert b["compiler_id"] == "AtlasTeachCC" and b["compiler_version"] == "1.0"
    assert b["compiler_is_teaching"]
    assert b["flags"] == "-g -fno-omit-frame-pointer"
    assert b["debug_symbols"] and b["frame_pointers"]
    st = p["stat"]
    assert st["measure_s"] == 30.0 and st["task_clock_s"] == 30.0
    assert st["cpus_utilized"] == 1.0
    assert st["user_share"] == 0.8 and st["kernel_share"] == 0.2
    assert st["user_cycles"] == 24_000_000 and st["kernel_cycles"] == 6_000_000
    pr = p["profile"]
    assert pr["freq"] == DEFAULT_FREQ == 1000 and pr["unwind"] == "fp"
    assert pr["measure_s"] == 30.0
    assert pr["n_intended"] == pr["n_recorded"] == 30000
    assert pr["n_lost"] == 0 and pr["lost_share"] == 0.0
    assert pr["n_empty_stacks"] == 0
    assert pr["user_samples"] == 24000 and pr["kernel_samples"] == 6000
    assert pr["user_share"] == 0.8 and pr["kernel_share"] == 0.2
    assert pr["hotspot"] == "kv_get" and pr["hotspot_is_kv_get"]
    by = {row["true_symbol"]: row for row in pr["rows"]}
    assert by["kv_get"]["self_samples"] == 21000 and by["kv_get"]["self_share"] == 0.7
    assert by["kv_get"]["tag"] == "[.]" and by["kv_get"]["stack"] == ["main", "handle_get", "kv_get"]
    assert by["copy_to_user"]["self_samples"] == 4500 and by["copy_to_user"]["tag"] == "[k]"
    assert by["hash_mix"]["self_samples"] == 3000
    assert by["sys_recv"]["self_samples"] == 1500
    assert p["practice_hotspot_checked"]

    u = r["unwind"]
    ns = u["no_symbols"]
    assert ns["hotspot"] == "0x401000" and not ns["hotspot_named"]
    assert ns["n_recorded"] == 30000 and ns["user_share"] == 0.8
    emp = u["fp_without_frame_pointers"]
    assert emp["n_empty_stacks"] == 30000 and emp["empty_stack_share"] == 1.0
    assert emp["hotspot"] == "[unknown]" and not emp["hotspot_named"]
    assert emp["user_share"] == 0.8 and emp["n_recorded"] == 30000
    dw = u["dwarf_without_frame_pointers"]
    assert dw["hotspot"] == "kv_get" and dw["n_empty_stacks"] == 0
    assert u["dwarf_without_symbols"]["n_empty_stacks"] == 30000
    assert u["pitfall_empty_stacks_not_no_bottleneck"]

    fr = r["frequency"]["at"]
    low, mid, high = fr["99"], fr["1000"], fr["10000"]
    assert low["n_intended"] == low["n_recorded"] == 2970 and low["n_lost"] == 0
    assert low["rows"][0]["symbol"] == "kv_get" and low["rows"][0]["self_samples"] == 2079
    assert low["rows"][0]["self_share"] == 0.7
    assert mid["n_recorded"] == 30000 and mid["n_lost"] == 0 and mid["perturb_share"] == 0.0
    assert high["n_intended"] == 300000 and high["n_recorded"] == 60000
    assert high["n_lost"] == 240000 and high["lost_share"] == 0.8
    assert high["perturb_share"] == 0.05 and high["user_share"] == 0.76
    assert high["rows"][0]["symbol"] == "kv_get" and high["rows"][0]["self_share"] == 0.665
    assert high["rows"][0]["self_samples"] == 39900
    assert r["frequency"]["tradeoff_freq_vs_perturbation"]

    assert r["acceptance_reports_samples_and_lost"]
    assert r["acceptance_explains_user_kernel"]
    assert r["practice_hotspot_checked"]
    assert r["pitfall_empty_stacks_not_no_bottleneck"]
    assert r["tradeoff_freq_vs_perturbation"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
