#!/usr/bin/env python3
"""Run the lesson 131 teaching perf / symbol experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    DEFAULT_FREQ,
    KEY_TITLE,
    MEASURE_S,
    TITLE_V1,
    PerfEngine,
)


def run_practice() -> dict[str, Any]:
    eng = PerfEngine()
    binary = eng.compile(debug_symbols=True, frame_pointers=True)
    stat = eng.stat(binary)
    prof = eng.record_and_report(binary, freq=DEFAULT_FREQ, unwind="fp")
    return {
        "binary": binary,
        "stat": stat,
        "profile": prof,
        "practice_hotspot_checked": prof["hotspot_is_kv_get"] and prof["n_lost"] == 0,
    }


def run_symbols_and_unwind() -> dict[str, Any]:
    eng = PerfEngine()
    stripped = eng.compile(debug_symbols=False, frame_pointers=True)
    omitted = eng.compile(debug_symbols=True, frame_pointers=False)
    no_sym = eng.record_and_report(stripped, freq=DEFAULT_FREQ, unwind="fp")
    fp_empty = eng.record_and_report(omitted, freq=DEFAULT_FREQ, unwind="fp")
    dwarf_ok = eng.record_and_report(omitted, freq=DEFAULT_FREQ, unwind="dwarf")
    dwarf_no_sym = eng.record_and_report(stripped, freq=DEFAULT_FREQ, unwind="dwarf")
    pitfall = (
        fp_empty["n_empty_stacks"] == fp_empty["n_recorded"]
        and fp_empty["hotspot"] == "[unknown]"
        and not fp_empty["hotspot_named"]
        and fp_empty["user_share"] == 0.8
        and fp_empty["n_recorded"] > 0
        and dwarf_ok["hotspot_is_kv_get"]
        and dwarf_ok["n_empty_stacks"] == 0
    )
    return {
        "no_symbols": no_sym,
        "fp_without_frame_pointers": fp_empty,
        "dwarf_without_frame_pointers": dwarf_ok,
        "dwarf_without_symbols": dwarf_no_sym,
        "pitfall_empty_stacks_not_no_bottleneck": pitfall,
    }


def run_frequency() -> dict[str, Any]:
    eng = PerfEngine()
    binary = eng.compile(debug_symbols=True, frame_pointers=True)
    rows = {}
    for freq in (99, 1000, 10000):
        rows[str(freq)] = eng.record_and_report(binary, freq=freq, unwind="fp")
    low, mid, high = rows["99"], rows["1000"], rows["10000"]
    tradeoff = (
        high["n_recorded"] > mid["n_recorded"] > low["n_recorded"]
        and high["n_lost"] > mid["n_lost"] == low["n_lost"] == 0
        and high["perturb_share"] > mid["perturb_share"] == 0.0
        and high["rows"][0]["self_share"] < mid["rows"][0]["self_share"]
    )
    return {
        "at": rows,
        "tradeoff_freq_vs_perturbation": tradeoff,
    }


def run() -> dict[str, Any]:
    practice = run_practice()
    unwind = run_symbols_and_unwind()
    freq = run_frequency()
    prof = practice["profile"]
    stat = practice["stat"]
    return {
        "engine": "PerfEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_perf_product": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "cycles_are_teaching": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "measure_s": MEASURE_S,
        "practice": practice,
        "unwind": unwind,
        "frequency": freq,
        "acceptance_reports_samples_and_lost": (
            prof["n_recorded"] == 30000 and prof["n_lost"] == 0 and "n_intended" in prof
        ),
        "acceptance_explains_user_kernel": (
            stat["user_share"] == 0.8
            and stat["kernel_share"] == 0.2
            and prof["user_share"] == 0.8
            and prof["kernel_share"] == 0.2
        ),
        "practice_hotspot_checked": practice["practice_hotspot_checked"],
        "pitfall_empty_stacks_not_no_bottleneck": unwind[
            "pitfall_empty_stacks_not_no_bottleneck"
        ],
        "tradeoff_freq_vs_perturbation": freq["tradeoff_freq_vs_perturbation"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {path}")
