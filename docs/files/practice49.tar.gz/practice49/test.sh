#!/usr/bin/env bash
# Backend Atlas 第49课实践验证：握手/半关闭/TIME_WAIT/字节流/RST/CLOSE-WAIT
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18049
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2

python3 server.py "$PORT" > /tmp/tcp49-srv.log 2>&1 &
SRV=$!
cleanup(){ kill $SRV 2>/dev/null; wait $SRV 2>/dev/null; }
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/tcp49-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

# 1) 三次握手 → ESTABLISHED
python3 - <<PY &
import socket, time
s = socket.create_connection(("127.0.0.1", $PORT))
time.sleep(0.8)
s.sendall(b"hello")
print(s.recv(64))
s.shutdown(socket.SHUT_WR)
s.close()
PY
CPID=$!
sleep 0.3
EST=$(ss -tan "sport = :$PORT or dport = :$PORT" | grep -c ESTAB || true)
[ "${EST:-0}" -ge 1 ] && ok "握手后可见 ESTABLISHED (count=$EST)" || bad "未见 ESTABLISHED count=$EST"
wait $CPID
ok "正常交互完成（三次握手 + 数据 + 关闭）"

# 2) 半关闭
OUT=$(python3 - <<PY
import socket
s = socket.create_connection(("127.0.0.1", $PORT))
s.sendall(b"half-close")
s.shutdown(socket.SHUT_WR)
print(s.recv(4096).decode())
s.close()
PY
)
echo "half-close recv: $OUT"
echo "$OUT" | grep -q "response-after-eof" && ok "半关闭：收到 FIN/EOF 后对端仍可写，本端仍可读到响应" || bad "半关闭失败: $OUT"

# 3) TIME_WAIT（主动关闭方）
python3 - <<PY
import socket
s = socket.create_connection(("127.0.0.1", $PORT))
s.sendall(b"x")
s.recv(16)
s.shutdown(socket.SHUT_RDWR)
s.close()
PY
sleep 0.3
TW=$(ss -tan state time-wait | grep -c ":$PORT" || true)
ss -tan state time-wait | grep ":$PORT" | head -5 || true
[ "${TW:-0}" -ge 1 ] && ok "主动关闭方出现 TIME_WAIT (条目=$TW)" || bad "未观察到 TIME_WAIT"

# 4) 字节流无消息边界
OUT=$(python3 - <<PY
import socket, time
s = socket.create_connection(("127.0.0.1", $PORT))
s.sendall(b"stream")
time.sleep(0.05)
s.sendall(b"PART2")
data = b""
while len(data) < 16:
    chunk = s.recv(4096)
    if not chunk: break
    data += chunk
print(data)
s.close()
PY
)
echo "stream got: $OUT"
echo "$OUT" | grep -q "got:streamPART2" && ok "字节流无消息边界：两次 send 拼成一段" || bad "字节流合并失败: $OUT"

# 5) Connection refused / RST
ERR=$(python3 - <<'PY'
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    s.connect(("127.0.0.1", 18999))
    print("unexpected_ok")
except OSError as e:
    print(type(e).__name__, e.errno, e)
s.close()
PY
)
echo "refused: $ERR"
echo "$ERR" | grep -qiE "ConnectionRefused|111|refused" && ok "未监听端口 Connection refused（通常伴随 RST）" || bad "拒绝连接异常: $ERR"

# 6) CLOSE-WAIT
python3 - <<PY &
import socket, time, subprocess
s = socket.create_connection(("127.0.0.1", $PORT))
s.sendall(b"hold-closewait")
s.shutdown(socket.SHUT_WR)
time.sleep(0.5)
print(subprocess.check_output(["ss","-tan",f"sport = :$PORT or dport = :$PORT"], text=True))
time.sleep(2)
s.close()
PY
CPID=$!
sleep 0.7
CW=$(ss -tan state close-wait | grep -c ":$PORT" || true)
ss -tan | grep ":$PORT" | head -10 || true
[ "${CW:-0}" -ge 1 ] && ok "对端发 FIN 后本端未 close → CLOSE-WAIT (count=$CW)" || bad "未见 CLOSE-WAIT count=$CW"
wait $CPID 2>/dev/null || true

echo "--- ss -s ---"; ss -s || true
echo "--- /proc/net/sockstat ---"; cat /proc/net/sockstat || true
echo "NOTE: box 无 tcpdump，抓包步骤请在有权限的机器上按课文执行。"

[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
