#!/usr/bin/env python3
"""Minimal TCP demo server for Backend Atlas lesson 49."""
import socket
import sys
import time

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18080

srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind((HOST, PORT))
srv.listen(32)
print(f"listening on {HOST}:{PORT}", flush=True)

while True:
    conn, addr = srv.accept()
    try:
        # first chunk
        data = conn.recv(4096)
        if data == b"half-close":
            # peer may still send FIN; we respond after seeing request
            conn.sendall(b"response-after-eof\n")
            conn.shutdown(socket.SHUT_WR)
        elif data == b"hold-closewait":
            # intentionally leave CLOSE-WAIT on this side by not closing yet
            # peer will FIN; we ACK but delay close so ss can observe CLOSE-WAIT
            time.sleep(2.0)
            conn.close()
            continue
        elif data == b"stream":
            # wait a moment then read more to show coalescing possible
            more = conn.recv(4096)
            conn.sendall(b"got:" + data + more)
            conn.shutdown(socket.SHUT_WR)
        elif data.startswith(b"rst"):
            # leave unread data then close -> often RST to peer if they keep reading
            conn.close()
            continue
        else:
            conn.sendall(b"ok\n")
            conn.shutdown(socket.SHUT_WR)
    except Exception as e:
        print("err", e, flush=True)
    finally:
        try:
            conn.close()
        except Exception:
            pass
