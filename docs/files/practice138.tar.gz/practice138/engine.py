#!/usr/bin/env python3
"""Teaching ZeroCopyEngine — not Redis, not a real profiler/zero-copy
product, not a network service, and not a host sendfile / splice /
perf / g++ run.

A Python 3 standard-library, virtual-clock model of sending a
teaching file from teachkv with read/write versus sendfile, plus
batching of small requests. The named source (checked on
2026-11-14) is:

* Linux man-pages — sendfile(2), at
  https://man7.org/linux/man-pages/man2/sendfile.2.html
  (Linux man-pages 6.19, page date 2026-02-08). sendfile() "copies
  data between one file descriptor and another. Because this
  copying is done within the kernel, sendfile() is more efficient
  than the combination of read(2) and write(2), which would
  require transferring data to and from user space." in_fd must
  support mmap(2)-like operations (it cannot be a socket), except
  since Linux 5.12 when out_fd is a pipe, in which case sendfile
  desugars to splice(2). A successful call may write fewer bytes
  than requested; the transfer size is at most 0x7ffff000. NOTES
  require that if out_fd is a socket or pipe with zero-copy
  support, the transferred portions of the input file "remain
  unmodified until the reader on the other end of out_fd has
  consumed the transferred data." NOTES also name TCP_CORK
  (tcp(7)) for headers before sendfile, and splice(2) for
  transfers where one or both fds is a pipe.

Follow-through pages named by sendfile(2), also read on 2026-11-14:

* splice(2) "moves data between two file descriptors without
  copying between kernel address space and user address space."
  One fd must be a pipe. "Though we talk of copying, actual copies
  are generally avoided" via reference-counted pipe pages, but
  SPLICE_F_MOVE is only a hint and "pages may still be copied";
  since Linux 2.6.21 that flag is a no-op. SPLICE_F_MORE points
  at TCP_CORK / MSG_MORE.

* tcp(7) TCP_CORK: don't send partial frames; useful for
  prepending headers before sendfile(2) or for throughput
  optimization. "There is a 200 millisecond ceiling on the time
  for which output is corked by TCP_CORK." tcp_autocorking
  coalesces small write(2)/sendmsg(2) calls to cut packet count.

This engine does not invoke host sendfile, splice, perf, or g++.
Times are teaching virtual-clock values, not production RTT, and
the 200 ms cork ceiling is the documented tcp(7) value, not a
host measurement.
"""
from __future__ import annotations

from typing import Any


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"
DIGEST_FILE = "weekly-digest.bin"

MEASURE_S = 30.00
MEASURE_NS = 30_000_000_000
FILE_BYTES = 64 * 1024 * 1024  # 67_108_864
CHUNK_BYTES = 64 * 1024
N_CHUNKS = FILE_BYTES // CHUNK_BYTES
SYSCALL_NS = 10_000
USER_COPY_NS_PER_BYTE = 2
KERN_COPY_NS_PER_BYTE = 1
SENDFILE_MAX = 0x7FFFF000
WIRE_FILES = 44  # teaching wire-limited complete files in 30 s
SMALL_BYTES = 64
HIGH_OFFERED_RPS = 200_000
LOW_OFFERED_RPS = 10
BATCH_N = 16
CORK_CEILING_MS = 200  # from tcp(7), not a host measurement
LOW_TIMEOUT_MS = 10
HOST_UNAME_R = "6.12.113+"


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def rw_file_ns() -> int:
    per_chunk = 2 * SYSCALL_NS + 2 * CHUNK_BYTES * USER_COPY_NS_PER_BYTE
    return N_CHUNKS * per_chunk


def sf_file_ns() -> int:
    # One sendfile() for the whole teaching file (under 0x7ffff000).
    return SYSCALL_NS + FILE_BYTES * KERN_COPY_NS_PER_BYTE


def cpu_bound(name: str, cost_ns: int, *, user_copies: int, kern_copies: int) -> dict[str, Any]:
    n = MEASURE_NS // cost_ns
    busy = n * cost_ns
    payload = n * FILE_BYTES
    return {
        "name": name,
        "mode": name,
        "n_files": n,
        "payload_bytes": payload,
        "throughput_mb_s": ts(payload / MEASURE_S / 1_000_000, 2),
        "cpu_ns": busy,
        "cpu_util": share(busy, MEASURE_NS),
        "user_copy_bytes": user_copies * payload,
        "kernel_copy_bytes": kern_copies * payload,
        "syscalls": n * (N_CHUNKS * 2 if name == "read_write" else 1),
        "file_bytes": FILE_BYTES,
        "cost_ns_per_file": cost_ns,
        "times_are_teaching_virtual_clock": True,
        "not_host_sendfile": True,
        "not_host_splice": True,
    }


def wire_limited(name: str, cost_ns: int, *, user_copies: int, kern_copies: int) -> dict[str, Any]:
    n = WIRE_FILES
    busy = n * cost_ns
    payload = n * FILE_BYTES
    return {
        "name": name,
        "mode": name,
        "n_files": n,
        "payload_bytes": payload,
        "throughput_mb_s": ts(payload / MEASURE_S / 1_000_000, 2),
        "cpu_ns": busy,
        "cpu_util": share(busy, MEASURE_NS),
        "user_copy_bytes": user_copies * payload,
        "kernel_copy_bytes": kern_copies * payload,
        "syscalls": n * (N_CHUNKS * 2 if name == "read_write" else 1),
        "file_bytes": FILE_BYTES,
        "cost_ns_per_file": cost_ns,
        "wire_limited": True,
        "times_are_teaching_virtual_clock": True,
        "not_host_sendfile": True,
    }


def batch_high(batch_n: int) -> dict[str, Any]:
    offered = HIGH_OFFERED_RPS
    inter_ns = 1_000_000_000 // offered  # 5000
    cap = 1_000_000_000 // SYSCALL_NS  # syscalls per second if unbatched
    if batch_n == 1:
        tput = min(offered, cap)
        completed = tput * int(MEASURE_S)
        syscalls = completed
        mean_wait_us = 0.0
        max_wait_us = 0.0
        cpu = completed * SYSCALL_NS
    else:
        # Periodic arrivals; a batch of batch_n fills in (batch_n-1)*inter_ns.
        tput = offered
        completed = offered * int(MEASURE_S)
        syscalls = completed // batch_n
        mean_wait_us = ts(((batch_n - 1) / 2) * inter_ns / 1000, 2)
        max_wait_us = ts((batch_n - 1) * inter_ns / 1000, 2)
        cpu = syscalls * SYSCALL_NS
    return {
        "offered_rps": offered,
        "batch_n": batch_n,
        "timeout_ms": None,
        "completed": completed,
        "throughput_rps": float(tput),
        "syscalls": syscalls,
        "cpu_util": share(cpu, MEASURE_NS),
        "mean_batch_wait_us": mean_wait_us,
        "max_batch_wait_us": max_wait_us,
        "measure_s": MEASURE_S,
        "times_are_teaching_virtual_clock": True,
    }


def batch_low(timeout_ms: int) -> dict[str, Any]:
    offered = LOW_OFFERED_RPS
    inter_ms = 1000 // offered  # 100
    # Flush when batch_n==16 or waited timeout_ms since first in batch.
    if timeout_ms < inter_ms:
        per_batch = 1
        mean_wait_ms = float(timeout_ms)
        max_wait_ms = float(timeout_ms)
    else:
        # Inclusive: arrivals at 0, inter, 2*inter, ... flush at timeout.
        per_batch = timeout_ms // inter_ms + 1
        # waits: timeout, timeout-inter, ..., 0
        waits = [timeout_ms - i * inter_ms for i in range(per_batch)]
        mean_wait_ms = ts(sum(waits) / per_batch, 2)
        max_wait_ms = float(timeout_ms)
    completed = offered * int(MEASURE_S)
    syscalls = completed // per_batch
    cpu = syscalls * SYSCALL_NS
    return {
        "offered_rps": offered,
        "batch_n": BATCH_N,
        "timeout_ms": timeout_ms,
        "timeout_source": (
            "tcp(7) TCP_CORK 200 ms ceiling"
            if timeout_ms == CORK_CEILING_MS
            else "teaching timeout"
        ),
        "completed": completed,
        "throughput_rps": float(offered),
        "requests_per_flush": per_batch,
        "syscalls": syscalls,
        "cpu_util": share(cpu, MEASURE_NS),
        "mean_batch_wait_ms": mean_wait_ms,
        "max_batch_wait_ms": max_wait_ms,
        "measure_s": MEASURE_S,
        "times_are_teaching_virtual_clock": True,
    }


class ZeroCopyEngine:
    """Teaching model of sendfile vs read/write, and of batch wait."""

    def compare(self) -> dict[str, Any]:
        rw_cost = rw_file_ns()
        sf_cost = sf_file_ns()
        assert FILE_BYTES <= SENDFILE_MAX
        rw_cpu = cpu_bound("read_write", rw_cost, user_copies=2, kern_copies=1)
        sf_cpu = cpu_bound("sendfile", sf_cost, user_copies=0, kern_copies=1)
        rw_wire = wire_limited("read_write", rw_cost, user_copies=2, kern_copies=1)
        sf_wire = wire_limited("sendfile", sf_cost, user_copies=0, kern_copies=1)
        high1 = batch_high(1)
        high16 = batch_high(BATCH_N)
        low_uncorked = {
            "offered_rps": LOW_OFFERED_RPS,
            "batch_n": 1,
            "timeout_ms": None,
            "completed": LOW_OFFERED_RPS * int(MEASURE_S),
            "throughput_rps": float(LOW_OFFERED_RPS),
            "syscalls": LOW_OFFERED_RPS * int(MEASURE_S),
            "cpu_util": share(
                LOW_OFFERED_RPS * int(MEASURE_S) * SYSCALL_NS, MEASURE_NS
            ),
            "mean_batch_wait_ms": 0.0,
            "max_batch_wait_ms": 0.0,
            "times_are_teaching_virtual_clock": True,
        }
        low10 = batch_low(LOW_TIMEOUT_MS)
        low200 = batch_low(CORK_CEILING_MS)
        mutation = {
            "sendfile_out_is_socket_with_zerocopy_support": True,
            "file_modified_after_sendfile_returns_before_consume": True,
            "official_contract": (
                "transferred portions of in_fd must remain unmodified "
                "until the reader has consumed the transferred data"
            ),
            "violates_unmodified_until_consumed": True,
            "receiver_bytes_not_invented": True,
        }
        return {
            "process": PROCESS,
            "key": KEY_TITLE,
            "title": TITLE_V1,
            "digest_file": DIGEST_FILE,
            "measure_s": MEASURE_S,
            "file_bytes": FILE_BYTES,
            "chunk_bytes": CHUNK_BYTES,
            "syscall_ns": SYSCALL_NS,
            "user_copy_ns_per_byte": USER_COPY_NS_PER_BYTE,
            "kern_copy_ns_per_byte": KERN_COPY_NS_PER_BYTE,
            "sendfile_max_bytes": SENDFILE_MAX,
            "host": {
                "uname_r": HOST_UNAME_R,
                "host_sendfile_invoked": False,
                "host_splice_invoked": False,
                "host_perf_invoked": False,
                "host_gxx_invoked": False,
            },
            "cpu_bound": {"read_write": rw_cpu, "sendfile": sf_cpu},
            "wire_limited": {"read_write": rw_wire, "sendfile": sf_wire},
            "zero_copy_does_not_mean_zero_copies_on_path": (
                sf_cpu["kernel_copy_bytes"] == sf_cpu["payload_bytes"]
                and sf_cpu["user_copy_bytes"] == 0
                and rw_cpu["user_copy_bytes"] == 2 * rw_cpu["payload_bytes"]
            ),
            "sendfile_beats_rw_throughput_when_cpu_bound": (
                sf_cpu["throughput_mb_s"] > rw_cpu["throughput_mb_s"]
            ),
            "sendfile_uses_less_cpu_when_wire_limited": (
                sf_wire["throughput_mb_s"] == rw_wire["throughput_mb_s"]
                and sf_wire["cpu_util"] < rw_wire["cpu_util"]
            ),
            "batch_high_unbatched": high1,
            "batch_high_n16": high16,
            "batch_low_unbatched": low_uncorked,
            "batch_low_timeout_10ms": low10,
            "batch_low_timeout_200ms_cork_ceiling": low200,
            "cork_ceiling_ms": CORK_CEILING_MS,
            "cork_ceiling_from_tcp7": True,
            "mutation": mutation,
            "quantifies_small_request_batch_wait": (
                high16["mean_batch_wait_us"] > 0
                and low200["mean_batch_wait_ms"] > low_uncorked["mean_batch_wait_ms"]
            ),
            "batching_helps_high_load_hurts_low_load_latency": (
                high16["throughput_rps"] > high1["throughput_rps"]
                and low200["mean_batch_wait_ms"] > 0
                and low200["throughput_rps"] == low_uncorked["throughput_rps"]
            ),
            "ignoring_file_mutation_is_unsafe": mutation["violates_unmodified_until_consumed"],
        }
