#!/usr/bin/env python3
"""Acceptance checks for the lesson 138 teaching zero-copy experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "ZeroCopyEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["digest_file"] == "weekly-digest.bin"
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["file_bytes"] == 67_108_864 and r["chunk_bytes"] == 65_536
    assert r["syscall_ns"] == 10_000
    assert r["sendfile_max_bytes"] == 0x7FFFF000
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_zerocopy_product"]
    assert r["not_host_sendfile"] and r["not_host_splice"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]
    assert r["host"]["uname_r"] == "6.12.113+"
    assert r["host"]["host_sendfile_invoked"] is False
    assert r["host"]["host_splice_invoked"] is False
    assert r["host"]["host_gxx_invoked"] is False

    rw, sf = r["cpu_bound"]["read_write"], r["cpu_bound"]["sendfile"]
    assert rw["n_files"] == 103 and rw["payload_bytes"] == 6_912_212_992
    assert rw["throughput_mb_s"] == 230.41 and rw["cpu_util"] == 0.9919
    assert rw["user_copy_bytes"] == 13_824_425_984
    assert rw["kernel_copy_bytes"] == rw["payload_bytes"]
    assert rw["syscalls"] == 210_944
    assert sf["n_files"] == 446 and sf["payload_bytes"] == 29_930_553_344
    assert sf["throughput_mb_s"] == 997.69 and sf["cpu_util"] == 0.9978
    assert sf["user_copy_bytes"] == 0
    assert sf["kernel_copy_bytes"] == sf["payload_bytes"]
    assert sf["syscalls"] == 446
    assert sf["throughput_mb_s"] > rw["throughput_mb_s"]
    assert r["acceptance_zero_copy_not_entire_path"]

    wrw, wsf = r["wire_limited"]["read_write"], r["wire_limited"]["sendfile"]
    assert wrw["n_files"] == wsf["n_files"] == 44
    assert wrw["throughput_mb_s"] == wsf["throughput_mb_s"] == 98.43
    assert wrw["cpu_util"] == 0.4237 and wsf["cpu_util"] == 0.0984
    assert wsf["user_copy_bytes"] == 0 and wrw["user_copy_bytes"] == 2 * wrw["payload_bytes"]

    hi1, hi16 = r["batch_high_unbatched"], r["batch_high_n16"]
    assert hi1["offered_rps"] == 200_000 and hi1["throughput_rps"] == 100_000.0
    assert hi1["completed"] == 3_000_000 and hi1["cpu_util"] == 1.0
    assert hi1["mean_batch_wait_us"] == 0.0
    assert hi16["throughput_rps"] == 200_000.0 and hi16["completed"] == 6_000_000
    assert hi16["syscalls"] == 375_000 and hi16["cpu_util"] == 0.125
    assert hi16["mean_batch_wait_us"] == 37.5 and hi16["max_batch_wait_us"] == 75.0

    lo0, lo10, lo200 = (
        r["batch_low_unbatched"],
        r["batch_low_timeout_10ms"],
        r["batch_low_timeout_200ms_cork_ceiling"],
    )
    assert lo0["throughput_rps"] == 10.0 and lo0["mean_batch_wait_ms"] == 0.0
    assert lo0["syscalls"] == 300
    assert lo10["timeout_ms"] == 10 and lo10["requests_per_flush"] == 1
    assert lo10["mean_batch_wait_ms"] == 10.0 and lo10["syscalls"] == 300
    assert lo200["timeout_ms"] == 200 and r["cork_ceiling_from_tcp7"]
    assert lo200["requests_per_flush"] == 3 and lo200["syscalls"] == 100
    assert lo200["mean_batch_wait_ms"] == 100.0 and lo200["max_batch_wait_ms"] == 200.0
    assert r["acceptance_quantifies_batch_wait"]
    assert r["tradeoff_batch_tput_vs_low_load_latency"]

    mut = r["mutation"]
    assert mut["violates_unmodified_until_consumed"] is True
    assert mut["receiver_bytes_not_invented"] is True
    assert r["pitfall_file_mutation"]

    flags = r["flags"]
    assert flags["zero_copy_does_not_mean_zero_copies_on_path"]
    assert flags["sendfile_beats_rw_throughput_when_cpu_bound"]
    assert flags["sendfile_uses_less_cpu_when_wire_limited"]
    assert flags["quantifies_small_request_batch_wait"]
    assert flags["batching_helps_high_load_hurts_low_load_latency"]
    assert flags["ignoring_file_mutation_is_unsafe"]


if __name__ == "__main__":
    main()
