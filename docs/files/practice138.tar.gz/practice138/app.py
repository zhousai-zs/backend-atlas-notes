#!/usr/bin/env python3
"""Run the lesson 138 teaching zero-copy / batching experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1, ZeroCopyEngine


def run() -> dict[str, Any]:
    eng = ZeroCopyEngine()
    cmp = eng.compare()
    return {
        "engine": "ZeroCopyEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "digest_file": cmp["digest_file"],
        "measure_s": MEASURE_S,
        "file_bytes": cmp["file_bytes"],
        "chunk_bytes": cmp["chunk_bytes"],
        "syscall_ns": cmp["syscall_ns"],
        "sendfile_max_bytes": cmp["sendfile_max_bytes"],
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_zerocopy_product": True,
        "not_host_sendfile": True,
        "not_host_splice": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "host": cmp["host"],
        "cpu_bound": cmp["cpu_bound"],
        "wire_limited": cmp["wire_limited"],
        "batch_high_unbatched": cmp["batch_high_unbatched"],
        "batch_high_n16": cmp["batch_high_n16"],
        "batch_low_unbatched": cmp["batch_low_unbatched"],
        "batch_low_timeout_10ms": cmp["batch_low_timeout_10ms"],
        "batch_low_timeout_200ms_cork_ceiling": cmp["batch_low_timeout_200ms_cork_ceiling"],
        "cork_ceiling_ms": cmp["cork_ceiling_ms"],
        "cork_ceiling_from_tcp7": cmp["cork_ceiling_from_tcp7"],
        "mutation": cmp["mutation"],
        "flags": {
            "zero_copy_does_not_mean_zero_copies_on_path": cmp["zero_copy_does_not_mean_zero_copies_on_path"],
            "sendfile_beats_rw_throughput_when_cpu_bound": cmp["sendfile_beats_rw_throughput_when_cpu_bound"],
            "sendfile_uses_less_cpu_when_wire_limited": cmp["sendfile_uses_less_cpu_when_wire_limited"],
            "quantifies_small_request_batch_wait": cmp["quantifies_small_request_batch_wait"],
            "batching_helps_high_load_hurts_low_load_latency": cmp["batching_helps_high_load_hurts_low_load_latency"],
            "ignoring_file_mutation_is_unsafe": cmp["ignoring_file_mutation_is_unsafe"],
        },
        "acceptance_zero_copy_not_entire_path": cmp["zero_copy_does_not_mean_zero_copies_on_path"],
        "acceptance_quantifies_batch_wait": cmp["quantifies_small_request_batch_wait"],
        "pitfall_file_mutation": cmp["ignoring_file_mutation_is_unsafe"],
        "tradeoff_batch_tput_vs_low_load_latency": cmp["batching_helps_high_load_hurts_low_load_latency"],
    }


if __name__ == "__main__":
    run()
