#!/usr/bin/env bash
# 第32课实践：两个编译选项不一致的共享库，用 nm/readelf/c++filt 定位 ABI 差异
set -euo pipefail
cd "$(dirname "$0")"; rm -rf build; mkdir build; cd build

# ---- 1. 同一份源码，两种 _GLIBCXX_USE_CXX11_ABI 编出两个共享库 ----
cat > greet.h <<'H'
#pragma once
#include <string>
std::string greet(const std::string& name);
H
cat > greet.cpp <<'C'
#include "greet.h"
std::string greet(const std::string& name) { return "hello, " + name; }
C
g++ -std=c++17 -fPIC -shared -D_GLIBCXX_USE_CXX11_ABI=1 greet.cpp -o libgreet_new.so
g++ -std=c++17 -fPIC -shared -D_GLIBCXX_USE_CXX11_ABI=0 greet.cpp -o libgreet_old.so
echo "== 导出符号（修饰名）=="
nm -D --defined-only libgreet_new.so | grep greet
nm -D --defined-only libgreet_old.so | grep greet
echo "== c++filt 还原 =="
nm -D --defined-only libgreet_new.so | grep greet | awk '{print $3}' | c++filt
nm -D --defined-only libgreet_old.so | grep greet | awk '{print $3}' | c++filt

# 用新 ABI 编调用方，链接旧 ABI 库 -> 链接期找不到符号
cat > main.cpp <<'C'
#include "greet.h"
#include <iostream>
int main() { std::cout << greet("wechat") << "\n"; }
C
g++ -std=c++17 -D_GLIBCXX_USE_CXX11_ABI=1 main.cpp -L. -lgreet_new -Wl,-rpath,'$ORIGIN' -o app_ok
./app_ok | tee out_ok.txt
grep -q "hello, wechat" out_ok.txt
if g++ -std=c++17 -D_GLIBCXX_USE_CXX11_ABI=1 main.cpp -L. -lgreet_old -o app_bad 2> link_err.txt; then
  echo "FAIL: 预期链接失败"; exit 1
fi
echo "== 新 ABI 调用方链接旧 ABI 库：链接失败（符合预期）=="
grep -m1 "undefined reference" link_err.txt

# ---- 2. 结构布局被编译选项改变：extern "C" 也救不了 ----
cat > cfg.h <<'H'
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
struct Cfg { char flag; int64_t timeout_ms; };
int64_t cfg_timeout(const struct Cfg* c);
unsigned cfg_size(void);
#ifdef __cplusplus
}
#endif
H
cat > cfg.cpp <<'C'
#include "cfg.h"
extern "C" int64_t cfg_timeout(const Cfg* c) { return c->timeout_ms; }
extern "C" unsigned cfg_size(void) { return sizeof(Cfg); }
C
g++ -fPIC -shared cfg.cpp -o libcfg_normal.so
g++ -fPIC -shared -fpack-struct=1 cfg.cpp -o libcfg_packed.so
cat > use_cfg.cpp <<'C'
#include "cfg.h"
#include <cstdio>
int main() {
  Cfg c{}; c.flag = 1; c.timeout_ms = 3000;
  std::printf("caller sizeof=%zu lib sizeof=%u timeout=%lld\n",
              sizeof(Cfg), cfg_size(), (long long)cfg_timeout(&c));
}
C
g++ use_cfg.cpp -L. -lcfg_normal -Wl,-rpath,'$ORIGIN' -o cfg_ok
g++ use_cfg.cpp -L. -lcfg_packed -Wl,-rpath,'$ORIGIN' -o cfg_bad 2>/dev/null
echo "== 布局一致 =="; ./cfg_ok | tee cfg_ok.txt
echo "== 库用 -fpack-struct=1：链接成功但读错字段 =="; ./cfg_bad | tee cfg_bad.txt
grep -q "caller sizeof=16 lib sizeof=16 timeout=3000" cfg_ok.txt
grep -q "lib sizeof=9" cfg_bad.txt
! grep -q "timeout=3000" cfg_bad.txt
echo "== nm 两边符号完全一样，看不出差异 =="
diff <(nm -D --defined-only libcfg_normal.so | awk '{print $3}' | grep cfg_) \
     <(nm -D --defined-only libcfg_packed.so | awk '{print $3}' | grep cfg_) && echo "符号相同"

# ---- 3. 符号版本：给 C 接口打版本号 ----
cat > v1.map <<'M'
CFG_1.0 { global: cfg_timeout; cfg_size; local: *; };
M
g++ -fPIC -shared cfg.cpp -Wl,--version-script=v1.map -Wl,-soname,libcfgv.so.1 -o libcfgv.so.1
echo "== readelf 查看 SONAME 与符号版本 =="
readelf -d libcfgv.so.1 | grep SONAME
readelf --dyn-syms -W libcfgv.so.1 | grep cfg_
readelf --dyn-syms -W libcfgv.so.1 | grep -q "cfg_timeout@@CFG_1.0"
echo "== 依赖的 glibc/libstdc++ 版本（新 ABI 库）=="
readelf -V libgreet_new.so | grep -oE "(GLIBCXX|CXXABI|GLIBC)_[0-9.]+" | sort -u | tail -5
echo ALL_CHECKS_PASSED
