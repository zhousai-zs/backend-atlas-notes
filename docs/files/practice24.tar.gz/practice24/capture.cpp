// 延迟执行的 Lambda：引用捕获局部变量 vs 值捕获
#include <cstdio>
#include <functional>
#include <memory>
#include <string>
#include <vector>

std::vector<std::function<void()>> tasks;   // 模拟“稍后执行”的任务队列

void enqueue_by_ref() {
    std::string msg = "hello-from-local-variable-long-enough";
    tasks.push_back([&msg] { std::printf("%s\n", msg.c_str()); });  // 悬垂引用
}
void enqueue_by_value() {
    std::string msg = "hello-by-value";
    tasks.push_back([msg] { std::printf("%s\n", msg.c_str()); });
}

struct Session : std::enable_shared_from_this<Session> {
    std::string uid = "u42";
    void async_bad()  { tasks.push_back([this] { std::printf("%s\n", uid.c_str()); }); }
    void async_good() { tasks.push_back([self = shared_from_this()] { std::printf("%s\n", self->uid.c_str()); }); }
};

int main(int argc, char** argv) {
    std::string mode = argc > 1 ? argv[1] : "value";
    if (mode == "ref") enqueue_by_ref();
    else if (mode == "value") enqueue_by_value();
    else if (mode == "this") { auto s = std::make_shared<Session>(); s->async_bad(); }
    else if (mode == "self") { auto s = std::make_shared<Session>(); s->async_good(); }
    for (auto& t : tasks) t();   // 函数已返回 / 对象已销毁后才执行
}
