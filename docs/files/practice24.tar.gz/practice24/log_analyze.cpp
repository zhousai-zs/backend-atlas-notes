// 日志分析：sort + lower_bound/upper_bound + transform
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>

struct Log { long ts; int latency_ms; std::string uid; };

// 严格弱序：只按 ts 比较，用 <，不能用 <=
bool by_ts(const Log& a, const Log& b) { return a.ts < b.ts; }

// 返回 [from, to) 时间窗口内的日志条数；要求 logs 已按 ts 排序（前置条件）
size_t count_window(const std::vector<Log>& logs, long from, long to) {
    auto lo = std::lower_bound(logs.begin(), logs.end(), from,
                               [](const Log& l, long t) { return l.ts < t; });
    auto hi = std::lower_bound(lo, logs.end(), to,
                               [](const Log& l, long t) { return l.ts < t; });
    return static_cast<size_t>(hi - lo);
}

std::vector<int> latencies(const std::vector<Log>& logs) {
    std::vector<int> out;
    out.reserve(logs.size());
    std::transform(logs.begin(), logs.end(), std::back_inserter(out),
                   [](const Log& l) { return l.latency_ms; });
    return out;
}

int main() {
    // 空输入
    std::vector<Log> empty;
    std::sort(empty.begin(), empty.end(), by_ts);
    assert(count_window(empty, 0, 100) == 0);
    assert(latencies(empty).empty());

    // 重复值
    std::vector<Log> logs = {{30, 5, "u3"}, {10, 7, "u1"}, {20, 9, "u2"},
                             {20, 4, "u4"}, {20, 6, "u5"}, {40, 8, "u6"}};
    std::stable_sort(logs.begin(), logs.end(), by_ts);
    assert(std::is_sorted(logs.begin(), logs.end(), by_ts));
    assert(count_window(logs, 20, 21) == 3);   // 3 条 ts=20
    assert(count_window(logs, 20, 40) == 4);   // 20,20,20,30
    assert(count_window(logs, 41, 99) == 0);
    // stable_sort 保持相等元素原顺序 u2,u4,u5
    assert(logs[1].uid == "u2" && logs[2].uid == "u4" && logs[3].uid == "u5");

    auto lat = latencies(logs);
    assert(lat.size() == logs.size() && lat[0] == 7);
    std::printf("ALL_TESTS_PASSED\n");
}
