// 用 <= 做比较器：违反严格弱序（comp(a,a) 必须为 false）
#include <algorithm>
#include <cstdio>
#include <vector>
int main() {
    std::vector<int> v(64, 7);
    auto bad = [](int a, int b) { return a <= b; };
    std::printf("bad(7,7)=%d  (严格弱序要求为 0)\n", bad(7, 7));
    std::sort(v.begin(), v.end(), bad);   // 未定义行为；_GLIBCXX_DEBUG 下直接报错
    std::printf("sort returned\n");
}
