#!/usr/bin/env bash
set -u
export ASAN_OPTIONS=detect_stack_use_after_return=1
cd "$(dirname "$0")"
F="-std=c++17 -g -O0 -Wall"
pass=0; fail=0
ok(){ echo "PASS: $1"; pass=$((pass+1)); }
ng(){ echo "FAIL: $1"; fail=$((fail+1)); }

g++ $F -fsanitize=address,undefined log_analyze.cpp -o log_analyze && ./log_analyze | grep -q ALL_TESTS_PASSED && ok "日志分析：空输入/重复值/窗口计数/transform" || ng "日志分析"

g++ $F -D_GLIBCXX_DEBUG bad_comparator.cpp -o bad_cmp 2>/dev/null
./bad_cmp >bad.out 2>&1; grep -qi "comparison\|irreflexive\|strict weak" bad.out && ok "<= 比较器被 _GLIBCXX_DEBUG 检出违反严格弱序" || ng "错误比较器未检出"

g++ $F -fsanitize=address capture.cpp -o capture
./capture value | grep -q hello-by-value && ok "值捕获：函数返回后仍安全" || ng "值捕获"
./capture ref  >ref.out  2>&1; grep -q "stack-use-after-return\|stack-use-after-scope\|heap-use-after-free" ref.out && ok "引用捕获局部变量：ASan 检出悬垂" || ng "引用捕获未检出"
./capture this >this.out 2>&1; grep -q heap-use-after-free this.out && ok "捕获裸 this：对象销毁后 heap-use-after-free" || ng "this 捕获未检出"
./capture self | grep -q u42 && ok "捕获 shared_from_this：保活成功" || ng "self 捕获"
echo "pass=$pass fail=$fail"; [ $fail -eq 0 ]
