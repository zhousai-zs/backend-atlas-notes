#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY ANTHROPIC_API_KEY GOOGLE_API_KEY GEMINI_API_KEY || true
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["openai_agents"]=="0.24.0" and r["is_live_model"] is False
assert r["retellings_dropped"]>=1 and r["unique_evidence_n"]<r["raw_evidence_n"]
assert r["double_write_rejected"] and r["timeout_degraded"]
assert r["contradictions_handled"]
print("POSTCHECK_OK")
PY
