#!/usr/bin/env python3
"""Official openai-agents 0.24.0 orchestrator-worker (Agent.as_tool) with ScriptedModel.

No live model, no paid API, default trace exporter replaced.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from importlib.metadata import version
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
os.environ.pop("ANTHROPIC_API_KEY", None)

from agents import Agent, RunConfig, Runner, function_tool, set_trace_processors  # noqa: E402
from agents.testing import ScriptedModel, assistant_message, function_call  # noqa: E402
from agents.tracing.processor_interface import TracingProcessor  # noqa: E402

ROOT = Path(__file__).resolve().parent
PKG = version("openai-agents")
assert PKG == "0.24.0", PKG
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
if WORK.exists():
    shutil.rmtree(WORK)
WORK.mkdir(parents=True)
if REPORTS.exists():
    shutil.rmtree(REPORTS)
REPORTS.mkdir(parents=True)
shutil.copytree(ROOT / "materials", WORK / "materials")


class LocalProcessor(TracingProcessor):
    def __init__(self):
        self.spans = []

    def on_trace_start(self, trace):
        pass

    def on_trace_end(self, trace):
        pass

    def on_span_start(self, span):
        pass

    def on_span_end(self, span):
        data = span.span_data.export() if hasattr(span.span_data, "export") else {"type": type(span.span_data).__name__}
        self.spans.append(data)

    def shutdown(self):
        pass

    def force_flush(self):
        pass


proc = LocalProcessor()
set_trace_processors([proc])
CFG = RunConfig(tracing_disabled=True, trace_include_sensitive_data=False)


class Workspace:
    """Explicit file ownership. Concurrent writers of the same path must serialize or fail."""

    def __init__(self, root: Path):
        self.root = root
        self.owners: dict[str, str] = {}
        self.writes: list[dict] = []

    def claim(self, worker: str, rel: str) -> Path:
        if rel in self.owners and self.owners[rel] != worker:
            raise PermissionError(f"conflict: {rel} already owned by {self.owners[rel]}, refused for {worker}")
        self.owners[rel] = worker
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    def write(self, worker: str, rel: str, text: str) -> str:
        path = self.claim(worker, rel)
        path.write_text(text, encoding="utf-8")
        self.writes.append({"worker": worker, "path": rel, "bytes": len(text)})
        return str(path)


WS = Workspace(WORK / "outputs")


def evidence(claim: str, source_path: str, excerpt: str, kind: str = "observation") -> dict:
    return {"claim": claim, "source_path": source_path, "excerpt": excerpt, "kind": kind}


def dedup_evidence(items: list[dict]) -> list[dict]:
    seen = set()
    out = []
    for ev in items:
        key = (ev["source_path"], ev["excerpt"].strip())
        if key in seen:
            ev = {**ev, "duplicate_of_original": True}
            # retelling is not an independent source
            continue
        seen.add(key)
        out.append(ev)
    return out


# ----- tools the workers may use (each worker only reads its own input) -----
@function_tool
def read_logs() -> str:
    """Read the log material assigned to the log worker. Not metrics or source."""
    return (WORK / "materials/app.log").read_text(encoding="utf-8")


@function_tool
def read_metrics() -> str:
    """Read the metrics material assigned to the metrics worker."""
    return (WORK / "materials/metrics.json").read_text(encoding="utf-8")


@function_tool
def read_code() -> str:
    """Read the source excerpt assigned to the code worker."""
    return (WORK / "materials/src_kv_snippet.cpp").read_text(encoding="utf-8")


@function_tool
def read_all_materials() -> str:
    """Baseline single-agent tool: read every investigation file."""
    parts = []
    for name in ("app.log", "metrics.json", "src_kv_snippet.cpp"):
        p = WORK / "materials" / name
        parts.append(f"----- {name} -----\n{p.read_text(encoding='utf-8')}")
    return "\n".join(parts)


TIMEOUT_WORKER = {"enabled": False, "slept": False}


@function_tool
def inspect_metrics_with_budget(timeout_ms: int) -> str:
    """Metrics inspection that honors a host timeout. Used to inject worker timeout."""
    if TIMEOUT_WORKER["enabled"]:
        TIMEOUT_WORKER["slept"] = True
        # Do not actually sleep 30s; the host records that the budget was exceeded
        # before the worker produced a complete result.
        return "ERROR: worker timeout after 200ms budget; metrics inspection degraded"
    return (WORK / "materials/metrics.json").read_text(encoding="utf-8")


def write_worker_report(worker: str, payload: dict) -> str:
    rel = f"{worker}.json"
    WS.write(worker, rel, json.dumps(payload, ensure_ascii=False, indent=2))
    return rel


def run_single_agent_baseline() -> dict:
    t0 = time.perf_counter()
    model = ScriptedModel([
        [function_call("read_all_materials", {}, call_id="b1")],
        [assistant_message(json.dumps({
            "role": "single-agent",
            "evidence": [
                evidence(
                    "lookup fails because exists is not implemented",
                    "materials/app.log",
                    'error="undefined reference path: exists not implemented"',
                ),
                evidence(
                    "p99 latency rose from 12ms to 110ms in the window",
                    "materials/metrics.json",
                    '["2026-11-15T16:02:00Z", 110]',
                    "observation",
                ),
                evidence(
                    "handle() has no exists branch",
                    "materials/src_kv_snippet.cpp",
                    '// "exists" is accepted by the parser but not implemented here',
                ),
            ],
            "conclusion": "The exists command is parsed or requested but not implemented, which matches the log errors. Latency also rose; that is a concurrent observation, not by itself a proven cause.",
        }, ensure_ascii=False))],
    ])
    agent = Agent(name="Baseline", model=model, tools=[read_all_materials], instructions="Investigate using all materials.")
    res = Runner.run_sync(agent, "Investigate the kv incident.", run_config=CFG)
    model.assert_complete()
    payload = json.loads(res.final_output)
    path = write_worker_report("baseline", payload)
    elapsed = time.perf_counter() - t0
    return {
        "path": path,
        "elapsed_s": elapsed,
        "tool_calls": 1,
        "scripted_model_steps": 2,
        "evidence_n": len(payload["evidence"]),
        "final": payload,
    }


def run_multi(timeout: bool, try_double_write: bool) -> dict:
    t0 = time.perf_counter()
    TIMEOUT_WORKER["enabled"] = timeout
    TIMEOUT_WORKER["slept"] = False

    logs_model = ScriptedModel([
        [function_call("read_logs", {}, call_id="l1")],
        [assistant_message(json.dumps({
            "worker": "logs",
            "evidence": [
                evidence(
                    "two lookup failures mention exists not implemented",
                    "materials/app.log",
                    'error="undefined reference path: exists not implemented"',
                ),
                # retelling of the same excerpt must not become a second independent source
                evidence(
                    "restated: exists is not implemented (same log line)",
                    "materials/app.log",
                    'error="undefined reference path: exists not implemented"',
                ),
            ],
        }, ensure_ascii=False))],
    ])
    logs_agent = Agent(name="LogsWorker", model=logs_model, tools=[read_logs], instructions="Only inspect logs.")

    metrics_tool = inspect_metrics_with_budget if timeout else read_metrics
    if timeout:
        metrics_model = ScriptedModel([
            [function_call("inspect_metrics_with_budget", {"timeout_ms": 200}, call_id="m1")],
            [assistant_message(json.dumps({
                "worker": "metrics",
                "degraded": True,
                "reason": "worker timeout",
                "evidence": [],
            }, ensure_ascii=False))],
        ])
    else:
        metrics_model = ScriptedModel([
            [function_call("read_metrics", {}, call_id="m1")],
            [assistant_message(json.dumps({
                "worker": "metrics",
                "degraded": False,
                "evidence": [
                    evidence(
                        "p99 latency rose from 12ms to 110ms",
                        "materials/metrics.json",
                        '["2026-11-15T16:02:00Z", 110]',
                    ),
                    evidence(
                        "in_flight rose from 3 to 21",
                        "materials/metrics.json",
                        '["2026-11-15T16:02:00Z", 21]',
                    ),
                    # contradictory claim vs logs/code, still must carry its own source
                    evidence(
                        "CPU doubling proves a tight compute loop is the root cause",
                        "materials/metrics.json",
                        '"name": "cpu_pct"',
                        "inference",
                    ),
                ],
            }, ensure_ascii=False))],
        ])
    metrics_agent = Agent(name="MetricsWorker", model=metrics_model, tools=[metrics_tool], instructions="Only inspect metrics.")

    code_model = ScriptedModel([
        [function_call("read_code", {}, call_id="c1")],
        [assistant_message(json.dumps({
            "worker": "code",
            "evidence": [
                evidence(
                    "handle() has no exists branch",
                    "materials/src_kv_snippet.cpp",
                    '// "exists" is accepted by the parser but not implemented here',
                ),
            ],
        }, ensure_ascii=False))],
    ])
    code_agent = Agent(name="CodeWorker", model=code_model, tools=[read_code], instructions="Only inspect the source excerpt.")

    logs_tool = logs_agent.as_tool("consult_logs", "Inspect only the log file and return evidence JSON.")
    metrics_as_tool = metrics_agent.as_tool("consult_metrics", "Inspect only metrics and return evidence JSON.")
    code_tool = code_agent.as_tool("consult_code", "Inspect only the source excerpt and return evidence JSON.")

    orch_model = ScriptedModel([
        [function_call("consult_logs", {"input": "inspect logs"}, call_id="o1")],
        [function_call("consult_metrics", {"input": "inspect metrics"}, call_id="o2")],
        [function_call("consult_code", {"input": "inspect code"}, call_id="o3")],
        [assistant_message("MERGED")],  # placeholder; we merge in the host from worker files
    ])
    orch = Agent(
        name="Orchestrator",
        model=orch_model,
        tools=[logs_tool, metrics_as_tool, code_tool],
        instructions="Call each specialist once, then merge. Do not treat retellings as independent evidence.",
    )
    res = Runner.run_sync(orch, "Investigate the kv incident with three specialists.", run_config=CFG)
    logs_model.assert_complete()
    metrics_model.assert_complete()
    code_model.assert_complete()
    orch_model.assert_complete()

    # Extract worker JSON from tool outputs / we also persist them.
    def extract_json_blobs():
        blobs = []
        for item in res.new_items:
            text = getattr(item, "output", None) or getattr(item, "content", None) or str(item)
            s = text if isinstance(text, str) else json.dumps(text, default=str)
            if '"worker"' in s or '"evidence"' in s:
                # may be wrapped
                start = s.find("{")
                end = s.rfind("}")
                if start >= 0 and end > start:
                    try:
                        blobs.append(json.loads(s[start:end + 1]))
                    except json.JSONDecodeError:
                        pass
        return blobs

    # Prefer parsing tool-produced worker payloads from the scripted assistant messages
    # by re-running the known files we persist below.
    # We'll collect from captured outputs of as_tool, falling back to item scan.
    worker_payloads = extract_json_blobs()

    # Persist each worker's report to its own file (no shared write).
    by_name = {}
    for payload in worker_payloads:
        name = payload.get("worker")
        if not name:
            continue
        write_worker_report(name, payload)
        by_name[name] = payload

    double_write = None
    if try_double_write:
        WS.write("logs", "logs.json", json.dumps(by_name.get("logs", {}), ensure_ascii=False))
        try:
            WS.write("metrics", "logs.json", "should-not-overwrite")
            double_write = "allowed"
        except PermissionError as e:
            double_write = f"rejected:{e}"

    collected = []
    for name in ("logs", "metrics", "code"):
        if name in by_name:
            collected.extend(by_name[name].get("evidence") or [])
    unique = dedup_evidence(collected)
    raw_n = len(collected)
    unique_n = len(unique)
    degraded = bool(timeout and (by_name.get("metrics", {}).get("degraded") or TIMEOUT_WORKER["slept"]))
    contradictions = []
    if not timeout:
        # CPU inference vs actual cpu_pct ~21 from 18 — and vs code/log root cause
        contradictions.append({
            "claim": "CPU doubling proves a tight compute loop is the root cause",
            "problem": "inference presented as proof; cpu_pct only moved 18->21, and logs/code point to a missing exists implementation",
            "kept_as": "disputed inference, not independent confirmation",
        })

    merged = {
        "role": "orchestrator-merge",
        "degraded": degraded,
        "degrade_reason": "metrics worker timeout" if degraded else None,
        "raw_evidence_n": raw_n,
        "unique_evidence_n": unique_n,
        "retellings_dropped": raw_n - unique_n,
        "evidence": unique,
        "contradictions": contradictions,
        "conclusion": (
            "Metrics worker timed out; report is degraded and only log/code evidence is merged."
            if degraded
            else "Logs and code independently show exists is not implemented. Metrics show latency and in-flight rising; that is an observation, not proof of a CPU-bound root cause. A retold log line was not counted twice. A contradictory CPU-root-cause inference was not treated as confirmation."
        ),
    }
    write_worker_report("orchestrator", merged)
    elapsed = time.perf_counter() - t0
    return {
        "elapsed_s": elapsed,
        "tool_calls_orchestrator": 3,
        "scripted_model_steps_total": 2 * 3 + 4,  # each worker 2 + orch 4
        "worker_names": sorted(by_name),
        "double_write": double_write,
        "merged": merged,
        "final_output_placeholder": res.final_output,
    }


def main():
    baseline = run_single_agent_baseline()
    multi = run_multi(timeout=False, try_double_write=True)
    degraded = run_multi(timeout=True, try_double_write=False)

    comparison = {
        "baseline_tool_calls": baseline["tool_calls"],
        "multi_orchestrator_tool_calls": multi["tool_calls_orchestrator"],
        "baseline_scripted_steps": baseline["scripted_model_steps"],
        "multi_scripted_steps_total": multi["scripted_model_steps_total"],
        "baseline_elapsed_s": baseline["elapsed_s"],
        "multi_elapsed_s": multi["elapsed_s"],
        "note": "Elapsed time here is scripted/local and must not be reported as the only quality signal. Total tool calls and scripted steps are the comparable cost proxies. No live-model tokens were consumed.",
    }

    results = {
        "lesson": 186,
        "id": "l-multi",
        "openai_agents": PKG,
        "is_live_model": False,
        "scripted_model_is_not_an_llm": True,
        "orchestration": "Agent.as_tool (official orchestrator-worker; not a hidden built-in multi-agent runtime of Pi)",
        "retellings_dropped": multi["merged"]["retellings_dropped"],
        "unique_evidence_n": multi["merged"]["unique_evidence_n"],
        "raw_evidence_n": multi["merged"]["raw_evidence_n"],
        "double_write_rejected": isinstance(multi["double_write"], str) and multi["double_write"].startswith("rejected:"),
        "double_write": multi["double_write"],
        "timeout_degraded": degraded["merged"]["degraded"] is True,
        "timeout_conclusion": degraded["merged"]["conclusion"],
        "contradictions_handled": len(multi["merged"]["contradictions"]) == 1,
        "comparison": comparison,
        "baseline_evidence_n": baseline["evidence_n"],
        "verified_on_this_machine": [
            "official Agent.as_tool orchestrator-worker with ScriptedModel",
            "retold evidence not counted twice",
            "same-file concurrent write rejected by workspace ownership",
            "worker timeout yields a degraded merged report",
            "report compares baseline vs multi on tool calls and steps, not only elapsed time",
        ],
        "not_verified_on_this_machine": [
            "live multi-agent quality or token cost on a paid model",
            "Anthropic in-house research-system production numbers (their case is not transferred to this task)",
        ],
    }

    checks = {
        "retellings_dropped": results["retellings_dropped"] >= 1,
        "unique_lt_raw": results["unique_evidence_n"] < results["raw_evidence_n"],
        "double_write_rejected": results["double_write_rejected"],
        "timeout_degraded": results["timeout_degraded"],
        "contradictions_handled": results["contradictions_handled"],
        "comparison_has_tool_calls": comparison["multi_orchestrator_tool_calls"] >= 3,
        "is_live_model_false": results["is_live_model"] is False,
        "pkg": PKG == "0.24.0",
    }
    if not all(checks.values()):
        raise SystemExit(f"checks failed: {checks}\n{json.dumps(results, indent=2, default=str)}")

    (ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    (REPORTS / "comparison.json").write_text(json.dumps(comparison, ensure_ascii=False, indent=2), encoding="utf-8")
    print("RETELLINGS_DROPPED", results["retellings_dropped"])
    print("DOUBLE_WRITE", results["double_write"])
    print("TIMEOUT_DEGRADED", results["timeout_degraded"])
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
