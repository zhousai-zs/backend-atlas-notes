// src/kv.cpp (excerpt used as investigation input, not a live build)
std::string KV::handle(const Request& req) {
  if (req.cmd == "get") {
    auto v = get(req.key);
    return v ? *v : "NOT_FOUND";
  }
  if (req.cmd == "set") {
    set(req.key, req.value);
    return "OK";
  }
  // "exists" is accepted by the parser but not implemented here
  return "ERR unknown command";
}
