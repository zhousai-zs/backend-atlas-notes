"""短连接 vs 长连接（池化）压测对比。"""
from __future__ import annotations

import argparse
import statistics
import threading
import time
from typing import List, Tuple

from connection_pool import BorrowTimeout, ConnectionPool, FakeConn


def _percentile(sorted_vals: List[float], p: float) -> float:
    if not sorted_vals:
        return 0.0
    k = (len(sorted_vals) - 1) * p
    f = int(k)
    c = min(f + 1, len(sorted_vals) - 1)
    if f == c:
        return sorted_vals[f]
    return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * (k - f)


def short_conn_request(handshake_ms: float, work_ms: float) -> float:
    """每次请求新建+销毁连接。"""
    t0 = time.monotonic()
    time.sleep(handshake_ms / 1000.0)  # 握手
    time.sleep(work_ms / 1000.0)  # 业务
    # teardown 忽略
    return (time.monotonic() - t0) * 1000.0


def pooled_request(pool: ConnectionPool, work_ms: float) -> float:
    t0 = time.monotonic()
    conn = pool.borrow()
    try:
        time.sleep(work_ms / 1000.0)
        conn.use()
    finally:
        pool.release(conn)
    return (time.monotonic() - t0) * 1000.0


def run_workers(
    n_workers: int,
    n_req: int,
    fn,
) -> Tuple[List[float], float]:
    latencies: List[float] = []
    lock = threading.Lock()
    errors = {"n": 0}

    def worker():
        local: List[float] = []
        for _ in range(n_req):
            try:
                local.append(fn())
            except BorrowTimeout:
                errors["n"] += 1
        with lock:
            latencies.extend(local)

    threads = [threading.Thread(target=worker) for _ in range(n_workers)]
    t0 = time.monotonic()
    for th in threads:
        th.start()
    for th in threads:
        th.join()
    wall = time.monotonic() - t0
    return latencies, wall, errors["n"]


def summarize(name: str, latencies: List[float], wall: float, handshakes: int, timeouts: int) -> dict:
    latencies = sorted(latencies)
    total = len(latencies)
    cpu_proxy = sum(latencies)  # 粗略：累计活跃时间
    report = {
        "mode": name,
        "n": total,
        "timeouts": timeouts,
        "handshakes": handshakes,
        "wall_s": round(wall, 4),
        "qps": round(total / wall, 2) if wall > 0 else 0,
        "p50_ms": round(_percentile(latencies, 0.50), 3),
        "p99_ms": round(_percentile(latencies, 0.99), 3),
        "mean_ms": round(statistics.mean(latencies), 3) if latencies else 0,
        "cpu_proxy_ms": round(cpu_proxy, 2),
    }
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--reqs", type=int, default=20)
    ap.add_argument("--handshake-ms", type=float, default=5.0)
    ap.add_argument("--work-ms", type=float, default=2.0)
    ap.add_argument("--pool-size", type=int, default=8)
    ap.add_argument("--borrow-timeout", type=float, default=2.0)
    args = ap.parse_args()

    # --- 短连接 ---
    lats, wall, to = run_workers(
        args.workers,
        args.reqs,
        lambda: short_conn_request(args.handshake_ms, args.work_ms),
    )
    short = summarize(
        "short",
        lats,
        wall,
        handshakes=args.workers * args.reqs,
        timeouts=to,
    )

    # --- 长连接（池化）---
    pool = ConnectionPool(
        max_size=args.pool_size,
        idle_timeout=30.0,
        borrow_timeout=args.borrow_timeout,
        handshake_ms=args.handshake_ms,
    )
    # 预热：填满池，避免冷启动握手污染 p99
    warm = []
    for _ in range(args.pool_size):
        warm.append(pool.borrow())
    for c in warm:
        pool.release(c)
    warm_hs = pool.handshake_count

    lats, wall, to = run_workers(
        args.workers,
        args.reqs,
        lambda: pooled_request(pool, args.work_ms),
    )
    long_r = summarize(
        "pooled",
        lats,
        wall,
        handshakes=pool.handshake_count,  # 含预热；对比仍远小于 short
        timeouts=to,
    )
    long_r["warm_handshakes"] = warm_hs
    pool.close()

    print("=== short vs pooled report ===")
    for r in (short, long_r):
        print(
            f"{r['mode']}: n={r['n']} handshakes={r['handshakes']} "
            f"timeouts={r['timeouts']} wall={r['wall_s']}s qps={r['qps']} "
            f"p50={r['p50_ms']}ms p99={r['p99_ms']}ms mean={r['mean_ms']}ms "
            f"cpu_proxy={r['cpu_proxy_ms']}ms"
        )

    # 断言：池化握手次数显著更少，p99 通常更好
    assert long_r["handshakes"] < short["handshakes"], (
        f"pooled handshakes {long_r['handshakes']} should be < short {short['handshakes']}"
    )
    assert long_r["p99_ms"] < short["p99_ms"], (
        f"pooled p99 {long_r['p99_ms']} should be < short p99 {short['p99_ms']}"
    )
    print("BENCH_OK")


if __name__ == "__main__":
    main()
