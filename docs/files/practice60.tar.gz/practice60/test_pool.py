#!/usr/bin/env python3
"""验收：借用超时；过期/失效连接可替换且无泄漏；短连 vs 长连压测报告。"""
from __future__ import annotations

import subprocess
import sys
import threading
import time
from pathlib import Path

from connection_pool import BorrowTimeout, ConnectionGuard, ConnectionPool


def test_borrow_timeout() -> None:
    pool = ConnectionPool(max_size=1, idle_timeout=10, borrow_timeout=0.15, handshake_ms=1)
    c1 = pool.borrow()
    t0 = time.monotonic()
    raised = False
    try:
        pool.borrow()
    except BorrowTimeout:
        raised = True
    elapsed = time.monotonic() - t0
    assert raised, "expected BorrowTimeout"
    assert 0.10 <= elapsed <= 0.5, f"timeout waited {elapsed}"
    pool.release(c1)
    pool.close()
    print("test_borrow_timeout OK", {"wait_s": round(elapsed, 3)})


def test_idle_reclaim_and_replace_broken() -> None:
    pool = ConnectionPool(max_size=2, idle_timeout=0.15, borrow_timeout=1.0, handshake_ms=1)
    c = pool.borrow()
    cid = c.conn_id
    pool.release(c)
    time.sleep(0.25)  # 超过 idle_timeout
    c2 = pool.borrow()
    # 旧连接应被回收，握手次数至少 2（首次 + 替换）
    assert pool.reclaimed_idle >= 1 or c2.conn_id != cid
    assert pool.handshake_count >= 2
    # 标记失效并归还
    c2.mark_broken()
    pool.release(c2, broken=True)
    assert pool.replaced_broken >= 1
    c3 = pool.borrow()
    assert c3.ping()
    pool.release(c3)
    pool.close()
    assert pool.leaked() == 0
    print(
        "test_idle_reclaim_and_replace_broken OK",
        {
            "reclaimed": pool.reclaimed_idle,
            "replaced": pool.replaced_broken,
            "handshakes": pool.handshake_count,
            "destroyed": pool.destroyed,
        },
    )


def test_no_leak_with_guard() -> None:
    pool = ConnectionPool(max_size=4, idle_timeout=5, borrow_timeout=1, handshake_ms=1)
    errors = []

    def worker(i: int) -> None:
        try:
            with ConnectionGuard(pool) as conn:
                time.sleep(0.01)
                if i % 7 == 0:
                    conn.mark_broken()
                    raise RuntimeError("simulated rpc error")
        except RuntimeError:
            pass
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
    for th in threads:
        th.start()
    for th in threads:
        th.join()
    # 关闭前不应有借出未还
    assert pool.in_use_count() == 0, f"leaked in_use={pool.in_use_count()}"
    pool.close()
    assert pool.leaked() == 0
    assert not errors, errors
    print("test_no_leak_with_guard OK", {"destroyed": pool.destroyed, "size": pool.size()})


def test_bench_short_vs_long() -> None:
    here = Path(__file__).resolve().parent
    cmd = [
        sys.executable,
        str(here / "bench.py"),
        "--workers",
        "6",
        "--reqs",
        "12",
        "--handshake-ms",
        "4",
        "--work-ms",
        "1",
        "--pool-size",
        "6",
        "--borrow-timeout",
        "3",
    ]
    out = subprocess.check_output(cmd, text=True)
    print(out.strip())
    assert "BENCH_OK" in out
    assert "handshakes=" in out
    assert "p99=" in out
    print("test_bench_short_vs_long OK")


if __name__ == "__main__":
    test_borrow_timeout()
    test_idle_reclaim_and_replace_broken()
    test_no_leak_with_guard()
    test_bench_short_vs_long()
    print("ALL_CHECKS_PASSED")
