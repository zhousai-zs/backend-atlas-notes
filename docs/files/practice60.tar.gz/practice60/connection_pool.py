"""带借用超时的连接池模拟：容量、空闲回收、失效替换、无泄漏。"""
from __future__ import annotations

import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional


@dataclass
class FakeConn:
    """模拟下游 TCP/RPC 连接。"""

    conn_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    created_at: float = field(default_factory=time.monotonic)
    last_used_at: float = field(default_factory=time.monotonic)
    broken: bool = False
    handshake_ms: float = 5.0
    in_use: bool = False
    _reserved: bool = False  # 已占名额、握手中

    def ping(self) -> bool:
        return not self.broken

    def mark_broken(self) -> None:
        self.broken = True

    def use(self) -> None:
        self.last_used_at = time.monotonic()


class BorrowTimeout(Exception):
    pass


class PoolClosed(Exception):
    pass


class ConnectionPool:
    """
    简单连接池：
    - max_size: 最大连接数
    - idle_timeout: 空闲超过该秒数可回收
    - borrow_timeout: 借用等待上限（秒）；超时抛 BorrowTimeout
    - 归还时若 broken / idle 过期则销毁并允许重建
    """

    def __init__(
        self,
        max_size: int = 8,
        idle_timeout: float = 2.0,
        borrow_timeout: float = 0.5,
        handshake_ms: float = 5.0,
        health_check_on_borrow: bool = True,
    ) -> None:
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        self.max_size = max_size
        self.idle_timeout = idle_timeout
        self.borrow_timeout = borrow_timeout
        self.handshake_ms = handshake_ms
        self.health_check_on_borrow = health_check_on_borrow

        self._idle: Deque[FakeConn] = deque()
        self._all: List[FakeConn] = []
        self._cv = threading.Condition()
        self._closed = False
        self._creating = 0  # 握手中占位，计入容量

        self.handshake_count = 0
        self.borrow_ok = 0
        self.borrow_timeout_count = 0
        self.replaced_broken = 0
        self.reclaimed_idle = 0
        self.destroyed = 0
        self.total_handshake_ms = 0.0
        self._stat_lock = threading.Lock()

    def _live_count_locked(self) -> int:
        return len(self._all) + self._creating

    def _destroy_locked(self, c: FakeConn) -> None:
        c.broken = True
        c.in_use = False
        if c in self._all:
            self._all.remove(c)
        self.destroyed += 1

    def _reclaim_idle_locked(self, now: float) -> None:
        kept: Deque[FakeConn] = deque()
        while self._idle:
            c = self._idle.popleft()
            if now - c.last_used_at > self.idle_timeout:
                self.reclaimed_idle += 1
                self._destroy_locked(c)
            else:
                kept.append(c)
        self._idle = kept

    def _do_handshake(self) -> FakeConn:
        time.sleep(self.handshake_ms / 1000.0)
        c = FakeConn(handshake_ms=self.handshake_ms)
        with self._stat_lock:
            self.handshake_count += 1
            self.total_handshake_ms += self.handshake_ms
        return c

    def borrow(self) -> FakeConn:
        deadline = time.monotonic() + self.borrow_timeout
        need_create = False
        with self._cv:
            while True:
                if self._closed:
                    raise PoolClosed("pool closed")

                now = time.monotonic()
                self._reclaim_idle_locked(now)

                while self._idle:
                    c = self._idle.popleft()
                    if self.health_check_on_borrow and not c.ping():
                        self.replaced_broken += 1
                        self._destroy_locked(c)
                        continue
                    if now - c.last_used_at > self.idle_timeout:
                        self.reclaimed_idle += 1
                        self._destroy_locked(c)
                        continue
                    c.in_use = True
                    c.use()
                    self.borrow_ok += 1
                    return c

                if self._live_count_locked() < self.max_size:
                    self._creating += 1
                    need_create = True
                    break

                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self.borrow_timeout_count += 1
                    raise BorrowTimeout(
                        f"borrow timeout after {self.borrow_timeout}s "
                        f"(max_size={self.max_size}, in_use={self.in_use_count()})"
                    )
                self._cv.wait(timeout=remaining)

        # 握手在锁外，避免堵死其他借还
        assert need_create
        try:
            c = self._do_handshake()
            with self._cv:
                self._creating -= 1
                if self._closed:
                    # 池已关：立刻销毁
                    self.destroyed += 1
                    self._cv.notify()
                    raise PoolClosed("pool closed during handshake")
                c.in_use = True
                c.use()
                self._all.append(c)
                self.borrow_ok += 1
                return c
        except Exception:
            with self._cv:
                self._creating -= 1
                self._cv.notify()
            raise

    def release(self, c: FakeConn, *, broken: bool = False) -> None:
        with self._cv:
            if broken or c.broken:
                if not c.broken:
                    c.mark_broken()
                self.replaced_broken += 1
                self._destroy_locked(c)
                self._cv.notify()
                return
            if self._closed:
                self._destroy_locked(c)
                self._cv.notify()
                return
            c.in_use = False
            c.use()
            self._idle.append(c)
            self._cv.notify()

    def close(self) -> None:
        with self._cv:
            self._closed = True
            while self._idle:
                self._destroy_locked(self._idle.popleft())
            self._cv.notify_all()

    def in_use_count(self) -> int:
        with self._cv:
            return sum(1 for c in self._all if c.in_use)

    def idle_count(self) -> int:
        with self._cv:
            return len(self._idle)

    def size(self) -> int:
        with self._cv:
            return len(self._all)

    def leaked(self) -> int:
        with self._cv:
            return sum(1 for c in self._all if c.in_use)


class ConnectionGuard:
    """RAII 风格：确保借出必还，避免泄漏。"""

    def __init__(self, pool: ConnectionPool) -> None:
        self.pool = pool
        self.conn: Optional[FakeConn] = None
        self._broken = False

    def __enter__(self) -> FakeConn:
        self.conn = self.pool.borrow()
        return self.conn

    def mark_broken(self) -> None:
        self._broken = True
        if self.conn is not None:
            self.conn.mark_broken()

    def __exit__(self, exc_type, exc, tb) -> None:
        if self.conn is not None:
            broken = self._broken or self.conn.broken or exc_type is not None
            self.pool.release(self.conn, broken=broken)
            self.conn = None
