from __future__ import annotations

import json
import shutil
from pathlib import Path

import rocksdict
from kv import KvService, MemoryBackend, RocksBackend

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"
DB = ROOT / "workspace" / "rocks"


def main() -> None:
    if (ROOT / "workspace").exists():
        shutil.rmtree(ROOT / "workspace")
    (ROOT / "workspace").mkdir()
    mem = MemoryBackend()
    rocks = RocksBackend(DB)
    kv = KvService(mem, rocks, mode="memory")
    checks = []

    def check(name, ok, detail=""):
        checks.append((name, bool(ok), detail))
        print(("PASS " if ok else "FAIL ") + name + (f" {d}" if (d:=detail) else ""))

    # Old client protocol on memory
    kv.set("a", "1")
    kv.set("b", "2")
    check("memory_get", kv.get("a") == "1")
    # Expand: dual write + dual read
    kv.set_mode("dual")
    # Backfill existing keys into rocks (expand phase)
    for k, v in mem.snapshot().items():
        rocks.set(k, v)
    check("dual_match_after_backfill", kv.get("a") == "1" and not kv.mismatches, str(kv.mismatches))
    kv.set("c", "3")  # written to both
    check("dual_write_visible_both", mem.get("c") == "3" and rocks.get("c") == "3")
    # Inject a mismatch to prove the comparer works, then repair
    rocks.set("b", "WRONG")
    got = kv.get("b")
    check("dual_detects_mismatch", got == "2" and any(m["key"] == "b" for m in kv.mismatches), str(kv.mismatches))
    rocks.set("b", "2")  # repair before switch
    kv.mismatches.clear()
    # Switch application to rocks; old get/set still work
    kv.set_mode("rocks")
    check("old_client_get_on_rocks", kv.get("a") == "1" and kv.get("c") == "3")
    kv.set("d", "4")
    check("old_client_set_on_rocks", kv.get("d") == "4" and rocks.get("d") == "4")
    # Memory does not automatically see 'd' — that's the data vs app boundary.
    check("memory_does_not_have_post_switch_write", mem.get("d") is None)
    # App rollback: serve memory again. Rocks data remains.
    kv.rollback_app()
    check("app_rollback_serves_memory", kv.mode == "memory" and kv.get("a") == "1")
    check("app_rollback_misses_rocks_only_key", kv.get("d") is None)
    check("rocks_still_has_d", rocks.get("d") == "4")
    # Data rollback the other way: copy rocks -> memory, then stay on memory
    for key in ("a", "b", "c", "d"):
        val = rocks.get(key)
        if val is not None:
            mem.set(key, val)
    check("data_rollback_restores_d_into_memory", kv.get("d") == "4")
    # Paths still exist (no delete-after-cutover)
    check("mode_flag_and_both_backends_remain", kv.mode == "memory" and DB.exists())
    rocks.close()

    failed = [n for n, ok, _ in checks if not ok]
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 201,
                "id": "n-evolution",
                "is_live_model": False,
                "rocksdict_import": getattr(rocksdict, "__file__", "ok"),
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "old_client_protocol_stable": True,
                "rollback_boundaries": {
                    "app_rollback": "switch mode back to memory; rocks files kept; keys only written to rocks after cutover are not in memory until a data copy",
                    "data_rollback": "copy rocks -> memory (or the reverse) as an explicit step",
                },
                "not_verified_on_this_machine": [
                    "Facebook RocksDB C++ API or a multi-gigabyte production cutover",
                    "online shadow traffic from real clients",
                ],
                "verified_on_this_machine": [
                    "rocksdict 0.3.29 (RocksDB binding) put/get in dual-read and cutover",
                    "old get/set client still works; app vs data rollback demonstrated; backends not deleted after switch",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
