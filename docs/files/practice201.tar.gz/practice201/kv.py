"""Stable client protocol in front of memory and RocksDB backends.

rocksdict 0.3.29 is a Python binding that embeds RocksDB (not the Facebook
C++ API used directly). The client still speaks get/set/exists; only the
mode flag changes: memory -> dual -> rocks, with a documented rollback.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from rocksdict import Options, Rdict


class MemoryBackend:
    name = "memory"

    def __init__(self):
        self.data: dict[str, str] = {}

    def get(self, key: str) -> Optional[str]:
        return self.data.get(key)

    def set(self, key: str, value: str) -> None:
        self.data[key] = value

    def exists(self, key: str) -> bool:
        return key in self.data

    def snapshot(self) -> dict[str, str]:
        return dict(self.data)


class RocksBackend:
    name = "rocks"

    def __init__(self, path: Path):
        path.mkdir(parents=True, exist_ok=True)
        opts = Options()
        opts.create_if_missing(True)
        self.path = path
        self.db = Rdict(str(path), opts)

    def get(self, key: str) -> Optional[str]:
        try:
            v = self.db[key]
        except KeyError:
            return None
        if isinstance(v, bytes):
            return v.decode()
        return v

    def set(self, key: str, value: str) -> None:
        self.db[key] = value

    def exists(self, key: str) -> bool:
        return self.get(key) is not None

    def close(self) -> None:
        self.db.close()


class KvService:
    """Old clients keep calling get/set/exists regardless of mode."""

    def __init__(self, mem: MemoryBackend, rocks: RocksBackend, mode: str = "memory"):
        self.mem = mem
        self.rocks = rocks
        self.mode = mode  # memory | dual | rocks
        self.mismatches: list[dict] = []
        self.audit: list[str] = []

    def set_mode(self, mode: str) -> None:
        if mode not in {"memory", "dual", "rocks"}:
            raise ValueError(mode)
        # Contract: do not delete the other backend when switching.
        self.audit.append(f"mode {self.mode} -> {mode}")
        self.mode = mode

    def set(self, key: str, value: str) -> None:
        if self.mode in {"memory", "dual"}:
            self.mem.set(key, value)
        if self.mode in {"dual", "rocks"}:
            self.rocks.set(key, value)

    def get(self, key: str) -> Optional[str]:
        if self.mode == "memory":
            return self.mem.get(key)
        if self.mode == "rocks":
            return self.rocks.get(key)
        # dual-read compare; memory is still primary for the client response
        mv = self.mem.get(key)
        rv = self.rocks.get(key)
        if mv != rv:
            self.mismatches.append({"key": key, "memory": mv, "rocks": rv})
        return mv

    def exists(self, key: str) -> bool:
        return self.get(key) is not None

    def rollback_app(self) -> None:
        """Application rollback: serve memory again. Rocks data is kept."""
        self.set_mode("memory")

    def rollback_data_from_rocks(self) -> None:
        """Data rollback boundary: rebuild memory from rocks (the new store)."""
        # Teaching path: copy rocks keys we know from memory snapshot plus later writes
        # is incomplete if we don't iterate. We iterate keys written through the service
        # by also storing a key set in memory during dual/rocks.
        raise SystemExit("use explicit key list in the driver; rocksdict iteration is done there")
