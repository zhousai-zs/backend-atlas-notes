"""Sessions, tasks, and long-term facts in separate tables. Not a vector store."""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE sessions(
  session_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, created REAL
);
CREATE TABLE tasks(
  task_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, state TEXT,
  step TEXT, -- executed business step, not a model opinion
  note TEXT
);
CREATE TABLE facts(
  fact_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  text TEXT NOT NULL,
  source TEXT NOT NULL,
  kind TEXT NOT NULL,          -- confirmed | inference
  confirmed INTEGER NOT NULL,  -- 1 only if kind=confirmed
  created REAL,
  expires_at REAL,             -- unix, NULL = no expiry
  revoked INTEGER NOT NULL DEFAULT 0,
  deleted INTEGER NOT NULL DEFAULT 0
);
"""


class Memory:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            path.unlink()
        self.conn = sqlite3.connect(path)
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def add_session(self, session_id, user_id):
        self.conn.execute("INSERT INTO sessions VALUES(?,?,?)", (session_id, user_id, time.time()))
        self.conn.commit()

    def add_task(self, task_id, user_id, state, step, note=""):
        self.conn.execute("INSERT OR REPLACE INTO tasks VALUES(?,?,?,?,?)", (task_id, user_id, state, step, note))
        self.conn.commit()

    def add_fact(self, fact_id, user_id, text, source, *, kind, expires_at=None):
        if kind not in {"confirmed", "inference"}:
            raise ValueError(kind)
        self.conn.execute(
            "INSERT INTO facts VALUES(?,?,?,?,?,?,?,?,0,0)",
            (fact_id, user_id, text, source, kind, 1 if kind == "confirmed" else 0, time.time(), expires_at),
        )
        self.conn.commit()

    def revoke(self, fact_id):
        self.conn.execute("UPDATE facts SET revoked=1 WHERE fact_id=?", (fact_id,))
        self.conn.commit()

    def delete_user(self, user_id):
        # Must also drop the row used for retrieval — not just a "main" view.
        self.conn.execute("UPDATE facts SET deleted=1 WHERE user_id=?", (user_id,))
        self.conn.commit()

    def recall(self, user_id, query: str, now: float | None = None) -> list[dict]:
        """Re-check permission (user_id) and validity on every recall. No cross-user hits."""
        now = time.time() if now is None else now
        rows = self.conn.execute(
            """SELECT fact_id,user_id,text,source,kind,confirmed,expires_at,revoked,deleted
               FROM facts WHERE user_id=?""",
            (user_id,),
        ).fetchall()
        out = []
        q = query.lower()
        for r in rows:
            rec = dict(zip(
                ["fact_id","user_id","text","source","kind","confirmed","expires_at","revoked","deleted"], r
            ))
            if rec["deleted"] or rec["revoked"]:
                continue
            if rec["expires_at"] is not None and rec["expires_at"] <= now:
                continue
            # toy lexical filter; authorization already applied via user_id
            if any(tok in rec["text"].lower() for tok in q.split() if len(tok) > 2):
                out.append(rec)
        return out

    def resume_task(self, task_id) -> dict:
        row = self.conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
        cols = ["task_id","user_id","state","step","note"]
        return dict(zip(cols, row))
