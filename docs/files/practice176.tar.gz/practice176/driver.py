#!/usr/bin/env python3
"""Two users, TTL, revoke, delete, confirmed vs inference. No live model."""

from __future__ import annotations

import json
import time
from pathlib import Path

from memory import Memory

ROOT = Path(__file__).resolve().parent
DB = ROOT / "reports/memory.db"
mem = Memory(DB)

mem.add_session("s-alice", "alice")
mem.add_session("s-bob", "bob")
now = time.time()

mem.add_fact("f1", "alice", "alice staging replica lag is 40ms", "runbook://replicas#L12", kind="confirmed", expires_at=now+3600)
mem.add_fact("f2", "bob", "bob staging replica lag is 40ms", "runbook://replicas#L12", kind="confirmed", expires_at=now+3600)
mem.add_fact("f-exp", "alice", "alice old canary percent is 5%", "ticket://CANARY-1", kind="confirmed", expires_at=now-10)
mem.add_fact("f-rev", "alice", "alice pager number is 555-0100", "hr://directory", kind="confirmed", expires_at=now+3600)
mem.revoke("f-rev")
mem.add_fact("f-inf", "alice", "the lag is probably caused by a lock", "model:session-s-alice", kind="inference", expires_at=now+3600)
mem.add_fact("f-del", "carol", "carol wifi password is hunter2", "it://wifi", kind="confirmed", expires_at=now+3600)
mem.delete_user("carol")

# Two users, same query, no cross recall
q = "staging replica lag"
alice_hits = mem.recall("alice", q, now=now)
bob_hits = mem.recall("bob", q, now=now)
alice_ids_q = {h["fact_id"] for h in alice_hits}
bob_ids_q = {h["fact_id"] for h in bob_hits}
assert "f1" in alice_ids_q and "f2" not in alice_ids_q
assert "f2" in bob_ids_q and "f1" not in bob_ids_q
assert all(h["user_id"]=="alice" for h in alice_hits)
assert all(h["user_id"]=="bob" for h in bob_hits)
# A later inference that mentions "lag" may also hit Alice; it must still be Alice-only.
assert "f-inf" not in bob_ids_q

# Expired, revoked, deleted stay out of context
alice_all = mem.recall("alice", "canary pager lag lock", now=now)
ids = {h["fact_id"] for h in alice_all}
assert "f-exp" not in ids and "f-rev" not in ids
assert "f1" in ids and "f-inf" in ids
carol_hits = mem.recall("carol", "wifi password", now=now)
assert carol_hits == []

# Every cited fact has source and validity
for h in alice_hits + bob_hits + alice_all:
    assert h["source"] and (h["expires_at"] is None or h["expires_at"] > now)
    assert h["kind"] in {"confirmed", "inference"}
    assert (h["kind"]=="confirmed") == bool(h["confirmed"])

# Display distinction
display = [{"id": h["fact_id"], "kind": h["kind"], "confirmed": bool(h["confirmed"]), "text": h["text"], "source": h["source"], "expires_at": h["expires_at"]} for h in alice_all]
assert {d["kind"] for d in display} == {"confirmed", "inference"}

# Task resume uses execution state, not a historical inference as a completed action
mem.add_task("t-alice", "alice", "running", "retrieved_logs", note="not yet written report")
# an inference must not be treated as step-complete
resumed = mem.resume_task("t-alice")
assert resumed["step"] == "retrieved_logs" and resumed["state"] == "running"
assert resumed["step"] != "the lag is probably caused by a lock"

results = {
    "lesson": 176,
    "id": "l-memory",
    "is_live_model": False,
    "used_vector_similarity_as_auth": False,
    "cross_user_leak": False,
    "alice_ids": sorted(ids),
    "bob_ids": [h["fact_id"] for h in bob_hits],
    "expired_or_revoked_or_deleted_returned": False,
    "cited_facts": display,
    "resume_uses_task_state_not_inference": resumed,
    "verified_on_this_machine": [
        "two_users_same_query_do_not_share_facts",
        "expired_revoked_deleted_excluded_on_recall",
        "each_hit_has_source_and_expiry",
        "inference_and_confirmed_are_distinct_fields",
    ],
    "not_verified_on_this_machine": ["production_vector_memory_or_OpenAI_Sessions_hosted_store"],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"alice": results["alice_ids"], "bob": results["bob_ids"], "kinds": sorted({d['kind'] for d in display})}, indent=2))
print("ALL_CHECKS_PASSED")
