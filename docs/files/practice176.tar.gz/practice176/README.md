# 实践 176：短期状态与长期记忆

在解压后的 `practice176/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（标准库 + sqlite3）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

分表存放 session/task/fact，不做向量检索，也不把词法匹配当成授权。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
