#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["cross_user_leak"] is False and r["expired_or_revoked_or_deleted_returned"] is False
assert "f1" in r["alice_ids"] and "f2" in r["bob_ids"] and "f1" not in r["bob_ids"]
assert any(x["kind"]=="inference" for x in r["cited_facts"]) and any(x["kind"]=="confirmed" for x in r["cited_facts"])
assert r["resume_uses_task_state_not_inference"]["step"]=="retrieved_logs"
print("POSTCHECK_OK")
PY
