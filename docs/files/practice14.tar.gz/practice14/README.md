# practice14 — 字符串 KV 解析器用例

节点实践：为字符串解析器设计合法、空值、超长和损坏输入案例。

```bash
python3 parse_kv_test.py
```

- `parse_kv.py`：符合契约的实现
- `parse_kv_buggy.py`：value 上界误为 257 的植入错误版
- 测试在抓到 buggy 接受 257 时打印 `PLANTED_BUG_DETECTED`
