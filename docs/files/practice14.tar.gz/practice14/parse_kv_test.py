"""合法 / 空值 / 超长 / 损坏 四类用例；并验证能发现植入的边界错误。"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from parse_kv import parse_kv_line
import parse_kv_buggy


def expect_ok(line: str, key: str, value: str) -> None:
    got = parse_kv_line(line)
    assert got == {"key": key, "value": value}, (line, got)


def expect_err(line: str) -> None:
    try:
        parse_kv_line(line)
    except ValueError:
        return
    raise AssertionError(f"expected ValueError for {line!r}")


def test_legal() -> None:
    expect_ok("app_id=wx123", "app_id", "wx123")
    expect_ok("flag=1", "flag", "1")
    expect_ok("name=", "name", "")  # 空 value 合法
    expect_ok("a=" + "x" * 256, "a", "x" * 256)  # 边界合法
    expect_ok("_private=ok", "_private", "ok")


def test_empty() -> None:
    expect_err("")
    expect_err("   ")
    expect_err("\t")


def test_oversized() -> None:
    expect_err("a=" + "x" * 257)  # value 超长
    expect_err("k" * 33 + "=v")  # key 超长（33 字符）
    expect_err("a=" + "x" * 300)


def test_corrupted() -> None:
    expect_err("no_eq")
    expect_err("=onlyvalue")
    expect_err("a=b=c")
    expect_err("bad-key=1")
    expect_err("1abc=x")  # key 不能以数字开头
    expect_err("a=b\nc")  # 含换行


def test_finds_planted_boundary_bug() -> None:
    """验收：测试能发现植入的边界错误。"""
    line = "a=" + "x" * 257
    # 正确实现必须拒绝
    try:
        parse_kv_line(line)
        raise AssertionError("correct impl should reject len=257")
    except ValueError:
        pass
    # buggy 实现错误地接受 257 → 用例「期望拒绝」会失败，从而「发现」bug
    accepted_by_bug = False
    try:
        parse_kv_buggy.parse_kv_line(line)
        accepted_by_bug = True
    except ValueError:
        accepted_by_bug = False
    assert accepted_by_bug, "buggy impl should wrongly accept 257 (planted bug missing?)"
    print("PLANTED_BUG_DETECTED: buggy accepts value length 257; correct rejects it")


def test_minimize_failure_input() -> None:
    """验收：能复现失败并缩小最小输入（演示：257 → 确认 256 合法）。"""
    # 复现：257 失败
    expect_err("a=" + "x" * 257)
    # 缩小：256 成功 → 最小超长触发长度是 257
    expect_ok("a=" + "x" * 256, "a", "x" * 256)
    print("MIN_FAIL_LEN: value length 257 (256 ok)")


def main() -> None:
    test_legal()
    test_empty()
    test_oversized()
    test_corrupted()
    test_finds_planted_boundary_bug()
    test_minimize_failure_input()
    print("ALL_PASSED")


if __name__ == "__main__":
    main()
