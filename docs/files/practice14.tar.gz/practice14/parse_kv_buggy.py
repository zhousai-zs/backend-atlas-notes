"""故意植入边界错误的版本：value 上界写成 257（应用允许到 257）。"""
from __future__ import annotations

import re

_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,31}$")
# BUG: 契约是 256，这里错误地允许 257
_MAX_VALUE = 257


def parse_kv_line(line: str) -> dict[str, str]:
    if not isinstance(line, str):
        raise TypeError("line must be str")
    if "\n" in line or "\r" in line:
        raise ValueError("line must be a single line without newlines")
    if line.strip() == "":
        raise ValueError("empty or whitespace-only line")
    if line.count("=") != 1:
        raise ValueError("line must contain exactly one '='")
    key, value = line.split("=", 1)
    if not _KEY_RE.match(key):
        raise ValueError(f"invalid key: {key!r}")
    if len(value) > _MAX_VALUE:  # BUG: 257 会被放行
        raise ValueError(f"value too long: {len(value)} > {_MAX_VALUE}")
    return {"key": key, "value": value}
