"""parse_kv_line: 单行 key=value 解析（契约见模块文档）。"""
from __future__ import annotations

import re

_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,31}$")
_MAX_VALUE = 256


def parse_kv_line(line: str) -> dict[str, str]:
    """解析单行 key=value。

    契约：
    - 合法：恰好一个 '='；key 匹配 ^[A-Za-z_][A-Za-z0-9_]{0,31}$；
      value 不含 \\n/\\r，长度 0..256。
    - 成功：返回 {"key": key, "value": value}
    - 非法：抛 ValueError
    """
    if not isinstance(line, str):
        raise TypeError("line must be str")
    if "\n" in line or "\r" in line:
        raise ValueError("line must be a single line without newlines")
    if line.strip() == "":
        raise ValueError("empty or whitespace-only line")
    if line.count("=") != 1:
        raise ValueError("line must contain exactly one '='")
    key, value = line.split("=", 1)
    if not _KEY_RE.match(key):
        raise ValueError(f"invalid key: {key!r}")
    if len(value) > _MAX_VALUE:
        raise ValueError(f"value too long: {len(value)} > {_MAX_VALUE}")
    return {"key": key, "value": value}
