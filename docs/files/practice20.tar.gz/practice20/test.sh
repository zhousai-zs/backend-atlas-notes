#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CXXFLAGS=(-std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0)

echo "== demo_early_return =="
g++ "${CXXFLAGS[@]}" demo_early_return.cpp -o demo_early_return
./demo_early_return

echo "== demo_move =="
g++ "${CXXFLAGS[@]}" demo_move.cpp -o demo_move
./demo_move

echo "== demo_close_fail =="
g++ "${CXXFLAGS[@]}" demo_close_fail.cpp -o demo_close_fail
./demo_close_fail

echo "ALL checks passed"
