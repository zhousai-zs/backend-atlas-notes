# practice20 · RAII与资源所有权

对应课程：`/workspace/atlas/lessons/20-b-raii.md`（节点 `b-raii`）

## 文件

| 文件 | 作用 |
|------|------|
| `unique_fd.hpp` | 禁止拷贝、可移动的 `UniqueFd`；close 失败记录 errno 不抛异常；移动后源对象置 `-1` |
| `fd_count.hpp` | 通过 `/proc/self/fd` 统计打开的 fd 数 |
| `demo_early_return.cpp` | 提前 return / 抛异常后 fd 数量不增长 |
| `demo_move.cpp` | 移动后源对象为 `-1`，不重复 close |
| `demo_close_fail.cpp` | close 失败（EBADF）只记录不抛 |
| `test.sh` | 一键编译与检查 |

## 一键验证

```bash
cd /workspace/atlas/lessons/practice20
./test.sh
```

期望最后一行：`ALL checks passed`

## 手动命令

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0 demo_early_return.cpp -o demo_early_return && ./demo_early_return
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0 demo_move.cpp -o demo_move && ./demo_move
g++ -std=c++17 -Wall -Wextra -Wpedantic -Werror -g -O0 demo_close_fail.cpp -o demo_close_fail && ./demo_close_fail
```
