#include "fd_count.hpp"
#include "unique_fd.hpp"

#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

static void take_and_return_early(UniqueFd fd) {
    if (!fd) {
        throw std::runtime_error("empty fd");
    }
    // 模拟业务提前返回：不手动 close，靠析构释放。
    if (fd.get() >= 0) {
        return;
    }
}

static void take_and_throw(UniqueFd fd) {
    if (!fd) {
        return;
    }
    throw std::runtime_error("simulated handler failure");
}

int main() {
    const int before = count_open_fds();
    if (before < 0) {
        std::cerr << "cannot read /proc/self/fd\n";
        return 1;
    }

    {
        int raw = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
        if (raw < 0) {
            std::cerr << "open /dev/null failed\n";
            return 1;
        }
        UniqueFd fd(raw);
        take_and_return_early(std::move(fd));
    }

    {
        int raw = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
        if (raw < 0) {
            std::cerr << "open /dev/null failed\n";
            return 1;
        }
        UniqueFd fd(raw);
        try {
            take_and_throw(std::move(fd));
        } catch (const std::exception& ex) {
            std::cout << "caught: " << ex.what() << '\n';
        }
    }

    const int after = count_open_fds();
    if (after < 0) {
        std::cerr << "cannot read /proc/self/fd\n";
        return 1;
    }

    if (after != before) {
        std::cerr << "fd leak: before=" << before << " after=" << after << '\n';
        return 1;
    }

    std::cout << "early-return/throw: fd count stable (" << before << ")\n";
    return 0;
}
