#pragma once

#include <cerrno>
#include <unistd.h>
#include <utility>

// 禁止拷贝、可移动的唯一文件描述符所有权包装。
// 析构 / reset 时 close 失败只记录 errno，绝不抛异常（析构路径 noexcept）。
class UniqueFd {
public:
    UniqueFd() noexcept = default;

    explicit UniqueFd(int fd) noexcept : fd_(fd) {}

    ~UniqueFd() noexcept { reset(); }

    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;

    UniqueFd(UniqueFd&& other) noexcept : fd_(other.fd_) { other.fd_ = -1; }

    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            reset();
            fd_ = other.fd_;
            other.fd_ = -1;
        }
        return *this;
    }

    explicit operator bool() const noexcept { return fd_ >= 0; }

    int get() const noexcept { return fd_; }

    bool valid() const noexcept { return fd_ >= 0; }

    int release() noexcept {
        int fd = fd_;
        fd_ = -1;
        return fd;
    }

    // 关闭当前 fd；EINTR 重试；其它失败写入 last_close_errno_，不抛异常。
    void reset(int new_fd = -1) noexcept {
        if (fd_ >= 0) {
            int rc;
            do {
                rc = ::close(fd_);
            } while (rc < 0 && errno == EINTR);
            if (rc < 0) {
                last_close_errno_ = errno;
            } else {
                last_close_errno_ = 0;
            }
        }
        fd_ = new_fd;
    }

    int last_close_errno() const noexcept { return last_close_errno_; }

private:
    int fd_{-1};
    int last_close_errno_{0};
};
