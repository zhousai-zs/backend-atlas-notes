#include "unique_fd.hpp"

#include <fcntl.h>
#include <iostream>
#include <unistd.h>

int main() {
    int raw = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
    if (raw < 0) {
        std::cerr << "open failed\n";
        return 1;
    }

    UniqueFd a(raw);
    const int owned = a.get();

    UniqueFd b(std::move(a));
    if (a.get() != -1) {
        std::cerr << "moved-from should be -1, got " << a.get() << '\n';
        return 1;
    }
    if (b.get() != owned) {
        std::cerr << "move target lost fd\n";
        return 1;
    }

    UniqueFd c;
    c = std::move(b);
    if (b.get() != -1 || c.get() != owned) {
        std::cerr << "move-assign failed\n";
        return 1;
    }

    // a、b 析构时不应 double-close；c 负责关闭。
    c.reset();
    if (::fcntl(owned, F_GETFD) != -1 || errno != EBADF) {
        std::cerr << "fd still valid after UniqueFd reset (or unexpected errno)\n";
        return 1;
    }

    std::cout << "move: source invalidated, no double-close\n";
    return 0;
}
