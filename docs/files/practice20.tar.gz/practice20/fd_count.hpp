#pragma once

#include <dirent.h>

// 通过 /proc/self/fd 统计当前进程打开的 fd 数量（含目录自身等）。
// 仅用于相对比较：操作前后计数应相等，证明无泄漏。
inline int count_open_fds() {
    DIR* dir = opendir("/proc/self/fd");
    if (!dir) {
        return -1;
    }
    int n = 0;
    while (readdir(dir) != nullptr) {
        ++n;
    }
    closedir(dir);
    return n;
}
