#include "unique_fd.hpp"

#include <cassert>
#include <fcntl.h>
#include <iostream>
#include <unistd.h>

int main() {
    int raw = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
    if (raw < 0) {
        std::cerr << "open failed\n";
        return 1;
    }

    UniqueFd fd(raw);

    // 人为先关掉底层 fd，让 UniqueFd::reset 内的 close 失败（EBADF）。
    if (::close(raw) != 0) {
        std::cerr << "manual close failed\n";
        return 1;
    }

    bool threw = false;
    try {
        fd.reset();
    } catch (...) {
        threw = true;
    }

    if (threw) {
        std::cerr << "reset must not throw on close failure\n";
        return 1;
    }
    if (fd.valid() || fd.get() != -1) {
        std::cerr << "fd should be invalid after reset\n";
        return 1;
    }
    if (fd.last_close_errno() != EBADF) {
        std::cerr << "expected EBADF, got " << fd.last_close_errno() << '\n';
        return 1;
    }

    std::cout << "close-failure: errno=" << fd.last_close_errno()
              << " recorded, no throw\n";
    return 0;
}
