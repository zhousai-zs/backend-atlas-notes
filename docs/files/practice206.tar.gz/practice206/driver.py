from __future__ import annotations

import json
from pathlib import Path

import yaml
from validate import validate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"


def main() -> None:
    good = validate(yaml.safe_load((ROOT / "portfolios" / "good.yaml").read_text()))
    bad = validate(yaml.safe_load((ROOT / "portfolios" / "hot-all-mandatory.yaml").read_text()))
    checks = [
        ("good_accepted", good["ok"], str(good)),
        ("hot_all_mandatory_rejected", (not bad["ok"]) and "all_items_are_mandatory_builds" in bad["problems"], str(bad)),
        ("hot_without_risk_flagged", any("hot_without_risk" in p for p in bad["problems"]), str(bad["problems"])),
        ("good_has_stop_or_reuse", any(d in {"stop", "reuse", "buy_or_wait"} for d in good["decisions"]), str(good["decisions"])),
        ("every_good_item_has_exit", good["ok"], ""),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    (ROOT / "reports" / "validation.json").write_text(json.dumps({"good": good, "bad": bad}, indent=2) + "\n")
    RESULTS.write_text(json.dumps({
        "lesson": 206, "id": "n-strategy", "is_live_model": False,
        "good": good, "bad": bad,
        "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        "failed": failed,
        "not_verified_on_this_machine": [
            "a real annual budget or production ROI on these investments",
        ],
        "verified_on_this_machine": [
            "portfolio validator requires risk, observable, and exit condition",
            "an all-mandatory hot-topic plan is rejected",
        ],
    }, ensure_ascii=False, indent=2) + "\n")
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
