from __future__ import annotations


REQUIRED = ("decision", "business_risk", "observable", "exit_condition")


def validate(plan: dict) -> dict:
    problems = []
    decisions = []
    for it in plan.get("items") or []:
        decisions.append(it.get("decision"))
        if it.get("because_it_is_hot") and not it.get("business_risk"):
            problems.append(f"{it.get('id')}_hot_without_risk")
        for k in REQUIRED:
            if not it.get(k):
                problems.append(f"{it.get('id')}_missing_{k}")
    if not any(d in {"stop", "buy_or_wait", "reuse"} for d in decisions):
        problems.append("no_stop_or_reuse_decision")
    if all(d == "build" for d in decisions if d):
        problems.append("all_items_are_mandatory_builds")
    return {"ok": not problems, "problems": problems, "decisions": decisions}
