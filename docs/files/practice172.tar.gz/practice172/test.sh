#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["sdk_version"]=="2.3.0" and r["protocol"]=="2026-07-28"
assert r["stdio_ok"]["is_error"] is False
assert r["stdout_pollution_breaks_protocol"]["first_line"].startswith("DEBUG:")
assert r["reap"]["alive_after_reap"] is False and r["reap"]["orphans"]==[]
assert r["http"]["disconnect"]["rolled_back"] is False
assert r["http"]["disconnect"]["job_still_interpretable"] is True
assert r["http"]["race"]["claimed_n"]==1
assert r["lifecycles"]["disconnect_is_not_rollback"] is True
print("POSTCHECK_OK")
PY
