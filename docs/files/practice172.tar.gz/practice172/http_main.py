#!/usr/bin/env python3
"""Streamable HTTP MCP server on 127.0.0.1, port from argv or 0."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="http-server: %(message)s")

import uvicorn

from server_app import build_server

PORTFILE = os.environ.get("PRACTICE172_PORTFILE")


async def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    mcp = build_server()
    app = mcp.streamable_http_app(streamable_http_path="/mcp", host="127.0.0.1")
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", lifespan="on")
    server = uvicorn.Server(config)
    listener = asyncio.create_task(server.serve())
    # Wait until sockets exist, then publish the bound port.
    for _ in range(100):
        if server.started:
            break
        await asyncio.sleep(0.05)
    socks = []
    for s in getattr(server, "servers", []) or []:
        socks.extend(getattr(s, "sockets", []) or [])
    if not socks:
        # uvicorn 0.54 stores sockets differently sometimes
        await asyncio.sleep(0.2)
        for s in getattr(server, "servers", []) or []:
            socks.extend(getattr(s, "sockets", []) or [])
    if socks:
        bound = socks[0].getsockname()[1]
        if PORTFILE:
            Path(PORTFILE).write_text(str(bound))
        print(f"LISTENING {bound}", file=sys.stderr, flush=True)
    await listener


if __name__ == "__main__":
    asyncio.run(main())
