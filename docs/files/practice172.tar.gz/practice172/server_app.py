"""The same read-only diagnose tool used on both stdio and HTTP."""

from __future__ import annotations

import asyncio
import os

from mcp.server import MCPServer
from mcp.server.mcpserver import Context

import jobs


async def _diagnose(job_id: str, delay_ms: int, ctx: Context) -> str:
    jobs.start(job_id)
    # A cancel file lets the driver request cancellation without a second protocol tool.
    cancel_file = jobs.JOB_DIR / f"{job_id}.cancel"
    delayed = max(0, delay_ms) / 1000.0
    step = 0.02
    waited = 0.0
    try:
        while waited < delayed:
            if cancel_file.exists():
                rec, claimed = jobs.claim_terminal(job_id, "cancelled")
                if claimed:
                    return f"cancelled:{job_id}"
                return f"already:{rec['status']}:{job_id}"
            await asyncio.sleep(min(step, delayed - waited))
            waited += step
        rec, claimed = jobs.claim_terminal(job_id, "completed")
        if claimed:
            return f"completed:{job_id}"
        return f"already:{rec['status']}:{job_id}"
    except asyncio.CancelledError:
        rec, claimed = jobs.claim_terminal(job_id, "cancelled")
        raise


def build_server() -> MCPServer:
    server = MCPServer("diagnose", version="2.3.0")

    @server.tool(description="Read-only diagnostic that can run for delay_ms milliseconds.")
    async def diagnose(job_id: str, delay_ms: int, ctx: Context) -> str:
        return await _diagnose(job_id, delay_ms, ctx)

    @server.resource("resource://about", description="Tool description")
    def about() -> str:
        return "diagnose is a read-only probe. Job files record operational state."

    return server
