#!/usr/bin/env python3
"""Stdio MCP server. Protocol frames go to stdout; logs must go to stderr."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

# Logging must not touch stdout. The MCP stdio binding is newline-delimited JSON-RPC on stdout.
logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="stdio-server: %(message)s")
log = logging.getLogger("stdio")

if os.environ.get("POLLUTE_STDOUT") == "1":
    # Deliberate protocol violation for the counterexample.
    sys.stdout.write("DEBUG: starting diagnose server\n")
    sys.stdout.flush()

# Record pid so the driver can reap us.
pid_file = os.environ.get("PRACTICE172_PIDFILE")
if pid_file:
    Path(pid_file).write_text(str(os.getpid()))

from server_app import build_server  # noqa: E402

log.info("pid=%s protocol=2026-07-28 sdk=mcp", os.getpid())
build_server().run(transport="stdio")
