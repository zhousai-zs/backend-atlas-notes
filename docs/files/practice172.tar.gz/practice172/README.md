# practice172 — MCP 传输与连接

同一 diagnose 工具跑 stdio 与 Streamable HTTP。stdout 不得混日志。子进程可回收。HTTP 断连不是回滚。取消与完成只有一个终态。

```bash
bash test.sh
```
