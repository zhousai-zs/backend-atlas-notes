#!/usr/bin/env python3
"""Same diagnose tool on stdio and Streamable HTTP. Official mcp 2.3.0."""

from __future__ import annotations

import asyncio
import importlib.metadata
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

from mcp import Client
from mcp.client.stdio import StdioServerParameters

import jobs

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
PY = sys.executable if "cmvenv" in sys.executable else "/workspace/atlas/cmvenv/bin/python"
SDK = importlib.metadata.version("mcp")
assert SDK == "2.3.0"


def _text(result) -> str:
    return "".join(getattr(c, "text", "") or "" for c in (result.content or []))


def _popen_env(**extra):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    env["PRACTICE172_JOBDIR"] = str(REPORTS / "jobs")
    env["PRACTICE172_PROBELOG"] = str(REPORTS / "probe.log")
    env.update(extra)
    return env


async def stdio_call(env: dict, job_id: str, delay_ms: int, timeout: float = 8.0):
    params = StdioServerParameters(
        command=PY,
        args=[str(ROOT / "stdio_main.py")],
        env=env,
        cwd=str(ROOT),
    )
    async with Client(params) as client:
        proto = client.session.protocol_version
        result = await asyncio.wait_for(client.call_tool("diagnose", {"job_id": job_id, "delay_ms": delay_ms}), timeout=timeout)
        return {"protocol": proto, "is_error": result.is_error, "text": _text(result)}


def raw_stdio_probe(pollute: bool) -> dict:
    """Newline-delimited JSON-RPC on stdout; a DEBUG line is not a valid frame."""
    env = _popen_env(POLLUTE_STDOUT="1" if pollute else "0")
    proc = subprocess.Popen(
        [PY, str(ROOT / "stdio_main.py")],
        cwd=str(ROOT),
        env=env,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    assert proc.stdin and proc.stdout
    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/list",
        "params": {
            "_meta": {
                "io.modelcontextprotocol/protocolVersion": "2026-07-28",
                "io.modelcontextprotocol/clientCapabilities": {},
                "io.modelcontextprotocol/clientInfo": {"name": "raw-probe", "version": "1"},
            }
        },
    }
    try:
        proc.stdin.write(json.dumps(req) + "\n")
        proc.stdin.flush()
        # first stdout line
        line = ""
        t0 = time.time()
        while time.time() - t0 < 3:
            if proc.poll() is not None and not line:
                break
            ready = []
            # nonblocking-ish: use a short timeout via select
            import select

            r, _, _ = select.select([proc.stdout], [], [], 0.2)
            if r:
                line = proc.stdout.readline()
                break
        stderr = ""
        # drain a bit of stderr
        import select as sel

        if sel.select([proc.stderr], [], [], 0.2)[0]:
            stderr = proc.stderr.read() if False else proc.stderr.readline()
        parsed = None
        parse_error = None
        if line:
            try:
                parsed = json.loads(line)
            except json.JSONDecodeError as e:
                parse_error = str(e)
        return {
            "pollute": pollute,
            "first_stdout_line": line.rstrip("\n"),
            "parsed": parsed,
            "parse_error": parse_error,
            "stderr_sample": (stderr or "")[:300],
            "pid": proc.pid,
        }
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=2)


async def stdio_reap() -> dict:
    pidfile = REPORTS / "stdio-reap.pid"
    if pidfile.exists():
        pidfile.unlink()
    env = _popen_env(PRACTICE172_PIDFILE=str(pidfile))
    params = StdioServerParameters(command=PY, args=[str(ROOT / "stdio_main.py")], env=env, cwd=str(ROOT))
    child_pid = None
    err = None
    try:
        async with Client(params) as client:
            # wait for pid file
            for _ in range(50):
                if pidfile.exists():
                    break
                await asyncio.sleep(0.05)
            child_pid = int(pidfile.read_text())
            task = asyncio.create_task(client.call_tool("diagnose", {"job_id": "reap1", "delay_ms": 8000}))
            await asyncio.sleep(0.3)
            os.kill(child_pid, signal.SIGTERM)
            try:
                await asyncio.wait_for(task, timeout=3)
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
    except Exception as e:
        err = (err or "") + f" | outer {type(e).__name__}: {e}"
    # reap
    still = True
    for _ in range(20):
        try:
            os.kill(child_pid, 0)
            time.sleep(0.1)
        except (OSError, TypeError):
            still = False
            break
    if still and child_pid:
        os.kill(child_pid, signal.SIGKILL)
        time.sleep(0.1)
        try:
            os.kill(child_pid, 0)
            alive = True
        except OSError:
            alive = False
    else:
        alive = False
    # no leftover children of that pid
    orphans = []
    proc_dir = Path("/proc")
    if proc_dir.exists() and child_pid:
        for p in proc_dir.iterdir():
            if not p.name.isdigit():
                continue
            try:
                stat = (p / "stat").read_text().split()
                ppid = int(stat[3])
                if ppid == child_pid:
                    orphans.append(int(p.name))
            except (FileNotFoundError, IndexError, PermissionError, ValueError):
                continue
    return {
        "child_pid": child_pid,
        "alive_after_reap": alive,
        "orphans": orphans,
        "client_error": err,
    }


def start_http():
    portfile = REPORTS / "http.port"
    if portfile.exists():
        portfile.unlink()
    env = _popen_env(PRACTICE172_PORTFILE=str(portfile))
    proc = subprocess.Popen(
        [PY, str(ROOT / "http_main.py"), "0"],
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    port = None
    t0 = time.time()
    while time.time() - t0 < 8:
        if portfile.exists() and portfile.read_text().strip().isdigit():
            port = int(portfile.read_text().strip())
            break
        if proc.poll() is not None:
            err = proc.stderr.read() if proc.stderr else ""
            raise RuntimeError(f"http server exited {proc.returncode}: {err[-1000:]}")
        time.sleep(0.05)
    if port is None:
        err = ""
        if proc.stderr:
            # don't block
            try:
                import select

                if select.select([proc.stderr], [], [], 0.2)[0]:
                    err = proc.stderr.read()
            except Exception:
                pass
        proc.terminate()
        raise RuntimeError(f"http server did not publish a port: {err[-1000:]}")
    return proc, port


async def http_scenarios(port: int) -> dict:
    url = f"http://127.0.0.1:{port}/mcp"
    async with Client(url) as client:
        proto = client.session.protocol_version
        ok = await client.call_tool("diagnose", {"job_id": "http-ok", "delay_ms": 50})
        assert ok.is_error is False, ok
        about = await client.read_resource("resource://about")
        short = {"protocol": proto, "text": _text(ok), "about": str(about)[:200]}

    # Disconnect mid-flight: do not wait for the tool to finish.
    disconnect = {"side_effect_before": None, "side_effect_after": None, "job": None, "rolled_back": None}
    async def _disconnect():
        async with Client(url) as client:
            task = asyncio.create_task(client.call_tool("diagnose", {"job_id": "http-disc", "delay_ms": 2500}))
            # wait until the side-effect log appears
            for _ in range(50):
                rec = jobs.read("http-disc")
                if rec:
                    break
                await asyncio.sleep(0.05)
            disconnect["side_effect_before"] = (REPORTS / "probe.log").read_text() if (REPORTS / "probe.log").exists() else ""
            # closing the context cancels the client; it must not erase the job record
            task.cancel()
            # fall through to context exit
        # after disconnect
        await asyncio.sleep(0.3)
        disconnect["job"] = jobs.read("http-disc")
        disconnect["side_effect_after"] = (REPORTS / "probe.log").read_text() if (REPORTS / "probe.log").exists() else ""
        # The started line must still be present: disconnect is not a rollback.
        disconnect["rolled_back"] = "http-disc started" not in disconnect["side_effect_after"]
        disconnect["job_still_interpretable"] = disconnect["job"] is not None and disconnect["job"]["status"] in {
            "running",
            "completed",
            "cancelled",
            "failed",
        }

    await _disconnect()
    assert disconnect["rolled_back"] is False
    assert disconnect["job_still_interpretable"] is True

    # Cancel vs complete race: two claimers, exactly one terminal.
    jobs.start("race1")
    async def claim(status: str):
        await asyncio.sleep(0)
        return jobs.claim_terminal("race1", status)

    r1, r2 = await asyncio.gather(claim("completed"), claim("cancelled"))
    rec = jobs.read("race1")
    terminals = [status for recs, claimed in (r1, r2) if claimed for status in [recs["status"]]]
    # exactly one claimed
    claimed_n = sum(1 for recs, claimed in (r1, r2) if claimed)
    assert claimed_n == 1, (r1, r2, rec)
    assert rec["status"] in {"completed", "cancelled"}
    assert rec.get("rejected_terminals") in (None, [], ["completed"], ["cancelled"])
    if rec.get("rejected_terminals"):
        assert rec["status"] not in rec["rejected_terminals"] or True
        assert rec["rejected_terminals"][0] != rec["status"]

    return {
        "ok": short,
        "disconnect": disconnect,
        "race": {"record": rec, "claimed_n": claimed_n},
    }


def main():
    # clean job dir leftovers from prior runs of this script
    for p in (REPORTS / "jobs").glob("*"):
        p.unlink()
    if (REPORTS / "probe.log").exists():
        (REPORTS / "probe.log").unlink()

    clean = asyncio.run(stdio_call(_popen_env(), "stdio-ok", 50))
    assert clean["is_error"] is False and "completed:stdio-ok" in clean["text"]
    assert clean["protocol"] == "2026-07-28"

    polluted = raw_stdio_probe(pollute=True)
    assert polluted["first_stdout_line"].startswith("DEBUG:")
    assert polluted["parse_error"] or (polluted["parsed"] is None)
    clean_raw = raw_stdio_probe(pollute=False)
    # first line should be JSON (or empty if server is slow; retry tolerance)
    if not clean_raw["parsed"]:
        # one retry
        clean_raw = raw_stdio_probe(pollute=False)
    assert clean_raw["parsed"] is not None, clean_raw
    assert "jsonrpc" in clean_raw["parsed"]

    reap = asyncio.run(stdio_reap())
    assert reap["child_pid"]
    assert reap["alive_after_reap"] is False
    assert reap["orphans"] == []

    http_proc = None
    try:
        http_proc, port = start_http()
        http = asyncio.run(http_scenarios(port))
        assert http["ok"]["protocol"] == "2026-07-28"
        assert "completed:http-ok" in http["ok"]["text"]
    finally:
        if http_proc and http_proc.poll() is None:
            http_proc.terminate()
            try:
                http_proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                http_proc.kill()
                http_proc.wait(timeout=3)

    results = {
        "lesson": 172,
        "id": "l-mcp-transport",
        "sdk": "mcp",
        "sdk_version": SDK,
        "protocol": "2026-07-28",
        "stdio_framing": "newline-delimited JSON-RPC on stdout; logs on stderr; not LSP Content-Length",
        "stdio_ok": clean,
        "stdout_pollution_breaks_protocol": {
            "first_line": polluted["first_stdout_line"],
            "parse_error": polluted["parse_error"],
            "parsed": polluted["parsed"],
        },
        "stdio_raw_clean_frame": {"first_keys": list(clean_raw["parsed"].keys()) if clean_raw["parsed"] else None},
        "reap": reap,
        "http": http,
        "lifecycles": {
            "connection": "stdio subprocess lifetime / HTTP client TCP+session",
            "request": "a single JSON-RPC request (2026-07-28 per-request envelope)",
            "tool_task": "diagnose job_id record in reports/jobs, independent of the connection",
            "disconnect_is_not_rollback": True,
        },
        "why_old_revision_examples_do_not_swap": {
            "modern": "2026-07-28 carries io.modelcontextprotocol/protocolVersion on each request; no initialize handshake is required",
            "handshake_era": "2024-11-05 through 2025-11-25 use an initialize handshake; sending that traffic on the modern envelope path yields UNSUPPORTED_PROTOCOL_VERSION (-32022)",
            "see_also_lesson": 171,
        },
        "verified_on_this_machine": [
            "same_diagnose_tool_on_stdio_and_streamable_http",
            "stdout_debug_line_breaks_newline_jsonrpc",
            "stdio_child_terminated_and_reaped_without_orphans",
            "http_disconnect_does_not_rollback_job_side_effect",
            "cancel_vs_complete_single_terminal",
        ],
        "not_verified_on_this_machine": [
            "proxied_production_timeouts_and_load_balancers",
            "OAuth_protected_remote_MCP_servers",
        ],
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
    (REPORTS / "transport.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(json.dumps(
        {
            "stdio": clean,
            "pollute_line": polluted["first_stdout_line"],
            "reap_alive": reap["alive_after_reap"],
            "http_ok": http["ok"]["text"],
            "disconnect_rolled_back": http["disconnect"]["rolled_back"],
            "race": http["race"]["record"]["status"],
        },
        indent=2,
    ))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
