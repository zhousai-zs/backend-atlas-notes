"""File-backed job registry. A job record is operational state, not a business transaction."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
JOB_DIR = Path(os.environ.get("PRACTICE172_JOBDIR", ROOT / "reports" / "jobs"))
PROBE_LOG = Path(os.environ.get("PRACTICE172_PROBELOG", ROOT / "reports" / "probe.log"))


def _path(job_id: str) -> Path:
    JOB_DIR.mkdir(parents=True, exist_ok=True)
    return JOB_DIR / f"{job_id}.json"


def start(job_id: str) -> dict:
    rec = {
        "job_id": job_id,
        "status": "running",
        "started_unix": time.time(),
        "ended_unix": None,
        "side_effect": "probe_log_appended",
    }
    _path(job_id).write_text(json.dumps(rec, indent=2) + "\n")
    PROBE_LOG.parent.mkdir(parents=True, exist_ok=True)
    with PROBE_LOG.open("a", encoding="utf-8") as f:
        f.write(f"{job_id} started\n")
    return rec


def finish(job_id: str, status: str) -> dict:
    path = _path(job_id)
    rec = json.loads(path.read_text()) if path.exists() else {"job_id": job_id}
    # Only one terminal state: running -> completed|cancelled|failed. Never overwrite a terminal.
    if rec.get("status") in {"completed", "cancelled", "failed"}:
        rec["lost_race"] = status
        path.write_text(json.dumps(rec, indent=2) + "\n")
        return rec
    rec["status"] = status
    rec["ended_unix"] = time.time()
    path.write_text(json.dumps(rec, indent=2) + "\n")
    return rec


def read(job_id: str) -> dict | None:
    path = _path(job_id)
    if not path.exists():
        return None
    return json.loads(path.read_text())


def claim_terminal(job_id: str, status: str) -> tuple[dict, bool]:
    """Atomically claim the single terminal state. Returns (record, claimed)."""
    path = _path(job_id)
    # Use a lock file for the race.
    lock = path.with_suffix(".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(lock), os.O_CREAT | os.O_RDWR)
    try:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_EX)
        rec = json.loads(path.read_text()) if path.exists() else {"job_id": job_id, "status": "running"}
        claimed = rec.get("status") not in {"completed", "cancelled", "failed"}
        if claimed:
            rec["status"] = status
            rec["ended_unix"] = time.time()
        else:
            rec.setdefault("rejected_terminals", []).append(status)
        path.write_text(json.dumps(rec, indent=2) + "\n")
        return rec, claimed
    finally:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
