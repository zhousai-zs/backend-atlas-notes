#!/usr/bin/env python3
"""Acceptance checks for the lesson 129 reproducible microbenchmark experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    COMPILER_ID,
    COMPILER_VERSION,
    COST_NO_RESERVE,
    COST_RESERVE,
    ITERATIONS,
    KEY_TITLE,
    MEASURE_REPS,
    N_INSERT,
    TEACHING_FLAGS_O2,
    TITLE_V1,
    WARMUP_REPS,
    insert_cost,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "BenchmarkEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_benchmark_product"] and r["not_google_benchmark"]
    assert r["not_host_gxx"] and r["cycles_are_teaching"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["compiler_id"] == COMPILER_ID == "AtlasTeachCC"
    assert r["compiler_version"] == COMPILER_VERSION == "1.0"
    assert r["compiler_is_teaching"] and r["flags"] == TEACHING_FLAGS_O2
    assert r["n_insert"] == N_INSERT == 64
    assert r["iterations"] == ITERATIONS == 100
    assert r["warmup_reps"] == WARMUP_REPS == 1
    assert r["measure_reps"] == MEASURE_REPS == 9
    assert COST_NO_RESERVE == insert_cost(64, False) == 127
    assert COST_RESERVE == insert_cost(64, True) == 64
    assert r["cost_no_reserve"] == 127 and r["cost_reserve"] == 64

    dce = r["dce"]
    assert dce["dce_drops_unused_work"]
    assert dce["o2_unused"]["cycles_per_iteration"] == 0
    assert dce["o2_unused"]["work_present"] is False
    assert "deleted" in "\n".join(dce["o2_unused"]["disassembly"])
    assert dce["donotoptimize_keeps_work"]
    assert dce["o2_kept"]["cycles_per_iteration"] == 127
    assert dce["o2_kept"]["work_present"] is True
    assert any("push_back" in line for line in dce["o2_kept"]["disassembly"])
    assert any("store" in line for line in dce["o2_kept"]["disassembly"])
    assert dce["o0_keeps_work_without_escape"]
    assert dce["o0_unused"]["cycles_per_iteration"] == 127
    assert dce["fold_drops_known_expr"]
    assert dce["folded_const_expr"]["cycles_per_iteration"] == 0
    assert "DoNotOptimize 42" in dce["folded_const_expr"]["disassembly"]
    assert dce["reserve_work_present"]
    assert dce["o2_reserve_kept"]["cycles_per_iteration"] == 64
    assert "lvalue" in dce["rvalue_advice"]["diagnostic"].lower() or "lvalue" in dce["rvalue_advice"]["diagnostic"]

    cmp_ = r["reserve_compare"]
    assert cmp_["freq_scaling"] is False and cmp_["affinity_pinned"] is True
    assert cmp_["mean_no_reserve"] == 127.0
    assert cmp_["mean_reserve"] == 64.0
    assert cmp_["delta"] == 63.0
    assert cmp_["ratio_no_over_reserve"] == 1.9844
    assert cmp_["both_work_present"] and cmp_["reserve_is_cheaper"]
    assert cmp_["isolated_zero_variance"]
    assert cmp_["no_reserve"]["stats"]["stddev"] == 0.0
    assert cmp_["reserve"]["stats"]["cv"] == 0.0
    assert cmp_["reserve"]["stats"]["ci_low"] == 64.0
    assert cmp_["reserve"]["stats"]["ci_high"] == 64.0
    assert cmp_["reserve"]["stats"]["ci_is_teaching"] is True
    assert cmp_["no_reserve"]["work_present"] and cmp_["reserve"]["work_present"]
    assert any("grow" in line for line in cmp_["no_reserve"]["disassembly"])
    assert any("reserve" in line for line in cmp_["reserve"]["disassembly"])

    reps = r["repetitions"]
    assert reps["single_run_baseline"] == 64.0
    assert reps["single_run_tweaked"] == 60.8
    assert reps["single_run_tweaked_faster_rel"] == 0.05
    assert reps["single_run_looks_like_a_few_percent"]
    assert reps["means_equal"]
    assert reps["baseline"]["stats"]["mean"] == 64.0
    assert reps["tweaked"]["stats"]["mean"] == 64.0
    assert reps["cis_overlap"]
    assert reps["same_true_cost"]
    assert reps["pitfall_single_run_not_enough"]
    # With variance, the teaching interval is wider than a point estimate.
    assert reps["baseline"]["stats"]["stddev"] > 0.0
    assert reps["baseline"]["stats"]["ci_halfwidth"] > 0.0

    env = r["environment"]
    assert env["isolated_cv"] == 0.0
    assert env["scaling_noisier_than_isolated"]
    assert env["unpinned_noisier_than_isolated"]
    assert env["noisy_noisier_than_either"]
    assert env["noisy_cis_still_separate"]
    assert env["isolated"]["stats"]["mean"] == 64.0
    # Scaling keeps the mean at the true cost because the table averages to 100.
    assert env["scaling"]["stats"]["mean"] == 64.0
    # Unpinned slower cores raise the mean above the true cost.
    assert env["unpinned"]["stats"]["mean"] > 64.0
    assert env["noisy"]["stats"]["mean"] > env["scaling"]["stats"]["mean"]

    assert r["acceptance_compiler_version_emitted"]
    assert r["acceptance_disassembly_shows_work"]
    assert r["practice_compares_reserve"]
    assert r["pitfall_single_run_not_enough"]
    assert r["tradeoff_isolation_still_needs_service_validation"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
