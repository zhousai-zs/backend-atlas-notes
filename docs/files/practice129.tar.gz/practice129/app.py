#!/usr/bin/env python3
"""Run the lesson 129 reproducible microbenchmark experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    COMPILER_ID,
    COMPILER_VERSION,
    COST_NO_RESERVE,
    COST_RESERVE,
    FREQ_HUNDREDTHS,
    FREQ_HUNDREDTHS_B,
    ITERATIONS,
    KEY_TITLE,
    MEASURE_REPS,
    N_INSERT,
    TEACHING_FLAGS_O2,
    TITLE_V1,
    WARMUP_REPS,
    BenchmarkEngine,
    cis_overlap,
    ts,
)


def _context() -> dict[str, Any]:
    return {
        "compiler_id": COMPILER_ID,
        "compiler_version": COMPILER_VERSION,
        "compiler_is_teaching": True,
        "compiler_note": (
            "AtlasTeachCC is a teaching compiler used by this engine. "
            "It is not a host g++ or clang, and no real object file is produced."
        ),
        "flags": TEACHING_FLAGS_O2,
        "n_insert": N_INSERT,
        "iterations": ITERATIONS,
        "warmup_reps": WARMUP_REPS,
        "measure_reps": MEASURE_REPS,
        "cost_no_reserve": COST_NO_RESERVE,
        "cost_reserve": COST_RESERVE,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "cycles_are_teaching": True,
    }


def run_dce_vs_donotoptimize() -> dict[str, Any]:
    eng = BenchmarkEngine()
    o2_unused = eng.compile_and_cost(
        reserved=False, opt="O2", donotoptimize=None, clobber_memory=False
    )
    o2_kept = eng.compile_and_cost(
        reserved=False, opt="O2", donotoptimize="lvalue", clobber_memory=True
    )
    o0_unused = eng.compile_and_cost(
        reserved=False, opt="O0", donotoptimize=None, clobber_memory=False
    )
    o2_reserve_kept = eng.compile_and_cost(
        reserved=True, opt="O2", donotoptimize="lvalue", clobber_memory=True
    )
    folded = eng.compile_and_cost(
        reserved=False,
        opt="O2",
        donotoptimize="rvalue",
        clobber_memory=True,
        fold_const_expr=True,
    )
    rvalue_advice = eng.compile_and_cost(
        reserved=True, opt="O2", donotoptimize="rvalue", clobber_memory=True
    )
    return {
        "o2_unused": o2_unused,
        "o2_kept": o2_kept,
        "o0_unused": o0_unused,
        "o2_reserve_kept": o2_reserve_kept,
        "folded_const_expr": folded,
        "rvalue_advice": rvalue_advice,
        "dce_drops_unused_work": (
            (not o2_unused["work_present"]) and o2_unused["cycles_per_iteration"] == 0
        ),
        "donotoptimize_keeps_work": (
            o2_kept["work_present"]
            and o2_kept["cycles_per_iteration"] == COST_NO_RESERVE
        ),
        "o0_keeps_work_without_escape": (
            o0_unused["work_present"]
            and o0_unused["cycles_per_iteration"] == COST_NO_RESERVE
        ),
        "fold_drops_known_expr": (
            (not folded["work_present"]) and folded["cycles_per_iteration"] == 0
        ),
        "reserve_work_present": o2_reserve_kept["work_present"],
    }


def run_reserve_compare() -> dict[str, Any]:
    eng = BenchmarkEngine()
    no_res = eng.run_bench(
        reserved=False,
        freq_scaling=False,
        affinity_pinned=True,
        name="BM_insert_no_reserve",
    )
    res = eng.run_bench(
        reserved=True,
        freq_scaling=False,
        affinity_pinned=True,
        name="BM_insert_reserve",
    )
    mean_no = no_res["stats"]["mean"]
    mean_yes = res["stats"]["mean"]
    return {
        "environment": "isolated",
        "freq_scaling": False,
        "affinity_pinned": True,
        "no_reserve": no_res,
        "reserve": res,
        "mean_no_reserve": mean_no,
        "mean_reserve": mean_yes,
        "ratio_no_over_reserve": ts(mean_no / mean_yes) if mean_yes else 0.0,
        "delta": ts(mean_no - mean_yes),
        "both_work_present": no_res["work_present"] and res["work_present"],
        "reserve_is_cheaper": mean_yes < mean_no,
        "isolated_zero_variance": (
            no_res["stats"]["stddev"] == 0.0 and res["stats"]["stddev"] == 0.0
        ),
    }


def run_repetitions_ci() -> dict[str, Any]:
    """Same reserved insertion, two names, under frequency noise.

    A single pair of first-run samples can look a few percent apart.
    After nine repetitions the teaching intervals overlap, so that
    difference is not enough to announce an optimization.
    """
    eng = BenchmarkEngine()
    baseline = eng.run_bench(
        reserved=True,
        freq_scaling=True,
        affinity_pinned=True,
        freq_table=FREQ_HUNDREDTHS,
        name="BM_insert_reserve",
    )
    tweaked = eng.run_bench(
        reserved=True,
        freq_scaling=True,
        affinity_pinned=True,
        freq_table=FREQ_HUNDREDTHS_B,
        name="BM_insert_reserve_tweaked",
    )
    first_a = baseline["samples"][0]
    first_b = tweaked["samples"][0]
    rel = (first_a - first_b) / first_a if first_a else 0.0
    overlap = cis_overlap(baseline["stats"], tweaked["stats"])
    return {
        "baseline": baseline,
        "tweaked": tweaked,
        "single_run_baseline": first_a,
        "single_run_tweaked": first_b,
        "single_run_tweaked_faster_rel": ts(rel),
        "single_run_looks_like_a_few_percent": 0.04 <= rel <= 0.06,
        "means_equal": baseline["stats"]["mean"] == tweaked["stats"]["mean"],
        "cis_overlap": overlap,
        "same_true_cost": baseline["base_cycles"] == tweaked["base_cycles"] == COST_RESERVE,
        "pitfall_single_run_not_enough": (
            0.04 <= rel <= 0.06 and overlap and baseline["stats"]["mean"] == tweaked["stats"]["mean"]
        ),
    }


def run_freq_affinity() -> dict[str, Any]:
    eng = BenchmarkEngine()
    isolated = eng.run_bench(
        reserved=True,
        freq_scaling=False,
        affinity_pinned=True,
        name="BM_insert_reserve_isolated",
    )
    scaling = eng.run_bench(
        reserved=True,
        freq_scaling=True,
        affinity_pinned=True,
        name="BM_insert_reserve_scaling",
    )
    unpinned = eng.run_bench(
        reserved=True,
        freq_scaling=False,
        affinity_pinned=False,
        name="BM_insert_reserve_unpinned",
    )
    noisy = eng.run_bench(
        reserved=True,
        freq_scaling=True,
        affinity_pinned=False,
        name="BM_insert_reserve_noisy",
    )
    # Also show reserve vs no-reserve still separates under noise.
    no_res_noisy = eng.run_bench(
        reserved=False,
        freq_scaling=True,
        affinity_pinned=False,
        name="BM_insert_no_reserve_noisy",
    )
    return {
        "isolated": isolated,
        "scaling": scaling,
        "unpinned": unpinned,
        "noisy": noisy,
        "no_reserve_noisy": no_res_noisy,
        "isolated_cv": isolated["stats"]["cv"],
        "scaling_cv": scaling["stats"]["cv"],
        "unpinned_cv": unpinned["stats"]["cv"],
        "noisy_cv": noisy["stats"]["cv"],
        "scaling_noisier_than_isolated": scaling["stats"]["cv"] > isolated["stats"]["cv"],
        "unpinned_noisier_than_isolated": unpinned["stats"]["cv"] > isolated["stats"]["cv"],
        "noisy_noisier_than_either": (
            noisy["stats"]["cv"] > scaling["stats"]["cv"]
            and noisy["stats"]["cv"] > unpinned["stats"]["cv"]
        ),
        "noisy_cis_still_separate": not cis_overlap(
            noisy["stats"], no_res_noisy["stats"]
        ),
    }


def run() -> dict[str, Any]:
    context = _context()
    dce = run_dce_vs_donotoptimize()
    compare = run_reserve_compare()
    reps = run_repetitions_ci()
    env = run_freq_affinity()
    return {
        "engine": "BenchmarkEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_benchmark_product": True,
        "not_google_benchmark": True,
        "not_host_gxx": True,
        "cycles_are_teaching": True,
        **context,
        "dce": dce,
        "reserve_compare": compare,
        "repetitions": reps,
        "environment": env,
        "acceptance_compiler_version_emitted": (
            context["compiler_id"] == COMPILER_ID
            and context["compiler_version"] == COMPILER_VERSION
            and context["flags"] == TEACHING_FLAGS_O2
            and context["compiler_is_teaching"]
        ),
        "acceptance_disassembly_shows_work": (
            dce["donotoptimize_keeps_work"]
            and dce["reserve_work_present"]
            and compare["both_work_present"]
        ),
        "practice_compares_reserve": (
            compare["reserve_is_cheaper"]
            and compare["mean_no_reserve"] == float(COST_NO_RESERVE)
            and compare["mean_reserve"] == float(COST_RESERVE)
        ),
        "pitfall_single_run_not_enough": reps["pitfall_single_run_not_enough"],
        "tradeoff_isolation_still_needs_service_validation": True,
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {path}")
