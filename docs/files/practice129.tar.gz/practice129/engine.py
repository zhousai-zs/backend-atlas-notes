#!/usr/bin/env python3
"""Teaching BenchmarkEngine — not Redis, not a real benchmark product, not a network service.

A Python 3 standard-library model of a reproducible microbenchmark of
teaching-vector insertion, with and without reserve. It is used to show
DoNotOptimize (and its limits), repeated sampling with a teaching
confidence interval, and the effect of CPU frequency scaling and affinity
on comparability.

The named source (checked on 2026-11-14) is the Google Benchmark User
Guide at https://github.com/google/benchmark/blob/main/docs/user_guide.md
(and the follow-through page docs/reducing_variance.md, which the Guide
names under Disabling CPU Frequency Scaling). The Guide defines
DoNotOptimize / ClobberMemory, repetitions that report mean, median,
standard deviation and coefficient of variation, warmup, and a warning
that CPU frequency scaling makes real-time measurements noisy. It does
not define a confidence interval; the teaching interval used here is
labeled as such. This engine is not the Google Benchmark library, not a
host g++ / clang invocation, and not a wall-clock microbenchmark.
Costs are teaching virtual cycles, not production RTT and not nanoseconds
measured on a real CPU.
"""
from __future__ import annotations

import math
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
N_INSERT = 64
WRITE_COST = 1
COPY_COST = 1
ITERATIONS = 100
WARMUP_REPS = 1
MEASURE_REPS = 9
COMPILER_ID = "AtlasTeachCC"
COMPILER_VERSION = "1.0"
# Teaching compiler identity. Not a host g++ or clang, and not a real
# object file. Flags are teaching labels that switch the DCE model.
TEACHING_FLAGS_O2 = "-O2"
TEACHING_FLAGS_O0 = "-O0"
# Normal-approximation teaching 95% interval. Not a Google Benchmark statistic.
Z_95 = 1.96
# Frequency multipliers in hundredths, mean 100, used when scaling is on.
# Sum is 900 so the nine measured repetitions average to the true cost.
FREQ_HUNDREDTHS = (100, 95, 105, 92, 108, 97, 103, 89, 111)
# A permutation of the same table, used for an identical-cost "tweaked"
# bench so a single noisy run can look a few percent faster.
FREQ_HUNDREDTHS_B = (95, 108, 92, 111, 97, 89, 103, 100, 105)
# Unpinned affinity: these measured-rep indices (0-based) land on a slower
# teaching core. The 1.15 factor is a teaching analogue, not a measured
# turbo or cross-core ratio from the Guide.
SLOWER_CORE_INDICES = (2, 5, 8)
SLOWER_CORE_HUNDREDTHS = 115


def ts(t: float, nd: int = 4) -> float:
    return round(float(t) + 1e-12, nd)


def insert_cost(n: int, reserved: bool) -> int:
    """Geometric-growth teaching-vector cost in virtual cycles."""
    cap = n if reserved else 0
    cost = 0
    size = 0
    for _ in range(n):
        if size == cap:
            new_cap = 1 if cap == 0 else cap * 2
            cost += COPY_COST * size
            cap = new_cap
        cost += WRITE_COST
        size += 1
    return cost


def mean(xs: list[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0


def median(xs: list[float]) -> float:
    if not xs:
        return 0.0
    ys = sorted(xs)
    n = len(ys)
    mid = n // 2
    if n % 2:
        return float(ys[mid])
    return (ys[mid - 1] + ys[mid]) / 2.0


def sample_stddev(xs: list[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    m = mean(xs)
    acc = sum((x - m) ** 2 for x in xs)
    return math.sqrt(acc / (n - 1))


def coefficient_of_variation(xs: list[float]) -> float:
    m = mean(xs)
    if m == 0.0:
        return 0.0
    return sample_stddev(xs) / m


def teaching_ci(xs: list[float]) -> dict[str, float]:
    """mean ± 1.96 * s / sqrt(n). Teaching interval, not a Guide statistic."""
    n = len(xs)
    m = mean(xs)
    s = sample_stddev(xs)
    half = 0.0 if n == 0 else Z_95 * s / math.sqrt(n)
    return {
        "mean": ts(m),
        "median": ts(median(xs)),
        "stddev": ts(s),
        "cv": ts(coefficient_of_variation(xs)),
        "n": n,
        "ci_low": ts(m - half),
        "ci_high": ts(m + half),
        "ci_halfwidth": ts(half),
        "ci_is_teaching": True,
        "z": Z_95,
    }


def cis_overlap(a: dict[str, float], b: dict[str, float]) -> bool:
    return not (a["ci_high"] < b["ci_low"] or b["ci_high"] < a["ci_low"])


class BenchmarkEngine:
    """Deterministic teaching microbenchmark runner."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1

    def compile_and_cost(
        self,
        *,
        reserved: bool,
        opt: str = "O2",
        donotoptimize: Optional[str] = "lvalue",
        clobber_memory: bool = True,
        fold_const_expr: bool = False,
        n: int = N_INSERT,
    ) -> dict[str, Any]:
        """Model DCE versus DoNotOptimize and emit teaching disassembly.

        donotoptimize: None (no escape), "lvalue" (preferred, as in the
        Guide), or "rvalue" (the form the Guide warns against for a
        known result).
        fold_const_expr: teaching analogue of DoNotOptimize(foo(0)) being
        reduced to DoNotOptimize(42) — the expression itself may vanish.
        """
        flags = TEACHING_FLAGS_O2 if opt == "O2" else TEACHING_FLAGS_O0
        true_cost = insert_cost(n, reserved)
        # O2 deletes unused insertion work unless the buffer is escaped
        # and pending writes are clobbered, matching the Guide's vector
        # push_back example in spirit (not as a compiled translation).
        kept = True
        diagnostic = ""
        if fold_const_expr:
            # The result is already known; the call body is not measured.
            kept = False
            true_cost = 0
            diagnostic = (
                "DoNotOptimize does not prevent optimizations on the "
                "expression itself; a known result may be used in place "
                "of the original work."
            )
        elif opt == "O2" and not (donotoptimize and clobber_memory):
            kept = False
            true_cost = 0
            diagnostic = (
                "At -O2, unused insertion work is deleted unless the "
                "buffer is escaped with a DoNotOptimize lvalue and "
                "ClobberMemory forces the stores to remain."
            )
        elif opt == "O2" and donotoptimize == "rvalue":
            # Still keep work for a non-folded insertion, but record the
            # Guide's advice to materialize an lvalue.
            diagnostic = (
                "Prefer materializing a local lvalue and passing that to "
                "DoNotOptimize; a const-result rvalue is the form the "
                "Guide warns against."
            )

        asm = self._disassembly(
            reserved=reserved,
            n=n,
            kept=kept,
            donotoptimize=donotoptimize,
            clobber_memory=clobber_memory,
            fold_const_expr=fold_const_expr,
        )
        work_present = kept and any(
            tok in line for line in asm for tok in ("store", "push_back", "grow")
        )
        return {
            "n": n,
            "reserved": reserved,
            "opt": opt,
            "flags": flags,
            "compiler_id": COMPILER_ID,
            "compiler_version": COMPILER_VERSION,
            "compiler_is_teaching": True,
            "donotoptimize": donotoptimize,
            "clobber_memory": clobber_memory,
            "fold_const_expr": fold_const_expr,
            "cycles_per_iteration": true_cost,
            "work_present": work_present,
            "disassembly": asm,
            "diagnostic": diagnostic,
        }

    def _disassembly(
        self,
        *,
        reserved: bool,
        n: int,
        kept: bool,
        donotoptimize: Optional[str],
        clobber_memory: bool,
        fold_const_expr: bool,
    ) -> list[str]:
        if fold_const_expr:
            return [
                "# teaching IR, not objdump of a real binary",
                "const 42",
                "DoNotOptimize 42",
                "ret",
            ]
        if not kept:
            return [
                "# teaching IR, not objdump of a real binary",
                "# insertion loop deleted: result unused, no escape, no clobber",
                "ret",
            ]
        lines = [
            "# teaching IR, not objdump of a real binary",
            f"alloc v, cap={'n' if reserved else '0'}",
        ]
        if reserved:
            lines.append(f"reserve v, {n}")
        lines.append(f"loop i in 0..{n - 1}:")
        if not reserved:
            lines.append("  grow v if size == cap")
        lines.append("  push_back v, i")
        lines.append("  store v[i], i")
        if donotoptimize:
            target = "v.data" if donotoptimize == "lvalue" else "tmp_rvalue"
            lines.append(f"DoNotOptimize {target}")
        if clobber_memory:
            lines.append("ClobberMemory")
        lines.append("ret")
        return lines

    def run_bench(
        self,
        *,
        reserved: bool,
        freq_scaling: bool = False,
        affinity_pinned: bool = True,
        freq_table: tuple[int, ...] = FREQ_HUNDREDTHS,
        opt: str = "O2",
        donotoptimize: Optional[str] = "lvalue",
        clobber_memory: bool = True,
        n: int = N_INSERT,
        measure_reps: int = MEASURE_REPS,
        warmup_reps: int = WARMUP_REPS,
        name: str = "",
    ) -> dict[str, Any]:
        compiled = self.compile_and_cost(
            reserved=reserved,
            opt=opt,
            donotoptimize=donotoptimize,
            clobber_memory=clobber_memory,
            n=n,
        )
        base = compiled["cycles_per_iteration"]
        warmup = []
        measured = []
        # Warmup uses the same environment model but is discarded, as in
        # the Guide (results gathered in the warmup period are not used).
        total_reps = warmup_reps + measure_reps
        for i in range(total_reps):
            measured_index = i - warmup_reps
            if freq_scaling:
                table = freq_table
                # Warmup rows reuse the first entry; only measured rows
                # walk the table.
                if measured_index >= 0:
                    hundredths = table[measured_index % len(table)]
                else:
                    hundredths = table[0]
            else:
                hundredths = 100
            if (not affinity_pinned) and measured_index in SLOWER_CORE_INDICES:
                core = SLOWER_CORE_HUNDREDTHS
                cpu = 1
            else:
                core = 100
                cpu = 0
            cycles = base * (hundredths / 100.0) * (core / 100.0)
            rec = {
                "rep": i,
                "measured": measured_index >= 0,
                "freq_hundredths": hundredths,
                "core_hundredths": core,
                "cpu": cpu,
                "cycles_per_iteration": ts(cycles),
            }
            if measured_index >= 0:
                measured.append(rec)
            else:
                warmup.append(rec)
        samples = [row["cycles_per_iteration"] for row in measured]
        stats = teaching_ci(samples)
        return {
            "name": name,
            "reserved": reserved,
            "n": n,
            "iterations": ITERATIONS,
            "freq_scaling": freq_scaling,
            "affinity_pinned": affinity_pinned,
            "base_cycles": base,
            "compiler_id": compiled["compiler_id"],
            "compiler_version": compiled["compiler_version"],
            "compiler_is_teaching": True,
            "flags": compiled["flags"],
            "donotoptimize": donotoptimize,
            "clobber_memory": clobber_memory,
            "work_present": compiled["work_present"],
            "disassembly": compiled["disassembly"],
            "diagnostic": compiled["diagnostic"],
            "warmup_reps": warmup,
            "measured_reps": measured,
            "samples": samples,
            "stats": stats,
        }


COST_NO_RESERVE = insert_cost(N_INSERT, False)
COST_RESERVE = insert_cost(N_INSERT, True)
