// 教学用 Task + 手动恢复器：统计协程帧创建/销毁次数，检查异常路径
#include <coroutine>
#include <cstdio>
#include <exception>
#include <stdexcept>
#include <thread>
#include <cstdlib>
#include <new>
#include <string>
#include <functional>
#include <utility>

static int frames_alive = 0, frames_created = 0;

struct Task {
  struct promise_type {
    int value = 0;
    std::exception_ptr err;
    // 统计帧分配：编译器用 promise_type::operator new 分配整个协程帧
    static void* operator new(std::size_t n) { ++frames_created; ++frames_alive; return ::operator new(n); }
    static void operator delete(void* p) noexcept { --frames_alive; ::operator delete(p); }
    Task get_return_object() { return Task{std::coroutine_handle<promise_type>::from_promise(*this)}; }
    std::suspend_always initial_suspend() noexcept { return {}; }   // 懒启动：创建后先挂起
    std::suspend_always final_suspend() noexcept { return {}; }     // 结束后挂起，由 Task 析构负责 destroy
    void return_value(int v) { value = v; }
    void unhandled_exception() { err = std::current_exception(); }
  };
  std::coroutine_handle<promise_type> h;
  explicit Task(std::coroutine_handle<promise_type> h) : h(h) {}
  Task(Task&& o) noexcept : h(std::exchange(o.h, {})) {}
  Task(const Task&) = delete;
  ~Task() { if (h) h.destroy(); }   // 帧恰好销毁一次
  bool resume() { if (!h.done()) h.resume(); return !h.done(); } // 手动恢复器
  int get() { if (h.promise().err) std::rethrow_exception(h.promise().err); return h.promise().value; }
};

// 一个最简单的 awaitable：记录 resume 前后的线程 id
struct Yield {
  bool await_ready() const noexcept { return false; }
  void await_suspend(std::coroutine_handle<>) const noexcept {}
  void await_resume() const noexcept {}
};

std::thread::id before_id, after_id;

Task add_steps(int a, int b) {
  before_id = std::this_thread::get_id();
  co_await Yield{};            // 暂停点 1
  after_id = std::this_thread::get_id();
  co_await Yield{};            // 暂停点 2
  co_return a + b;
}

Task may_throw(bool fail) {
  co_await Yield{};
  if (fail) throw std::runtime_error("db timeout");
  co_return 1;
}

#define CHECK(c) do { if (!(c)) { std::printf("FAIL %s line %d\n", #c, __LINE__); std::exit(1); } } while (0)

int main() {
  { // 1. 正常路径：懒启动 + 手动恢复次数
    Task t = add_steps(2, 3);
    CHECK(frames_alive == 1);
    int resumes = 0;
    while (t.resume()) ++resumes;   // 第1次跑到暂停点1 后返回 true...
    std::printf("resumes_until_done=%d value=%d\n", resumes + 1, t.get());
    CHECK(t.get() == 5);
    CHECK(before_id == after_id);    // co_await 不一定切换线程
    std::puts("same_thread_after_co_await=yes");
  }
  CHECK(frames_alive == 0);
  { // 2. 异常路径：异常被 promise 捕获，get() 时重新抛出
    Task t = may_throw(true);
    while (t.resume()) {}
    bool caught = false;
    try { t.get(); } catch (const std::runtime_error& e) { caught = true; std::printf("rethrown=%s\n", e.what()); }
    CHECK(caught);
  }
  CHECK(frames_alive == 0);
  { // 3. 未跑完就销毁：挂起中的帧也会被 destroy 一次
    Task t = add_steps(1, 1);
    t.resume();
    CHECK(!t.h.done());
  }
  CHECK(frames_alive == 0);
  { // 4. 移动 Task 后只销毁一次
    Task a = add_steps(4, 4);
    Task b = std::move(a);
    while (b.resume()) {}
    CHECK(b.get() == 8);
  }
  std::printf("frames_created=%d frames_alive=%d\n", frames_created, frames_alive);
  CHECK(frames_alive == 0 && frames_created == 4);
  std::puts("ALL_CHECKS_PASSED");
}
