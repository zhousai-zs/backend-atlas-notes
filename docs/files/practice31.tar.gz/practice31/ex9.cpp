#include <cassert>
#include <coroutine>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

class Task {
public:
    struct promise_type {
        promise_type() { std::cout << "[promise ctor]\n"; }
        ~promise_type() { std::cout << "[promise dtor]\n"; }

        Task get_return_object() {
            return Task{std::coroutine_handle<promise_type>::from_promise(*this)};
        }
        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        void return_void() noexcept {}
        void unhandled_exception() noexcept { error = std::current_exception(); }

        std::exception_ptr error;
    };

    Task() noexcept = default;
    explicit Task(std::coroutine_handle<promise_type> h) noexcept : h_(h) {}
    Task(Task&& other) noexcept : h_(std::exchange(other.h_, nullptr)) {}
    Task& operator=(Task&& other) noexcept {
        if (this != &other) {
            reset();
            h_ = std::exchange(other.h_, nullptr);
        }
        return *this;
    }
    Task(const Task&) = delete;
    Task& operator=(const Task&) = delete;
    ~Task() { reset(); }

    bool done() const noexcept { return !h_ || h_.done(); }

    void resume() {
        if (!h_) throw std::logic_error("empty Task");
        if (h_.done()) throw std::logic_error("finished Task");
        h_.resume();
        if (h_.done() && h_.promise().error) {
            std::rethrow_exception(h_.promise().error);
        }
    }

private:
    void reset() noexcept {
        if (h_) {
            h_.destroy();
            h_ = {};
        }
    }

    std::coroutine_handle<promise_type> h_{};
};

class ManualRunner {
public:
    explicit ManualRunner(Task&& task) : task_(std::move(task)) {}

    bool step() {
        task_.resume();
        return task_.done();
    }

    bool done() const noexcept { return task_.done(); }

private:
    Task task_;
};

struct LocalState {
    explicit LocalState(std::string name) : name_(std::move(name)) {
        std::cout << "[local ctor] " << name_ << '\n';
    }
    ~LocalState() {
        std::cout << "[local dtor] " << name_ << '\n';
    }

    std::string name_;
};

Task lifecycle_demo() {
    LocalState state{"request-state"};
    std::cout << "[body] before suspend " << state.name_ << '\n';
    co_await std::suspend_always{};
    std::cout << "[body] after resume\n";
}

Task failing_demo() {
    co_await std::suspend_always{};
    throw std::runtime_error("rpc timeout");
}

int main() {
    {
        ManualRunner runner{lifecycle_demo()};
        std::cout << "[caller] step 1\n";
        runner.step();
        std::cout << "[caller] step 2\n";
        runner.step();
        assert(runner.done());
        std::cout << "[caller] scope end\n";
    }

    std::cout << "--- exception path ---\n";

    {
        ManualRunner runner{failing_demo()};
        runner.step();
        try {
            runner.step();
        } catch (const std::runtime_error& e) {
            std::cout << "[caller] caught " << e.what() << '\n';
        }
        assert(runner.done());
        std::cout << "[caller] scope end\n";
    }
}
