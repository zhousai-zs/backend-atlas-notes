#!/bin/bash
set -e
cd "$(dirname "$0")"
g++ -std=c++20 -Wall -Wextra -g -fsanitize=address,undefined task.cpp -o task
./task
g++ -std=c++20 -g -fsanitize=address lambda_bug.cpp -o lambda_bug
./lambda_bug && echo "good_version_ok"
if ./lambda_bug bad 2> bad.log; then echo "UNEXPECTED: bad version did not crash"; exit 1; fi
grep -m1 -o "heap-use-after-free\|stack-use-after-scope\|stack-use-after-return" bad.log
echo "lambda_capture_bug_detected"
