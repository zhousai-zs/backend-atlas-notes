#include <coroutine>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <utility>

class Task {
public:
    struct promise_type {
        Task get_return_object() {
            return Task{std::coroutine_handle<promise_type>::from_promise(*this)};
        }
        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        void return_void() noexcept {}
        void unhandled_exception() noexcept { error = std::current_exception(); }

        std::exception_ptr error;
    };

    Task() noexcept = default;
    explicit Task(std::coroutine_handle<promise_type> h) noexcept : h_(h) {}
    Task(Task&& other) noexcept : h_(std::exchange(other.h_, nullptr)) {}
    Task& operator=(Task&& other) noexcept {
        if (this != &other) {
            reset();
            h_ = std::exchange(other.h_, nullptr);
        }
        return *this;
    }
    Task(const Task&) = delete;
    Task& operator=(const Task&) = delete;
    ~Task() { reset(); }

    bool done() const noexcept { return !h_ || h_.done(); }

    void resume() {
        if (!h_) throw std::logic_error("empty Task");
        if (h_.done()) throw std::logic_error("finished Task");
        h_.resume();
        if (h_.done() && h_.promise().error) {
            std::rethrow_exception(h_.promise().error);
        }
    }

private:
    void reset() noexcept {
        if (h_) {
            h_.destroy();
            h_ = {};
        }
    }

    std::coroutine_handle<promise_type> h_{};
};

struct InspectAwaiter {
    bool ready;
    bool await_ready() const noexcept { return ready; }
    void await_suspend(std::coroutine_handle<>) const noexcept {
        std::cout << "suspend on " << std::this_thread::get_id() << '\n';
    }
    int await_resume() const noexcept {
        std::cout << "resume on " << std::this_thread::get_id() << '\n';
        return 7;
    }
};

Task inspect(bool ready) {
    const int value = co_await InspectAwaiter{ready};
    std::cout << "value=" << value << '\n';
}

int main() {
    Task t = inspect(false);
    std::cout << "caller on " << std::this_thread::get_id() << '\n';
    t.resume();
    t.resume();
}
