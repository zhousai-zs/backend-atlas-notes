#include <coroutine>
#include <exception>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <utility>

class Task {
public:
    struct promise_type {
        Task get_return_object() {
            return Task{std::coroutine_handle<promise_type>::from_promise(*this)};
        }
        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        void return_void() noexcept {}
        void unhandled_exception() noexcept { error = std::current_exception(); }

        std::exception_ptr error;
    };

    Task() noexcept = default;
    explicit Task(std::coroutine_handle<promise_type> h) noexcept : h_(h) {}
    Task(Task&& other) noexcept : h_(std::exchange(other.h_, nullptr)) {}
    Task& operator=(Task&& other) noexcept {
        if (this != &other) {
            reset();
            h_ = std::exchange(other.h_, nullptr);
        }
        return *this;
    }
    Task(const Task&) = delete;
    Task& operator=(const Task&) = delete;
    ~Task() { reset(); }

    bool done() const noexcept { return !h_ || h_.done(); }

    void resume() {
        if (!h_) throw std::logic_error("empty Task");
        if (h_.done()) throw std::logic_error("finished Task");
        h_.resume();
        if (h_.done() && h_.promise().error) {
            std::rethrow_exception(h_.promise().error);
        }
    }

private:
    void reset() noexcept {
        if (h_) {
            h_.destroy();
            h_ = {};
        }
    }

    std::coroutine_handle<promise_type> h_{};
};

Task failing() {
    co_await std::suspend_always{};
    throw std::runtime_error("rpc timeout");
}

int main() {
    Task t = failing();
    t.resume();
    try {
        t.resume();
    } catch (const std::runtime_error& e) {
        std::cout << "caught: " << e.what() << '\n';
    }
    std::cout << std::boolalpha << "done=" << t.done() << '\n';
}
