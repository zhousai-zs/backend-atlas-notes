// 误区：临时 lambda 的捕获早于协程帧结束就被销毁
#include <coroutine>
#include <cstdio>
#include <string>
#include <utility>
struct Task {
  struct promise_type {
    Task get_return_object() { return Task{std::coroutine_handle<promise_type>::from_promise(*this)}; }
    std::suspend_always initial_suspend() noexcept { return {}; }
    std::suspend_always final_suspend() noexcept { return {}; }
    void return_void() {}
    void unhandled_exception() {}
  };
  std::coroutine_handle<promise_type> h;
  ~Task() { if (h) h.destroy(); }
};
Task make_bad() {
  std::string user = std::string(64, 'u');
  // lambda 本身是临时对象，协程帧只保存 this(=lambda 指针)，捕获的 user 在 lambda 析构后悬垂
  auto t = [user]() -> Task { std::printf("user=%zu\n", user.size()); co_return; }();
  return t;   // 临时 lambda 在这里已经析构
}
Task good(std::string user) {   // 修复：按值作为协程参数，参数会被拷进帧
  std::printf("user=%zu\n", user.size()); co_return;
}
int main(int argc, char**) {
  if (argc > 1) { Task t = make_bad(); t.h.resume(); }
  else { Task t = good(std::string(64, 'u')); t.h.resume(); }
}
