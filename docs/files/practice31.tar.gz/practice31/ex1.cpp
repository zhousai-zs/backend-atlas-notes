#include <coroutine>
#include <exception>
#include <iostream>
#include <utility>

struct MiniTask {
    struct promise_type {
        promise_type() { std::cout << "[promise ctor]\n"; }
        ~promise_type() { std::cout << "[promise dtor]\n"; }

        MiniTask get_return_object() {
            return MiniTask{std::coroutine_handle<promise_type>::from_promise(*this)};
        }
        std::suspend_always initial_suspend() noexcept { return {}; }
        std::suspend_always final_suspend() noexcept { return {}; }
        void return_void() noexcept {}
        void unhandled_exception() noexcept { std::terminate(); }
    };

    explicit MiniTask(std::coroutine_handle<promise_type> handle) noexcept : h(handle) {}
    MiniTask(MiniTask&& other) noexcept : h(std::exchange(other.h, nullptr)) {}
    MiniTask& operator=(MiniTask&& other) noexcept {
        if (this != &other) {
            if (h) h.destroy();
            h = std::exchange(other.h, nullptr);
        }
        return *this;
    }
    MiniTask(const MiniTask&) = delete;
    MiniTask& operator=(const MiniTask&) = delete;
    ~MiniTask() { if (h) h.destroy(); }

    std::coroutine_handle<promise_type> h{};
};

struct Probe {
    ~Probe() { std::cout << "[local dtor]\n"; }
};

MiniTask demo() {
    Probe p;
    std::cout << "[body] A\n";
    co_await std::suspend_always{};
    std::cout << "[body] B\n";
}

int main() {
    auto t = demo();
    t.h.resume();
    std::cout << "[caller]\n";
    t.h.resume();
}
