#!/usr/bin/env bash
# Backend Atlas 第54课：poll 聊天、HUP+残留数据、POLLNVAL
set -u
cd "$(dirname "$0")"
fail=0
ok(){ echo "PASS: $1"; }
bad(){ echo "FAIL: $1"; fail=1; }

PORT=18054
fuser -k ${PORT}/tcp 2>/dev/null || true
sleep 0.2
rm -f /tmp/poll54-srv.log /tmp/poll54-*.out

python3 server.py "$PORT" > /tmp/poll54-srv.log 2>&1 &
SRV=$!
cleanup(){
  kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
  fuser -k ${PORT}/tcp 2>/dev/null || true
  pkill -f "practice54/client.py" 2>/dev/null || true
}
trap cleanup EXIT
sleep 0.4
if ! kill -0 $SRV 2>/dev/null; then
  echo "server failed to start:"; cat /tmp/poll54-srv.log; exit 1
fi
ok "server listening on 127.0.0.1:$PORT (pid=$SRV)"

SSOUT=$(ss -ltnp "sport = :$PORT" 2>/dev/null || ss -ltnp | grep ":$PORT" || true)
echo "$SSOUT" | head -3
echo "$SSOUT" | grep -q ":$PORT" && ok "ss 可见 TCP 监听 :$PORT" || bad "ss 未见 TCP :$PORT"

# --- 1) 两客户端互相广播 ---
python3 client.py --port "$PORT" --expect "from-A" --timeout 8 > /tmp/poll54-b.out 2>&1 &
B=$!
sleep 0.2
python3 client.py --port "$PORT" --expect "from-B" --timeout 8 > /tmp/poll54-a.out 2>&1 &
A=$!
sleep 0.25

python3 - "$PORT" <<'PY' > /tmp/poll54-send1.out 2>&1
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
time.sleep(0.05)
s.sendall(b"from-A\n")
time.sleep(0.4)
s.close()
PY
wait $B
BRC=$?
cat /tmp/poll54-b.out
if [ "$BRC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/poll54-b.out && grep -q "from-A" /tmp/poll54-b.out; then
  ok "客户端 B 收到广播 from-A"
else
  bad "客户端 B 未收到 from-A rc=$BRC"
fi

python3 - "$PORT" <<'PY' > /tmp/poll54-send2.out 2>&1
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
time.sleep(0.05)
s.sendall(b"from-B\n")
time.sleep(0.4)
s.close()
PY
wait $A
ARC=$?
cat /tmp/poll54-a.out
if [ "$ARC" -eq 0 ] && grep -q "GOT_EXPECT ok" /tmp/poll54-a.out && grep -q "from-B" /tmp/poll54-a.out; then
  ok "客户端 A 收到广播 from-B"
else
  bad "客户端 A 未收到 from-B rc=$ARC"
fi

# --- 2) HUP 时仍能读出缓冲剩余数据（acceptance 核心）---
# 接收端先挂着，发送端 send-then-close 制造 POLLIN|POLLHUP
python3 client.py --port "$PORT" --expect "last-event-payload" --timeout 8 > /tmp/poll54-hup-recv.out 2>&1 &
HR=$!
sleep 0.3
python3 client.py --port "$PORT" --send-then-close "last-event-payload" --timeout 3 > /tmp/poll54-hup-send.out 2>&1
wait $HR
HRC=$?
cat /tmp/poll54-hup-recv.out
cat /tmp/poll54-hup-send.out
# 服务日志：应先有 RECV last-event，再有 HUP drained>0
echo "---- HUP related log ----"
grep -E "RECV fd=.*last-event|HUP fd=|CLOSE fd=" /tmp/poll54-srv.log | tail -20

if [ "$HRC" -eq 0 ] && grep -q "last-event-payload" /tmp/poll54-hup-recv.out; then
  ok "HUP 场景：其他客户端仍收到残留数据广播"
else
  bad "HUP 场景广播失败 rc=$HRC"
fi

# 断言服务端在 HUP 前读到了数据（drained>0 或 RECV 含 last-event）
python3 - <<'PY'
import re
log = open("/tmp/poll54-srv.log").read()
drains = [int(x) for x in re.findall(r"HUP fd=\d+ drained=(\d+)", log)]
print(f"all_drains={drains[-8:]}")
has_recv = "last-event-payload" in log
has_hup_drain = any(d > 0 for d in drains)
print("RECV_LAST_EVENT_OK" if has_recv else "RECV_LAST_EVENT_MISSING")
print("HUP_DRAINED_OK" if has_hup_drain else "HUP_DRAINED_MISSING")
ok = has_recv and has_hup_drain
print("HUP_CHECK_OK" if ok else "HUP_CHECK_FAIL")
raise SystemExit(0 if ok else 1)
PY
HUPRC=$?
if [ "$HUPRC" -eq 0 ]; then
  ok "HUP 时仍读出缓冲剩余数据（drained>0 + last-event）"
else
  bad "HUP 残留数据验收失败"
fi

# --- 3) 正确处理 POLLNVAL ---
# 通过控制命令注入：注册 fd 后关闭但不 unregister
LINES_BEFORE=$(wc -l < /tmp/poll54-srv.log)
python3 - "$PORT" <<'PY' > /tmp/poll54-nval.out 2>&1
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(5); s.connect(("127.0.0.1",p))
time.sleep(0.05)
s.sendall(b"__INJECT_NVAL__\n")
time.sleep(0.8)  # 等服务下一轮 poll 看到 POLLNVAL
s.sendall(b"after-nval-still-ok\n")
time.sleep(0.3)
s.close()
print("NVAL_INJECT_DONE")
PY
sleep 0.3
echo "---- POLLNVAL related log ----"
grep -E "INJECT_NVAL|POLLNVAL|after-nval" /tmp/poll54-srv.log | tail -20
cat /tmp/poll54-nval.out

if grep -q "INJECT_NVAL registered_then_closed" /tmp/poll54-srv.log; then
  ok "已注入 stale fd（注册后关闭）"
else
  bad "未见 INJECT_NVAL 日志"
fi

if grep -q "POLLNVAL fd=" /tmp/poll54-srv.log; then
  ok "服务正确报告 POLLNVAL 并清理"
else
  bad "未见 POLLNVAL 处理日志"
fi

# 注入后服务仍存活，且能广播
if kill -0 $SRV 2>/dev/null; then
  ok "POLLNVAL 处理后服务进程仍存活（未崩溃）"
else
  bad "POLLNVAL 后服务已退出"
  cat /tmp/poll54-srv.log
fi

python3 client.py --port "$PORT" --expect "after-nval-ping" --timeout 6 > /tmp/poll54-nval-recv.out 2>&1 &
NR=$!
sleep 0.25
python3 - "$PORT" <<'PY'
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
s.sendall(b"after-nval-ping\n")
time.sleep(0.4)
s.close()
PY
wait $NR
NRC=$?
cat /tmp/poll54-nval-recv.out
if [ "$NRC" -eq 0 ] && grep -q "after-nval-ping" /tmp/poll54-nval-recv.out; then
  ok "POLLNVAL 清理后仍可接受新连接并广播"
else
  bad "POLLNVAL 后广播失败 rc=$NRC"
fi

# --- 4) 关闭连接后集合更新、服务继续 ---
python3 client.py --port "$PORT" --hold 20 --timeout 25 > /tmp/poll54-hold1.out 2>&1 &
H1=$!
python3 client.py --port "$PORT" --hold 20 --timeout 25 > /tmp/poll54-hold2.out 2>&1 &
H2=$!
sleep 0.4
kill $H1 2>/dev/null || true
wait $H1 2>/dev/null || true
sleep 0.5
if grep -q "CLOSE fd=" /tmp/poll54-srv.log; then
  ok "关闭连接后服务从集合摘掉（CLOSE 日志）"
else
  bad "未见 CLOSE 日志"
fi
python3 client.py --port "$PORT" --expect "still-alive" --timeout 6 > /tmp/poll54-remain.out 2>&1 &
REM=$!
sleep 0.25
python3 - "$PORT" <<'PY'
import socket, sys, time
p=int(sys.argv[1])
s=socket.socket(); s.settimeout(3); s.connect(("127.0.0.1",p))
s.sendall(b"still-alive\n")
time.sleep(0.4)
s.close()
PY
wait $REM
RRC=$?
if [ "$RRC" -eq 0 ] && grep -q "still-alive" /tmp/poll54-remain.out; then
  ok "关闭一个客户端后剩余客户端仍可收广播"
else
  bad "关闭后广播失败 rc=$RRC"
  cat /tmp/poll54-remain.out
fi
kill $H2 2>/dev/null || true
wait $H2 2>/dev/null || true

# --- 5) 空闲心跳 ---
sleep 2.5
if grep -q "IDLE heartbeat" /tmp/poll54-srv.log; then
  ok "超时路径打印 IDLE heartbeat（演示 poll timeout 毫秒）"
else
  sleep 2.5
  if grep -q "IDLE heartbeat" /tmp/poll54-srv.log; then
    ok "超时路径打印 IDLE heartbeat（演示 poll timeout 毫秒）"
  else
    bad "未见 IDLE heartbeat"
  fi
fi

# --- 6) 端口占用 ---
OUT=$(python3 server.py "$PORT" 2>&1) || RC=$?
RC=${RC:-0}
echo "second_bind rc=$RC out=$OUT"
echo "$OUT" | grep -qiE "EADDRINUSE|already in use|port .* in use" && ok "端口占用给出明确错误" || bad "端口占用错误不明确: $OUT"
[ "${RC}" -eq 2 ] && ok "端口占用退出码为 2" || bad "端口占用退出码异常 rc=$RC"

# --- 7) 服务仍存活 ---
if kill -0 $SRV 2>/dev/null; then
  ok "全部用例后服务进程仍存活"
else
  bad "服务进程已退出"
  cat /tmp/poll54-srv.log
fi

echo "---- server log (tail) ----"
tail -60 /tmp/poll54-srv.log || true

if [ "$fail" -eq 0 ]; then
  echo "ALL_CHECKS_PASSED"
  exit 0
else
  echo "SOME_CHECKS_FAILED"
  exit 1
fi
