#!/usr/bin/env python3
"""poll 聊天服务：select.poll 多路复用；HUP 时先读尽；正确处理 POLLNVAL（第54课 d-poll）。"""
from __future__ import annotations

import errno
import os
import select
import socket
import sys
import time

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18054
BACKLOG = 128
IDLE_TIMEOUT_MS = 2000  # poll 超时：毫秒
INJECT_NVAL_CMD = b"__INJECT_NVAL__\n"


def main() -> None:
    clients: dict[int, socket.socket] = {}
    # 已 close 但仍留在 poller 里的 fd，等待 POLLNVAL
    stale_fds: set[int] = set()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((HOST, PORT))
        except OSError as e:
            if e.errno == errno.EADDRINUSE:
                print(
                    f"ERROR: port {HOST}:{PORT} already in use (EADDRINUSE)",
                    file=sys.stderr,
                    flush=True,
                )
                sys.exit(2)
            print(f"ERROR: bind failed: {e}", file=sys.stderr, flush=True)
            sys.exit(1)
        srv.listen(BACKLOG)
        srv.setblocking(False)
        listen_fd = srv.fileno()

        poller = select.poll()
        poller.register(listen_fd, select.POLLIN)

        print(
            f"poll chat listening on {HOST}:{PORT} "
            f"listen_fd={listen_fd} nfds_tracked=1",
            flush=True,
        )

        def tracked_count() -> int:
            return 1 + len(clients) + len(stale_fds)

        def unregister_safe(fd: int) -> None:
            try:
                poller.unregister(fd)
            except KeyError:
                pass
            except OSError:
                pass

        def close_client(fd: int, reason: str, already_closed: bool = False) -> None:
            sock = clients.pop(fd, None)
            unregister_safe(fd)
            if sock is not None and not already_closed:
                try:
                    sock.close()
                except OSError:
                    pass
            stale_fds.discard(fd)
            print(
                f"CLOSE fd={fd} reason={reason} "
                f"STATE after_close clients={len(clients)} nfds_tracked={tracked_count()}",
                flush=True,
            )

        def broadcast(src_fd: int, data: bytes) -> None:
            dead: list[int] = []
            for fd, sock in list(clients.items()):
                if fd == src_fd:
                    continue
                try:
                    sock.sendall(data)
                except OSError as e:
                    print(f"WARN broadcast fail fd={fd}: {e}", flush=True)
                    dead.append(fd)
            for fd in dead:
                close_client(fd, "broadcast_fail")

        def inject_nval() -> None:
            """注册一个 fd，立刻 close，但不 unregister → 下一轮 poll 应得 POLLNVAL。"""
            # 用 socketpair 拿一个独立 fd，避免复用 listen/client 编号语义混淆
            a, b = socket.socketpair()
            fd = a.fileno()
            # 先复制出一个独立 fd 编号再关掉 pair，确保 poll 条目指向已关闭编号
            dup_fd = os.dup(fd)
            a.close()
            b.close()
            # dup_fd 仍然打开；注册后再 close(dup_fd)，条目残留
            poller.register(dup_fd, select.POLLIN)
            os.close(dup_fd)
            stale_fds.add(dup_fd)
            print(
                f"INJECT_NVAL registered_then_closed fd={dup_fd} "
                f"nfds_tracked={tracked_count()}",
                flush=True,
            )

        def handle_client(fd: int, revents: int) -> None:
            sock = clients.get(fd)
            if sock is None:
                return

            # 1) POLLNVAL：不做 I/O，不重复 close
            if revents & select.POLLNVAL:
                print(f"POLLNVAL fd={fd} skip_io cleanup", flush=True)
                close_client(fd, "POLLNVAL", already_closed=True)
                return

            drained = 0
            eof = False
            # 2) 即使只有 HUP/ERR，也尝试排空（man：HUP 不表示缓冲已空）
            if revents & (select.POLLIN | select.POLLHUP | select.POLLERR):
                while True:
                    try:
                        chunk = sock.recv(4096)
                    except BlockingIOError:
                        break
                    except OSError as e:
                        print(f"RECV_ERR fd={fd} {e}", flush=True)
                        eof = True
                        break
                    if not chunk:
                        eof = True
                        break
                    drained += len(chunk)
                    print(
                        f"RECV fd={fd} bytes={len(chunk)} data={chunk!r}",
                        flush=True,
                    )
                    # 控制命令：注入 POLLNVAL（不广播）
                    if chunk == INJECT_NVAL_CMD or chunk.startswith(b"__INJECT_NVAL__"):
                        inject_nval()
                        continue
                    broadcast(fd, chunk)

            # 对端关闭：Linux 上常与 POLLIN 同帧出现 POLLHUP；
            # 即便本轮只有 POLLIN 读到 EOF，语义仍是「HUP + 残留数据」
            saw_hup = bool(revents & select.POLLHUP) or (eof and drained > 0)
            if saw_hup:
                print(
                    f"HUP fd={fd} drained={drained} "
                    f"eof={int(eof)} revents=0x{revents:x} "
                    f"bit_hup={int(bool(revents & select.POLLHUP))}",
                    flush=True,
                )
            if revents & select.POLLERR:
                print(f"ERR fd={fd} revents=0x{revents:x}", flush=True)

            # 3) 数据读尽后再关
            if eof or (revents & (select.POLLHUP | select.POLLERR)):
                close_client(fd, "hup_err_eof")

        def handle_stale(fd: int, revents: int) -> None:
            if revents & select.POLLNVAL:
                print(f"POLLNVAL fd={fd} skip_io cleanup", flush=True)
                unregister_safe(fd)
                stale_fds.discard(fd)
                print(
                    f"CLOSE fd={fd} reason=POLLNVAL "
                    f"STATE after_close clients={len(clients)} "
                    f"nfds_tracked={tracked_count()}",
                    flush=True,
                )
                return
            # 其他事件不应出现在已关闭 fd；防御性清理
            print(
                f"WARN stale fd={fd} unexpected revents=0x{revents:x} cleanup",
                flush=True,
            )
            unregister_safe(fd)
            stale_fds.discard(fd)

        while True:
            try:
                ready = poller.poll(IDLE_TIMEOUT_MS)
            except InterruptedError:
                continue

            if not ready:
                print(
                    f"IDLE heartbeat clients={len(clients)} "
                    f"nfds_tracked={tracked_count()}",
                    flush=True,
                )
                continue

            for fd, revents in ready:
                if fd == listen_fd:
                    if revents & (select.POLLERR | select.POLLHUP | select.POLLNVAL):
                        print(
                            f"FATAL listen fd bad revents=0x{revents:x}",
                            file=sys.stderr,
                            flush=True,
                        )
                        sys.exit(1)
                    while True:
                        try:
                            conn, addr = srv.accept()
                        except BlockingIOError:
                            break
                        except OSError as e:
                            print(f"ACCEPT_ERR {e}", flush=True)
                            break
                        conn.setblocking(False)
                        cfd = conn.fileno()
                        clients[cfd] = conn
                        poller.register(cfd, select.POLLIN)
                        print(
                            f"ACCEPT fd={cfd} from={addr} "
                            f"STATE after_accept clients={len(clients)} "
                            f"nfds_tracked={tracked_count()}",
                            flush=True,
                        )
                    continue

                if fd in stale_fds:
                    handle_stale(fd, revents)
                    continue

                if fd in clients:
                    handle_client(fd, revents)
                    continue

                print(f"WARN unknown fd={fd} revents=0x{revents:x}", flush=True)
                unregister_safe(fd)

    finally:
        for sock in list(clients.values()):
            try:
                sock.close()
            except OSError:
                pass
        try:
            srv.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
