#!/usr/bin/env python3
"""poll 聊天客户端（第54课）：发/收、半关闭测 HUP+残留数据。"""
from __future__ import annotations

import argparse
import select
import socket
import sys
import time


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=18054)
    ap.add_argument("--send", default="", help="发送一条消息")
    ap.add_argument("--expect", default="", help="期望在超时内收到包含此子串的广播")
    ap.add_argument("--timeout", type=float, default=5.0)
    ap.add_argument("--hold", type=float, default=0.0, help="连接保持秒数")
    ap.add_argument(
        "--send-then-close",
        default="",
        help="发送该消息后立刻 close（制造 POLLIN|POLLHUP）",
    )
    ap.add_argument(
        "--send-then-shutdown",
        default="",
        help="发送后 shutdown(SHUT_WR)，半关闭测 HUP",
    )
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(args.timeout)
    try:
        s.connect((args.host, args.port))
        fd = s.fileno()
        if not args.quiet:
            print(f"CONNECTED fd={fd} to {args.host}:{args.port}", flush=True)

        def send_line(text: str) -> None:
            payload = text.encode()
            if not payload.endswith(b"\n"):
                payload += b"\n"
            s.sendall(payload)
            if not args.quiet:
                print(f"SENT bytes={len(payload)} text={payload!r}", flush=True)

        if args.send_then_close:
            send_line(args.send_then_close)
            s.close()
            print(f"SEND_THEN_CLOSE done fd={fd}", flush=True)
            sys.exit(0)

        if args.send_then_shutdown:
            send_line(args.send_then_shutdown)
            s.shutdown(socket.SHUT_WR)
            print(f"SEND_THEN_SHUTDOWN done fd={fd}", flush=True)
            # 半关闭后仍可读一小会儿（服务端可能无回环）
            deadline = time.monotonic() + min(1.0, args.timeout)
            while time.monotonic() < deadline:
                r, _, _ = select.select([s], [], [], 0.2)
                if not r:
                    continue
                chunk = s.recv(4096)
                if not chunk:
                    break
            sys.exit(0)

        if args.send:
            send_line(args.send)

        deadline = time.monotonic() + args.timeout
        got = b""
        hold_until = time.monotonic() + args.hold

        while time.monotonic() < deadline:
            remaining_hold = hold_until - time.monotonic()
            if args.hold > 0 and remaining_hold > 0 and not args.expect:
                select.select([s], [], [], min(0.2, remaining_hold))
                r, _, _ = select.select([s], [], [], 0)
                if r:
                    chunk = s.recv(4096)
                    if not chunk:
                        print("PEER_CLOSED during hold", flush=True)
                        sys.exit(1)
                    got += chunk
                if time.monotonic() >= hold_until and not args.expect:
                    print(f"HOLD_DONE fd={fd}", flush=True)
                    sys.exit(0)
                continue

            wait = min(0.5, max(0.0, deadline - time.monotonic()))
            r, _, _ = select.select([s], [], [], wait)
            if not r:
                if args.expect:
                    continue
                if args.hold > 0 and time.monotonic() >= hold_until:
                    print(f"HOLD_DONE fd={fd}", flush=True)
                    sys.exit(0)
                break
            chunk = s.recv(4096)
            if not chunk:
                if not args.quiet:
                    print("PEER_CLOSED", flush=True)
                break
            got += chunk
            if args.expect and args.expect.encode() in got:
                print(f"GOT_EXPECT ok fd={fd} text={got!r}", flush=True)
                sys.exit(0)

        if args.expect:
            print(
                f"RESULT fail missing expect={args.expect!r} got={got!r}",
                file=sys.stderr,
            )
            sys.exit(1)

        if args.send and not args.hold:
            print(f"SEND_DONE fd={fd} got_extra={got!r}", flush=True)
            sys.exit(0)

        print(f"RESULT ok fd={fd} got={got!r}", flush=True)
    except Exception as e:
        print(f"RESULT fail {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        try:
            s.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()
