#!/usr/bin/env python3
"""Acceptance checks for practice108 (Bloom filter and read amplification)."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    bpk = data["bits_per_key"]
    rows = {r["requested_bits_per_key"]: r for r in bpk["rows"]}
    _assert(bpk["n_existing"] == 4000, "existing key count")
    _assert(bpk["n_missing"] == 20000, "missing key count")
    no = rows[0]
    _assert(no["data_block_reads_missing"] == 20000, "no-filter must read a data block for every missing query")
    _assert(no["measured_fpr"] == 1.0, "no-filter FPR is 1")
    for bits in (3, 5, 10, 16):
        row = rows[bits]
        _assert(row["correctness_ok"], f"bpk={bits} correctness")
        _assert(row["existing_false_negatives"] == 0, f"bpk={bits} false negatives")
        _assert(row["missing_hits"] == 0, f"bpk={bits} must not invent values")
        _assert(row["data_block_reads_missing"] == row["bloom_fp"], f"bpk={bits} IO equals false positives")
        _assert(row["data_block_reads_missing"] < no["data_block_reads_missing"], f"bpk={bits} must cut IO")
        _assert(row["filter_bytes"] > 0, f"bpk={bits} uses memory")
    _assert(rows[16]["measured_fpr"] < rows[10]["measured_fpr"] < rows[5]["measured_fpr"] < rows[3]["measured_fpr"], "FPR falls as bits-per-key rises")
    _assert(rows[16]["filter_bytes"] > rows[10]["filter_bytes"] > rows[5]["filter_bytes"], "memory rises with bits-per-key")
    _assert(rows[10]["io_saved_vs_no_filter"] >= 0.9 * no["data_block_reads_missing"], "10 bits/key should save most missing-key IO")

    cor = data["correctness"]
    _assert(cor["no_false_negative"], "existing keys never rejected")
    _assert(cor["false_positive_does_not_invent_value"], "FP does not invent a value")
    _assert(cor["fp_then_data_read"], "each FP is followed by a data-block read")
    _assert(cor["existing_hits"] == 4000, "all existing titles found")

    unsafe = data["unsafe_delete"]
    _assert(unsafe["unsafe_false_negatives"] >= 1, "clearing bits must be able to reject a live key")
    _assert(unsafe["rebuild_false_negatives"] == 0, "rebuilt filter has no false negatives")
    _assert(unsafe["remaining_all_present"], "remaining keys survive a rebuild")

    layered = data["layered_read_amp"]
    _assert(layered["n_files"] == 8, "8 L0 files")
    no_m = layered["no_filter"]["missing"]
    b10 = layered["bpk10"]["missing"]
    b16 = layered["bpk16"]["missing"]
    _assert(no_m["data_block_reads"] == 8 * layered["missing_queries"], "no filter reads every overlapping SST")
    _assert(b10["data_block_reads"] < no_m["data_block_reads"] / 10, "bpk10 cuts layered IO by more than 10x")
    _assert(b16["data_block_reads"] <= b10["data_block_reads"], "bpk16 IO not worse than bpk10")
    _assert(b10["false_hit"] == 0 and b16["false_hit"] == 0 and no_m["false_hit"] == 0, "missing keys stay missing")
    for label in ("no_filter", "bpk10", "bpk16"):
        ex = layered[label]["existing"]
        _assert(ex["false_negatives"] == 0, f"{label} existing FN")
        _assert(ex["hits"] == layered["total_existing"], f"{label} existing hits")

    layouts = data["filter_layouts"]["layouts"]
    _assert(layouts["none"]["data_block_reads_missing"] == 20000, "none layout reads every data block")
    for mode in ("full", "partitioned", "block"):
        lay = layouts[mode]
        _assert(lay["existing_false_negatives"] == 0, f"{mode} FN")
        _assert(lay["missing_hits"] == 0, f"{mode} no invented values")
        _assert(lay["data_block_reads_missing"] < 20000, f"{mode} cuts data IO")
    # Full filter loads the whole bit array; partitioned loads one slice; per-block is smaller still.
    _assert(layouts["full"]["filter_bytes_loaded_per_query"] > layouts["partitioned"]["filter_bytes_loaded_per_query"], "partitioned loads fewer filter bytes per query")
    _assert(layouts["partitioned"]["filter_bytes_loaded_per_query"] > layouts["block"]["filter_bytes_loaded_per_query"], "block filter loads fewer bytes than a partition")
    _assert(layouts["block"]["index_reads_missing"] >= layouts["full"]["index_reads_missing"], "block-based path consults the index before the filter")
    _assert(layouts["partitioned"]["n_partitions"] == 8, "8 partitions")
    _assert(layouts["partitioned"]["partition_index_reads_missing"] == 20000, "partitioned consults the top-level partition index")

    opt = data["optimize_filters_for_hits"]
    all_lv = opt["filters_on_all_levels"]
    skip = opt["skip_bottom_filter"]
    _assert(all_lv["l2_has_filter"] is True, "default keeps bottom filter")
    _assert(skip["l2_has_filter"] is False, "optimize_filters_for_hits skips bottom filter")
    _assert(skip["filter_memory_bytes"] < all_lv["filter_memory_bytes"], "skipping bottom filter saves memory")
    _assert(all_lv["missing"]["data_block_reads"] < skip["missing"]["data_block_reads"], "bottom filter is what cuts most missing-key IO")
    _assert(all_lv["bottom_hits"]["false_negatives"] == 0, "hits still found with bottom filter")
    _assert(skip["bottom_hits"]["false_negatives"] == 0, "hits still found without bottom filter")
    # On a pure hit workload, the bottom bloom cannot skip the data block.
    _assert(all_lv["bottom_hits"]["data_block_reads"] >= opt["bottom_hit_queries"], "bottom-level hits still read data")

    tomb = data["tombstone_in_filter"]
    _assert(tomb["correct_bloom_includes_tombstone"]["hides_old_value"], "tombstone in bloom hides the old title")
    _assert(tomb["buggy_bloom_omits_tombstone"]["resurrects_old_value"], "omitting the tombstone resurrects Weekly digest")
    _assert(tomb["rebuild_on_bottom_compaction"]["correct_miss"], "rebuilt bottom SST does not return the deleted title")
    _assert(tomb["rebuild_on_bottom_compaction"]["key_in_sst"] is False, "tombstone dropped at bottom-most compact")

    r10 = rows[10]
    r16 = rows[16]
    r5 = rows[5]
    r3 = rows[3]
    lay_full = layouts["full"]
    lay_part = layouts["partitioned"]
    lay_block = layouts["block"]
    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"bpk3_fpr={r3['measured_fpr']:.6f} "
        f"bpk5_fpr={r5['measured_fpr']:.6f} "
        f"bpk10_fpr={r10['measured_fpr']:.6f} "
        f"bpk16_fpr={r16['measured_fpr']:.6f} "
        f"bpk10_fp={r10['bloom_fp']} "
        f"bpk10_io={r10['data_block_reads_missing']} "
        f"bpk10_mem={r10['filter_bytes']} "
        f"no_io={no['data_block_reads_missing']} "
        f"fn=0 "
        f"unsafe_fn={unsafe['unsafe_false_negatives']} "
        f"rebuild_fn={unsafe['rebuild_false_negatives']} "
        f"layer_no_io={no_m['data_block_reads']} "
        f"layer_b10_io={b10['data_block_reads']} "
        f"layer_b16_io={b16['data_block_reads']} "
        f"full_load={lay_full['filter_bytes_loaded_per_query']:.2f} "
        f"part_load={lay_part['filter_bytes_loaded_per_query']:.2f} "
        f"block_load={lay_block['filter_bytes_loaded_per_query']:.2f} "
        f"opt_miss_io={all_lv['missing']['data_block_reads']} "
        f"skip_miss_io={skip['missing']['data_block_reads']} "
        f"opt_mem={all_lv['filter_memory_bytes']} "
        f"skip_mem={skip['filter_memory_bytes']} "
        f"tomb_ok={int(tomb['correct_bloom_includes_tombstone']['hides_old_value'])} "
        f"tomb_bug={int(tomb['buggy_bloom_omits_tombstone']['resurrects_old_value'])}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
