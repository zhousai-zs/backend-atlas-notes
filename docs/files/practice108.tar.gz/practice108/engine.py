#!/usr/bin/env python3
"""Teaching Bloom filter and LSM read path for practice108.

This is a Python 3 standard-library teaching engine. It is not RocksDB,
not Redis, and not a network service. Teaching SSTs are in-memory sorted
record lists split into fixed-count blocks. There is no WAL, MANIFEST,
column family, snapshot, real block cache, compression, or Ribbon filter.
Bloom filters here are a standard (non cache-local) bit array; they are
not RocksDB FastLocalBloom (format_version=5) and not a drop-in for
production numbers.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from typing import Callable, Iterable, Optional


KIND_PUT = "put"
KIND_DEL = "del"

MISS_RANGE = "miss_range"
MISS_BLOOM = "miss_bloom"
MISS_DATA = "miss_data"
HIT = "hit"
TOMBSTONE = "tombstone"


def stable_hash64(key: str, seed: int = 0) -> tuple[int, int]:
    """Two 64-bit hashes from blake2b; independent of PYTHONHASHSEED."""
    digest = hashlib.blake2b(f"{seed}:{key}".encode("utf-8"), digest_size=16).digest()
    h1 = int.from_bytes(digest[:8], "little")
    h2 = int.from_bytes(digest[8:], "little")
    if h2 % 2 == 0:
        h2 += 1
    return h1, h2


def optimal_num_probes(bits_per_key: float) -> int:
    """k ≈ (m/n) * ln(2), same idea as LegacyNoLocalityBloomImpl (×0.69)."""
    if bits_per_key <= 0:
        return 0
    return max(1, int(round(bits_per_key * math.log(2))))


def standard_fp_rate(bits_per_key: float, num_probes: int) -> float:
    """(1 - e^(-k / (m/n)))^k. Returns 1.0 when there is no filter."""
    if bits_per_key <= 0 or num_probes <= 0:
        return 1.0
    return (1.0 - math.exp(-num_probes / bits_per_key)) ** num_probes


class BloomFilter:
    """Standard bit-array Bloom filter. Cannot safely delete by clearing bits."""

    def __init__(self, n_keys: int, bits_per_key: float) -> None:
        if n_keys < 0:
            raise ValueError("n_keys must be >= 0")
        self.requested_bits_per_key = float(bits_per_key)
        self.n_keys_declared = int(n_keys)
        self.num_probes = optimal_num_probes(bits_per_key)
        if bits_per_key <= 0 or n_keys == 0 or self.num_probes == 0:
            self.n_bits = 0
            self.n_bytes = 0
            self.bits = bytearray()
        else:
            n_bits = max(self.num_probes, int(math.ceil(bits_per_key * n_keys)))
            self.n_bytes = max(1, (n_bits + 7) // 8)
            self.n_bits = self.n_bytes * 8
            self.bits = bytearray(self.n_bytes)
        self.added = 0
        self.probe_ops = 0

    @property
    def actual_bits_per_key(self) -> float:
        if self.added <= 0:
            return 0.0
        return self.n_bits / self.added

    def memory_bytes(self) -> int:
        return self.n_bytes

    def theoretical_fpr(self) -> float:
        if self.added <= 0 or self.n_bits <= 0:
            return 1.0
        return standard_fp_rate(self.n_bits / self.added, self.num_probes)

    def _positions(self, key: str) -> list[int]:
        if self.n_bits <= 0 or self.num_probes <= 0:
            return []
        h1, h2 = stable_hash64(key)
        self.probe_ops += self.num_probes
        return [((h1 + i * h2) % self.n_bits) for i in range(self.num_probes)]

    def add(self, key: str) -> None:
        for pos in self._positions(key):
            self.bits[pos // 8] |= 1 << (pos % 8)
        self.added += 1

    def may_contain(self, key: str) -> bool:
        if self.n_bits <= 0 or self.num_probes <= 0:
            return True
        for pos in self._positions(key):
            if not (self.bits[pos // 8] & (1 << (pos % 8))):
                return False
        return True

    def naive_clear_bits(self, key: str) -> None:
        """Unsafe 'delete': clear this key's probe bits. May create false negatives."""
        for pos in self._positions(key):
            self.bits[pos // 8] &= ~(1 << (pos % 8))


@dataclass
class Record:
    key: str
    kind: str
    value: str


@dataclass
class ReadStats:
    range_checks: int = 0
    range_skips: int = 0
    bloom_checks: int = 0
    bloom_useful: int = 0
    bloom_fp: int = 0
    bloom_tp: int = 0
    index_reads: int = 0
    data_block_reads: int = 0
    filter_bytes_loaded: int = 0
    partition_index_reads: int = 0
    sst_touched: int = 0
    memtable_hits: int = 0

    def as_dict(self) -> dict:
        return self.__dict__.copy()


class SSTFile:
    """In-memory teaching SST with optional Bloom (full / partitioned / per-block)."""

    def __init__(
        self,
        file_id: int,
        level: int,
        records: list[Record],
        *,
        bits_per_key: float = 10.0,
        filter_mode: str = "full",
        keys_per_block: int = 16,
        partitions: int = 8,
        skip_filter: bool = False,
    ) -> None:
        if not records:
            raise ValueError("SST must contain at least one record")
        recs = sorted(records, key=lambda r: r.key)
        # last write wins if duplicates slipped in
        merged: dict[str, Record] = {}
        for rec in recs:
            merged[rec.key] = rec
        self.records = [merged[k] for k in sorted(merged)]
        self.file_id = file_id
        self.level = level
        self.smallest = self.records[0].key
        self.largest = self.records[-1].key
        self.keys_per_block = keys_per_block
        self.filter_mode = "none" if skip_filter or bits_per_key <= 0 else filter_mode
        self.bits_per_key = 0.0 if self.filter_mode == "none" else float(bits_per_key)
        self.blocks: list[list[Record]] = []
        for i in range(0, len(self.records), keys_per_block):
            self.blocks.append(self.records[i : i + keys_per_block])
        self.index: list[tuple[str, int]] = [
            (block[-1].key, idx) for idx, block in enumerate(self.blocks)
        ]
        self.bloom: Optional[BloomFilter] = None
        self.partitions: list[dict] = []
        self.block_blooms: list[BloomFilter] = []
        keys = [r.key for r in self.records]
        if self.filter_mode == "full":
            self.bloom = BloomFilter(len(keys), self.bits_per_key)
            for key in keys:
                self.bloom.add(key)
        elif self.filter_mode == "partitioned":
            n_part = max(1, min(int(partitions), len(self.blocks)))
            cuts = []
            for p in range(n_part):
                start = int(round(p * len(self.blocks) / n_part))
                end = int(round((p + 1) * len(self.blocks) / n_part))
                if end > start:
                    cuts.append((start, end))
            for start, end in cuts:
                part_records = [rec for block in self.blocks[start:end] for rec in block]
                bf = BloomFilter(len(part_records), self.bits_per_key)
                for rec in part_records:
                    bf.add(rec.key)
                self.partitions.append(
                    {
                        "smallest": part_records[0].key,
                        "largest": part_records[-1].key,
                        "block_start": start,
                        "block_end": end,
                        "bloom": bf,
                    }
                )
        elif self.filter_mode == "block":
            for block in self.blocks:
                bf = BloomFilter(len(block), self.bits_per_key)
                for rec in block:
                    bf.add(rec.key)
                self.block_blooms.append(bf)
        elif self.filter_mode != "none":
            raise ValueError(f"unknown filter_mode: {filter_mode}")

    def filter_memory_bytes(self) -> int:
        if self.bloom is not None:
            return self.bloom.memory_bytes()
        if self.partitions:
            return sum(p["bloom"].memory_bytes() for p in self.partitions)
        if self.block_blooms:
            return sum(b.memory_bytes() for b in self.block_blooms)
        return 0

    def _block_index(self, key: str) -> int:
        for last_key, idx in self.index:
            if key <= last_key:
                return idx
        return len(self.blocks) - 1

    def _partition_for(self, key: str) -> Optional[dict]:
        for part in self.partitions:
            if part["smallest"] <= key <= part["largest"]:
                return part
        return None

    def get(self, key: str, stats: ReadStats) -> tuple[str, Optional[str]]:
        stats.sst_touched += 1
        stats.range_checks += 1
        if key < self.smallest or key > self.largest:
            stats.range_skips += 1
            return MISS_RANGE, None

        used_bloom = False
        if self.filter_mode == "full" and self.bloom is not None:
            used_bloom = True
            stats.bloom_checks += 1
            stats.filter_bytes_loaded += self.bloom.memory_bytes()
            if not self.bloom.may_contain(key):
                stats.bloom_useful += 1
                return MISS_BLOOM, None
        elif self.filter_mode == "partitioned":
            stats.partition_index_reads += 1
            part = self._partition_for(key)
            if part is None:
                stats.range_skips += 1
                return MISS_RANGE, None
            used_bloom = True
            stats.bloom_checks += 1
            stats.filter_bytes_loaded += part["bloom"].memory_bytes()
            if not part["bloom"].may_contain(key):
                stats.bloom_useful += 1
                return MISS_BLOOM, None
        elif self.filter_mode == "block":
            stats.index_reads += 1
            bidx = self._block_index(key)
            used_bloom = True
            stats.bloom_checks += 1
            stats.filter_bytes_loaded += self.block_blooms[bidx].memory_bytes()
            if not self.block_blooms[bidx].may_contain(key):
                stats.bloom_useful += 1
                return MISS_BLOOM, None

        if self.filter_mode != "block":
            stats.index_reads += 1
        bidx = self._block_index(key)
        stats.data_block_reads += 1
        block = self.blocks[bidx]
        lo, hi = 0, len(block) - 1
        found: Optional[Record] = None
        while lo <= hi:
            mid = (lo + hi) // 2
            if block[mid].key == key:
                found = block[mid]
                break
            if block[mid].key < key:
                lo = mid + 1
            else:
                hi = mid - 1
        if found is None:
            if used_bloom:
                stats.bloom_fp += 1
            return MISS_DATA, None
        if used_bloom:
            stats.bloom_tp += 1
        if found.kind == KIND_DEL:
            return TOMBSTONE, None
        return HIT, found.value


class BloomLSM:
    """A tiny LSM used only to show multi-file Get and filter placement."""

    def __init__(
        self,
        *,
        bits_per_key: float = 10.0,
        filter_mode: str = "full",
        keys_per_block: int = 16,
        partitions: int = 8,
        optimize_filters_for_hits: bool = False,
        bottom_level: int = 2,
    ) -> None:
        self.bits_per_key = bits_per_key
        self.filter_mode = filter_mode
        self.keys_per_block = keys_per_block
        self.partitions = partitions
        self.optimize_filters_for_hits = optimize_filters_for_hits
        self.bottom_level = bottom_level
        self.memtable: dict[str, Record] = {}
        self.levels: list[list[SSTFile]] = [[] for _ in range(bottom_level + 1)]
        self._next_file_id = 1
        self.stats = ReadStats()

    def reset_stats(self) -> None:
        self.stats = ReadStats()

    def put(self, key: str, value: str) -> None:
        self.memtable[key] = Record(key, KIND_PUT, value)

    def delete(self, key: str) -> None:
        self.memtable[key] = Record(key, KIND_DEL, "")

    def _new_sst(self, records: list[Record], level: int, skip_filter: bool = False) -> SSTFile:
        sst = SSTFile(
            self._next_file_id,
            level,
            records,
            bits_per_key=self.bits_per_key,
            filter_mode=self.filter_mode,
            keys_per_block=self.keys_per_block,
            partitions=self.partitions,
            skip_filter=skip_filter,
        )
        self._next_file_id += 1
        return sst

    def flush_to_level(self, level: int) -> Optional[SSTFile]:
        if not self.memtable:
            return None
        records = list(self.memtable.values())
        self.memtable.clear()
        skip = self.optimize_filters_for_hits and level == self.bottom_level
        sst = self._new_sst(records, level, skip_filter=skip)
        self.levels[level].append(sst)
        return sst

    def add_sst(self, records: list[Record], level: int, skip_filter: Optional[bool] = None) -> SSTFile:
        if skip_filter is None:
            skip_filter = self.optimize_filters_for_hits and level == self.bottom_level
        sst = self._new_sst(records, level, skip_filter=skip_filter)
        self.levels[level].append(sst)
        return sst

    def compact_level(self, src_level: int, dst_level: int) -> SSTFile:
        """Merge SSTs on src_level (plus overlapping dst) and rebuild the filter."""
        src = list(self.levels[src_level])
        dst_overlap = list(self.levels[dst_level])
        merged: dict[str, Record] = {}
        for sst in dst_overlap + src:
            for rec in sst.records:
                merged[rec.key] = rec
        # drop tombstones at the bottom-most teaching level
        if dst_level >= self.bottom_level:
            merged = {k: r for k, r in merged.items() if r.kind != KIND_DEL}
        self.levels[src_level] = []
        self.levels[dst_level] = []
        records = [merged[k] for k in sorted(merged)]
        if not records:
            # empty destination; return a placeholder empty is not allowed, so
            # caller should not compact an empty set. Keep an empty level.
            raise RuntimeError("compaction produced no records")
        sst = self._new_sst(
            records,
            dst_level,
            skip_filter=self.optimize_filters_for_hits and dst_level == self.bottom_level,
        )
        self.levels[dst_level].append(sst)
        return sst

    def get(self, key: str) -> tuple[str, Optional[str]]:
        if key in self.memtable:
            self.stats.memtable_hits += 1
            rec = self.memtable[key]
            if rec.kind == KIND_DEL:
                return TOMBSTONE, None
            return HIT, rec.value
        for level, files in enumerate(self.levels):
            # newer files first within a level
            for sst in reversed(files):
                outcome, value = sst.get(key, self.stats)
                if outcome == HIT:
                    return HIT, value
                if outcome == TOMBSTONE:
                    return TOMBSTONE, None
        return MISS_DATA, None

    def filter_memory_bytes(self) -> int:
        return sum(sst.filter_memory_bytes() for level in self.levels for sst in level)
