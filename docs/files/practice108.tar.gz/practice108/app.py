#!/usr/bin/env python3
"""Runnable experiments for practice108 (Bloom filter and read amplification)."""
from __future__ import annotations

import time
from typing import Any, Optional

from engine import (
    HIT,
    MISS_BLOOM,
    TOMBSTONE,
    BloomFilter,
    BloomLSM,
    Record,
    ReadStats,
    SSTFile,
    KIND_DEL,
    KIND_PUT,
    optimal_num_probes,
    standard_fp_rate,
)

# Teaching scenario (教学假设): WeChat Official Account article titles.
TITLES = (
    "Weekly digest",
    "Product update",
    "Community notes",
    "Editor picks",
    "Weekly digest (revised)",
)

N_EXISTING = 4000
N_MISSING = 20000
KEYS_PER_BLOCK = 16
PARTITIONS = 8
BPK_LIST = (0, 3, 5, 10, 16)


def existing_key(i: int) -> str:
    return f"article:{i:04d}:title"


def existing_value(i: int) -> str:
    return TITLES[i % len(TITLES)]


def missing_key(i: int, span: int = N_EXISTING) -> str:
    # Stay strictly inside (smallest, largest) so a range check cannot
    # skip the SST. Never suffix the last existing id: "title~" sorts
    # after "title" and would fall past the largest key.
    base_span = span - 1
    base = i % base_span
    copy = i // base_span
    return f"article:{base:04d}:title~{copy}"


def existing_records(n: int = N_EXISTING) -> list[Record]:
    return [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(n)]


def _probe_sst(sst: SSTFile, keys: list[str]) -> tuple[ReadStats, int, int, list[str]]:
    stats = ReadStats()
    hits = 0
    not_found = 0
    wrong: list[str] = []
    for key in keys:
        outcome, value = sst.get(key, stats)
        if outcome == HIT:
            hits += 1
        else:
            not_found += 1
            if outcome not in (MISS_BLOOM, "miss_data", "miss_range", TOMBSTONE):
                wrong.append(f"{key}:{outcome}")
    return stats, hits, not_found, wrong


def _probe_lsm(db: BloomLSM, keys: list[str], expect_hit: bool) -> dict[str, Any]:
    db.reset_stats()
    if expect_hit:
        hits = 0
        false_negatives = 0
        unexpected: list[str] = []
        t0 = time.perf_counter()
        for key in keys:
            outcome, value = db.get(key)
            if outcome == HIT and value is not None:
                hits += 1
            else:
                false_negatives += 1
                if len(unexpected) < 8:
                    unexpected.append(f"{key}:{outcome}")
        elapsed = time.perf_counter() - t0
        st = db.stats
        return {
            "queries": len(keys),
            "hits": hits,
            "false_negatives": false_negatives,
            "unexpected": unexpected,
            "elapsed_s": round(elapsed, 6),
            **st.as_dict(),
            "data_reads_per_query": st.data_block_reads / len(keys) if keys else 0.0,
        }

    correct_miss = 0
    false_hit = 0
    t0 = time.perf_counter()
    for key in keys:
        outcome, value = db.get(key)
        if outcome == HIT:
            false_hit += 1
        else:
            correct_miss += 1
    elapsed = time.perf_counter() - t0
    st = db.stats
    denom = st.bloom_fp + st.bloom_useful
    if denom:
        fpr = st.bloom_fp / denom
    elif st.data_block_reads:
        fpr = 1.0
    else:
        fpr = 0.0
    return {
        "queries": len(keys),
        "correct_miss": correct_miss,
        "false_hit": false_hit,
        "elapsed_s": round(elapsed, 6),
        **st.as_dict(),
        "fpr": fpr,
        "data_reads_per_query": st.data_block_reads / len(keys) if keys else 0.0,
    }


def experiment_bits_per_key() -> dict[str, Any]:
    """Measure FPR and data-block IO for missing keys at several bits-per-key."""
    records = existing_records()
    exist_keys = [r.key for r in records]
    miss_keys = [missing_key(i) for i in range(N_MISSING)]
    rows = []
    for bpk in BPK_LIST:
        mode = "none" if bpk <= 0 else "full"
        t_build = time.perf_counter()
        sst = SSTFile(
            1,
            0,
            records,
            bits_per_key=bpk,
            filter_mode=mode,
            keys_per_block=KEYS_PER_BLOCK,
        )
        build_s = time.perf_counter() - t_build
        st_exist, hits, _, wrong = _probe_sst(sst, exist_keys)
        t_q = time.perf_counter()
        st_miss, miss_hits, not_found, _ = _probe_sst(sst, miss_keys)
        query_s = time.perf_counter() - t_q
        denom = st_miss.bloom_fp + st_miss.bloom_useful
        if bpk <= 0:
            measured_fpr = 1.0
            theoretical = 1.0
            num_probes = 0
            actual_bpk = 0.0
            mem = 0
        else:
            measured_fpr = (st_miss.bloom_fp / denom) if denom else 0.0
            assert sst.bloom is not None
            theoretical = sst.bloom.theoretical_fpr()
            num_probes = sst.bloom.num_probes
            actual_bpk = sst.bloom.actual_bits_per_key
            mem = sst.filter_memory_bytes()
        rows.append(
            {
                "requested_bits_per_key": bpk,
                "actual_bits_per_key": round(actual_bpk, 4),
                "num_probes": num_probes,
                "theoretical_fpr": theoretical,
                "measured_fpr": measured_fpr,
                "bloom_fp": st_miss.bloom_fp,
                "bloom_useful": st_miss.bloom_useful,
                "bloom_checks": st_miss.bloom_checks,
                "missing_queries": N_MISSING,
                "missing_hits": miss_hits,
                "missing_not_found": not_found,
                "data_block_reads_missing": st_miss.data_block_reads,
                "data_reads_per_missing_query": st_miss.data_block_reads / N_MISSING,
                "index_reads_missing": st_miss.index_reads,
                "filter_bytes": mem,
                "filter_bytes_loaded_missing": st_miss.filter_bytes_loaded,
                "build_s": round(build_s, 6),
                "missing_query_s": round(query_s, 6),
                "existing_queries": N_EXISTING,
                "existing_hits": hits,
                "existing_false_negatives": N_EXISTING - hits,
                "existing_bloom_tp": st_exist.bloom_tp,
                "existing_data_block_reads": st_exist.data_block_reads,
                "existing_wrong": wrong,
                "correctness_ok": miss_hits == 0 and hits == N_EXISTING and not wrong,
            }
        )
    no_io = next(r["data_block_reads_missing"] for r in rows if r["requested_bits_per_key"] == 0)
    for row in rows:
        saved = no_io - row["data_block_reads_missing"]
        row["io_saved_vs_no_filter"] = saved
        row["effectiveness_vs_no_filter"] = saved / no_io if no_io else 0.0
    return {
        "n_existing": N_EXISTING,
        "n_missing": N_MISSING,
        "keys_per_block": KEYS_PER_BLOCK,
        "rows": rows,
    }


def experiment_correctness() -> dict[str, Any]:
    """False positives still return not_found; existing keys are never rejected."""
    records = existing_records()
    sst = SSTFile(1, 0, records, bits_per_key=10, filter_mode="full", keys_per_block=KEYS_PER_BLOCK)
    exist_keys = [r.key for r in records]
    miss_keys = [missing_key(i) for i in range(N_MISSING)]
    st_exist, hits, _, wrong = _probe_sst(sst, exist_keys)
    st_miss, miss_hits, not_found, _ = _probe_sst(sst, miss_keys)
    fp_reads_ok = st_miss.bloom_fp == st_miss.data_block_reads
    return {
        "existing_hits": hits,
        "existing_false_negatives": N_EXISTING - hits,
        "existing_values_ok": hits == N_EXISTING and not wrong,
        "missing_hits": miss_hits,
        "missing_not_found": not_found,
        "bloom_fp": st_miss.bloom_fp,
        "data_block_reads_on_missing": st_miss.data_block_reads,
        "fp_then_data_read": fp_reads_ok,
        "false_positive_does_not_invent_value": miss_hits == 0,
        "no_false_negative": (N_EXISTING - hits) == 0,
    }


def experiment_unsafe_delete() -> dict[str, Any]:
    """Clearing bits is not a safe delete; rebuilding the filter is."""
    n = 200
    bpk = 8.0
    keys = [existing_key(i) for i in range(n)]
    victim = None
    unsafe_fn_keys: list[str] = []
    n_bits = 0
    num_probes = 0
    for cand in keys:
        bf = BloomFilter(n, bpk)
        for k in keys:
            bf.add(k)
        pre_fn = [k for k in keys if not bf.may_contain(k)]
        bf.naive_clear_bits(cand)
        fn = [k for k in keys if k != cand and not bf.may_contain(k)]
        if fn and not pre_fn:
            victim = cand
            unsafe_fn_keys = fn
            n_bits = bf.n_bits
            num_probes = bf.num_probes
            break
    if victim is None:
        raise RuntimeError("could not find a victim that demonstrates unsafe clear")
    remaining = [k for k in keys if k != victim]
    rebuilt = BloomFilter(len(remaining), bpk)
    t0 = time.perf_counter()
    for k in remaining:
        rebuilt.add(k)
    rebuild_s = time.perf_counter() - t0
    rebuild_fn = [k for k in remaining if not rebuilt.may_contain(k)]
    deleted_still_maybe = rebuilt.may_contain(victim)
    return {
        "n_keys": n,
        "bits_per_key": bpk,
        "num_probes": num_probes,
        "n_bits": n_bits,
        "victim": victim,
        "unsafe_false_negatives": len(unsafe_fn_keys),
        "unsafe_fn_examples": unsafe_fn_keys[:5],
        "rebuild_false_negatives": len(rebuild_fn),
        "rebuild_s": round(rebuild_s, 6),
        "deleted_key_may_contain_after_rebuild": deleted_still_maybe,
        "remaining_all_present": len(rebuild_fn) == 0,
    }


def experiment_layered_read_amp() -> dict[str, Any]:
    """Several overlapping L0 SSTs: bloom cuts data reads on missing keys."""
    n_files = 8
    per_file = 500
    miss_n = 8000

    def build(bpk: float) -> BloomLSM:
        db = BloomLSM(
            bits_per_key=bpk,
            filter_mode="full" if bpk > 0 else "none",
            keys_per_block=KEYS_PER_BLOCK,
        )
        # Interleave keys so every L0 file covers almost the same range
        # (like real L0 flushes), and a mid-range miss overlaps all 8 files.
        for f in range(n_files):
            recs = []
            for j in range(per_file):
                i = j * n_files + f
                recs.append(Record(existing_key(i), KIND_PUT, existing_value(i)))
            db.add_sst(recs, level=0, skip_filter=False)
        return db

    exist_all = [existing_key(i) for i in range(n_files * per_file)]
    # Bases 8..3991 sit inside every interleaved file range.
    miss_keys = [f"article:{8 + (i % 3984):04d}:title~ov{i}" for i in range(miss_n)]
    out: dict[str, Any] = {
        "n_files": n_files,
        "keys_per_file": per_file,
        "total_existing": len(exist_all),
        "missing_queries": miss_n,
        "note": "all 8 L0 files interleave keys over the same article:NNNN range, so a mid-range miss overlaps every file",
    }
    for label, bpk in (("no_filter", 0), ("bpk10", 10), ("bpk16", 16)):
        db = build(bpk)
        miss = _probe_lsm(db, miss_keys, expect_hit=False)
        hit = _probe_lsm(db, exist_all, expect_hit=True)
        out[label] = {
            "bits_per_key": bpk,
            "filter_memory_bytes": db.filter_memory_bytes(),
            "missing": miss,
            "existing": {
                "queries": hit["queries"],
                "hits": hit["hits"],
                "false_negatives": hit["false_negatives"],
                "data_block_reads": hit["data_block_reads"],
                "bloom_useful": hit["bloom_useful"],
                "bloom_fp": hit["bloom_fp"],
                "bloom_tp": hit["bloom_tp"],
                "elapsed_s": hit["elapsed_s"],
                "data_reads_per_query": hit["data_reads_per_query"],
            },
        }
    return out


def experiment_filter_layouts() -> dict[str, Any]:
    """Compare none / full / partitioned / per-block layouts on the same SST."""
    records = existing_records()
    miss_keys = [missing_key(i) for i in range(N_MISSING)]
    exist_keys = [r.key for r in records]
    layouts = {}
    for mode in ("none", "full", "partitioned", "block"):
        bpk = 0 if mode == "none" else 10
        sst = SSTFile(
            1,
            0,
            records,
            bits_per_key=bpk,
            filter_mode=mode,
            keys_per_block=KEYS_PER_BLOCK,
            partitions=PARTITIONS,
        )
        st_miss, miss_hits, not_found, _ = _probe_sst(sst, miss_keys)
        st_exist, hits, _, wrong = _probe_sst(sst, exist_keys)
        denom = st_miss.bloom_fp + st_miss.bloom_useful
        layouts[mode] = {
            "filter_mode": mode,
            "bits_per_key": bpk,
            "filter_memory_bytes": sst.filter_memory_bytes(),
            "n_blocks": len(sst.blocks),
            "n_partitions": len(sst.partitions),
            "n_block_blooms": len(sst.block_blooms),
            "missing_queries": N_MISSING,
            "missing_hits": miss_hits,
            "measured_fpr": (st_miss.bloom_fp / denom) if denom else (1.0 if mode == "none" else 0.0),
            "bloom_fp": st_miss.bloom_fp,
            "bloom_useful": st_miss.bloom_useful,
            "data_block_reads_missing": st_miss.data_block_reads,
            "index_reads_missing": st_miss.index_reads,
            "partition_index_reads_missing": st_miss.partition_index_reads,
            "filter_bytes_loaded_missing": st_miss.filter_bytes_loaded,
            "filter_bytes_loaded_per_query": st_miss.filter_bytes_loaded / N_MISSING,
            "existing_hits": hits,
            "existing_false_negatives": N_EXISTING - hits,
            "existing_index_reads": st_exist.index_reads,
            "existing_data_block_reads": st_exist.data_block_reads,
            "existing_wrong": wrong,
        }
    return {
        "n_existing": N_EXISTING,
        "n_missing": N_MISSING,
        "keys_per_block": KEYS_PER_BLOCK,
        "partitions_requested": PARTITIONS,
        "layouts": layouts,
    }


def experiment_optimize_filters_for_hits() -> dict[str, Any]:
    """Last-level bloom mainly helps missing keys, not hits."""

    def build(optimize: bool) -> BloomLSM:
        db = BloomLSM(
            bits_per_key=10,
            filter_mode="full",
            keys_per_block=KEYS_PER_BLOCK,
            optimize_filters_for_hits=optimize,
            bottom_level=2,
        )
        recs0 = [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(0, 100)]
        recs1 = [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(100, 300)]
        recs2 = [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(300, 4300)]
        db.add_sst(recs0, 0)
        db.add_sst(recs1, 1)
        db.add_sst(recs2, 2)
        return db

    # Missing keys inside the L2 range (article:0300:title .. article:4299:title).
    miss_keys = [f"article:{300 + (i % 3999):04d}:title~m{i}" for i in range(8000)]
    bottom_hits = [existing_key(i) for i in range(300, 4300)]
    out: dict[str, Any] = {
        "l0_keys": 100,
        "l1_keys": 200,
        "l2_keys": 4000,
        "missing_queries": len(miss_keys),
        "bottom_hit_queries": len(bottom_hits),
    }
    for label, optimize in (("filters_on_all_levels", False), ("skip_bottom_filter", True)):
        db = build(optimize)
        miss = _probe_lsm(db, miss_keys, expect_hit=False)
        hit = _probe_lsm(db, bottom_hits, expect_hit=True)
        out[label] = {
            "optimize_filters_for_hits": optimize,
            "filter_memory_bytes": db.filter_memory_bytes(),
            "l2_has_filter": db.levels[2][0].filter_mode != "none",
            "missing": {
                "data_block_reads": miss["data_block_reads"],
                "bloom_useful": miss["bloom_useful"],
                "bloom_fp": miss["bloom_fp"],
                "data_reads_per_query": miss["data_reads_per_query"],
                "false_hit": miss["false_hit"],
                "elapsed_s": miss["elapsed_s"],
            },
            "bottom_hits": {
                "hits": hit["hits"],
                "false_negatives": hit["false_negatives"],
                "data_block_reads": hit["data_block_reads"],
                "bloom_tp": hit["bloom_tp"],
                "bloom_useful": hit["bloom_useful"],
                "data_reads_per_query": hit["data_reads_per_query"],
                "elapsed_s": hit["elapsed_s"],
            },
        }
    return out


def experiment_tombstone_in_filter() -> dict[str, Any]:
    """Tombstone keys must stay in the SST bloom, or an older value can resurrect."""
    old = Record(existing_key(1), KIND_PUT, "Weekly digest")
    tomb = Record(existing_key(1), KIND_DEL, "")
    others_l1 = [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(10, 60)]
    others_l0 = [Record(existing_key(i), KIND_PUT, existing_value(i)) for i in range(70, 90)]

    def build(include_tombstone_in_bloom: bool) -> tuple[BloomLSM, str, Optional[str]]:
        db = BloomLSM(bits_per_key=10, filter_mode="full", keys_per_block=8, bottom_level=1)
        db.add_sst(others_l1 + [old], level=1)
        l0_recs = others_l0 + [tomb]
        sst = SSTFile(db._next_file_id, 0, l0_recs, bits_per_key=10, filter_mode="full", keys_per_block=8)
        db._next_file_id += 1
        if not include_tombstone_in_bloom:
            live = [r.key for r in l0_recs if r.kind != KIND_DEL]
            buggy = BloomFilter(len(live), 10)
            for k in live:
                buggy.add(k)
            sst.bloom = buggy
        db.levels[0].append(sst)
        db.reset_stats()
        outcome, value = db.get(existing_key(1))
        return db, outcome, value

    ok_db, ok_outcome, ok_value = build(True)
    bad_db, bad_outcome, bad_value = build(False)
    db = BloomLSM(bits_per_key=10, filter_mode="full", keys_per_block=8, bottom_level=1)
    db.add_sst(others_l1 + [old], level=1)
    db.add_sst(others_l0 + [tomb], level=0)
    compacted = db.compact_level(0, 1)
    db.reset_stats()
    c_outcome, c_value = db.get(existing_key(1))
    still_in_bloom = compacted.bloom.may_contain(existing_key(1)) if compacted.bloom else None
    key_in_sst = any(r.key == existing_key(1) for r in compacted.records)
    return {
        "correct_bloom_includes_tombstone": {
            "outcome": ok_outcome,
            "value": ok_value,
            "data_block_reads": ok_db.stats.data_block_reads,
            "hides_old_value": ok_outcome == TOMBSTONE and ok_value is None,
        },
        "buggy_bloom_omits_tombstone": {
            "outcome": bad_outcome,
            "value": bad_value,
            "resurrects_old_value": bad_outcome == HIT and bad_value == "Weekly digest",
        },
        "rebuild_on_bottom_compaction": {
            "outcome": c_outcome,
            "value": c_value,
            "key_in_sst": key_in_sst,
            "may_contain_after_rebuild": still_in_bloom,
            "records": len(compacted.records),
            "correct_miss": c_outcome != HIT,
        },
    }


def run_all_experiments() -> dict[str, Any]:
    return {
        "bits_per_key": experiment_bits_per_key(),
        "correctness": experiment_correctness(),
        "unsafe_delete": experiment_unsafe_delete(),
        "layered_read_amp": experiment_layered_read_amp(),
        "filter_layouts": experiment_filter_layouts(),
        "optimize_filters_for_hits": experiment_optimize_filters_for_hits(),
        "tombstone_in_filter": experiment_tombstone_in_filter(),
    }


if __name__ == "__main__":
    import json

    data = run_all_experiments()
    print(json.dumps(list(data.keys()), ensure_ascii=False))
