#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 -c "import agents; print('openai-agents', getattr(agents,'__version__','?'))"
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
log=Path("run.log").read_text()
assert "ALL_CHECKS_PASSED" in log
assert r["is_live_model"] is False
assert r["dashboard"]["task_success_sli"] < r["dashboard"]["http_200_rate"]
assert r["sensitive_redacted"] is True
assert r["failed"]==[]
# traces must not contain the raw demo secret
spans=Path("reports/spans.json").read_text()
assert "sk-demo-not-a-real-key-atlas-196" not in spans
assert "aabbccdd-secret" not in spans
print("POSTCHECK_OK")
PY
