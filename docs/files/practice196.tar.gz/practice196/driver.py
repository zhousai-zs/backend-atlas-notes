"""Task-success SLI and official Agents SDK tracing, offline.

Uses openai-agents 0.24.0 tracing APIs with a local TracingProcessor.
Default OpenAI export is replaced; no API key is read or sent.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from agents.tracing import (
    TracingProcessor,
    custom_span,
    function_span,
    generation_span,
    set_trace_processors,
    set_tracing_disabled,
    trace,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results.json"
SECRET = "sk-demo-not-a-real-key-atlas-196"
BEARER = "Bearer aabbccdd-secret"


class LocalProcessor(TracingProcessor):
    def __init__(self):
        self.traces = []
        self.spans = []

    def on_trace_start(self, t):
        self.traces.append({"event": "start", "id": t.trace_id, "name": t.name})

    def on_trace_end(self, t):
        self.traces.append({"event": "end", "id": t.trace_id, "name": t.name})

    def on_span_start(self, s):
        pass

    def on_span_end(self, s):
        exported = s.export() if hasattr(s, "export") else {}
        self.spans.append(redact(exported))

    def shutdown(self):
        pass

    def force_flush(self):
        pass


SENSITIVE_RE = re.compile(r"(sk-[A-Za-z0-9\-]+)|(Bearer\s+[A-Za-z0-9\-_]+)", re.I)


def redact(obj):
    if isinstance(obj, str):
        return SENSITIVE_RE.sub("[REDACTED]", obj)
    if isinstance(obj, list):
        return [redact(x) for x in obj]
    if isinstance(obj, dict):
        return {k: redact(v) for k, v in obj.items()}
    return obj


def run_task(name: str, kind: str) -> dict:
    """kind: success | http_ok_task_fail | model_fail | tool_fail"""
    usage_tokens = 0
    tool_error = False
    model_error = False
    http_ok = True
    task_ok = False
    cost = 0.0
    with trace(name):
        with custom_span("http_request"):
            http_ok = True  # all four tasks get an HTTP 200 from the front door
        if kind == "model_fail":
            with generation_span() as span:
                span.span_data.input = [{"role": "user", "content": f"diagnose with {BEARER}"}]
                span.span_data.output = [{"content": "model timeout"}]
                span.span_data.model = "scripted-offline"
                span.span_data.usage = {"input_tokens": 20, "output_tokens": 0}
                if hasattr(span, "set_error"):
                    span.set_error({"message": "model_timeout"})
                elif hasattr(span, "error"):
                    try:
                        span.error = {"message": "model_timeout"}
                    except Exception:
                        pass
            model_error = True
            usage_tokens = 20
            cost = 0.0002
            task_ok = False
        elif kind == "tool_fail":
            with generation_span() as span:
                span.span_data.model = "scripted-offline"
                span.span_data.usage = {"input_tokens": 10, "output_tokens": 8}
            usage_tokens = 18
            cost = 0.0003
            with function_span("kv_get") as span:
                span.span_data.input = {"key": "alice/profile", "authorization": SECRET}
                span.span_data.output = {"error": "backend_5xx"}
                if hasattr(span, "set_error"):
                    span.set_error({"message": "backend_5xx"})
            tool_error = True
            task_ok = False
        elif kind == "http_ok_task_fail":
            with generation_span() as span:
                span.span_data.model = "scripted-offline"
                span.span_data.output = [{"content": "wrong root cause"}]
                span.span_data.usage = {"input_tokens": 12, "output_tokens": 12}
            usage_tokens = 24
            cost = 0.0004
            with function_span("kv_get"):
                pass
            # Task acceptance fails even though HTTP and tools returned.
            task_ok = False
        else:
            with generation_span() as span:
                span.span_data.model = "scripted-offline"
                span.span_data.usage = {"input_tokens": 11, "output_tokens": 15}
            usage_tokens = 26
            cost = 0.0005
            with function_span("kv_get"):
                pass
            task_ok = True
    return {
        "name": name,
        "kind": kind,
        "http_ok": http_ok,
        "task_ok": task_ok,
        "model_error": model_error,
        "tool_error": tool_error,
        "tokens": usage_tokens,
        "cost_usd": cost,
    }


def set_span_error_if_possible(kind_label: str):
    return


def main() -> None:
    proc = LocalProcessor()
    set_tracing_disabled(False)
    set_trace_processors([proc])  # replaces default OpenAI exporter
    kinds = [
        ("p10-success", "success"),
        ("p10-http-ok-wrong", "http_ok_task_fail"),
        ("p10-model-fail", "model_fail"),
        ("p10-tool-fail", "tool_fail"),
    ]
    outcomes = [run_task(n, k) for n, k in kinds]
    total = len(outcomes)
    task_success = sum(1 for o in outcomes if o["task_ok"])
    http_success = sum(1 for o in outcomes if o["http_ok"])
    tool_errors = sum(1 for o in outcomes if o["tool_error"])
    model_errors = sum(1 for o in outcomes if o["model_error"])
    duration_proxy = len(proc.spans)  # structural; we also use span timestamps
    times = []
    for s in proc.spans:
        if s and s.get("started_at") and s.get("ended_at"):
            times.append((s["started_at"], s["ended_at"]))
    cost_ok = sum(o["cost_usd"] for o in outcomes if o["task_ok"])
    cost_all = sum(o["cost_usd"] for o in outcomes)
    cost_per_success = cost_ok / task_success if task_success else None

    dumped = json.dumps(proc.spans)
    leaked = (SECRET in dumped) or ("aabbccdd-secret" in dumped) or (BEARER in dumped)
    redacted = "[REDACTED]" in dumped

    dashboard = {
        "task_success_sli": task_success / total,
        "http_200_rate": http_success / total,
        "tool_error_rate": tool_errors / total,
        "model_error_rate": model_errors / total,
        "tasks": total,
        "successes": task_success,
        "cost_per_successful_task_usd": cost_per_success,
        "cost_all_tasks_usd": cost_all,
        "note": "Success is task acceptance, not HTTP 200. Token costs are scripted, not from a live model.",
    }
    checks = [
        ("task_sli_not_http", dashboard["task_success_sli"] == 0.25 and dashboard["http_200_rate"] == 1.0, str(dashboard)),
        ("model_and_tool_failures_separated", model_errors == 1 and tool_errors == 1, f"model={model_errors} tool={tool_errors}"),
        ("cost_per_success_defined", cost_per_success is not None, str(cost_per_success)),
        ("sensitive_redacted", (not leaked) and redacted, f"leaked={leaked} redacted={redacted}"),
        ("official_spans_captured", any((s or {}).get("span_data", {}).get("type") == "generation" for s in proc.spans), str(len(proc.spans))),
        ("function_spans_captured", any((s or {}).get("span_data", {}).get("type") == "function" for s in proc.spans), ""),
    ]
    for n, ok, d in checks:
        print(("PASS " if ok else "FAIL ") + n + (f" {d}" if d else ""))
    failed = [n for n, ok, _ in checks if not ok]
    (ROOT / "reports" / "dashboard.json").write_text(json.dumps(dashboard, indent=2) + "\n")
    (ROOT / "reports" / "spans.json").write_text(json.dumps(proc.spans, indent=2) + "\n")
    RESULTS.write_text(
        json.dumps(
            {
                "lesson": 196,
                "id": "m-observability",
                "is_live_model": False,
                "agents_sdk_version": "0.24.0",
                "dashboard": dashboard,
                "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
                "failed": failed,
                "sensitive_redacted": not leaked,
                "not_verified_on_this_machine": [
                    "OpenAI hosted trace export (processor is local only; no API key used)",
                    "live-model token accounting or a production Grafana board",
                ],
                "verified_on_this_machine": [
                    "openai-agents 0.24.0 trace/generation_span/function_span with a local TracingProcessor",
                    "task success SLI differs from HTTP 200 rate; model vs tool errors counted separately; secrets redacted",
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    if failed:
        raise SystemExit("FAILED: " + ", ".join(failed))
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
