# practice166 — 推理服务与批调度

教学调度器比较 FIFO / 连续批处理草图 / SJF 的 TTFT 与吞吐，不是 vLLM。scripts/vllm-openai.sh 需自备 GPU，test.sh 不执行它。

```bash
bash test.sh
```
