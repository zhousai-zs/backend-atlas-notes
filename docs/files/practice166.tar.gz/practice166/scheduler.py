"""Teaching prefill/decode scheduler. Not vLLM and not a GPU runtime."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Request:
    req_id: str
    input_tokens: int
    output_tokens: int
    arrival: float = 0.0
    start: float | None = None
    first_token_at: float | None = None
    end: float | None = None
    decode_left: int = 0
    kv_tokens: int = 0


@dataclass
class Params:
    prefill_ms_per_token: float = 0.05
    decode_ms_per_token: float = 0.8
    decode_batch_overhead: float = 0.05
    kv_bytes_per_token: float = 16.0
    kv_memory_limit_bytes: float = 80_000  # tight enough that a huge prompt can be refused


def ttft(r: Request) -> float:
    assert r.first_token_at is not None
    return r.first_token_at - r.arrival


def tpot(r: Request) -> float | None:
    if r.end is None or r.first_token_at is None or r.output_tokens <= 1:
        return None
    return (r.end - r.first_token_at) / (r.output_tokens - 1)


def e2e(r: Request) -> float:
    assert r.end is not None
    return r.end - r.arrival


def clone(r: Request) -> Request:
    return Request(r.req_id, r.input_tokens, r.output_tokens, r.arrival)


def run_fifo(requests: list[Request], params: Params) -> list[Request]:
    """Finish one request (prefill + all decode) before starting the next arrived request."""
    waiting = [clone(r) for r in sorted(requests, key=lambda x: (x.arrival, x.req_id))]
    t = 0.0
    done: list[Request] = []
    for r in waiting:
        t = max(t, r.arrival)
        r.start = t
        t += r.input_tokens * params.prefill_ms_per_token
        r.first_token_at = t  # first token emitted at end of prefill + first decode step
        t += params.decode_ms_per_token  # first token compute, already reflected in first_token_at? 
        # Be consistent: first token time = after prefill + first decode step.
        r.first_token_at = t
        t += max(r.output_tokens - 1, 0) * params.decode_ms_per_token
        r.end = t
        r.kv_tokens = r.input_tokens + r.output_tokens
        done.append(r)
    return done


def run_continuous(requests: list[Request], params: Params) -> list[Request]:
    """Prefill every request that has already arrived, then share decode steps.

    A late arrival is prefilling as soon as the current decode step finishes,
    then joins the batch. This is a teaching sketch, not vLLM's scheduler.
    """
    waiting = [clone(r) for r in requests]
    decoding: list[Request] = []
    done: list[Request] = []
    t = 0.0
    steps = 0
    while waiting or decoding:
        steps += 1
        if steps > 100000:
            raise RuntimeError("scheduler ran away")
        arrived = [r for r in waiting if r.arrival <= t + 1e-12]
        if arrived:
            r = min(arrived, key=lambda x: (x.arrival, x.req_id))
            r.start = t
            t += r.input_tokens * params.prefill_ms_per_token
            r.decode_left = r.output_tokens
            r.kv_tokens = r.input_tokens
            waiting.remove(r)
            decoding.append(r)
            continue
        if decoding:
            batch = len(decoding)
            step = params.decode_ms_per_token * (1 + params.decode_batch_overhead * (batch - 1))
            t += step
            finished = []
            for r in decoding:
                if r.first_token_at is None:
                    r.first_token_at = t
                r.decode_left -= 1
                r.kv_tokens += 1
                if r.decode_left <= 0:
                    r.end = t
                    finished.append(r)
            for r in finished:
                decoding.remove(r)
                done.append(r)
            continue
        t = min(r.arrival for r in waiting)
    return done


def kv_bytes(r: Request, params: Params, generated: int) -> float:
    return (r.input_tokens + generated) * params.kv_bytes_per_token


def would_exceed_kv(active: list[Request], new: Request, params: Params) -> bool:
    used = sum(kv_bytes(r, params, r.output_tokens) for r in active)  # worst-case reserved
    return used + kv_bytes(new, params, new.output_tokens) > params.kv_memory_limit_bytes


def run_sjf(requests: list[Request], params: Params) -> list[Request]:
    """One request at a time, always the shortest remaining arrived job (by input+output).

    Interactive TTFT can look excellent while tokens/s stays below a batched policy
    because decode never overlaps.
    """
    waiting = [clone(r) for r in requests]
    t = 0.0
    done: list[Request] = []
    while waiting:
        arrived = [r for r in waiting if r.arrival <= t + 1e-12]
        if not arrived:
            t = min(r.arrival for r in waiting)
            continue
        r = min(arrived, key=lambda x: (x.input_tokens + x.output_tokens, x.req_id))
        r.start = t
        t += r.input_tokens * params.prefill_ms_per_token
        t += params.decode_ms_per_token
        r.first_token_at = t
        t += max(r.output_tokens - 1, 0) * params.decode_ms_per_token
        r.end = t
        waiting.remove(r)
        done.append(r)
    return done
