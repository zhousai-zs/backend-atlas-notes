#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_vllm"] is False and r["is_live_gpu"] is False
assert r["scheduler_is_teaching_sketch"] is True
assert r["observations"]["long_request_queues_others_under_fifo"] is True
assert r["fifo"]["input_tokens"] and r["fifo"]["output_tokens"]
for row in r["fifo"]["requests"] + r["continuous_batching_sketch"]["requests"]:
    assert "input_tokens" in row and "output_tokens" in row and "ttft_ms" in row
print("POSTCHECK_OK")
PY
