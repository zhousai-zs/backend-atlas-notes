#!/usr/bin/env python3
"""Compare FIFO vs continuous-batching sketches. Not a vLLM measurement."""

from __future__ import annotations

import json
from pathlib import Path

from scheduler import Params, Request, e2e, run_continuous, run_fifo, run_sjf, tpot, ttft, would_exceed_kv

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

params = Params()

# Mix of a long-running request and shorter interactive ones.
workload = [
    Request("long", input_tokens=800, output_tokens=120, arrival=0.0),
    Request("short-a", input_tokens=40, output_tokens=16, arrival=0.0),
    Request("short-b", input_tokens=60, output_tokens=20, arrival=5.0),  # arrives while long is running
    Request("tiny", input_tokens=20, output_tokens=8, arrival=8.0),
]


def summarize(name: str, rs: list[Request]) -> dict:
    wall = max(r.end for r in rs)
    out_tok = sum(r.output_tokens for r in rs)
    in_tok = sum(r.input_tokens for r in rs)
    rows = []
    for r in rs:
        rows.append(
            {
                "req_id": r.req_id,
                "input_tokens": r.input_tokens,
                "output_tokens": r.output_tokens,
                "arrival_ms": r.arrival,
                "ttft_ms": round(ttft(r), 4),
                "tpot_ms": None if tpot(r) is None else round(tpot(r), 4),
                "e2e_ms": round(e2e(r), 4),
            }
        )
    return {
        "policy": name,
        "is_vllm": False,
        "wall_ms": round(wall, 4),
        "input_tokens": in_tok,
        "output_tokens": out_tok,
        "output_tokens_per_ms": round(out_tok / wall, 6),
        "requests": rows,
    }


fifo = summarize("fifo", run_fifo(workload, params))
cb = summarize("continuous_batching_sketch", run_continuous(workload, params))
sjf = summarize("shortest_job_first", run_sjf(workload, params))

# Short request TTFT is worse under FIFO because it waits for the long one.
fifo_short = next(r for r in fifo["requests"] if r["req_id"] == "short-a")
cb_short = next(r for r in cb["requests"] if r["req_id"] == "short-a")
fifo_late = next(r for r in fifo["requests"] if r["req_id"] == "tiny")
cb_late = next(r for r in cb["requests"] if r["req_id"] == "tiny")
assert fifo_short["ttft_ms"] > cb_short["ttft_ms"]
assert fifo_late["ttft_ms"] > cb_late["ttft_ms"]

sjf_short = next(r for r in sjf["requests"] if r["req_id"] == "short-a")
sjf_late = next(r for r in sjf["requests"] if r["req_id"] == "tiny")
# Peak tokens/s and interactive TTFT need not elect the same policy.
throughput = {
    "fifo": fifo["output_tokens_per_ms"],
    "cb": cb["output_tokens_per_ms"],
    "sjf": sjf["output_tokens_per_ms"],
}
tiny_ttft = {
    "fifo": fifo_late["ttft_ms"],
    "cb": cb_late["ttft_ms"],
    "sjf": sjf_late["ttft_ms"],
}
tokens_s_better_policy = max(throughput, key=throughput.get)
ttft_better_for_tiny = min(tiny_ttft, key=tiny_ttft.get)
diverged = tokens_s_better_policy != ttft_better_for_tiny
assert diverged, (throughput, tiny_ttft)
assert sjf_short["ttft_ms"] < cb_short["ttft_ms"]

# KV admission: a huge reserved prompt is refused when the budget is already tight.
active = [Request("a", 2000, 100), Request("b", 2000, 100)]
huge = Request("huge", 8000, 200)
assert would_exceed_kv(active, huge, params) is True
small = Request("ok", 10, 8)
# empty cluster admits a small request
assert would_exceed_kv([], small, params) is False

vllm_commands = (ROOT / "scripts/vllm-openai.sh").read_text()
assert "vllm serve" in vllm_commands
assert "docs.vllm.ai/en/latest/serving/online_serving" in vllm_commands

results = {
    "lesson": 166,
    "id": "k-inference",
    "is_live_vllm": False,
    "is_live_gpu": False,
    "scheduler_is_teaching_sketch": True,
    "params": {
        "prefill_ms_per_token": params.prefill_ms_per_token,
        "decode_ms_per_token": params.decode_ms_per_token,
        "decode_batch_overhead": params.decode_batch_overhead,
        "note": "These constants are teaching units, not measurements from a real GPU or vLLM.",
    },
    "fifo": fifo,
    "continuous_batching_sketch": cb,
    "shortest_job_first": sjf,
    "observations": {
        "short-a_ttft_fifo_ms": fifo_short["ttft_ms"],
        "short-a_ttft_cb_ms": cb_short["ttft_ms"],
        "short-a_ttft_sjf_ms": sjf_short["ttft_ms"],
        "tiny_ttft_fifo_ms": fifo_late["ttft_ms"],
        "tiny_ttft_cb_ms": cb_late["ttft_ms"],
        "tiny_ttft_sjf_ms": sjf_late["ttft_ms"],
        "fifo_output_tokens_per_ms": fifo["output_tokens_per_ms"],
        "cb_output_tokens_per_ms": cb["output_tokens_per_ms"],
        "sjf_output_tokens_per_ms": sjf["output_tokens_per_ms"],
        "tokens_per_ms_winner": tokens_s_better_policy,
        "tiny_ttft_winner": ttft_better_for_tiny,
        "tokens_per_ms_and_ttft_diverge": diverged,
        "long_request_queues_others_under_fifo": fifo_short["ttft_ms"] > cb_short["ttft_ms"],
    },
    "kv_admission": {
        "huge_refused_when_active": True,
        "small_admitted_on_empty": True,
        "limit_bytes": params.kv_memory_limit_bytes,
        "kv_bytes_per_token_is_teaching_constant": True,
    },
    "official_vllm_docs": "https://docs.vllm.ai/en/latest/serving/online_serving/",
    "verified_on_this_machine": [
        "teaching_scheduler_ttft_tpot_on_labeled_workload",
        "fifo_queues_short_requests_behind_a_long_one",
        "kv_admission_rejects_over_budget_reservation",
    ],
    "not_verified_on_this_machine": [
        "vLLM_continuous_batching_on_a_real_GPU",
        "real_TTFT_TPOT_of_any_served_model",
        "chunked_prefill_or_paged_attention_implementation",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
(REPORTS / "trace.txt").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results["observations"], indent=2))
print("ALL_CHECKS_PASSED")
