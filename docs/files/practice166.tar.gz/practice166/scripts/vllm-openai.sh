#!/usr/bin/env bash
# User-run path for a local OpenAI-compatible vLLM server.
# This script is not executed by test.sh (no GPU / no vLLM on this machine).
# Official docs (fetched 2026-11-15; the older openai_compatible_server page
# now redirects here):
#   https://docs.vllm.ai/en/latest/serving/online_serving/
set -euo pipefail
MODEL="${MODEL:-meta-llama/Llama-3.2-1B-Instruct}"
PORT="${PORT:-8000}"
# Install and run only on a machine that has a GPU and a vLLM wheel you trust.
# Do not paste paid API keys into this script.
python3 -m vllm.entrypoints.openai.api_server \
  --model "$MODEL" \
  --port "$PORT"
# Equivalent newer CLI (see the same official page):
#   vllm serve "$MODEL" --port "$PORT"
# Then compare TTFT / TPOT with a client of your choice, and record
# input_tokens and output_tokens with every measurement.
