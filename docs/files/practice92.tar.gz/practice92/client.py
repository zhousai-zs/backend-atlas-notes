"""并发发请求并校验日志。用法: python3 client.py PORT LOGFILE MODE
MODE: concurrent | deadline | security"""
import sys, json, os, urllib.request
from concurrent.futures import ThreadPoolExecutor

PORT, LOG, MODE = int(sys.argv[1]), sys.argv[2], sys.argv[3]

def get(headers):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}/article/1", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")

def logs():
    return [json.loads(l) for l in open(LOG)]

if MODE == "concurrent":
    traces = [os.urandom(16).hex() for _ in range(40)]
    def one(t):
        return t, get({"traceparent": f"00-{t}-{os.urandom(8).hex()}-01",
                       "authorization": "Bearer tok-alice", "x-sleep-ms": "30",
                       "baggage": "channel=web,exp=B"})
    with ThreadPoolExecutor(20) as ex:
        res = list(ex.map(one, traces))
    mism = sum(1 for t, (st, b) in res if b.get("storage", {}).get("trace_seen") != t)
    L = logs()
    bad_lines = sum(1 for r in L if r["svc"] == "storage" and r["trace_id"] not in traces)
    # 完整调用链：每个 trace 都应有 gateway recv -> call_storage -> storage recv，且父子 span 相连
    chains = 0
    for t in traces:
        rs = [r for r in L if r["trace_id"] == t]
        call = [r for r in rs if r["event"] == "call_storage"]
        srec = [r for r in rs if r["svc"] == "storage" and r["event"] == "recv"]
        if call and srec and srec[0]["parent_id"] == call[0]["span_id"]:
            chains += 1
    print(json.dumps({"requests": len(traces), "status_200": sum(1 for _, (s, _) in res if s == 200),
                      "trace_mismatch": mism, "storage_lines_with_foreign_trace": bad_lines,
                      "complete_chains": chains}))

elif MODE == "deadline":
    st, b = get({"authorization": "Bearer tok-bob", "x-deadline-ms": "150", "x-sleep-ms": "400"})
    import time; time.sleep(0.5)               # 等存储服务那边把中止记录写完
    L = logs()
    ab = [r for r in L if r["event"] == "abort"]
    rec = [r for r in L if r["svc"] == "storage" and r["event"] == "recv"]
    print(json.dumps({"status": st, "storage_recv_remaining_ms": rec[-1]["remaining_ms"] if rec else None,
                      "storage_aborted": bool(ab), "work_done_ms": ab[-1]["work_done_ms"] if ab else None,
                      "write_ok": any(r["event"] == "write_ok" for r in L)}))

elif MODE == "security":
    st1, b1 = get({"x-user-id": "admin", "traceparent": f"00-{'a'*32}-{'b'*16}-01"})
    st2, b2 = get({"authorization": "Bearer tok-alice", "x-user-id": "admin",
                   "baggage": "channel=app,access_token=SECRET123,user_phone=13800000000"})
    L = logs()
    leaked = any("SECRET123" in json.dumps(r) or "13800000000" in json.dumps(r)
                 for r in L if r["svc"] == "storage")
    recv = [r for r in L if r["svc"] == "gateway" and r["event"] == "recv"]
    print(json.dumps({"forged_only_status": st1, "forged_with_token_user": recv[-1]["user"],
                      "storage_baggage": [r["baggage"] for r in L if r["svc"] == "storage" and r["event"] == "recv"][-1],
                      "secret_reached_storage": leaked}))
