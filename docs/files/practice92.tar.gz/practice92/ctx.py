"""最小请求上下文：contextvars + W3C traceparent 风格的 inject/extract（教学实现）。"""
import contextvars, os, time, json, threading

_ctx = contextvars.ContextVar("req_ctx", default=None)
SENSITIVE = ("token", "authorization", "password", "phone", "id_card")
LOG_LOCK = threading.Lock()

def new_id(nbytes):
    return os.urandom(nbytes).hex()

class Ctx:
    def __init__(self, trace_id, span_id, parent_id=None, deadline=None, baggage=None, user=None):
        self.trace_id, self.span_id, self.parent_id = trace_id, span_id, parent_id
        self.deadline = deadline            # 绝对时间（time.monotonic 秒）
        self.baggage = dict(baggage or {})
        self.user = user                    # 只能由服务端在认证后写入

    def remaining_ms(self):
        return None if self.deadline is None else int((self.deadline - time.monotonic()) * 1000)

    def child(self):
        return Ctx(self.trace_id, new_id(8), self.span_id, self.deadline, self.baggage, self.user)

def current():
    return _ctx.get()

def attach(ctx):
    return _ctx.set(ctx)

def detach(token):
    _ctx.reset(token)

def inject(ctx):
    """把上下文序列化成出站请求头。身份不放头里，敏感 baggage 被丢弃。"""
    h = {"traceparent": f"00-{ctx.trace_id}-{ctx.span_id}-01"}
    safe = {k: v for k, v in ctx.baggage.items() if not any(s in k.lower() for s in SENSITIVE)}
    if safe:
        h["baggage"] = ",".join(f"{k}={v}" for k, v in safe.items())
    rem = ctx.remaining_ms()
    if rem is not None:
        h["x-deadline-ms"] = str(max(rem, 0))   # 传剩余预算，不传绝对时间（两台机器时钟不同）
    return h

def extract(headers, default_budget_ms=None):
    """从入站请求头恢复上下文；格式不合法就重新生成 trace。"""
    tp = headers.get("traceparent", "")
    parts = tp.split("-")
    if len(parts) == 4 and len(parts[1]) == 32 and len(parts[2]) == 16:
        trace_id, parent = parts[1], parts[2]
    else:
        trace_id, parent = new_id(16), None
    bag = {}
    for kv in filter(None, headers.get("baggage", "").split(",")):
        k, _, v = kv.partition("=")
        if not any(s in k.lower() for s in SENSITIVE):
            bag[k.strip()] = v.strip()
    budget = headers.get("x-deadline-ms")
    budget = int(budget) if budget and budget.isdigit() else default_budget_ms
    deadline = None if budget is None else time.monotonic() + budget / 1000
    return Ctx(trace_id, new_id(8), parent, deadline, bag)

def log(logfile, service, event, **kw):
    c = current()
    rec = {"svc": service, "event": event,
           "trace_id": c.trace_id if c else None, "span_id": c.span_id if c else None,
           "parent_id": c.parent_id if c else None, **kw}
    with LOG_LOCK, open(logfile, "a") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
