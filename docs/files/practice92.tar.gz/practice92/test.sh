#!/usr/bin/env bash
# practice92：跨线程 RPC 传播 trace 和 deadline，验证并发请求互不覆盖
set -u
cd "$(dirname "$0")"
PORT=${PORT:-18920}
fail=0
check(){ if python3 -c "import json,sys; d=json.loads(sys.argv[1]); sys.exit(0 if ($2) else 1)" "$3"; then echo "  PASS: $1"; else echo "  FAIL: $1"; fail=1; fi; }
start(){ rm -f "$2"; python3 server.py "$PORT" "$2" ${3:-} > /dev/null 2>&1 & SP=$!; sleep 0.6; }
stop(){ kill $SP 2>/dev/null; wait $SP 2>/dev/null; }

echo "== 1. 反面教材：全局变量保存 trace（--naive）"
start "$PORT" naive.log --naive
R=$(python3 client.py $PORT naive.log concurrent); echo "  $R"; stop
check "naive 模式出现串请求" "d['trace_mismatch']>0" "$R"

echo "== 2. contextvars + copy_context 跨线程传播"
start "$PORT" good.log
R=$(python3 client.py $PORT good.log concurrent); echo "  $R"; stop
check "40 个并发请求全部 200" "d['status_200']==40" "$R"
check "trace 互不覆盖" "d['trace_mismatch']==0 and d['storage_lines_with_foreign_trace']==0" "$R"
check "日志可关联完整调用链（父子 span 相连）" "d['complete_chains']==40" "$R"

echo "== 3. deadline 继承与提前放弃"
start "$PORT" dl.log
R=$(python3 client.py $PORT dl.log deadline); echo "  $R"; stop
check "存储服务收到的剩余预算 < 150ms" "0 < d['storage_recv_remaining_ms'] < 150" "$R"
check "网关按截止时间返回 504" "d['status']==504" "$R"
check "预算耗尽后中止且未写入" "d['storage_aborted'] and not d['write_ok'] and d['work_done_ms'] < 400" "$R"

echo "== 4. 身份来源与 baggage 边界"
start "$PORT" sec.log
R=$(python3 client.py $PORT sec.log security); echo "  $R"; stop
check "只带伪造 x-user-id 被拒 401" "d['forged_only_status']==401" "$R"
check "有令牌时身份取自令牌而非 x-user-id" "d['forged_with_token_user']=='alice'" "$R"
check "令牌和手机号没有进入下游 baggage" "not d['secret_reached_storage'] and d['storage_baggage']=={'channel':'app'}" "$R"

[ $fail = 0 ] && echo "ALL_CHECKS_PASSED" || { echo "SOME_CHECKS_FAILED"; exit 1; }
