"""两个服务：gateway(:PORT) 认证+扇出到线程池调用 storage(:PORT+1)。
用法: python3 server.py PORT LOGFILE [--naive]
--naive 模式用全局变量保存当前 trace，演示并发串请求。"""
import sys, time, json, urllib.request, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from concurrent.futures import ThreadPoolExecutor
import contextvars
import ctx as C

PORT, LOG = int(sys.argv[1]), sys.argv[2]
NAIVE = "--naive" in sys.argv
POOL = ThreadPoolExecutor(max_workers=8)
GLOBAL_TRACE = {"id": None}          # 反面教材
TOKENS = {"tok-alice": "alice", "tok-bob": "bob"}   # 教学用的假令牌表

def call_storage(path, headers, timeout_s):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT+1}{path}", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
    except Exception as e:                      # 超时 = 自己的预算用完，按截止时间超限处理
        return 504, {"err": "deadline exceeded (" + type(e).__name__ + ")"}

def storage_task(path, sleep_ms):
    """在线程池中执行：依赖上下文里的 trace 和 deadline。"""
    c = C.current()
    if NAIVE:
        time.sleep(0.02)                        # 让别的请求有机会改全局变量
        C.log(LOG, "gateway", "call_storage", naive_trace=GLOBAL_TRACE["id"])
        return call_storage(path, {"traceparent": f"00-{GLOBAL_TRACE['id']}-{'0'*16}-01",
                                   "x-sleep-ms": str(sleep_ms)}, 5)
    child = c.child()
    tok = C.attach(child)
    try:
        rem = child.remaining_ms()
        if rem is not None and rem <= 10:
            C.log(LOG, "gateway", "skip_storage", remaining_ms=rem)
            return 504, {"err": "deadline exceeded before call"}
        C.log(LOG, "gateway", "call_storage", remaining_ms=rem)
        h = C.inject(child); h["x-sleep-ms"] = str(sleep_ms)
        return call_storage(path, h, (rem or 5000) / 1000)
    finally:
        C.detach(tok)

class Gateway(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        hdr = {k.lower(): v for k, v in self.headers.items()}
        # 1) 身份只来自可信来源：校验令牌；外部传入的 x-user-id 一律忽略
        user = TOKENS.get(hdr.get("authorization", "").removeprefix("Bearer "))
        c = C.extract(hdr, default_budget_ms=1000)
        c.user = user
        tok = C.attach(c)
        try:
            C.log(LOG, "gateway", "recv", forged_user_hdr=hdr.get("x-user-id"), user=user,
                  baggage=c.baggage)
            if user is None:
                return self.reply(401, {"err": "unauthenticated", "trace_id": c.trace_id})
            if NAIVE:
                GLOBAL_TRACE["id"] = c.trace_id
                fut = POOL.submit(storage_task, self.path, int(hdr.get("x-sleep-ms", "50")))
            else:
                # 关键：把当前上下文复制进线程池任务
                fut = POOL.submit(contextvars.copy_context().run, storage_task,
                                  self.path, int(hdr.get("x-sleep-ms", "50")))
            st, body = fut.result()
            C.log(LOG, "gateway", "done", status=st)
            self.reply(st, {"trace_id": c.trace_id, "storage": body})
        finally:
            C.detach(tok)
    def reply(self, st, obj):
        b = json.dumps(obj).encode()
        self.send_response(st); self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)

class Storage(Gateway):
    def do_GET(self):
        hdr = {k.lower(): v for k, v in self.headers.items()}
        c = C.extract(hdr)
        tok = C.attach(c)
        try:
            sleep_ms = int(hdr.get("x-sleep-ms", "50"))
            C.log(LOG, "storage", "recv", remaining_ms=c.remaining_ms(), baggage=c.baggage,
                  baggage_hdr=hdr.get("baggage"))
            # 继承剩余预算：分小步工作，预算用完就停（模拟取消）
            done = 0
            while done < sleep_ms:
                rem = c.remaining_ms()
                if rem is not None and rem <= 0:
                    C.log(LOG, "storage", "abort", work_done_ms=done)
                    return self.reply(504, {"err": "deadline", "work_done_ms": done})
                time.sleep(0.01); done += 10
            C.log(LOG, "storage", "write_ok", work_done_ms=done)
            self.reply(200, {"trace_seen": c.trace_id, "parent_seen": c.parent_id})
        finally:
            C.detach(tok)

if __name__ == "__main__":
    s1 = ThreadingHTTPServer(("127.0.0.1", PORT), Gateway)
    s2 = ThreadingHTTPServer(("127.0.0.1", PORT + 1), Storage)
    threading.Thread(target=s2.serve_forever, daemon=True).start()
    print(f"gateway :{PORT} storage :{PORT+1} naive={NAIVE}", flush=True)
    s1.serve_forever()
