#!/usr/bin/env python3
"""Teaching ShardingEngine — not Redis.

A Python standard-library model of hash sharding, range sharding,
consistent hashing with virtual nodes, and a Redis-like hash-slot
migration protocol (MOVED / ASK / MIGRATING / IMPORTING, hash tags).

This is not Redis, not redis-py, and not a network service. There is
no TCP protocol, no cluster bus, no gossip, no CLUSTER command parser,
and no slot-ownership gossip. The consistent-hash ring uses MD5 to
place virtual nodes; Redis Cluster does not use that ring. The
hash-slot path uses the Redis Cluster CRC16 (XMODEM) formula
HASH_SLOT = CRC16(key) & 0x3FFF and the hash-tag rule from the Redis
Cluster specification checked on 2026-11-12, for the subset
implemented here.
"""
from __future__ import annotations

import bisect
import hashlib
from dataclasses import dataclass
from typing import Any, Iterable, Optional

CRC16TAB = [
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
    0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
    0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
    0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
    0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
    0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
    0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
    0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
    0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
    0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
    0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
    0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
    0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
    0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
    0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
    0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
    0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
    0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
    0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
    0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
    0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
    0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
    0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0,
]

CLUSTER_SLOTS = 16384


def crc16(data: bytes | str) -> int:
    """XMODEM CRC-16, same parameters as the Redis Cluster spec appendix."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    crc = 0
    for b in data:
        crc = ((crc << 8) ^ CRC16TAB[((crc >> 8) ^ b) & 0xFF]) & 0xFFFF
    return crc


def hash_tag_payload(key: str) -> str:
    """Return the substring Redis Cluster would hash, or the whole key."""
    s = key.find("{")
    if s < 0:
        return key
    e = key.find("}", s + 1)
    if e < 0 or e == s + 1:
        return key
    return key[s + 1 : e]


def key_hash_slot(key: str) -> int:
    """HASH_SLOT = CRC16(hash-tag or key) & 0x3FFF. Matches Redis keyHashSlot."""
    return crc16(hash_tag_payload(key)) & 0x3FFF


def ring_hash(text: str) -> int:
    """Teaching ring hash (MD5). Not CRC16, not Redis."""
    return int.from_bytes(hashlib.md5(text.encode("utf-8")).digest()[:8], "big")


@dataclass
class OpResult:
    ok: bool
    status: str
    key: str = ""
    value: Optional[str] = None
    node: str = ""
    slot: Optional[int] = None
    redirect_to: str = ""
    asking: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "status": self.status,
            "key": self.key,
            "value": self.value,
            "node": self.node,
            "slot": self.slot,
            "redirect_to": self.redirect_to,
            "asking": self.asking,
        }


class Node:
    def __init__(self, name: str) -> None:
        self.name = name
        self.data: dict[str, str] = {}

    def size(self) -> int:
        return len(self.data)


class ConsistentHashRouter:
    """Ketama-style ring: each physical node owns `vnodes` points.

    Adding or removing a node only remaps keys whose clockwise
    successor changes. This is a teaching router, not Redis Cluster.
    """

    def __init__(self, nodes: Iterable[str], vnodes: int = 150) -> None:
        self.vnodes = int(vnodes)
        if self.vnodes < 1:
            raise ValueError("vnodes must be >= 1")
        self.nodes: list[str] = []
        self._ring: list[tuple[int, str]] = []  # sorted (hash, node)
        self._hashes: list[int] = []
        for name in nodes:
            self.add_node(name, rebuild_only=True)
        self._rebuild()

    def _rebuild(self) -> None:
        ring: list[tuple[int, str]] = []
        for name in self.nodes:
            for i in range(self.vnodes):
                ring.append((ring_hash(f"{name}#{i}"), name))
        ring.sort()
        self._ring = ring
        self._hashes = [h for h, _ in ring]

    def add_node(self, name: str, rebuild_only: bool = False) -> None:
        if name in self.nodes:
            raise ValueError(f"duplicate node {name}")
        self.nodes.append(name)
        if not rebuild_only:
            self._rebuild()

    def remove_node(self, name: str) -> None:
        if name not in self.nodes:
            raise ValueError(f"unknown node {name}")
        self.nodes = [n for n in self.nodes if n != name]
        self._rebuild()

    def route(self, key: str) -> str:
        if not self._ring:
            raise RuntimeError("empty ring")
        h = ring_hash(key)
        i = bisect.bisect_left(self._hashes, h)
        if i == len(self._ring):
            i = 0
        return self._ring[i][1]

    def place(self, keys: Iterable[str]) -> dict[str, str]:
        return {k: self.route(k) for k in keys}

    def counts(self, keys: Iterable[str]) -> dict[str, int]:
        out = {n: 0 for n in self.nodes}
        for k in keys:
            out[self.route(k)] += 1
        return out

    def snapshot(self) -> "ConsistentHashRouter":
        return ConsistentHashRouter(list(self.nodes), vnodes=self.vnodes)


class ModuloRouter:
    """hash(key) % N. Changing N remaps most keys. Teaching only."""

    def __init__(self, nodes: Iterable[str]) -> None:
        self.nodes = list(nodes)

    def route(self, key: str) -> str:
        return self.nodes[ring_hash(key) % len(self.nodes)]

    def add_node(self, name: str) -> None:
        if name in self.nodes:
            raise ValueError(f"duplicate node {name}")
        self.nodes.append(name)

    def remove_node(self, name: str) -> None:
        self.nodes = [n for n in self.nodes if n != name]

    def place(self, keys: Iterable[str]) -> dict[str, str]:
        return {k: self.route(k) for k in keys}

    def counts(self, keys: Iterable[str]) -> dict[str, int]:
        out = {n: 0 for n in self.nodes}
        for k in keys:
            out[self.route(k)] += 1
        return out

    def snapshot(self) -> "ModuloRouter":
        return ModuloRouter(list(self.nodes))


class RangeRouter:
    """Contiguous id ranges. Good for range scans, easy to unbalance."""

    def __init__(self, ranges: list[tuple[str, int, int]]) -> None:
        # (node, start_inclusive, end_exclusive)
        self.ranges = list(ranges)

    def route_id(self, article_id: int) -> str:
        for name, start, end in self.ranges:
            if start <= article_id < end:
                return name
        raise KeyError(f"id {article_id} not in any range")

    def route_key(self, key: str) -> str:
        # keys like article:00042:title
        parts = key.split(":")
        return self.route_id(int(parts[1]))

    def nodes_for_scan(self, start_id: int, end_id: int) -> list[str]:
        # end_id inclusive
        hit: list[str] = []
        for name, start, end in self.ranges:
            if start < end_id + 1 and end > start_id:
                hit.append(name)
        return hit

    def counts_by_id(self, ids: Iterable[int]) -> dict[str, int]:
        out: dict[str, int] = {name: 0 for name, _, _ in self.ranges}
        for i in ids:
            out[self.route_id(i)] += 1
        return out


def migration_stats(before: dict[str, str], after: dict[str, str]) -> dict[str, Any]:
    assert before.keys() == after.keys()
    total = len(before)
    moved = sum(1 for k in before if before[k] != after[k])
    stayed = total - moved
    by_dest: dict[str, int] = {}
    for k in before:
        if before[k] != after[k]:
            by_dest[after[k]] = by_dest.get(after[k], 0) + 1
    return {
        "total_keys": total,
        "moved": moved,
        "stayed": stayed,
        "migration_ratio": (moved / total) if total else 0.0,
        "stay_ratio": (stayed / total) if total else 0.0,
        "moved_to": by_dest,
    }


def imbalance(counts: dict[str, int]) -> dict[str, Any]:
    vals = list(counts.values())
    total = sum(vals) or 1
    shares = {n: c / total for n, c in counts.items()}
    return {
        "counts": dict(counts),
        "shares": shares,
        "min": min(vals) if vals else 0,
        "max": max(vals) if vals else 0,
        "max_min_ratio": (max(vals) / min(vals)) if vals and min(vals) else None,
        "ideal_share": 1 / len(counts) if counts else 0.0,
        "max_share": max(shares.values()) if shares else 0.0,
        "min_share": min(shares.values()) if shares else 0.0,
    }


@dataclass
class SlotMeta:
    owner: str
    migrating_to: Optional[str] = None
    importing_to: Optional[str] = None  # dest node name when this node imports
    importing_from: Optional[str] = None


class HashSlotCluster:
    """Teaching model of Redis Cluster slots, redirections, and resharding.

    Not a Redis server. Slot ownership is a local table. MIGRATE is a
    process-local dict move, not the Redis MIGRATE command over TCP.
    """

    def __init__(self, nodes: Iterable[str], slot_ranges: Optional[list[tuple[str, int, int]]] = None) -> None:
        names = list(nodes)
        self.nodes: dict[str, Node] = {n: Node(n) for n in names}
        self.slots: list[SlotMeta] = [SlotMeta(owner=names[0]) for _ in range(CLUSTER_SLOTS)]
        if slot_ranges is None:
            # even contiguous assignment
            n = len(names)
            size = CLUSTER_SLOTS // n
            for i, name in enumerate(names):
                start = i * size
                end = CLUSTER_SLOTS if i == n - 1 else (i + 1) * size
                for s in range(start, end):
                    self.slots[s] = SlotMeta(owner=name)
        else:
            for s in range(CLUSTER_SLOTS):
                self.slots[s] = SlotMeta(owner="")
            for name, start, end in slot_ranges:
                for s in range(start, end + 1):  # inclusive end, Redis style
                    self.slots[s] = SlotMeta(owner=name)
            if any(m.owner == "" for m in self.slots):
                raise ValueError("slot ranges must cover 0..16383")

    def add_empty_node(self, name: str) -> None:
        if name in self.nodes:
            raise ValueError(f"duplicate node {name}")
        self.nodes[name] = Node(name)

    def owner_of_slot(self, slot: int) -> str:
        return self.slots[slot].owner

    def owner_of_key(self, key: str) -> str:
        return self.owner_of_slot(key_hash_slot(key))

    def _redirect_or_serve(self, key: str, node: str, asking: bool, exists_locally: bool) -> Optional[OpResult]:
        slot = key_hash_slot(key)
        meta = self.slots[slot]
        if node not in self.nodes:
            return OpResult(False, "unknown_node", key=key, slot=slot, node=node)
        # IMPORTING dest: only serve with ASKING, else MOVED to owner
        if meta.importing_from and node != meta.owner and node == self._importer_of(slot):
            if asking:
                return None  # serve locally
            return OpResult(False, "moved", key=key, slot=slot, node=node, redirect_to=meta.owner)
        # MIGRATING source: serve if key exists, else ASK dest
        if meta.migrating_to and node == meta.owner:
            if exists_locally:
                return None
            return OpResult(
                False, "ask", key=key, slot=slot, node=node, redirect_to=meta.migrating_to, asking=True
            )
        # Normal: only the owner serves
        if node != meta.owner:
            return OpResult(False, "moved", key=key, slot=slot, node=node, redirect_to=meta.owner)
        return None

    def _importer_of(self, slot: int) -> Optional[str]:
        meta = self.slots[slot]
        if meta.migrating_to:
            return meta.migrating_to
        # also search in case only dest was marked
        for name, node in self.nodes.items():
            # stored on SlotMeta.importing_from only on the slot table globally
            pass
        return None

    def start_migrate(self, slot: int, dest: str) -> None:
        meta = self.slots[slot]
        if dest not in self.nodes:
            raise ValueError(f"unknown dest {dest}")
        if dest == meta.owner:
            raise ValueError("dest is already the owner")
        if meta.migrating_to:
            raise ValueError("already migrating")
        meta.migrating_to = dest
        meta.importing_from = meta.owner  # recorded on the slot; dest is migrating_to

    def migrate_key(self, key: str) -> OpResult:
        """Atomic teaching move: copy to dest, delete on source. Key exists on exactly one node."""
        slot = key_hash_slot(key)
        meta = self.slots[slot]
        if not meta.migrating_to:
            return OpResult(False, "not_migrating", key=key, slot=slot, node=meta.owner)
        src = self.nodes[meta.owner]
        dst = self.nodes[meta.migrating_to]
        if key not in src.data:
            return OpResult(False, "not_found", key=key, slot=slot, node=meta.owner)
        dst.data[key] = src.data[key]
        del src.data[key]
        return OpResult(True, "migrated", key=key, value=dst.data[key], slot=slot, node=dst.name)

    def keys_in_slot(self, slot: int, node: Optional[str] = None) -> list[str]:
        owner = node or self.slots[slot].owner
        return [k for k in self.nodes[owner].data if key_hash_slot(k) == slot]

    def migrate_slot_keys(self, slot: int) -> int:
        keys = list(self.keys_in_slot(slot))
        for k in keys:
            r = self.migrate_key(k)
            if not r.ok:
                raise RuntimeError(f"migrate failed for {k}: {r.status}")
        return len(keys)

    def finish_migrate(self, slot: int, check_empty: bool = True) -> None:
        meta = self.slots[slot]
        if not meta.migrating_to:
            raise ValueError("not migrating")
        if check_empty and self.keys_in_slot(slot, meta.owner):
            raise RuntimeError("source still holds keys in this slot")
        meta.owner = meta.migrating_to
        meta.migrating_to = None
        meta.importing_from = None

    def get(self, key: str, node: str, asking: bool = False) -> OpResult:
        exists = key in self.nodes[node].data if node in self.nodes else False
        redir = self._redirect_or_serve(key, node, asking, exists)
        if redir is not None:
            return redir
        val = self.nodes[node].data.get(key)
        if val is None:
            return OpResult(True, "not_found", key=key, node=node, slot=key_hash_slot(key))
        return OpResult(True, "ok", key=key, value=val, node=node, slot=key_hash_slot(key))

    def set(self, key: str, value: str, node: str, asking: bool = False) -> OpResult:
        exists = key in self.nodes[node].data if node in self.nodes else False
        redir = self._redirect_or_serve(key, node, asking, exists)
        if redir is not None:
            return redir
        self.nodes[node].data[key] = value
        return OpResult(True, "ok", key=key, value=value, node=node, slot=key_hash_slot(key))

    def mset(self, pairs: list[tuple[str, str]], node: str, asking: bool = False) -> OpResult:
        if not pairs:
            return OpResult(False, "empty", node=node)
        slots = {key_hash_slot(k) for k, _ in pairs}
        if len(slots) != 1:
            return OpResult(False, "crossslot", node=node, key=pairs[0][0])
        slot = next(iter(slots))
        meta = self.slots[slot]
        # During migration, keys may be split across source and dest.
        src_has = [k for k, _ in pairs if k in self.nodes[meta.owner].data]
        dest_name = meta.migrating_to
        dest_has = [k for k, _ in pairs if dest_name and k in self.nodes[dest_name].data] if dest_name else []
        missing = [k for k, _ in pairs if k not in src_has and k not in dest_has]
        if meta.migrating_to and (dest_has or missing) and (src_has or missing):
            # split or missing keys during resharding
            if not (src_has and not dest_has and not missing):
                return OpResult(False, "tryagain", node=node, slot=slot, key=pairs[0][0])
        # route as a single-slot command against `node`
        # serve only if all keys already exist locally, or new keys on the serving node under protocol
        first_key = pairs[0][0]
        exists_all_local = all(k in self.nodes[node].data for k, _ in pairs) if node in self.nodes else False
        # If all exist on this node, treat as existing; else as maybe-new
        exists_any = any(k in self.nodes[node].data for k, _ in pairs) if node in self.nodes else False
        redir = self._redirect_or_serve(first_key, node, asking, exists_all_local or (exists_any and not missing))
        # For brand-new multi-key on owner with no migration: serve
        if redir is not None:
            return redir
        for k, v in pairs:
            self.nodes[node].data[k] = v
        return OpResult(True, "ok", key=first_key, node=node, slot=slot)

    def node_sizes(self) -> dict[str, int]:
        return {n: node.size() for n, node in self.nodes.items()}

    def slot_counts(self) -> dict[str, int]:
        out = {n: 0 for n in self.nodes}
        for meta in self.slots:
            out[meta.owner] += 1
        return out


class ClusterClient:
    """Teaching client: caches slot → owner, follows MOVED and one-shot ASK."""

    def __init__(self, cluster: HashSlotCluster) -> None:
        self.cluster = cluster
        self.slot_map: dict[int, str] = {s: cluster.slots[s].owner for s in range(CLUSTER_SLOTS)}
        self.moved_count = 0
        self.ask_count = 0

    def refresh_map(self) -> None:
        self.slot_map = {s: self.cluster.slots[s].owner for s in range(CLUSTER_SLOTS)}

    def _node_for(self, key: str) -> str:
        return self.slot_map[key_hash_slot(key)]

    def get(self, key: str) -> OpResult:
        node = self._node_for(key)
        r = self.cluster.get(key, node)
        if r.status == "ask":
            self.ask_count += 1
            return self.cluster.get(key, r.redirect_to, asking=True)
        if r.status == "moved":
            self.moved_count += 1
            self.slot_map[key_hash_slot(key)] = r.redirect_to
            return self.cluster.get(key, r.redirect_to)
        return r

    def set(self, key: str, value: str) -> OpResult:
        node = self._node_for(key)
        r = self.cluster.set(key, value, node)
        if r.status == "ask":
            self.ask_count += 1
            return self.cluster.set(key, value, r.redirect_to, asking=True)
        if r.status == "moved":
            self.moved_count += 1
            self.slot_map[key_hash_slot(key)] = r.redirect_to
            return self.cluster.set(key, value, r.redirect_to)
        return r


class ShardingEngine:
    """Facade used by experiments: routers plus an optional slot cluster."""

    def __init__(self) -> None:
        pass
