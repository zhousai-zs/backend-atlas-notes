#!/usr/bin/env python3
"""Runnable experiments for practice110 (sharding, redistribution, hotspots)."""
from __future__ import annotations

from typing import Any

from engine import (
    CLUSTER_SLOTS,
    ClusterClient,
    ConsistentHashRouter,
    HashSlotCluster,
    ModuloRouter,
    RangeRouter,
    crc16,
    hash_tag_payload,
    imbalance,
    key_hash_slot,
    migration_stats,
)

OLD = "Weekly digest"
NEW = "Weekly digest (revised)"
HOT_KEY = "article:00042:title"
N_KEYS = 10000


def article_keys(n: int = N_KEYS) -> list[str]:
    return [f"article:{i:05d}:title" for i in range(n)]


def tagged_pairs(article_id: int) -> tuple[str, str]:
    tag = f"{{article:{article_id:05d}}}"
    return f"{tag}:title", f"{tag}:views"


def experiment_crc16_and_hashtags() -> dict[str, Any]:
    sample = "123456789"
    crc = crc16(sample)
    examples = {
        "{user1000}.following": key_hash_slot("{user1000}.following"),
        "{user1000}.followers": key_hash_slot("{user1000}.followers"),
        "foo{}{bar}": key_hash_slot("foo{}{bar}"),
        "foo{{bar}}zap": key_hash_slot("foo{{bar}}zap"),
        "foo{bar}{zap}": key_hash_slot("foo{bar}{zap}"),
        "{}whole": key_hash_slot("{}whole"),
        "article:00042:title": key_hash_slot("article:00042:title"),
        "{article:00042}:title": key_hash_slot("{article:00042}:title"),
        "{article:00042}:views": key_hash_slot("{article:00042}:views"),
    }
    payloads = {k: hash_tag_payload(k) for k in examples}
    following = examples["{user1000}.following"]
    followers = examples["{user1000}.followers"]
    tagged_title = examples["{article:00042}:title"]
    tagged_views = examples["{article:00042}:views"]
    untagged = examples["article:00042:title"]
    return {
        "setup": "CRC16 XMODEM and Redis Cluster hash-tag rule, no server",
        "crc16_123456789": crc,
        "crc16_123456789_hex": f"0x{crc:04X}",
        "matches_spec_31C3": crc == 0x31C3,
        "hash_tag_payloads": payloads,
        "slots": examples,
        "same_slot_user1000": following == followers,
        "same_slot_article_42_tagged": tagged_title == tagged_views,
        "untagged_title_slot_differs_from_tagged": untagged != tagged_title,
        "foo_empty_tag_hashes_whole_key": payloads["foo{}{bar}"] == "foo{}{bar}",
        "foo_double_brace_payload": payloads["foo{{bar}}zap"],
        "foo_bar_zap_payload": payloads["foo{bar}{zap}"],
        "cluster_slots": CLUSTER_SLOTS,
        "formula": "HASH_SLOT = CRC16(key_or_tag) & 0x3FFF",
    }


def experiment_modulo_vs_consistent() -> dict[str, Any]:
    keys = article_keys()
    nodes3 = ["n1", "n2", "n3"]
    # add node
    mod = ModuloRouter(nodes3)
    before_mod = mod.place(keys)
    mod.add_node("n4")
    after_mod = mod.place(keys)
    add_mod = migration_stats(before_mod, after_mod)

    ch = ConsistentHashRouter(nodes3, vnodes=150)
    before_ch = ch.place(keys)
    ch.add_node("n4")
    after_ch = ch.place(keys)
    add_ch = migration_stats(before_ch, after_ch)

    # only the new node should receive moved keys in consistent hashing
    ch_dests = set(add_ch["moved_to"].keys())
    # remove node n4 afterwards? also measure 4->3 remove n4
    before_rm = ch.place(keys)
    ch.remove_node("n4")
    after_rm = ch.place(keys)
    rm_ch = migration_stats(before_rm, after_rm)

    mod4 = ModuloRouter(["n1", "n2", "n3", "n4"])
    before_mod_rm = mod4.place(keys)
    mod4.remove_node("n4")
    after_mod_rm = mod4.place(keys)
    rm_mod = migration_stats(before_mod_rm, after_mod_rm)

    return {
        "setup": "10000 article titles, 3 nodes -> add n4, then remove n4",
        "key_count": len(keys),
        "add_node": {
            "modulo": add_mod,
            "consistent_hash_vnodes_150": add_ch,
            "consistent_hash_moved_only_to_new_node": ch_dests == {"n4"},
            "modulo_expected_migrate_about": 0.75,
            "consistent_expected_migrate_about": 0.25,
        },
        "remove_node": {
            "modulo": rm_mod,
            "consistent_hash_vnodes_150": rm_ch,
        },
        "contrast": {
            "add_modulo_moved": add_mod["moved"],
            "add_consistent_moved": add_ch["moved"],
            "add_modulo_ratio": add_mod["migration_ratio"],
            "add_consistent_ratio": add_ch["migration_ratio"],
            "remove_modulo_moved": rm_mod["moved"],
            "remove_consistent_moved": rm_ch["moved"],
            "remove_modulo_ratio": rm_mod["migration_ratio"],
            "remove_consistent_ratio": rm_ch["migration_ratio"],
        },
    }


def experiment_vnode_balance() -> dict[str, Any]:
    keys = article_keys()
    nodes = ["n1", "n2", "n3"]
    one = ConsistentHashRouter(nodes, vnodes=1)
    many = ConsistentHashRouter(nodes, vnodes=150)
    imb_one = imbalance(one.counts(keys))
    imb_many = imbalance(many.counts(keys))
    return {
        "setup": "10000 keys, 3 nodes, 1 virtual node vs 150 virtual nodes",
        "vnodes_1": imb_one,
        "vnodes_150": imb_many,
        "max_min_ratio_improved": imb_many["max_min_ratio"] < imb_one["max_min_ratio"],
        "vnodes_do_not_move_data_by_themselves": True,
    }


def experiment_hotspot() -> dict[str, Any]:
    """Uniform keys are not uniform traffic. One viral title dominates reads."""
    keys = article_keys()
    router = ConsistentHashRouter(["n1", "n2", "n3", "n4"], vnodes=150)
    key_counts = router.counts(keys)
    key_imb = imbalance(key_counts)
    hot_node = router.route(HOT_KEY)
    n_reads = 10000
    hot_reads = 9000
    cold_reads = n_reads - hot_reads
    # 9000 reads hit HOT_KEY; 1000 reads walk the other keys uniformly
    access = {n: 0 for n in router.nodes}
    access[hot_node] += hot_reads
    for i in range(cold_reads):
        k = keys[i % len(keys)]
        if k == HOT_KEY:
            k = keys[(i + 1) % len(keys)]
        access[router.route(k)] += 1
    acc_imb = imbalance(access)
    return {
        "setup": "10000 evenly placed titles; 9000/10000 reads hit article:00042:title (Weekly digest)",
        "hot_key": HOT_KEY,
        "hot_value": OLD,
        "hot_node": hot_node,
        "key_distribution": key_imb,
        "access_distribution": acc_imb,
        "hot_node_key_share": key_imb["shares"][hot_node],
        "hot_node_access_share": acc_imb["shares"][hot_node],
        "uniform_keys_are_not_uniform_access": acc_imb["shares"][hot_node] > 0.8
        and key_imb["max_share"] < 0.4,
        "n_reads": n_reads,
        "hot_reads": hot_reads,
    }


def experiment_hotspot_split() -> dict[str, Any]:
    """Split the hot title into 8 partition keys routed by user id."""
    router = ConsistentHashRouter(["n1", "n2", "n3", "n4"], vnodes=150)
    n_reads = 10000
    hot_reads = 9000
    parts = 8
    part_keys = [f"{HOT_KEY}#{i}" for i in range(parts)]
    part_nodes = [router.route(k) for k in part_keys]
    access = {n: 0 for n in router.nodes}
    for i in range(hot_reads):
        # teaching split: user id i selects a partition
        k = part_keys[i % parts]
        access[router.route(k)] += 1
    # remaining 1000 cold reads unused here; report only hot traffic after split
    acc_imb = imbalance(access)
    unique_nodes = sorted(set(part_nodes))
    return {
        "setup": "split article:00042:title into 8 partitions article:00042:title#0..#7, 9000 hot reads by user id",
        "partition_keys": part_keys,
        "partition_nodes": part_nodes,
        "nodes_holding_partitions": unique_nodes,
        "node_count_after_split": len(unique_nodes),
        "access_distribution": acc_imb,
        "max_access_share_after_split": acc_imb["max_share"],
        "spread_across_more_than_one_node": len(unique_nodes) > 1,
        "max_share_below_half": acc_imb["max_share"] < 0.5,
        "note": "This is a teaching split of a hot cache key, not a Redis Cluster command and not replica promotion.",
    }


def experiment_naive_vs_protocol_migration() -> dict[str, Any]:
    """Flip slot ownership without moving keys vs MIGRATING/IMPORTING + ASK."""
    # 3-node official-looking ranges, then move a set of slots to n4
    ranges = [("n1", 0, 5460), ("n2", 5461, 10922), ("n3", 10923, 16383)]
    keys = article_keys(2000)
    # --- naive: write keys, add n4, reassign slots in the client map, do not move data
    naive = HashSlotCluster(["n1", "n2", "n3"], slot_ranges=ranges)
    naive.add_empty_node("n4")
    for k in keys:
        owner = naive.owner_of_key(k)
        naive.set(k, OLD, owner)
    # pick slots currently on n1 that we will "give" to n4 — first 200 of n1's slots that have keys, or just slots 0-199
    naive_slots = list(range(0, 200))
    keys_in_naive_slots = [k for k in keys if key_hash_slot(k) in set(naive_slots)]
    # flip ownership without moving
    for s in naive_slots:
        naive.slots[s].owner = "n4"
    naive_client = ClusterClient(naive)  # map now points at n4 for those slots
    naive_hits = 0
    naive_missing = 0
    naive_values = []
    for k in keys_in_naive_slots:
        r = naive_client.get(k)
        if r.status == "ok" and r.value == OLD:
            naive_hits += 1
        else:
            naive_missing += 1
            naive_values.append({"key": k, "status": r.status, "value": r.value, "node": r.node})
    # a write of the revised title goes to n4, leaving the old value on n1
    split_key = keys_in_naive_slots[0] if keys_in_naive_slots else None
    split_write = None
    old_on_n1 = None
    new_on_n4 = None
    if split_key:
        split_write = naive_client.set(split_key, NEW).as_dict()
        old_on_n1 = naive.nodes["n1"].data.get(split_key)
        new_on_n4 = naive.nodes["n4"].data.get(split_key)

    # --- protocol: same setup, start_migrate / migrate_key / ASK / finish
    proto = HashSlotCluster(["n1", "n2", "n3"], slot_ranges=ranges)
    proto.add_empty_node("n4")
    for k in keys:
        proto.set(k, OLD, proto.owner_of_key(k))
    proto_slots = list(range(0, 200))
    keys_in_proto_slots = [k for k in keys if key_hash_slot(k) in set(proto_slots)]
    for s in proto_slots:
        proto.start_migrate(s, "n4")
    client = ClusterClient(proto)
    # mid-migration: keys still on n1 should be served by n1 (ok),
    # a brand-new key in those slots should ASK n4
    mid_existing = [client.get(k).as_dict() for k in keys_in_proto_slots]
    mid_existing_ok = sum(1 for r in mid_existing if r["status"] == "ok" and r["value"] == OLD)
    mid_existing_nodes = sorted({r["node"] for r in mid_existing})
    new_key = "article:mig-new:title"
    # ensure new_key hashes into a migrating slot; if not, search a key that does
    if key_hash_slot(new_key) not in set(proto_slots):
        for i in range(100000):
            cand = f"article:new:{i}:title"
            if key_hash_slot(cand) in set(proto_slots):
                new_key = cand
                break
    set_new = client.set(new_key, NEW)
    # existing keys still on source; new key should have been asked to n4
    mid_asks = client.ask_count
    # migrate all keys in those slots, then finish
    moved_count = 0
    for s in proto_slots:
        moved_count += proto.migrate_slot_keys(s)
        proto.finish_migrate(s)
    # after finish, map may still point at n1 until MOVED
    stale_client = client  # slot_map still old unless MOVED happened for new_key's slot
    after = [stale_client.get(k).as_dict() for k in keys_in_proto_slots]
    after_ok = sum(1 for r in after if r["status"] == "ok" and r["value"] == OLD)
    after_nodes = sorted({r["node"] for r in after})
    after_new = stale_client.get(new_key)
    return {
        "setup": "2000 titles on 3-node slot ranges; move slots 0-199 to n4",
        "keys_in_moved_slots": len(keys_in_naive_slots),
        "slots_moved": len(naive_slots),
        "naive": {
            "reads_ok": naive_hits,
            "reads_missing": naive_missing,
            "missing_ratio": (naive_missing / len(keys_in_naive_slots)) if keys_in_naive_slots else 0.0,
            "split_key": split_key,
            "split_write": split_write,
            "old_value_still_on_n1": old_on_n1,
            "new_value_on_n4": new_on_n4,
            "split_brain": old_on_n1 == OLD and new_on_n4 == NEW,
        },
        "protocol": {
            "mid_migration_existing_ok": mid_existing_ok,
            "mid_migration_existing_total": len(keys_in_proto_slots),
            "mid_migration_served_by": mid_existing_nodes,
            "new_key": new_key,
            "new_key_slot": key_hash_slot(new_key),
            "new_key_set": set_new.as_dict(),
            "ask_count_after_new_write": mid_asks,
            "keys_migrated": moved_count,
            "after_finish_ok": after_ok,
            "after_finish_total": len(keys_in_proto_slots),
            "after_finish_served_by": after_nodes,
            "after_new_key": after_new.as_dict(),
            "moved_count": stale_client.moved_count,
            "ask_count": stale_client.ask_count,
        },
        "rw_policy": {
            "during_migration": "source serves existing keys; missing keys get ASK to dest; dest serves only with ASKING; new keys are created on dest",
            "after_migration": "SETSLOT NODE dest; later queries get MOVED and the client updates its slot map",
            "naive_policy": "client map flipped first, data not moved: reads miss, writes create a second copy",
        },
    }


def experiment_consistent_hash_is_not_consistency() -> dict[str, Any]:
    """Consistent hashing only remaps keys; it does not move values or keep them consistent."""
    keys = article_keys(400)
    router = ConsistentHashRouter(["n1", "n2", "n3"], vnodes=150)
    store = {n: {} for n in router.nodes}
    for k in keys:
        store[router.route(k)][k] = OLD
    before = router.place(keys)
    router.add_node("n4")
    store["n4"] = {}
    after = router.place(keys)
    stats = migration_stats(before, after)
    # naive: read from the new ring without moving values
    missing = []
    found = 0
    for k in keys:
        node = after[k]
        if k in store[node]:
            found += 1
        else:
            missing.append(k)
    # write NEW on the new home of a moved key, old copy remains
    moved_keys = [k for k in keys if before[k] != after[k]]
    sample = moved_keys[0]
    old_node, new_node = before[sample], after[sample]
    store[new_node][sample] = NEW
    return {
        "setup": "400 titles on a 3-node consistent-hash ring; add n4 and read the new ring without migrating values",
        "migration": stats,
        "naive_reads_found": found,
        "naive_reads_missing": len(missing),
        "all_moved_keys_missing_on_new_home": len(missing) == stats["moved"],
        "sample_key": sample,
        "sample_old_node": old_node,
        "sample_new_node": new_node,
        "sample_old_copy": store[old_node].get(sample),
        "sample_new_copy": store[new_node].get(sample),
        "two_copies_diverge": store[old_node].get(sample) == OLD and store[new_node].get(sample) == NEW,
        "pitfall": "Consistent hashing limits how many keys remap; it does not move data or resolve which copy is current.",
    }


def experiment_range_vs_hash_scan() -> dict[str, Any]:
    keys_ids = list(range(10000))
    ranges = [("n1", 0, 2500), ("n2", 2500, 5000), ("n3", 5000, 7500), ("n4", 7500, 10000)]
    rr = RangeRouter(ranges)
    ch = ConsistentHashRouter(["n1", "n2", "n3", "n4"], vnodes=150)
    scan_start, scan_end = 2000, 2199  # 200 consecutive article ids
    range_nodes = rr.nodes_for_scan(scan_start, scan_end)
    hash_nodes: dict[str, int] = {n: 0 for n in ch.nodes}
    for i in range(scan_start, scan_end + 1):
        hash_nodes[ch.route(f"article:{i:05d}:title")] += 1
    hash_hit = [n for n, c in hash_nodes.items() if c]
    # hot tail: 80% of 5000 new writes land on ids 9800-9999
    n_writes = 5000
    hot_ids = list(range(9800, 10000))
    tail_writes = 4000
    other_writes = n_writes - tail_writes
    range_write = {n: 0 for n, _, _ in ranges}
    hash_write = {n: 0 for n in ch.nodes}
    for i in range(tail_writes):
        aid = hot_ids[i % len(hot_ids)]
        range_write[rr.route_id(aid)] += 1
        hash_write[ch.route(f"article:{aid:05d}:title")] += 1
    for i in range(other_writes):
        aid = i % 9800
        range_write[rr.route_id(aid)] += 1
        hash_write[ch.route(f"article:{aid:05d}:title")] += 1
    return {
        "setup": "10000 article ids, 4 shards; scan 2000-2199; 4000/5000 writes on ids 9800-9999",
        "scan": {
            "start": scan_start,
            "end": scan_end,
            "count": scan_end - scan_start + 1,
            "range_nodes": range_nodes,
            "range_shard_count": len(range_nodes),
            "hash_nodes": hash_hit,
            "hash_shard_count": len(hash_hit),
            "hash_counts": hash_nodes,
        },
        "hot_tail_writes": {
            "n_writes": n_writes,
            "tail_writes": tail_writes,
            "range": imbalance(range_write),
            "hash": imbalance(hash_write),
            "range_hot_node": max(range_write, key=range_write.get),
            "range_hot_share": imbalance(range_write)["max_share"],
            "hash_max_share": imbalance(hash_write)["max_share"],
        },
        "range_scan_uses_fewer_shards": len(range_nodes) < len(hash_hit),
        "hash_spreads_hot_tail": imbalance(hash_write)["max_share"] < imbalance(range_write)["max_share"],
    }


def experiment_hashtag_and_tryagain() -> dict[str, Any]:
    ranges = [("n1", 0, 5460), ("n2", 5461, 10922), ("n3", 10923, 16383)]
    cluster = HashSlotCluster(["n1", "n2", "n3"], slot_ranges=ranges)
    title, views = tagged_pairs(1)
    un_title, un_views = "article:00001:title", "article:00001:views"
    # untagged mset: likely CROSSSLOT (almost surely different slots)
    owner_guess = cluster.owner_of_key(un_title)
    untagged = cluster.mset([(un_title, OLD), (un_views, "0")], owner_guess)
    # if they happened to collide, record that
    tagged_owner = cluster.owner_of_key(title)
    tagged = cluster.mset([(title, OLD), (views, "0")], tagged_owner)
    # start migrating the tagged slot, move only the title, then mset both
    slot = key_hash_slot(title)
    cluster.add_empty_node("n4")
    cluster.start_migrate(slot, "n4")
    moved = cluster.migrate_key(title)
    # views still on source, title on dest
    split_mset = cluster.mset([(title, NEW), (views, "1")], tagged_owner)
    # after moving views too, same-slot mset on dest with ASKING works? 
    # still migrating, both keys now on dest — mset all on dest should be ok (all exist on dest)
    moved_views = cluster.migrate_key(views)
    both_on_dest = cluster.mset([(title, NEW), (views, "2")], "n4", asking=True)
    cluster.migrate_slot_keys(slot)
    cluster.finish_migrate(slot)
    return {
        "setup": "MSET title+views with and without hash tags; mid-slot migration split",
        "untagged_keys": [un_title, un_views],
        "untagged_slots": [key_hash_slot(un_title), key_hash_slot(un_views)],
        "untagged_mset": untagged.as_dict(),
        "untagged_crossslot": untagged.status == "crossslot",
        "tagged_keys": [title, views],
        "tagged_slots": [key_hash_slot(title), key_hash_slot(views)],
        "tagged_mset": tagged.as_dict(),
        "tagged_ok": tagged.ok and tagged.status == "ok",
        "split_after_one_key_moved": {
            "migrate_title": moved.as_dict(),
            "mset": split_mset.as_dict(),
            "tryagain": split_mset.status == "tryagain",
        },
        "after_both_moved": {
            "migrate_views": moved_views.as_dict(),
            "mset_on_dest_asking": both_on_dest.as_dict(),
        },
        "final_owner": cluster.owner_of_slot(slot),
        "final_slot": slot,
    }


def experiment_slot_add_node_migration_ratio() -> dict[str, Any]:
    """Redis-style: add n4 and move 1/4 of slots, count key moves (10000 titles)."""
    ranges = [("n1", 0, 5460), ("n2", 5461, 10922), ("n3", 10923, 16383)]
    cluster = HashSlotCluster(["n1", "n2", "n3"], slot_ranges=ranges)
    cluster.add_empty_node("n4")
    keys = article_keys()
    for k in keys:
        cluster.set(k, OLD, cluster.owner_of_key(k))
    before_sizes = cluster.node_sizes()
    before_slots = cluster.slot_counts()
    # move every 4th slot to n4 (~1/4 of slots). Group keys first so empty
    # slots do not scan the whole node dictionary.
    from collections import defaultdict

    moved_slots = [s for s in range(CLUSTER_SLOTS) if s % 4 == 0]
    moved_set = set(moved_slots)
    by_slot: dict[int, list[str]] = defaultdict(list)
    for k in keys:
        s = key_hash_slot(k)
        if s in moved_set:
            by_slot[s].append(k)
    keys_moved = 0
    for s in moved_slots:
        if cluster.owner_of_slot(s) == "n4":
            continue
        cluster.start_migrate(s, "n4")
        for k in by_slot[s]:
            r = cluster.migrate_key(k)
            if not r.ok:
                raise RuntimeError(f"migrate failed for {k}: {r.status}")
            keys_moved += 1
        cluster.finish_migrate(s, check_empty=False)
    after_sizes = cluster.node_sizes()
    after_slots = cluster.slot_counts()
    return {
        "setup": "10000 titles, 3-node slot ranges; move every 4th slot to n4",
        "before_sizes": before_sizes,
        "after_sizes": after_sizes,
        "before_slots": before_slots,
        "after_slots": after_slots,
        "slots_moved": len(moved_slots),
        "keys_moved": keys_moved,
        "key_migration_ratio": keys_moved / len(keys),
        "expected_about": 0.25,
    }


def run_all_experiments() -> dict[str, Any]:
    return {
        "crc16_and_hashtags": experiment_crc16_and_hashtags(),
        "modulo_vs_consistent": experiment_modulo_vs_consistent(),
        "vnode_balance": experiment_vnode_balance(),
        "hotspot": experiment_hotspot(),
        "hotspot_split": experiment_hotspot_split(),
        "naive_vs_protocol_migration": experiment_naive_vs_protocol_migration(),
        "consistent_hash_is_not_consistency": experiment_consistent_hash_is_not_consistency(),
        "range_vs_hash_scan": experiment_range_vs_hash_scan(),
        "hashtag_and_tryagain": experiment_hashtag_and_tryagain(),
        "slot_add_node_migration_ratio": experiment_slot_add_node_migration_ratio(),
    }


if __name__ == "__main__":
    import json
    import os

    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("wrote", out)
