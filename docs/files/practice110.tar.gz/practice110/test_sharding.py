#!/usr/bin/env python3
"""Acceptance checks for practice110 (sharding, redistribution, hotspots)."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    crc = data["crc16_and_hashtags"]
    _assert(crc["matches_spec_31C3"] is True, "CRC16('123456789') must be 0x31C3")
    _assert(crc["crc16_123456789"] == 0x31C3, "numeric CRC")
    _assert(crc["same_slot_user1000"] is True, "{user1000} keys share a slot")
    _assert(crc["same_slot_article_42_tagged"] is True, "tagged title and views share a slot")
    _assert(crc["foo_empty_tag_hashes_whole_key"] is True, "foo{}{bar} hashes the whole key")
    _assert(crc["foo_double_brace_payload"] == "{bar", "foo{{bar}}zap payload")
    _assert(crc["foo_bar_zap_payload"] == "bar", "foo{bar}{zap} payload")
    _assert(crc["cluster_slots"] == 16384, "16384 slots")

    mv = data["modulo_vs_consistent"]
    add = mv["add_node"]
    _assert(add["consistent_hash_moved_only_to_new_node"] is True, "CH add moves only to n4")
    _assert(add["modulo"]["moved"] > add["consistent_hash_vnodes_150"]["moved"] * 2, "modulo moves far more than CH")
    _assert(0.70 <= add["modulo"]["migration_ratio"] <= 0.80, "modulo 3->4 ~75%")
    _assert(0.15 <= add["consistent_hash_vnodes_150"]["migration_ratio"] <= 0.35, "CH 3->4 ~25%")
    _assert(0.70 <= mv["remove_node"]["modulo"]["migration_ratio"] <= 0.80, "modulo 4->3 ~75%")
    _assert(0.15 <= mv["remove_node"]["consistent_hash_vnodes_150"]["migration_ratio"] <= 0.35, "CH 4->3 ~25%")

    vn = data["vnode_balance"]
    _assert(vn["max_min_ratio_improved"] is True, "150 vnodes more even than 1")
    _assert(vn["vnodes_150"]["max_min_ratio"] < 1.3, "150 vnodes should be close to even")
    _assert(vn["vnodes_1"]["max_min_ratio"] > vn["vnodes_150"]["max_min_ratio"], "1 vnode is worse")

    hot = data["hotspot"]
    _assert(hot["uniform_keys_are_not_uniform_access"] is True, "even keys, uneven access")
    _assert(hot["hot_node_access_share"] >= 0.85, "hot node takes most reads")
    _assert(hot["hot_node_key_share"] < 0.4, "hot node is not holding most keys")
    _assert(hot["key_distribution"]["max_share"] < 0.4, "keys themselves stay balanced")

    split = data["hotspot_split"]
    _assert(split["spread_across_more_than_one_node"] is True, "partitions land on >1 node")
    _assert(split["max_share_below_half"] is True, "after split no node has >=50% of hot reads")
    _assert(split["max_access_share_after_split"] < hot["hot_node_access_share"] / 2, "split cuts the hot share")

    mig = data["naive_vs_protocol_migration"]
    _assert(mig["keys_in_moved_slots"] > 0, "some keys sit in slots 0-199")
    _assert(mig["naive"]["reads_missing"] == mig["keys_in_moved_slots"], "naive flip misses every moved key")
    _assert(mig["naive"]["reads_ok"] == 0, "naive has no hits")
    _assert(mig["naive"]["split_brain"] is True, "naive write leaves two copies")
    proto = mig["protocol"]
    _assert(proto["mid_migration_existing_ok"] == proto["mid_migration_existing_total"], "existing keys still readable")
    _assert(proto["new_key_set"]["ok"] is True, "new key created on dest via ASK")
    _assert(proto["new_key_set"]["node"] == "n4", "new key lives on n4")
    _assert(proto["ask_count_after_new_write"] >= 1, "ASK used for the new key")
    _assert(proto["after_finish_ok"] == proto["after_finish_total"], "after finish every old key is readable")
    _assert(proto["after_finish_served_by"] == ["n4"], "finished keys served by n4")
    _assert(proto["after_new_key"]["ok"] is True and proto["after_new_key"]["value"] == "Weekly digest (revised)", "new key survives")

    pit = data["consistent_hash_is_not_consistency"]
    _assert(pit["all_moved_keys_missing_on_new_home"] is True, "CH remaps without moving values")
    _assert(pit["naive_reads_missing"] == pit["migration"]["moved"], "missing count equals remapped keys")
    _assert(pit["two_copies_diverge"] is True, "old and new copies can diverge")

    scan = data["range_vs_hash_scan"]
    _assert(scan["range_scan_uses_fewer_shards"] is True, "range scan hits fewer shards")
    _assert(scan["scan"]["range_shard_count"] == 1, "2000-2199 sits in one range")
    _assert(scan["scan"]["hash_shard_count"] >= 3, "hash scan fans out")
    _assert(scan["hash_spreads_hot_tail"] is True, "hash spreads recent-id writes")
    _assert(scan["hot_tail_writes"]["range_hot_share"] >= 0.75, "range tail is a hotspot")

    tag = data["hashtag_and_tryagain"]
    _assert(tag["untagged_crossslot"] is True, "untagged title+views is CROSSSLOT")
    _assert(tag["tagged_ok"] is True, "hash-tagged title+views is one slot")
    _assert(tag["tagged_slots"][0] == tag["tagged_slots"][1], "same slot")
    _assert(tag["split_after_one_key_moved"]["tryagain"] is True, "split keys during resharding -> TRYAGAIN")
    _assert(tag["after_both_moved"]["mset_on_dest_asking"]["ok"] is True, "after both keys moved, ASKING MSET works")
    _assert(tag["final_owner"] == "n4", "slot finishes on n4")

    sl = data["slot_add_node_migration_ratio"]
    _assert(0.20 <= sl["key_migration_ratio"] <= 0.30, "moving 1/4 of slots moves ~1/4 of keys")
    _assert(sl["after_slots"]["n4"] == sl["slots_moved"], "n4 owns the moved slots")
    _assert(sum(sl["after_sizes"].values()) == 10000, "no keys lost")
    _assert(sl["after_sizes"]["n4"] == sl["keys_moved"], "n4 holds exactly the moved keys")

    print("ALL_CHECKS_PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"CHECK_FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
