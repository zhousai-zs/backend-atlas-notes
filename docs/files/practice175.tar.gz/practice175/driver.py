#!/usr/bin/env python3
"""Three context strategies on a 100-line incident log. No live model."""

from __future__ import annotations

import json
from pathlib import Path

from context import (
    Runtime, TaskCard, load_lines, ntok, render, refetch, scrub,
    strategy_hard_truncate, strategy_keep_all, strategy_pointers,
)

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "logs/incident.log"
lines = load_lines(LOG)
assert len(lines) == 100
assert "OOM_KILL" in lines[72]
assert "sk-live-example-not-used" in lines[40]

runtime = Runtime(log_path=LOG)
card = TaskCard(
    goal="Locate the fatal event for kv-node-7 and quote the supporting log line.",
    forbidden=["do not rotate production keys", "do not call the write API", "do not paste credentials into the prompt"],
    todos=["find FATAL line", "confirm memory evidence", "write diagnosis"],
    failed_attempts=["first pass looked only at heartbeat lines and missed the FATAL"],
)

keep = strategy_keep_all(lines, str(LOG), card)
hard = strategy_hard_truncate(lines, str(LOG), card, budget_tokens=400)
ptr = strategy_pointers(lines, str(LOG), card, budget_tokens=400)

# After any compression, the card still carries goal, forbidden, todos, failed attempts.
for name, c in ("keep", keep), ("hard", hard), ("ptr", ptr):
    assert c.goal == card.goal, name
    assert c.forbidden == card.forbidden, name
    assert c.todos == card.todos, name
    assert c.failed_attempts == card.failed_attempts, name

# Hard truncate must mark incompleteness, not look finished.
assert any(e.get("truncated") for e in hard.evidence)
assert any(e.get("complete") is False for e in hard.evidence)
assert "not a complete result" in hard.evidence[-1]["text"]

# Pointers can re-fetch the compressed evidence by path + line.
oom = [e for e in ptr.evidence if "OOM_KILL" in e["text"]]
assert oom and oom[0]["line"] == 73
refetched = refetch(Path(oom[0]["path"]), oom[0]["line"])
assert refetched == lines[72] and "OOM_KILL" in refetched

# Credentials never enter model-visible text; runtime token is also excluded.
for name, c in ("keep", keep), ("hard", hard), ("ptr", ptr):
    visible = render(c)
    assert "sk-live-example-not-used" not in visible, name
    assert runtime.api_token not in visible, name
    assert "sk-runtime-must-not-enter-model" not in visible
    if "sk-" in visible:
        raise AssertionError(name + " leaked a key-shaped secret")
# keep-all includes the redacted form of line 41
assert any("[REDACTED]" in e["text"] for e in keep.evidence)

# Cost comparison
costs = {
    "keep_all": {"tokens": ntok(render(keep)), "lines_sent": len(keep.evidence), "found_fault": any("OOM_KILL" in e["text"] for e in keep.evidence)},
    "hard_truncate": {"tokens": ntok(render(hard)), "lines_sent": len(hard.evidence), "found_fault": any("OOM_KILL" in e["text"] for e in hard.evidence), "marked_truncated": True},
    "pointers": {"tokens": ntok(render(ptr)), "lines_sent": len(ptr.evidence), "found_fault": True, "refetch_ok": True},
}
assert costs["pointers"]["tokens"] < costs["keep_all"]["tokens"]
# hard truncate with 400 tokens will likely miss line 73 (near the end)
# that's the point: report completion honestly
assert costs["hard_truncate"]["found_fault"] is False or costs["hard_truncate"]["found_fault"] is True  # either is data
# we assert the task can continue with pointers
assert costs["pointers"]["found_fault"] is True

# A follow-up "model" step using only the pointer context can still name line 73.
followup_input = render(ptr)
assert "73" in followup_input or any(e["line"]==73 for e in ptr.evidence)

results = {
    "lesson": 175,
    "id": "l-context",
    "is_live_model": False,
    "n_log_lines": 100,
    "tokenizer": "tiktoken 0.14.0 cl100k_base",
    "runtime_token_entered_model_input": False,
    "log_secret_entered_model_input": False,
    "card_preserved_after_compress": True,
    "refetch": {"path": oom[0]["path"], "line": 73, "text": refetched},
    "hard_truncate_marked_incomplete": True,
    "costs": costs,
    "verified_on_this_machine": [
        "goal_forbidden_todos_failures_survive_compression",
        "evidence_reloaded_by_path_and_line",
        "over_budget_output_has_truncation_marker",
        "token_costs_compared_and_secrets_scrubbed",
    ],
    "not_verified_on_this_machine": ["live_model_decision_quality_after_compression"],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(costs, indent=2))
print("ALL_CHECKS_PASSED")
