#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["n_log_lines"]==100 and r["card_preserved_after_compress"]
assert r["refetch"]["line"]==73 and "OOM_KILL" in r["refetch"]["text"]
assert r["hard_truncate_marked_incomplete"]
assert r["runtime_token_entered_model_input"] is False
assert r["costs"]["pointers"]["tokens"] < r["costs"]["keep_all"]["tokens"]
print("POSTCHECK_OK")
PY
