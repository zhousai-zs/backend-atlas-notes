# 实践 175：上下文工程与压缩

在解压后的 `practice175/` 目录中运行：

```bash
export PYTHON=/path/to/python3   # 需要 cmvenv（tiktoken 0.14.0）
bash test.sh
```

脚本把完整输出写入 `run.log`，并生成 `results.json`。最后应出现 `ALL_CHECKS_PASSED` 与 `POSTCHECK_OK`。

用确定性检索替代直播模型。is_live_model=false。凭证不得进入模型输入。

不要把本目录里的教学密钥、令牌指纹或模拟凭证用于任何真实服务。
