"""Model-visible context vs local runtime context. Credentials never go to the model."""

from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from pathlib import Path

import tiktoken

ENC = tiktoken.get_encoding("cl100k_base")
SECRET_RE = re.compile(r"(sk-[A-Za-z0-9-]+|tok_[A-Za-z0-9-]+|password=\\S+)")


def ntok(s: str) -> int:
    return len(ENC.encode(s))


def scrub(s: str) -> str:
    return SECRET_RE.sub("[REDACTED]", s)


@dataclass
class Runtime:
    """Local runtime context: not serialized to the model."""
    db_handle: str = "sqlite://internal"
    api_token: str = "sk-runtime-must-not-enter-model"
    log_path: Path = Path("logs/incident.log")


@dataclass
class TaskCard:
    goal: str
    forbidden: list[str]
    todos: list[str]
    failed_attempts: list[str]
    evidence: list[dict] = field(default_factory=list)  # {path, line, text}


def render(card: TaskCard) -> str:
    ev = "\n".join(f"{e['path']}:{e['line']}: {e['text']}" for e in card.evidence)
    return (
        f"GOAL: {card.goal}\n"
        f"FORBIDDEN: {'; '.join(card.forbidden)}\n"
        f"TODOS: {'; '.join(card.todos)}\n"
        f"FAILED: {'; '.join(card.failed_attempts) or '(none)'}\n"
        f"EVIDENCE:\n{ev or '(none)'}\n"
    )


def load_lines(path: Path) -> list[str]:
    return path.read_text().splitlines()


def strategy_keep_all(lines: list[str], path: str, card: TaskCard) -> TaskCard:
    out = TaskCard(card.goal, list(card.forbidden), list(card.todos), list(card.failed_attempts), [])
    for i, line in enumerate(lines, 1):
        out.evidence.append({"path": path, "line": i, "text": scrub(line)})
    return out


def strategy_hard_truncate(lines: list[str], path: str, card: TaskCard, budget_tokens: int) -> TaskCard:
    out = TaskCard(card.goal, list(card.forbidden), list(card.todos), list(card.failed_attempts), [])
    used = ntok(render(out))
    for i, line in enumerate(lines, 1):
        item = {"path": path, "line": i, "text": scrub(line)}
        add = ntok(f"{path}:{i}: {item['text']}\n")
        if used + add > budget_tokens:
            out.evidence.append({
                "path": path,
                "line": i,
                "text": "[truncated: output exceeded token budget, not a complete result]",
                "truncated": True,
                "complete": False,
            })
            break
        out.evidence.append(item)
        used += add
    return out


def strategy_pointers(lines: list[str], path: str, card: TaskCard, budget_tokens: int) -> TaskCard:
    """Keep goal/constraints/failures; only error-like lines + pointers go to the model."""
    out = TaskCard(card.goal, list(card.forbidden), list(card.todos), list(card.failed_attempts), [])
    interesting = []
    for i, line in enumerate(lines, 1):
        if any(k in line for k in ("FATAL", "OOM", "error", "cgroup")) and "heartbeat" not in line:
            interesting.append((i, line))
    used = ntok(render(out))
    for i, line in interesting:
        item = {"path": path, "line": i, "text": scrub(line), "pointer": f"{path}:{i}"}
        add = ntok(f"{item['pointer']}: {item['text']}\n")
        if used + add > budget_tokens:
            item = {"path": path, "line": i, "text": "[truncated: output exceeded token budget, not a complete result]", "truncated": True, "complete": False, "pointer": f"{path}:{i}"}
            out.evidence.append(item)
            break
        out.evidence.append(item)
        used += add
    return out


def refetch(path: Path, line: int) -> str:
    lines = load_lines(path)
    return lines[line - 1]
