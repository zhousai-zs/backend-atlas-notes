#!/usr/bin/env python3
"""Run the lesson 139 teaching io_uring pipeline experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import KEY_BODY, MEASURE_S, PROCESS, TITLE_V1, UringEngine


def run() -> dict[str, Any]:
    eng = UringEngine()
    cmp = eng.compare()
    return {
        "engine": "UringEngine",
        "process": PROCESS,
        "key": KEY_BODY,
        "title": TITLE_V1,
        "body_file": cmp["body_file"],
        "measure_s": MEASURE_S,
        "file_bytes": cmp["file_bytes"],
        "syscall_ns": cmp["syscall_ns"],
        "disk_ns": cmp["disk_ns"],
        "copy_ns_per_byte": cmp["copy_ns_per_byte"],
        "copy_ns": cmp["copy_ns"],
        "service_ns": cmp["service_ns"],
        "max_parallel": cmp["max_parallel"],
        "max_parallel_is_teaching_parameter": True,
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_uring_product": True,
        "not_host_io_uring": True,
        "not_host_liburing": True,
        "not_host_gxx": True,
        "times_are_teaching_virtual_clock": True,
        "host": cmp["host"],
        "sync": cmp["sync"],
        "pipelines": cmp["pipelines"],
        "qd1_matches_sync_file_count": cmp["qd1_matches_sync_file_count"],
        "deeper_than_cap_holds_more_buffers": cmp["deeper_than_cap_holds_more_buffers"],
        "throughput_gain_qd16_vs_qd8_mb_s": cmp["throughput_gain_qd16_vs_qd8_mb_s"],
        "throughput_gain_qd32_vs_qd8_mb_s": cmp["throughput_gain_qd32_vs_qd8_mb_s"],
        "buffer_lifetime": cmp["buffer_lifetime"],
        "partial_and_link": cmp["partial_and_link"],
        "cancel_races": cmp["cancel_races"],
        "fd_lifetime": cmp["fd_lifetime"],
        "pitfall_nonblock_and_copy": cmp["pitfall_nonblock_and_copy"],
        "acceptance_buffer_held_until_cqe": cmp["acceptance_buffer_held_until_cqe"],
        "acceptance_partial_and_cancel_race": cmp["acceptance_partial_and_cancel_race"],
        "pitfall_not_always_nonblock_or_zerocopy": cmp["pitfall_not_always_nonblock_or_zerocopy"],
        "tradeoff_parallelism_vs_lifetime": cmp["tradeoff_parallelism_vs_lifetime"],
    }


if __name__ == "__main__":
    run()
