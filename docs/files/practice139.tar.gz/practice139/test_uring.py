#!/usr/bin/env python3
"""Acceptance checks for the lesson 139 teaching io_uring experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    EALREADY_VAL,
    ECANCELED_VAL,
    ENOENT_VAL,
    FILE_BYTES,
    KEY_BODY,
    MEASURE_S,
    PROCESS,
    SHORT_READ_RES,
    TITLE_V1,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "UringEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_BODY and r["title"] == TITLE_V1
    assert r["body_file"] == "article-body.bin"
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["file_bytes"] == FILE_BYTES == 262_144
    assert r["syscall_ns"] == 10_000
    assert r["disk_ns"] == 200_000
    assert r["copy_ns_per_byte"] == 1 and r["copy_ns"] == 262_144
    assert r["service_ns"] == 462_144
    assert r["max_parallel"] == 8 and r["max_parallel_is_teaching_parameter"]
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_uring_product"]
    assert r["not_host_io_uring"] and r["not_host_liburing"] and r["not_host_gxx"]
    assert r["times_are_teaching_virtual_clock"]
    assert r["host"]["uname_r"] == "6.12.113+"
    assert r["host"]["host_io_uring_disabled_sysctl"] == 0
    assert r["host"]["host_io_uring_invoked"] is False
    assert r["host"]["host_liburing_invoked"] is False
    assert r["host"]["host_gxx_invoked"] is False

    sync = r["sync"]
    assert sync["n_files"] == 63_539 and sync["payload_bytes"] == 16_656_367_616
    assert sync["throughput_mb_s"] == 555.21 and sync["syscalls"] == 63_539
    assert sync["user_copy_bytes"] == sync["payload_bytes"]
    assert sync["cost_ns_per_file"] == 472_144
    assert sync["inflight_buffers"] == 1
    assert sync["not_zero_copy_file_read"]

    p = r["pipelines"]
    qd1, qd4, qd8, qd16, qd32 = p["qd1"], p["qd4"], p["qd8"], p["qd16"], p["qd32"]
    assert r["qd1_matches_sync_file_count"]
    assert qd1["n_files"] == 63_539 and qd1["throughput_mb_s"] == 555.21
    assert qd1["syscalls"] == 63_539 and qd1["user_copy_bytes"] == 16_656_367_616
    assert qd1["inflight_buffer_bytes"] == 262_144

    assert qd4["n_files"] == 254_156 and qd4["payload_bytes"] == 66_625_470_464
    assert qd4["throughput_mb_s"] == 2220.85 and qd4["syscalls"] == 63_539
    assert qd4["inflight_buffer_bytes"] == 1_048_576
    assert qd4["user_copy_bytes"] == qd4["payload_bytes"]

    assert qd8["n_files"] == 508_312 and qd8["payload_bytes"] == 133_250_940_928
    assert qd8["throughput_mb_s"] == 4441.7 and qd8["syscalls"] == 63_539
    assert qd8["inflight_buffer_bytes"] == 2_097_152
    assert qd8["max_parallel_used"] == 8
    assert qd8["user_copy_bytes"] == qd8["payload_bytes"]
    assert qd8["throughput_mb_s"] > sync["throughput_mb_s"]

    assert qd16["n_files"] == 513_760 and qd16["payload_bytes"] == 134_679_101_440
    assert qd16["throughput_mb_s"] == 4489.3 and qd16["syscalls"] == 32_110
    assert qd16["wave_ns"] == 934_288 and qd16["service_rounds_per_wave"] == 2
    assert qd16["inflight_buffer_bytes"] == 4_194_304
    assert qd16["max_parallel_used"] == 8

    assert qd32["n_files"] == 516_512 and qd32["payload_bytes"] == 135_400_521_728
    assert qd32["throughput_mb_s"] == 4513.35 and qd32["syscalls"] == 16_141
    assert qd32["wave_ns"] == 1_858_576 and qd32["service_rounds_per_wave"] == 4
    assert qd32["inflight_buffer_bytes"] == 8_388_608
    assert qd32["max_parallel_used"] == 8

    assert r["throughput_gain_qd16_vs_qd8_mb_s"] == 47.6
    assert r["throughput_gain_qd32_vs_qd8_mb_s"] == 71.65
    assert r["deeper_than_cap_holds_more_buffers"]
    assert r["tradeoff_parallelism_vs_lifetime"]

    buf = r["buffer_lifetime"]
    assert buf["freed_before_cqe"] and buf["violates_buffer_until_completion"]
    assert buf["kernel_bytes_not_invented"] and buf["cqe_seen"] is False
    assert r["acceptance_buffer_held_until_cqe"]

    part = r["partial_and_link"]
    assert part["requested_bytes"] == 262_144 and part["short_read_res"] == SHORT_READ_RES == 131_072
    assert part["is_short_read"] and part["chain_broken_by_short_read"]
    assert part["follow_up_res"] == ECANCELED_VAL == -125
    assert part["link_flag"] == "IOSQE_IO_LINK"

    cancel = r["cancel_races"]
    assert cancel["two_cqes_generated"] and cancel["order_not_guaranteed"]
    assert cancel["inherently_racy"] and cancel["async_cancel_available_since"] == "5.5"
    cases = {c["name"]: c for c in cancel["cases"]}
    assert cases["already_complete"]["cancel_cqe_res"] == ENOENT_VAL == -2
    assert cases["already_complete"]["request_cqe_res"] == 262_144
    assert cases["canceled_before_start"]["cancel_cqe_res"] == 0
    assert cases["canceled_before_start"]["request_cqe_res"] == ECANCELED_VAL == -125
    assert cases["disk_io_already_started"]["cancel_cqe_res"] == EALREADY_VAL == -114
    assert cases["disk_io_already_started"]["request_cqe_res"] == 262_144
    assert cases["disk_io_already_started"]["may_or_may_not_terminate"]
    assert r["acceptance_partial_and_cancel_race"]

    fd = r["fd_lifetime"]
    assert fd["close_fd_while_inflight"] and fd["auto_canceled"] is False
    assert fd["must_explicitly_cancel"] and fd["close_ring_cancels_pending"]

    pit = r["pitfall_nonblock_and_copy"]
    assert pit["tried_nonblock_first"] and pit["fell_back_to_async"]
    assert pit["file_read_user_copy"] and pit["send_zc_zerocopy_not_guaranteed"]
    assert r["pitfall_not_always_nonblock_or_zerocopy"]


if __name__ == "__main__":
    main()
