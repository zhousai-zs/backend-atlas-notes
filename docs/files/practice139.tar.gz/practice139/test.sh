#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 test_uring.py
echo ALL_CHECKS_PASSED
