#!/usr/bin/env python3
"""Teaching UringEngine — not Redis, not a network service, not a
real io_uring / liburing / profiler product, and not a host
io_uring, liburing, or g++ run.

A Python 3 standard-library, virtual-clock model of a file-read
pipeline in teachkv: synchronous pread versus an io_uring
submission/completion queue at several queue depths. The named
source (checked on 2026-11-14) is:

* Linux man-pages page for io_uring(7), at
  https://man7.org/linux/man-pages/man7/io_uring.7.html
  This page is part of the liburing project (COLOPHON: obtained
  from https://github.com/axboe/liburing on 2026-08-04; most
  recent commit found then was 2026-07-28). The page footer is
  "Linux  July 26, 2020  io_uring(7)". NAME is
  "io_uring - Asynchronous I/O facility". It describes shared
  submission (SQ) and completion (CQ) ring buffers between user
  and kernel: the application places submission queue entries
  (SQEs) on the SQ tail, calls io_uring_enter(2) so the kernel
  can dequeue them, and the kernel places one completion queue
  event (CQE) on the CQ tail per SQE in the basic model. The
  CQE res field is the equivalent system-call return value, or
  -errno on error. Completions may occur in any order; user_data
  is passed back unchanged so a CQE can be matched to its SQE.
  The basic "one CQE per SQE" rule can deviate with
  IOSQE_CQE_SKIP_SUCCESS or multi-shot operations. Pointers to
  buffers used by IORING_OP_READ / IORING_OP_WRITE "must remain
  valid until completion". Some other pointers (example:
  IORING_OP_TIMEOUT's __kernel_timespec) may be freed after
  submit, except with IORING_SETUP_SQPOLL or on kernels 5.4 and
  earlier (probe IORING_FEAT_SUBMIT_STABLE). The performance
  section says io_uring "can be a zero-copy system" because
  communication is via shared rings, "avoiding the overhead of
  copying buffers between them, where possible"; copying "becomes
  necessary when system calls that transfer data between kernel
  and user space are involved." Batching several SQEs into one
  io_uring_enter(2) is a stated benefit; SQ polling can avoid
  even that call. Kernels older than 5.4 need three mmap(2)
  calls to set up the rings, not two.

Follow-through pages named by io_uring(7) SEE ALSO / "Pages that
refer to this page", also read on 2026-11-14:

* io_uring_enter(2) (footer January 22, 2019). IORING_OP_ASYNC_CANCEL
  (available since 5.5): addr holds the target user_data; cancel
  CQE res is 0 if found, -ENOENT if not found, -EALREADY if found
  and "attempted canceled" (the request may or may not
  terminate). "requests that are interruptible (like socket IO)
  will get canceled, while disk IO requests cannot be canceled
  if already started." IOSQE_IO_LINK (since 5.3): a short read
  is an unexpected result and breaks the rest of the chain with
  -ECANCELED. IOSQE_ASYNC (since 5.6): "Normal operation for
  io_uring is to try and issue an sqe as non-blocking first, and
  if that fails, execute it in an async manner." IORING_OP_SEND_ZC:
  "Zerocopy execution is not guaranteed and may fall back to
  copying." The first CQE may have IORING_CQE_F_MORE; the user
  must not modify the data buffer until the notification CQE
  (IORING_CQE_F_NOTIF) is posted.

* io_uring_setup(2) (footer January 29, 2019) and
  io_uring_register(2) (footer January 17, 2019): ring setup and
  registration; not the source of this lesson's throughput
  numbers.

* io_uring_cancelation(7) (American spelling "cancelation" as
  linked from io_uring(7); the URL with "cancellation" returned
  404 on 2026-11-14). Footer January 18, 2025. Two CQEs are
  generated: the canceled request's res is -ECANCELED (or
  occasionally -EINTR); the cancel request's res is 0, -ENOENT,
  or -EALREADY. "The order of these CQEs is not guaranteed."
  Cancelation is inherently racy. Closing a file descriptor does
  not automatically cancel pending io_uring requests (the ring
  holds its own file reference). Closing the ring does cancel
  pending requests. "Not all operations are cancelable.
  Operations that have already been submitted to hardware
  (e.g., disk I/O in progress) typically cannot be canceled."

This engine does not invoke host io_uring, liburing, or g++.
Times are teaching virtual-clock values, not production disk
service times or host measurements. The teaching device
concurrency cap (MAX_PARALLEL = 8) is a teaching parameter, not
a host SSD queue depth.
"""
from __future__ import annotations

from typing import Any


TITLE_V1 = "Weekly digest"
KEY_BODY = "article:01:body"
PROCESS = "teachkv"
BODY_FILE = "article-body.bin"

MEASURE_S = 30.00
MEASURE_NS = 30_000_000_000
FILE_BYTES = 256 * 1024  # 262_144
SYSCALL_NS = 10_000
DISK_NS = 200_000
COPY_NS_PER_BYTE = 1
COPY_NS = FILE_BYTES * COPY_NS_PER_BYTE  # 262_144
SERVICE_NS = DISK_NS + COPY_NS  # 462_144
ENTER_NS = SYSCALL_NS
MAX_PARALLEL = 8  # teaching device concurrency, not a host measurement
DEPTHS = (1, 4, 8, 16, 32)
SHORT_READ_RES = FILE_BYTES // 2  # 131_072
HOST_UNAME_R = "6.12.113+"


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def mb_s(payload_bytes: int, used_s: float = MEASURE_S) -> float:
    return ts(payload_bytes / used_s / 1_000_000.0, 2)


class UringEngine:
    """Virtual-clock SQ/CQ file-read pipeline. Not host io_uring."""

    def _wave_cost(self, depth: int) -> tuple[int, int, int]:
        """Return (wave_ns, files_per_wave, service_rounds).

        One io_uring_enter submits `depth` SQEs and waits for their
        CQEs. At most MAX_PARALLEL services run at a time, so a
        wave deeper than the cap takes ceil(depth / MAX_PARALLEL)
        service rounds after that single enter.
        """
        rounds = (depth + MAX_PARALLEL - 1) // MAX_PARALLEL
        wave_ns = ENTER_NS + rounds * SERVICE_NS
        return wave_ns, depth, rounds

    def sync_read(self) -> dict[str, Any]:
        cost = SYSCALL_NS + SERVICE_NS  # 472_144
        n_files = MEASURE_NS // cost
        used_ns = n_files * cost
        payload = n_files * FILE_BYTES
        return {
            "name": "sync_pread",
            "mode": "sync",
            "n_files": n_files,
            "payload_bytes": payload,
            "throughput_mb_s": mb_s(payload),
            "syscalls": n_files,
            "user_copy_bytes": payload,
            "cost_ns_per_file": cost,
            "used_ns": used_ns,
            "inflight_buffers": 1,
            "inflight_buffer_bytes": FILE_BYTES,
            "queue_depth": 1,
            "max_parallel_used": 1,
            "times_are_teaching_virtual_clock": True,
            "not_host_io_uring": True,
            "not_host_liburing": True,
            "not_zero_copy_file_read": True,
        }

    def uring_pipeline(self, depth: int) -> dict[str, Any]:
        wave_ns, files_per_wave, rounds = self._wave_cost(depth)
        waves = MEASURE_NS // wave_ns
        n_files = waves * files_per_wave
        used_ns = waves * wave_ns
        payload = n_files * FILE_BYTES
        parallel = min(depth, MAX_PARALLEL)
        return {
            "name": f"uring_qd{depth}",
            "mode": "io_uring",
            "queue_depth": depth,
            "n_files": n_files,
            "payload_bytes": payload,
            "throughput_mb_s": mb_s(payload),
            "syscalls": waves,
            "user_copy_bytes": payload,
            "wave_ns": wave_ns,
            "files_per_wave": files_per_wave,
            "service_rounds_per_wave": rounds,
            "waves": waves,
            "used_ns": used_ns,
            "cost_ns_per_file_amortized": wave_ns // files_per_wave
            if files_per_wave
            else 0,
            "inflight_buffers": depth,
            "inflight_buffer_bytes": depth * FILE_BYTES,
            "max_parallel_used": parallel,
            "times_are_teaching_virtual_clock": True,
            "not_host_io_uring": True,
            "not_host_liburing": True,
            "not_zero_copy_file_read": True,
        }

    def buffer_lifetime(self) -> dict[str, Any]:
        """Free the read buffer before the CQE is seen.

        io_uring(7) 'SQE pointer lifetimes & data stability':
        pointers to a buffer used by IORING_OP_READ must remain
        valid until completion. This case violates that rule.
        The engine does not invent what bytes the kernel would
        have written.
        """
        return {
            "opcode": "IORING_OP_READ",
            "requested_bytes": FILE_BYTES,
            "freed_before_cqe": True,
            "violates_buffer_until_completion": True,
            "kernel_bytes_not_invented": True,
            "cqe_seen": False,
            "doc": (
                "io_uring(7): pointers to a buffer used as part of "
                "IORING_OP_WRITE or IORING_OP_READ must remain valid "
                "until completion."
            ),
        }

    def partial_and_link(self) -> dict[str, Any]:
        """A short read breaks an IOSQE_IO_LINK chain.

        io_uring_enter(2): a short read is an unexpected result
        and terminates the remainder of the chain with -ECANCELED.
        """
        return {
            "requested_bytes": FILE_BYTES,
            "short_read_res": SHORT_READ_RES,
            "is_short_read": True,
            "linked_follow_up": True,
            "follow_up_res": ECANCELED_VAL,
            "chain_broken_by_short_read": True,
            "link_flag": "IOSQE_IO_LINK",
            "link_available_since": "5.3",
            "doc": (
                "io_uring_enter(2) IOSQE_IO_LINK: a chain is broken if "
                "any request ends in error; io_uring considers any "
                "unexpected result an error, so a short read also "
                "terminates the remainder of the chain with -ECANCELED."
            ),
        }

    def cancel_races(self) -> dict[str, Any]:
        """Three teaching cancel races. CQE order is not guaranteed."""
        already_complete = {
            "name": "already_complete",
            "cancel_cqe_res": ENOENT_VAL,
            "request_cqe_res": FILE_BYTES,
            "request_completed_successfully": True,
            "note": (
                "Cancel processed after the read had already completed; "
                "cancel CQE res is -ENOENT; the original CQE carries "
                "the byte count. io_uring_cancelation(7) says the "
                "order of these two CQEs is not guaranteed."
            ),
        }
        canceled = {
            "name": "canceled_before_start",
            "cancel_cqe_res": 0,
            "request_cqe_res": ECANCELED_VAL,
            "request_completed_successfully": False,
            "note": (
                "Cancel found a still-cancelable request; cancel CQE "
                "res is 0; the original request completes with "
                "-ECANCELED. Order is not guaranteed."
            ),
        }
        disk_started = {
            "name": "disk_io_already_started",
            "cancel_cqe_res": EALREADY_VAL,
            "request_cqe_res": FILE_BYTES,
            "request_completed_successfully": True,
            "may_or_may_not_terminate": True,
            "note": (
                "io_uring_enter(2): if found and attempted canceled, "
                "the cancel CQE res is -EALREADY and the request may "
                "or may not terminate; disk IO cannot be canceled if "
                "already started. io_uring_cancelation(7) phrases "
                "-EALREADY as 'found but already completing', and "
                "NOTES say operations already submitted to hardware "
                "(e.g., disk I/O in progress) typically cannot be "
                "canceled. This teaching case lets the original read "
                "complete successfully with the full byte count; it "
                "does not invent a second, contradictory outcome."
            ),
        }
        return {
            "two_cqes_generated": True,
            "order_not_guaranteed": True,
            "inherently_racy": True,
            "async_cancel_available_since": "5.5",
            "cases": [already_complete, canceled, disk_started],
            "cqe_order_in_this_run": [
                "request_cqe_then_cancel_cqe_is_one_possible_order",
                "the_reverse_is_also_possible_per_docs",
            ],
        }

    def fd_lifetime(self) -> dict[str, Any]:
        return {
            "close_fd_while_inflight": True,
            "auto_canceled": False,
            "must_explicitly_cancel": True,
            "close_ring_cancels_pending": True,
            "doc": (
                "io_uring_cancelation(7): pending requests on an fd "
                "are not automatically canceled when the application "
                "closes that fd; the ring holds its own file "
                "reference. Closing the io_uring instance does "
                "cancel pending requests."
            ),
        }

    def pitfall_nonblock_and_copy(self) -> dict[str, Any]:
        return {
            "tried_nonblock_first": True,
            "fell_back_to_async": True,
            "iosqe_async_available_since": "5.6",
            "file_read_user_copy": True,
            "send_zc_zerocopy_not_guaranteed": True,
            "shared_rings_avoid_syscall_arg_copy_where_possible": True,
            "doc_issue_path": (
                "io_uring_enter(2) IOSQE_ASYNC: normal operation is "
                "to try and issue an SQE as non-blocking first, and "
                "if that fails, execute it in an async manner."
            ),
            "doc_copy": (
                "io_uring(7): io_uring can be a zero-copy system "
                "because rings are shared, avoiding the overhead of "
                "copying buffers between them where possible; "
                "copying becomes necessary when system calls that "
                "transfer data between kernel and user space are "
                "involved. IORING_OP_READ into a user buffer is such "
                "a transfer. io_uring_enter(2) IORING_OP_SEND_ZC: "
                "zerocopy execution is not guaranteed and may fall "
                "back to copying."
            ),
        }

    def compare(self) -> dict[str, Any]:
        sync = self.sync_read()
        pipelines = {f"qd{d}": self.uring_pipeline(d) for d in DEPTHS}
        qd1 = pipelines["qd1"]
        qd8 = pipelines["qd8"]
        qd16 = pipelines["qd16"]
        qd32 = pipelines["qd32"]
        # QD=1 matches sync file rate under this cost model
        qd1_matches_sync = qd1["n_files"] == sync["n_files"]
        deeper_holds_more_buffers = (
            qd16["inflight_buffer_bytes"] > qd8["inflight_buffer_bytes"]
            and qd32["inflight_buffer_bytes"] > qd16["inflight_buffer_bytes"]
        )
        # Beyond the teaching cap, added depth mainly holds buffers
        small_gain_16 = qd16["throughput_mb_s"] - qd8["throughput_mb_s"]
        small_gain_32 = qd32["throughput_mb_s"] - qd8["throughput_mb_s"]
        buffer = self.buffer_lifetime()
        partial = self.partial_and_link()
        cancel = self.cancel_races()
        fdlife = self.fd_lifetime()
        pitfall = self.pitfall_nonblock_and_copy()
        return {
            "body_file": BODY_FILE,
            "file_bytes": FILE_BYTES,
            "syscall_ns": SYSCALL_NS,
            "disk_ns": DISK_NS,
            "copy_ns_per_byte": COPY_NS_PER_BYTE,
            "copy_ns": COPY_NS,
            "service_ns": SERVICE_NS,
            "max_parallel": MAX_PARALLEL,
            "max_parallel_is_teaching_parameter": True,
            "measure_s": MEASURE_S,
            "host": {
                "uname_r": HOST_UNAME_R,
                "host_io_uring_disabled_sysctl": 0,
                "host_io_uring_invoked": False,
                "host_liburing_invoked": False,
                "host_gxx_invoked": False,
            },
            "sync": sync,
            "pipelines": pipelines,
            "qd1_matches_sync_file_count": qd1_matches_sync,
            "deeper_than_cap_holds_more_buffers": deeper_holds_more_buffers,
            "throughput_gain_qd16_vs_qd8_mb_s": ts(small_gain_16, 2),
            "throughput_gain_qd32_vs_qd8_mb_s": ts(small_gain_32, 2),
            "buffer_lifetime": buffer,
            "partial_and_link": partial,
            "cancel_races": cancel,
            "fd_lifetime": fdlife,
            "pitfall_nonblock_and_copy": pitfall,
            "acceptance_buffer_held_until_cqe": (
                buffer["violates_buffer_until_completion"]
                and buffer["kernel_bytes_not_invented"]
            ),
            "acceptance_partial_and_cancel_race": (
                partial["chain_broken_by_short_read"]
                and cancel["inherently_racy"]
                and cancel["order_not_guaranteed"]
            ),
            "pitfall_not_always_nonblock_or_zerocopy": (
                pitfall["fell_back_to_async"]
                and pitfall["file_read_user_copy"]
                and sync["user_copy_bytes"] == sync["payload_bytes"]
                and qd8["user_copy_bytes"] == qd8["payload_bytes"]
            ),
            "tradeoff_parallelism_vs_lifetime": (
                qd8["throughput_mb_s"] > sync["throughput_mb_s"]
                and deeper_holds_more_buffers
                and qd32["throughput_mb_s"] - qd8["throughput_mb_s"]
                < qd8["throughput_mb_s"] - pipelines["qd4"]["throughput_mb_s"]
            ),
        }


# CQE res values use negative errno, as io_uring(7) describes.
ECANCELED_VAL = -125
ENOENT_VAL = -2
EALREADY_VAL = -114
