#!/usr/bin/env bash
# practice94：异步 fan-out 聚合——一次性完成、晚到回调、取消后引用释放
set -u
cd "$(dirname "$0")"
FAIL=0; ok(){ echo "PASS $1"; }; bad(){ echo "FAIL $1"; FAIL=1; }
BP=(19401 19402 19403 19404); NAIVE=19411; SAFE=19412
start_backends(){ # $1=comment 额外参数
  python3 backend.py article ${BP[0]} 40 & python3 backend.py stats ${BP[1]} 50 &
  python3 backend.py comment ${BP[2]} 60 $1 & python3 backend.py relation ${BP[3]} 45 --fail-every 5 &
}
B="{\"article\":${BP[0]},\"stats\":${BP[1]},\"comment\":${BP[2]},\"relation\":${BP[3]}}"
start_aggs(){ python3 agg.py $NAIVE naive "$B" & python3 agg.py $SAFE safe "$B" & sleep 0.6; }
stopall(){ kill $(jobs -p) 2>/dev/null; wait 2>/dev/null; }
trap stopall EXIT
J(){ python3 -c "import json,sys;d=json.loads(sys.argv[1]);print(eval(sys.argv[2],{},d))" "$1" "$2"; }
C(){ python3 client.py "$@"; }

echo "== A. 正常 fan-out + 部分失败 + 超时（comment 每 4 个请求慢到 400ms；relation 每 5 个失败；timeout=150ms）"
start_backends "--slow-every 4 --slow-ms 400"; start_aggs
r=$(C $SAFE 40 150); echo "  safe : $(J "$r" '{k:v for k,v in locals().items() if k in ("answered","dup_rids","p50","p99","statuses")}')"
[ "$(J "$r" 'answered')" = 40 ] && [ "$(J "$r" 'dup_rids')" = 0 ] && ok "A1 40 个请求每个恰好完成一次" || bad A1
[ "$(J "$r" 'statuses.get("TIMEOUT",0)')" = 10 ] && [ "$(J "$r" 'statuses.get("PARTIAL",0)')" -ge 1 ] && ok "A2 慢下游→TIMEOUT，非关键下游失败→PARTIAL 降级" || bad A2
[ "$(J "$r" 'server["late_dropped"]>=1 and server["use_after_destroy"]==0')" = True ] && ok "A3 晚到回调被安全丢弃(late_dropped=$(J "$r" 'server["late_dropped"]'))，未访问已销毁上下文" || bad A3
r2=$(C $NAIVE 40 150); echo "  naive: use_after_destroy=$(J "$r2" 'server["use_after_destroy"]')（同样 10 个超时请求，晚到回调都摸到了已销毁的上下文）"
[ "$(J "$r2" 'server["use_after_destroy"]')" -ge 1 ] && ok "A4 对照：naive 晚到回调访问已销毁上下文" || bad A4

echo "== B. 串行 vs 并行（40 个请求一次性突发进入，timeout=1000 不触发超时）"
rp=$(C $SAFE 40 1000 --start 101 --gap 0 --reset)
rs=$(C $SAFE 40 1000 --start 201 --gap 0 --serial --wait 2.5 --reset)
pp=$(J "$rp" 'server["peak_inflight_ops"]'); ps=$(J "$rs" 'server["peak_inflight_ops"]')
echo "  并行: p50=$(J "$rp" p50)ms p99=$(J "$rp" p99)ms 聚合层同时在途的下游调用峰值=$pp"
echo "  串行: p50=$(J "$rs" p50)ms p99=$(J "$rs" p99)ms 聚合层同时在途的下游调用峰值=$ps"
python3 -c "import sys;sys.exit(0 if $(J "$rp" p50) < $(J "$rs" p50) else 1)" && ok "B1 并行缩短关键路径" || bad B1
python3 -c "import sys;sys.exit(0 if $pp >= 3*$ps else 1)" && ok "B2 并行放大下游瞬时并发（$ps → $pp）" || bad B2
stopall

echo "== C. 超时与正常完成同时到达（comment 固定 60ms，timeout=60ms，200 请求；检查-设置之间有 2ms 窗口）"
start_backends ""; start_aggs
r=$(C $NAIVE 200 60 --start 1001 --wait 0.8)
echo "  naive(普通布尔): dup_rids=$(J "$r" dup_rids) double_complete=$(J "$r" 'server["double_complete"]') replies=$(J "$r" 'server["replies"]')"
[ "$(J "$r" dup_rids)" -ge 1 ] && ok "C1 对照：普通布尔标记出现重复完成" || bad C1
r=$(C $SAFE 200 60 --start 2001 --wait 0.8)
echo "  safe (锁内CAS) : dup_rids=$(J "$r" dup_rids) double_complete=$(J "$r" 'server["double_complete"]') replies=$(J "$r" 'server["replies"]') statuses=$(J "$r" statuses)"
[ "$(J "$r" dup_rids)" = 0 ] && [ "$(J "$r" 'server["replies"]')" = 200 ] && ok "C2 一次性完成：200 请求恰好 200 次回包" || bad C2
stopall

echo "== D. 客户端取消后引用最终释放（comment 全部 400ms，100ms 后取消全部 30 个请求）"
start_backends "--slow-every 1 --slow-ms 400"; start_aggs
python3 bstat.py RESET ${BP[@]} >/dev/null
r=$(C $SAFE 30 2000 --start 3001 --cancel-after 100 --wait 0.15); b=$(python3 bstat.py STATS ${BP[@]})
echo "  safe : 取消后150ms inflight_ops=$(J "$r" 'server["inflight_ops"]') alive_ctx=$(J "$r" 'server["alive_ctx"]') registry=$(J "$r" 'server["registry"]') comment aborted=$(J "$b" 'comment["aborted"]') served=$(J "$b" 'comment["served"]') statuses=$(J "$r" statuses)"
[ "$(J "$r" 'statuses.get("CANCELLED",0)')" = 30 ] && ok "D1 30 个请求均以 CANCELLED 完成一次" || bad D1
[ "$(J "$r" 'server["inflight_ops"]==0 and server["alive_ctx"]==0 and server["registry"]==0')" = True ] && ok "D2 取消后在途操作/上下文/注册表引用全部归零" || bad D2
[ "$(J "$b" 'comment["aborted"]')" -ge 1 ] && ok "D3 取消传播到下游，comment 放弃了在途工作" || bad D3
python3 bstat.py RESET ${BP[@]} >/dev/null
r=$(C $NAIVE 30 2000 --start 4001 --cancel-after 100 --wait 0.15); b=$(python3 bstat.py STATS ${BP[@]})
echo "  naive: 取消后150ms inflight_ops=$(J "$r" 'server["inflight_ops"]') alive_ctx=$(J "$r" 'server["alive_ctx"]') comment aborted=$(J "$b" 'comment["aborted"]')"
[ "$(J "$r" 'server["inflight_ops"]')" -ge 1 ] && ok "D4 对照：naive 不取消下游，取消后仍有在途操作" || bad D4
sleep 0.5; r=$(C $NAIVE 0 2000 --wait 0.1)
echo "  naive: 再等500ms inflight_ops=$(J "$r" 'server["inflight_ops"]') alive_ctx=$(J "$r" 'server["alive_ctx"]') use_after_destroy=$(J "$r" 'server["use_after_destroy"]')"
[ "$(J "$r" 'server["use_after_destroy"]')" -ge 1 ] && ok "D5 对照：naive 下游白干完后回调摸到已销毁上下文" || bad D5
[ $FAIL = 0 ] && echo ALL_CHECKS_PASSED || { echo SOME_CHECKS_FAILED; exit 1; }
