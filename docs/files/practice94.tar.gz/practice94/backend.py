#!/usr/bin/env python3
"""下游服务模拟：一行请求 "<rid>\n"，按服务名延迟后回一行。统计在途峰值。
用法: backend.py NAME PORT DELAY_MS [--slow-every N --slow-ms M] [--fail-every N]
"""
import socket, sys, threading, time, json, argparse
ap = argparse.ArgumentParser()
ap.add_argument("name"); ap.add_argument("port", type=int); ap.add_argument("delay", type=int)
ap.add_argument("--slow-every", type=int, default=0); ap.add_argument("--slow-ms", type=int, default=0)
ap.add_argument("--fail-every", type=int, default=0)
a = ap.parse_args()
lock = threading.Lock(); inflight = 0; peak = 0; served = 0; aborted = 0

def handle(c):
    global inflight, peak, served, aborted
    with c:
        f = c.makefile("rwb")
        line = f.readline().strip().decode()
        if line == "STATS":
            f.write((json.dumps({"name": a.name, "peak": peak, "served": served, "aborted": aborted}) + "\n").encode()); f.flush(); return
        if line == "RESET":
            with lock: peak = 0; served = 0; aborted = 0
            f.write(b"OK\n"); f.flush(); return
        rid = int(line.split()[0])
        with lock:
            inflight += 1; peak = max(peak, inflight)
        try:
            d = a.delay
            if a.slow_every and rid % a.slow_every == 0: d = a.slow_ms
            # 分片 sleep，期间对端关闭（上游取消）可被感知
            end = time.monotonic() + d / 1000
            c.settimeout(0.005)
            while time.monotonic() < end:
                try:
                    if c.recv(1) == b"":  # 上游 shutdown -> EOF，放弃这次工作
                        with lock: aborted += 1
                        return
                except socket.timeout: pass
                except OSError:
                    with lock: aborted += 1
                    return
            if a.fail_every and rid % a.fail_every == 0:
                f.write(f"ERR {a.name} unavailable\n".encode())
            else:
                f.write(f"OK {a.name}-{rid}\n".encode())
            f.flush()
            with lock: served += 1
        except OSError:
            pass
        finally:
            with lock: inflight -= 1

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", a.port)); s.listen(512)
print(f"LISTEN {a.name} {a.port}", flush=True)
while True:
    c, _ = s.accept()
    threading.Thread(target=handle, args=(c,), daemon=True).start()
