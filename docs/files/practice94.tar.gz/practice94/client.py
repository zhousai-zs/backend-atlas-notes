#!/usr/bin/env python3
"""压测客户端：一条连接上并发发 N 个请求，统计每个 rid 收到几次响应。
用法: client.py PORT N TIMEOUT_MS [--serial] [--cancel-after MS] [--start RID] [--stats-only] [--gc]
"""
import socket, sys, time, json, argparse, threading
ap = argparse.ArgumentParser()
ap.add_argument("port", type=int); ap.add_argument("n", type=int); ap.add_argument("tmo", type=int)
ap.add_argument("--serial", action="store_true"); ap.add_argument("--cancel-after", type=int, default=0)
ap.add_argument("--start", type=int, default=1); ap.add_argument("--wait", type=float, default=1.5)
ap.add_argument("--gap", type=float, default=0.002)
ap.add_argument("--reset", action="store_true")
a = ap.parse_args()
s = socket.create_connection(("127.0.0.1", a.port)); f = s.makefile("rb")
if a.reset: s.sendall(b"RESET\n")
got = {}; sent_at = {}; lat = []; statuses = {}; stats = []
def reader():
    for raw in f:
        line = raw.decode().rstrip("\n")
        if line.startswith("STATS "): stats.append(json.loads(line[6:])); continue
        _, rid, st, _ = line.split(" ", 3); rid = int(rid)
        got[rid] = got.get(rid, 0) + 1
        if got[rid] == 1:
            lat.append((time.monotonic() - sent_at[rid]) * 1000); statuses[st] = statuses.get(st, 0) + 1
threading.Thread(target=reader, daemon=True).start()
rids = range(a.start, a.start + a.n)
for r in rids:
    sent_at[r] = time.monotonic()
    s.sendall(f"REQ {r} {a.tmo}{' serial' if a.serial else ''}\n".encode())
    time.sleep(a.gap)
if a.cancel_after:
    time.sleep(a.cancel_after / 1000)
    for r in rids: s.sendall(f"CANCEL {r}\n".encode())
time.sleep(a.wait)
s.sendall(b"GC\n"); time.sleep(0.2)
lat.sort()
p = lambda q: round(lat[min(len(lat) - 1, int(q * len(lat)))], 1) if lat else -1
dups = sum(1 for v in got.values() if v > 1); missing = sum(1 for r in rids if r not in got)
print(json.dumps({"answered": len(got), "dup_rids": dups, "missing": missing, "p50": p(0.5), "p99": p(0.99),
                  "statuses": statuses, "server": stats[-1] if stats else None}, ensure_ascii=False))
