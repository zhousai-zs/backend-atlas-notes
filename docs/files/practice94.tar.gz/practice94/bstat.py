#!/usr/bin/env python3
"""查询/重置下游统计: bstat.py CMD PORT..."""
import socket, sys, json
cmd = sys.argv[1]; out = {}
for p in sys.argv[2:]:
    s = socket.create_connection(("127.0.0.1", int(p))); s.sendall(f"{cmd}\n".encode())
    line = s.makefile("rb").readline().decode().strip(); s.close()
    if cmd == "STATS": d = json.loads(line); out[d.pop("name")] = d
print(json.dumps(out) if out else "OK")
