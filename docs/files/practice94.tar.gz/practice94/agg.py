#!/usr/bin/env python3
"""异步 fan-out 聚合服务。
前端协议（每连接多路复用，一行一个命令）:
  REQ <rid> <timeout_ms> [serial]   -> 稍后回 "RESP <rid> <status> <json-parts>"
  CANCEL <rid>                      -> 客户端取消
  STATS                             -> 回 JSON 统计
  GC                                -> 触发 gc 并回 STATS
  RESET                             -> 清零计数（不清在途/存活）
mode=naive：普通布尔标记 + 回调持有上下文强引用、完成即销毁上下文（模拟 delete this）
mode=safe ：锁保护的一次性完成(CAS) + 回调只持弱引用 + 超时/取消时取消在途下游
"""
import socket, sys, threading, time, json, weakref, gc
MODE = sys.argv[2]; PORT = int(sys.argv[1]); BACKENDS = json.loads(sys.argv[3])  # {"article":port,...}
CRITICAL = {"article"}
RACE_WINDOW = 0.002  # 人为放大"检查-设置"之间的窗口，使竞态在短时间内可复现

stats_lock = threading.Lock()
S = dict(replies=0, double_complete=0, use_after_destroy=0, late_dropped=0,
         inflight_ops=0, peak_inflight_ops=0, alive_ctx=0, status={})
def inc(k, n=1):
    with stats_lock:
        S[k] += n
        if k == "inflight_ops": S["peak_inflight_ops"] = max(S["peak_inflight_ops"], S[k])

class Ctx:
    """请求上下文/响应对象：被销毁后不应再被访问。"""
    def __init__(self, rid):
        self.rid = rid; self.parts = {}; self.errors = {}; self.destroyed = False
        inc("alive_ctx"); weakref.finalize(self, inc, "alive_ctx", -1)
    def destroy(self):  # 模拟 C++ 中 delete：之后任何访问都是 use-after-free
        self.destroyed = True; self.parts = None; self.errors = None

class Call:
    def __init__(self, rid, conn, wlock, n):
        self.rid = rid; self.conn = conn; self.wlock = wlock
        self.ctx = Ctx(rid); self.pending = n
        self.done = False; self.lock = threading.Lock()
        self.socks = []; self.timer = None; self.replied = 0

    # ---------- 一次性完成 ----------
    def try_complete_naive(self):
        if not self.done:            # 检查
            time.sleep(RACE_WINDOW)  # 窗口：另一条线程也可能通过检查
            self.done = True         # 设置
            return True
        return False
    def try_complete_safe(self):
        with self.lock:              # 检查与设置原子化（等价 compare_exchange）
            if self.done: return False
            time.sleep(RACE_WINDOW)
            self.done = True
            return True

    def finish(self, status):
        ok = self.try_complete_safe() if MODE == "safe" else self.try_complete_naive()
        if not ok: return
        ctx = self.ctx
        if self.replied: inc("double_complete")      # 第二个完成者也通过了检查
        if ctx.destroyed: inc("use_after_destroy")    # 读到了已被另一完成者销毁的上下文
        if self.timer: self.timer.cancel()
        body = json.dumps({"parts": ctx.parts, "errors": ctx.errors}, ensure_ascii=False)
        self.replied += 1
        self.reply(f"RESP {self.rid} {status} {body}")
        with stats_lock: S["status"][status] = S["status"].get(status, 0) + 1
        REG.pop(self.rid, None)
        if MODE == "safe":
            with self.lock:                 # 与 register 互斥：done 之后登记的连接由 register 自己关
                socks, self.socks = self.socks, []
            for sk in socks:                # 取消所有在途下游（合作式：shutdown 让对方看到 EOF）
                try: sk.shutdown(socket.SHUT_RDWR)
                except OSError: pass
            self.ctx = None                 # 释放唯一强引用；回调只持弱引用
        else:
            ctx.destroy()                   # 完成即“delete”，晚到回调仍持有它

    def reply(self, line):
        with self.wlock:
            try: self.conn.sendall((line + "\n").encode())
            except OSError: pass
            inc("replies")

REG = {}

def downstream(name, port, rid, timeout_s, register=None):
    sk = socket.create_connection(("127.0.0.1", port), timeout=timeout_s)
    if register: register(sk)
    try:
        sk.sendall(f"{rid}\n".encode())
        line = sk.makefile("rb").readline().decode().strip()
    finally:
        sk.close()
    if not line: raise ConnectionAbortedError("cancelled")
    k, v = line.split(" ", 1)
    if k != "OK": raise RuntimeError(v)
    return v

def on_part(call_ref_or_call, ctx_ref_or_ctx, name, ok, val):
    """下游回调：可能在请求完成/超时/取消之后很久才到达。"""
    if MODE == "safe":
        ctx = ctx_ref_or_ctx()            # weak_ptr::lock()
        call = call_ref_or_call()
        if ctx is None or call is None:
            inc("late_dropped"); return
    else:
        ctx, call = ctx_ref_or_ctx, call_ref_or_call
        if ctx.destroyed:                 # 真实 C++ 里这里就是悬垂指针写入
            inc("use_after_destroy"); return
    try:
        if ok: ctx.parts[name] = val
        else: ctx.errors[name] = val
    except TypeError:                     # parts 已被销毁置 None
        inc("use_after_destroy"); return
    if MODE == "safe":
        with call.lock:
            call.pending -= 1; left = call.pending
    else:
        call.pending -= 1; left = call.pending
    if left == 0:
        crit_fail = any(n in CRITICAL for n in ctx.errors)
        status = "ERROR" if crit_fail else ("PARTIAL" if ctx.errors else "OK")
        del ctx
        call.finish(status)

def op_thread(name, port, rid, timeout_s, cref, xref, register):
    inc("inflight_ops")
    try:
        try:
            v = downstream(name, port, rid, timeout_s + 1, register); ok = True
        except Exception as e:
            v = type(e).__name__; ok = False
        on_part(cref, xref, name, ok, v)
    finally:
        inc("inflight_ops", -1)

def start(rid, tmo_ms, serial, conn, wlock):
    call = Call(rid, conn, wlock, len(BACKENDS)); REG[rid] = call
    if MODE == "safe":
        cref, xref = weakref.ref(call), weakref.ref(call.ctx)
        def register(sk):
            c = cref()
            if c is not None:
                with c.lock:
                    if not c.done: c.socks.append(sk); return
            sk.shutdown(socket.SHUT_RDWR)   # 请求已结束：新发起的下游调用立即取消
    else:
        cref, xref = call, call.ctx
        register = None
    def on_timeout(cref=cref):
        c = cref() if MODE == "safe" else cref
        if c is not None: c.finish("TIMEOUT")
    call.timer = threading.Timer(tmo_ms / 1000, on_timeout); call.timer.daemon = True
    call.timer.start()
    if serial:
        def run():
            for n, p in BACKENDS.items(): op_thread(n, p, rid, tmo_ms / 1000, cref, xref, register)
        threading.Thread(target=run, daemon=True).start()
    else:
        for n, p in BACKENDS.items():
            threading.Thread(target=op_thread, args=(n, p, rid, tmo_ms / 1000, cref, xref, register), daemon=True).start()
    del call

def client_conn(c):
    wlock = threading.Lock(); f = c.makefile("rb")
    for raw in f:
        p = raw.decode().split()
        if not p: continue
        if p[0] == "REQ":
            start(int(p[1]), int(p[2]), len(p) > 3 and p[3] == "serial", c, wlock)
        elif p[0] == "CANCEL":
            call = REG.get(int(p[1]))
            if call: call.finish("CANCELLED")
            del call
        elif p[0] == "RESET":
            with stats_lock:
                for k in ("replies", "double_complete", "use_after_destroy", "late_dropped"): S[k] = 0
                S["peak_inflight_ops"] = S["inflight_ops"]
                S["status"] = {}
            with wlock: c.sendall(b"STATS {}\n")
        elif p[0] in ("STATS", "GC"):
            if p[0] == "GC": gc.collect()
            with stats_lock: out = json.dumps(dict(S, mode=MODE, registry=len(REG)))
            with wlock: c.sendall(f"STATS {out}\n".encode())

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", PORT)); s.listen(64)
print(f"LISTEN agg {MODE} {PORT}", flush=True)
while True:
    c, _ = s.accept()
    threading.Thread(target=client_conn, args=(c,), daemon=True).start()
