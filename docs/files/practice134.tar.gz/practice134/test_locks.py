#!/usr/bin/env python3
"""Acceptance checks for the lesson 134 teaching lock experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, PROCESS, TITLE_V1


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "LockEngine"
    assert r["process"] == PROCESS == "teachkv"
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["measure_s"] == MEASURE_S == 30.00
    assert r["hold_us"] == 20 and r["outside_us"] == 10
    assert r["n_shards"] == 8 and r["n_keys"] == 16
    assert r["thread_counts"] == [1, 2, 4, 8]
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_profiler_product"] and r["not_a_real_lock_product"]
    assert r["not_host_perf"] and r["not_host_gxx"]
    assert r["not_host_lock_stat"] and r["not_host_futex"]
    assert r["times_are_teaching_virtual_clock"]

    g = r["practice"]["global_futex"]
    s = r["practice"]["sharded_futex"]
    g1, g2, g4, g8 = g["1"], g["2"], g["4"], g["8"]
    s1, s2, s4, s8 = s["1"], s["2"], s["4"], s["8"]

    assert g1["n_done"] == 1_000_000 and g1["throughput_rps"] == 33333.33
    assert g1["cpu_util"] == 1.0 and g1["lock"]["contentions"] == 0
    assert g1["lock"]["holdtime_avg_us"] == 20.0
    assert g1["lock"]["waittime_avg_us"] == 0.0

    assert g2["n_done"] == g4["n_done"] == g8["n_done"] == 1_500_000
    assert g2["throughput_rps"] == g4["throughput_rps"] == g8["throughput_rps"] == 50000.0
    assert g2["lock"]["holdtime_avg_us"] == 20.0
    assert g2["lock"]["waittime_avg_us"] == 10.0
    assert g2["lock"]["waittime_min_us"] == 10 and g2["lock"]["waittime_max_us"] == 20
    assert g2["cpu_util"] == 0.75
    assert g4["lock"]["waittime_avg_us"] == 50.0
    assert g4["lock"]["waittime_min_us"] == 20 and g4["lock"]["waittime_max_us"] == 60
    assert g4["cpu_util"] == 0.375
    assert g8["lock"]["waittime_avg_us"] == 130.0
    assert g8["lock"]["waittime_min_us"] == 20 and g8["lock"]["waittime_max_us"] == 140
    assert g8["lock"]["waittime_total_us"] == 194_999_520
    assert g8["lock"]["contentions"] == 1_499_999
    assert g8["lock"]["acquisitions"] == 1_500_000
    assert g8["cpu_util"] == 0.1875
    assert g8["useful_share_of_cpu"] == 1.0

    assert s1["throughput_rps"] == 33333.33
    assert s2["n_done"] == 2_000_000 and s2["throughput_rps"] == 66666.67
    assert s4["n_done"] == 4_000_000 and s4["throughput_rps"] == 133333.33
    assert s8["n_done"] == 8_000_000 and s8["throughput_rps"] == 266666.67
    assert s8["lock"]["contentions"] == 0 and s8["lock"]["waittime_avg_us"] == 0.0
    assert s8["cpu_util"] == 1.0 and s8["lock"]["holdtime_avg_us"] == 20.0
    assert s8["throughput_rps"] > g8["throughput_rps"]

    spin = r["wait_policy"]["global_spin_8"]
    futex = r["wait_policy"]["global_futex_8"]
    assert spin["throughput_rps"] == futex["throughput_rps"] == 50000.0
    assert spin["cpu_util"] == 1.0 and futex["cpu_util"] == 0.1875
    assert spin["useful_share_of_cpu"] == 0.1875
    assert spin["lock"]["waittime_avg_us"] == futex["lock"]["waittime_avg_us"] == 130.0
    assert r["wait_policy"]["sharded_spin_8"]["cpu_util"] == 1.0
    assert r["wait_policy"]["sharded_spin_8"]["lock"]["contentions"] == 0

    snap = r["snapshot"]
    assert snap["snapshot"]["completed"]
    assert snap["snapshot"]["lock_order"] == [0, 1, 2, 3, 4, 5, 6, 7]
    assert snap["snapshot"]["wait_us"] == 20
    assert snap["snapshot"]["hold_us"] == 200
    assert snap["snapshot"]["done_at_us"] == 15_000_220
    assert snap["n_done"] == 7_999_944
    assert snap["throughput_rps"] == 266664.8
    assert snap["lock"]["contentions"] == 9
    assert snap["lock"]["waittime_max_us"] == 190
    assert snap["lock"]["waittime_total_us"] == 1540
    assert snap["lock"]["waittime_avg_us"] == 171.11

    lf1, lf8 = r["lockfree_1"], r["lockfree_8"]
    assert lf1["n_done"] == 1_000_000 and lf1["n_retries"] == 0
    assert lf1["throughput_rps"] == 33333.33
    assert lf8["n_done"] == 1_411_765
    assert lf8["throughput_rps"] == 47058.83
    assert lf8["n_attempts"] == 11_294_120
    assert lf8["n_retries"] == 9_882_355
    assert lf8["retry_share"] == 0.875
    assert lf8["cpu_util"] == 1.0 and lf8["useful_share_of_cpu"] == 0.1765
    assert lf8["throughput_rps"] < g8["throughput_rps"]
    assert lf8["throughput_rps"] < s8["throughput_rps"]

    assert r["deadlock"]["deadlock_detected"] is True
    assert r["deadlock"]["lock_order_a"] == [0, 1]
    assert r["deadlock"]["lock_order_b"] == [1, 0]
    assert r["deadlock_fixed"]["deadlock_detected"] is False
    assert r["deadlock_fixed"]["resolved_by_fixed_order"] is True

    flags = r["flags"]
    assert flags["global_does_not_scale"]
    assert flags["sharded_beats_global"]
    assert flags["distinguishes_hold_from_wait"]
    assert flags["futex_cpu_low_under_contention"]
    assert flags["spin_inflates_cpu"]
    assert flags["busy_wait_does_not_justify_cpu"]
    assert flags["lockfree_not_automatically_faster"]
    assert flags["snapshot_uses_fixed_lock_order"]
    assert flags["deadlock_from_opposite_order"]
    assert flags["fixed_order_avoids_deadlock"]
    assert r["acceptance_distinguishes_hold_from_wait"]
    assert r["acceptance_avoids_busy_wait_cpu"]
    assert r["pitfall_lockfree_not_always_faster"]
    assert r["tradeoff_fine_locks_need_order"]


if __name__ == "__main__":
    main()
