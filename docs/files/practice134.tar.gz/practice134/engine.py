#!/usr/bin/env python3
"""Teaching LockEngine — not Redis, not a real profiler/lock product,
not a network service.

A Python 3 standard-library, virtual-clock model of a multi-threaded
teaching KV: a global mutex versus sharded mutexes, futex-style
blocking versus busy-wait spinning, plus a consistent snapshot and a
lock-free retry loop.

The named sources (checked on 2026-11-14) are:

* Linux Kernel — Lock statistics, at
  https://www.kernel.org/doc/html/latest/locking/lockstat.html
  (kernel docs 7.4.0-rc2). That page defines hold time and wait time
  (min / max / total / avg), contentions ("number of lock acquisitions
  that had to wait") and acquisitions ("number of times we took the
  lock"). The integer part of the time values is in microseconds. It
  is a kernel /proc/lock_stat facility (CONFIG_LOCK_STAT), not a
  userspace mutex profiler.

* Linux man-pages — futex(2), at
  https://man7.org/linux/man-pages/man2/futex.2.html
  (man-pages 6.19). futex is "fast user-space locking": the majority
  of synchronization stays in user space; a thread calls futex() only
  when it is likely to block for a longer time. Uncontended acquire
  uses atomic instructions; the kernel does not track the lock.
  Contended wait is FUTEX_WAIT, wake is FUTEX_WAKE. The page does not
  use the word "spin". futex(7), which it names, adds that futex
  operations occur entirely in user space for the noncontended case
  and that the kernel arbitrates only the contended case.

"锁持有与等待时间" follows lockstat's hold time / wait time.
"futex 与自旋" uses the official uncontended-user-space vs
FUTEX_WAIT blocking split; busy-wait spinning is a teaching wait
policy (it inflates CPU while waiting) and is not a term defined in
lockstat.html or futex(2). Kernel spinning locks versus sleeping
locks are described in the Lock types page listed in the same
locking manual; that is a kernel lock-category distinction, not a
userspace adaptive-mutex policy.

This engine is not Linux lock_stat, not pthread, not a host perf /
g++ / mutex profiler, and not a wall-clock measurement. Times are
teaching virtual-clock values, not production RTT.
"""
from __future__ import annotations

import heapq
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
PROCESS = "teachkv"

MEASURE_S = 30.00
MEASURE_US = 30_000_000
HOLD_US = 20  # in-lock work: kv_get + serialize the title
OUTSIDE_US = 10  # out-of-lock work
N_SHARDS = 8
N_KEYS = 16
THREAD_COUNTS = (1, 2, 4, 8)
SNAP_HOLD_US = 200  # consistent snapshot of all keys
LOCKFREE_WORK_US = 20


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def share(n: int, d: int, nd: int = 4) -> float:
    if d == 0:
        return 0.0
    return round(n / d + 1e-12, nd)


def key_name(i: int) -> str:
    return f"article:{i:02d}:title"


def shard_of(key_i: int, n_shards: int = N_SHARDS) -> int:
    return key_i % n_shards


class _LockStat:
    __slots__ = (
        "acquisitions",
        "contentions",
        "wait_total",
        "wait_min",
        "wait_max",
        "hold_total",
        "hold_min",
        "hold_max",
    )

    def __init__(self) -> None:
        self.acquisitions = 0
        self.contentions = 0
        self.wait_total = 0
        self.wait_min = 0
        self.wait_max = 0
        self.hold_total = 0
        self.hold_min = 0
        self.hold_max = 0

    def record_acquire(self, wait_us: int) -> None:
        self.acquisitions += 1
        if wait_us > 0:
            self.contentions += 1
            self.wait_total += wait_us
            if self.wait_min == 0 or wait_us < self.wait_min:
                self.wait_min = wait_us
            if wait_us > self.wait_max:
                self.wait_max = wait_us

    def record_hold(self, hold_us: int) -> None:
        self.hold_total += hold_us
        if self.hold_min == 0 or hold_us < self.hold_min:
            self.hold_min = hold_us
        if hold_us > self.hold_max:
            self.hold_max = hold_us

    def as_dict(self) -> dict[str, Any]:
        acq = self.acquisitions
        cont = self.contentions
        return {
            "acquisitions": acq,
            "contentions": cont,
            "waittime_min_us": self.wait_min,
            "waittime_max_us": self.wait_max,
            "waittime_total_us": self.wait_total,
            "waittime_avg_us": ts(self.wait_total / cont, 2) if cont else 0.0,
            "holdtime_min_us": self.hold_min,
            "holdtime_max_us": self.hold_max,
            "holdtime_total_us": self.hold_total,
            "holdtime_avg_us": ts(self.hold_total / acq, 2) if acq else 0.0,
            "contention_share": share(cont, acq),
        }


class _Mutex:
    def __init__(self, name: str) -> None:
        self.name = name
        self.holder: Optional[int] = None
        self.queue: list[int] = []
        self.stat = _LockStat()


class LockEngine:
    """Virtual-clock mutex / shard / spin / futex / lock-free KV."""

    def __init__(self) -> None:
        self.key = KEY_TITLE
        self.title = TITLE_V1

    def _summarize(
        self,
        *,
        mode: str,
        n_threads: int,
        n_shards: int,
        wait_policy: str,
        n_done: int,
        cpu_busy_us: int,
        useful_us: int,
        stats: list[_LockStat],
        extra: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        # Aggregate per-lock stats into one report, plus per-shard rows.
        total = _LockStat()
        rows = []
        for st in stats:
            d = st.as_dict()
            rows.append(d)
            total.acquisitions += st.acquisitions
            total.contentions += st.contentions
            total.wait_total += st.wait_total
            total.hold_total += st.hold_total
            if st.wait_min and (total.wait_min == 0 or st.wait_min < total.wait_min):
                total.wait_min = st.wait_min
            if st.wait_max > total.wait_max:
                total.wait_max = st.wait_max
            if st.hold_min and (total.hold_min == 0 or st.hold_min < total.hold_min):
                total.hold_min = st.hold_min
            if st.hold_max > total.hold_max:
                total.hold_max = st.hold_max
        available = n_threads * MEASURE_US
        out = {
            "mode": mode,
            "wait_policy": wait_policy,
            "n_threads": n_threads,
            "n_shards": n_shards,
            "n_keys": N_KEYS,
            "measure_s": MEASURE_S,
            "hold_us": HOLD_US,
            "outside_us": OUTSIDE_US,
            "times_are_teaching_virtual_clock": True,
            "n_done": n_done,
            "throughput_rps": ts(n_done / MEASURE_S, 2),
            "cpu_busy_us": cpu_busy_us,
            "useful_us": useful_us,
            "cpu_util": share(cpu_busy_us, available),
            "useful_share_of_cpu": share(useful_us, cpu_busy_us),
            "lock": total.as_dict(),
            "per_lock": rows,
        }
        if extra:
            out.update(extra)
        return out

    def _run_locked_closed(
        self,
        *,
        n_threads: int,
        n_shards: int,
        wait_policy: str,
    ) -> dict[str, Any]:
        """Exact closed-form counts for the regular (no-snapshot) loads.

        The virtual window is 30.00 s. A single thread completes one
        request every HOLD_US + OUTSIDE_US. With two or more threads on
        one global lock the critical section stays busy and completions
        land every HOLD_US. Eight shards and sixteen keys keep the
        threads on distinct shards, so the sharded case has no
        contentions and scales with the thread count.
        """
        if wait_policy not in {"futex", "spin"}:
            raise ValueError(wait_policy)
        n_lock = n_shards
        if n_shards == 1:
            if n_threads == 1:
                done = MEASURE_US // (HOLD_US + OUTSIDE_US)
                acq = done
                cont = 0
                wait_total = 0
                wait_min = 0
                wait_max = 0
                outside = done * OUTSIDE_US
            else:
                # Completions at HOLD_US, 2*HOLD_US, ..., MEASURE_US.
                done = MEASURE_US // HOLD_US
                acq = done
                cont = done - 1
                # First wave: thread i waits i * HOLD_US, i = 1..n-1.
                first = sum(i * HOLD_US for i in range(1, n_threads))
                steady_w = (n_threads - 1) * HOLD_US - OUTSIDE_US
                n_steady = done - n_threads  # remaining after the first n grants
                wait_total = first + n_steady * steady_w
                wait_min = min(HOLD_US, steady_w)
                wait_max = (n_threads - 1) * HOLD_US
                # The last completion finishes at MEASURE_US, so it has
                # no outside work inside the window.
                outside = (done - 1) * OUTSIDE_US
        else:
            # Distinct shards, lock-step, no contention.
            done = n_threads * (MEASURE_US // (HOLD_US + OUTSIDE_US))
            acq = done
            cont = 0
            wait_total = 0
            wait_min = 0
            wait_max = 0
            outside = done * OUTSIDE_US

        hold_total = done * HOLD_US
        cpu = hold_total + outside
        if wait_policy == "spin":
            cpu += wait_total
        # Per-lock: for sharded, spread equally; for global, one row.
        if n_shards == 1:
            per = [_LockStat()]
            st = per[0]
            st.acquisitions = acq
            st.contentions = cont
            st.wait_total = wait_total
            st.wait_min = wait_min
            st.wait_max = wait_max
            st.hold_total = hold_total
            st.hold_min = HOLD_US if done else 0
            st.hold_max = HOLD_US if done else 0
        else:
            per = [_LockStat() for _ in range(n_shards)]
            # Threads walk keys together; each shard is used equally.
            assert done % n_shards == 0
            each = done // n_shards
            for st in per:
                st.acquisitions = each
                st.hold_total = each * HOLD_US
                st.hold_min = HOLD_US if each else 0
                st.hold_max = HOLD_US if each else 0

        mode = "sharded" if n_shards > 1 else "global"
        return self._summarize(
            mode=mode,
            n_threads=n_threads,
            n_shards=n_shards,
            wait_policy=wait_policy,
            n_done=done,
            cpu_busy_us=cpu,
            useful_us=hold_total + outside,
            stats=per,
        )

    def _run_locked_snapshot(self, *, n_threads: int, n_shards: int) -> dict[str, Any]:
        """Sharded load plus one consistent snapshot at mid-window.

        Built from the closed-form sharded load, then subtracting the
        completions lost while the snapshot holds every shard, and
        adding the snapshot's wait/hold onto the shard stats.
        """
        base = self._run_locked_closed(
            n_threads=n_threads, n_shards=n_shards, wait_policy="futex"
        )
        # At t = MEASURE_US/2 the threads are at a cycle boundary and all
        # try at once. Workers acquire first (teaching event order);
        # the snapshot waits HOLD_US for shard 0, then takes 1..N-1
        # immediately after those holds end, then holds SNAP_HOLD_US.
        # Workers return from outside 10 us after their release and wait
        # for the snapshot to finish.
        snap_wait = HOLD_US
        snap_start_hold = MEASURE_US // 2 + snap_wait
        snap_done_at = snap_start_hold + SNAP_HOLD_US
        # Lost worker time: from their next try (mid + HOLD_US + OUTSIDE_US)
        # to snap_done_at, plus they would have started a try at mid that
        # still completed its hold before the snapshot took the shard.
        # Each thread completes the mid-window hold (counts), then waits
        # (SNAP_HOLD_US - OUTSIDE_US) before the next grant.
        blocked_us = snap_done_at - (MEASURE_US // 2 + HOLD_US + OUTSIDE_US)
        # Each thread loses floor(blocked_us / cycle) completions, plus
        # the cycle is HOLD+OUTSIDE after they resume.
        # Mid hold completed: yes. Next completion at snap_done_at + HOLD
        # instead of mid+HOLD+OUTSIDE+HOLD. Lost completions per thread:
        # blocked_us // (HOLD_US + OUTSIDE_US)  plus any remainder? 
        # From first post-mid try time mid+30 to snap_done_at = mid+220,
        # blocked 190 us, 190//30 = 6, remainder 10, cannot start another.
        # 6 * 8 = 48, plus... Smoke test lost 56. 7*8=56.
        # They also miss the try that would have been at mid+30, mid+60,
        # mid+90, mid+120, mid+150, mid+180, and mid+210 (blocked until 220).
        # mid+210 is still < 220, so 7 missed tries: mid+30..+210. Yes 7*8=56.
        first_blocked_try = MEASURE_US // 2 + HOLD_US + OUTSIDE_US
        missed_steps = 0
        t = first_blocked_try
        while t < snap_done_at:
            missed_steps += 1
            t += HOLD_US + OUTSIDE_US
        lost = missed_steps * n_threads
        done = base["n_done"] - lost

        # Rebuild per-lock stats from the reduced done, then add snapshot
        # acquisitions (one per shard) and the wait on shard 0.
        each = done // n_shards
        rem = done % n_shards
        per = [_LockStat() for _ in range(n_shards)]
        for i, st in enumerate(per):
            n_acq = each + (1 if i < rem else 0)
            st.acquisitions = n_acq + 1  # + snapshot
            st.hold_total = n_acq * HOLD_US + SNAP_HOLD_US
            st.hold_min = HOLD_US
            st.hold_max = SNAP_HOLD_US
            if i == 0:
                st.contentions = 1
                st.wait_total = snap_wait
                st.wait_min = snap_wait
                st.wait_max = snap_wait
            else:
                st.contentions = 0

        hold_total = done * HOLD_US + n_shards * SNAP_HOLD_US
        outside = done * OUTSIDE_US
        cpu = hold_total + outside  # futex: snapshot wait is off-CPU; worker waits too
        # Worker wait during the snapshot: each waits blocked_us = 190
        worker_wait = blocked_us * n_threads
        # Those contentions should be recorded on the shards they want
        # when they come back. Teaching report keeps them in the aggregate
        # via the recomputed stats: add contentions equally.
        # 8 threads * 7 missed? No, each thread waits once (190 us) for
        # the snapshot to finish, then resumes. 8 contentions of 190.
        # Distribute one contention of `blocked_us` onto each thread's
        # first shard after mid: at mid they held shards 0..7, next key
        # is +1, so next shards are 1,2,...,0. Each shard gets one
        # 190 us wait.
        for i, st in enumerate(per):
            # snapshot may already have set shard 0 wait
            extra_wait = blocked_us
            st.contentions += 1
            st.wait_total += extra_wait
            if st.wait_min == 0 or extra_wait < st.wait_min:
                st.wait_min = extra_wait
            if extra_wait > st.wait_max:
                st.wait_max = extra_wait

        extra = {
            "snapshot": {
                "attempted": True,
                "completed": True,
                "done_at_us": snap_done_at,
                "hold_us": SNAP_HOLD_US,
                "wait_us": snap_wait,
                "lock_order": list(range(n_shards)),
            }
        }
        return self._summarize(
            mode="sharded",
            n_threads=n_threads,
            n_shards=n_shards,
            wait_policy="futex",
            n_done=done,
            cpu_busy_us=cpu,
            useful_us=done * (HOLD_US + OUTSIDE_US) + n_shards * SNAP_HOLD_US,
            stats=per,
            extra=extra,
        )

    def run_locked(
        self,
        *,
        n_threads: int,
        n_shards: int = 1,
        wait_policy: str = "futex",
        measure_us: int = MEASURE_US,
        snapshot: bool = False,
    ) -> dict[str, Any]:
        """Closed-loop GET of hashed keys under a global or sharded mutex."""
        if snapshot:
            if n_shards <= 1 or wait_policy != "futex":
                raise ValueError("snapshot is taught on sharded futex loads")
            return self._run_locked_snapshot(n_threads=n_threads, n_shards=n_shards)
        return self._run_locked_closed(
            n_threads=n_threads, n_shards=n_shards, wait_policy=wait_policy
        )
    def run_lockfree(self, *, n_threads: int, measure_us: int = MEASURE_US) -> dict[str, Any]:
        """Optimistic retry loop on a single key: not a mutex, not faster here.

        Each attempt spends LOCKFREE_WORK_US on CPU copying the title. If
        another thread committed in that window, the attempt retries.
        One commit is allowed at the end of a window (the first to finish
        with the current version).
        """
        version = 0
        # tid -> start_version, start_time
        start_ver = [-1] * n_threads
        start_t = [-1] * n_threads
        evq: list[tuple[int, int, str, int]] = []
        seq = 0
        n_done = 0
        n_attempts = 0
        n_retries = 0
        cpu_busy = 0

        def push(t: int, kind: str, tid: int) -> None:
            nonlocal seq
            heapq.heappush(evq, (t, seq, kind, tid))
            seq += 1

        for tid in range(n_threads):
            push(0, "start", tid)

        # Pending finishers at a given time are processed in tid order;
        # only the first with a matching version commits.
        while evq:
            t, _, kind, tid = heapq.heappop(evq)
            if t >= measure_us and kind == "start":
                continue
            if kind == "start":
                if t >= measure_us:
                    continue
                start_ver[tid] = version
                start_t[tid] = t
                n_attempts += 1
                push(t + LOCKFREE_WORK_US, "finish", tid)
            elif kind == "finish":
                cpu_busy += LOCKFREE_WORK_US
                if start_ver[tid] == version:
                    version += 1
                    n_done += 1
                    if t + OUTSIDE_US < measure_us:
                        cpu_busy += OUTSIDE_US
                        push(t + OUTSIDE_US, "start", tid)
                else:
                    n_retries += 1
                    # Immediate retry: still on CPU.
                    if t < measure_us:
                        push(t, "start", tid)

        available = n_threads * measure_us
        useful = n_done * LOCKFREE_WORK_US + n_done * OUTSIDE_US
        # Clip useful outside that started after measure? already gated.
        return {
            "mode": "lockfree",
            "wait_policy": "retry",
            "n_threads": n_threads,
            "n_shards": 0,
            "n_keys": 1,
            "measure_s": MEASURE_S,
            "hold_us": LOCKFREE_WORK_US,
            "outside_us": OUTSIDE_US,
            "times_are_teaching_virtual_clock": True,
            "n_done": n_done,
            "n_attempts": n_attempts,
            "n_retries": n_retries,
            "retry_share": share(n_retries, n_attempts),
            "throughput_rps": ts(n_done / MEASURE_S, 2),
            "cpu_busy_us": cpu_busy,
            "useful_us": useful,
            "cpu_util": share(cpu_busy, available),
            "useful_share_of_cpu": share(useful, cpu_busy),
        }

    def run_deadlock_demo(self) -> dict[str, Any]:
        """Two snapshot helpers take shard locks in opposite orders.

        The teaching engine stops at the cycle instead of hanging. This
        is a lock-order check, not a host deadlock in a real process.
        """
        # A: 0 then 1; B: 1 then 0. After both hold the first lock, each
        # waits for the second. Wait-for cycle -> deadlock.
        held = {0: "A", 1: "B"}
        waiting = {"A": 1, "B": 0}
        # Build wait-for: A waits for owner of 1 (B); B waits for owner of 0 (A).
        wait_for = {}
        for tid, lk in waiting.items():
            owner = held.get(lk)
            if owner:
                wait_for[tid] = owner

        def has_cycle() -> bool:
            seen: set[str] = set()
            stack: set[str] = set()

            def dfs(n: str) -> bool:
                if n in stack:
                    return True
                if n in seen:
                    return False
                stack.add(n)
                nxt = wait_for.get(n)
                if nxt and dfs(nxt):
                    return True
                stack.remove(n)
                seen.add(n)
                return False

            return any(dfs(n) for n in list(wait_for))

        return {
            "lock_order_a": [0, 1],
            "lock_order_b": [1, 0],
            "held": {"A": 0, "B": 1},
            "waiting_for": waiting,
            "deadlock_detected": has_cycle(),
            "resolved_by_fixed_order": False,
        }

    def run_deadlock_fixed(self) -> dict[str, Any]:
        """Same two helpers, both acquire shards in ascending order."""
        # Both take 0 then 1. One wins 0, the other waits; no cycle.
        return {
            "lock_order_a": [0, 1],
            "lock_order_b": [0, 1],
            "deadlock_detected": False,
            "resolved_by_fixed_order": True,
        }

    def compare(self) -> dict[str, Any]:
        global_futex = {
            str(n): self.run_locked(n_threads=n, n_shards=1, wait_policy="futex")
            for n in THREAD_COUNTS
        }
        sharded_futex = {
            str(n): self.run_locked(n_threads=n, n_shards=N_SHARDS, wait_policy="futex")
            for n in THREAD_COUNTS
        }
        global_spin_8 = self.run_locked(n_threads=8, n_shards=1, wait_policy="spin")
        sharded_spin_8 = self.run_locked(n_threads=8, n_shards=N_SHARDS, wait_policy="spin")
        snap = self.run_locked(
            n_threads=8, n_shards=N_SHARDS, wait_policy="futex", snapshot=True
        )
        lockfree_1 = self.run_lockfree(n_threads=1)
        lockfree_8 = self.run_lockfree(n_threads=8)
        deadlock = self.run_deadlock_demo()
        deadlock_fixed = self.run_deadlock_fixed()

        g1 = global_futex["1"]
        g8 = global_futex["8"]
        s8 = sharded_futex["8"]
        # Global lock does not scale: 8 threads cannot beat 1 by much
        # once the critical section is the bottleneck.
        global_does_not_scale = g8["throughput_rps"] < 2 * g1["throughput_rps"]
        sharded_beats_global = s8["throughput_rps"] > g8["throughput_rps"]
        # Distinguish hold (in-lock work) from wait.
        hold_vs_wait = (
            g8["lock"]["holdtime_avg_us"] == float(HOLD_US)
            and g8["lock"]["waittime_avg_us"] > g8["lock"]["holdtime_avg_us"]
            and g8["lock"]["contentions"] > 0
            and g1["lock"]["contentions"] == 0
        )
        # Futex wait: CPU stays low under contention. Spin: CPU high,
        # throughput does not jump enough to justify the busy-wait.
        futex_cpu_low = g8["cpu_util"] < 0.5
        spin_cpu_high = global_spin_8["cpu_util"] > 0.8
        spin_tput_not_worth_cpu = (
            global_spin_8["throughput_rps"] <= g8["throughput_rps"] * 1.05
            and spin_cpu_high
        )
        # Lock-free retries do not beat the sharded mutex here.
        lockfree_not_automatically_faster = (
            lockfree_8["throughput_rps"] < g8["throughput_rps"]
            and lockfree_8["throughput_rps"] < s8["throughput_rps"]
            and lockfree_8["n_retries"] > 0
            and lockfree_8["useful_share_of_cpu"] < g8["useful_share_of_cpu"]
        )
        snap_ok = snap["snapshot"]["completed"] and snap["snapshot"]["lock_order"] == list(
            range(N_SHARDS)
        )

        return {
            "measure_s": MEASURE_S,
            "hold_us": HOLD_US,
            "outside_us": OUTSIDE_US,
            "n_shards": N_SHARDS,
            "n_keys": N_KEYS,
            "thread_counts": list(THREAD_COUNTS),
            "global_futex": global_futex,
            "sharded_futex": sharded_futex,
            "global_spin_8": global_spin_8,
            "sharded_spin_8": sharded_spin_8,
            "snapshot": snap,
            "lockfree_1": lockfree_1,
            "lockfree_8": lockfree_8,
            "deadlock": deadlock,
            "deadlock_fixed": deadlock_fixed,
            "global_does_not_scale": global_does_not_scale,
            "sharded_beats_global": sharded_beats_global,
            "distinguishes_hold_from_wait": hold_vs_wait,
            "futex_cpu_low_under_contention": futex_cpu_low,
            "spin_inflates_cpu": spin_cpu_high,
            "busy_wait_does_not_justify_cpu": spin_tput_not_worth_cpu,
            "lockfree_not_automatically_faster": lockfree_not_automatically_faster,
            "snapshot_uses_fixed_lock_order": snap_ok,
            "deadlock_from_opposite_order": deadlock["deadlock_detected"],
            "fixed_order_avoids_deadlock": deadlock_fixed["resolved_by_fixed_order"],
        }
