#!/usr/bin/env python3
"""Run the lesson 134 teaching lock-contention experiments and write results.json."""
from __future__ import annotations

from typing import Any

from engine import (
    HOLD_US,
    KEY_TITLE,
    MEASURE_S,
    N_KEYS,
    N_SHARDS,
    OUTSIDE_US,
    PROCESS,
    THREAD_COUNTS,
    TITLE_V1,
    LockEngine,
)


def _public_lock_run(d: dict[str, Any]) -> dict[str, Any]:
    out = {
        "mode": d["mode"],
        "wait_policy": d["wait_policy"],
        "n_threads": d["n_threads"],
        "n_shards": d["n_shards"],
        "n_keys": d.get("n_keys"),
        "measure_s": d["measure_s"],
        "hold_us": d["hold_us"],
        "outside_us": d["outside_us"],
        "times_are_teaching_virtual_clock": d["times_are_teaching_virtual_clock"],
        "n_done": d["n_done"],
        "throughput_rps": d["throughput_rps"],
        "cpu_util": d["cpu_util"],
        "useful_share_of_cpu": d["useful_share_of_cpu"],
        "cpu_busy_us": d["cpu_busy_us"],
        "useful_us": d["useful_us"],
    }
    if "lock" in d:
        out["lock"] = d["lock"]
    for k in ("n_attempts", "n_retries", "retry_share", "snapshot"):
        if k in d:
            out[k] = d[k]
    return out


def run() -> dict[str, Any]:
    eng = LockEngine()
    cmp = eng.compare()
    acceptance_hold_wait = cmp["distinguishes_hold_from_wait"]
    acceptance_no_busywait = (
        cmp["futex_cpu_low_under_contention"]
        and cmp["spin_inflates_cpu"]
        and cmp["busy_wait_does_not_justify_cpu"]
    )
    pitfall = cmp["lockfree_not_automatically_faster"]
    tradeoff = (
        cmp["sharded_beats_global"]
        and cmp["snapshot_uses_fixed_lock_order"]
        and cmp["deadlock_from_opposite_order"]
        and cmp["fixed_order_avoids_deadlock"]
    )
    return {
        "engine": "LockEngine",
        "process": PROCESS,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "measure_s": MEASURE_S,
        "hold_us": HOLD_US,
        "outside_us": OUTSIDE_US,
        "n_shards": N_SHARDS,
        "n_keys": N_KEYS,
        "thread_counts": list(THREAD_COUNTS),
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_profiler_product": True,
        "not_a_real_lock_product": True,
        "not_host_perf": True,
        "not_host_gxx": True,
        "not_host_lock_stat": True,
        "not_host_futex": True,
        "times_are_teaching_virtual_clock": True,
        "practice": {
            "global_futex": {k: _public_lock_run(v) for k, v in cmp["global_futex"].items()},
            "sharded_futex": {k: _public_lock_run(v) for k, v in cmp["sharded_futex"].items()},
        },
        "wait_policy": {
            "global_futex_8": _public_lock_run(cmp["global_futex"]["8"]),
            "global_spin_8": _public_lock_run(cmp["global_spin_8"]),
            "sharded_spin_8": _public_lock_run(cmp["sharded_spin_8"]),
        },
        "snapshot": _public_lock_run(cmp["snapshot"]),
        "lockfree_1": _public_lock_run(cmp["lockfree_1"]),
        "lockfree_8": _public_lock_run(cmp["lockfree_8"]),
        "deadlock": cmp["deadlock"],
        "deadlock_fixed": cmp["deadlock_fixed"],
        "flags": {
            "global_does_not_scale": cmp["global_does_not_scale"],
            "sharded_beats_global": cmp["sharded_beats_global"],
            "distinguishes_hold_from_wait": cmp["distinguishes_hold_from_wait"],
            "futex_cpu_low_under_contention": cmp["futex_cpu_low_under_contention"],
            "spin_inflates_cpu": cmp["spin_inflates_cpu"],
            "busy_wait_does_not_justify_cpu": cmp["busy_wait_does_not_justify_cpu"],
            "lockfree_not_automatically_faster": cmp["lockfree_not_automatically_faster"],
            "snapshot_uses_fixed_lock_order": cmp["snapshot_uses_fixed_lock_order"],
            "deadlock_from_opposite_order": cmp["deadlock_from_opposite_order"],
            "fixed_order_avoids_deadlock": cmp["fixed_order_avoids_deadlock"],
        },
        "acceptance_distinguishes_hold_from_wait": acceptance_hold_wait,
        "acceptance_avoids_busy_wait_cpu": acceptance_no_busywait,
        "pitfall_lockfree_not_always_faster": pitfall,
        "tradeoff_fine_locks_need_order": tradeoff,
    }
