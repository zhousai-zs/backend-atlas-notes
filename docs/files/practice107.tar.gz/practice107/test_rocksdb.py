#!/usr/bin/env python3
"""Acceptance checks for practice107 (RocksDBEngine)."""
from __future__ import annotations

import json
import os
import sys

from app import TITLE_V1, TITLE_V2, run_all_experiments


def main() -> int:
    data = run_all_experiments()
    out = os.path.join(os.path.dirname(__file__), "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    _assert_cf(data["cf_batch_scan_recover"])
    _assert_atomic(data["write_batch_atomic"])
    _assert_snapshot(data["snapshot_restart"])
    _assert_iter(data["iterator_lifetime"])
    _assert_cache(data["block_cache"])
    _assert_stall(data["write_stall"])
    _assert_tune(data["tuning_budget"])
    _assert_status(data["status_checked"])

    c = data["cf_batch_scan_recover"]
    a = data["write_batch_atomic"]
    s = data["snapshot_restart"]
    it = data["iterator_lifetime"]
    k = data["block_cache"]
    w = data["write_stall"]
    t = data["tuning_budget"]
    st = data["status_checked"]
    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"batch_ops={c['batch_ops']} "
        f"titles_scan={c['titles_scan_count']} "
        f"open_missing_invalid={int(c['open_missing_cf_invalid'])} "
        f"recovered={len(c['all_titles_recovered'])} "
        f"naive_dup={int(a['naive']['duplicated'])} "
        f"sync_atomic={int(a['synced_batch']['atomic_move'])} "
        f"unsync_lost={int(a['unsynced_power_loss']['batch_lost'])} "
        f"kill_atomic={int(a['unsynced_process_kill']['atomic_move'])} "
        f"snap_v1={s['snapshot_after_update']!r} "
        f"live_v2={s['live_after_update']!r} "
        f"iter_after_release={int(s['iterator_still_valid_after_release'])} "
        f"snap_lost={s['snapshots_lost_on_crash']} "
        f"snap_after={s['snapshots_after_reopen']} "
        f"reopen_v2={int(s['revised_title_after_reopen'])} "
        f"pinned_during={it['pinned_during']} "
        f"pinned_after_close={it['pinned_after_close']} "
        f"iter_end_ok={int(it['end_status_ok'])} "
        f"range={len(it['range_05_to_09'])} "
        f"cache_blocks={k['blocks']} "
        f"first_miss={k['first_scan']['misses']} "
        f"first_hit={k['first_scan']['hits']} "
        f"hot2_hit={k['hot_second']['hits']} "
        f"fill_evict={k['bulk_fill_cache_true']['evictions']} "
        f"hot_after_fill_miss={k['hot_after_fill_true']['misses']} "
        f"nofill_evict={k['bulk_fill_cache_false']['evictions']} "
        f"hot_after_nofill_hit={k['hot_after_fill_false']['hits']} "
        f"fast_stop={w['fast']['stop_count']} "
        f"fast_stop_s={w['fast']['stop_seconds']} "
        f"fast_p99={w['fast']['write_p99_s']} "
        f"slow_stop={w['slow']['stop_count']} "
        f"slow_p99={w['slow']['write_p99_s']} "
        f"cross_incomplete={int(w['cross_cf_incomplete']['titles_no_slowdown_incomplete'])} "
        f"tight_stop={t['tight']['stop_count']} "
        f"tight_stall={t['tight']['stall_count']} "
        f"tight_p99={t['tight']['write_p99_s']} "
        f"budget_stop={t['budgeted']['stop_count']} "
        f"budget_miss={t['budgeted']['misses']} "
        f"tight_miss={t['tight']['misses']} "
        f"shared_cap={t['shared_cache']['capacity']} "
        f"private_cap={t['private_caches']['capacity_total']} "
        f"status_all={int(st['all_non_ok_detected'])}"
    )
    return 0


def _assert_cf(c: dict) -> None:
    assert c["batch_ops"] == 6
    assert c["titles_scan_count"] == 3
    assert c["titles_scanned"][0][1] == "Weekly digest"
    assert not c["titles_contain_counter_key"]
    assert c["counter_keys"] == ["article:01:views", "article:02:views", "article:03:views"]
    assert c["open_missing_cf_invalid"]
    assert "titles" in c["open_missing_cf_status"]
    assert c["all_titles_recovered"] == ["Weekly digest", "Product update", "Community notes"]
    assert c["listed_cfs"] == ["default", "titles", "counters"]
    assert c["iterator_status_ok"]


def _assert_atomic(a: dict) -> None:
    assert a["naive"]["duplicated"]
    assert a["naive"]["old_value"] == TITLE_V1
    assert a["synced_batch"]["atomic_move"]
    assert a["unsynced_power_loss"]["batch_lost"]
    assert a["unsynced_process_kill"]["atomic_move"]


def _assert_snapshot(s: dict) -> None:
    assert s["snapshot_after_update"] == TITLE_V1
    assert s["live_after_update"] == TITLE_V2
    assert s["iterator_on_snapshot"] == TITLE_V1
    assert s["get_released_snapshot_invalid"]
    assert s["iterator_still_valid_after_release"]
    assert s["new_iterator_after_release_invalid"]
    assert s["snapshots_before_crash"] == 1
    assert s["snapshots_lost_on_crash"] == 1
    assert s["snapshots_after_reopen"] == 0
    assert s["revised_title_after_reopen"]
    assert not s["old_title_after_reopen"]
    assert s["stale_snapshot_after_reopen_invalid"]
    assert s["value_after_reopen"] == TITLE_V2


def _assert_iter(it: dict) -> None:
    assert it["keys_written"] == 16
    assert it["range_count"] == 16
    assert it["first_key"] == "article:01:title"
    assert it["end_valid"] is False
    assert it["end_status_ok"] is True
    assert it["pinned_during"] > 0
    assert it["pinned_after_close"] == 0
    assert it["open_iterators_during"] == 1
    assert it["open_iterators_after_close"] == 0
    assert it["range_05_to_09"] == [
        "article:05:title",
        "article:06:title",
        "article:07:title",
        "article:08:title",
    ]


def _assert_cache(k: dict) -> None:
    assert k["keys"] == 40
    assert k["sst_files"] == 8
    assert k["blocks"] == 16
    assert k["first_scan"]["misses"] == 16
    assert k["first_scan"]["hits"] == 24
    assert k["second_scan"]["misses"] == 16
    assert k["second_scan"]["hits"] == 24
    assert k["hot_second"]["hits"] == 8
    assert k["hot_second"]["misses"] == 0
    assert k["bulk_fill_cache_true"]["evictions"] > 0
    assert k["hot_after_fill_true"]["misses"] > 0
    assert k["bulk_fill_cache_false"]["evictions"] == 0
    assert k["hot_after_fill_false"]["hits"] == 8
    assert k["hot_after_fill_false"]["misses"] == 0
    assert k["hot_after_fill_false"]["seconds"] < k["hot_after_fill_true"]["seconds"]


def _assert_stall(w: dict) -> None:
    assert w["fast"]["stop_count"] >= 1
    assert w["fast"]["stop_seconds"] > 0
    assert w["slow"]["stop_count"] == 0
    assert w["slow"]["stall_count"] == 0
    assert w["slow"]["write_p99_s"] == 0.15
    assert w["fast"]["write_p99_s"] > w["slow"]["write_p99_s"]
    p = w["cross_cf_incomplete"]
    assert p["titles_no_slowdown_incomplete"]
    assert p["titles_absent_after_incomplete"]
    assert p["titles_blocking_ok"]
    assert p["titles_value_after_blocking"] == TITLE_V2
    assert "immutable memtables" in p["pressure_reason"]


def _assert_tune(t: dict) -> None:
    assert t["tight"]["stop_count"] > 0
    assert t["tight"]["write_p99_s"] > 0
    assert t["budgeted"]["stop_count"] == 0
    assert t["budgeted"]["stall_count"] == 0
    assert t["budgeted"]["misses"] < t["tight"]["misses"]
    assert t["budgeted"]["read_two_passes_s"] < t["tight"]["read_two_passes_s"]
    assert t["shared_cache"]["capacity"] == 300
    assert t["private_caches"]["capacity_total"] == 600
    assert t["private_caches"]["usage_total"] > t["shared_cache"]["usage"]


def _assert_status(st: dict) -> None:
    assert st["get_missing_not_found"]
    assert st["bad_cf_invalid"]
    assert st["open_missing_cf_invalid"]
    assert st["released_snapshot_invalid"]
    assert st["iterator_end_status_ok"]
    assert st["all_non_ok_detected"]


if __name__ == "__main__":
    sys.exit(main())
