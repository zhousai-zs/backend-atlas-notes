#!/usr/bin/env python3
"""In-process teaching RocksDB-like kernel for g-rocksdb.

This is not RocksDB, not Redis, and not a network service. It models a
subset of the RocksDB integration API: Status, DB, Column Family,
WriteBatch, snapshot, iterator, a teaching block cache, write stall,
and restart recovery from a durable WAL. Teaching SST files are ordered
record lists split into fixed-count blocks; they are not RocksDB
block-based 4KiB tables, and there is no bloom, compression, MANIFEST
log, Checkpoint, transaction, merge operator, or prefix seek.
"""
from __future__ import annotations

import json
import os
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Optional


KIND_PUT = "put"
KIND_DEL = "del"

DEFAULT_CF = "default"


# --------------------------------------------------------------------------- Status


class Status:
    """Teaching stand-in for rocksdb::Status. Most APIs return one."""

    def __init__(self, code: str = "ok", message: str = "", value: Optional[str] = None) -> None:
        self.code = code
        self.message = message
        self.value = value

    def ok(self) -> bool:
        return self.code == "ok"

    def IsNotFound(self) -> bool:
        return self.code == "not_found"

    def IsIncomplete(self) -> bool:
        return self.code == "incomplete"

    def IsInvalidArgument(self) -> bool:
        return self.code == "invalid_argument"

    def ToString(self) -> str:
        if self.code == "ok":
            return "OK"
        if self.message:
            return f"{self.code}: {self.message}"
        return self.code

    @staticmethod
    def OK(value: Optional[str] = None) -> "Status":
        return Status("ok", value=value)

    @staticmethod
    def NotFound(message: str = "") -> "Status":
        return Status("not_found", message)

    @staticmethod
    def Incomplete(message: str = "") -> "Status":
        return Status("incomplete", message)

    @staticmethod
    def InvalidArgument(message: str = "") -> "Status":
        return Status("invalid_argument", message)

    @staticmethod
    def IOError(message: str = "") -> "Status":
        return Status("io_error", message)


# --------------------------------------------------------------------------- options


@dataclass
class ColumnFamilyOptions:
    write_buffer_size: int = 200
    max_write_buffer_number: int = 3
    level0_file_num_compaction_trigger: int = 4
    level0_slowdown_writes_trigger: int = 8
    level0_stop_writes_trigger: int = 12
    delayed_write_rate: int = 400
    records_per_block: int = 4


@dataclass
class Options(ColumnFamilyOptions):
    create_if_missing: bool = True
    error_if_exists: bool = False
    # Teaching cache capacity in bytes. Real RocksDB default is 32MB
    # (8MB before 8.2); this engine uses a small budget so experiments fit.
    block_cache_capacity: int = 256
    # If None, the DB creates its own cache. Pass the same BlockCache to
    # share one capacity across column families / DB instances.
    block_cache: Optional["BlockCache"] = None
    compaction_bandwidth: int = 800
    auto_compact: bool = True
    # Per-iterator / Get miss cost in simulated seconds (block cache miss).
    block_read_s: float = 0.001
    block_hit_s: float = 0.00001
    strict_capacity_limit: bool = False


@dataclass
class WriteOptions:
    sync: bool = False
    no_slowdown: bool = False
    disableWAL: bool = False


@dataclass
class ReadOptions:
    snapshot: Optional["Snapshot"] = None
    fill_cache: bool = True
    iterate_upper_bound: Optional[str] = None
    iterate_lower_bound: Optional[str] = None


@dataclass
class WriteBatch:
    ops: list[dict[str, str]] = field(default_factory=list)

    def Put(self, key: str, value: str, cf: str = DEFAULT_CF) -> None:
        self.ops.append({"op": KIND_PUT, "cf": cf, "key": key, "value": value})

    def Delete(self, key: str, cf: str = DEFAULT_CF) -> None:
        self.ops.append({"op": KIND_DEL, "cf": cf, "key": key, "value": ""})

    def nbytes(self) -> int:
        return sum(len(o["key"]) + len(o.get("value") or "") for o in self.ops)


# --------------------------------------------------------------------------- clock, log, durable file


class Clock:
    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self.live = bool(live)
        self._anchor = time.monotonic()
        self._offset = float(start)
        self.t = float(start)

    def now(self) -> float:
        if self.live:
            return self._offset + (time.monotonic() - self._anchor)
        return self.t

    def advance(self, seconds: float) -> None:
        if self.live:
            raise RuntimeError("live clock cannot be advanced")
        self.t = round(self.t + float(seconds), 10)


class VisualLog:
    def __init__(self, clock: Clock) -> None:
        self.clock = clock
        self.events: list[dict[str, Any]] = []

    def emit(self, kind: str, **fields: Any) -> None:
        ev: dict[str, Any] = {"t": round(self.clock.now(), 6), "kind": kind}
        ev.update(fields)
        self.events.append(ev)

    def lines(self) -> list[str]:
        out: list[str] = []
        for ev in self.events:
            kind = ev["kind"]
            rest = {k: v for k, v in ev.items() if k not in ("t", "kind")}
            payload = " ".join(f"{k}={v}" for k, v in rest.items())
            out.append(f"[t={ev['t']:.6f}] {kind} {payload}".rstrip())
        return out

    def of(self, kind: str) -> list[dict[str, Any]]:
        return [e for e in self.events if e["kind"] == kind]


class DurableFile:
    """WAL with an explicit page cache and a durable image (same model as lesson 105)."""

    def __init__(self, path: str) -> None:
        self.path = path
        self.durable = bytearray()
        self.cache = bytearray()
        self.fsync_count = 0
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)

    def write(self, data: bytes) -> None:
        if data:
            self.cache.extend(data)

    def fsync(self) -> None:
        if self.cache:
            self.durable.extend(self.cache)
            self.cache.clear()
        self.fsync_count += 1
        directory = os.path.dirname(self.path) or "."
        os.makedirs(directory, exist_ok=True)
        with open(self.path, "wb") as fh:
            fh.write(self.durable)
            fh.flush()
            os.fsync(fh.fileno())

    def persist_cached(self) -> None:
        """Process-kill recovery: the OS page cache is still there."""
        with open(self.path, "wb") as fh:
            fh.write(self.durable)
            fh.write(self.cache)
            fh.flush()

    def power_loss(self) -> None:
        self.cache = bytearray()

    def load_from_disk(self, durable_only: bool = True) -> None:
        if not os.path.exists(self.path):
            self.durable = bytearray()
            self.cache = bytearray()
            return
        with open(self.path, "rb") as fh:
            blob = fh.read()
        if durable_only:
            self.durable = bytearray(blob)
            self.cache = bytearray()
        else:
            # Caller already decided what is on disk.
            self.durable = bytearray(blob)
            self.cache = bytearray()

    def durable_bytes(self) -> bytes:
        return bytes(self.durable)

    def cached_bytes(self) -> bytes:
        return bytes(self.durable) + bytes(self.cache)


# --------------------------------------------------------------------------- records, memtable, SST, cache


@dataclass
class Record:
    key: str
    value: str
    seq: int
    kind: str = KIND_PUT

    def nbytes(self) -> int:
        return len(self.key) + len(self.value)


class MemTable:
    def __init__(self) -> None:
        self.records: list[Record] = []
        self.sealed = False

    def put(self, rec: Record) -> None:
        self.records.append(rec)

    def nbytes(self) -> int:
        return sum(r.nbytes() for r in self.records)

    def get(self, key: str, read_seq: int) -> Optional[Record]:
        found: Optional[Record] = None
        for rec in self.records:
            if rec.key == key and rec.seq <= read_seq:
                if found is None or rec.seq >= found.seq:
                    found = rec
        return found

    def items(self, read_seq: int) -> dict[str, Record]:
        out: dict[str, Record] = {}
        for rec in self.records:
            if rec.seq <= read_seq:
                prev = out.get(rec.key)
                if prev is None or rec.seq >= prev.seq:
                    out[rec.key] = rec
        return out


@dataclass
class Block:
    block_id: str
    records: list[Record]
    nbytes: int

    def get(self, key: str, read_seq: int) -> Optional[Record]:
        found: Optional[Record] = None
        for rec in self.records:
            if rec.key == key and rec.seq <= read_seq:
                if found is None or rec.seq >= found.seq:
                    found = rec
        return found


class SST:
    def __init__(self, file_no: int, level: int, records: list[Record], records_per_block: int) -> None:
        self.file_no = file_no
        self.level = level
        self.records = list(records)
        self.records.sort(key=lambda r: (r.key, r.seq))
        self.nbytes = sum(r.nbytes() for r in self.records)
        self.smallest = self.records[0].key if self.records else ""
        self.largest = self.records[-1].key if self.records else ""
        self.blocks: list[Block] = []
        chunk = max(int(records_per_block), 1)
        for i in range(0, len(self.records), chunk):
            recs = self.records[i : i + chunk]
            bid = f"sst{file_no}-b{i // chunk}"
            self.blocks.append(Block(bid, recs, sum(r.nbytes() for r in recs)))

    def covers(self, key: str) -> bool:
        if not self.records:
            return False
        return self.smallest <= key <= self.largest

    def block_for(self, key: str) -> Optional[Block]:
        for blk in self.blocks:
            if not blk.records:
                continue
            if blk.records[0].key <= key <= blk.records[-1].key:
                return blk
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "file_no": self.file_no,
            "level": self.level,
            "records": [
                {"key": r.key, "value": r.value, "seq": r.seq, "kind": r.kind}
                for r in self.records
            ],
        }

    @staticmethod
    def from_dict(data: dict[str, Any], records_per_block: int) -> "SST":
        recs = [
            Record(r["key"], r["value"], int(r["seq"]), r.get("kind", KIND_PUT))
            for r in data["records"]
        ]
        return SST(int(data["file_no"]), int(data["level"]), recs, records_per_block)


class BlockCache:
    """Teaching LRU cache of uncompressed SST blocks. Not RocksDB LRUCache."""

    def __init__(self, capacity: int, strict_capacity_limit: bool = False) -> None:
        self.capacity = int(capacity)
        self.strict_capacity_limit = bool(strict_capacity_limit)
        self._lru: OrderedDict[str, Block] = OrderedDict()
        self._pinned: dict[str, int] = {}
        self.hits = 0
        self.misses = 0
        self.add = 0
        self.add_failures = 0
        self.evictions = 0
        self.bytes_read = 0
        self.bytes_write = 0

    def usage(self) -> int:
        return sum(b.nbytes for b in self._lru.values())

    def pinned_usage(self) -> int:
        return sum(self._lru[k].nbytes for k, n in self._pinned.items() if n > 0 and k in self._lru)

    def lookup(self, block_id: str) -> Optional[Block]:
        blk = self._lru.get(block_id)
        if blk is None:
            self.misses += 1
            return None
        self._lru.move_to_end(block_id)
        self.hits += 1
        self.bytes_read += blk.nbytes
        return blk

    def insert(self, blk: Block) -> bool:
        if blk.block_id in self._lru:
            self._lru.move_to_end(blk.block_id)
            return True
        if self.usage() + blk.nbytes > self.capacity:
            if not self._evict_until(blk.nbytes):
                self.add_failures += 1
                return False
        self._lru[blk.block_id] = blk
        self.add += 1
        self.bytes_write += blk.nbytes
        return True

    def pin(self, block_id: str) -> None:
        if block_id in self._lru:
            self._pinned[block_id] = self._pinned.get(block_id, 0) + 1

    def unpin(self, block_id: str) -> None:
        n = self._pinned.get(block_id, 0)
        if n <= 1:
            self._pinned.pop(block_id, None)
        else:
            self._pinned[block_id] = n - 1

    def _evict_until(self, need: int) -> bool:
        # Evict unpinned LRU entries first.
        for bid in list(self._lru.keys()):
            if self.usage() + need <= self.capacity:
                return True
            if self._pinned.get(bid, 0) > 0:
                continue
            self._lru.pop(bid, None)
            self.evictions += 1
        if self.usage() + need <= self.capacity:
            return True
        if self.strict_capacity_limit:
            return False
        # Default RocksDB behavior: allow insertion past capacity when
        # remaining entries are pinned, rather than failing the read.
        return True

    def snapshot_stats(self) -> dict[str, int]:
        return {
            "capacity": self.capacity,
            "usage": self.usage(),
            "pinned_usage": self.pinned_usage(),
            "hits": self.hits,
            "misses": self.misses,
            "add": self.add,
            "add_failures": self.add_failures,
            "evictions": self.evictions,
            "bytes_read": self.bytes_read,
            "bytes_write": self.bytes_write,
        }


# --------------------------------------------------------------------------- snapshot, handle, iterator


class Snapshot:
    def __init__(self, seq: int, snap_id: int) -> None:
        self.seq = seq
        self.snap_id = snap_id
        self.released = False


class ColumnFamilyHandle:
    def __init__(self, name: str, cf_id: int) -> None:
        self.name = name
        self.id = cf_id
        self.dropped = False
        self.destroyed = False


class Iterator:
    """Forward iterator over one column family at a point-in-time seq."""

    def __init__(
        self,
        db: "RocksDBEngine",
        cf: str,
        read_seq: int,
        fill_cache: bool,
        upper: Optional[str],
        lower: Optional[str],
    ) -> None:
        self._db = db
        self.cf = cf
        self.read_seq = read_seq
        self.fill_cache = fill_cache
        self.upper = upper
        self.lower = lower
        self._status = Status.OK()
        self._closed = False
        self._valid = False
        self._keys: list[str] = []
        self._values: dict[str, Record] = {}
        self._idx = -1
        self._pinned: list[str] = []
        self._materialize()

    def _materialize(self) -> None:
        try:
            items = self._db._visible_map(self.cf, self.read_seq, fill_cache=self.fill_cache)
        except KeyError:
            self._status = Status.InvalidArgument(f"unknown column family {self.cf}")
            self._valid = False
            return
        recs = {k: v for k, v in items.items() if v.kind != KIND_DEL}
        keys = sorted(recs.keys())
        if self.lower is not None:
            keys = [k for k in keys if k >= self.lower]
        if self.upper is not None:
            keys = [k for k in keys if k < self.upper]
        self._keys = keys
        self._values = recs

    def _pin_current(self) -> None:
        self._unpin()
        if not self._valid:
            return
        key = self._keys[self._idx]
        state = self._db.cfs.get(self.cf)
        if state is None:
            return
        for files in state.levels:
            for sst in files:
                blk = sst.block_for(key)
                if blk is None:
                    continue
                if blk.block_id not in self._db.cache._lru:
                    if not self.fill_cache:
                        continue
                    self._db.cache.insert(blk)
                self._db.cache.pin(blk.block_id)
                self._pinned.append(blk.block_id)

    def _unpin(self) -> None:
        for bid in self._pinned:
            self._db.cache.unpin(bid)
        self._pinned = []

    def SeekToFirst(self) -> None:
        if self._closed:
            self._status = Status.InvalidArgument("iterator closed")
            self._valid = False
            return
        if not self._status.ok() and self._status.IsInvalidArgument():
            self._valid = False
            return
        self._status = Status.OK()
        self._idx = 0 if self._keys else -1
        self._valid = self._idx == 0
        self._pin_current()

    def Seek(self, key: str) -> None:
        if self._closed:
            self._status = Status.InvalidArgument("iterator closed")
            self._valid = False
            return
        self._status = Status.OK()
        self._idx = 0
        while self._idx < len(self._keys) and self._keys[self._idx] < key:
            self._idx += 1
        self._valid = self._idx < len(self._keys)
        if not self._valid:
            self._idx = -1
        self._pin_current()

    def Next(self) -> None:
        if not self._valid:
            return
        self._idx += 1
        self._valid = 0 <= self._idx < len(self._keys)
        if not self._valid:
            self._idx = -1
        self._pin_current()

    def Valid(self) -> bool:
        return self._valid and self._status.ok()

    def key(self) -> str:
        if not self._valid:
            raise RuntimeError("iterator not valid")
        return self._keys[self._idx]

    def value(self) -> str:
        if not self._valid:
            raise RuntimeError("iterator not valid")
        return self._values[self._keys[self._idx]].value

    def status(self) -> Status:
        return self._status

    def close(self) -> None:
        self._unpin()
        self._closed = True
        self._valid = False
        if self in self._db._iterators:
            self._db._iterators.remove(self)


# --------------------------------------------------------------------------- column family state


class ColumnFamilyState:
    def __init__(self, name: str, cf_id: int, opts: ColumnFamilyOptions) -> None:
        self.name = name
        self.id = cf_id
        self.opts = opts
        self.active = MemTable()
        self.immutables: list[MemTable] = []
        self.levels: list[list[SST]] = [[], [], []]  # L0, L1, L2
        self.handle_count = 1

    def memtable_count(self) -> int:
        # active + immutables; RocksDB stall counts immutables waiting to flush.
        return len(self.immutables)

    def l0_count(self) -> int:
        return len(self.levels[0])

    def pending_compaction_bytes(self) -> int:
        # Teaching estimate: all L0 bytes are waiting to be compacted.
        return sum(s.nbytes for s in self.levels[0])


# --------------------------------------------------------------------------- DB


class RocksDBEngine:
    def __init__(
        self,
        path: str,
        options: Optional[Options] = None,
        clock: Optional[Clock] = None,
    ) -> None:
        self.path = path
        self.opts = options or Options()
        self.clock = clock or Clock()
        self.log = VisualLog(self.clock)
        self.cache = self.opts.block_cache or BlockCache(
            self.opts.block_cache_capacity,
            self.opts.strict_capacity_limit,
        )
        self.cfs: dict[str, ColumnFamilyState] = {}
        self.handles: dict[str, ColumnFamilyHandle] = {}
        self.last_seq = 0
        self.next_file = 1
        self.next_cf_id = 1
        self.next_snap_id = 1
        self.snapshots: list[Snapshot] = []
        self._iterators: list[Iterator] = []
        self.wal = DurableFile(os.path.join(path, "WAL"))
        self.closed = False
        self.bg_credit = 0.0
        self.stats: dict[str, Any] = {
            "user_writes": 0,
            "user_bytes": 0,
            "flush_count": 0,
            "flush_bytes": 0,
            "compact_count": 0,
            "stall_count": 0,
            "stop_count": 0,
            "stall_seconds": 0.0,
            "stop_seconds": 0.0,
            "write_latency": [],
            "get_latency": [],
            "status_checked": 0,
            "status_returned": 0,
            "incomplete_writes": 0,
            "wal_fsyncs": 0,
        }

    # ----- open / close / recover -----

    @staticmethod
    def ListColumnFamilies(path: str) -> tuple[Status, list[str]]:
        manifest = os.path.join(path, "MANIFEST.json")
        if not os.path.isdir(path) or not os.path.exists(manifest):
            return Status.IOError(f"no db at {path}"), []
        data = json.loads(open(manifest, encoding="utf-8").read())
        return Status.OK(), list(data.get("cfs", []))

    @staticmethod
    def Open(
        path: str,
        options: Optional[Options] = None,
        column_families: Optional[list[str]] = None,
        clock: Optional[Clock] = None,
        recover: str = "durable",
    ) -> tuple[Status, Optional["RocksDBEngine"]]:
        opts = options or Options()
        os.makedirs(path, exist_ok=True)
        manifest_path = os.path.join(path, "MANIFEST.json")
        exists = os.path.exists(manifest_path)
        if exists and opts.error_if_exists:
            return Status.InvalidArgument("db exists"), None
        if not exists and not opts.create_if_missing:
            return Status.InvalidArgument("db missing"), None

        db = RocksDBEngine(path, opts, clock)
        if not exists:
            db._create_cf(DEFAULT_CF)
            if column_families:
                for name in column_families:
                    if name != DEFAULT_CF:
                        db._create_cf(name)
            db._persist_manifest(fsync=True)
            db.log.emit("OPEN", path=path, created=True, cfs=list(db.cfs))
            return Status.OK(), db

        data = json.loads(open(manifest_path, encoding="utf-8").read())
        existing = list(data.get("cfs", [DEFAULT_CF]))
        requested = list(column_families) if column_families is not None else [DEFAULT_CF]
        # RW open must name every existing CF.
        missing = [n for n in existing if n not in requested]
        extra = [n for n in requested if n not in existing]
        if missing:
            return (
                Status.InvalidArgument(
                    "must specify all existing column families, missing: " + ",".join(missing)
                ),
                None,
            )
        if extra:
            return Status.InvalidArgument("unknown column families: " + ",".join(extra)), None
        st = db._recover(data, recover=recover)
        if not st.ok():
            return st, None
        db.log.emit("OPEN", path=path, created=False, cfs=list(db.cfs), last_seq=db.last_seq)
        return Status.OK(), db

    def _create_cf(self, name: str) -> ColumnFamilyHandle:
        cf_id = self.next_cf_id
        self.next_cf_id += 1
        state = ColumnFamilyState(name, cf_id, self.opts)
        self.cfs[name] = state
        handle = ColumnFamilyHandle(name, cf_id)
        self.handles[name] = handle
        return handle

    def _recover(self, data: dict[str, Any], recover: str = "durable") -> Status:
        self.last_seq = int(data.get("last_seq", 0))
        self.next_file = int(data.get("next_file", 1))
        self.next_cf_id = int(data.get("next_cf_id", 1))
        wal_flushed_seq = int(data.get("wal_flushed_seq", 0))
        for name in data.get("cfs", [DEFAULT_CF]):
            if name not in self.cfs:
                # Preserve ids if present.
                meta = (data.get("cf_meta") or {}).get(name, {})
                cf_id = int(meta.get("id", self.next_cf_id))
                self.next_cf_id = max(self.next_cf_id, cf_id + 1)
                state = ColumnFamilyState(name, cf_id, self.opts)
                self.cfs[name] = state
                self.handles[name] = ColumnFamilyHandle(name, cf_id)
            state = self.cfs[name]
            for item in (data.get("ssts") or {}).get(name, []):
                sst_path = os.path.join(self.path, item["file"])
                if not os.path.exists(sst_path):
                    continue
                payload = json.loads(open(sst_path, encoding="utf-8").read())
                sst = SST.from_dict(payload, self.opts.records_per_block)
                level = int(item.get("level", sst.level))
                while len(state.levels) <= level:
                    state.levels.append([])
                state.levels[level].append(sst)
        # Replay durable WAL after last flushed seq.
        wal_path = os.path.join(self.path, "WAL")
        if os.path.exists(wal_path):
            self.wal.load_from_disk(durable_only=(recover == "durable"))
            if recover == "process_kill":
                # Include unsynced page cache that was persisted by persist_cached.
                self.wal.load_from_disk(durable_only=False)
            blob = self.wal.durable_bytes()
            for line in blob.splitlines():
                if not line.strip():
                    continue
                rec = json.loads(line.decode("utf-8"))
                if int(rec["seq"]) <= wal_flushed_seq:
                    continue
                self._apply_ops(rec["ops"], int(rec["seq"]), from_recovery=True)
                self.last_seq = max(self.last_seq, int(rec["seq"]))
        # Snapshots are not in the manifest: they do not survive reopen.
        self.snapshots = []
        return Status.OK()

    def _persist_manifest(self, fsync: bool = True, wal_flushed_seq: Optional[int] = None) -> None:
        ssts: dict[str, list[dict[str, Any]]] = {}
        cf_meta: dict[str, dict[str, Any]] = {}
        for name, state in self.cfs.items():
            cf_meta[name] = {"id": state.id}
            items = []
            for level, files in enumerate(state.levels):
                for sst in files:
                    fname = f"sst-{name}-{sst.file_no}.json"
                    items.append({"file": fname, "level": level, "file_no": sst.file_no})
            ssts[name] = items
        flushed = wal_flushed_seq
        if flushed is None:
            flushed = self._wal_flushed_seq()
        data = {
            "cfs": list(self.cfs.keys()),
            "cf_meta": cf_meta,
            "ssts": ssts,
            "last_seq": self.last_seq,
            "next_file": self.next_file,
            "next_cf_id": self.next_cf_id,
            "wal_flushed_seq": flushed,
        }
        path = os.path.join(self.path, "MANIFEST.json")
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
            fh.flush()
            if fsync:
                os.fsync(fh.fileno())
        os.replace(tmp, path)
        if fsync:
            dirfd = os.open(self.path, os.O_DIRECTORY)
            try:
                os.fsync(dirfd)
            finally:
                os.close(dirfd)

    def _wal_flushed_seq(self) -> int:
        # Everything in memtables is still only in WAL; flushed SSTs are durable.
        seqs = []
        for state in self.cfs.values():
            for mem in [state.active, *state.immutables]:
                for rec in mem.records:
                    seqs.append(rec.seq)
        if not seqs:
            return self.last_seq
        return min(seqs) - 1

    def _persist_sst(self, cf: str, sst: SST) -> None:
        fname = f"sst-{cf}-{sst.file_no}.json"
        path = os.path.join(self.path, fname)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(sst.to_dict(), fh)
            fh.flush()
            os.fsync(fh.fileno())

    def Close(self) -> Status:
        if self.closed:
            return Status.OK()
        # Flush leftover memtables so a clean close is fully durable.
        for name in list(self.cfs):
            self.flush(name)
        self.wal.fsync()
        self.stats["wal_fsyncs"] = self.wal.fsync_count
        self._persist_manifest(fsync=True)
        for it in list(self._iterators):
            it.close()
        for snap in list(self.snapshots):
            snap.released = True
        self.snapshots.clear()
        self.closed = True
        self.log.emit("CLOSE", last_seq=self.last_seq)
        return Status.OK()

    def crash(self, kind: str = "power_loss") -> dict[str, Any]:
        """Drop the in-memory DB. power_loss discards the WAL page cache."""
        if kind == "power_loss":
            self.wal.power_loss()
            # Rewrite WAL file to durable-only bytes.
            with open(self.wal.path, "wb") as fh:
                fh.write(self.wal.durable_bytes())
                fh.flush()
                os.fsync(fh.fileno())
        else:
            # process kill: unsynced WAL cache survives in the kernel.
            self.wal.persist_cached()
        # Snapshots are process-local and die with the process either way.
        n_snap = len(self.snapshots)
        for snap in self.snapshots:
            snap.released = True
        self.snapshots = []
        self.closed = True
        self.log.emit("CRASH", crash_kind=kind, snapshots_lost=n_snap, last_seq=self.last_seq)
        return {
            "kind": kind,
            "snapshots_lost": n_snap,
            "wal_durable": len(self.wal.durable_bytes()),
            "last_seq": self.last_seq,
        }

    # ----- column families -----

    def CreateColumnFamily(self, name: str) -> tuple[Status, Optional[ColumnFamilyHandle]]:
        if self.closed:
            return Status.InvalidArgument("db closed"), None
        if name in self.cfs:
            return Status.InvalidArgument(f"cf exists: {name}"), None
        handle = self._create_cf(name)
        self._persist_manifest(fsync=True)
        self.log.emit("CREATE_CF", name=name, id=handle.id)
        return Status.OK(), handle

    def DropColumnFamily(self, handle: ColumnFamilyHandle) -> Status:
        if handle.destroyed or handle.name not in self.cfs:
            return Status.InvalidArgument("invalid handle")
        handle.dropped = True
        self.log.emit("DROP_CF", name=handle.name)
        # Data stays until the handle is destroyed, matching the wiki.
        return Status.OK()

    def DestroyHandle(self, handle: ColumnFamilyHandle) -> Status:
        handle.destroyed = True
        if handle.dropped and handle.name in self.cfs:
            # Actual deletion after the last handle is gone.
            del self.cfs[handle.name]
            self.handles.pop(handle.name, None)
            self._persist_manifest(fsync=True)
            self.log.emit("DESTROY_CF", name=handle.name)
        return Status.OK()

    def DefaultColumnFamily(self) -> ColumnFamilyHandle:
        return self.handles[DEFAULT_CF]

    def handle(self, name: str) -> Optional[ColumnFamilyHandle]:
        return self.handles.get(name)

    # ----- writes -----

    def Put(self, key: str, value: str, wo: Optional[WriteOptions] = None, cf: str = DEFAULT_CF) -> Status:
        batch = WriteBatch()
        batch.Put(key, value, cf)
        return self.Write(batch, wo)

    def Delete(self, key: str, wo: Optional[WriteOptions] = None, cf: str = DEFAULT_CF) -> Status:
        batch = WriteBatch()
        batch.Delete(key, cf)
        return self.Write(batch, wo)

    def Write(self, batch: WriteBatch, wo: Optional[WriteOptions] = None) -> Status:
        self.stats["status_returned"] += 1
        wo = wo or WriteOptions()
        if self.closed:
            return Status.InvalidArgument("db closed")
        for op in batch.ops:
            state = self.cfs.get(op["cf"])
            if state is None or (self.handles.get(op["cf"]) and self.handles[op["cf"]].destroyed):
                return Status.InvalidArgument(f"unknown column family {op['cf']}")
            handle = self.handles.get(op["cf"])
            if handle is not None and handle.dropped and handle.destroyed:
                return Status.InvalidArgument(f"dropped column family {op['cf']}")
        t0 = self.clock.now()
        incoming = max(batch.nbytes(), 1)
        stall_st = self._wait_if_needed(incoming, wo)
        if stall_st.IsIncomplete():
            self.stats["incomplete_writes"] += 1
            self.stats["write_latency"].append(round(self.clock.now() - t0, 6))
            return stall_st
        self.last_seq += 1
        seq = self.last_seq
        if not wo.disableWAL:
            line = (json.dumps({"seq": seq, "ops": batch.ops}, ensure_ascii=False) + "\n").encode("utf-8")
            self.wal.write(line)
            if wo.sync:
                self.wal.fsync()
                self.stats["wal_fsyncs"] = self.wal.fsync_count
        self._apply_ops(batch.ops, seq)
        self.stats["user_writes"] += 1
        self.stats["user_bytes"] += batch.nbytes()
        self.log.emit("WRITE", seq=seq, ops=len(batch.ops), cfs=sorted({o['cf'] for o in batch.ops}))
        for op in batch.ops:
            state = self.cfs[op["cf"]]
            if state.active.nbytes() >= state.opts.write_buffer_size:
                self._seal(state)
        if self.opts.auto_compact:
            self._drain_available()
        self.stats["write_latency"].append(round(self.clock.now() - t0, 6))
        return Status.OK()

    def _apply_ops(self, ops: list[dict[str, str]], seq: int, from_recovery: bool = False) -> None:
        for op in ops:
            state = self.cfs.get(op["cf"])
            if state is None:
                if from_recovery:
                    self._create_cf(op["cf"])
                    state = self.cfs[op["cf"]]
                else:
                    continue
            rec = Record(op["key"], op.get("value") or "", seq, op["op"])
            state.active.put(rec)

    def naive_put_unbatched(
        self, key: str, value: str, wo: Optional[WriteOptions] = None, cf: str = DEFAULT_CF
    ) -> Status:
        """One WAL record per Put; used only to contrast with WriteBatch atomicity."""
        return self.Put(key, value, wo, cf)

    # ----- stall -----

    def _any_stop_reason(self) -> str:
        for state in self.cfs.values():
            r = self._stop_reason(state)
            if r:
                return r
        return ""

    def _any_stall_reason(self) -> str:
        for state in self.cfs.values():
            r = self._stall_reason(state)
            if r:
                return r
        return ""

    def _stop_reason(self, state: ColumnFamilyState) -> str:
        imm = state.memtable_count()
        if imm >= state.opts.max_write_buffer_number:
            return (
                f"stopping writes because we have {imm} immutable memtables "
                f"(waiting for flush), max_write_buffer_number is set to "
                f"{state.opts.max_write_buffer_number}"
            )
        if imm >= max(state.opts.max_write_buffer_number - 1, 1) and (
            state.active.nbytes() >= state.opts.write_buffer_size
        ):
            return (
                f"stopping writes because we have {imm} immutable memtables "
                f"(waiting for flush), max_write_buffer_number is set to "
                f"{state.opts.max_write_buffer_number}"
            )
        n0 = state.l0_count()
        if n0 >= state.opts.level0_stop_writes_trigger:
            return f"stopping writes because we have {n0} level-0 files"
        return ""

    def _stall_reason(self, state: ColumnFamilyState) -> str:
        imm = state.memtable_count()
        if state.opts.max_write_buffer_number > 3 and imm >= state.opts.max_write_buffer_number - 1:
            return (
                f"stalling writes because we have {imm} immutable memtables "
                f"(waiting for flush), max_write_buffer_number is set to "
                f"{state.opts.max_write_buffer_number}"
            )
        n0 = state.l0_count()
        if n0 >= state.opts.level0_slowdown_writes_trigger:
            return f"stalling writes because we have {n0} level-0 files"
        return ""

    def _wait_if_needed(self, incoming_bytes: int, wo: WriteOptions) -> Status:
        stop = self._any_stop_reason()
        stall = self._any_stall_reason()
        if (stop or stall) and wo.no_slowdown:
            reason = stop or stall
            self.log.emit("INCOMPLETE", reason=reason)
            return Status.Incomplete(reason)
        status = Status.OK()
        while True:
            stop = self._any_stop_reason()
            if not stop:
                break
            if status.ok():
                self.stats["stop_count"] += 1
                self.log.emit("STOP", reason=stop, **self._pressure())
            t0 = self.clock.now()
            slice_t = max(incoming_bytes / max(self.opts.compaction_bandwidth, 1), 0.01)
            progressed = self._background(slice_t, require_work=True)
            self.stats["stop_seconds"] = round(self.stats["stop_seconds"] + (self.clock.now() - t0), 6)
            status = Status.OK()  # write will proceed after stop lifts
            if not progressed and self._any_stop_reason():
                if not self._force_one_job():
                    break
        if not self._any_stop_reason() and self.log.of("STOP") and self.log.events[-1]["kind"] != "RESUME":
            # emit resume only if we just stopped
            pass
        stall = self._any_stall_reason()
        if stall:
            self.stats["stall_count"] += 1
            self.log.emit("STALL", reason=stall, **self._pressure())
            delay = incoming_bytes / max(self.opts.delayed_write_rate, 1)
            t0 = self.clock.now()
            self._background(delay)
            self.stats["stall_seconds"] = round(self.stats["stall_seconds"] + (self.clock.now() - t0), 6)
            self.log.emit("RESUME", after="stall", **self._pressure())
        return Status.OK()

    def _pressure(self) -> dict[str, Any]:
        return {
            "l0": {n: s.l0_count() for n, s in self.cfs.items()},
            "immutable_memtables": {n: s.memtable_count() for n, s in self.cfs.items()},
        }

    def _background(self, seconds: float, require_work: bool = False) -> bool:
        if seconds <= 0:
            return False
        self.bg_credit += seconds * max(self.opts.compaction_bandwidth, 0)
        did = self._run_jobs_with_credit()
        self.clock.advance(seconds)
        if require_work and not did:
            return self._force_one_job()
        return did

    def _run_jobs_with_credit(self) -> bool:
        did = False
        while True:
            cost = self._next_job_cost()
            if cost is None:
                break
            if cost > self.bg_credit:
                break
            job = self._one_job()
            if job is None:
                break
            self.bg_credit -= max(int(cost), 1)
            did = True
        return did

    def _next_job_cost(self) -> Optional[int]:
        for state in self.cfs.values():
            if state.immutables:
                return max(sum(r.nbytes() for r in state.immutables[0].records), 1)
            if state.active.records and state.active.nbytes() >= state.opts.write_buffer_size:
                return max(state.active.nbytes(), 1)
        if not self.opts.auto_compact:
            return None
        for state in self.cfs.values():
            if state.l0_count() >= state.opts.level0_file_num_compaction_trigger:
                return max(sum(s.nbytes for s in state.levels[0]), 1)
        return None

    def _force_one_job(self) -> bool:
        if self._next_job_cost() is None:
            return False
        cost = self._next_job_cost() or 1
        job = self._one_job()
        if job is None:
            return False
        dt = max(int(cost), 1) / max(self.opts.compaction_bandwidth, 1)
        self.clock.advance(dt)
        self.bg_credit = 0.0
        return True

    def _one_job(self) -> Optional[int]:
        # Prefer flush, then L0 compaction.
        for state in self.cfs.values():
            if state.active.records and not state.immutables:
                if state.active.nbytes() >= state.opts.write_buffer_size or self._any_stop_reason():
                    self._seal(state)
            if state.immutables:
                sst = self._flush_one(state)
                return sst.nbytes if sst else 1
        for state in self.cfs.values():
            if state.l0_count() >= state.opts.level0_file_num_compaction_trigger and self.opts.auto_compact:
                nbytes = self._compact_l0(state)
                return nbytes or 1
        return None

    def _drain_available(self) -> None:
        """Spend leftover background credit only; do not invent free flush/compact."""
        self._run_jobs_with_credit()

    def _seal(self, state: ColumnFamilyState) -> None:
        if not state.active.records:
            return
        state.active.sealed = True
        self.log.emit(
            "MEMTABLE_SEAL",
            cf=state.name,
            keys=len(state.active.records),
            bytes=state.active.nbytes(),
            immutable_waiting=len(state.immutables) + 1,
        )
        state.immutables.append(state.active)
        state.active = MemTable()

    def flush(self, cf: str = DEFAULT_CF) -> Status:
        state = self.cfs[cf]
        if state.active.records:
            self._seal(state)
        while state.immutables:
            self._flush_one(state)
        self._persist_manifest(fsync=True)
        return Status.OK()

    def _flush_one(self, state: ColumnFamilyState) -> Optional[SST]:
        if not state.immutables:
            return None
        mem = state.immutables.pop(0)
        recs = list(mem.records)
        if not recs:
            return None
        sst = SST(self.next_file, 0, recs, self.opts.records_per_block)
        self.next_file += 1
        state.levels[0].append(sst)
        self._persist_sst(state.name, sst)
        self.stats["flush_count"] += 1
        self.stats["flush_bytes"] += sst.nbytes
        self.log.emit("FLUSH", cf=state.name, file=sst.file_no, keys=len(sst.records), bytes=sst.nbytes)
        return sst

    def _compact_l0(self, state: ColumnFamilyState) -> int:
        if not state.levels[0]:
            return 0
        inputs = list(state.levels[0])
        # Merge by key keeping newest seq. Teaching simplification: all L0 + overlapping L1.
        l1 = list(state.levels[1])
        recs: dict[str, Record] = {}
        for sst in l1 + inputs:  # inputs newer, overwrite
            for rec in sst.records:
                prev = recs.get(rec.key)
                if prev is None or rec.seq >= prev.seq:
                    recs[rec.key] = rec
        # Drop tombstones at L1 if we treat L1 as bottom-most when L2 is empty.
        out_recs = []
        for rec in recs.values():
            if rec.kind == KIND_DEL and not state.levels[2]:
                continue
            out_recs.append(rec)
        out_recs.sort(key=lambda r: r.key)
        state.levels[0] = []
        state.levels[1] = []
        nbytes = 0
        if out_recs:
            sst = SST(self.next_file, 1, out_recs, self.opts.records_per_block)
            self.next_file += 1
            state.levels[1].append(sst)
            self._persist_sst(state.name, sst)
            nbytes = sst.nbytes
        self.stats["compact_count"] += 1
        self.log.emit(
            "COMPACT",
            cf=state.name,
            from_level=0,
            inputs=[s.file_no for s in inputs],
            output_bytes=nbytes,
        )
        return nbytes

    # ----- reads -----

    def Get(self, key: str, ro: Optional[ReadOptions] = None, cf: str = DEFAULT_CF) -> Status:
        self.stats["status_returned"] += 1
        ro = ro or ReadOptions()
        if self.closed:
            return Status.InvalidArgument("db closed")
        if cf not in self.cfs:
            return Status.InvalidArgument(f"unknown column family {cf}")
        if ro.snapshot is not None:
            if ro.snapshot.released or ro.snapshot not in self.snapshots:
                return Status.InvalidArgument("snapshot already released")
            read_seq = ro.snapshot.seq
        else:
            read_seq = self.last_seq
        t0 = self.clock.now()
        rec, source = self._lookup(cf, key, read_seq, fill_cache=ro.fill_cache)
        latency = round(self.clock.now() - t0, 6)
        self.stats["get_latency"].append(latency)
        if rec is None or rec.kind == KIND_DEL:
            return Status.NotFound()
        return Status.OK(rec.value)

    def _lookup(
        self, cf: str, key: str, read_seq: int, fill_cache: bool
    ) -> tuple[Optional[Record], str]:
        state = self.cfs[cf]
        # Memtables first (newest data).
        found = state.active.get(key, read_seq)
        source = "memtable"
        for mem in reversed(state.immutables):
            rec = mem.get(key, read_seq)
            if rec is not None and (found is None or rec.seq >= found.seq):
                found = rec
                source = "immutable"
        # SSTs: L0 (newest files last) then lower levels.
        for level, files in enumerate(state.levels):
            iterable = files if level > 0 else list(reversed(files))
            for sst in iterable:
                if not sst.covers(key):
                    continue
                rec = self._get_from_sst(sst, key, read_seq, fill_cache)
                if rec is not None and (found is None or rec.seq >= found.seq):
                    found = rec
                    source = f"sst{sst.file_no}"
        return found, source

    def _get_from_sst(self, sst: SST, key: str, read_seq: int, fill_cache: bool) -> Optional[Record]:
        blk = sst.block_for(key)
        if blk is None:
            return None
        cached = self.cache.lookup(blk.block_id)
        if cached is not None:
            self.clock.advance(self.opts.block_hit_s)
            return cached.get(key, read_seq)
        self.clock.advance(self.opts.block_read_s)
        if fill_cache:
            self.cache.insert(blk)
        return blk.get(key, read_seq)

    def _visible_map(self, cf: str, read_seq: int, fill_cache: bool) -> dict[str, Record]:
        state = self.cfs[cf]
        out: dict[str, Record] = {}

        def consider(rec: Record) -> None:
            prev = out.get(rec.key)
            if rec.seq <= read_seq and (prev is None or rec.seq >= prev.seq):
                out[rec.key] = rec

        for level, files in enumerate(state.levels):
            for sst in files:
                for blk in sst.blocks:
                    cached = self.cache.lookup(blk.block_id)
                    if cached is None:
                        self.clock.advance(self.opts.block_read_s)
                        if fill_cache:
                            self.cache.insert(blk)
                        src = blk
                    else:
                        self.clock.advance(self.opts.block_hit_s)
                        src = cached
                    for rec in src.records:
                        consider(rec)
        for mem in state.immutables:
            for rec in mem.items(read_seq).values():
                consider(rec)
        for rec in state.active.items(read_seq).values():
            consider(rec)
        return out

    def _block_ids_for_key(self, cf: str, key: str) -> list[str]:
        ids = []
        state = self.cfs.get(cf)
        if state is None:
            return ids
        for files in state.levels:
            for sst in files:
                blk = sst.block_for(key)
                if blk is not None:
                    ids.append(blk.block_id)
        return ids

    # ----- snapshot / iterator -----

    def GetSnapshot(self) -> Snapshot:
        snap = Snapshot(self.last_seq, self.next_snap_id)
        self.next_snap_id += 1
        self.snapshots.append(snap)
        self.log.emit("SNAPSHOT", id=snap.snap_id, seq=snap.seq)
        return snap

    def ReleaseSnapshot(self, snapshot: Snapshot) -> None:
        snapshot.released = True
        if snapshot in self.snapshots:
            self.snapshots.remove(snapshot)
        self.log.emit("RELEASE_SNAPSHOT", id=snapshot.snap_id, seq=snapshot.seq)

    def NewIterator(self, ro: Optional[ReadOptions] = None, cf: str = DEFAULT_CF) -> Iterator:
        ro = ro or ReadOptions()
        if ro.snapshot is not None:
            if ro.snapshot.released or ro.snapshot not in self.snapshots:
                it = Iterator(self, cf, -1, ro.fill_cache, ro.iterate_upper_bound, ro.iterate_lower_bound)
                it._status = Status.InvalidArgument("snapshot already released")
                it._keys = []
                it._valid = False
                self._iterators.append(it)
                return it
            read_seq = ro.snapshot.seq
        else:
            read_seq = self.last_seq
        it = Iterator(self, cf, read_seq, ro.fill_cache, ro.iterate_upper_bound, ro.iterate_lower_bound)
        self._iterators.append(it)
        return it

    # ----- stats helpers -----

    def tree_shape(self, cf: str = DEFAULT_CF) -> dict[str, Any]:
        state = self.cfs[cf]
        return {
            "cf": cf,
            "memtable_keys": len(state.active.records),
            "immutable": len(state.immutables),
            "l0": state.l0_count(),
            "l1": len(state.levels[1]),
            "l2": len(state.levels[2]),
        }

    def p99(self, latencies: list[float]) -> float:
        if not latencies:
            return 0.0
        xs = sorted(latencies)
        idx = min(len(xs) - 1, max(0, int(round(0.99 * (len(xs) - 1)))))
        return round(xs[idx], 6)

    def live_snapshots(self) -> int:
        return len(self.snapshots)

    def open_iterators(self) -> int:
        return sum(1 for it in self._iterators if not it._closed)
