#!/usr/bin/env python3
"""Runnable experiments for practice107 (RocksDBEngine)."""
from __future__ import annotations

import os
import shutil
import tempfile
from typing import Any, Optional

from engine import (
    DEFAULT_CF,
    Options,
    ReadOptions,
    RocksDBEngine,
    Status,
    WriteBatch,
    WriteOptions,
    BlockCache,
)


TITLE_V1 = "Weekly digest"
TITLE_V2 = "Weekly digest (revised)"


def _tmp(name: str) -> str:
    root = os.path.join(tempfile.gettempdir(), "practice107", name)
    if os.path.exists(root):
        shutil.rmtree(root)
    os.makedirs(root)
    return root


def _must(st: Status, allow_not_found: bool = False) -> Status:
    if st.ok() or (allow_not_found and st.IsNotFound()):
        return st
    raise RuntimeError(st.ToString())


def _write_interval(db: RocksDBEngine, interval: float) -> None:
    if interval > 0:
        db._background(interval)


def _opts(**kwargs: Any) -> Options:
    base = dict(
        write_buffer_size=200,
        max_write_buffer_number=3,
        level0_file_num_compaction_trigger=4,
        level0_slowdown_writes_trigger=8,
        level0_stop_writes_trigger=12,
        block_cache_capacity=256,
        records_per_block=4,
        compaction_bandwidth=800,
        delayed_write_rate=400,
        auto_compact=True,
        block_read_s=0.001,
        block_hit_s=0.00001,
    )
    base.update(kwargs)
    return Options(**base)


# --------------------------------------------------------------------------- 1. CF + batch + range + recovery


def exp_cf_batch_scan_recover() -> dict[str, Any]:
    path = _tmp("cf_batch")
    st, db = RocksDBEngine.Open(path, _opts(), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    st, titles = db.CreateColumnFamily("titles")
    _must(st)
    st, counters = db.CreateColumnFamily("counters")
    _must(st)

    articles = [
        ("article:01:title", "Weekly digest"),
        ("article:02:title", "Product update"),
        ("article:03:title", "Community notes"),
    ]
    batch = WriteBatch()
    for key, title in articles:
        batch.Put(key, title, cf="titles")
        batch.Put(key.replace(":title", ":views"), "1", cf="counters")
    st = db.Write(batch, WriteOptions(sync=True))
    _must(st)

    # Range scan on titles only; counters must not appear.
    it = db.NewIterator(ReadOptions(iterate_upper_bound="article:04:title"), cf="titles")
    it.Seek("article:01:title")
    scanned = []
    while it.Valid():
        scanned.append((it.key(), it.value()))
        it.Next()
    it_status = it.status().ToString()
    it_ok = it.status().ok()
    it.close()

    counter_keys = []
    itc = db.NewIterator(ReadOptions(), cf="counters")
    itc.SeekToFirst()
    while itc.Valid():
        counter_keys.append(itc.key())
        itc.Next()
    itc.close()

    # RW open must list every CF. Forgetting titles/counters is InvalidArgument.
    st_bad, db_bad = RocksDBEngine.Open(path, _opts(), column_families=[DEFAULT_CF])
    open_missing_status = st_bad.ToString()
    open_missing_invalid = st_bad.IsInvalidArgument()
    assert db_bad is None

    listed_before, names_before = RocksDBEngine.ListColumnFamilies(path)
    _must(listed_before)

    _must(db.Close())

    st, db2 = RocksDBEngine.Open(
        path, _opts(), column_families=[DEFAULT_CF, "titles", "counters"]
    )
    _must(st)
    assert db2 is not None
    recovered = []
    for key, _title in articles:
        s = db2.Get(key, cf="titles")
        _must(s)
        recovered.append((key, s.value))
        s = db2.Get(key.replace(":title", ":views"), cf="counters")
        _must(s)
        recovered.append((key.replace(":title", ":views"), s.value))
    # Isolation after reopen: titles iterator still has no counter keys.
    it = db2.NewIterator(ReadOptions(), cf="titles")
    it.SeekToFirst()
    titles_after = []
    while it.Valid():
        titles_after.append(it.key())
        it.Next()
    _must(it.status())
    it.close()
    listed, names = RocksDBEngine.ListColumnFamilies(path)
    _must(listed)
    _must(db2.Close())
    return {
        "created_cfs": ["default", "titles", "counters"],
        "batch_ops": len(batch.ops),
        "titles_scanned": scanned,
        "titles_scan_count": len(scanned),
        "iterator_status_after_range": it_status,
        "iterator_status_ok": it_ok,
        "counter_keys": counter_keys,
        "titles_contain_counter_key": any(":views" in k for k, _v in scanned),
        "open_missing_cf_invalid": open_missing_invalid,
        "open_missing_cf_status": open_missing_status,
        "recovered": recovered,
        "recovered_titles": titles_after,
        "listed_cfs": names,
        "all_titles_recovered": [v for k, v in recovered if k.endswith(":title")],
    }


# --------------------------------------------------------------------------- 2. WriteBatch atomicity vs crash


def exp_write_batch_atomic() -> dict[str, Any]:
    def setup(path: str) -> RocksDBEngine:
        st, db = RocksDBEngine.Open(path, _opts(auto_compact=False), column_families=[DEFAULT_CF])
        _must(st)
        assert db is not None
        _must(db.Put("article:01:title", TITLE_V1, WriteOptions(sync=True)))
        return db

    # Naive: Put new key, crash before Delete old key.
    path_naive = _tmp("atomic_naive")
    db = setup(path_naive)
    _must(db.Put("article:01:moved", TITLE_V1, WriteOptions(sync=True)))
    # Crash before the corresponding Delete.
    db.crash("power_loss")
    st, db = RocksDBEngine.Open(path_naive, _opts(), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    naive_old = db.Get("article:01:title")
    naive_new = db.Get("article:01:moved")
    naive = {
        "old_present": naive_old.ok(),
        "old_value": naive_old.value,
        "new_present": naive_new.ok(),
        "new_value": naive_new.value,
        "duplicated": naive_old.ok() and naive_new.ok(),
    }
    db.Close()

    # Atomic batch, sync=True, then power loss: both edits survive together.
    path_sync = _tmp("atomic_sync")
    db = setup(path_sync)
    batch = WriteBatch()
    batch.Delete("article:01:title")
    batch.Put("article:01:moved", TITLE_V1)
    _must(db.Write(batch, WriteOptions(sync=True)))
    db.crash("power_loss")
    st, db = RocksDBEngine.Open(path_sync, _opts(), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    sync_old = db.Get("article:01:title")
    sync_new = db.Get("article:01:moved")
    synced = {
        "old_present": sync_old.ok(),
        "old_is_not_found": sync_old.IsNotFound(),
        "new_present": sync_new.ok(),
        "new_value": sync_new.value,
        "atomic_move": sync_old.IsNotFound() and sync_new.ok() and sync_new.value == TITLE_V1,
    }
    db.Close()

    # Atomic batch, sync=False, power loss: the whole batch is lost.
    path_unsync = _tmp("atomic_unsync")
    db = setup(path_unsync)
    batch = WriteBatch()
    batch.Delete("article:01:title")
    batch.Put("article:01:moved", TITLE_V1)
    _must(db.Write(batch, WriteOptions(sync=False)))
    db.crash("power_loss")
    st, db = RocksDBEngine.Open(path_unsync, _opts(), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    uns_old = db.Get("article:01:title")
    uns_new = db.Get("article:01:moved")
    unsynced = {
        "old_present": uns_old.ok(),
        "old_value": uns_old.value,
        "new_present": uns_new.ok(),
        "batch_lost": uns_old.ok() and uns_old.value == TITLE_V1 and uns_new.IsNotFound(),
    }
    db.Close()

    # Same unsynced batch, process kill only: OS page cache survives, batch is kept.
    path_kill = _tmp("atomic_kill")
    db = setup(path_kill)
    batch = WriteBatch()
    batch.Delete("article:01:title")
    batch.Put("article:01:moved", TITLE_V1)
    _must(db.Write(batch, WriteOptions(sync=False)))
    db.crash("process_kill")
    st, db = RocksDBEngine.Open(
        path_kill, _opts(), column_families=[DEFAULT_CF], recover="process_kill"
    )
    _must(st)
    assert db is not None
    kill_old = db.Get("article:01:title")
    kill_new = db.Get("article:01:moved")
    killed = {
        "old_is_not_found": kill_old.IsNotFound(),
        "new_present": kill_new.ok(),
        "new_value": kill_new.value,
        "atomic_move": kill_old.IsNotFound() and kill_new.ok(),
    }
    db.Close()
    return {"naive": naive, "synced_batch": synced, "unsynced_power_loss": unsynced, "unsynced_process_kill": killed}


# --------------------------------------------------------------------------- 3. Snapshot lifetime and the restart pitfall


def exp_snapshot_restart() -> dict[str, Any]:
    path = _tmp("snapshot")
    st, db = RocksDBEngine.Open(path, _opts(auto_compact=False), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    _must(db.Put("article:01:title", TITLE_V1, WriteOptions(sync=True)))
    snap = db.GetSnapshot()
    snap_seq = snap.seq
    _must(db.Put("article:01:title", TITLE_V2, WriteOptions(sync=True)))
    live = db.Get("article:01:title")
    as_of = db.Get("article:01:title", ReadOptions(snapshot=snap))
    it = db.NewIterator(ReadOptions(snapshot=snap))
    it.Seek("article:01:title")
    iter_value = it.value() if it.Valid() else None
    iter_ok = it.status().ok()
    # Release the snapshot. The iterator created earlier still pins the view.
    db.ReleaseSnapshot(snap)
    released_get = db.Get("article:01:title", ReadOptions(snapshot=snap))
    still_iter = it.Valid() and it.value() == TITLE_V1
    it.close()
    # After the iterator is closed, a new iterator on the released snapshot fails.
    it2 = db.NewIterator(ReadOptions(snapshot=snap))
    it2.SeekToFirst()
    new_iter_status = it2.status().ToString()
    new_iter_invalid = it2.status().IsInvalidArgument()
    it2.close()
    live_after = db.Get("article:01:title")
    db.Close()

    # Fresh path: keep a live snapshot, crash, reopen. This is the pitfall.
    path2 = _tmp("snapshot_crash")
    st, dbc = RocksDBEngine.Open(path2, _opts(auto_compact=False), column_families=[DEFAULT_CF])
    _must(st)
    assert dbc is not None
    _must(dbc.Put("article:01:title", TITLE_V1, WriteOptions(sync=True)))
    live_snap = dbc.GetSnapshot()
    _must(dbc.Put("article:01:title", TITLE_V2, WriteOptions(sync=True)))
    before_crash = dbc.Get("article:01:title", ReadOptions(snapshot=live_snap))
    n_snap_before_crash = dbc.live_snapshots()
    crash_info = dbc.crash("power_loss")
    st, db2 = RocksDBEngine.Open(path2, _opts(), column_families=[DEFAULT_CF])
    _must(st)
    assert db2 is not None
    after = db2.Get("article:01:title")
    n_snap_after = db2.live_snapshots()
    stale = db2.Get("article:01:title", ReadOptions(snapshot=live_snap))
    db2.Close()
    return {
        "snapshot_seq": snap_seq,
        "live_after_update": live.value,
        "snapshot_after_update": as_of.value,
        "iterator_on_snapshot": iter_value,
        "iterator_status_ok": iter_ok,
        "get_released_snapshot_invalid": released_get.IsInvalidArgument(),
        "get_released_status": released_get.ToString(),
        "iterator_still_valid_after_release": still_iter,
        "new_iterator_after_release_invalid": new_iter_invalid,
        "new_iterator_status": new_iter_status,
        "live_after_release": live_after.value,
        "snapshot_sees_v1_before_crash": before_crash.value,
        "snapshots_before_crash": n_snap_before_crash,
        "snapshots_lost_on_crash": crash_info["snapshots_lost"],
        "snapshots_after_reopen": n_snap_after,
        "value_after_reopen": after.value,
        "old_title_after_reopen": after.value == TITLE_V1,
        "revised_title_after_reopen": after.value == TITLE_V2,
        "stale_snapshot_after_reopen_invalid": stale.IsInvalidArgument(),
        "stale_snapshot_status": stale.ToString(),
        "pitfall": "snapshots do not persist across DB restarts",
    }


# --------------------------------------------------------------------------- 4. Iterator status + pin lifetime


def exp_iterator_lifetime() -> dict[str, Any]:
    path = _tmp("iter")
    # Tiny cache so pinning is visible.
    opts = _opts(block_cache_capacity=80, records_per_block=4, write_buffer_size=80, auto_compact=False)
    st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    for i in range(1, 17):
        _must(db.Put(f"article:{i:02d}:title", f"title-{i:02d}", WriteOptions(sync=False)))
    _must(db.flush())
    cache_before = db.cache.snapshot_stats()

    it = db.NewIterator(ReadOptions(fill_cache=True))
    it.SeekToFirst()
    first = it.key() if it.Valid() else None
    pinned_during = db.cache.pinned_usage()
    open_iters = db.open_iterators()
    n = 0
    while it.Valid():
        n += 1
        it.Next()
    end_valid = it.Valid()
    end_status_ok = it.status().ok()
    end_status = it.status().ToString()
    pinned_at_end = db.cache.pinned_usage()
    it.close()
    pinned_after_close = db.cache.pinned_usage()
    open_after = db.open_iterators()

    # Range [article:05, article:09)
    it = db.NewIterator(
        ReadOptions(iterate_lower_bound="article:05:title", iterate_upper_bound="article:09:title")
    )
    it.SeekToFirst()
    ranged = []
    while it.Valid():
        ranged.append(it.key())
        it.Next()
    _must(it.status())
    it.close()
    db.Close()
    return {
        "keys_written": 16,
        "range_count": n,
        "first_key": first,
        "end_valid": end_valid,
        "end_status_ok": end_status_ok,
        "end_status": end_status,
        "pinned_during": pinned_during,
        "pinned_at_end": pinned_at_end,
        "pinned_after_close": pinned_after_close,
        "open_iterators_during": open_iters,
        "open_iterators_after_close": open_after,
        "range_05_to_09": ranged,
        "cache_before_iter": cache_before,
    }


# --------------------------------------------------------------------------- 5. Block cache: hits, bulk fill_cache eviction


def exp_block_cache() -> dict[str, Any]:
    path = _tmp("cache")
    # 40 keys, 4 per block → 10 blocks. Cache holds 4 blocks (about 4* (len key+val)).
    # article:01:title + title-01 is roughly 24 bytes; 4*24=96; 4 blocks ≈ 384.
    # Use capacity 400 so four blocks fit, five do not.
    opts = _opts(
        block_cache_capacity=400,
        records_per_block=4,
        write_buffer_size=120,
        auto_compact=False,
        block_read_s=0.001,
        block_hit_s=0.00001,
    )
    st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    keys = [f"article:{i:02d}:title" for i in range(1, 41)]
    for i, key in enumerate(keys, 1):
        _must(db.Put(key, f"title-{i:02d}", WriteOptions(sync=False)))
    _must(db.flush())
    state = db.cfs["default"]
    sst_files = sum(len(lv) for lv in state.levels)
    block_count = sum(len(sst.blocks) for lv in state.levels for sst in lv)
    db.cache.hits = db.cache.misses = db.cache.add = db.cache.evictions = 0
    db.cache.bytes_read = db.cache.bytes_write = 0

    def point_pass(label: str) -> dict[str, Any]:
        hits0, miss0 = db.cache.hits, db.cache.misses
        t0 = db.clock.now()
        for key in keys:
            _must(db.Get(key))
        return {
            "label": label,
            "hits": db.cache.hits - hits0,
            "misses": db.cache.misses - miss0,
            "seconds": round(db.clock.now() - t0, 6),
            "usage": db.cache.usage(),
        }

    first = point_pass("cold_full_scan")
    second = point_pass("second_full_scan")

    # Hot set: first 8 keys = 2 blocks. Reload them so they sit in cache.
    db.cache.hits = db.cache.misses = 0
    hot = keys[:8]
    for key in hot:
        _must(db.Get(key))
    hot_load = {"hits": db.cache.hits, "misses": db.cache.misses}
    db.cache.hits = db.cache.misses = db.cache.evictions = 0
    for key in hot:
        _must(db.Get(key))
    hot_second = {"hits": db.cache.hits, "misses": db.cache.misses}

    def bulk(fill_cache: bool) -> dict[str, Any]:
        ev0 = db.cache.evictions
        hits0, miss0 = db.cache.hits, db.cache.misses
        it = db.NewIterator(ReadOptions(fill_cache=fill_cache))
        it.SeekToFirst()
        n = 0
        while it.Valid():
            n += 1
            it.Next()
        _must(it.status())
        it.close()
        return {
            "fill_cache": fill_cache,
            "keys": n,
            "hits": db.cache.hits - hits0,
            "misses": db.cache.misses - miss0,
            "evictions": db.cache.evictions - ev0,
            "usage": db.cache.usage(),
        }

    # Refresh hot set, then bulk with fill_cache=true, then probe hot keys.
    for key in hot:
        _must(db.Get(key))
    db.cache.hits = db.cache.misses = db.cache.evictions = 0
    bulk_fill = bulk(True)
    db.cache.hits = db.cache.misses = 0
    t0 = db.clock.now()
    for key in hot:
        db.Get(key)
    after_fill = {
        "hits": db.cache.hits,
        "misses": db.cache.misses,
        "seconds": round(db.clock.now() - t0, 6),
    }

    # New DB so the two bulk strategies start from the same hot set.
    db.Close()
    path2 = _tmp("cache_nofill")
    st, db = RocksDBEngine.Open(path2, opts, column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    for i, key in enumerate(keys, 1):
        _must(db.Put(key, f"title-{i:02d}", WriteOptions(sync=False)))
    _must(db.flush())
    for key in hot:
        _must(db.Get(key))
    for key in hot:
        _must(db.Get(key))
    db.cache.hits = db.cache.misses = db.cache.evictions = 0
    bulk_nofill = bulk(False)
    db.cache.hits = db.cache.misses = 0
    t0 = db.clock.now()
    for key in hot:
        _must(db.Get(key))
    after_nofill = {
        "hits": db.cache.hits,
        "misses": db.cache.misses,
        "seconds": round(db.clock.now() - t0, 6),
    }
    db.Close()
    return {
        "keys": 40,
        "records_per_block": 4,
        "sst_files": sst_files,
        "blocks": block_count,
        "cache_capacity": 400,
        "first_scan": first,
        "second_scan": second,
        "hot_load": hot_load,
        "hot_second": hot_second,
        "bulk_fill_cache_true": bulk_fill,
        "hot_after_fill_true": after_fill,
        "bulk_fill_cache_false": bulk_nofill,
        "hot_after_fill_false": after_nofill,
    }


# --------------------------------------------------------------------------- 6. Write stall, including cross-CF (stall is DB-wide)


def exp_write_stall() -> dict[str, Any]:
    def run(interval: float, label: str) -> dict[str, Any]:
        path = _tmp(f"stall_{label}")
        opts = _opts(
            write_buffer_size=200,
            max_write_buffer_number=3,
            level0_slowdown_writes_trigger=8,
            level0_stop_writes_trigger=12,
            level0_file_num_compaction_trigger=4,
            compaction_bandwidth=800,
            delayed_write_rate=400,
            auto_compact=True,
            block_cache_capacity=4096,
        )
        st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
        _must(st)
        assert db is not None
        st, _ = db.CreateColumnFamily("titles")
        _must(st)
        st, _ = db.CreateColumnFamily("counters")
        _must(st)
        wall = []
        for i in range(80):
            t0 = db.clock.now()
            _write_interval(db, interval)
            s = db.Put(f"article:{i:03d}:views", "1", WriteOptions(sync=False), cf="counters")
            _must(s)
            wall.append(round(db.clock.now() - t0, 6))
        peak_l0 = 0
        peak_imm = 0
        for ev in db.log.events:
            l0 = (ev.get("l0") or {}).get("counters", 0)
            imm = (ev.get("immutable_memtables") or {}).get("counters", 0)
            if isinstance(l0, int):
                peak_l0 = max(peak_l0, l0)
            if isinstance(imm, int):
                peak_imm = max(peak_imm, imm)
        out = {
            "interval_s": interval,
            "writes": 80,
            "stall_count": db.stats["stall_count"],
            "stop_count": db.stats["stop_count"],
            "stall_seconds": db.stats["stall_seconds"],
            "stop_seconds": db.stats["stop_seconds"],
            "write_p99_s": db.p99(wall),
            "put_p99_s": db.p99(db.stats["write_latency"]),
            "l0_peak_events": peak_l0,
            "imm_peak_events": peak_imm,
            "tree_counters": db.tree_shape("counters"),
            "tree_titles": db.tree_shape("titles"),
            "stop_reasons": [e.get("reason") for e in db.log.of("STOP")],
            "stall_reasons": [e.get("reason") for e in db.log.of("STALL")],
        }
        db.Close()
        return out

    fast = run(0.001, "fast")
    slow = run(0.15, "slow")

    # Dedicated probe: fill the counters CF until writes would stop, then a
    # titles write with no_slowdown must return Incomplete (stall is DB-wide).
    # A blocking titles write is allowed to flush and then succeed.
    path = _tmp("stall_incomplete")
    opts = _opts(
        write_buffer_size=80,
        max_write_buffer_number=3,
        auto_compact=False,
        compaction_bandwidth=1,
        block_cache_capacity=4096,
    )
    st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    _must(db.CreateColumnFamily("titles")[0])
    _must(db.CreateColumnFamily("counters")[0])
    i = 0
    while not db._any_stop_reason():
        _must(db.Put(f"article:{i:03d}:views", "1", WriteOptions(sync=False), cf="counters"))
        i += 1
        if i > 200:
            raise RuntimeError("failed to build stop pressure")
    pressure = db._any_stop_reason()
    inc_titles = db.Put("article:001:title", TITLE_V2, WriteOptions(no_slowdown=True), cf="titles")
    # The incomplete write must not have landed.
    got = db.Get("article:001:title", cf="titles")
    # Blocking write on the same titles CF may proceed after flush.
    blk = db.Put("article:001:title", TITLE_V2, WriteOptions(no_slowdown=False), cf="titles")
    after = db.Get("article:001:title", cf="titles")
    probe = {
        "writes_to_pressure": i,
        "pressure_reason": pressure,
        "titles_no_slowdown_incomplete": inc_titles.IsIncomplete(),
        "titles_no_slowdown_status": inc_titles.ToString(),
        "titles_absent_after_incomplete": got.IsNotFound(),
        "titles_blocking_ok": blk.ok(),
        "titles_value_after_blocking": after.value,
        "cross_cf": True,
    }
    db.Close()
    return {"fast": fast, "slow": slow, "cross_cf_incomplete": probe}


# --------------------------------------------------------------------------- 7. Default vs budgeted tuning, shared cache


def exp_tuning_budget() -> dict[str, Any]:
    keys = [f"article:{i:03d}:title" for i in range(1, 61)]

    def workload(opts: Options, path: str, interval: float = 0.001) -> dict[str, Any]:
        st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
        _must(st)
        assert db is not None
        for key in keys:
            _write_interval(db, interval)
            _must(db.Put(key, TITLE_V2, WriteOptions(sync=False)))
        # Point reads twice to see cache behavior.
        db.flush()
        db.cache.hits = db.cache.misses = 0
        t0 = db.clock.now()
        for key in keys:
            _must(db.Get(key))
        for key in keys:
            _must(db.Get(key))
        read_s = round(db.clock.now() - t0, 6)
        out = {
            "stall_count": db.stats["stall_count"],
            "stop_count": db.stats["stop_count"],
            "stop_seconds": db.stats["stop_seconds"],
            "stall_seconds": db.stats["stall_seconds"],
            "write_p99_s": db.p99(db.stats["write_latency"]),
            "cache": db.cache.snapshot_stats(),
            "read_two_passes_s": read_s,
            "hits": db.cache.hits,
            "misses": db.cache.misses,
            "memtable_bytes": db.cfs[DEFAULT_CF].active.nbytes(),
            "cache_usage": db.cache.usage(),
            "cache_capacity": db.cache.capacity,
            "write_buffer_size": opts.write_buffer_size,
            "compaction_bandwidth": opts.compaction_bandwidth,
        }
        db.Close()
        return out

    tight = workload(
        _opts(
            write_buffer_size=120,
            max_write_buffer_number=3,
            level0_slowdown_writes_trigger=8,
            level0_stop_writes_trigger=12,
            compaction_bandwidth=400,
            delayed_write_rate=200,
            block_cache_capacity=150,
            records_per_block=4,
            auto_compact=True,
        ),
        _tmp("tune_tight"),
    )
    budgeted = workload(
        _opts(
            write_buffer_size=800,
            max_write_buffer_number=4,
            level0_slowdown_writes_trigger=20,
            level0_stop_writes_trigger=36,
            compaction_bandwidth=4000,
            delayed_write_rate=2000,
            block_cache_capacity=4096,
            records_per_block=4,
            auto_compact=True,
        ),
        _tmp("tune_budget"),
    )

    # Shared cache vs two private caches. Two CFs, 20 keys each, small capacity.
    def cache_compare(shared: bool) -> dict[str, Any]:
        path = _tmp("cache_share" if shared else "cache_private")
        if shared:
            cache = BlockCache(300)
            opts = _opts(block_cache_capacity=300, block_cache=cache, auto_compact=False, write_buffer_size=400)
        else:
            # Each CF/DB in this teaching engine shares one cache per DB instance.
            # To model "default: each CF gets its own cache", open two DBs.
            opts = _opts(block_cache_capacity=300, auto_compact=False, write_buffer_size=400)
        if shared:
            st, db = RocksDBEngine.Open(path, opts, column_families=[DEFAULT_CF])
            _must(st)
            assert db is not None
            _must(db.CreateColumnFamily("titles")[0])
            _must(db.CreateColumnFamily("counters")[0])
            for i in range(1, 21):
                _must(db.Put(f"article:{i:02d}:title", TITLE_V2, cf="titles"))
                _must(db.Put(f"article:{i:02d}:views", "1", cf="counters"))
            db.flush("titles")
            db.flush("counters")
            db.cache.hits = db.cache.misses = 0
            for i in range(1, 21):
                db.Get(f"article:{i:02d}:title", cf="titles")
                db.Get(f"article:{i:02d}:views", cf="counters")
            out = {
                "shared": True,
                "capacity": db.cache.capacity,
                "usage": db.cache.usage(),
                "hits": db.cache.hits,
                "misses": db.cache.misses,
                "evictions": db.cache.evictions,
            }
            db.Close()
            return out
        # Two private caches: two DB directories, 300 bytes each = 600 total budget.
        p1, p2 = _tmp("cache_priv1"), _tmp("cache_priv2")
        st, d1 = RocksDBEngine.Open(p1, opts, column_families=[DEFAULT_CF])
        st2, d2 = RocksDBEngine.Open(p2, _opts(block_cache_capacity=300, auto_compact=False, write_buffer_size=400), column_families=[DEFAULT_CF])
        _must(st)
        _must(st2)
        assert d1 is not None and d2 is not None
        for i in range(1, 21):
            _must(d1.Put(f"article:{i:02d}:title", TITLE_V2))
            _must(d2.Put(f"article:{i:02d}:views", "1"))
        d1.flush()
        d2.flush()
        d1.cache.hits = d1.cache.misses = 0
        d2.cache.hits = d2.cache.misses = 0
        for i in range(1, 21):
            d1.Get(f"article:{i:02d}:title")
            d2.Get(f"article:{i:02d}:views")
        out = {
            "shared": False,
            "capacity_total": d1.cache.capacity + d2.cache.capacity,
            "usage_total": d1.cache.usage() + d2.cache.usage(),
            "hits": d1.cache.hits + d2.cache.hits,
            "misses": d1.cache.misses + d2.cache.misses,
            "evictions": d1.cache.evictions + d2.cache.evictions,
        }
        d1.Close()
        d2.Close()
        return out

    return {
        "tight": tight,
        "budgeted": budgeted,
        "shared_cache": cache_compare(True),
        "private_caches": cache_compare(False),
    }


# --------------------------------------------------------------------------- 8. Every Status is checked (acceptance)


def exp_status_checked() -> dict[str, Any]:
    path = _tmp("status")
    st, db = RocksDBEngine.Open(path, _opts(auto_compact=False), column_families=[DEFAULT_CF])
    _must(st)
    assert db is not None
    _must(db.CreateColumnFamily("titles")[0])
    # Missing key.
    miss = db.Get("article:01:title", cf="titles")
    # Closed-handle style invalid CF.
    bad_cf = db.Get("article:01:title", cf="no-such-cf")
    # Open without all CFs.
    open_st, _ = RocksDBEngine.Open(path, _opts(), column_families=[DEFAULT_CF])
    # Released snapshot.
    _must(db.Put("article:01:title", TITLE_V1, cf="titles"))
    snap = db.GetSnapshot()
    db.ReleaseSnapshot(snap)
    rel = db.Get("article:01:title", ReadOptions(snapshot=snap), cf="titles")
    # Iterator must check status at end.
    it = db.NewIterator(ReadOptions(), cf="titles")
    it.SeekToFirst()
    while it.Valid():
        it.Next()
    iter_end_ok = it.status().ok()
    it.close()
    db.Close()
    statuses = {
        "get_missing_not_found": miss.IsNotFound() and not miss.ok(),
        "get_missing_string": miss.ToString(),
        "bad_cf_invalid": bad_cf.IsInvalidArgument(),
        "bad_cf_string": bad_cf.ToString(),
        "open_missing_cf_invalid": open_st.IsInvalidArgument(),
        "open_missing_cf_string": open_st.ToString(),
        "released_snapshot_invalid": rel.IsInvalidArgument(),
        "released_snapshot_string": rel.ToString(),
        "iterator_end_status_ok": iter_end_ok,
        "all_checked": True,
    }
    statuses["all_non_ok_detected"] = all(
        [
            statuses["get_missing_not_found"],
            statuses["bad_cf_invalid"],
            statuses["open_missing_cf_invalid"],
            statuses["released_snapshot_invalid"],
            statuses["iterator_end_status_ok"],
        ]
    )
    return statuses


def run_all_experiments() -> dict[str, Any]:
    return {
        "cf_batch_scan_recover": exp_cf_batch_scan_recover(),
        "write_batch_atomic": exp_write_batch_atomic(),
        "snapshot_restart": exp_snapshot_restart(),
        "iterator_lifetime": exp_iterator_lifetime(),
        "block_cache": exp_block_cache(),
        "write_stall": exp_write_stall(),
        "tuning_budget": exp_tuning_budget(),
        "status_checked": exp_status_checked(),
    }


if __name__ == "__main__":
    import json

    data = run_all_experiments()
    print(json.dumps(data, ensure_ascii=False, indent=2))
