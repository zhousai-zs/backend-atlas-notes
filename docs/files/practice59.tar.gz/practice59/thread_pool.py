"""有界工作线程池：try_run 非阻塞；stop 后 join。"""
from __future__ import annotations
import threading
from typing import Callable, List, Optional
from bounded_queue import BoundedQueue

Task = Callable[[], None]
_SENTINEL = object()


class BoundedThreadPool:
    def __init__(self, num_threads: int, capacity: int) -> None:
        self._queue = BoundedQueue(capacity)
        self._threads: List[threading.Thread] = []
        self._num = num_threads
        self._running = False
        self._mu = threading.Lock()

    def start(self) -> None:
        with self._mu:
            self._running = True
        for i in range(self._num):
            th = threading.Thread(target=self._worker, name=f"worker-{i}", daemon=True)
            th.start()
            self._threads.append(th)

    def try_run(self, task: Task) -> bool:
        with self._mu:
            if not self._running:
                return False
        return self._queue.try_put(task)

    def stop(self, drain: bool = True) -> None:
        with self._mu:
            self._running = False
        if not drain:
            # 丢弃剩余：关闭队列，worker 取出后遇 close+空退出
            self._queue.close()
        else:
            # 排空：投入 sentinel 唤醒，再 close
            for _ in self._threads:
                # 尽力投入 sentinel；队列满则等 worker 消费
                while not self._queue.try_put(_SENTINEL):
                    pass
            self._queue.close()
        for th in self._threads:
            th.join(timeout=10)
        self._threads.clear()

    def _worker(self) -> None:
        while True:
            item = self._queue.take(timeout=0.5)
            if item is _SENTINEL:
                return
            if item is None:
                # timeout or closed-empty
                with self._mu:
                    running = self._running
                if not running and self._queue.size() == 0:
                    return
                continue
            item()
