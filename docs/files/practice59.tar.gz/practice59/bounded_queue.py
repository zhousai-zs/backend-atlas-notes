"""有界队列：IO 线程用 try_put，满则立刻 False。"""
from __future__ import annotations
import threading
from collections import deque
from typing import Any, Optional


class BoundedQueue:
    def __init__(self, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be > 0")
        self.capacity = capacity
        self._q: deque[Any] = deque()
        self._mu = threading.Lock()
        self._not_empty = threading.Condition(self._mu)
        self._not_full = threading.Condition(self._mu)
        self._closed = False

    def try_put(self, item: Any) -> bool:
        with self._mu:
            if self._closed or len(self._q) >= self.capacity:
                return False
            self._q.append(item)
            self._not_empty.notify()
            return True

    def take(self, timeout: Optional[float] = None) -> Any:
        with self._not_empty:
            if not self._not_empty.wait_for(
                lambda: self._closed or len(self._q) > 0, timeout=timeout
            ):
                return None
            if not self._q:
                return None
            item = self._q.popleft()
            self._not_full.notify()
            return item

    def close(self) -> None:
        with self._mu:
            self._closed = True
            self._not_empty.notify_all()
            self._not_full.notify_all()

    def size(self) -> int:
        with self._mu:
            return len(self._q)
