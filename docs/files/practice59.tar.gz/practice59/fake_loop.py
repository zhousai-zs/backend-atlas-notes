"""最小假 EventLoop：queue_in_loop + run_once。"""
from __future__ import annotations
import queue
from typing import Callable

Functor = Callable[[], None]


class FakeLoop:
    def __init__(self) -> None:
        self.pending: queue.Queue[Functor] = queue.Queue()
        self.alive = True
        self.touch_count = 0

    def queue_in_loop(self, fn: Functor) -> None:
        if not self.alive:
            raise RuntimeError("queueInLoop on destroyed loop")
        self.pending.put(fn)

    def run_once(self) -> None:
        try:
            while True:
                fn = self.pending.get_nowait()
                self.touch_count += 1
                fn()
        except queue.Empty:
            return

    def destroy(self) -> None:
        self.alive = False
