#!/usr/bin/env python3
"""验收：队列满拒绝；停机后无任务访问销毁的 loop。"""
from __future__ import annotations
import time
import threading
from thread_pool import BoundedThreadPool
from fake_loop import FakeLoop


def test_queue_full_reject() -> None:
    pool = BoundedThreadPool(num_threads=1, capacity=2)
    pool.start()
    gate = threading.Event()

    def slow():
        gate.wait(timeout=2)
        time.sleep(0.05)

    ok = 0
    fail = 0
    for _ in range(8):
        if pool.try_run(slow):
            ok += 1
        else:
            fail += 1
    assert fail >= 1, f"expected rejects, ok={ok} fail={fail}"
    gate.set()
    time.sleep(0.3)
    pool.stop(drain=True)
    print("test_queue_full_reject OK", {"ok": ok, "fail": fail})


def test_shutdown_no_touch_destroyed_loop() -> None:
    loop = FakeLoop()
    pool = BoundedThreadPool(num_threads=2, capacity=16)
    pool.start()
    errors = []

    def job():
        time.sleep(0.02)
        def back():
            if not loop.alive:
                errors.append("touched destroyed loop")
            else:
                loop.touch_count += 0  # already counted in run_once path
        try:
            loop.queue_in_loop(back)
        except RuntimeError as e:
            errors.append(str(e))

    for _ in range(10):
        pool.try_run(job)

    # 正确停机：先停池 join，再销毁 loop
    pool.stop(drain=True)
    # drain pending while alive
    loop.run_once()
    loop.destroy()
    assert not errors, errors
    print("test_shutdown_no_touch_destroyed_loop OK")


if __name__ == "__main__":
    test_queue_full_reject()
    test_shutdown_no_touch_destroyed_loop()
    print("ALL_CHECKS_PASSED")
