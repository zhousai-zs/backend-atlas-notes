#!/usr/bin/env python3
"""Acceptance checks for the lesson 128 throughput / latency experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import KEY_TITLE, MEASURE_S, SERVICE_S, SLOW_S, TITLE_V1, WARMUP_S, WORKERS


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "EchoMetricsEngine"
    assert r["not_redis"] and r["not_a_network_service"]
    assert r["not_a_real_metrics_product"] and r["not_prometheus"] and r["not_google_sre_production"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1
    assert r["workers"] == WORKERS == 2
    assert r["service_s"] == SERVICE_S == 0.10
    assert r["slow_s"] == SLOW_S == 5.00
    assert r["warmup_s"] == WARMUP_S == 1.00
    assert r["measure_s"] == MEASURE_S == 10.00

    sw = r["sweep"]
    assert sw["capacity_qps"] == 20.0
    assert sw["throughput_plateau"] and sw["e2e_grows_after_saturation"]
    assert sw["service_time_unchanged"] and sw["little_holds_in_steady_state"]
    expected = {
        1: (10.0, 0.10, 0.0, 0.50, False, 100),
        2: (20.0, 0.10, 0.0, 1.00, True, 200),
        4: (20.0, 0.20, 0.10, 1.00, True, 200),
        8: (20.0, 0.40, 0.30, 1.00, True, 200),
        16: (20.0, 0.80, 0.70, 1.00, True, 200),
    }
    assert [row["concurrency"] for row in sw["rows"]] == [1, 2, 4, 8, 16]
    for row in sw["rows"]:
        qps, e2e, wait, util, sat, n = expected[row["concurrency"]]
        assert row["qps"] == qps and row["n_completed"] == n
        assert row["mean_e2e"] == e2e and row["p50_e2e"] == e2e and row["p99_e2e"] == e2e
        assert row["mean_wait"] == wait and row["mean_service"] == 0.10
        assert row["utilization"] == util and row["workers_saturated"] is sat
        assert row["l_avg"] == float(row["concurrency"])
        assert row["lambda_times_w"] == float(row["concurrency"])
        assert row["little_holds"] and row["little_abs_err"] == 0.0
        assert row["t0"] == 1.00 and row["t1"] == 11.00

    qt = r["qps_tps"]
    assert qt["qps_echo"] == 20.0 and qt["tps_echo"] == 20.0
    assert qt["qps_publish"] == 20.0 and qt["tps_publish"] == 10.0
    assert qt["echo_qps_equals_tps"] and qt["publish_qps_is_twice_tps"] and qt["same_query_capacity"]
    assert qt["publish"]["n_completed"] == 200 and qt["publish"]["n_txns"] == 100

    tail = r["tail"]
    assert tail["n_completed"] == 100 and tail["n_slow"] == 1
    assert tail["measure_s"] == 14.9 and tail["qps"] == 6.7114
    assert tail["mean_e2e"] == 0.149 and tail["p50_e2e"] == 0.10
    assert tail["p99_e2e"] == 5.00 and tail["max_e2e"] == 5.00
    assert tail["mean_hides_tail"] and tail["p50_near_service"]

    b = r["burst"]
    assert b["half_util"]["utilization"] == 0.50 and b["half_util"]["qps"] == 10.0
    assert b["full_util"]["utilization"] == 1.00 and b["full_util"]["qps"] == 20.0
    tight = b["burst_on_two_workers"]
    wide = b["burst_on_five_workers"]
    assert tight["n_completed"] == 5 and tight["mean_e2e"] == 0.18
    assert tight["p50_e2e"] == 0.20 and tight["p99_e2e"] == 0.30 and tight["max_e2e"] == 0.30
    assert tight["mean_wait"] == 0.08 and tight["t1"] == 0.30
    assert wide["n_completed"] == 5 and wide["mean_e2e"] == 0.10
    assert wide["p99_e2e"] == 0.10 and wide["mean_wait"] == 0.0 and wide["t1"] == 0.10
    assert b["high_util_less_idle"] and b["high_util_less_headroom"]

    assert r["acceptance_throughput_plateau"]
    assert r["acceptance_service_vs_e2e"]
    assert r["practice_records_qps_and_percentiles"]
    assert r["pitfall_mean_hides_tail"]
    assert r["tradeoff_util_vs_headroom"]
    assert r["little_holds_when_stable"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
