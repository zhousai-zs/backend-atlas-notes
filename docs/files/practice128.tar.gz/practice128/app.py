#!/usr/bin/env python3
"""Run the lesson 128 throughput / latency / queueing experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    KEY_TITLE,
    MEASURE_S,
    SERVICE_S,
    SLOW_S,
    TITLE_V1,
    WARMUP_S,
    WORKERS,
    EchoMetricsEngine,
)


CONCURRENCIES = (1, 2, 4, 8, 16)


def run_concurrency_sweep() -> dict[str, Any]:
    rows = []
    for n in CONCURRENCIES:
        eng = EchoMetricsEngine()
        rec = eng.run_closed(concurrency=n, measure_s=MEASURE_S, warmup_s=WARMUP_S)
        rec["capacity_qps"] = rec["workers"] / rec["service_s"]
        rows.append(rec)
    # Throughput plateaus once concurrency exceeds the worker count.
    qps_at = {r["concurrency"]: r["qps"] for r in rows}
    sat = [r for r in rows if r["concurrency"] > WORKERS]
    plateau = all(abs(r["qps"] - sat[0]["qps"]) <= 0.05 for r in sat) if sat else False
    cap = WORKERS / SERVICE_S
    near_cap = all(abs(r["qps"] - cap) <= 0.05 for r in sat) if sat else False
    e2e_grows = all(
        sat[i]["mean_e2e"] > sat[i - 1]["mean_e2e"] + 1e-6 for i in range(1, len(sat))
    ) if len(sat) >= 2 else False
    service_flat = all(abs(r["mean_service"] - SERVICE_S) <= 1e-6 for r in rows)
    little_all = all(r["little_holds"] for r in rows)
    return {
        "rows": rows,
        "capacity_qps": cap,
        "qps_at": qps_at,
        "throughput_plateau": plateau and near_cap,
        "e2e_grows_after_saturation": e2e_grows,
        "service_time_unchanged": service_flat,
        "little_holds_in_steady_state": little_all,
        "t_end": max(r["t1"] for r in rows),
    }


def run_qps_vs_tps() -> dict[str, Any]:
    """Same concurrency, one query per transaction vs two queries per transaction."""
    echo = EchoMetricsEngine()
    one = echo.run_closed(concurrency=2, measure_s=MEASURE_S, warmup_s=WARMUP_S, txn_steps=1)
    pub = EchoMetricsEngine()
    two = pub.run_closed(concurrency=2, measure_s=MEASURE_S, warmup_s=WARMUP_S, txn_steps=2)
    return {
        "echo": one,
        "publish": two,
        "qps_echo": one["qps"],
        "tps_echo": one["tps"],
        "qps_publish": two["qps"],
        "tps_publish": two["tps"],
        "echo_qps_equals_tps": abs(one["qps"] - one["tps"]) <= 0.05,
        "publish_qps_is_twice_tps": abs(two["qps"] - 2 * two["tps"]) <= 0.05,
        "same_query_capacity": abs(one["qps"] - two["qps"]) <= 0.05,
        "t_end": max(one["t1"], two["t1"]),
    }


def run_tail_vs_mean() -> dict[str, Any]:
    """100 echoes, every 100th request is slow: mean hides the tail that p99 shows."""
    eng = EchoMetricsEngine()
    rec = eng.run_closed(concurrency=1, slow_every=100, stop_after=100)
    return {
        **{k: rec[k] for k in (
            "n_completed", "n_slow", "measure_s", "qps",
            "mean_e2e", "p50_e2e", "p99_e2e", "max_e2e",
            "mean_service", "mean_wait", "t0", "t1",
        )},
        "service_s": SERVICE_S,
        "slow_s": SLOW_S,
        "mean_hides_tail": rec["mean_e2e"] < 1.0 and rec["p99_e2e"] >= 4.0,
        "p50_near_service": abs(rec["p50_e2e"] - SERVICE_S) <= 0.01,
        "t_end": rec["t1"],
    }


def run_utilization_burst() -> dict[str, Any]:
    """Same burst of extra clients, at half utilization vs a saturated pool."""
    # Headroom: concurrency 1, workers 2, utilization 0.5. Burst adds 4 one-shot clients
    # by temporarily raising concurrency via a separate closed run is not a burst.
    # We model the burst as a short closed-loop jump: compare p99/queue at N=1 vs N=2
    # when we also run N=1+burst equivalently as N=5 for one "wave".
    # Clearer: use the sweep rows' utilization and a dedicated burst by starting
    # extra arrivals on an already-busy engine.
    # Implemented as: after warmup of a base closed loop, inject `burst` additional
    # one-shot requests at the same instant, then continue to t_end.
    # To keep the engine API small, compare steady N=1 (util ~0.5) vs N=2 (util ~1.0)
    # plus a one-shot burst run built here with a thin wrapper using two phases
    # of concurrency... Simplest honest comparison: the already-measured utilization
    # and queue at N=1 vs N=2, and a burst run that starts 4 extra requests at t=warmup
    # on top of each base.
    from engine import EchoMetricsEngine as E

    def with_burst(base_n: int, burst: int) -> dict[str, Any]:
        eng = E()
        # Reuse run_closed for the base, then we cannot inject mid-run.
        # Instead, run_closed with concurrency = base_n, and report those
        # figures; burst is a second engine that uses concurrency = base_n + burst
        # for a short measure of 1.0s after warmup 0, capturing the initial wave.
        # That's not quite a burst on a steady system.
        # We'll add a small official burst by calling a dedicated helper if needed.
        return eng.run_closed(concurrency=base_n, measure_s=MEASURE_S, warmup_s=WARMUP_S)

    low = with_burst(1, 0)
    high = with_burst(2, 0)
    # Burst comparison: run N=1 and N=2 with a *short* extra concurrency spike
    # modeled as concurrency 1 vs 2 still, plus an N=5 short window against
    # the same pool (all 5 arrive at t=0, measure first wave completions).
    tight = E()  # same 2-worker pool as the rest of the lesson
    burst_tight = tight.run_closed(concurrency=5, one_shot=True)
    wide = E(workers=5)  # more idle capacity, higher idle cost
    burst_wide = wide.run_closed(concurrency=5, one_shot=True)
    return {
        "half_util": {
            "concurrency": 1,
            "utilization": low["utilization"],
            "qps": low["qps"],
            "p50": low["p50_e2e"],
            "p99": low["p99_e2e"],
            "avg_queue": low["avg_queue"],
            "mean_e2e": low["mean_e2e"],
            "mean_wait": low["mean_wait"],
        },
        "full_util": {
            "concurrency": 2,
            "utilization": high["utilization"],
            "qps": high["qps"],
            "p50": high["p50_e2e"],
            "p99": high["p99_e2e"],
            "avg_queue": high["avg_queue"],
            "mean_e2e": high["mean_e2e"],
            "mean_wait": high["mean_wait"],
        },
        "burst_on_two_workers": {
            "workers": 2,
            "n_completed": burst_tight["n_completed"],
            "mean_e2e": burst_tight["mean_e2e"],
            "p50_e2e": burst_tight["p50_e2e"],
            "p99_e2e": burst_tight["p99_e2e"],
            "max_e2e": burst_tight["max_e2e"],
            "mean_wait": burst_tight["mean_wait"],
            "t1": burst_tight["t1"],
        },
        "burst_on_five_workers": {
            "workers": 5,
            "n_completed": burst_wide["n_completed"],
            "mean_e2e": burst_wide["mean_e2e"],
            "p50_e2e": burst_wide["p50_e2e"],
            "p99_e2e": burst_wide["p99_e2e"],
            "max_e2e": burst_wide["max_e2e"],
            "mean_wait": burst_wide["mean_wait"],
            "t1": burst_wide["t1"],
        },
        "high_util_less_idle": high["utilization"] > low["utilization"] + 0.4,
        "high_util_less_headroom": (
            burst_tight["max_e2e"] > burst_wide["max_e2e"] + 1e-6
            and burst_wide["mean_wait"] == 0.0
        ),
        "t_end": max(low["t1"], high["t1"], burst_tight["t1"], burst_wide["t1"]),
    }


def run() -> dict[str, Any]:
    sweep = run_concurrency_sweep()
    qt = run_qps_vs_tps()
    tail = run_tail_vs_mean()
    burst = run_utilization_burst()
    return {
        "engine": "EchoMetricsEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_metrics_product": True,
        "not_prometheus": True,
        "not_google_sre_production": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "workers": WORKERS,
        "service_s": SERVICE_S,
        "slow_s": SLOW_S,
        "warmup_s": WARMUP_S,
        "measure_s": MEASURE_S,
        "sweep": sweep,
        "qps_tps": qt,
        "tail": tail,
        "burst": burst,
        "acceptance_throughput_plateau": sweep["throughput_plateau"] and sweep["e2e_grows_after_saturation"],
        "acceptance_service_vs_e2e": sweep["service_time_unchanged"] and sweep["e2e_grows_after_saturation"],
        "practice_records_qps_and_percentiles": all(
            r["p50_e2e"] is not None and r["p99_e2e"] is not None and r["qps"] > 0
            for r in sweep["rows"]
        ),
        "pitfall_mean_hides_tail": tail["mean_hides_tail"] and tail["p50_near_service"],
        "tradeoff_util_vs_headroom": burst["high_util_less_idle"] and burst["high_util_less_headroom"],
        "little_holds_when_stable": sweep["little_holds_in_steady_state"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
