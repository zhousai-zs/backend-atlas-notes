#!/usr/bin/env python3
"""Teaching EchoMetricsEngine — not Redis, not a real metrics product, not a network service.

A Python 3 standard-library model of a closed-loop Echo service with a fixed
worker pool and a FIFO queue. It is used to watch throughput (QPS / TPS)
and end-to-end percentiles as concurrency rises, to check Little's law in a
stable window, and to contrast mean latency with p99.

The named source (checked on 2026-11-14) is Google SRE Chapter 6, Monitoring
Distributed Systems, at https://sre.google/sre-book/monitoring-distributed-systems/.
That chapter defines the four golden signals (latency, traffic, errors,
saturation), distinguishes a slow average from a slow tail, and describes
traffic as a system-specific demand metric such as HTTP requests per second
or transactions and retrievals per second. It does not define the acronyms
QPS or TPS, and it does not state Little's law; those names and the
stability premise used here come from this node and the teaching model.
This engine is not Google production monitoring, not Borgmon or Prometheus,
and not a network service. There is no TCP, no real clock, and no disk.
Clock is virtual. service_s, slow_s, and the measure window are teaching
delays, not production RTT.
"""
from __future__ import annotations

import heapq
import math
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
KEY_TITLE = "article:01:title"
WORKERS = 2
SERVICE_S = 0.10
SLOW_S = 5.00
WARMUP_S = 1.00
MEASURE_S = 10.00


def ts(t: float, nd: int = 2) -> float:
    return round(float(t) + 1e-12, nd)


def ts4(t: float) -> float:
    return ts(t, 4)


def percentile(xs: list[float], p: float) -> Optional[float]:
    """Floor percentile: index = min(n-1, floor(p/100 * n)).

    With 100 samples and one slow request at the end, p99 is that slow
    value. This is a teaching choice, documented here, not a standard
    from the SRE chapter.
    """
    if not xs:
        return None
    s = sorted(xs)
    n = len(s)
    if p >= 100:
        return ts4(s[-1])
    idx = int((p / 100.0) * n)
    if idx >= n:
        idx = n - 1
    return ts4(s[idx])


@dataclass(order=True)
class Event:
    t: float
    seq: int
    kind: str = field(compare=False)
    payload: dict[str, Any] = field(compare=False, default_factory=dict)


class EchoMetricsEngine:
    def __init__(
        self,
        *,
        workers: int = WORKERS,
        service_s: float = SERVICE_S,
        slow_s: float = SLOW_S,
        title: str = TITLE_V1,
    ) -> None:
        if workers < 1:
            raise ValueError("workers must be >= 1")
        self.workers = int(workers)
        self.service_s = float(service_s)
        self.slow_s = float(slow_s)
        self.title = title
        self.key = KEY_TITLE
        self.clock = 0.0
        self._seq = 0
        self._req_seq = 0
        self.events: list[Event] = []
        self.queue: list[int] = []
        self.busy = 0
        self.in_system = 0
        self.requests: dict[int, dict[str, Any]] = {}
        self.completed: list[dict[str, Any]] = []
        self._area_system = 0.0
        self._area_queue = 0.0
        self._busy_time = 0.0
        self._area_t = 0.0
        self._window_start: Optional[float] = None

    def now(self) -> float:
        return self.clock

    def _push(self, t: float, kind: str, **payload: Any) -> None:
        self._seq += 1
        heapq.heappush(self.events, Event(t, self._seq, kind, payload))

    def _advance_areas(self, t: float) -> None:
        if t < self._area_t:
            return
        dt = t - self._area_t
        if self._window_start is not None and t > self._window_start:
            # Only count the overlap with the open window.
            start = max(self._area_t, self._window_start)
            dtw = t - start
            if dtw > 0:
                self._area_system += self.in_system * dtw
                self._area_queue += len(self.queue) * dtw
                self._busy_time += self.busy * dtw
        self._area_t = t
        self.clock = t

    def _service_time(self, req: dict[str, Any]) -> float:
        return self.slow_s if req.get("slow") else self.service_s

    def _try_start(self) -> None:
        while self.busy < self.workers and self.queue:
            rid = self.queue.pop(0)
            req = self.requests[rid]
            self.busy += 1
            req["t_start"] = self.clock
            req["wait_s"] = self.clock - req["t_arrive"]
            dur = self._service_time(req)
            req["service_s"] = dur
            self._push(self.clock + dur, "complete", rid=rid)

    def _arrive(self, *, client: int, slow: bool, txn_id: Optional[int], txn_step: int, txn_steps: int) -> None:
        self._req_seq += 1
        rid = self._req_seq
        self.requests[rid] = {
            "id": rid,
            "client": client,
            "slow": slow,
            "t_arrive": self.clock,
            "txn_id": txn_id,
            "txn_step": txn_step,
            "txn_steps": txn_steps,
            "title": self.title,
            "key": self.key,
        }
        self.in_system += 1
        self.queue.append(rid)
        self._try_start()

    def _complete(self, rid: int) -> Optional[int]:
        req = self.requests[rid]
        req["t_complete"] = self.clock
        req["e2e_s"] = self.clock - req["t_arrive"]
        self.busy -= 1
        self.in_system -= 1
        self.completed.append(req)
        self._try_start()
        return req["client"]

    def run_closed(
        self,
        *,
        concurrency: int,
        measure_s: float = MEASURE_S,
        warmup_s: float = WARMUP_S,
        slow_every: int = 0,
        txn_steps: int = 1,
        stop_after: Optional[int] = None,
        one_shot: bool = False,
    ) -> dict[str, Any]:
        """Closed-loop load: `concurrency` clients, each sends the next request immediately.

        A transaction is `txn_steps` sequential echo queries. QPS counts queries;
        TPS counts finished transactions. Times are on the virtual clock.
        """
        if concurrency < 1:
            raise ValueError("concurrency must be >= 1")
        if txn_steps < 1:
            raise ValueError("txn_steps must be >= 1")
        # Reset runtime state (constructor values kept).
        self.clock = 0.0
        self._seq = 0
        self._req_seq = 0
        self.events.clear()
        self.queue.clear()
        self.busy = 0
        self.in_system = 0
        self.requests.clear()
        self.completed.clear()
        self._area_system = 0.0
        self._area_queue = 0.0
        self._busy_time = 0.0
        self._area_t = 0.0
        self._window_start = None

        next_txn = 0
        txns_done = 0
        client_step = {i: 0 for i in range(concurrency)}
        client_txn = {}

        def is_slow(next_id: int) -> bool:
            return bool(slow_every and next_id % slow_every == 0)

        def start_txn(client: int) -> None:
            nonlocal next_txn
            next_txn += 1
            client_txn[client] = next_txn
            client_step[client] = 1
            self._arrive(
                client=client,
                slow=is_slow(self._req_seq + 1),
                txn_id=next_txn,
                txn_step=1,
                txn_steps=txn_steps,
            )

        # First arrivals at t=0.
        for c in range(concurrency):
            start_txn(c)

        t_end = warmup_s + measure_s
        started_window = False
        # If stop_after is set, ignore the time window and stop after that
        # many *query* completions (used by the tail experiment).
        while self.events:
            ev = heapq.heappop(self.events)
            if ev.kind == "reschedule_skip":
                continue
            if stop_after is None and ev.t > t_end:
                if not started_window and ev.t >= warmup_s:
                    if self._area_t < warmup_s:
                        self._advance_areas(warmup_s)
                    self._area_system = 0.0
                    self._area_queue = 0.0
                    self._busy_time = 0.0
                    self._area_t = warmup_s
                    self._window_start = warmup_s
                    started_window = True
                if started_window:
                    self._advance_areas(t_end)
                break
            self._advance_areas(ev.t)
            if ev.kind == "complete":
                client = self._complete(ev.payload["rid"])
                req = self.requests[ev.payload["rid"]]
                step = req["txn_step"]
                # Next step or next transaction.
                if one_shot:
                    if step < txn_steps:
                        client_step[client] = step + 1
                        self._arrive(
                            client=client,
                            slow=is_slow(self._req_seq + 1),
                            txn_id=req["txn_id"],
                            txn_step=step + 1,
                            txn_steps=txn_steps,
                        )
                    continue
                if stop_after is not None and len(self.completed) >= stop_after:
                    continue
                if self.clock >= t_end and stop_after is None:
                    continue
                if step < txn_steps:
                    client_step[client] = step + 1
                    self._arrive(
                        client=client,
                        slow=is_slow(self._req_seq + 1),
                        txn_id=req["txn_id"],
                        txn_step=step + 1,
                        txn_steps=txn_steps,
                    )
                else:
                    txns_done += 1
                    if self.clock < t_end or stop_after is not None:
                        start_txn(client)
            if not started_window and stop_after is None and ev.t >= warmup_s:
                # Open the measure window exactly at warmup_s.
                if self._area_t < warmup_s:
                    self._advance_areas(warmup_s)
                self._area_system = 0.0
                self._area_queue = 0.0
                self._busy_time = 0.0
                self._area_t = warmup_s
                self._window_start = warmup_s
                started_window = True
                # Continue so this event's time is integrated inside the window.
            if stop_after is None and self.clock >= t_end and self.busy == 0 and not self.queue:
                break
            if stop_after is not None and len(self.completed) >= stop_after and self.busy == 0 and not self.queue:
                break

        if stop_after is None:
            # Close the window at t_end (or now if we finished later mid-request).
            close = max(self.clock, t_end) if self._window_start is not None else self.clock
            if self._window_start is not None:
                self._advance_areas(close)
            t0 = self._window_start if self._window_start is not None else 0.0
            t1 = close
            window = [r for r in self.completed if r["t_complete"] > t0 + 1e-12 and r["t_complete"] <= t1 + 1e-12]
        else:
            t0 = 0.0
            t1 = self.clock
            self._window_start = 0.0
            # Recompute areas over the whole run for the tail experiment.
            # Areas were not tracked with a window; use completed only.
            window = list(self.completed)
            # Build L from the completed requests' occupancy? Skip Little here
            # if we didn't integrate. We'll integrate by replaying? Simpler:
            # set window stats from a post-pass below if needed.
        measure = t1 - t0 if t1 > t0 else 0.0
        e2es = [r["e2e_s"] for r in window]
        waits = [r["wait_s"] for r in window]
        services = [r["service_s"] for r in window]
        n = len(window)
        qps = n / measure if measure > 0 else 0.0
        # Transactions completed in the window: those whose last step fell in it.
        txn_done_in_window = sum(1 for r in window if r["txn_step"] == r["txn_steps"])
        tps = txn_done_in_window / measure if measure > 0 else 0.0
        mean_e2e = sum(e2es) / n if n else 0.0
        mean_wait = sum(waits) / n if n else 0.0
        mean_svc = sum(services) / n if n else 0.0
        if stop_after is None and measure > 0:
            l_avg = self._area_system / measure
            q_avg = self._area_queue / measure
            util = self._busy_time / (self.workers * measure)
        else:
            # Occupancy from completed sojourns (stable closed run of fixed N).
            l_avg = sum(e2es) / measure if measure > 0 else 0.0
            q_avg = sum(waits) / measure if measure > 0 else 0.0
            util = sum(services) / (self.workers * measure) if measure > 0 else 0.0
        little_rhs = qps * mean_e2e
        little_abs_err = abs(l_avg - little_rhs)
        little_holds = little_abs_err <= 1e-6 or (l_avg > 0 and little_abs_err / l_avg <= 0.02)
        slow_n = sum(1 for r in window if r["slow"])
        return {
            "concurrency": concurrency,
            "workers": self.workers,
            "service_s": self.service_s,
            "slow_s": self.slow_s,
            "slow_every": slow_every,
            "txn_steps": txn_steps,
            "warmup_s": 0.0 if stop_after is not None else warmup_s,
            "t0": ts4(t0),
            "t1": ts4(t1),
            "measure_s": ts4(measure),
            "n_completed": n,
            "n_slow": slow_n,
            "n_txns": txn_done_in_window,
            "qps": ts4(qps),
            "tps": ts4(tps),
            "mean_e2e": ts4(mean_e2e),
            "mean_wait": ts4(mean_wait),
            "mean_service": ts4(mean_svc),
            "p50_e2e": percentile(e2es, 50),
            "p99_e2e": percentile(e2es, 99),
            "max_e2e": ts4(max(e2es) if e2es else 0.0),
            "l_avg": ts4(l_avg),
            "lambda_times_w": ts4(little_rhs),
            "little_abs_err": ts4(little_abs_err),
            "little_holds": little_holds,
            "avg_queue": ts4(q_avg),
            "utilization": ts4(util),
            "workers_saturated": util >= 0.99,
        }

