"""Official openai==3.51.0 client against a MockTransport. No paid calls."""

from __future__ import annotations

import json
from typing import Any

import httpx
from openai import OpenAI, APIStatusError, APITimeoutError
from openai import __version__ as openai_version


def _client(handler, *, max_retries: int = 0, timeout: float = 2.0) -> OpenAI:
    http = httpx.Client(transport=httpx.MockTransport(handler), timeout=timeout)
    # Placeholder key is never sent to a real host; MockTransport intercepts.
    return OpenAI(
        api_key="sk-unused-offline-placeholder",
        http_client=http,
        max_retries=max_retries,
    )


def _scripted(handler):
    return httpx.MockTransport(handler)


def _ok_body() -> dict[str, Any]:
    return {
        "id": "chatcmpl-offline-ok",
        "object": "chat.completion",
        "created": 0,
        "model": "offline-scripted",
        "choices": [
            {
                "index": 0,
                "finish_reason": "stop",
                "message": {"role": "assistant", "content": "final-answer"},
            }
        ],
        "usage": {"prompt_tokens": 4, "completion_tokens": 2, "total_tokens": 6},
    }


def run() -> dict[str, Any]:
    hits: list[str] = []

    def only_ok(request: httpx.Request) -> httpx.Response:
        hits.append(f"{request.method} {request.url.path}")
        return httpx.Response(200, json=_ok_body(), request=request)

    c = _client(only_ok, max_retries=0)
    done = c.chat.completions.create(
        model="offline-scripted",
        messages=[{"role": "user", "content": "hello"}],
    )
    usage = done.usage
    assert done.choices[0].finish_reason == "stop"
    assert done.choices[0].message.content == "final-answer"
    assert usage is not None and usage.total_tokens == 6

    # 429: with max_retries=0 the official client surfaces APIStatusError.
    def always_429(request: httpx.Request) -> httpx.Response:
        hits.append("429")
        return httpx.Response(
            429,
            json={"error": {"message": "rate limited", "type": "rate_limit_error"}},
            headers={"Retry-After": "1"},
            request=request,
        )

    limited = _client(always_429, max_retries=0)
    status = None
    try:
        limited.chat.completions.create(
            model="offline-scripted",
            messages=[{"role": "user", "content": "hello"}],
        )
    except APIStatusError as exc:
        status = exc.status_code
    assert status == 429

    # 429 then success: official retries when max_retries>=1.
    n = {"k": 0}

    def once_429(request: httpx.Request) -> httpx.Response:
        n["k"] += 1
        if n["k"] == 1:
            return httpx.Response(
                429,
                json={"error": {"message": "rate limited", "type": "rate_limit_error"}},
                headers={"Retry-After": "0"},
                request=request,
            )
        return httpx.Response(200, json=_ok_body(), request=request)

    recovered = _client(once_429, max_retries=2)
    rec = recovered.chat.completions.create(
        model="offline-scripted",
        messages=[{"role": "user", "content": "hello"}],
    )
    assert rec.choices[0].finish_reason == "stop"
    assert n["k"] == 2

    # Incomplete finish_reason=length is not a completed final answer.
    def cut(request: httpx.Request) -> httpx.Response:
        body = _ok_body()
        body["choices"][0]["finish_reason"] = "length"
        body["choices"][0]["message"]["content"] = "partial-"
        body["usage"] = {"prompt_tokens": 4, "completion_tokens": 1, "total_tokens": 5}
        return httpx.Response(200, json=body, request=request)

    incomplete = _client(cut, max_retries=0).chat.completions.create(
        model="offline-scripted",
        messages=[{"role": "user", "content": "hello"}],
    )
    assert incomplete.choices[0].finish_reason == "length"
    assert incomplete.choices[0].message.content == "partial-"

    return {
        "openai_version": openai_version,
        "used_mock_transport": True,
        "is_live_paid_api": False,
        "is_live_model": False,
        "success_usage_total_tokens": usage.total_tokens,
        "status_429_without_retry": status,
        "retry_then_success_attempts": n["k"],
        "length_finish_is_not_complete": incomplete.choices[0].finish_reason == "length",
        "official_path": (
            "pip install 'openai==3.51.0'; "
            "client = OpenAI(); "
            "client.chat.completions.create(...) or client.responses.create(...). "
            "This file never sends a request to api.openai.com."
        ),
    }
