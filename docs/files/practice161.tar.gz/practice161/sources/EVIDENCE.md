# 第 161 课官方来源核对（2026-11-15，北京时间）

本次全部为公共 Web 抓取，未使用付费模型 API，未持有或发送 OpenAI 密钥。节点 `verifiedAt` 为 2026-10-26，与本次核对日期不同。正文里的版本与弃用结论以本文件为准。时间已换算为北京时间（Asia/Shanghai，UTC+8）。

## 主资源

| 来源 | URL | HTTP | 最终 URL 是否跳转 | 字节 | 响应 Date（北京时间） | Last-Modified（北京时间） | 要点 |
| --- | --- | ---: | --- | ---: | --- | --- | --- |
| OpenAI Python SDK README（GitHub raw, main） | https://raw.githubusercontent.com/openai/openai-python/main/README.md | 200 | 否 | 43144 | 2026-11-15 22:43:55 | （未提供） | 与下一行文档站点 Markdown 正文等长且内容一致 |
| OpenAI Python library 文档（developers） | https://developers.openai.com/api/reference/python/index.md | 200 | 否 | 43144 | 2026-11-15 22:43:56 | （未提供） | 与 README 相同文本 |
| GitHub 仓库页 | https://github.com/openai/openai-python | 200 | 否 | 665337 | 2026-11-15 22:43:55 | （未提供） | 标题：GitHub - openai/openai-python: The official Python library for the OpenAI API |
| PyPI JSON | https://pypi.org/pypi/openai/json | 200 | 否 | 725051 | 2026-11-15 22:43:56 | （未提供） | 当前稳定版 `openai 3.51.0`，`requires_python >=3.10`，未 yanked；wheel 上传时间 2026-11-13 21:13:37 UTC，合北京时间 2026-11-14 05:13:37 |
| SDK `_constants.py`（v3.51.0 标签与 main） | https://raw.githubusercontent.com/openai/openai-python/v3.51.0/src/openai/_constants.py 与 `.../main/src/openai/_constants.py` | 200 | 否 | 548 | 2026-11-15 22:44:39 | （未提供） | 两份文件内容相同 |
| SDK `_base_client.py`（main） | https://raw.githubusercontent.com/openai/openai-python/main/src/openai/_base_client.py | 200 | 否 | 84184 | 2026-11-15 22:44:07 | （未提供） | 用于对照 `_should_retry` 与退避计算；可能略新于 3.51.0 的其它文件，但常量文件已与 3.51.0 一致 |
| SDK `_streaming.py`（main） | https://raw.githubusercontent.com/openai/openai-python/main/src/openai/_streaming.py | 200 | 否 | 16229 | 2026-11-15 22:44:39 | （未提供） | 流式读取超时包装为 `APITimeoutError` |

GitHub Releases API `https://api.github.com/repos/openai/openai-python/releases?per_page=5` 返回 **403**（2026-11-15 22:44:07 北京时间）。因此版本结论以 PyPI `3.51.0` 为准，不编造 GitHub release 标签列表。

## 跟随阅读

| 来源 | URL | HTTP | 字节 | 响应 Date（北京时间） | Last-Modified（北京时间） |
| --- | --- | ---: | ---: | --- | --- |
| Streaming API responses（Markdown） | https://developers.openai.com/api/docs/guides/streaming-responses.md | 200 | 7112 | 2026-11-15 22:44:07 | 2026-11-14 12:35:09 |
| 同上 HTML | https://developers.openai.com/api/docs/guides/streaming-responses | 200 | 553761 | 2026-11-15 22:43:56 | 2026-11-14 11:21:52 |
| Migrate to the Responses API（Markdown） | https://developers.openai.com/api/docs/guides/migrate-to-responses.md | 200 | 63189 | 2026-11-15 22:44:07 | 2026-11-14 12:37:28 |
| 同上 HTML | https://developers.openai.com/api/docs/guides/migrate-to-responses | 200 | 1019230 | 2026-11-15 22:43:56 | 2026-11-15 15:21:47 |
| Deprecations（Markdown） | https://developers.openai.com/api/docs/deprecations.md | 200 | 见抓取文件 | 2026-11-15 22:44:07 | 2026-11-14 12:03:54 |
| 同上 HTML | https://developers.openai.com/api/docs/deprecations | 200 | 446051 | 2026-11-15 22:43:56 | 2026-11-14 16:03:30 |
| Error codes（Markdown） | https://developers.openai.com/api/docs/guides/error-codes.md | 200 | 32328 | 2026-11-15 22:44:07 | 2026-11-14 13:03:40 |
| Rate limits（Markdown） | https://developers.openai.com/api/docs/guides/rate-limits.md | 200 | 24742 | 2026-11-15 22:44:32 | 2026-11-14 11:14:18 |

上述 Markdown 页最终 URL 均与请求 URL 相同，无跳转。HTML 与 Markdown 的 `Last-Modified` 可能不同，引用以 Markdown 正文为准。

## 当日摘录（易变接口，不是实验观测）

- README / 文档：默认 `max_retries=2`，指数退避；默认重试连接错误、408、409、429 与 >=500；“Requests are retried only when their body can be safely resent.”；`max_retries=0` 关闭重试。
- README：流式消费“Stream consumption is not automatically retried, because replaying a request could duplicate output already delivered to your application.”
- README：默认超时 10 分钟；超时抛出 `APITimeoutError`；“requests that time out are retried twice by default”。
- README：成功响应用 `_request_id`（来自 `x-request-id`，该属性虽以下划线开头但是公开的）；失败请求须捕获 `APIStatusError` 并读 `exc.request_id`。
- `_constants.py`（3.51.0）：`DEFAULT_TIMEOUT = httpx2.Timeout(timeout=600, connect=5.0)`，`DEFAULT_MAX_RETRIES = 2`，`INITIAL_RETRY_DELAY = 0.5`，`MAX_RETRY_DELAY = 8.0`，`MAX_RETRY_AFTER_DELAY = 2 * 60`。默认 HTTP 客户端已是 HTTPX2。
- `_base_client.py`：`Retry-After` / `retry-after-ms` 超过 `MAX_RETRY_AFTER_DELAY` 则不重试；否则按指数退避，并将时延随机减少 0–25%。
- 迁移文档原文：“While Chat Completions remains supported, Responses is recommended for all new projects.”
- 弃用页：Assistants API 的 shutdown date 为 2026-08-26，推荐改走 Responses / Conversations；当日「Feature and endpoint deprecations」表未将 Chat Completions 列为即将关停的端点。
- 限流文档：429 可能带 `Retry-After`，应视为下限并加抖动；不要重试额度/账单类错误；若应用自己做重试，应关闭或计入 SDK 重试，以免嵌套放大。文档示例模型名（如 `gpt-6-luna`、`gpt-6-astra`、README 中的 `gpt-5.5`）随页面变化，本次未实调。

抓取正文保存在本目录对应 `.body` / `.py` 文件中。
