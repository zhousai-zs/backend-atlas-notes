#!/usr/bin/env python3
"""Local HTTP mock for lesson 161. This is a teaching protocol, not the OpenAI API."""

from __future__ import annotations

import json
import socket
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse


class LessonMockState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.calls: dict[str, int] = {}
        self.side_effects: int = 0
        self.seen_hosts: list[str] = []

    def bump(self, key: str) -> int:
        with self.lock:
            self.calls[key] = self.calls.get(key, 0) + 1
            return self.calls[key]

    def add_side_effect(self) -> int:
        with self.lock:
            self.side_effects += 1
            return self.side_effects

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "calls": dict(self.calls),
                "side_effects": self.side_effects,
                "seen_hosts": list(self.seen_hosts),
            }


def _sse(event: str, data: dict[str, Any]) -> bytes:
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return f"event: {event}\ndata: {payload}\n\n".encode("utf-8")


def make_handler(state: LessonMockState) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt: str, *args: Any) -> None:
            sys_stderr_write = self.server.log  # type: ignore[attr-defined]
            sys_stderr_write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

        def _read_json(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length else b"{}"
            if not raw:
                return {}
            return json.loads(raw.decode("utf-8"))

        def _request_id(self) -> str:
            return "req_" + uuid.uuid4().hex[:16]

        def _send_headers(self, status: int, content_type: str, request_id: str, extra: dict[str, str] | None = None, length: int | None = None, chunked: bool = False) -> None:
            try:
                self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError:
                pass
            self.close_connection = True
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("X-Request-Id", request_id)
            if chunked:
                self.send_header("Transfer-Encoding", "chunked")
            elif length is not None:
                self.send_header("Content-Length", str(length))
            if extra:
                for key, value in extra.items():
                    self.send_header(key, value)
            self.send_header("Connection", "close")
            self.end_headers()

        def _write_raw(self, data: bytes) -> None:
            try:
                self.wfile.write(data)
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
                return

        def _write_chunk(self, data: bytes) -> None:
            header = f"{len(data):X}\r\n".encode("ascii")
            self._write_raw(header + data + b"\r\n")

        def _end_chunks(self) -> None:
            self._write_raw(b"0\r\n\r\n")

        def _json(self, status: int, body: dict[str, Any], request_id: str, extra: dict[str, str] | None = None) -> None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self._send_headers(status, "application/json", request_id, extra, length=len(data))
            self._write_raw(data)

        def do_GET(self) -> None:
            if urlparse(self.path).path == "/health":
                body = {"ok": True}
                data = json.dumps(body).encode("utf-8")
                self._send_headers(200, "application/json", "req_health", length=len(data))
                self._write_raw(data)
                return
            if urlparse(self.path).path == "/state":
                body = state.snapshot()
                data = json.dumps(body).encode("utf-8")
                self._send_headers(200, "application/json", "req_state", length=len(data))
                self._write_raw(data)
                return
            self._json(404, {"error": {"type": "not_found", "message": "unknown path"}}, self._request_id())

        def do_POST(self) -> None:
            host = self.headers.get("Host", "")
            with state.lock:
                state.seen_hosts.append(host)
            path = urlparse(self.path).path
            if path != "/v1/lesson/responses":
                self._json(404, {"error": {"type": "not_found", "message": "unknown path"}}, self._request_id())
                return
            try:
                body = self._read_json()
            except json.JSONDecodeError:
                self._json(400, {"error": {"type": "bad_request", "message": "invalid json"}}, self._request_id())
                return

            case = str(body.get("case") or self.headers.get("X-Lesson-Case") or "success")
            stream = bool(body.get("stream", False))
            has_tools = bool(body.get("tools"))
            request_id = self._request_id()
            attempt = state.bump(case)

            if case == "timeout":
                time.sleep(1.5)
                self._complete(request_id, "late-ok", usage=(2, 1, 3), stream=stream)
                return

            if case == "timeout_with_tool":
                state.add_side_effect()
                time.sleep(1.5)
                self._complete(request_id, "charged", usage=(2, 1, 3), stream=stream)
                return

            if case == "429_then_ok":
                if attempt <= 2:
                    self._json(
                        429,
                        {"error": {"type": "rate_limit_error", "message": "slow down", "attempt": attempt}},
                        request_id,
                        extra={"Retry-After": "0.12"},
                    )
                    return
                self._complete(request_id, "after-backoff", usage=(4, 6, 10), stream=stream)
                return

            if case == "429_always":
                self._json(
                    429,
                    {"error": {"type": "rate_limit_error", "message": "still limited", "attempt": attempt}},
                    request_id,
                    extra={"Retry-After": "0.05"},
                )
                return

            if case == "400_bad_request":
                self._json(400, {"error": {"type": "bad_request", "message": "unknown parameter"}}, request_id)
                return

            if case == "401_auth":
                self._json(401, {"error": {"type": "invalid_api_key", "message": "invalid mock key"}}, request_id)
                return

            if case == "500_then_ok":
                if attempt == 1:
                    self._json(500, {"error": {"type": "internal_error", "message": "transient"}}, request_id)
                    return
                self._complete(request_id, "recovered", usage=(3, 2, 5), stream=stream)
                return

            if case == "invalid_body":
                # HTTP 200 with a payload that must fail client-side validation.
                payload = {"ok": True, "text": "missing-id-and-usage"}
                data = json.dumps(payload).encode("utf-8")
                self._send_headers(200, "application/json", request_id, length=len(data))
                self._write_raw(data)
                return

            if case == "midstream_cut":
                self._send_headers(200, "text/event-stream", request_id, chunked=True)
                self._write_chunk(_sse("response.created", {"type": "response.created", "id": "resp_cut", "request_id": request_id}))
                self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": "未完"}))
                self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": "成片"}))
                # Close without response.completed or the chunked terminator.
                return

            if case == "stream_timeout":
                self._send_headers(200, "text/event-stream", request_id, chunked=True)
                self._write_chunk(_sse("response.created", {"type": "response.created", "id": "resp_slow", "request_id": request_id}))
                self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": "开头"}))
                time.sleep(1.5)
                self._write_chunk(_sse("response.completed", {"type": "response.completed", "id": "resp_slow", "output_text": "开头结尾", "usage": _usage(2, 2, 4)}))
                self._end_chunks()
                return

            if case == "slow_stream":
                self._send_headers(200, "text/event-stream", request_id, chunked=True)
                self._write_chunk(_sse("response.created", {"type": "response.created", "id": "resp_slow2", "request_id": request_id}))
                self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": "第一"}))
                time.sleep(0.35)
                self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": "第二"}))
                self._write_chunk(_sse("response.completed", {"type": "response.completed", "id": "resp_slow2", "output_text": "第一第二", "usage": _usage(1, 2, 3)}))
                self._end_chunks()
                return

            text = "可靠客户端"
            if has_tools:
                state.add_side_effect()
            self._complete(request_id, text, usage=(5, 4, 9), stream=stream or case == "success_stream")

        def _complete(self, request_id: str, text: str, usage: tuple[int, int, int], stream: bool) -> None:
            usage_obj = _usage(*usage)
            if stream:
                self._send_headers(200, "text/event-stream", request_id, chunked=True)
                self._write_chunk(_sse("response.created", {"type": "response.created", "id": "resp_ok", "request_id": request_id}))
                for part in _chunks(text):
                    self._write_chunk(_sse("response.output_text.delta", {"type": "response.output_text.delta", "delta": part}))
                self._write_chunk(
                    _sse(
                        "response.completed",
                        {"type": "response.completed", "id": "resp_ok", "output_text": text, "usage": usage_obj},
                    )
                )
                self._end_chunks()
                return
            self._json(
                200,
                {
                    "id": "resp_ok",
                    "status": "completed",
                    "output_text": text,
                    "usage": usage_obj,
                },
                request_id,
            )

    return Handler


def _usage(inp: int, out: int, total: int) -> dict[str, int]:
    return {"input_tokens": inp, "output_tokens": out, "total_tokens": total}


def _chunks(text: str) -> list[str]:
    if not text:
        return [""]
    return [text[i : i + 2] for i in range(0, len(text), 2)]


class LessonMockServer:
    def __init__(self) -> None:
        self.state = LessonMockState()
        handler = make_handler(self.state)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.httpd.log = lambda msg: print(msg, end="")  # type: ignore[attr-defined]
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="lesson161-mock", daemon=True)

    @property
    def url(self) -> str:
        host, port = self.httpd.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> str:
        self.thread.start()
        return self.url

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
