# 第 161 课实践：模型 API 与可靠客户端

只使用 Python 3 标准库，在本机回环地址启动 HTTP 模拟服务，验证统一客户端的超时、429 退避、不可重试错误、流式中断、请求预算、响应校验、usage 与 request id。不调用付费模型 API，不需要密钥。

```bash
bash test.sh
```

成功时最后一行是 `ALL_CHECKS_PASSED`，并生成 `run.log` 与 `results.json`。日志里的 400/401/中途断流/超时是受控负例，不代表脚本整体失败。
