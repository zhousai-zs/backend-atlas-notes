#!/usr/bin/env python3
"""Teaching HTTP client for model-style requests. Talks only to a local mock."""

from __future__ import annotations

import http.client
import json
import socket
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


RETRYABLE_STATUS = frozenset({408, 409, 429}) | frozenset(range(500, 600))
NON_RETRYABLE_STATUS = frozenset({400, 401, 403, 404, 422})


@dataclass
class Usage:
    input_tokens: int
    output_tokens: int
    total_tokens: int

    def as_dict(self) -> dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass
class ModelResult:
    status: str
    output_text: str
    usage: Usage | None
    request_ids: list[str]
    attempts: int
    error: str | None
    finish_reason: str
    retry_sleeps: list[float] = field(default_factory=list)
    incomplete: bool = True
    http_status: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "output_text": self.output_text,
            "usage": None if self.usage is None else self.usage.as_dict(),
            "request_ids": list(self.request_ids),
            "attempts": self.attempts,
            "error": self.error,
            "finish_reason": self.finish_reason,
            "retry_sleeps": list(self.retry_sleeps),
            "incomplete": self.incomplete,
            "http_status": self.http_status,
        }


@dataclass
class RetryPolicy:
    max_retries: int = 2
    initial_delay: float = 0.05
    max_delay: float = 0.4
    max_retry_after: float = 2.0
    overall_deadline: float = 2.0
    jitter: float = 0.0  # official SDK uses up to 25%; tests default to 0 for asserts

    def backoff(self, retry_index: int, retry_after: float | None) -> float | None:
        """Return seconds to sleep, or None if the delay is not acceptable."""
        if retry_after is not None and retry_after > self.max_retry_after:
            return None
        if retry_after is not None and retry_after > 0:
            delay = retry_after
        else:
            delay = min(self.initial_delay * (2 ** retry_index), self.max_delay)
        if self.jitter:
            # Match the official SDK shape: reduce the delay by 0-jitter fraction.
            # Deterministic when jitter is 0.
            delay = delay * (1.0 - self.jitter * 0.5)
        return max(delay, 0.0)


class ReliableModelClient:
    """Minimal unified client around the lesson mock.

    It is not a wrapper of the openai package and does not call paid APIs.
    """

    def __init__(self, base_url: str, policy: RetryPolicy | None = None, timeout: float = 0.25) -> None:
        if not base_url.startswith("http://127.0.0.1:") and not base_url.startswith("http://localhost:"):
            raise ValueError("this teaching client only talks to a loopback mock")
        self.base_url = base_url.rstrip("/")
        self.policy = policy or RetryPolicy()
        self.timeout = timeout

    def complete(
        self,
        prompt: str,
        *,
        case: str = "success",
        stream: bool = False,
        tools: list[dict[str, Any]] | None = None,
        cancel_event: Any | None = None,
    ) -> ModelResult:
        started = time.monotonic()
        request_ids: list[str] = []
        sleeps: list[float] = []
        attempts = 0
        last: ModelResult | None = None
        max_attempts = self.policy.max_retries + 1

        while attempts < max_attempts:
            if cancel_event is not None and cancel_event.is_set():
                return self._cancelled(request_ids, attempts, sleeps, last)
            remaining = self.policy.overall_deadline - (time.monotonic() - started)
            if remaining <= 0:
                return self._budget_exceeded(request_ids, attempts, sleeps, last)
            attempt_timeout = min(self.timeout, remaining)
            attempts += 1
            result = self._once(
                prompt,
                case=case,
                stream=stream,
                tools=tools,
                timeout=attempt_timeout,
                cancel_event=cancel_event,
            )
            request_ids.extend(result.request_ids)
            result.request_ids = list(request_ids)
            result.attempts = attempts
            result.retry_sleeps = list(sleeps)
            last = result

            if result.status == "completed":
                return result
            if not self._should_retry(result, tools=tools, stream=stream):
                return result
            if attempts >= max_attempts:
                return result

            retry_after = result._retry_after if hasattr(result, "_retry_after") else None
            delay = self.policy.backoff(attempts - 1, retry_after)
            if delay is None:
                result.error = (result.error or "") + "; retry-after exceeds policy cap"
                result.finish_reason = "retry_after_capped"
                return result
            remaining = self.policy.overall_deadline - (time.monotonic() - started)
            if delay > remaining:
                result.status = "error"
                result.incomplete = True
                result.finish_reason = "budget_exhausted"
                result.error = "retry delay would exceed remaining request budget"
                return result
            if cancel_event is not None and cancel_event.is_set():
                return self._cancelled(request_ids, attempts, sleeps, result)
            time.sleep(delay)
            sleeps.append(delay)

        assert last is not None
        return last

    def _should_retry(self, result: ModelResult, *, tools: list[dict[str, Any]] | None, stream: bool) -> bool:
        # Never retry after any output has already been delivered.
        if result.output_text:
            return False
        # Do not automatically repeat a timed-out or cancelled call that may have
        # executed a side-effecting tool.
        if tools and result.finish_reason in {"timeout", "cancelled", "stream_interrupted"}:
            return False
        # Stream consumption is not retried: a replay could duplicate tokens.
        if stream and result.finish_reason in {"stream_interrupted", "timeout", "cancelled"}:
            return False
        if result.finish_reason in {"validation_failed", "cancelled", "budget_exhausted"}:
            return False
        if result.http_status in NON_RETRYABLE_STATUS:
            return False
        if result.http_status in RETRYABLE_STATUS:
            return True
        if result.finish_reason == "timeout" and not tools and not result.output_text:
            # Official SDK retries request-level timeouts by default when the
            # body can be resent. This teaching client does the same only when
            # no tools were involved and no stream tokens were delivered.
            return True
        if result.finish_reason == "connection_error":
            return True
        return False

    def _once(
        self,
        prompt: str,
        *,
        case: str,
        stream: bool,
        tools: list[dict[str, Any]] | None,
        timeout: float,
        cancel_event: Any | None,
    ) -> ModelResult:
        payload = {
            "model": "lesson-mock",
            "input": prompt,
            "stream": stream,
            "case": case,
        }
        if tools:
            payload["tools"] = tools
        body = json.dumps(payload).encode("utf-8")
        url = self.base_url + "/v1/lesson/responses"
        req = Request(
            url,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "X-Lesson-Case": case,
            },
        )
        started = time.monotonic()
        try:
            with urlopen(req, timeout=timeout) as resp:
                request_id = resp.headers.get("X-Request-Id") or resp.headers.get("x-request-id")
                content_type = resp.headers.get("Content-Type", "")
                status = resp.status
                if stream or "text/event-stream" in content_type:
                    return self._read_stream(resp, request_id=request_id, timeout=timeout, started=started, cancel_event=cancel_event)
                raw = resp.read()
                return self._parse_json(status, raw, request_id)
        except HTTPError as exc:
            raw = exc.read()
            request_id = exc.headers.get("X-Request-Id") if exc.headers else None
            retry_after = _parse_retry_after(exc.headers)
            result = self._parse_error(exc.code, raw, request_id)
            result._retry_after = retry_after  # type: ignore[attr-defined]
            return result
        except socket.timeout:
            return ModelResult(
                status="error",
                output_text="",
                usage=None,
                request_ids=[],
                attempts=1,
                error="socket timeout",
                finish_reason="timeout",
                incomplete=True,
            )
        except TimeoutError:
            return ModelResult(
                status="error",
                output_text="",
                usage=None,
                request_ids=[],
                attempts=1,
                error="timeout",
                finish_reason="timeout",
                incomplete=True,
            )
        except URLError as exc:
            reason = str(exc.reason) if exc.reason else str(exc)
            finish = "timeout" if "timed out" in reason.lower() else "connection_error"
            return ModelResult(
                status="error",
                output_text="",
                usage=None,
                request_ids=[],
                attempts=1,
                error=reason,
                finish_reason=finish,
                incomplete=True,
            )

    def _read_stream(self, resp: Any, *, request_id: str | None, timeout: float, started: float, cancel_event: Any | None) -> ModelResult:
        ids = [request_id] if request_id else []
        pieces: list[str] = []
        completed_text: str | None = None
        usage: Usage | None = None
        saw_completed = False
        buffer = b""
        try:
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    return ModelResult(
                        status="incomplete",
                        output_text="".join(pieces),
                        usage=None,
                        request_ids=ids,
                        attempts=1,
                        error="cancelled after partial stream",
                        finish_reason="cancelled",
                        incomplete=True,
                    )
                remaining = timeout - (time.monotonic() - started)
                if remaining <= 0:
                    raise TimeoutError("stream read exceeded attempt timeout")
                _set_socket_timeout(resp, max(remaining, 0.01))
                # Read a single line so a small flushed SSE frame is not blocked
                # behind a larger read() size while the server pauses mid-stream.
                line = resp.readline()
                if not line:
                    break
                buffer += line
                while b"\n\n" in buffer:
                    frame, buffer = buffer.split(b"\n\n", 1)
                    event, data = _parse_sse_frame(frame)
                    if not data:
                        continue
                    typ = data.get("type") or event
                    if typ == "response.output_text.delta":
                        pieces.append(str(data.get("delta") or ""))
                    elif typ == "response.completed":
                        saw_completed = True
                        completed_text = str(data.get("output_text") or "".join(pieces))
                        usage = _usage_from(data.get("usage"))
                    elif typ == "error":
                        return ModelResult(
                            status="error",
                            output_text="".join(pieces),
                            usage=None,
                            request_ids=ids,
                            attempts=1,
                            error=str(data.get("message") or "stream error event"),
                            finish_reason="stream_error",
                            incomplete=True,
                            http_status=200,
                        )
        except (socket.timeout, TimeoutError) as exc:
            return ModelResult(
                status="incomplete",
                output_text="".join(pieces),
                usage=None,
                request_ids=ids,
                attempts=1,
                error=str(exc),
                finish_reason="timeout",
                incomplete=True,
            )
        except http.client.IncompleteRead as exc:
            leftover = exc.partial or b""
            if leftover:
                buffer += leftover
            _drain_frames(buffer, pieces)
            text_so_far = "".join(pieces)
            return ModelResult(
                status="incomplete",
                output_text=text_so_far,
                usage=None,
                request_ids=ids,
                attempts=1,
                error="stream ended mid-chunk without response.completed",
                finish_reason="stream_interrupted",
                incomplete=True,
                http_status=200,
            )
        except (BrokenPipeError, ConnectionResetError, OSError) as exc:
            return ModelResult(
                status="incomplete",
                output_text="".join(pieces),
                usage=None,
                request_ids=ids,
                attempts=1,
                error=str(exc),
                finish_reason="stream_interrupted",
                incomplete=True,
            )

        text = completed_text if completed_text is not None else "".join(pieces)
        if not saw_completed:
            return ModelResult(
                status="incomplete",
                output_text=text,
                usage=None,
                request_ids=ids,
                attempts=1,
                error="stream ended without response.completed",
                finish_reason="stream_interrupted",
                incomplete=True,
                http_status=200,
            )
        if usage is None:
            return ModelResult(
                status="error",
                output_text=text,
                usage=None,
                request_ids=ids,
                attempts=1,
                error="completed event missing usage",
                finish_reason="validation_failed",
                incomplete=True,
                http_status=200,
            )
        return ModelResult(
            status="completed",
            output_text=text,
            usage=usage,
            request_ids=ids,
            attempts=1,
            error=None,
            finish_reason="stop",
            incomplete=False,
            http_status=200,
        )

    def _parse_json(self, status: int, raw: bytes, request_id: str | None) -> ModelResult:
        ids = [request_id] if request_id else []
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError as exc:
            return ModelResult(
                status="error",
                output_text="",
                usage=None,
                request_ids=ids,
                attempts=1,
                error=f"invalid json: {exc}",
                finish_reason="validation_failed",
                incomplete=True,
                http_status=status,
            )
        if status >= 400:
            return self._error_from_body(status, data, ids)
        required = ("id", "output_text", "usage")
        missing = [key for key in required if key not in data]
        usage = _usage_from(data.get("usage")) if "usage" in data else None
        if missing or usage is None or not isinstance(data.get("output_text"), str) or not data.get("id"):
            return ModelResult(
                status="error",
                output_text=str(data.get("output_text") or ""),
                usage=usage,
                request_ids=ids,
                attempts=1,
                error="response failed validation: missing id, output_text, or usage",
                finish_reason="validation_failed",
                incomplete=True,
                http_status=status,
            )
        return ModelResult(
            status="completed",
            output_text=data["output_text"],
            usage=usage,
            request_ids=ids,
            attempts=1,
            error=None,
            finish_reason="stop",
            incomplete=False,
            http_status=status,
        )

    def _parse_error(self, status: int, raw: bytes, request_id: str | None) -> ModelResult:
        ids = [request_id] if request_id else []
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except json.JSONDecodeError:
            data = {"error": {"message": raw.decode("utf-8", errors="replace")}}
        return self._error_from_body(status, data, ids)

    def _error_from_body(self, status: int, data: dict[str, Any], ids: list[str]) -> ModelResult:
        message = ""
        err = data.get("error")
        if isinstance(err, dict):
            message = str(err.get("message") or err)
        elif err:
            message = str(err)
        reason = "http_error"
        if status == 429:
            reason = "rate_limited"
        elif status in NON_RETRYABLE_STATUS:
            reason = "non_retryable"
        elif status in RETRYABLE_STATUS:
            reason = "retryable_http"
        return ModelResult(
            status="error",
            output_text="",
            usage=None,
            request_ids=ids,
            attempts=1,
            error=message or f"http {status}",
            finish_reason=reason,
            incomplete=True,
            http_status=status,
        )

    def _cancelled(self, request_ids: list[str], attempts: int, sleeps: list[float], last: ModelResult | None) -> ModelResult:
        text = last.output_text if last else ""
        return ModelResult(
            status="incomplete",
            output_text=text,
            usage=None,
            request_ids=list(request_ids),
            attempts=attempts,
            error="cancelled",
            finish_reason="cancelled",
            retry_sleeps=list(sleeps),
            incomplete=True,
        )

    def _budget_exceeded(self, request_ids: list[str], attempts: int, sleeps: list[float], last: ModelResult | None) -> ModelResult:
        text = last.output_text if last else ""
        return ModelResult(
            status="error",
            output_text=text,
            usage=None,
            request_ids=list(request_ids),
            attempts=attempts,
            error="request budget exhausted",
            finish_reason="budget_exhausted",
            retry_sleeps=list(sleeps),
            incomplete=True,
        )


def _drain_frames(buffer: bytes, pieces: list[str]) -> bytes:
    while b"\n\n" in buffer:
        frame, buffer = buffer.split(b"\n\n", 1)
        event, data = _parse_sse_frame(frame)
        if not data:
            continue
        typ = data.get("type") or event
        if typ == "response.output_text.delta":
            pieces.append(str(data.get("delta") or ""))
    # Also accept a trailing unterminated data line if the server closed after a full event.
    if buffer.strip() and b"data:" in buffer and not buffer.endswith(b"\n\n"):
        event, data = _parse_sse_frame(buffer)
        if data and (data.get("type") or event) == "response.output_text.delta":
            pieces.append(str(data.get("delta") or ""))
            buffer = b""
    return buffer


def _set_socket_timeout(resp: Any, timeout: float) -> None:
    sock = None
    fp = getattr(resp, "fp", None)
    raw = getattr(fp, "raw", None) if fp is not None else None
    sock = getattr(raw, "_sock", None) if raw is not None else None
    if sock is None:
        conn = getattr(resp, "_connection", None) or getattr(resp, "connection", None)
        sock = getattr(conn, "sock", None) if conn is not None else None
    if sock is not None:
        try:
            sock.settimeout(timeout)
        except OSError:
            pass


def _usage_from(value: Any) -> Usage | None:
    if not isinstance(value, dict):
        return None
    try:
        inp = int(value["input_tokens"])
        out = int(value["output_tokens"])
        total = int(value["total_tokens"])
    except (KeyError, TypeError, ValueError):
        return None
    if inp < 0 or out < 0 or total < 0:
        return None
    return Usage(inp, out, total)


def _parse_sse_frame(frame: bytes) -> tuple[str | None, dict[str, Any] | None]:
    event = None
    data_lines: list[str] = []
    for line in frame.decode("utf-8", errors="replace").splitlines():
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())
    if not data_lines:
        return event, None
    try:
        data = json.loads("\n".join(data_lines))
    except json.JSONDecodeError:
        return event, None
    if not isinstance(data, dict):
        return event, None
    return event, data


def _parse_retry_after(headers: Any) -> float | None:
    if headers is None:
        return None
    raw = headers.get("Retry-After") or headers.get("retry-after")
    if raw is None:
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return None
    if value < 0:
        return None
    return value
