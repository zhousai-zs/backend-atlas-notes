#!/usr/bin/env bash
# 第161课实践：模型 API 与可靠客户端。运行：bash test.sh
# 只访问本机回环 HTTP 模拟服务，不调用付费模型 API，不需要密钥。
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
exec > >(tee run.log) 2>&1
echo "### tool versions"
date '+date: %Y-%m-%d %H:%M:%S %Z'
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"; else PY="${PYTHON:-python3}"; fi
"$PY" --version
"$PY" - <<'PY'
import platform, sys
print("python_implementation:", platform.python_implementation())
print("platform:", platform.platform())
print("executable:", sys.executable)
print("openai_imported_at_start:", "openai" in sys.modules)
PY
echo "### run checks"
"$PY" driver.py
status=${PIPESTATUS[0]:-$?}
echo "driver_exit=$status"
if [[ "$status" -ne 0 ]]; then
  exit "$status"
fi
"$PY" - <<'PY'
import json,sys
data=json.load(open("results.json"))
assert data["lesson"]==161 and data["id"]=="k-api"
assert data["failed"]==0
assert data["is_live_model"] is False and data["is_live_paid_api"] is False
assert data["official_sdk_offline"]["is_live_paid_api"] is False
assert data["official_sdk_offline"]["status_429_without_retry"] == 429
assert data["official_sdk_offline"]["used_mock_transport"] is True
print("results.json ok, checks=", len(data["checks"]))
PY
