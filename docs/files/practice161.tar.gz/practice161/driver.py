#!/usr/bin/env python3
"""Run lesson 161 checks against a local HTTP mock. No paid API calls."""

from __future__ import annotations

import json
import os
import platform
import sys
import threading
import time
import urllib.request
from typing import Any

from client import ReliableModelClient, RetryPolicy
from mock_server import LessonMockServer


FAIL = 0
CHECKS: list[dict[str, Any]] = []


def say(*parts: object) -> None:
    print(*parts, flush=True)


def check(name: str, cond: bool, detail: str = "") -> None:
    global FAIL
    status = "OK" if cond else "FAIL"
    if not cond:
        FAIL += 1
    rec = {"name": name, "ok": bool(cond), "detail": detail}
    CHECKS.append(rec)
    suffix = f" — {detail}" if detail else ""
    say(f"CHECK {status}: {name}{suffix}")


def assert_loopback(url: str) -> None:
    check("base url is loopback", url.startswith("http://127.0.0.1:"), url)


def env_info() -> dict[str, Any]:
    return {
        "python": sys.version.replace("\n", " "),
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "implementation": platform.python_implementation(),
        "cwd": os.getcwd(),
        "openai_api_key_present": bool(os.environ.get("OPENAI_API_KEY")),
        "openai_package_imported": "openai" in sys.modules,
        "is_live_model": False,
        "is_live_paid_api": False,
    }


def main() -> int:
    started = time.perf_counter()
    say("### 0. environment")
    info = env_info()
    say("python:", info["python"])
    say("platform:", info["platform"])
    say("OPENAI_API_KEY present:", info["openai_api_key_present"])
    say("openai package already imported:", info["openai_package_imported"])
    check("no paid API key is required or used", not info["openai_api_key_present"])

    server = LessonMockServer()
    url = server.start()
    say("mock url:", url)
    assert_loopback(url)
    try:
        with urllib.request.urlopen(url + "/health", timeout=1) as resp:
            health = json.loads(resp.read().decode())
        check("mock health", health.get("ok") is True, str(health))

        default_policy = RetryPolicy(max_retries=2, initial_delay=0.05, max_delay=0.4, max_retry_after=2.0, overall_deadline=2.5, jitter=0.0)
        client = ReliableModelClient(url, policy=default_policy, timeout=0.25)

        say("\n### 1. success (non-stream)")
        t0 = time.perf_counter()
        ok = client.complete("hello", case="success", stream=False)
        elapsed_ok = round(time.perf_counter() - t0, 6)
        say(json.dumps(ok.as_dict(), ensure_ascii=False))
        check("success completed", ok.status == "completed" and ok.incomplete is False and ok.finish_reason == "stop")
        check("success records usage", ok.usage is not None and ok.usage.total_tokens == 9, str(ok.usage))
        check("success has request id", len(ok.request_ids) == 1 and ok.request_ids[0].startswith("req_"), str(ok.request_ids))
        check("success single attempt", ok.attempts == 1, str(ok.attempts))
        check("success output text", ok.output_text == "可靠客户端", ok.output_text)

        say("\n### 2. success (stream)")
        streamed = client.complete("hello", case="success_stream", stream=True)
        say(json.dumps(streamed.as_dict(), ensure_ascii=False))
        check("stream completed", streamed.status == "completed" and streamed.incomplete is False)
        check("stream distinguishes final answer", streamed.finish_reason == "stop" and streamed.output_text == "可靠客户端")
        check("stream records usage", streamed.usage is not None and streamed.usage.as_dict() == {"input_tokens": 5, "output_tokens": 4, "total_tokens": 9})
        check("stream has request id", bool(streamed.request_ids) and streamed.request_ids[0].startswith("req_"))

        say("\n### 3. timeout (no stream, no tools) then no hang")
        timeout_client = ReliableModelClient(
            url,
            policy=RetryPolicy(max_retries=0, overall_deadline=0.8, initial_delay=0.05),
            timeout=0.2,
        )
        t0 = time.perf_counter()
        timed = timeout_client.complete("hello", case="timeout", stream=False)
        elapsed_timeout = round(time.perf_counter() - t0, 6)
        say(json.dumps(timed.as_dict(), ensure_ascii=False), "elapsed", elapsed_timeout)
        check("timeout finish_reason", timed.finish_reason == "timeout" and timed.incomplete is True)
        check("timeout is not a final answer", timed.status in {"error", "incomplete"} and timed.usage is None)
        check("timeout did not hang past budget", elapsed_timeout < 1.0, f"elapsed={elapsed_timeout}")
        check("timeout attempts with max_retries=0", timed.attempts == 1, str(timed.attempts))

        say("\n### 4. 429 then success, Retry-After honored")
        t0 = time.perf_counter()
        limited = client.complete("hello", case="429_then_ok", stream=False)
        elapsed_429 = round(time.perf_counter() - t0, 6)
        say(json.dumps(limited.as_dict(), ensure_ascii=False), "elapsed", elapsed_429)
        check("429 then success completed", limited.status == "completed" and limited.output_text == "after-backoff")
        check("429 retried twice then succeeded", limited.attempts == 3, str(limited.attempts))
        check("429 recorded two sleeps", len(limited.retry_sleeps) == 2, str(limited.retry_sleeps))
        check(
            "429 Retry-After is a minimum wait",
            len(limited.retry_sleeps) == 2 and all(s >= 0.12 - 1e-9 for s in limited.retry_sleeps),
            str(limited.retry_sleeps),
        )
        check("429 success records usage", limited.usage is not None and limited.usage.total_tokens == 10)
        check("429 collected request ids for each attempt", len(limited.request_ids) == 3, str(limited.request_ids))

        say("\n### 5. negative: 400 and 401 are not retried")
        bad = client.complete("hello", case="400_bad_request")
        auth = client.complete("hello", case="401_auth")
        say("400", json.dumps(bad.as_dict(), ensure_ascii=False))
        say("401", json.dumps(auth.as_dict(), ensure_ascii=False))
        check("400 not retried", bad.attempts == 1 and bad.http_status == 400 and bad.finish_reason == "non_retryable")
        check("401 not retried", auth.attempts == 1 and auth.http_status == 401 and auth.finish_reason == "non_retryable")
        check("400 is not completed", bad.incomplete is True and bad.status == "error")

        say("\n### 6. 500 then success is retryable")
        recovered = client.complete("hello", case="500_then_ok")
        say(json.dumps(recovered.as_dict(), ensure_ascii=False))
        check("500 then success", recovered.status == "completed" and recovered.attempts == 2 and recovered.output_text == "recovered")

        say("\n### 7. mid-stream cut: incomplete, no auto retry")
        cut = client.complete("hello", case="midstream_cut", stream=True)
        say(json.dumps(cut.as_dict(), ensure_ascii=False))
        check("midstream is incomplete not final", cut.status == "incomplete" and cut.incomplete is True and cut.finish_reason == "stream_interrupted")
        check("midstream keeps partial text", cut.output_text == "未完成片", cut.output_text)
        check("midstream has no usage", cut.usage is None)
        check("midstream not retried", cut.attempts == 1, str(cut.attempts))
        check("incomplete is distinct from success", cut.incomplete != ok.incomplete and cut.status != ok.status)

        say("\n### 8. stream timeout after partial tokens is not retried")
        stream_to = ReliableModelClient(url, policy=RetryPolicy(max_retries=2, overall_deadline=1.0), timeout=0.2)
        partial = stream_to.complete("hello", case="stream_timeout", stream=True)
        say(json.dumps(partial.as_dict(), ensure_ascii=False))
        check("partial stream timeout incomplete", partial.incomplete is True and partial.finish_reason == "timeout")
        check("partial stream text retained", partial.output_text == "开头", partial.output_text)
        check("partial stream not retried", partial.attempts == 1, str(partial.attempts))

        say("\n### 9. retry budget exhausted, not infinite")
        exhausted = ReliableModelClient(
            url,
            policy=RetryPolicy(max_retries=2, initial_delay=0.04, overall_deadline=2.0, max_retry_after=2.0),
            timeout=0.25,
        ).complete("hello", case="429_always")
        say(json.dumps(exhausted.as_dict(), ensure_ascii=False))
        check("429 always stops at max_retries+1", exhausted.attempts == 3, str(exhausted.attempts))
        check("429 always not completed", exhausted.status == "error" and exhausted.finish_reason == "rate_limited" and exhausted.http_status == 429)
        check("429 always recorded two sleeps", len(exhausted.retry_sleeps) == 2, str(exhausted.retry_sleeps))

        say("\n### 10. overall budget stops further retries")
        budgeted = ReliableModelClient(
            url,
            policy=RetryPolicy(max_retries=5, initial_delay=0.2, max_delay=0.2, overall_deadline=0.10, max_retry_after=2.0),
            timeout=0.2,
        ).complete("hello", case="429_always")
        say(json.dumps(budgeted.as_dict(), ensure_ascii=False))
        check("budget prevents unbounded retries", budgeted.attempts <= 2, str(budgeted.attempts))
        check(
            "budget finish_reason",
            budgeted.finish_reason == "budget_exhausted",
            budgeted.finish_reason,
        )
        check("budget result is incomplete", budgeted.incomplete is True and budgeted.status != "completed")

        say("\n### 11. response validation")
        invalid = client.complete("hello", case="invalid_body")
        say(json.dumps(invalid.as_dict(), ensure_ascii=False))
        check("invalid body fails validation", invalid.finish_reason == "validation_failed" and invalid.status == "error")
        check("invalid body is not retried", invalid.attempts == 1, str(invalid.attempts))

        say("\n### 12. timeout after a side-effecting tool is not retried")
        before = _state(url)["side_effects"]
        tool_client = ReliableModelClient(
            url,
            policy=RetryPolicy(max_retries=2, overall_deadline=1.0),
            timeout=0.2,
        )
        t0 = time.perf_counter()
        tool = tool_client.complete("charge", case="timeout_with_tool", tools=[{"name": "charge_once"}])
        elapsed_tool = round(time.perf_counter() - t0, 6)
        after = _state(url)["side_effects"]
        say(json.dumps(tool.as_dict(), ensure_ascii=False), "elapsed", elapsed_tool, "side_effects", before, "->", after)
        check("tool timeout not retried", tool.attempts == 1 and tool.finish_reason == "timeout")
        check("tool side effect ran once, not multiplied", after - before == 1, f"{before}->{after}")
        check("tool timeout did not hang", elapsed_tool < 1.0, f"elapsed={elapsed_tool}")

        say("\n### 13. cancel mid-stream")
        cancel_event = threading.Event()
        holder: dict[str, Any] = {}

        def _run() -> None:
            cancel_client = ReliableModelClient(
                url,
                policy=RetryPolicy(max_retries=0, overall_deadline=2.0),
                timeout=1.0,
            )
            holder["result"] = cancel_client.complete("hello", case="slow_stream", stream=True, cancel_event=cancel_event)

        thread = threading.Thread(target=_run, name="cancel-demo")
        thread.start()
        time.sleep(0.05)
        cancel_event.set()
        thread.join(timeout=2)
        check("cancel thread finished", not thread.is_alive())
        cancelled = holder.get("result")
        say(json.dumps(cancelled.as_dict(), ensure_ascii=False) if cancelled else "missing")
        check("cancel yields incomplete", cancelled is not None and cancelled.incomplete is True and cancelled.finish_reason == "cancelled")
        check("cancel is not a final answer", cancelled is not None and cancelled.status != "completed" and cancelled.usage is None)

        say("\n### 14. refused off-loopback construction")
        refused = False
        try:
            ReliableModelClient("https://api.openai.com/v1")
        except ValueError:
            refused = True
        check("client refuses non-loopback base url", refused)

        snapshot = _state(url)
        say("\n### 15. mock audit")
        say(json.dumps(snapshot, ensure_ascii=False))
        hosts = snapshot.get("seen_hosts") or []
        check("mock only saw loopback Host headers", all(_is_loopback_host(h) for h in hosts), str(hosts[:8]))
        check("openai package still not imported", "openai" not in sys.modules)
        check("is_live_model is false", info["is_live_model"] is False and info["is_live_paid_api"] is False)

        elapsed = round(time.perf_counter() - started, 6)
        results = {
            "lesson": 161,
            "id": "k-api",
            "is_live_model": False,
            "is_live_paid_api": False,
            "failed": FAIL,
            "checks": CHECKS,
            "env": info,
            "mock_url": url,
            "elapsed_seconds": elapsed,
            "cases": {
                "success": ok.as_dict() | {"elapsed_seconds": elapsed_ok},
                "success_stream": streamed.as_dict(),
                "timeout": timed.as_dict() | {"elapsed_seconds": elapsed_timeout},
                "retry_429": limited.as_dict() | {"elapsed_seconds": elapsed_429},
                "bad_request": bad.as_dict(),
                "auth": auth.as_dict(),
                "retry_500": recovered.as_dict(),
                "midstream_cut": cut.as_dict(),
                "stream_timeout": partial.as_dict(),
                "retry_exhausted": exhausted.as_dict(),
                "budget": budgeted.as_dict(),
                "invalid_body": invalid.as_dict(),
                "tool_timeout": tool.as_dict() | {"elapsed_seconds": elapsed_tool, "side_effects_delta": after - before},
                "cancelled": cancelled.as_dict() if cancelled else None,
            },
            "mock_state": snapshot,
        }
        with open("results.json", "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
            f.write("\n")
        say("\nresults.json written, failed=", FAIL, "elapsed=", elapsed)
        if FAIL == 0:
            say("ALL_CHECKS_PASSED")
            return 0
        say("SOME_CHECKS_FAILED")
        return 1
    finally:
        server.stop()
        say("mock stopped")


def _state(url: str) -> dict[str, Any]:
    with urllib.request.urlopen(url + "/state", timeout=1) as resp:
        return json.loads(resp.read().decode())


def _is_loopback_host(host: str) -> bool:
    raw = host.split("%")[0]
    name = raw.rsplit(":", 1)[0] if raw.count(":") == 1 else raw
    name = name.strip("[]")
    return name in {"127.0.0.1", "localhost", "::1"}


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise
