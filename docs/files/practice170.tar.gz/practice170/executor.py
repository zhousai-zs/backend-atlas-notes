"""Server-side executor: schema, tenant auth, window cap. Failures stay failures."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from pydantic import ValidationError

from schema import MAX_WINDOW_SECONDS, parse_args

# tenant -> services it may read
ACL = {
    "alice": {"checkout", "search", "payments"},
    "bob": {"search"},
}

# seed metrics (service, start-iso minute granularity is ignored; we return a fixed value)
METRICS = {
    "checkout": 42.0,
    "search": 7.5,
    "payments": 3.0,
    "secret-internal": 99.0,  # exists but no tenant in this practice is granted it
}

# A secret that must never appear in logs even if a caller sends it as an extra header.
FORBIDDEN_IN_LOGS = ("sk-live-example-not-used", "tok_supersecret")


def _redact(value):
    if isinstance(value, str):
        out = value
        for s in FORBIDDEN_IN_LOGS:
            out = out.replace(s, "[REDACTED]")
        return out
    if isinstance(value, dict):
        return {k: _redact(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        typ = type(value)
        return typ(_redact(v) for v in value)
    return value


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = _redact(record.msg)
        if record.args:
            record.args = tuple(_redact(a) for a in record.args)
        return True


log = logging.getLogger("practice170.executor")
log.addFilter(RedactingFilter())
log.setLevel(logging.INFO)


@dataclass
class ToolResult:
    call_id: str
    ok: bool
    name: str
    # business payload or a safe error
    payload: dict
    error_class: str | None = None  # protocol | rejected | execution | unknown


def _err(call_id: str, name: str, cls: str, code: str, message: str) -> ToolResult:
    return ToolResult(call_id, False, name, {"error": code, "message": message}, error_class=cls)


def execute(call_id: str, name: str, arguments: Any, *, tenant: str, headers: dict | None = None) -> ToolResult:
    headers = headers or {}
    # Log the call without secrets. If a caller stuffed a token in a header, redact it.
    log.info("call_id=%s tool=%s tenant=%s headers=%s", call_id, name, tenant, _redact(dict(headers)))
    if name != "get_metric":
        return _err(call_id, name, "protocol", "unknown_tool", f"tool {name!r} is not supported")
    try:
        args = parse_args(arguments)
    except ValidationError as e:
        # do not dump raw input that might contain extras like tokens; include type/loc only
        locs = [str(err["loc"]) + ":" + err["type"] for err in e.errors()]
        return _err(call_id, name, "protocol", "invalid_arguments", "schema validation failed: " + ", ".join(locs))

    if tenant not in ACL:
        return _err(call_id, name, "rejected", "unauthenticated", "unknown tenant")
    if args.service not in ACL[tenant]:
        return _err(call_id, name, "rejected", "unauthorized_service", "service is not in the tenant scope")

    window = (args.end - args.start).total_seconds()
    if window < 0:
        return _err(call_id, name, "rejected", "invalid_range", "end is before start")
    if window > MAX_WINDOW_SECONDS:
        return _err(call_id, name, "rejected", "window_too_large", "time range exceeds the allowed window")

    if args.service not in METRICS:
        return _err(call_id, name, "execution", "metric_missing", "no metric is recorded for this service")

    value = METRICS[args.service]
    return ToolResult(
        call_id,
        True,
        name,
        {
            "service": args.service,
            "start": args.start.isoformat(),
            "end": args.end.isoformat(),
            "value": value,
        },
        error_class=None,
    )


def bind_results(submitted: list[dict], completed: list[ToolResult]) -> dict[str, ToolResult]:
    """Map results back to the submitted call_id, ignoring completion order."""
    by = {r.call_id: r for r in completed}
    missing = [s["call_id"] for s in submitted if s["call_id"] not in by]
    if missing:
        raise KeyError(f"missing results for {missing}")
    if len(by) != len(completed):
        raise ValueError("duplicate call_id in results")
    return by
