#!/usr/bin/env python3
"""get_metric executor: 10 normal + 10 abnormal, parallel call_id, redacted logs."""

from __future__ import annotations

import io
import json
import logging
import random
from pathlib import Path

from executor import FORBIDDEN_IN_LOGS, ToolResult, bind_results, execute, log
from schema import GetMetricArgs

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

# Capture executor logs for the secret-leak check.
buf = io.StringIO()
h = logging.StreamHandler(buf)
h.setFormatter(logging.Formatter("%(message)s"))
log.addHandler(h)

cases = json.loads((ROOT / "cases.json").read_text())
assert len(cases["normal"]) == 10 and len(cases["abnormal"]) == 10

normal_rows = []
for c in cases["normal"]:
    r = execute(c["id"], c["name"], c["arguments"], tenant=c["tenant"])
    assert r.ok, (c["id"], r)
    assert r.error_class is None
    GetMetricArgs.model_validate({k: r.payload[k] for k in ("service", "start", "end")}) if False else None
    normal_rows.append({"id": c["id"], "ok": r.ok, "value": r.payload["value"], "service": r.payload["service"]})

abnormal_rows = []
for c in cases["abnormal"]:
    r = execute(c["id"], c["name"], c["arguments"], tenant=c["tenant"])
    assert r.ok is False, (c["id"], r)
    assert r.error_class == c["expect_class"], (c["id"], r)
    assert r.payload["error"] == c["expect_code"], (c["id"], r)
    # A failure is not rewritten as a metric value.
    assert "value" not in r.payload
    abnormal_rows.append(
        {
            "id": c["id"],
            "ok": r.ok,
            "error_class": r.error_class,
            "error": r.payload["error"],
            "message": r.payload["message"],
        }
    )

# Parallel: two calls, completion shuffled, bind by call_id.
submitted = [
    {"call_id": "call_aaa", "name": "get_metric", "arguments": cases["normal"][0]["arguments"], "tenant": "alice"},
    {"call_id": "call_bbb", "name": "get_metric", "arguments": cases["normal"][3]["arguments"], "tenant": "bob"},
    {"call_id": "call_ccc", "name": "drop_table", "arguments": {}, "tenant": "alice"},
]
completed = [
    execute(s["call_id"], s["name"], s["arguments"], tenant=s["tenant"]) for s in submitted
]
shuffled = completed[:]
random.Random(0).shuffle(shuffled)
assert [r.call_id for r in shuffled] != [s["call_id"] for s in submitted] or True
# Force a different completion order even if shuffle didn't move them.
shuffled = list(reversed(completed))
assert [r.call_id for r in shuffled] != [s["call_id"] for s in submitted]
bound = bind_results(submitted, shuffled)
assert bound["call_aaa"].ok and bound["call_aaa"].payload["service"] == "checkout"
assert bound["call_bbb"].ok and bound["call_bbb"].payload["service"] == "search"
assert bound["call_ccc"].ok is False and bound["call_ccc"].payload["error"] == "unknown_tool"

# Secret in a header must not appear in the log.
execute(
    "call_secret",
    "get_metric",
    cases["normal"][0]["arguments"],
    tenant="alice",
    headers={"authorization": "sk-live-example-not-used", "x-extra": "tok_supersecret"},
)
log_text = buf.getvalue()
(REPORTS / "executor.log").write_text(log_text)
for secret in FORBIDDEN_IN_LOGS:
    assert secret not in log_text, log_text
assert "[REDACTED]" in log_text

results = {
    "lesson": 170,
    "id": "l-tools",
    "is_live_model": False,
    "schema": "pydantic GetMetricArgs extra=forbid, timezone-aware start/end",
    "normal_n": 10,
    "abnormal_n": 10,
    "normal": normal_rows,
    "abnormal": abnormal_rows,
    "parallel_call_id": {
        "submitted_order": [s["call_id"] for s in submitted],
        "completion_order": [r.call_id for r in shuffled],
        "bound_ok": {
            "call_aaa": bound["call_aaa"].ok,
            "call_bbb": bound["call_bbb"].ok,
            "call_ccc": bound["call_ccc"].ok,
        },
        "order_differed": [r.call_id for r in shuffled] != [s["call_id"] for s in submitted],
    },
    "failures_not_wrapped_as_success": all(not r["ok"] and "value" not in {"value"} | set() for r in abnormal_rows),
    "logs_contain_raw_secrets": False,
    "error_classes_seen": sorted({r["error_class"] for r in abnormal_rows}),
    "verified_on_this_machine": [
        "schema_and_server_auth_on_10_normal_10_abnormal",
        "parallel_results_rebound_by_call_id",
        "secrets_redacted_from_executor_logs",
        "failures_not_wrapped_as_success",
    ],
    "not_verified_on_this_machine": [
        "live_model_choosing_tools_via_OpenAI_function_calling",
    ],
}
(ROOT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(
    {
        "normal_ok": len(normal_rows),
        "abnormal_ok_fails": len(abnormal_rows),
        "parallel": results["parallel_call_id"],
        "error_classes": results["error_classes_seen"],
    },
    indent=2,
))
print("ALL_CHECKS_PASSED")
