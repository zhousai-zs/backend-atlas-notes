"""JSON Schema / Pydantic contract for get_metric. Authorization is not in the schema."""

from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

MAX_WINDOW_SECONDS = 7 * 24 * 3600  # business rule, also enforced server-side


class GetMetricArgs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    service: str = Field(min_length=1, max_length=64)
    start: datetime
    end: datetime

    @field_validator("start", "end")
    @classmethod
    def _aware(cls, v: datetime) -> datetime:
        if v.tzinfo is None:
            raise ValueError("timestamps must be timezone-aware UTC")
        return v.astimezone(timezone.utc)


def parse_args(payload) -> GetMetricArgs:
    return GetMetricArgs.model_validate(payload)
