#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
if [[ -x /workspace/atlas/cmvenv/bin/python ]]; then
  PY="${PYTHON:-/workspace/atlas/cmvenv/bin/python}"
else
  PY="${PYTHON:-python3}"
fi
"$PY" driver.py 2>&1 | tee run.log
"$PY" - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["normal_n"]==10 and r["abnormal_n"]==10
assert r["parallel_call_id"]["order_differed"] and r["parallel_call_id"]["bound_ok"]["call_ccc"] is False
assert r["logs_contain_raw_secrets"] is False
log=Path("reports/executor.log").read_text()
assert "sk-live-example-not-used" not in log and "tok_supersecret" not in log
assert any(x["error"]=="unauthorized_service" for x in r["abnormal"])
assert any(x["error"]=="unknown_tool" for x in r["abnormal"])
assert any(x["error"]=="window_too_large" for x in r["abnormal"])
print("POSTCHECK_OK")
PY
