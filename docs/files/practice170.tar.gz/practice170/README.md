# practice170 — Tool Calling 与执行器

get_metric 的 schema + 租户授权 + 时间窗口。10 正常 / 10 异常。并行结果按 call_id 对齐。日志脱敏。

```bash
bash test.sh
```
