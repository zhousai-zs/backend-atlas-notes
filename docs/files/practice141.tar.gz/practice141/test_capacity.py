#!/usr/bin/env python3
"""Acceptance checks for the lesson 141 capacity-modeling experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    COST_PER_MACHINE,
    DEFAULT_PUBLISH_PERCENT,
    DISK_IOPS,
    DISK_US_PER_IO,
    DOWNSTREAM_QPS,
    ENGINE_NAME,
    LARGE_READ_RESP_BYTES,
    N_CORES,
    NET_BPS,
    PUBLISH_CPU_US,
    PUBLISH_IOS,
    READ_CPU_US,
    READ_IOS,
    READ_RESP_BYTES,
    REALITY_READ_MISS_PERCENT,
    SLO_P99_US,
    TEACHING_HOST,
    TIMEOUT_US,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    assert r["engine"] == ENGINE_NAME == "CapacityEngine"
    assert r["not_a_real_machine"] and r["not_a_real_loadtest_product"]
    assert r["not_fio_or_wrk"] and r["not_sre_workbook_numbers"]
    assert r["not_host_measurement"] and r["cycles_are_teaching"]
    assert r["teaching_host"] == TEACHING_HOST == "atlas-teach-cap-1"
    assert r["n_cores"] == N_CORES == 4
    assert r["disk_iops"] == DISK_IOPS == 200
    assert r["disk_us_per_io"] == DISK_US_PER_IO == 5000
    assert r["net_bps"] == NET_BPS == 1_000_000_000
    assert r["downstream_qps"] == DOWNSTREAM_QPS == 200
    assert r["timeout_us"] == TIMEOUT_US == 200_000
    assert r["slo_p99_us"] == SLO_P99_US == 50_000
    assert r["read_cpu_us"] == READ_CPU_US == 2000
    assert r["read_ios"] == READ_IOS == 0
    assert r["read_resp_bytes"] == READ_RESP_BYTES == 8000
    assert r["publish_cpu_us"] == PUBLISH_CPU_US == 8000
    assert r["publish_ios"] == PUBLISH_IOS == 2
    assert r["large_read_resp_bytes"] == LARGE_READ_RESP_BYTES == 200 * 1024
    assert r["default_publish_percent"] == DEFAULT_PUBLISH_PERCENT == 10
    assert r["reality_read_miss_percent"] == REALITY_READ_MISS_PERCENT == 5
    assert r["cost_per_machine"] == COST_PER_MACHINE == 100

    p1 = r["predict_default_1"]
    assert p1["d_cpu_us"] == 2600.0
    assert p1["d_disk_us"] == 1000.0
    assert p1["d_bits"] == 59200.0
    assert p1["d_down_us"] == 500.0
    assert p1["cap_cpu_qps"] == 1538.4615
    assert p1["cap_disk_qps"] == 1000.0
    assert p1["cap_net_qps"] == 16891.8919
    assert p1["cap_down_qps"] == 2000.0
    assert p1["bottleneck"] == "disk"
    assert p1["predicted_qps"] == 1000.0

    pa = r["predict_all_read"]
    assert pa["d_cpu_us"] == 2000.0 and pa["d_disk_us"] == 0.0
    assert pa["bottleneck"] == "cpu" and pa["predicted_qps"] == 2000.0
    assert pa["cap_cpu_qps"] == 2000.0

    ph = r["predict_half_publish"]
    assert ph["d_cpu_us"] == 5000.0 and ph["d_disk_us"] == 5000.0
    assert ph["bottleneck"] == "disk" and ph["predicted_qps"] == 200.0
    assert ph["cap_cpu_qps"] == 800.0

    pl = r["predict_large_read"]
    assert pl["bottleneck"] == "net"
    assert pl["predicted_qps"] == 610.3516
    assert pl["cap_cpu_qps"] == 2000.0

    pm = r["predict_cache_miss_5pct"]
    assert pm["read_miss_percent"] == 5
    assert pm["read_ios"] == 0.05
    assert pm["d_disk_us"] == 1225.0
    assert pm["bottleneck"] == "disk"
    assert pm["predicted_qps"] == 816.3265

    # default even-mix ladder: SLO holds through the demand-model cap, breaks at 1050
    ld = r["ladder_default"]
    assert ld["last_slo_ok"]["offered_qps"] == 1000
    assert ld["last_slo_ok"]["completed_qps"] == 997.7823
    assert ld["last_slo_ok"]["p99_us"] == 23476
    assert ld["last_slo_ok"]["error_rate"] == 0.0
    assert ld["last_slo_ok"]["disk_util"] == 0.9978
    assert ld["first_slo_fail"]["offered_qps"] == 1050
    assert ld["first_slo_fail"]["error_rate"] == 0.0635
    assert ld["first_slo_fail"]["p99_us"] == 158174
    assert ld["test_peak"]["offered_qps"] == 1200
    assert ld["test_peak"]["completed_qps"] == 1090.9567
    assert ld["test_peak"]["p99_us"] == 22786
    assert ld["test_peak"]["error_rate"] == 0.0908
    assert ld["test_peak"]["meets_slo"] is False

    # clustered writes: same average demand, p99 already over the 50 ms SLO at 200 QPS
    lc = r["ladder_clustered"]
    assert lc["last_slo_ok"] is None
    assert lc["first_slo_fail"]["offered_qps"] == 200
    assert lc["first_slo_fail"]["p99_us"] == 63116
    assert lc["first_slo_fail"]["error_rate"] == 0.0
    assert lc["first_slo_fail"]["disk_util"] == 0.2

    # bottleneck shifts with mix
    assert r["ladder_all_read"]["last_slo_ok"]["offered_qps"] == 2000
    assert r["ladder_all_read"]["last_slo_ok"]["cpu_util"] == 0.9998
    assert r["ladder_all_read"]["first_slo_fail"]["offered_qps"] == 2100
    assert r["ladder_half_publish"]["last_slo_ok"]["offered_qps"] == 200
    assert r["ladder_half_publish"]["first_slo_fail"]["offered_qps"] == 220
    assert r["ladder_large_read"]["last_slo_ok"]["offered_qps"] == 610
    assert r["ladder_large_read"]["last_slo_ok"]["net_util"] == 0.9996
    assert r["ladder_large_read"]["first_slo_fail"]["offered_qps"] == 630

    # wrong cache-hit assumption: observed SLO capacity 800 vs naive 1000
    lm = r["ladder_cache_miss_5pct"]
    assert lm["last_slo_ok"]["offered_qps"] == 800
    assert lm["last_slo_ok"]["p99_us"] == 25926
    assert lm["first_slo_fail"]["offered_qps"] == 820
    assert lm["first_slo_fail"]["p99_us"] == 65427
    er = r["error_range"]
    assert er["predicted_qps"] == 1000.0
    assert er["rel_last_slo_ok_vs_predicted"] == 0.0
    assert er["rel_cache_miss_slo_vs_naive_predicted"] == -0.2
    assert er["cache_miss_5pct_predicted_qps"] == 816.3265

    # scale-out hits the shared downstream cap of 2000
    scale = {row["n"]: row for row in r["predict_scale"]}
    assert scale[1]["with_downstream"]["predicted_qps"] == 1000.0
    assert scale[1]["with_downstream"]["bottleneck"] == "disk"
    assert scale[2]["with_downstream"]["predicted_qps"] == 2000.0
    assert scale[2]["with_downstream"]["bottleneck"] == "disk"
    assert scale[3]["with_downstream"]["predicted_qps"] == 2000.0
    assert scale[3]["with_downstream"]["bottleneck"] == "downstream"
    assert scale[3]["front_end_only"]["predicted_qps"] == 3000.0
    assert scale[4]["with_downstream"]["predicted_qps"] == 2000.0
    assert scale[4]["front_end_only"]["predicted_qps"] == 4000.0
    last_by_n = {row["n"]: row["ladder"]["last_slo_ok"]["offered_qps"] for row in r["ladder_scale"]}
    fail_by_n = {row["n"]: row["ladder"]["first_slo_fail"]["offered_qps"] for row in r["ladder_scale"]}
    assert last_by_n == {1: 1000, 2: 2000, 3: 2000, 4: 2000}
    assert fail_by_n == {1: 1050, 2: 2200, 3: 2200, 4: 2200}

    # pitfall: +20% burst on test peak and on last SLO-ok both miss the SLO;
    # 30% headroom (700) plus the same burst (840) still meets it.
    assert r["burst_at_test_peak"]["offered_qps"] == 1440
    assert r["burst_at_test_peak"]["meets_slo"] is False
    assert r["burst_at_test_peak"]["error_rate"] == 0.0958
    assert r["burst_at_test_peak"]["p99_us"] == 2104  # success-path p99 looks fine
    assert r["burst_at_last_slo_ok"]["offered_qps"] == 1200
    assert r["burst_at_last_slo_ok"]["meets_slo"] is False
    assert r["burst_at_headroom_30"]["offered_qps"] == 840
    assert r["burst_at_headroom_30"]["meets_slo"] is True
    assert r["headroom_30_base"]["offered_qps"] == 700
    assert r["headroom_30_base"]["meets_slo"] is True

    fo = r["failover_target_2000"]
    assert fo["two_machines"]["meets_slo"] is True
    assert fo["two_after_losing_one"]["meets_slo"] is False
    assert fo["two_after_losing_one"]["error_rate"] == 0.9382
    assert fo["three_machines"]["meets_slo"] is True
    assert fo["three_after_losing_one"]["meets_slo"] is True
    assert fo["four_machines"]["meets_slo"] is True
    assert fo["four_after_losing_one"]["meets_slo"] is True

    costs = {row["label"]: row for row in r["cost_table"]}
    assert costs["no_margin_100pct"]["machines"] == 2
    assert costs["no_margin_100pct"]["teaching_cost"] == 200
    assert costs["headroom_10pct"]["machines"] == 3
    assert costs["headroom_30pct"]["machines"] == 3
    assert costs["headroom_50pct"]["machines"] == 4
    assert costs["headroom_50pct"]["teaching_cost"] == 400

    assert r["acceptance_assumptions_and_error_range"] is True
    assert r["acceptance_scale_limited_by_shared_downstream"] is True
    assert r["pitfall_test_peak_not_safe"] is True
    assert r["tradeoff_margin_costs_machines"] is True
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
