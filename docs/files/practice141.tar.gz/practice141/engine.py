#!/usr/bin/env python3
"""Teaching CapacityEngine — not a real machine, not a real load-test product.

A Python 3 standard-library model of capacity planning for a teaching
content-backend API. It predicts machine capacity from per-request CPU
and I/O service demand, then checks the prediction with an open-loop
stepwise load test on a virtual-time multi-resource queue.

The named source (checked on 2026-11-14) is the Google SRE Workbook
chapter "Non-Abstract Large System Design" at
https://sre.google/workbook/non-abstract-design/.
That chapter works through capacity-style resource estimates
(queries/sec x bytes, IOPS, RAM, network throughput) for an AdWords
CTR design, and stresses that sound assumptions matter more than any
final machine count. It does not define the terms 服务需求量,
Amdahl's law, 拐点, or 安全余量. This engine is not that chapter,
not a production load test, and not a measurement of the host box.
Times are teaching virtual microseconds. Disk IOPS, NIC speed and
core counts are teaching parameters, not /proc or fio readings.
"""
from __future__ import annotations

import heapq
from typing import Any, Optional


ENGINE_NAME = "CapacityEngine"

# ---- teaching machine (not host hardware, not the workbook example box) ----
N_CORES = 4
CPU_US_PER_CORE_PER_SEC = 1_000_000
DISK_IOPS = 200  # teaching parameter; same illustrative figure as the chapter's "common 4 TB HDD" example, not a measured disk
DISK_US_PER_IO = CPU_US_PER_CORE_PER_SEC // DISK_IOPS  # 5000
NET_BPS = 1_000_000_000  # 1 Gbps, teaching
DOWNSTREAM_QPS = 200  # shared audit/index, teaching
DOWNSTREAM_US = CPU_US_PER_CORE_PER_SEC // DOWNSTREAM_QPS  # 5000
TIMEOUT_US = 200_000
SLO_P99_US = 50_000
SLO_ERROR_RATE = 0.0

# ---- teaching request demands (virtual us / bytes; not production RTT) ----
READ_CPU_US = 2_000
READ_IOS = 0
READ_RESP_BYTES = 8_000

PUBLISH_CPU_US = 8_000
PUBLISH_IOS = 2
PUBLISH_RESP_BYTES = 2_000

# large-read variant, used only to move the bottleneck onto the NIC
LARGE_READ_RESP_BYTES = 200 * 1024  # 200 KiB

# default mix: 90% READ, 10% PUBLISH
DEFAULT_PUBLISH_PERCENT = 10

# used only in the assumption-error experiment: some READs miss the teaching cache and issue 1 IO
ASSUMED_READ_IOS = 0
REALITY_READ_MISS_PERCENT = 5
MISS_STEPS = (600, 700, 750, 800, 820, 850, 900, 1000)

# deterministic service-time multipliers, hundredths, mean 100
JITTER = (99, 100, 101, 98, 102, 100, 99, 101, 100)

# stepwise load (offered QPS)
DEFAULT_STEPS = (200, 400, 600, 700, 800, 850, 900, 950, 980, 1000, 1050, 1100, 1200)
MIX_STEPS = (100, 150, 180, 200, 220, 250, 400, 600, 800, 1000, 1500, 1800, 2000, 2100, 2200)
SCALE_STEPS = (400, 800, 1000, 1200, 1500, 1800, 2000, 2200, 2500, 2800, 3000, 3200)
NET_STEPS = (300, 400, 500, 550, 580, 610, 630, 650, 700, 800)

# how long each step runs, teaching microseconds
STEP_DURATION_US = 10_000_000  # 10 teaching seconds
MIN_REQUESTS = 4_000

# teaching cost unit per machine, used only for the margin tradeoff
COST_PER_MACHINE = 100

# teaching host metadata (not a real machine)
TEACHING_HOST = "atlas-teach-cap-1"
TEACHING_KERNEL = "Linux 6.8.0-teach"

# burst used in the pitfall experiment: +20% on top of a nominated capacity
BURST_RATIO_HUNDREDTHS = 120


def mix_demands(
    publish_percent: int,
    read_resp_bytes: int = READ_RESP_BYTES,
    read_miss_percent: int = 0,
) -> dict[str, float]:
    """Average service demand per request for a given publish percentage."""
    p = publish_percent / 100.0
    r = 1.0 - p
    # A cache miss on a READ issues 1 teaching IO; hits issue READ_IOS (0 by default).
    read_ios = READ_IOS + (read_miss_percent / 100.0) * 1
    d_cpu = r * READ_CPU_US + p * PUBLISH_CPU_US
    d_disk = (r * read_ios + p * PUBLISH_IOS) * DISK_US_PER_IO
    d_bits = (r * read_resp_bytes + p * PUBLISH_RESP_BYTES) * 8
    d_down = p * DOWNSTREAM_US  # 0 if the request does not use the shared downstream
    return {
        "publish_percent": publish_percent,
        "publish_ratio": p,
        "read_ratio": r,
        "read_miss_percent": read_miss_percent,
        "read_ios": read_ios,
        "d_cpu_us": d_cpu,
        "d_disk_us": d_disk,
        "d_bits": d_bits,
        "d_down_us": d_down,
        "read_resp_bytes": read_resp_bytes,
    }


def predict_capacity(
    n_machines: int,
    publish_percent: int,
    read_resp_bytes: int = READ_RESP_BYTES,
    include_downstream: bool = True,
    read_miss_percent: int = 0,
) -> dict[str, Any]:
    """Predict open-loop capacity from service demand and resource caps.

    For a resource with capacity C (work units / sec) and demand D
    (work units / request), the demand-model ceiling is C / D.
    The tightest resource is the predicted bottleneck.
    """
    if n_machines < 1:
        raise ValueError("n_machines must be >= 1")
    d = mix_demands(publish_percent, read_resp_bytes, read_miss_percent)
    cap_cpu = (n_machines * N_CORES * CPU_US_PER_CORE_PER_SEC) / d["d_cpu_us"]
    if d["d_disk_us"] > 0:
        cap_disk = (n_machines * CPU_US_PER_CORE_PER_SEC) / d["d_disk_us"]
    else:
        cap_disk = float("inf")
    cap_net = (n_machines * NET_BPS) / d["d_bits"]
    if include_downstream and d["d_down_us"] > 0:
        cap_down = CPU_US_PER_CORE_PER_SEC / d["d_down_us"]
    else:
        cap_down = float("inf")
    caps = {
        "cpu": cap_cpu,
        "disk": cap_disk,
        "net": cap_net,
        "downstream": cap_down,
    }
    bottleneck = min(caps, key=lambda k: caps[k])
    predicted = caps[bottleneck]
    return {
        **d,
        "n_machines": n_machines,
        "include_downstream": include_downstream,
        "cap_cpu_qps": cap_cpu,
        "cap_disk_qps": cap_disk,
        "cap_net_qps": cap_net,
        "cap_down_qps": cap_down,
        "bottleneck": bottleneck,
        "predicted_qps": predicted,
    }


def _percentile(sorted_vals: list[int], p: float) -> int:
    """Nearest-rank percentile. p in [0, 100]. Empty list -> 0."""
    n = len(sorted_vals)
    if n == 0:
        return 0
    if p <= 0:
        return sorted_vals[0]
    # Common nearest-rank: ceil(p/100 * n), 1-based, then -1
    rank = int((p / 100.0) * n)
    if (p / 100.0) * n > rank:
        rank += 1
    if rank < 1:
        rank = 1
    if rank > n:
        rank = n
    return sorted_vals[rank - 1]


def _is_publish(seq: int, publish_percent: int, clustered: bool = False) -> bool:
    """Deterministic mix.

    Even spread (default): Bresenham so 10% PUBLISH means every 10th request,
    not a burst of 10 writes at the start of each 100. Clustered means the
    first publish_percent of every 100 arrivals are PUBLISH, which packs
    writes together and is used only in the traffic-distribution experiment.
    """
    if publish_percent <= 0:
        return False
    if publish_percent >= 100:
        return True
    if clustered:
        return (seq % 100) < publish_percent
    return ((seq + 1) * publish_percent) // 100 > (seq * publish_percent) // 100


def _jitter(seq: int) -> int:
    return JITTER[seq % len(JITTER)]


def simulate_step(
    offered_qps: int,
    n_machines: int,
    publish_percent: int,
    read_resp_bytes: int = READ_RESP_BYTES,
    include_downstream: bool = True,
    duration_us: int = STEP_DURATION_US,
    min_requests: int = MIN_REQUESTS,
    clustered: bool = False,
    read_miss_percent: int = 0,
) -> dict[str, Any]:
    """Open-loop stepwise point: fixed offered rate, virtual-time queues.

    Each request goes CPU -> disk (if IOs) -> NIC -> optional shared downstream.
    Requests that would wait past TIMEOUT_US are dropped as errors and
    do not hold a resource. Arrivals are periodic (interval = 1e6 / QPS).
    Service times are multiplied by the repeating JITTER table.
    """
    if offered_qps <= 0 or n_machines < 1:
        raise ValueError("offered_qps and n_machines must be positive")

    n_arrivals = max(min_requests, int(offered_qps * duration_us / CPU_US_PER_CORE_PER_SEC))
    # Exact interval in us; keep remainder so the average rate matches.
    # arrival_i = i * 1_000_000 / offered_qps, integer division via accumulation.
    sim_end = int(n_arrivals * CPU_US_PER_CORE_PER_SEC / offered_qps)

    # Resource state per machine
    cpu_free = [N_CORES] * n_machines
    cpu_q: list[list[int]] = [[] for _ in range(n_machines)]  # request ids
    disk_busy = [False] * n_machines
    disk_q: list[list[int]] = [[] for _ in range(n_machines)]
    net_busy = [False] * n_machines
    net_q: list[list[int]] = [[] for _ in range(n_machines)]
    down_busy = False
    down_q: list[int] = []

    # request records
    start: list[int] = [0] * n_arrivals
    machine_of: list[int] = [0] * n_arrivals
    kind_pub: list[bool] = [False] * n_arrivals
    cpu_us: list[int] = [0] * n_arrivals
    disk_us: list[int] = [0] * n_arrivals
    net_us: list[int] = [0] * n_arrivals
    down_us: list[int] = [0] * n_arrivals
    done_at: list[Optional[int]] = [None] * n_arrivals
    err: list[bool] = [False] * n_arrivals
    stage: list[str] = ["wait_cpu"] * n_arrivals

    # events: (time, seq, typ, rid) typ: 0=arrival, 1=cpu_done, 2=disk_done, 3=net_done, 4=down_done
    ev: list[tuple[int, int, int, int]] = []
    seq_counter = 0

    def evpush(t: int, typ: int, rid: int) -> None:
        nonlocal seq_counter
        seq_counter += 1
        heapq.heappush(ev, (t, seq_counter, typ, rid))

    # Decide kind first, then assign machines in a per-kind round-robin so a
    # 10% publish stride cannot pin every write onto one machine when N=2.
    pub_assigned = 0
    read_assigned = 0
    read_seen = 0
    for i in range(n_arrivals):
        t = (i * CPU_US_PER_CORE_PER_SEC) // offered_qps
        evpush(t, 0, i)
        start[i] = t
        pub = _is_publish(i, publish_percent, clustered=clustered)
        kind_pub[i] = pub
        if pub:
            machine_of[i] = pub_assigned % n_machines
            pub_assigned += 1
        else:
            machine_of[i] = read_assigned % n_machines
            read_assigned += 1
        j = _jitter(i)
        if pub:
            cpu_us[i] = PUBLISH_CPU_US * j // 100
            disk_us[i] = PUBLISH_IOS * DISK_US_PER_IO * j // 100
            bits = PUBLISH_RESP_BYTES * 8
        else:
            cpu_us[i] = READ_CPU_US * j // 100
            # Bresenham on the READ index: read_miss_percent of READs issue 1 extra IO.
            miss = False
            if read_miss_percent > 0:
                miss = ((read_seen + 1) * read_miss_percent) // 100 > (read_seen * read_miss_percent) // 100
            read_seen += 1
            ios = READ_IOS + (1 if miss else 0)
            disk_us[i] = ios * DISK_US_PER_IO * j // 100
            bits = read_resp_bytes * 8
        # serialization time on a 1 Gbps teaching NIC, at least 1 us if bits>0
        net_us[i] = max(1, (bits * 1_000_000 + NET_BPS - 1) // NET_BPS)
        if pub and include_downstream:
            down_us[i] = DOWNSTREAM_US * j // 100
        else:
            down_us[i] = 0

    def timed_out(rid: int, now: int) -> bool:
        return now - start[rid] >= TIMEOUT_US

    def fail(rid: int, now: int) -> None:
        err[rid] = True
        done_at[rid] = now
        stage[rid] = "error"

    def try_cpu(rid: int, now: int) -> None:
        m = machine_of[rid]
        if timed_out(rid, now):
            fail(rid, now)
            return
        if cpu_free[m] > 0:
            cpu_free[m] -= 1
            stage[rid] = "cpu"
            evpush(now + cpu_us[rid], 1, rid)
        else:
            cpu_q[m].append(rid)
            stage[rid] = "wait_cpu"

    def try_disk(rid: int, now: int) -> None:
        m = machine_of[rid]
        if disk_us[rid] <= 0:
            try_net(rid, now)
            return
        if timed_out(rid, now):
            fail(rid, now)
            return
        if not disk_busy[m]:
            disk_busy[m] = True
            stage[rid] = "disk"
            evpush(now + disk_us[rid], 2, rid)
        else:
            disk_q[m].append(rid)
            stage[rid] = "wait_disk"

    def try_net(rid: int, now: int) -> None:
        m = machine_of[rid]
        if timed_out(rid, now):
            fail(rid, now)
            return
        if not net_busy[m]:
            net_busy[m] = True
            stage[rid] = "net"
            evpush(now + net_us[rid], 3, rid)
        else:
            net_q[m].append(rid)
            stage[rid] = "wait_net"

    def try_down(rid: int, now: int) -> None:
        if down_us[rid] <= 0:
            done_at[rid] = now
            stage[rid] = "ok"
            return
        if timed_out(rid, now):
            fail(rid, now)
            return
        nonlocal down_busy
        if not down_busy:
            down_busy = True
            stage[rid] = "down"
            evpush(now + down_us[rid], 4, rid)
        else:
            down_q.append(rid)
            stage[rid] = "wait_down"

    def release_cpu(m: int, now: int) -> None:
        cpu_free[m] += 1
        # drain one waiter
        while cpu_q[m] and cpu_free[m] > 0:
            nxt = cpu_q[m].pop(0)
            if timed_out(nxt, now):
                fail(nxt, now)
                continue
            cpu_free[m] -= 1
            stage[nxt] = "cpu"
            evpush(now + cpu_us[nxt], 1, nxt)
            break

    def release_disk(m: int, now: int) -> None:
        disk_busy[m] = False
        while disk_q[m] and not disk_busy[m]:
            nxt = disk_q[m].pop(0)
            if timed_out(nxt, now):
                fail(nxt, now)
                continue
            disk_busy[m] = True
            stage[nxt] = "disk"
            evpush(now + disk_us[nxt], 2, nxt)
            break

    def release_net(m: int, now: int) -> None:
        net_busy[m] = False
        while net_q[m] and not net_busy[m]:
            nxt = net_q[m].pop(0)
            if timed_out(nxt, now):
                fail(nxt, now)
                continue
            net_busy[m] = True
            stage[nxt] = "net"
            evpush(now + net_us[nxt], 3, nxt)
            break

    def release_down(now: int) -> None:
        nonlocal down_busy
        down_busy = False
        while down_q and not down_busy:
            nxt = down_q.pop(0)
            if timed_out(nxt, now):
                fail(nxt, now)
                continue
            down_busy = True
            stage[nxt] = "down"
            evpush(now + down_us[nxt], 4, nxt)
            break

    cpu_busy_us = 0
    disk_busy_us = 0
    net_busy_us = 0
    down_busy_us = 0
    # occupancy accounting: we add service times of started services
    max_cpu_q = 0
    max_disk_q = 0
    max_down_q = 0

    while ev:
        t, _, typ, rid = heapq.heappop(ev)
        if typ == 0:
            try_cpu(rid, t)
        elif typ == 1:
            m = machine_of[rid]
            cpu_busy_us += cpu_us[rid]
            release_cpu(m, t)
            try_disk(rid, t)
        elif typ == 2:
            m = machine_of[rid]
            disk_busy_us += disk_us[rid]
            release_disk(m, t)
            try_net(rid, t)
        elif typ == 3:
            m = machine_of[rid]
            net_busy_us += net_us[rid]
            release_net(m, t)
            try_down(rid, t)
        elif typ == 4:
            down_busy_us += down_us[rid]
            release_down(t)
            if not err[rid]:
                done_at[rid] = t
                stage[rid] = "ok"
        # queue high-water
        for m in range(n_machines):
            if len(cpu_q[m]) > max_cpu_q:
                max_cpu_q = len(cpu_q[m])
            if len(disk_q[m]) > max_disk_q:
                max_disk_q = len(disk_q[m])
        if len(down_q) > max_down_q:
            max_down_q = len(down_q)

    # anything still queued at the end of the event list is an error (didn't finish)
    for i in range(n_arrivals):
        if done_at[i] is None:
            # last event time as a stand-in
            fail(i, sim_end)
        # also: if a waiter is still sitting, already failed above

    latencies = []
    lat_read = []
    lat_pub = []
    ok = 0
    errors = 0
    last_ok = 0
    first_arr = start[0] if n_arrivals else 0
    for i in range(n_arrivals):
        if err[i] or stage[i] != "ok":
            errors += 1
        else:
            ok += 1
            lat = int(done_at[i]) - start[i]  # type: ignore[arg-type]
            latencies.append(lat)
            if kind_pub[i]:
                lat_pub.append(lat)
            else:
                lat_read.append(lat)
            if int(done_at[i]) > last_ok:  # type: ignore[arg-type]
                last_ok = int(done_at[i])  # type: ignore[arg-type]

    latencies.sort()
    lat_read.sort()
    lat_pub.sort()
    window_us = max(sim_end, last_ok) - first_arr
    if window_us <= 0:
        window_us = 1
    completed_qps = ok * CPU_US_PER_CORE_PER_SEC / window_us
    error_rate = errors / n_arrivals if n_arrivals else 0.0
    p50 = _percentile(latencies, 50)
    p99 = _percentile(latencies, 99)
    pmax = latencies[-1] if latencies else 0
    p99_read = _percentile(lat_read, 99)
    p99_publish = _percentile(lat_pub, 99)
    cpu_util = cpu_busy_us / (n_machines * N_CORES * window_us)
    disk_util = disk_busy_us / (n_machines * window_us)
    net_util = net_busy_us / (n_machines * window_us)
    down_util = down_busy_us / window_us if include_downstream else 0.0
    meets_slo = (error_rate <= SLO_ERROR_RATE + 1e-15) and (p99 <= SLO_P99_US) and ok > 0

    return {
        "offered_qps": offered_qps,
        "n_machines": n_machines,
        "publish_percent": publish_percent,
        "read_resp_bytes": read_resp_bytes,
        "include_downstream": include_downstream,
        "n_arrivals": n_arrivals,
        "ok": ok,
        "errors": errors,
        "error_rate": error_rate,
        "window_us": window_us,
        "completed_qps": completed_qps,
        "p50_us": p50,
        "p99_us": p99,
        "p99_read_us": p99_read,
        "p99_publish_us": p99_publish,
        "pmax_us": pmax,
        "clustered": clustered,
        "read_miss_percent": read_miss_percent,
        "cpu_util": cpu_util,
        "disk_util": disk_util,
        "net_util": net_util,
        "down_util": down_util,
        "max_cpu_q": max_cpu_q,
        "max_disk_q": max_disk_q,
        "max_down_q": max_down_q,
        "meets_slo": meets_slo,
    }


def run_ladder(
    steps: tuple[int, ...] | list[int],
    n_machines: int,
    publish_percent: int,
    read_resp_bytes: int = READ_RESP_BYTES,
    include_downstream: bool = True,
    clustered: bool = False,
    read_miss_percent: int = 0,
) -> dict[str, Any]:
    """Run a stepwise load test and locate the SLO inflection."""
    points = [
        simulate_step(
            offered_qps=s,
            n_machines=n_machines,
            publish_percent=publish_percent,
            read_resp_bytes=read_resp_bytes,
            include_downstream=include_downstream,
            clustered=clustered,
            read_miss_percent=read_miss_percent,
        )
        for s in steps
    ]
    # last step that still meets the SLO
    safe = [p for p in points if p["meets_slo"]]
    fail = [p for p in points if not p["meets_slo"]]
    last_safe = safe[-1] if safe else None
    first_fail = fail[0] if fail else None
    # test peak = max completed throughput, regardless of SLO
    peak = max(points, key=lambda p: p["completed_qps"])
    return {
        "n_machines": n_machines,
        "publish_percent": publish_percent,
        "read_resp_bytes": read_resp_bytes,
        "include_downstream": include_downstream,
        "clustered": clustered,
        "read_miss_percent": read_miss_percent,
        "steps": points,
        "last_slo_ok": last_safe,
        "first_slo_fail": first_fail,
        "test_peak": {
            "offered_qps": peak["offered_qps"],
            "completed_qps": peak["completed_qps"],
            "p99_us": peak["p99_us"],
            "error_rate": peak["error_rate"],
            "meets_slo": peak["meets_slo"],
        },
    }


def _round4(x: float) -> float:
    if x == float("inf"):
        return x
    return round(x, 4)


def _clean_pred(p: dict[str, Any]) -> dict[str, Any]:
    out = dict(p)
    for k, v in list(out.items()):
        if isinstance(v, float):
            if v == float("inf"):
                out[k] = None
                out[f"{k}_infinite"] = True
            else:
                out[k] = _round4(v)
    return out


def _clean_step(p: dict[str, Any]) -> dict[str, Any]:
    out = dict(p)
    for k in ("completed_qps", "error_rate", "cpu_util", "disk_util", "net_util", "down_util"):
        if k in out and isinstance(out[k], float):
            out[k] = _round4(out[k])
    return out


def run_all() -> dict[str, Any]:
    """All teaching experiments used by lesson 141."""
    # ---- predictions ----
    pred_default_1 = predict_capacity(1, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    pred_default_1_fe = predict_capacity(1, DEFAULT_PUBLISH_PERCENT, include_downstream=False)
    pred_all_read = predict_capacity(1, 0, include_downstream=True)
    pred_half = predict_capacity(1, 50, include_downstream=True)
    pred_large = predict_capacity(1, 0, read_resp_bytes=LARGE_READ_RESP_BYTES, include_downstream=True)
    pred_miss = predict_capacity(
        1, DEFAULT_PUBLISH_PERCENT, include_downstream=True, read_miss_percent=REALITY_READ_MISS_PERCENT
    )

    scale_preds = []
    for n in (1, 2, 3, 4):
        with_d = predict_capacity(n, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
        no_d = predict_capacity(n, DEFAULT_PUBLISH_PERCENT, include_downstream=False)
        scale_preds.append({"n": n, "with_downstream": with_d, "front_end_only": no_d})

    # ---- ladders ----
    ladder_default = run_ladder(DEFAULT_STEPS, 1, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    ladder_clustered = run_ladder(
        DEFAULT_STEPS, 1, DEFAULT_PUBLISH_PERCENT, include_downstream=True, clustered=True
    )
    ladder_all_read = run_ladder(MIX_STEPS, 1, 0, include_downstream=True)
    ladder_half = run_ladder(MIX_STEPS, 1, 50, include_downstream=True)
    ladder_large = run_ladder(NET_STEPS, 1, 0, read_resp_bytes=LARGE_READ_RESP_BYTES, include_downstream=True)
    ladder_miss = run_ladder(
        MISS_STEPS,
        1,
        DEFAULT_PUBLISH_PERCENT,
        include_downstream=True,
        read_miss_percent=REALITY_READ_MISS_PERCENT,
    )

    scale_ladders = []
    for n in (1, 2, 3, 4):
        # reuse default steps plus higher ones for n>1
        steps = DEFAULT_STEPS if n == 1 else SCALE_STEPS
        scale_ladders.append(
            {"n": n, "ladder": run_ladder(steps, n, DEFAULT_PUBLISH_PERCENT, include_downstream=True)}
        )

    # ---- pitfall: treat test peak as safe, then apply a +20% burst ----
    peak_offered = int(ladder_default["test_peak"]["offered_qps"])
    burst_offered = peak_offered * BURST_RATIO_HUNDREDTHS // 100
    burst_at_peak = simulate_step(
        offered_qps=burst_offered,
        n_machines=1,
        publish_percent=DEFAULT_PUBLISH_PERCENT,
        include_downstream=True,
    )
    # compare: take last SLO-ok as candidate, apply same burst
    last_ok = ladder_default["last_slo_ok"]
    last_ok_qps = int(last_ok["offered_qps"]) if last_ok else 0
    burst_at_slo = simulate_step(
        offered_qps=last_ok_qps * BURST_RATIO_HUNDREDTHS // 100 if last_ok_qps else burst_offered,
        n_machines=1,
        publish_percent=DEFAULT_PUBLISH_PERCENT,
        include_downstream=True,
    )
    # 30% headroom under the demand-model prediction (1000 -> 700)
    predicted_1 = pred_default_1["predicted_qps"]
    headroom_30 = int(predicted_1 * 70 / 100)
    burst_at_30 = simulate_step(
        offered_qps=headroom_30 * BURST_RATIO_HUNDREDTHS // 100,
        n_machines=1,
        publish_percent=DEFAULT_PUBLISH_PERCENT,
        include_downstream=True,
    )
    # base load at the 30% headroom point itself
    base_30 = simulate_step(
        offered_qps=headroom_30,
        n_machines=1,
        publish_percent=DEFAULT_PUBLISH_PERCENT,
        include_downstream=True,
    )

    # ---- failover: 2 machines, lose one ----
    # offered = 2 * last_slo_ok (as if we took "N times test-safe" with no extra margin)
    # and offered = 2 * headroom_30 (with 30% headroom on each)
    two_at_double_safe = None
    two_after_fail_no_margin = None
    two_at_double_headroom = None
    two_after_fail_with_margin = None
    if last_ok_qps:
        two_at_double_safe = simulate_step(
            offered_qps=2 * last_ok_qps,
            n_machines=2,
            publish_percent=DEFAULT_PUBLISH_PERCENT,
            include_downstream=True,
        )
        two_after_fail_no_margin = simulate_step(
            offered_qps=2 * last_ok_qps,
            n_machines=1,
            publish_percent=DEFAULT_PUBLISH_PERCENT,
            include_downstream=True,
        )
        two_at_double_headroom = simulate_step(
            offered_qps=2 * headroom_30,
            n_machines=2,
            publish_percent=DEFAULT_PUBLISH_PERCENT,
            include_downstream=True,
        )
        two_after_fail_with_margin = simulate_step(
            offered_qps=2 * headroom_30,
            n_machines=1,
            publish_percent=DEFAULT_PUBLISH_PERCENT,
            include_downstream=True,
        )

    # cost to carry a target load of 2000 QPS (the shared-downstream cap,
    # also 2x the single-machine demand-model capacity) at different margins.
    # machines_needed = ceil(target / (predicted * usable_frac))
    def machines_for(target: int, usable_frac: float) -> int:
        usable = predicted_1 * usable_frac
        if usable <= 0:
            return 0
        n = int(target / usable)
        if n * usable < target:
            n += 1
        return max(1, n)

    target_load = 2000
    cost_table = []
    for label, frac in (
        ("no_margin_100pct", 1.0),
        ("headroom_10pct", 0.9),
        ("headroom_30pct", 0.7),
        ("headroom_50pct", 0.5),
    ):
        n = machines_for(target_load, frac)
        cost_table.append(
            {
                "label": label,
                "usable_frac": frac,
                "usable_qps_per_machine": _round4(predicted_1 * frac),
                "target_qps": target_load,
                "machines": n,
                "teaching_cost": n * COST_PER_MACHINE,
            }
        )

    # Failover while carrying the 2000 QPS target:
    # 2 machines at 0% headroom, 3 machines (~33% headroom), 4 machines (50%).
    fo_2 = simulate_step(2000, 2, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    fo_2_to_1 = simulate_step(2000, 1, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    fo_3 = simulate_step(2000, 3, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    fo_3_to_2 = simulate_step(2000, 2, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    fo_4 = simulate_step(2000, 4, DEFAULT_PUBLISH_PERCENT, include_downstream=True)
    fo_4_to_3 = simulate_step(2000, 3, DEFAULT_PUBLISH_PERCENT, include_downstream=True)

    # error range: predicted vs last SLO-ok vs test peak
    last_ok_completed = last_ok["completed_qps"] if last_ok else 0.0
    last_ok_offered = last_ok["offered_qps"] if last_ok else 0
    rel_slo_vs_pred = (last_ok_offered - predicted_1) / predicted_1 if predicted_1 else 0.0
    rel_peak_vs_pred = (peak_offered - predicted_1) / predicted_1 if predicted_1 else 0.0

    def slim_ladder(L: dict[str, Any]) -> dict[str, Any]:
        return {
            "n_machines": L["n_machines"],
            "publish_percent": L["publish_percent"],
            "read_resp_bytes": L["read_resp_bytes"],
            "include_downstream": L["include_downstream"],
            "clustered": L.get("clustered", False),
            "read_miss_percent": L.get("read_miss_percent", 0),
            "steps": [_clean_step(p) for p in L["steps"]],
            "last_slo_ok": _clean_step(L["last_slo_ok"]) if L["last_slo_ok"] else None,
            "first_slo_fail": _clean_step(L["first_slo_fail"]) if L["first_slo_fail"] else None,
            "test_peak": {
                k: (_round4(v) if isinstance(v, float) else v)
                for k, v in L["test_peak"].items()
            },
        }

    results: dict[str, Any] = {
        "engine": ENGINE_NAME,
        "not_a_real_machine": True,
        "not_a_real_loadtest_product": True,
        "not_fio_or_wrk": True,
        "not_sre_workbook_numbers": True,
        "not_host_measurement": True,
        "cycles_are_teaching": True,
        "teaching_host": TEACHING_HOST,
        "teaching_kernel": TEACHING_KERNEL,
        "n_cores": N_CORES,
        "disk_iops": DISK_IOPS,
        "disk_us_per_io": DISK_US_PER_IO,
        "net_bps": NET_BPS,
        "downstream_qps": DOWNSTREAM_QPS,
        "downstream_us": DOWNSTREAM_US,
        "timeout_us": TIMEOUT_US,
        "slo_p99_us": SLO_P99_US,
        "slo_error_rate": SLO_ERROR_RATE,
        "read_cpu_us": READ_CPU_US,
        "read_ios": READ_IOS,
        "read_resp_bytes": READ_RESP_BYTES,
        "publish_cpu_us": PUBLISH_CPU_US,
        "publish_ios": PUBLISH_IOS,
        "publish_resp_bytes": PUBLISH_RESP_BYTES,
        "large_read_resp_bytes": LARGE_READ_RESP_BYTES,
        "default_publish_percent": DEFAULT_PUBLISH_PERCENT,
        "jitter": list(JITTER),
        "step_duration_us": STEP_DURATION_US,
        "min_requests": MIN_REQUESTS,
        "cost_per_machine": COST_PER_MACHINE,
        "burst_ratio": BURST_RATIO_HUNDREDTHS / 100.0,
        "assumptions": {
            "mix": "default is an even Bresenham spread: ((seq+1)*publish_percent)//100 increases exactly publish_percent times per 100 arrivals. The clustered experiment instead puts the first publish_percent of every 100 arrivals in a burst.",
            "arrivals": "open-loop periodic, arrival_i = i * 1e6 / offered_qps (integer division)",
            "service_jitter": "each request's CPU/disk/downstream times are multiplied by JITTER[i % 9] / 100; mean is 1.0",
            "cpu": f"{N_CORES} teaching cores per machine, each {CPU_US_PER_CORE_PER_SEC} us/s",
            "disk": f"one teaching disk per machine, {DISK_IOPS} IOPS, {DISK_US_PER_IO} us per IO, FCFS",
            "nic": f"one teaching NIC per machine, {NET_BPS} bps, serialization only",
            "downstream": f"one shared teaching audit/index, {DOWNSTREAM_QPS} QPS, FCFS, does not grow with machines",
            "path": "CPU then disk (if IOs) then NIC then optional downstream",
            "timeout": f"a request that would wait past {TIMEOUT_US} us is an error and does not hold a resource",
            "slo": f"p99 <= {SLO_P99_US} us and error_rate == 0",
            "read_cache": "default READ issues 0 disk IOs (teaching cache-hit assumption)",
            "units": "all times are teaching virtual microseconds, not host wall-clock",
            "not_from_workbook": "these teaching numbers are not the workbook's 500,000 QPS / 200 IOPS / 16-core / 64 GB example values used as measurements",
        },
        "predict_default_1": _clean_pred(pred_default_1),
        "predict_default_1_front_end_only": _clean_pred(pred_default_1_fe),
        "predict_all_read": _clean_pred(pred_all_read),
        "predict_half_publish": _clean_pred(pred_half),
        "predict_large_read": _clean_pred(pred_large),
        "predict_cache_miss_5pct": _clean_pred(pred_miss),
        "reality_read_miss_percent": REALITY_READ_MISS_PERCENT,
        "predict_scale": [
            {
                "n": row["n"],
                "with_downstream": _clean_pred(row["with_downstream"]),
                "front_end_only": _clean_pred(row["front_end_only"]),
            }
            for row in scale_preds
        ],
        "ladder_default": slim_ladder(ladder_default),
        "ladder_clustered": slim_ladder(ladder_clustered),
        "ladder_all_read": slim_ladder(ladder_all_read),
        "ladder_half_publish": slim_ladder(ladder_half),
        "ladder_large_read": slim_ladder(ladder_large),
        "ladder_cache_miss_5pct": slim_ladder(ladder_miss),
        "ladder_scale": [
            {"n": row["n"], "ladder": slim_ladder(row["ladder"])} for row in scale_ladders
        ],
        "error_range": {
            "predicted_qps": _round4(predicted_1),
            "predicted_bottleneck": pred_default_1["bottleneck"],
            "last_slo_ok_offered_qps": last_ok_offered,
            "last_slo_ok_completed_qps": _round4(last_ok_completed) if last_ok else None,
            "last_slo_ok_p99_us": last_ok["p99_us"] if last_ok else None,
            "rel_last_slo_ok_vs_predicted": _round4(rel_slo_vs_pred),
            "test_peak_offered_qps": peak_offered,
            "test_peak_completed_qps": _round4(ladder_default["test_peak"]["completed_qps"]),
            "test_peak_p99_us": ladder_default["test_peak"]["p99_us"],
            "test_peak_error_rate": _round4(ladder_default["test_peak"]["error_rate"]),
            "rel_test_peak_offered_vs_predicted": _round4(rel_peak_vs_pred),
            "cache_miss_5pct_predicted_qps": _round4(pred_miss["predicted_qps"]),
            "cache_miss_5pct_predicted_bottleneck": pred_miss["bottleneck"],
            "cache_miss_5pct_last_slo_ok_offered_qps": (
                ladder_miss["last_slo_ok"]["offered_qps"] if ladder_miss["last_slo_ok"] else None
            ),
            "cache_miss_5pct_last_slo_ok_p99_us": (
                ladder_miss["last_slo_ok"]["p99_us"] if ladder_miss["last_slo_ok"] else None
            ),
            "rel_cache_miss_slo_vs_naive_predicted": _round4(
                ((ladder_miss["last_slo_ok"]["offered_qps"] if ladder_miss["last_slo_ok"] else 0) - predicted_1)
                / predicted_1
            ),
        },
        "burst_at_test_peak": _clean_step(burst_at_peak),
        "burst_at_last_slo_ok": _clean_step(burst_at_slo),
        "headroom_30_base_qps": headroom_30,
        "headroom_30_base": _clean_step(base_30),
        "burst_at_headroom_30": _clean_step(burst_at_30),
        "failover_2_to_1_no_margin": {
            "two_machines": _clean_step(two_at_double_safe) if two_at_double_safe else None,
            "after_losing_one": _clean_step(two_after_fail_no_margin) if two_after_fail_no_margin else None,
        },
        "failover_2_to_1_headroom_30": {
            "two_machines": _clean_step(two_at_double_headroom) if two_at_double_headroom else None,
            "after_losing_one": _clean_step(two_after_fail_with_margin) if two_after_fail_with_margin else None,
        },
        "failover_target_2000": {
            "two_machines": _clean_step(fo_2),
            "two_after_losing_one": _clean_step(fo_2_to_1),
            "three_machines": _clean_step(fo_3),
            "three_after_losing_one": _clean_step(fo_3_to_2),
            "four_machines": _clean_step(fo_4),
            "four_after_losing_one": _clean_step(fo_4_to_3),
        },
        "cost_table": cost_table,
        "cost_target_qps": target_load,
    }

    # convenience flags for acceptance / pitfalls / tradeoffs
    slo_ok = results["error_range"]["last_slo_ok_offered_qps"]
    results["acceptance_assumptions_and_error_range"] = (
        slo_ok is not None and predicted_1 > 0
    )
    # shared downstream limits scale-out: n=3 predicted with downstream equals n=2, below front-end-only
    p2 = next(r for r in results["predict_scale"] if r["n"] == 2)
    p3 = next(r for r in results["predict_scale"] if r["n"] == 3)
    results["acceptance_scale_limited_by_shared_downstream"] = (
        p2["with_downstream"]["predicted_qps"] == p3["with_downstream"]["predicted_qps"]
        and p3["with_downstream"]["bottleneck"] == "downstream"
        and p3["front_end_only"]["predicted_qps"] > p3["with_downstream"]["predicted_qps"]
    )
    results["pitfall_test_peak_not_safe"] = (
        not results["burst_at_test_peak"]["meets_slo"]
    )
    results["tradeoff_margin_costs_machines"] = (
        cost_table[0]["machines"] < cost_table[-1]["machines"]
    )
    return results


if __name__ == "__main__":
    import json
    from pathlib import Path

    r = run_all()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print("wrote results.json", "engine=", r["engine"])
