#!/usr/bin/env python3
"""Teaching scenario wrapper for CapacityEngine.

The scenario is a content-backend article API used only as a teaching
assumption: READ fetches an article body, PUBLISH writes a new revision
and also calls a shared teaching audit/index. This is not a WeChat
service, not a real HTTP server, and not a host load test.
"""
from __future__ import annotations

from engine import run_all


def run():
    return run_all()


if __name__ == "__main__":
    r = run()
    print("engine", r["engine"])
    print("predicted", r["predict_default_1"]["predicted_qps"], r["predict_default_1"]["bottleneck"])
    er = r["error_range"]
    print("last_slo_ok", er["last_slo_ok_offered_qps"], "peak", er["test_peak_offered_qps"])
