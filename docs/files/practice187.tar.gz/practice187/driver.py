#!/usr/bin/env python3
"""Scripted coding-agent workflow for adding EXISTS to a C++ KV store.

The agent edits only the implementation and does not touch docs/UNRELATED.md.
This script actually invokes the documented CMake build; if the compiler is
missing, that fact is recorded. A Python protocol check is labeled as not
the compiler.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)

shutil.copytree(ROOT / "repo", WORK / "repo")
REPO = WORK / "repo"


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


UNRELATED = REPO / "docs/UNRELATED.md"
unrelated_before = UNRELATED.read_text(encoding="utf-8")
unrelated_hash_before = sha256(UNRELATED)
tracked = {
    rel: sha256(REPO / rel)
    for rel in [
        "docs/UNRELATED.md",
        "README.md",
        "CMakeLists.txt",
        "include/kv.h",
        "src/kv.cpp",
        "src/main.cpp",
        "tests/test_kv.cpp",
        "tests/protocol.md",
        "tests/protocol_check.py",
    ]
}

# ---- scripted agent: add exists(), explain lifecycle, extend protocol tests already present ----
# The C++ test file already has EXISTS assertions (they fail on the starting tree).
# The agent must declare and implement exists() and route EXISTS in handle_line
# without creating the key.

header = (REPO / "include/kv.h").read_text(encoding="utf-8")
if "bool exists(" not in header:
    header = header.replace(
        "  std::optional<std::string> get(const std::string& key) const;\n  // exists() is the requested command. The starting tree does not declare it yet.\n",
        "  std::optional<std::string> get(const std::string& key) const;\n  bool exists(const std::string& key) const;\n",
    )
    (REPO / "include/kv.h").write_text(header, encoding="utf-8")

cpp = (REPO / "src/kv.cpp").read_text(encoding="utf-8")
if "KV::exists" not in cpp:
    cpp = cpp.replace(
        "std::string KV::handle_line(const std::string& line) {",
        "bool KV::exists(const std::string& key) const { return data_.find(key) != data_.end(); }\n\n"
        "std::string KV::handle_line(const std::string& line) {",
    )
    cpp = cpp.replace(
        '  // EXISTS is part of the protocol contract (see tests/protocol.md) but is not implemented.\n  return "ERR unknown command";\n',
        '  if (cmd == "EXISTS") {\n'
        "    iss >> key;\n"
        '    if (key.empty()) return "ERR missing key";\n'
        '    return exists(key) ? "1" : "0";\n'
        "  }\n"
        '  return "ERR unknown command";\n',
    )
    (REPO / "src/kv.cpp").write_text(cpp, encoding="utf-8")

lifecycle_note = (
    "EXISTS is a membership query. It must not insert the key, so a following GET "
    "of a missing key still returns MISSING. The key's lifetime is unchanged: only SET creates "
    "or updates an entry; exists() is a const lookup on data_."
)
(REPORTS / "lifecycle.md").write_text(lifecycle_note, encoding="utf-8")

# Python protocol checker (NOT the compiler): contract-level properties.
import sys
sys.path.insert(0, str(REPO / "tests"))
import protocol_check

# Simulate protocol state in Python to show the intended contract, clearly labeled.
class PyKV:
    def __init__(self):
        self.data = {}
    def handle(self, line: str) -> str:
        parts = line.split(" ", 2)
        cmd = parts[0]
        if cmd == "SET":
            self.data[parts[1]] = parts[2] if len(parts) > 2 else ""
            return "OK"
        if cmd == "GET":
            return self.data[parts[1]] if parts[1] in self.data else "MISSING"
        if cmd == "EXISTS":
            return "1" if parts[1] in self.data else "0"
        return "ERR unknown command"

py = PyKV()
assert py.handle("SET a 1") == "OK"
assert py.handle("EXISTS a") == "1"
assert py.handle("EXISTS z") == "0"
assert protocol_check.valid_exists_response(py.handle("EXISTS z"))
before = "z" in py.data
after = "z" in py.data
assert protocol_check.exists_should_not_create(before, "EXISTS z", after)
protocol_ok = True

# Actually invoke the documented build commands.
def run_cmd(argv, cwd) -> dict:
    try:
        p = subprocess.run(argv, cwd=cwd, text=True, capture_output=True, timeout=60)
        return {
            "argv": argv,
            "returncode": p.returncode,
            "stdout_tail": (p.stdout or "")[-2000:],
            "stderr_tail": (p.stderr or "")[-2000:],
            "started": True,
            "which_missing": False,
        }
    except FileNotFoundError as e:
        return {
            "argv": argv,
            "returncode": None,
            "stdout_tail": "",
            "stderr_tail": str(e),
            "started": False,
            "which_missing": True,
        }


cmake_cfg = run_cmd(["cmake", "-S", ".", "-B", "build"], REPO)
cmake_build = run_cmd(["cmake", "--build", "build"], REPO) if cmake_cfg.get("returncode") == 0 else {
    "argv": ["cmake", "--build", "build"],
    "returncode": None,
    "stdout_tail": "",
    "stderr_tail": "skipped because cmake configure did not succeed",
    "started": False,
    "which_missing": cmake_cfg.get("which_missing", False),
}
ctest = run_cmd(["ctest", "--test-dir", "build", "--output-on-failure"], REPO) if cmake_build.get("returncode") == 0 else {
    "argv": ["ctest", "--test-dir", "build", "--output-on-failure"],
    "returncode": None,
    "stdout_tail": "",
    "stderr_tail": "skipped because the C++ build did not succeed",
    "started": False,
    "which_missing": False,
}

# Also record `which` for the toolchain (no sudo install).
which = {}
for tool in ("cmake", "g++", "clang++", "c++", "ctest"):
    which[tool] = shutil.which(tool)

unrelated_after = UNRELATED.read_text(encoding="utf-8")
changed = []
unchanged = []
for rel, before_h in tracked.items():
    now = sha256(REPO / rel) if (REPO / rel).exists() else None
    if now != before_h:
        changed.append(rel)
    else:
        unchanged.append(rel)

# The agent should have changed only include/kv.h and src/kv.cpp (implementation).
allowed_changes = {"include/kv.h", "src/kv.cpp"}
unexpected = [c for c in changed if c not in allowed_changes]
cpp_built = cmake_build.get("returncode") == 0
tests_ran = ctest.get("returncode") == 0

results = {
    "lesson": 187,
    "id": "m-coding",
    "is_live_model": False,
    "scripted_agent_is_not_an_llm": True,
    "build_commands": [cmake_cfg, cmake_build, ctest],
    "toolchain_which": which,
    "cpp_build_succeeded": cpp_built,
    "cpp_tests_ran": tests_ran,
    "protocol_check_python_ok": protocol_ok,
    "protocol_check_is_not_the_compiler": True,
    "unrelated_file_unchanged": unrelated_after == unrelated_before and sha256(UNRELATED) == unrelated_hash_before,
    "changed_files": changed,
    "unchanged_files": unchanged,
    "unexpected_changes": unexpected,
    "exists_declared": "bool exists(" in (REPO / "include/kv.h").read_text(encoding="utf-8"),
    "exists_implemented": "KV::exists" in (REPO / "src/kv.cpp").read_text(encoding="utf-8"),
    "handle_routes_exists": 'cmd == "EXISTS"' in (REPO / "src/kv.cpp").read_text(encoding="utf-8"),
    "lifecycle_note_path": "reports/lifecycle.md",
    "verified_on_this_machine": [
        "scripted agent added exists() and routed EXISTS without touching docs/UNRELATED.md",
        "documented CMake/ctest commands were invoked and their results recorded",
        "Python protocol-format check (explicitly not the compiler)",
    ],
    "not_verified_on_this_machine": [],
}

if not cpp_built:
    results["not_verified_on_this_machine"].append(
        "end-to-end C++ configure/build/ctest success (toolchain missing or build failed; see build_commands)"
    )
else:
    results["verified_on_this_machine"].append("C++ build and tests ran on this machine")

checks = {
    "unrelated": results["unrelated_file_unchanged"],
    "no_unexpected": unexpected == [],
    "exists_declared": results["exists_declared"],
    "exists_implemented": results["exists_implemented"],
    "routed": results["handle_routes_exists"],
    "protocol_py": protocol_ok,
    "commands_recorded": len(results["build_commands"]) == 3,
    "is_live_false": results["is_live_model"] is False,
    "did_not_claim_cpp_if_missing": (cpp_built is True) or ("end-to-end C++" in results["not_verified_on_this_machine"][0]),
}
if not all(checks.values()):
    raise SystemExit(f"checks failed: {checks}")

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
(REPORTS / "build.json").write_text(json.dumps(results["build_commands"], ensure_ascii=False, indent=2), encoding="utf-8")
print("CHANGED", changed)
print("UNRELATED_UNCHANGED", results["unrelated_file_unchanged"])
print("CMAKE", cmake_cfg.get("started"), cmake_cfg.get("returncode"), cmake_cfg.get("stderr_tail")[:200])
print("WHICH", which)
print("CPP_BUILD_SUCCEEDED", cpp_built)
print("ALL_CHECKS_PASSED")
