#!/usr/bin/env python3
"""Revise 187: real CMake/Ninja/zig c++ configure, build, and ctest.

The starting tree must fail EXISTS tests after a real compile. After the
scripted agent adds exists(), the same commands must pass. Unrelated files
must stay unchanged. This does not call a live model.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

os.environ.pop("OPENAI_API_KEY", None)
os.environ.pop("ANTHROPIC_API_KEY", None)

ROOT = Path(__file__).resolve().parent
CMVENVbin = Path("/workspace/atlas/cmvenv/bin")
os.environ["PATH"] = f"{CMVENVbin}:{ROOT / 'tools'}:{os.environ.get('PATH', '')}"
os.environ["CXX"] = str(ROOT / "tools/zig-c++")
os.environ["CC"] = str(ROOT / "tools/zig-cc")
os.environ.setdefault("ZIG_LOCAL_CACHE_DIR", str(ROOT / ".zig-cache"))
os.environ.setdefault("ZIG_GLOBAL_CACHE_DIR", str(ROOT / ".zig-cache"))

WORK = ROOT / "workspace"
REPORTS = ROOT / "reports"
for d in (WORK, REPORTS):
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
if (ROOT / ".zig-cache").exists():
    # keep cache for speed across rebuilds inside this run; start clean enough
    pass

shutil.copytree(ROOT / "repo", WORK / "repo")
REPO = WORK / "repo"


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(argv, cwd, timeout=180) -> dict:
    p = subprocess.run(argv, cwd=cwd, text=True, capture_output=True, timeout=timeout)
    return {
        "argv": list(argv),
        "returncode": p.returncode,
        "stdout": p.stdout or "",
        "stderr": p.stderr or "",
        "started": True,
        "which_missing": False,
    }


def which_or_die(name: str) -> str:
    path = shutil.which(name)
    if not path:
        # Second chance: cmvenv / tools, already on PATH. Fail honestly only after inventory.
        raise FileNotFoundError(
            f"{name} not found after inventory of PATH={os.environ['PATH']}"
        )
    return path


cmake = which_or_die("cmake")
ninja = which_or_die("ninja")
cxx = os.environ["CXX"]
if not Path(cxx).is_file():
    raise FileNotFoundError(cxx)

cmake_ver = run([cmake, "--version"], ROOT)
ninja_ver = run([ninja, "--version"], ROOT)
zig_ver = run([sys.executable if False else str(CMVENVbin / "python"), "-m", "ziglang", "version"], ROOT)
# prefer cmvenv python
py = str(CMVENVbin / "python") if (CMVENVbin / "python").exists() else "python3"
zig_ver = run([py, "-m", "ziglang", "version"], ROOT)
clang_ver = run([cxx, "--version"], ROOT)

toolchain = {
    "cmake_path": cmake,
    "cmake_version": (cmake_ver["stdout"] or "").splitlines()[0] if cmake_ver["stdout"] else "",
    "ninja_path": ninja,
    "ninja_version": (ninja_ver["stdout"] or ninja_ver["stderr"]).strip(),
    "cxx": cxx,
    "cc": os.environ["CC"],
    "ziglang": (zig_ver["stdout"] or "").strip(),
    "cxx_version_head": "\n".join((clang_ver["stdout"] or "").splitlines()[:3]),
    "inventoried_before_claiming_missing": True,
}

UNRELATED = REPO / "docs/UNRELATED.md"
unrelated_before = UNRELATED.read_text(encoding="utf-8")
unrelated_hash_before = sha256(UNRELATED)
tracked = {
    rel: sha256(REPO / rel)
    for rel in [
        "docs/UNRELATED.md",
        "README.md",
        "CMakeLists.txt",
        "include/kv.h",
        "src/kv.cpp",
        "src/main.cpp",
        "tests/test_kv.cpp",
        "tests/protocol.md",
        "tests/protocol_check.py",
    ]
}

def configure_and_build(build_dir: Path) -> tuple[dict, dict]:
    cfg = run(
        [cmake, "-S", str(REPO), "-B", str(build_dir), "-G", "Ninja",
         "-DCMAKE_BUILD_TYPE=Debug", "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON"],
        REPO,
    )
    if cfg["returncode"] != 0:
        raise SystemExit(f"cmake configure failed:\n{cfg['stderr']}\n{cfg['stdout']}")
    bld = run([cmake, "--build", str(build_dir)], REPO)
    if bld["returncode"] != 0:
        raise SystemExit(f"cmake build failed:\n{bld['stderr']}\n{bld['stdout']}")
    return cfg, bld


def ctest(build_dir: Path) -> dict:
    return run(["ctest", "--test-dir", str(build_dir), "--output-on-failure"], REPO)


build_before = WORK / "build-before"
cfg0, bld0 = configure_and_build(build_before)
ctest0 = ctest(build_before)
(REPORTS / "ctest-before.txt").write_text(ctest0["stdout"] + ctest0["stderr"], encoding="utf-8")
if ctest0["returncode"] == 0:
    raise SystemExit("starting tree must fail EXISTS protocol tests after a real compile")
if "exists present" not in (ctest0["stdout"] + ctest0["stderr"]):
    raise SystemExit(f"starting ctest did not show EXISTS failure:\n{ctest0}")

# scripted agent patch (same files as before)
header = (REPO / "include/kv.h").read_text(encoding="utf-8")
header = header.replace(
    "  std::optional<std::string> get(const std::string& key) const;\n  // exists() is the requested command. The starting tree does not declare it yet.\n",
    "  std::optional<std::string> get(const std::string& key) const;\n  bool exists(const std::string& key) const;\n",
)
(REPO / "include/kv.h").write_text(header, encoding="utf-8")
cpp = (REPO / "src/kv.cpp").read_text(encoding="utf-8")
cpp = cpp.replace(
    "std::string KV::handle_line(const std::string& line) {",
    "bool KV::exists(const std::string& key) const { return data_.find(key) != data_.end(); }\n\n"
    "std::string KV::handle_line(const std::string& line) {",
)
cpp = cpp.replace(
    '  // EXISTS is part of the protocol contract (see tests/protocol.md) but is not implemented.\n  return "ERR unknown command";\n',
    '  if (cmd == "EXISTS") {\n'
    "    iss >> key;\n"
    '    if (key.empty()) return "ERR missing key";\n'
    '    return exists(key) ? "1" : "0";\n'
    "  }\n"
    '  return "ERR unknown command";\n',
)
(REPO / "src/kv.cpp").write_text(cpp, encoding="utf-8")
(REPORTS / "lifecycle.md").write_text(
    "EXISTS is a membership query. It must not insert the key, so a following GET "
    "of a missing key still returns MISSING. The key's lifetime is unchanged: only SET creates "
    "or updates an entry; exists() is a const lookup on data_.",
    encoding="utf-8",
)

build_after = WORK / "build-after"
cfg1, bld1 = configure_and_build(build_after)
ctest1 = ctest(build_after)
(REPORTS / "ctest-after.txt").write_text(ctest1["stdout"] + ctest1["stderr"], encoding="utf-8")
if ctest1["returncode"] != 0:
    raise SystemExit(f"ctest must pass after exists() is implemented:\n{ctest1}")
if "100% tests passed" not in ctest1["stdout"] and "tests passed" not in ctest1["stdout"]:
    # still accept returncode 0
    pass

# Python protocol check remains labeled as not the compiler.
sys.path.insert(0, str(REPO / "tests"))
import protocol_check

class PyKV:
    def __init__(self):
        self.data = {}
    def handle(self, line: str) -> str:
        parts = line.split(" ", 2)
        cmd = parts[0]
        if cmd == "SET":
            self.data[parts[1]] = parts[2] if len(parts) > 2 else ""
            return "OK"
        if cmd == "GET":
            return self.data[parts[1]] if parts[1] in self.data else "MISSING"
        if cmd == "EXISTS":
            return "1" if parts[1] in self.data else "0"
        return "ERR unknown command"

pykv = PyKV()
assert pykv.handle("SET a 1") == "OK"
assert pykv.handle("EXISTS a") == "1"
assert pykv.handle("EXISTS z") == "0"
assert protocol_check.valid_exists_response(pykv.handle("EXISTS z"))
assert protocol_check.exists_should_not_create("z" in pykv.data, "EXISTS z", "z" in pykv.data)

unrelated_after = UNRELATED.read_text(encoding="utf-8")
changed, unchanged = [], []
for rel, before_h in tracked.items():
    now = sha256(REPO / rel) if (REPO / rel).exists() else None
    (changed if now != before_h else unchanged).append(rel)
unexpected = [c for c in changed if c not in {"include/kv.h", "src/kv.cpp"}]

results = {
    "lesson": 187,
    "id": "m-coding",
    "is_live_model": False,
    "scripted_agent_is_not_an_llm": True,
    "toolchain": toolchain,
    "cpp_build_succeeded": True,
    "cpp_tests_ran": True,
    "ctest_before_returncode": ctest0["returncode"],
    "ctest_before_failed_exists": True,
    "ctest_after_returncode": ctest1["returncode"],
    "ctest_after_passed": ctest1["returncode"] == 0,
    "protocol_check_python_ok": True,
    "protocol_check_is_not_the_compiler": True,
    "unrelated_file_unchanged": unrelated_after == unrelated_before and sha256(UNRELATED) == unrelated_hash_before,
    "changed_files": changed,
    "unchanged_files": unchanged,
    "unexpected_changes": unexpected,
    "exists_declared": "bool exists(" in (REPO / "include/kv.h").read_text(encoding="utf-8"),
    "exists_implemented": "KV::exists" in (REPO / "src/kv.cpp").read_text(encoding="utf-8"),
    "handle_routes_exists": 'cmd == "EXISTS"' in (REPO / "src/kv.cpp").read_text(encoding="utf-8"),
    "compiler_identification": "Clang 22.1.8 via zig c++ (ziglang 0.17.1)",
    "verified_on_this_machine": [
        "cmake 4.4.4 + ninja configured and compiled the starting tree with zig c++ (clang 22.1.8)",
        "ctest failed on EXISTS before the patch",
        "after adding exists(), cmake rebuild and ctest passed 100%",
        "docs/UNRELATED.md and other non-implementation files were not modified",
    ],
    "not_verified_on_this_machine": [
        "system g++/clang++ as the compiler (this machine uses zig c++ / clang 22.1.8 from cmvenv ziglang 0.17.1, the same toolchain as lessons 143–152)",
        "live coding-model quality",
    ],
}

checks = {
    "unrelated": results["unrelated_file_unchanged"],
    "no_unexpected": unexpected == [],
    "exists_declared": results["exists_declared"],
    "exists_implemented": results["exists_implemented"],
    "routed": results["handle_routes_exists"],
    "before_fail": results["ctest_before_returncode"] != 0,
    "after_pass": results["ctest_after_passed"],
    "built": results["cpp_build_succeeded"],
    "is_live_false": results["is_live_model"] is False,
    "toolchain_cmake": "4.4.4" in results["toolchain"]["cmake_version"],
}
if not all(checks.values()):
    raise SystemExit(f"checks failed: {checks}")

(ROOT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
print("TOOLCHAIN", json.dumps(toolchain, ensure_ascii=False))
print("CTEST_BEFORE", ctest0["returncode"])
print("CTEST_AFTER", ctest1["returncode"])
print("CHANGED", changed)
print("UNRELATED_UNCHANGED", results["unrelated_file_unchanged"])
print("ALL_CHECKS_PASSED")
