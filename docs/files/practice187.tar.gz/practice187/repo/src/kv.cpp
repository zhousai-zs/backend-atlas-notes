#include "kv.h"
#include <sstream>

void KV::set(const std::string& key, const std::string& value) { data_[key] = value; }

std::optional<std::string> KV::get(const std::string& key) const {
  auto it = data_.find(key);
  if (it == data_.end()) return std::nullopt;
  return it->second;
}

std::string KV::handle_line(const std::string& line) {
  std::istringstream iss(line);
  std::string cmd, key, value;
  iss >> cmd;
  if (cmd == "SET") {
    iss >> key;
    std::getline(iss, value);
    if (!value.empty() && value[0] == ' ') value.erase(0, 1);
    if (key.empty()) return "ERR missing key";
    set(key, value);
    return "OK";
  }
  if (cmd == "GET") {
    iss >> key;
    auto v = get(key);
    return v ? *v : "MISSING";
  }
  // EXISTS is part of the protocol contract (see tests/protocol.md) but is not implemented.
  return "ERR unknown command";
}
