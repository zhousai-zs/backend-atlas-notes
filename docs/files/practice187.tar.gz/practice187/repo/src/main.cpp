#include "kv.h"
#include <iostream>
#include <string>

int main() {
  KV kv;
  std::string line;
  while (std::getline(std::cin, line)) {
    std::cout << kv.handle_line(line) << "\n";
  }
  return 0;
}
