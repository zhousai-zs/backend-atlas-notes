# kv_exists (teaching store)

Build (requires a C++ compiler and CMake, not provided on every machine):

```
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

Protocol: see tests/protocol.md. The starting tree does not implement EXISTS yet.
