# KV text protocol (contract)

Commands are one line, responses are one line.

- `SET <key> <value>` -> `OK`
- `GET <key>` -> the value, or `MISSING`
- `EXISTS <key>` -> `1` if the key is present, `0` if it is not. This is a membership query and must not create the key.

This contract is the test oracle. A Python checker can validate message formatting without compiling C++. That checker is not a substitute for `kv_test` or the compiler.
