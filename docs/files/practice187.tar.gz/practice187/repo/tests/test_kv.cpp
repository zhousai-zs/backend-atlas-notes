#include "kv.h"
#include <cstdlib>
#include <iostream>
#include <string>

static int g_fails = 0;
static void expect_eq(const std::string& got, const std::string& want, const char* what) {
  if (got != want) {
    std::cerr << "FAIL " << what << " got=[" << got << "] want=[" << want << "]\n";
    g_fails++;
  }
}

int main() {
  KV kv;
  expect_eq(kv.handle_line("SET a 1"), "OK", "set");
  expect_eq(kv.handle_line("GET a"), "1", "get");
  expect_eq(kv.handle_line("GET z"), "MISSING", "missing");
  // The following assertions are the protocol tests the agent must keep working
  // after adding EXISTS. Starting tree will fail them until exists is implemented.
  expect_eq(kv.handle_line("EXISTS a"), "1", "exists present");
  expect_eq(kv.handle_line("EXISTS z"), "0", "exists absent");
  if (g_fails) {
    std::cerr << g_fails << " assertion(s) failed\n";
    return 1;
  }
  return 0;
}
