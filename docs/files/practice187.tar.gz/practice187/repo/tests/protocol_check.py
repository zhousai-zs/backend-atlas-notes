#!/usr/bin/env python3
"""Protocol-format checker. This is NOT a C++ compiler and does not run kv_test."""
from __future__ import annotations

def valid_exists_response(text: str) -> bool:
    return text in {"0", "1"}

def exists_should_not_create(before_present: bool, command: str, after_present: bool) -> bool:
    if not command.startswith("EXISTS "):
        return False
    return after_present == before_present
