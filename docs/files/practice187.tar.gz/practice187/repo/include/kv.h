#pragma once
#include <optional>
#include <string>
#include <unordered_map>

// Teaching store: an in-memory key-value map with a tiny text protocol.
// This is not a Tencent or WeChat production component.
class KV {
public:
  void set(const std::string& key, const std::string& value);
  std::optional<std::string> get(const std::string& key) const;
  // exists() is the requested command. The starting tree does not declare it yet.

  // Apply one text-protocol line and return the response line (no trailing newline).
  std::string handle_line(const std::string& line);

private:
  std::unordered_map<std::string, std::string> data_;
};
