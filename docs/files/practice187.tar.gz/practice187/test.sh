#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["unrelated_file_unchanged"] and r["unexpected_changes"]==[]
assert r["exists_declared"] and r["exists_implemented"] and r["handle_routes_exists"]
assert r["protocol_check_is_not_the_compiler"] is True
assert r["protocol_check_python_ok"] is True
# Honest: if the compiler was missing, we must not claim a C++ success.
if not r["cpp_build_succeeded"]:
    assert r["not_verified_on_this_machine"], "missing compiler must be listed"
    assert r["cpp_tests_ran"] is False
print("POSTCHECK_OK")
PY
