#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PATH="/workspace/atlas/cmvenv/bin:$PWD/tools:${PATH:-}"
unset OPENAI_API_KEY ANTHROPIC_API_KEY || true
# Inventory first: never claim the C++ toolchain is missing without looking in cmvenv.
cmake --version | head -1
ninja --version
./tools/zig-c++ --version | head -3
python3 driver.py 2>&1 | tee run.log
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path("results.json").read_text())
assert "ALL_CHECKS_PASSED" in Path("run.log").read_text()
assert r["is_live_model"] is False
assert r["cpp_build_succeeded"] and r["cpp_tests_ran"]
assert r["ctest_before_returncode"] != 0 and r["ctest_after_passed"]
assert r["unrelated_file_unchanged"] and r["unexpected_changes"]==[]
assert r["exists_declared"] and r["exists_implemented"] and r["handle_routes_exists"]
assert "4.4.4" in r["toolchain"]["cmake_version"]
print("POSTCHECK_OK")
PY
