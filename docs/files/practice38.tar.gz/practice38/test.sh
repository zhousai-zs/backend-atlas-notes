#!/usr/bin/env bash
# 第38课实践：mmap 文件顺序/随机读，记录 minor/major faults、VSZ/RSS，截断后 SIGBUS
set -u; cd "$(dirname "$0")"
gcc -O1 -w -o vm vm.c || exit 1
out=$(./vm ./data.bin); echo "$out"; fail=0
chk(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
g(){ echo "$out" | grep "^$1" | grep -o "$2=[0-9]*" | cut -d= -f2; }
vsz=$(echo "$out"|grep after_mmap|sed 's/.*VSZ+\([0-9]*\)KB RSS+\([0-9]*\)KB/\1/')
rss=$(echo "$out"|grep after_mmap|sed 's/.*RSS+\([0-9]*\)KB/\1/')
chk "mmap 后 VSZ 涨 64MB 而 RSS 几乎不涨" '[ "$vsz" -ge 65536 ] && [ "$rss" -lt 4096 ]'
chk "顺序读缺页数远少于页数(fault-around/预读)" '[ "$(g seq_half minflt)" -lt 8192 ]'
chk "MADV_RANDOM 随机读出现大量 major fault" '[ "$(g rand_2000 majflt)" -gt 100 ]'
chk "再次顺序读已驻留页不再缺页" '[ "$(g seq_again minflt)" -eq 0 ] && [ "$(g seq_again majflt)" -eq 0 ]'
chk "截断后访问越界映射收到 SIGBUS" 'echo "$out" | grep -q "truncate_access SIGBUS"'
a0=$(echo "$out"|grep anon_256MB|grep -o '+[0-9]*'|tr -d +); a1=$(echo "$out"|grep anon_touch|grep -o '+[0-9]*'|tr -d +)
chk "匿名 256MB 未触碰不占 RSS，触碰 32MB 才涨约 32MB" '[ "$a0" -lt 1024 ] && [ "$a1" -ge 32000 ]'
[ $fail -eq 0 ] && echo ALL_CHECKS_PASSED
