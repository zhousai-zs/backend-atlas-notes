#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>

static long rss_kb(void){FILE*f=fopen("/proc/self/status","r");char l[256];long v=-1;
 while(fgets(l,sizeof l,f)) if(!strncmp(l,"VmRSS:",6)) sscanf(l+6,"%ld",&v); fclose(f);return v;}
static long vsz_kb(void){FILE*f=fopen("/proc/self/status","r");char l[256];long v=-1;
 while(fgets(l,sizeof l,f)) if(!strncmp(l,"VmSize:",7)) sscanf(l+7,"%ld",&v); fclose(f);return v;}
static void flt(long*mn,long*mj){struct rusage r;getrusage(RUSAGE_SELF,&r);*mn=r.ru_minflt;*mj=r.ru_majflt;}
static sigjmp_buf jb; static void onbus(int s){(void)s;siglongjmp(jb,1);}

int main(int argc,char**argv){
 const char*path=argc>1?argv[1]:"data.bin"; size_t sz=64UL<<20; long pg=sysconf(_SC_PAGESIZE);
 int fd=open(path,O_RDWR|O_CREAT|O_TRUNC,0644); char*buf=malloc(1<<20); memset(buf,'x',1<<20);
 for(int i=0;i<64;i++) if(write(fd,buf,1<<20)!=1<<20){perror("write");return 1;}
 fsync(fd); posix_fadvise(fd,0,0,POSIX_FADV_DONTNEED);  /* 尽量把页缓存踢掉 */
 long mn0,mj0,mn1,mj1; long r0=rss_kb(),v0=vsz_kb();
 char*p=mmap(NULL,sz,PROT_READ,MAP_SHARED,fd,0); if(p==MAP_FAILED){perror("mmap");return 1;}
 printf("after_mmap VSZ+%ldKB RSS+%ldKB\n",vsz_kb()-v0,rss_kb()-r0);
 flt(&mn0,&mj0); volatile long sum=0;
 for(size_t off=0;off<sz/2;off+=pg) sum+=p[off];          /* 顺序读前一半 */
 flt(&mn1,&mj1);
 printf("seq_half minflt=%ld majflt=%ld RSS+%ldKB pages=%zu\n",mn1-mn0,mj1-mj0,rss_kb()-r0,sz/2/pg);
 madvise(p,sz,MADV_RANDOM); srand(1); flt(&mn0,&mj0);
 for(int i=0;i<2000;i++){size_t off=(size_t)(sz/2+ (rand()%(sz/2/pg))*pg); sum+=p[off];} /* 随机读后一半 */
 flt(&mn1,&mj1);
 printf("rand_2000 minflt=%ld majflt=%ld RSS+%ldKB\n",mn1-mn0,mj1-mj0,rss_kb()-r0);
 flt(&mn0,&mj0); for(size_t off=0;off<sz/2;off+=pg) sum+=p[off]; flt(&mn1,&mj1);
 printf("seq_again minflt=%ld majflt=%ld\n",mn1-mn0,mj1-mj0);
 /* 截断后访问映射 -> SIGBUS */
 ftruncate(fd,pg); signal(SIGBUS,onbus);
 if(sigsetjmp(jb,1)==0){ sum+=p[sz-1]; printf("truncate_access no_signal\n"); }
 else printf("truncate_access SIGBUS\n");
 printf("first_page_ok=%c\n",p[0]);
 /* 匿名映射：只有触碰才占 RSS */
 long ra=rss_kb(); char*a=mmap(NULL,256UL<<20,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 printf("anon_256MB_untouched RSS+%ldKB\n",rss_kb()-ra);
 for(size_t o=0;o<(32UL<<20);o+=pg) a[o]=1;
 printf("anon_touch_32MB RSS+%ldKB\n",rss_kb()-ra);
 munmap(a,256UL<<20); munmap(p,sz); close(fd); unlink(path); (void)sum; return 0;}
