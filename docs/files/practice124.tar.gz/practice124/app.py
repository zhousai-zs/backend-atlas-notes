#!/usr/bin/env python3
"""Run the lesson 124 circuit-breaking / isolation / degradation experiments."""
from __future__ import annotations

from typing import Any

from engine import (
    DEADLINE_S,
    DEST_RELATED,
    DEST_TITLE,
    HALF_OPEN_MAX_PROBES,
    KEY_TITLE,
    OPEN_DURATION_S,
    POOL_SIZE,
    RELATED_V1,
    SERVICE_TIME_S,
    SHARED_POOL_SIZE,
    SLOW_TIME_S,
    TITLE_V1,
    WINDOW_SIZE,
    CircuitIsolateEngine,
)


def run_error_window_and_half_open() -> dict[str, Any]:
    """Fail 5 times to open the circuit, fail-fast while open, then bound half-open probes."""
    eng = CircuitIsolateEngine(use_circuit=True, shared_pool=False)
    eng.set_mode(DEST_RELATED, "error")
    # 5 failing calls at t=0, 0.10, ..., 0.40 to fill the error window.
    for i in range(5):
        eng.arrive(DEST_RELATED, at=round(i * 0.10, 2))
    # The fifth error finishes at 0.50 and trips the breaker; drain so the state is visible.
    eng.drain()
    opened_at = eng.now()
    snap_open = eng.circuits[DEST_RELATED].snapshot()
    # While open, 8 more arrivals should not touch the downstream.
    calls_after_open = eng.downstreams[DEST_RELATED].calls
    fail_fast = []
    for i in range(8):
        rec = eng.arrive(DEST_RELATED, at=round(0.40 + (i + 1) * 0.01, 2))
        fail_fast.append(rec.as_dict())
    calls_during_open = eng.downstreams[DEST_RELATED].calls
    # Half-open at open_until = opened_at + 0.50. 5th failure finishes at ~0.40 (error duration 0).
    # Calls at 0, 0.1, 0.2, 0.3, 0.4 — all complete immediately, last observe at 0.40, open_until=0.90.
    half_at = (eng.circuits[DEST_RELATED].open_until or 0.0)
    # 6 arrivals at half-open instant: only 2 may probe.
    probes = []
    blocked = []
    for i in range(6):
        rec = eng.arrive(DEST_RELATED, at=half_at)
        if rec.probed:
            probes.append(rec.as_dict())
        else:
            blocked.append(rec.as_dict())
    eng.drain()
    cb = eng.circuits[DEST_RELATED].snapshot()
    st = eng.stats(DEST_RELATED)
    return {
        "window_size": WINDOW_SIZE,
        "fail_threshold": 5,
        "open_duration_s": OPEN_DURATION_S,
        "half_open_max_probes": HALF_OPEN_MAX_PROBES,
        "opened_state_after_five": snap_open["state"],
        "trips_after_five": snap_open["trips"],
        "opened_at": opened_at,
        "open_until": None if snap_open["open_until"] is None else snap_open["open_until"],
        "calls_when_opened": calls_after_open,
        "calls_during_open": calls_during_open,
        "no_calls_while_open": calls_during_open == calls_after_open,
        "fail_fast_n": len(fail_fast),
        "fail_fast_reasons": sorted({r["reason"] for r in fail_fast}),
        "half_open_at": ts_safe(half_at),
        "half_open_arrivals": 6,
        "half_open_probes": len(probes),
        "half_open_blocked": len(blocked),
        "probes_bounded": len(probes) <= HALF_OPEN_MAX_PROBES and len(probes) == HALF_OPEN_MAX_PROBES,
        "max_probes_in_one_half_open": cb["max_probes_in_one_half_open"],
        "downstream_calls_total": st["downstream_calls"],
        "downstream_calls_are_window_plus_probes": st["downstream_calls"] == 5 + len(probes),
        "state_after": cb["state"],
        "trips_after": cb["trips"],
        "stats": st,
        "t_end": eng.now(),
    }


def ts_safe(t: float) -> float:
    return round(float(t) + 1e-12, 2)


def run_half_open_recovery() -> dict[str, Any]:
    """After the circuit opens, the dependency recovers; a bounded probe closes it."""
    eng = CircuitIsolateEngine(use_circuit=True, shared_pool=False)
    eng.set_mode(DEST_RELATED, "error")
    for i in range(5):
        eng.arrive(DEST_RELATED, at=round(i * 0.10, 2))
    eng.drain()
    open_until = eng.circuits[DEST_RELATED].open_until or 0.0
    eng.set_mode(DEST_RELATED, "ok")
    rec = eng.arrive(DEST_RELATED, at=open_until)
    eng.drain()
    cb = eng.circuits[DEST_RELATED].snapshot()
    # A later call should go through closed, not as a probe.
    later = eng.arrive(DEST_RELATED, at=open_until + 0.10)
    eng.drain()
    return {
        "probe": rec.as_dict(),
        "probe_succeeded": rec.status == "ok" and rec.probed,
        "state_after_probe": cb["state"],
        "later": later.as_dict(),
        "later_ok_not_probe": later.status == "ok" and not later.probed,
        "closed_after_successful_probe": cb["state"] == "closed" and later.status == "ok",
        "downstream_calls": eng.downstreams[DEST_RELATED].calls,
        "t_end": eng.now(),
    }


def _isolation_arrivals() -> list[tuple[float, str]]:
    # 4 slow/related at t=0; 10 title at 10 QPS starting at t=0.00.
    arr = [(0.0, DEST_RELATED) for _ in range(4)]
    arr += [(round(i * 0.10, 2), DEST_TITLE) for i in range(10)]
    return arr


def run_bulkhead_isolation() -> dict[str, Any]:
    """Official practice: independent pools vs one shared pool, one slow dependency."""
    def _run(shared: bool) -> CircuitIsolateEngine:
        if shared:
            eng = CircuitIsolateEngine(
                use_circuit=False,
                shared_pool=True,
                shared_pool_size=SHARED_POOL_SIZE,
                deadline_s=DEADLINE_S,
            )
        else:
            eng = CircuitIsolateEngine(
                use_circuit=False,
                shared_pool=False,
                pool_size=POOL_SIZE,
                deadline_s=DEADLINE_S,
            )
        eng.set_mode(DEST_RELATED, "slow")
        eng.downstreams[DEST_RELATED].slow_time_s = SLOW_TIME_S
        eng.run_arrivals(_isolation_arrivals())
        return eng

    shared = _run(True)
    isolated = _run(False)
    ss, st = shared.stats(), isolated.stats()
    title_shared, title_iso = ss["title"], st["title"]
    rel_shared, rel_iso = ss["related"], st["related"]
    return {
        "service_time_s": SERVICE_TIME_S,
        "slow_time_s": SLOW_TIME_S,
        "deadline_s": DEADLINE_S,
        "shared_pool_size": SHARED_POOL_SIZE,
        "isolated_pool_size": POOL_SIZE,
        "shared": ss,
        "isolated": st,
        "shared_title_ok": title_shared["ok"],
        "shared_title_timeout": title_shared["timeout"],
        "shared_title_latency_max": title_shared["latency_max"],
        "shared_title_dragged_down": title_shared["ok"] < 10 and title_shared["timeout"] > 0,
        "isolated_title_ok": title_iso["ok"],
        "isolated_title_timeout": title_iso["timeout"],
        "isolated_title_ok_latency_max": title_iso["ok_latency_max"],
        "isolated_title_untouched": title_iso["ok"] == 10 and title_iso["timeout"] == 0 and title_iso["ok_latency_max"] == SERVICE_TIME_S,
        "shared_related_pool_max": rel_shared["pool_max_inflight"],
        "isolated_related_pool_max": rel_iso["pool_max_inflight"],
        "isolated_title_pool_max": title_iso["pool_max_inflight"],
        "same_physical_pool_when_shared": rel_shared["pool_name"] == title_shared["pool_name"] == "shared",
        "different_pools_when_isolated": rel_iso["pool_name"] != title_iso["pool_name"],
        "practice_isolated_title_survives_slow_related": title_iso["ok"] == 10
        and title_iso["ok_latency_max"] == SERVICE_TIME_S
        and title_shared["ok"] < title_iso["ok"],
    }


def run_degradation_freshness() -> dict[str, Any]:
    """A degraded related result must carry freshness; a freshness budget can refuse it."""
    # Policy A: serve stale cache with a label, no freshness budget.
    labelled = CircuitIsolateEngine(use_circuit=True, max_stale_s=None)
    labelled.set_mode(DEST_RELATED, "error")
    for i in range(5):
        labelled.arrive(DEST_RELATED, at=round(i * 0.10, 2))
    # Circuit is open after the 5th failure at 0.40. A user-facing call at 0.80.
    user = labelled.arrive(DEST_RELATED, at=0.80)
    labelled.drain()
    # Policy B: product tolerance max_stale_s=0.50 — at t=0.80 the cache (as_of=0 initially,
    # never refreshed because all calls failed) is 0.80 old, so unavailable.
    strict = CircuitIsolateEngine(use_circuit=True, max_stale_s=0.50)
    strict.set_mode(DEST_RELATED, "error")
    for i in range(5):
        strict.arrive(DEST_RELATED, at=round(i * 0.10, 2))
    user_strict = strict.arrive(DEST_RELATED, at=0.80)
    strict.drain()
    # Also a live title call so the combined page can show fresh title + stale related.
    page = CircuitIsolateEngine(use_circuit=True, max_stale_s=None)
    page.set_mode(DEST_RELATED, "error")
    for i in range(5):
        page.arrive(DEST_RELATED, at=round(i * 0.10, 2))
    title_rec = page.arrive(DEST_TITLE, at=0.80)
    related_rec = page.arrive(DEST_RELATED, at=0.80)
    page.drain()
    return {
        "labelled": user.as_dict(),
        "labelled_is_stale": user.degraded and user.freshness == "stale" and user.value == RELATED_V1,
        "labelled_age": None if user.cache_age_s is None else ts_safe(user.cache_age_s),
        "strict": user_strict.as_dict(),
        "strict_unavailable": user_strict.freshness == "unavailable" and user_strict.value is None,
        "user_can_tell_freshness": user.freshness == "stale" and user_strict.freshness == "unavailable",
        "page_title": title_rec.as_dict(),
        "page_related": related_rec.as_dict(),
        "page_title_fresh_related_stale": title_rec.status == "ok"
        and title_rec.freshness == "fresh"
        and title_rec.value == TITLE_V1
        and related_rec.freshness == "stale"
        and related_rec.degraded,
        "product_must_state_tolerance": user.freshness == "stale" and user_strict.freshness == "unavailable",
        "t_end_labelled": labelled.now(),
        "t_end_strict": strict.now(),
    }


def run_retry_pitfall() -> dict[str, Any]:
    """Retrying every error amplifies traffic; a breaker stops the stampede."""
    attempts = 10
    logical = 10
    # Naive: no circuit, retry every error up to 10 attempts, retry_on_overload True.
    naive = CircuitIsolateEngine(use_circuit=False, max_retries=attempts, retry_on_overload=True, deadline_s=DEADLINE_S)
    naive.set_mode(DEST_RELATED, "error")
    naive_recs = []
    t = 0.0
    for _ in range(logical):
        naive_recs.extend(naive.retrying_arrive(DEST_RELATED, at=t, max_attempts=attempts))
        t = round(naive.clock.now() + 0.01, 2)
    naive.drain()
    # Protected: circuit on, do not retry circuit_open / budget exhausted.
    protected = CircuitIsolateEngine(use_circuit=True, retry_on_overload=False, deadline_s=DEADLINE_S)
    protected.set_mode(DEST_RELATED, "error")
    prot_recs = []
    t = 0.0
    for _ in range(logical):
        prot_recs.extend(protected.retrying_arrive(DEST_RELATED, at=t, max_attempts=attempts))
        t = round(protected.clock.now() + 0.01, 2)
    protected.drain()
    n_calls = naive.downstreams[DEST_RELATED].calls
    p_calls = protected.downstreams[DEST_RELATED].calls
    return {
        "logical_requests": logical,
        "max_attempts": attempts,
        "naive_downstream_calls": n_calls,
        "protected_downstream_calls": p_calls,
        "naive_records": len(naive_recs),
        "protected_records": len(prot_recs),
        "naive_amplifies": n_calls == logical * attempts,
        "protected_stops": p_calls < n_calls and p_calls <= 5 + HALF_OPEN_MAX_PROBES,
        "pitfall_blind_retry_amplifies_traffic": n_calls > p_calls and n_calls == 100,
        "t_end_naive": naive.now(),
        "t_end_protected": protected.now(),
        "protected_stats": protected.stats(DEST_RELATED),
        "naive_stats": naive.stats(DEST_RELATED),
    }


def run() -> dict[str, Any]:
    window = run_error_window_and_half_open()
    recovery = run_half_open_recovery()
    iso = run_bulkhead_isolation()
    deg = run_degradation_freshness()
    pit = run_retry_pitfall()
    return {
        "engine": "CircuitIsolateEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_a_real_gateway": True,
        "not_hystrix": True,
        "not_resilience4j": True,
        "not_envoy": True,
        "not_google_sre_production": True,
        "key": KEY_TITLE,
        "title": TITLE_V1,
        "related": RELATED_V1,
        "service_time_s": SERVICE_TIME_S,
        "error_window_half_open": window,
        "half_open_recovery": recovery,
        "bulkhead": iso,
        "degradation_freshness": deg,
        "retry_pitfall": pit,
        "acceptance_half_open_probes_bounded": window["probes_bounded"]
        and window["max_probes_in_one_half_open"] == HALF_OPEN_MAX_PROBES
        and window["downstream_calls_are_window_plus_probes"],
        "acceptance_user_can_tell_freshness": deg["user_can_tell_freshness"]
        and deg["page_title_fresh_related_stale"],
        "practice_isolated_title_survives_slow_related": iso["practice_isolated_title_survives_slow_related"],
        "pitfall_blind_retry_amplifies_traffic": pit["pitfall_blind_retry_amplifies_traffic"],
        "tradeoff_degradation_needs_product_tolerance": deg["product_must_state_tolerance"],
    }


if __name__ == "__main__":
    import json
    from pathlib import Path
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("wrote results.json")
    for k in r:
        if isinstance(r[k], bool) or (isinstance(k, str) and k.startswith(("acceptance", "practice", "pitfall", "tradeoff"))):
            print(k, r[k])
