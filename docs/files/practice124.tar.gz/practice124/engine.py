#!/usr/bin/env python3
"""Teaching CircuitIsolateEngine — not Redis, not a real circuit breaker, not a network service.

A Python 3 standard-library model of a frontend that talks to two
downstream dependencies (title and related), each with a teaching
connection/thread pool, an optional circuit breaker, and a stale-cache
degradation path. It is used to observe error-window trips and bounded
half-open probes, bulkhead isolation when one dependency is slow, the
freshness of a degraded result, and how blind retries amplify load.

Ideas such as fail-fast when a backend is unavailable, graceful
degradation to cheaper or lower-quality results, not retrying every
error, testing non-critical backends that blackhole, and not letting
shared thread pools spread saturation follow Google SRE Chapter 22,
Addressing Cascading Failures (checked on 2026-11-14). This engine is
not Google's production stack, not Hystrix, not Resilience4j, not
Envoy, and not a real gateway. The chapter does not define the words
"circuit breaker", "half-open", "error window", or "bulkhead"; those
are teaching names for the closed/open/half-open admission pattern and
for per-dependency pools. There is no TCP, no real sockets, no ISR,
and no Borg/GSLB. Pools are in-process slot counters. Persistence is a
teaching dict flush, not a disk or fsync. Clock is virtual.
service_time_s, deadlines, and open_duration_s are teaching delays, not
production RTT.
"""
from __future__ import annotations

import heapq
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
RELATED_V1 = "Editor picks"
KEY_TITLE = "article:01:title"
DEST_TITLE = "title"
DEST_RELATED = "related"
SERVICE_TIME_S = 0.10
SLOW_TIME_S = 1.00
DEADLINE_S = 0.50
POOL_SIZE = 2
SHARED_POOL_SIZE = 4
WINDOW_SIZE = 5
FAIL_THRESHOLD = 5
OPEN_DURATION_S = 0.50
HALF_OPEN_MAX_PROBES = 2


def ts(t: float) -> float:
    return round(float(t) + 1e-12, 2)


class Clock:
    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class CachedValue:
    value: str
    as_of: float


@dataclass(order=True)
class Completion:
    finish_t: float
    seq: int
    token: int = field(compare=False)


@dataclass
class CallRecord:
    call_id: int
    dest: str
    arrive_t: float
    start_t: Optional[float] = None
    finish_t: Optional[float] = None
    status: str = "pending"  # ok, degraded, rejected, timeout, error
    reason: Optional[str] = None
    probed: bool = False
    downstream_called: bool = False
    retries: int = 0
    value: Optional[str] = None
    freshness: Optional[str] = None  # fresh, stale, unavailable
    cache_age_s: Optional[float] = None
    cached_at: Optional[float] = None
    degraded: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "call_id": self.call_id,
            "dest": self.dest,
            "arrive_t": ts(self.arrive_t),
            "start_t": None if self.start_t is None else ts(self.start_t),
            "finish_t": None if self.finish_t is None else ts(self.finish_t),
            "latency": None if self.finish_t is None else ts(self.finish_t - self.arrive_t),
            "status": self.status,
            "reason": self.reason,
            "probed": self.probed,
            "downstream_called": self.downstream_called,
            "retries": self.retries,
            "value": self.value,
            "freshness": self.freshness,
            "cache_age_s": None if self.cache_age_s is None else ts(self.cache_age_s),
            "cached_at": None if self.cached_at is None else ts(self.cached_at),
            "degraded": self.degraded,
        }


class Pool:
    """Teaching connection/thread pool: a slot counter, not a socket pool."""

    def __init__(self, name: str, size: int) -> None:
        self.name = name
        self.size = int(size)
        self.inflight = 0
        self.max_inflight = 0
        self.waiters: deque[int] = deque()  # call tokens waiting for a slot

    def has_slot(self) -> bool:
        return self.inflight < self.size

    def acquire(self) -> bool:
        if self.inflight < self.size:
            self.inflight += 1
            if self.inflight > self.max_inflight:
                self.max_inflight = self.inflight
            return True
        return False

    def release(self) -> None:
        if self.inflight > 0:
            self.inflight -= 1

    def snapshot(self) -> dict[str, Any]:
        return {"name": self.name, "size": self.size, "inflight": self.inflight, "max_inflight": self.max_inflight, "waiters": len(self.waiters)}


class CircuitBreaker:
    """Teaching closed / open / half-open breaker. Not Hystrix or Envoy."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

    def __init__(
        self,
        *,
        window_size: int = WINDOW_SIZE,
        fail_threshold: int = FAIL_THRESHOLD,
        open_duration_s: float = OPEN_DURATION_S,
        half_open_max_probes: int = HALF_OPEN_MAX_PROBES,
        clock: Clock,
    ) -> None:
        self.window_size = int(window_size)
        self.fail_threshold = int(fail_threshold)
        self.open_duration_s = float(open_duration_s)
        self.half_open_max_probes = int(half_open_max_probes)
        self.clock = clock
        self.state = self.CLOSED
        self.window: deque[bool] = deque()  # True = failure
        self.open_until: Optional[float] = None
        self.probes_used = 0
        self.probes_succeeded = 0
        self.trips = 0
        self.half_open_entries = 0
        self.max_probes_in_one_half_open = 0
        self.history: list[dict[str, Any]] = []

    def _record_state(self, action: str) -> None:
        self.history.append({"t": ts(self.clock.now()), "action": action, "state": self.state, "probes_used": self.probes_used})

    def maybe_enter_half_open(self) -> None:
        if self.state == self.OPEN and self.open_until is not None and self.clock.now() + 1e-12 >= self.open_until:
            self.state = self.HALF_OPEN
            self.probes_used = 0
            self.probes_succeeded = 0
            self.half_open_entries += 1
            self._record_state("enter_half_open")

    def allow(self) -> tuple[bool, str, bool]:
        """Return (allowed_to_call_downstream, reason, is_probe)."""
        self.maybe_enter_half_open()
        if self.state == self.CLOSED:
            return True, "closed", False
        if self.state == self.OPEN:
            return False, "circuit_open", False
        # half-open
        if self.probes_used < self.half_open_max_probes:
            self.probes_used += 1
            if self.probes_used > self.max_probes_in_one_half_open:
                self.max_probes_in_one_half_open = self.probes_used
            return True, "half_open_probe", True
        return False, "half_open_budget_exhausted", False

    def observe(self, failed: bool) -> None:
        self.maybe_enter_half_open()
        if self.state == self.HALF_OPEN:
            if failed:
                self._trip("half_open_probe_failed")
            else:
                self.probes_succeeded += 1
                # Close once any probe succeeds and no remaining in-flight
                # requirement: all probes used so far that have reported, succeeded.
                # We close on the first success if we don't require all probes.
                # Teaching rule: if half_open_max_probes probes were allowed,
                # close after one success (dependency is back).
                self.state = self.CLOSED
                self.window.clear()
                self.open_until = None
                self._record_state("close_after_probe_success")
            return
        self.window.append(bool(failed))
        while len(self.window) > self.window_size:
            self.window.popleft()
        if self.state == self.CLOSED:
            failures = sum(1 for x in self.window if x)
            if failures >= self.fail_threshold and len(self.window) >= self.fail_threshold:
                self._trip("error_window")

    def _trip(self, why: str) -> None:
        self.state = self.OPEN
        self.open_until = self.clock.now() + self.open_duration_s
        self.trips += 1
        self.probes_used = 0
        self.probes_succeeded = 0
        self.window.clear()
        self._record_state(f"open:{why}")

    def snapshot(self) -> dict[str, Any]:
        self.maybe_enter_half_open()
        return {
            "state": self.state,
            "window_failures": sum(1 for x in self.window if x),
            "window_len": len(self.window),
            "open_until": None if self.open_until is None else ts(self.open_until),
            "probes_used": self.probes_used,
            "trips": self.trips,
            "half_open_entries": self.half_open_entries,
            "max_probes_in_one_half_open": self.max_probes_in_one_half_open,
            "half_open_max_probes": self.half_open_max_probes,
        }


class Downstream:
    def __init__(self, name: str, pool: Pool, service_time_s: float) -> None:
        self.name = name
        self.pool = pool
        self.service_time_s = float(service_time_s)
        self.mode = "ok"  # ok, error, slow, blackhole
        self.slow_time_s = SLOW_TIME_S
        self.calls = 0
        self.successes = 0
        self.failures = 0

    def handle_duration(self) -> Optional[float]:
        """How long a call occupies a slot. None means blackhole (never completes)."""
        if self.mode == "blackhole":
            return None
        if self.mode == "slow":
            return self.slow_time_s
        if self.mode == "error":
            # Still occupies a slot for the usual service time, then returns an error.
            # Zero-duration errors would complete in the same instant as a second
            # half-open probe, making the probe budget hard to observe.
            return self.service_time_s
        return self.service_time_s

    def outcome(self) -> str:
        if self.mode in {"error", "blackhole"}:
            return "error"
        if self.mode == "slow":
            return "ok"  # eventually succeeds if the caller waits long enough
        return "ok"


class CircuitIsolateEngine:
    def __init__(
        self,
        *,
        service_time_s: float = SERVICE_TIME_S,
        deadline_s: float = DEADLINE_S,
        pool_size: int = POOL_SIZE,
        shared_pool: bool = False,
        shared_pool_size: int = SHARED_POOL_SIZE,
        use_circuit: bool = True,
        window_size: int = WINDOW_SIZE,
        fail_threshold: int = FAIL_THRESHOLD,
        open_duration_s: float = OPEN_DURATION_S,
        half_open_max_probes: int = HALF_OPEN_MAX_PROBES,
        max_retries: int = 0,
        retry_on_overload: bool = False,
        max_stale_s: Optional[float] = None,
        title: str = TITLE_V1,
        related: str = RELATED_V1,
    ) -> None:
        self.clock = Clock()
        self.service_time_s = float(service_time_s)
        self.deadline_s = float(deadline_s)
        self.shared_pool = bool(shared_pool)
        self.use_circuit = bool(use_circuit)
        self.max_retries = int(max_retries)
        self.retry_on_overload = bool(retry_on_overload)
        self.max_stale_s = max_stale_s

        if shared_pool:
            shared = Pool("shared", shared_pool_size)
            self.pools = {DEST_TITLE: shared, DEST_RELATED: shared}
        else:
            self.pools = {
                DEST_TITLE: Pool(DEST_TITLE, pool_size),
                DEST_RELATED: Pool(DEST_RELATED, pool_size),
            }

        self.downstreams = {
            DEST_TITLE: Downstream(DEST_TITLE, self.pools[DEST_TITLE], service_time_s),
            DEST_RELATED: Downstream(DEST_RELATED, self.pools[DEST_RELATED], service_time_s),
        }
        self.circuits: dict[str, Optional[CircuitBreaker]] = {}
        for name in (DEST_TITLE, DEST_RELATED):
            self.circuits[name] = (
                CircuitBreaker(
                    window_size=window_size,
                    fail_threshold=fail_threshold,
                    open_duration_s=open_duration_s,
                    half_open_max_probes=half_open_max_probes,
                    clock=self.clock,
                )
                if use_circuit
                else None
            )

        self.live = {DEST_TITLE: title, DEST_RELATED: related}
        self.cache: dict[str, CachedValue] = {
            DEST_TITLE: CachedValue(title, 0.0),
            DEST_RELATED: CachedValue(related, 0.0),
        }
        self.records: list[CallRecord] = []
        self.completions: list[Completion] = []
        self.in_flight: dict[int, CallRecord] = {}
        self._seq = 0
        self._call_seq = 0
        self.flush_count = 0
        self.events: list[dict[str, Any]] = []
        self._event("init", shared_pool=shared_pool, use_circuit=use_circuit, deadline_s=deadline_s)

    def now(self) -> float:
        return ts(self.clock.now())

    def _event(self, name: str, **kw: Any) -> dict[str, Any]:
        ev = {"t": self.now(), "event": name, **kw}
        self.events.append(ev)
        return ev

    def set_mode(self, dest: str, mode: str) -> None:
        self.downstreams[dest].mode = mode
        self._event("set_mode", dest=dest, mode=mode)

    def _flush(self, reason: str) -> None:
        self.flush_count += 1
        self._event("persist_flushed", reason=reason, flush_count=self.flush_count)

    def _finish_record(self, rec: CallRecord, status: str, reason: Optional[str], *, from_cache: bool = False) -> None:
        rec.finish_t = self.clock.now()
        rec.status = status
        rec.reason = reason
        if from_cache:
            cached = self.cache.get(rec.dest)
            age = self.clock.now() - cached.as_of if cached else None
            if cached is None:
                rec.degraded = True
                rec.freshness = "unavailable"
                rec.value = None
            elif self.max_stale_s is not None and age is not None and age > self.max_stale_s + 1e-12:
                rec.degraded = True
                rec.freshness = "unavailable"
                rec.cache_age_s = age
                rec.cached_at = cached.as_of
                rec.value = None
                rec.reason = (reason + ":stale_exceeds_tolerance") if reason else "stale_exceeds_tolerance"
            else:
                rec.degraded = True
                rec.freshness = "stale"
                rec.cache_age_s = age
                rec.cached_at = cached.as_of
                rec.value = cached.value
        self._event("finished", **{k: rec.as_dict()[k] for k in ("call_id", "dest", "status", "reason", "freshness", "degraded")})

    def _deliver_success(self, rec: CallRecord) -> None:
        rec.downstream_called = True
        value = self.live[rec.dest]
        rec.value = value
        rec.freshness = "fresh"
        rec.degraded = False
        rec.cache_age_s = 0.0
        rec.cached_at = self.clock.now()
        self.cache[rec.dest] = CachedValue(value, self.clock.now())
        self._flush(f"cache_{rec.dest}")
        rec.finish_t = self.clock.now()
        rec.status = "ok"
        rec.reason = None
        self.downstreams[rec.dest].successes += 1
        cb = self.circuits[rec.dest]
        if cb:
            cb.observe(False)

    def _deliver_failure(self, rec: CallRecord, reason: str) -> None:
        rec.finish_t = self.clock.now()
        self.downstreams[rec.dest].failures += 1
        cb = self.circuits[rec.dest]
        if cb:
            cb.observe(True)
        # Prefer a stale (labelled) result over a bare error for the caller.
        self._finish_record(rec, "degraded" if self.cache.get(rec.dest) else "error", reason, from_cache=True)

    def _release_and_promote(self, dest: str) -> None:
        pool = self.pools[dest]
        pool.release()
        # Promote a waiter for this same pool, if any.
        while pool.waiters and pool.has_slot():
            token = pool.waiters.popleft()
            waited = self.in_flight.get(token)
            if waited is None:
                continue
            # Deadline checked against original arrival.
            if self.clock.now() - waited.arrive_t > self.deadline_s + 1e-12:
                self._finish_record(waited, "timeout", "deadline_while_waiting", from_cache=True)
                self.in_flight.pop(token, None)
                continue
            if not pool.acquire():
                pool.waiters.appendleft(token)
                break
            self._dispatch(waited)
            break

    def _dispatch(self, rec: CallRecord) -> None:
        dest = rec.dest
        down = self.downstreams[dest]
        rec.start_t = self.clock.now()
        rec.downstream_called = True
        down.calls += 1
        duration = down.handle_duration()
        if duration is None:
            # Blackhole: occupies the slot until the caller's deadline.
            finish = rec.arrive_t + self.deadline_s
            rec.reason = "blackhole"
            self._seq += 1
            heapq.heappush(self.completions, Completion(finish, self._seq, rec.call_id))
            self._event("dispatched_blackhole", call_id=rec.call_id, dest=dest, finish_t=ts(finish))
            return
        outcome = down.outcome()
        finish = rec.start_t + duration
        # If the work would finish after the caller's deadline, the caller gives up at the deadline.
        deadline_at = rec.arrive_t + self.deadline_s
        rec._pending_outcome = outcome  # type: ignore[attr-defined]
        rec._work_finish = finish  # type: ignore[attr-defined]
        fire_at = min(finish, deadline_at)
        self._seq += 1
        heapq.heappush(self.completions, Completion(fire_at, self._seq, rec.call_id))
        self._event("dispatched", call_id=rec.call_id, dest=dest, finish_t=ts(fire_at), outcome=outcome)

    def _complete_one(self, item: Completion) -> None:
        rec = self.in_flight.pop(item.token, None)
        if rec is None:
            return
        self.clock.wait_until(item.finish_t)
        dest = rec.dest
        if rec.reason == "blackhole" or item.finish_t + 1e-12 >= rec.arrive_t + self.deadline_s and getattr(rec, "_work_finish", item.finish_t) > rec.arrive_t + self.deadline_s + 1e-12:
            # Timed out waiting for a slow or blackholed backend.
            self.downstreams[dest].failures += 1
            cb = self.circuits[dest]
            if cb:
                cb.observe(True)
            self._finish_record(rec, "timeout", rec.reason or "deadline", from_cache=True)
            self._maybe_retry(rec)
            self._release_and_promote(dest)
            return
        outcome = getattr(rec, "_pending_outcome", "ok")
        if outcome == "ok":
            self._deliver_success(rec)
        else:
            self._deliver_failure(rec, "downstream_error")
            self._maybe_retry(rec)
        self._release_and_promote(dest)

    def _maybe_retry(self, rec: CallRecord) -> None:
        # Retries are modelled as additional arrivals at the current time.
        # They are not automatic unless max_retries > 0 and the policy allows it.
        pass  # handled at arrive() layer for simplicity

    def advance(self, t: float) -> None:
        while self.completions and self.completions[0].finish_t <= t + 1e-12:
            item = heapq.heappop(self.completions)
            self._complete_one(item)
        if t > self.clock.now():
            self.clock.wait_until(t)
            for cb in self.circuits.values():
                if cb:
                    cb.maybe_enter_half_open()

    def drain(self) -> None:
        while self.completions:
            item = heapq.heappop(self.completions)
            self._complete_one(item)

    def arrive(self, dest: str, at: Optional[float] = None) -> CallRecord:
        if at is not None:
            self.advance(at)
        self._call_seq += 1
        rec = CallRecord(self._call_seq, dest, self.clock.now())
        self.records.append(rec)
        self.in_flight[rec.call_id] = rec

        # Circuit admission.
        cb = self.circuits[dest]
        if cb:
            allowed, reason, is_probe = cb.allow()
            rec.probed = is_probe
            if not allowed:
                self.in_flight.pop(rec.call_id, None)
                self._finish_record(rec, "degraded", reason, from_cache=True)
                self._event("short_circuit", call_id=rec.call_id, dest=dest, reason=reason)
                return rec

        pool = self.pools[dest]
        if pool.acquire():
            self._dispatch(rec)
            return rec
        # Wait for a slot, or fail if we refuse to queue behind a full pool.
        # Teaching default: waiters are allowed, but deadline still applies.
        pool.waiters.append(rec.call_id)
        self._event("queued", call_id=rec.call_id, dest=dest, pool=pool.name, inflight=pool.inflight)
        return rec

    def run_arrivals(self, arrivals: list[tuple[float, str]]) -> None:
        for t, dest in sorted(arrivals, key=lambda x: (x[0], x[1])):
            self.arrive(dest, at=t)
        self.drain()

    def retrying_arrive(self, dest: str, at: float, *, max_attempts: int) -> list[CallRecord]:
        """Issue one logical request, retrying failures up to max_attempts total tries.

        Each retry is a new downstream attempt at the current clock (no delay),
        unless the previous attempt is still in flight. Used for the pitfall
        experiment. When retry_on_overload is False, circuit_open /
        half_open_budget_exhausted / deadline failures stop the loop.
        """
        attempts: list[CallRecord] = []
        t = at
        for i in range(max_attempts):
            rec = self.arrive(dest, at=t)
            attempts.append(rec)
            rec.retries = i
            # Wait only until this attempt finishes, not until the full deadline
            # (that would jump the clock into the next half-open window).
            while rec.status == "pending" and self.completions:
                self.advance(self.completions[0].finish_t)
            t = self.clock.now()
            if rec.status == "ok":
                break
            if not self.retry_on_overload and rec.reason in {
                "circuit_open",
                "half_open_budget_exhausted",
                "deadline",
                "deadline_while_waiting",
            }:
                break
            # else retry immediately at current t
        return attempts

    def stats(self, dest: Optional[str] = None) -> dict[str, Any]:
        recs = [r for r in self.records if dest is None or r.dest == dest]
        ok = [r for r in recs if r.status == "ok"]
        degraded = [r for r in recs if r.status == "degraded"]
        timeout = [r for r in recs if r.status == "timeout"]
        lats = [r.finish_t - r.arrive_t for r in recs if r.finish_t is not None]
        ok_lats = [r.finish_t - r.arrive_t for r in ok if r.finish_t is not None]
        freshness = {}
        for r in recs:
            key = r.freshness or r.status
            freshness[key] = freshness.get(key, 0) + 1
        reasons: dict[str, int] = {}
        for r in recs:
            if r.reason:
                reasons[r.reason] = reasons.get(r.reason, 0) + 1
        probes = sum(1 for r in recs if r.probed)
        downstream_called = sum(1 for r in recs if r.downstream_called)
        out: dict[str, Any] = {
            "n": len(recs),
            "ok": len(ok),
            "degraded": len(degraded),
            "timeout": len(timeout),
            "freshness": freshness,
            "reasons": reasons,
            "probes": probes,
            "downstream_called": downstream_called,
            "latency_max": None if not lats else ts(max(lats)),
            "ok_latency_max": None if not ok_lats else ts(max(ok_lats)),
            "ok_latency_min": None if not ok_lats else ts(min(ok_lats)),
            "t_end": self.now(),
        }
        if dest:
            down = self.downstreams[dest]
            out["downstream_calls"] = down.calls
            out["downstream_successes"] = down.successes
            out["downstream_failures"] = down.failures
            pool = self.pools[dest]
            out["pool_max_inflight"] = pool.max_inflight
            out["pool_size"] = pool.size
            out["pool_name"] = pool.name
            cb = self.circuits[dest]
            if cb:
                out["circuit"] = cb.snapshot()
        else:
            out["title"] = self.stats(DEST_TITLE)
            out["related"] = self.stats(DEST_RELATED)
            out["flush_count"] = self.flush_count
        return out

    def snapshot(self) -> dict[str, Any]:
        return {
            "t": self.now(),
            "pools": {name: pool.snapshot() for name, pool in ({p.name: p for p in self.pools.values()}).items()},
            "circuits": {n: (None if c is None else c.snapshot()) for n, c in self.circuits.items()},
            "cache": {n: {"value": c.value, "as_of": ts(c.as_of)} for n, c in self.cache.items()},
        }
