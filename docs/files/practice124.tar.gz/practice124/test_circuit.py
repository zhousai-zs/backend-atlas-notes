#!/usr/bin/env python3
"""Acceptance checks for the lesson 124 circuit / isolation experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import (
    DEADLINE_S,
    HALF_OPEN_MAX_PROBES,
    KEY_TITLE,
    RELATED_V1,
    SERVICE_TIME_S,
    TITLE_V1,
)


def main() -> None:
    r = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    assert r["engine"] == "CircuitIsolateEngine"
    assert r["not_redis"] and r["not_a_network_service"] and r["not_a_real_gateway"]
    assert r["not_hystrix"] and r["not_resilience4j"] and r["not_envoy"]
    assert r["not_google_sre_production"]
    assert r["key"] == KEY_TITLE and r["title"] == TITLE_V1 and r["related"] == RELATED_V1
    assert r["service_time_s"] == SERVICE_TIME_S == 0.10

    w = r["error_window_half_open"]
    assert w["opened_state_after_five"] == "open" and w["trips_after_five"] == 1
    assert w["opened_at"] == 0.5 and w["open_until"] == 1.0
    assert w["calls_when_opened"] == 5 and w["no_calls_while_open"]
    assert w["fail_fast_n"] == 8 and w["fail_fast_reasons"] == ["circuit_open"]
    assert w["half_open_at"] == 1.0
    assert w["half_open_probes"] == HALF_OPEN_MAX_PROBES == 2
    assert w["half_open_blocked"] == 4
    assert w["probes_bounded"]
    assert w["max_probes_in_one_half_open"] == 2
    assert w["downstream_calls_total"] == 7
    assert w["downstream_calls_are_window_plus_probes"]
    assert w["state_after"] == "open" and w["trips_after"] == 2

    rec = r["half_open_recovery"]
    assert rec["probe_succeeded"] and rec["state_after_probe"] == "closed"
    assert rec["later_ok_not_probe"] and rec["closed_after_successful_probe"]
    assert rec["probe"]["value"] == RELATED_V1 and rec["later"]["status"] == "ok"
    assert rec["t_end"] == 1.2

    iso = r["bulkhead"]
    assert iso["deadline_s"] == DEADLINE_S == 0.50
    assert iso["slow_time_s"] == 1.00
    assert iso["shared_title_ok"] == 9 and iso["shared_title_timeout"] == 1
    assert iso["shared_title_latency_max"] == 0.50
    assert iso["isolated_title_ok"] == 10 and iso["isolated_title_timeout"] == 0
    assert iso["isolated_title_ok_latency_max"] == 0.10
    assert iso["isolated_title_untouched"]
    assert iso["shared_related_pool_max"] == 4 and iso["isolated_related_pool_max"] == 2
    assert iso["same_physical_pool_when_shared"] and iso["different_pools_when_isolated"]
    assert iso["practice_isolated_title_survives_slow_related"]

    deg = r["degradation_freshness"]
    assert deg["labelled_is_stale"] and deg["labelled_age"] == 0.80
    assert deg["labelled"]["value"] == RELATED_V1 and deg["labelled"]["freshness"] == "stale"
    assert deg["strict_unavailable"] and deg["strict"]["value"] is None
    assert deg["strict"]["freshness"] == "unavailable"
    assert deg["page_title_fresh_related_stale"]
    assert deg["page_title"]["value"] == TITLE_V1 and deg["page_title"]["freshness"] == "fresh"
    assert deg["user_can_tell_freshness"] and deg["product_must_state_tolerance"]

    pit = r["retry_pitfall"]
    assert pit["naive_downstream_calls"] == 100 and pit["protected_downstream_calls"] == 5
    assert pit["naive_amplifies"] and pit["protected_stops"]
    assert pit["pitfall_blind_retry_amplifies_traffic"]
    assert pit["t_end_naive"] == 10.09 and pit["t_end_protected"] == 0.59

    assert r["acceptance_half_open_probes_bounded"]
    assert r["acceptance_user_can_tell_freshness"]
    assert r["practice_isolated_title_survives_slow_related"]
    assert r["pitfall_blind_retry_amplifies_traffic"]
    assert r["tradeoff_degradation_needs_product_tolerance"]
    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
