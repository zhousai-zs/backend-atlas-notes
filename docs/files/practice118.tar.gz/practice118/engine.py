#!/usr/bin/env python3
"""Teaching RaftLogEngine — not Redis, not a network service, not a full Raft.

A Python 3 standard-library model of Raft log replication: the
prevLogIndex / prevLogTerm consistency check, nextIndex / matchIndex,
commitIndex, conflict truncation, and the current-term commit
restriction. Servers talk over an in-process mailbox driven by a
virtual clock.

This is not Redis, not redis-py, and not a network server. There is no
TCP and no real message loss. It is not a complete Raft, Paxos, or
Jepsen implementation: there is no snapshot transfer (§7) and no
membership change (§6). pause() is an omniscient freeze; isolate() is
an omniscient partition; a real asynchronous network has no such
signal. Persistent state is a teaching dict flushed before RPC
replies, not a disk or fsync. Clock is a virtual clock. Election
timeouts are fixed per server so timelines are repeatable; the paper
resamples from an interval such as 150–300 ms. The leader tracks
nextIndex and matchIndex and does not peek at another server's log
when deciding to commit. A follower that passes the consistency check
sets commitIndex = min(leaderCommit, last log index), including on a
heartbeat with no new entries; Figure 2's wording is "index of last
new entry", but §5.3 says the leader carries commitIndex in
heartbeats so other servers eventually learn it. There is at most one
in-flight AppendEntries per follower (no pipelining). Definitions
follow Ongaro & Ousterhout, "In Search of an Understandable Consensus
Algorithm (Extended Version)", checked on 2026-11-13.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from random import Random
from typing import Any, Optional


TITLE_V1 = "Weekly digest"
TITLE_DRAFT = "Weekly digest (draft)"
TITLE_V2 = "Weekly digest (revised)"
KEY_TITLE = "article:01:title"
LOCAL_STEP_S = 0.01
RPC_DELAY_S = 0.01
ENTRY_DELAY_S = 0.0
HEARTBEAT_INTERVAL_S = 0.05
ELECTION_TIMEOUT_MIN_S = 0.15
ELECTION_TIMEOUT_MAX_S = 0.30


def ts(t: float) -> float:
    """Round a virtual-clock time to two decimals for stable records."""
    return round(float(t) + 1e-12, 2)


class Clock:
    """A virtual clock tests can freeze and advance. Not a wall clock."""

    def __init__(self, start: float = 0.0) -> None:
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def wait_until(self, t: float) -> None:
        if t > self.t:
            self.t = round(float(t), 10)


@dataclass
class LogEntry:
    index: int
    term: int
    command: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {"index": self.index, "term": self.term, "command": dict(self.command)}

    def short(self) -> dict[str, Any]:
        cmd = self.command
        value = cmd.get("value")
        return {"index": self.index, "term": self.term, "value": value}


@dataclass
class Persist:
    """Persistent state. Must be copied before an RPC reply is sent."""

    current_term: int = 0
    voted_for: Optional[str] = None
    log: list[LogEntry] = field(default_factory=list)

    def clone(self) -> "Persist":
        return Persist(
            current_term=self.current_term,
            voted_for=self.voted_for,
            log=[LogEntry(e.index, e.term, dict(e.command)) for e in self.log],
        )


@dataclass
class Message:
    src: str
    dst: str
    typ: str
    body: dict[str, Any]
    send_at: float
    deliver_at: float
    dropped: bool = False


class Server:
    """One Raft server in the teaching cluster."""

    def __init__(
        self,
        server_id: str,
        cluster: "RaftLogEngine",
        election_timeout_s: float,
        persist_votes: bool = True,
    ) -> None:
        self.server_id = server_id
        self.cluster = cluster
        self.election_timeout_s = float(election_timeout_s)
        self.persist_votes = persist_votes
        self.persist = Persist()
        self.durable: Optional[Persist] = None
        self.flush_persist()
        self.state = "follower"
        self.commit_index = 0
        self.last_applied = 0
        self.votes_got: set[str] = set()
        self.leader_id: Optional[str] = None
        self.election_deadline = 0.0
        self.heartbeat_deadline = 0.0
        self.paused = False
        self.crashed = False
        self.kv: dict[str, str] = {}
        self.next_index: dict[str, int] = {}
        self.match_index: dict[str, int] = {}
        self.inflight: set[str] = set()
        self.reset_election_timer()

    def flush_persist(self) -> None:
        self.durable = self.persist.clone()

    def load_persist(self) -> None:
        assert self.durable is not None
        self.persist = self.durable.clone()

    def last_log_index(self) -> int:
        return self.persist.log[-1].index if self.persist.log else 0

    def last_log_term(self) -> int:
        return self.persist.log[-1].term if self.persist.log else 0

    def entry_at(self, index: int) -> Optional[LogEntry]:
        if index <= 0:
            return None
        for e in self.persist.log:
            if e.index == index:
                return e
        return None

    def term_at(self, index: int) -> int:
        if index <= 0:
            return 0
        e = self.entry_at(index)
        return e.term if e is not None else -1

    def log_is_up_to_date(self, cand_last_term: int, cand_last_index: int) -> bool:
        """True if the candidate's log is at least as up-to-date as ours (§5.4.1)."""
        my_term = self.last_log_term()
        my_index = self.last_log_index()
        if cand_last_term != my_term:
            return cand_last_term > my_term
        return cand_last_index >= my_index

    def reset_election_timer(self) -> None:
        self.election_deadline = ts(self.cluster.clock.now() + self.election_timeout_s)

    def snapshot(self) -> dict[str, Any]:
        return {
            "id": self.server_id,
            "state": self.state,
            "current_term": self.persist.current_term,
            "voted_for": self.persist.voted_for,
            "commit_index": self.commit_index,
            "last_applied": self.last_applied,
            "last_log_index": self.last_log_index(),
            "last_log_term": self.last_log_term(),
            "leader_id": self.leader_id,
            "paused": self.paused,
            "crashed": self.crashed,
            "title": self.kv.get(KEY_TITLE),
            "log": [e.short() for e in self.persist.log],
            "next_index": dict(self.next_index),
            "match_index": dict(self.match_index),
        }

    def maybe_step_down(self, term: int) -> None:
        if term > self.persist.current_term:
            self.persist.current_term = term
            self.persist.voted_for = None
            self.flush_persist()
            self.become_follower(leader_id=None)

    def become_follower(self, leader_id: Optional[str]) -> None:
        prev = self.state
        self.state = "follower"
        self.leader_id = leader_id
        self.votes_got.clear()
        self.next_index.clear()
        self.match_index.clear()
        self.inflight.clear()
        if prev != "follower" or leader_id is not None:
            self.cluster.log_event(
                self.server_id,
                "become_follower",
                term=self.persist.current_term,
                leader_id=leader_id,
                from_state=prev,
            )

    def start_election(self) -> None:
        self.state = "candidate"
        self.leader_id = None
        self.persist.current_term += 1
        self.persist.voted_for = self.server_id
        self.flush_persist()
        self.votes_got = {self.server_id}
        self.reset_election_timer()
        self.cluster.log_event(
            self.server_id,
            "become_candidate",
            term=self.persist.current_term,
            last_log_index=self.last_log_index(),
            last_log_term=self.last_log_term(),
            election_timeout_s=self.election_timeout_s,
        )
        for other in self.cluster.peer_ids(self.server_id):
            self.cluster.send(
                self.server_id,
                other,
                "RequestVote",
                {
                    "term": self.persist.current_term,
                    "candidate_id": self.server_id,
                    "last_log_index": self.last_log_index(),
                    "last_log_term": self.last_log_term(),
                },
            )

    def become_leader(self) -> None:
        self.state = "leader"
        self.leader_id = self.server_id
        last = self.last_log_index()
        self.next_index = {sid: last + 1 for sid in self.cluster.peer_ids(self.server_id)}
        self.match_index = {sid: 0 for sid in self.cluster.peer_ids(self.server_id)}
        self.inflight.clear()
        self.cluster.log_event(
            self.server_id,
            "become_leader",
            term=self.persist.current_term,
            votes=sorted(self.votes_got),
            vote_count=len(self.votes_got),
            majority=self.cluster.majority,
            last_log_index=last,
            next_index=dict(self.next_index),
            match_index=dict(self.match_index),
        )
        self.broadcast_append_entries()
        self.heartbeat_deadline = ts(
            self.cluster.clock.now() + self.cluster.heartbeat_interval_s
        )

    def broadcast_append_entries(self) -> None:
        for other in self.cluster.peer_ids(self.server_id):
            self.send_append_entries(other)

    def send_append_entries(self, dst: str) -> None:
        if self.state != "leader":
            return
        if dst in self.inflight:
            return
        ni = self.next_index.get(dst, self.last_log_index() + 1)
        prev_index = ni - 1
        prev_term = self.term_at(prev_index)
        if prev_index > 0 and prev_term < 0:
            # Should not happen: nextIndex walked off the leader's log.
            ni = 1
            self.next_index[dst] = 1
            prev_index = 0
            prev_term = 0
        entries_src = [e for e in self.persist.log if e.index >= ni]
        batch = self.cluster.batch_size
        if batch is not None:
            entries_src = entries_src[: max(1, int(batch))] if entries_src else []
            # heartbeats may be empty when caught up
        entries = [e.as_dict() for e in entries_src]
        self.inflight.add(dst)
        self.cluster.log_event(
            self.server_id,
            "append_entries_send",
            term=self.persist.current_term,
            dst=dst,
            prev_log_index=prev_index,
            prev_log_term=prev_term if prev_term >= 0 else 0,
            entry_count=len(entries),
            first_index=entries[0]["index"] if entries else None,
            last_index=entries[-1]["index"] if entries else None,
            next_index=ni,
            leader_commit=self.commit_index,
        )
        self.cluster.send(
            self.server_id,
            dst,
            "AppendEntries",
            {
                "term": self.persist.current_term,
                "leader_id": self.server_id,
                "prev_log_index": prev_index,
                "prev_log_term": prev_term if prev_term >= 0 else 0,
                "entries": entries,
                "leader_commit": self.commit_index,
            },
            entry_count=len(entries),
        )

    def append_and_replicate(self, command: dict[str, Any]) -> dict[str, Any]:
        """Leader appends a command and sends it to every peer."""
        if self.state != "leader":
            return {"status": "not_leader", "leader_id": self.leader_id}
        entry = LogEntry(self.last_log_index() + 1, self.persist.current_term, dict(command))
        self.persist.log.append(entry)
        self.flush_persist()
        self.cluster.log_event(
            self.server_id,
            "append_local",
            term=self.persist.current_term,
            index=entry.index,
            command=dict(command),
        )
        self.broadcast_append_entries()
        self.try_commit()
        return {"status": "appended", "index": entry.index, "term": entry.term}

    def holders_for(self, index: int) -> int:
        """How many servers the leader believes hold index (self + matchIndex)."""
        holders = 1  # leader always has its own log
        for sid, match in self.match_index.items():
            if match >= index:
                holders += 1
        return holders

    def try_commit(self) -> None:
        if self.state != "leader":
            return
        last = self.last_log_index()
        for n in range(last, self.commit_index, -1):
            entry = self.entry_at(n)
            if entry is None:
                continue
            holders = self.holders_for(n)
            current_term_ok = entry.term == self.persist.current_term
            if not current_term_ok and not self.cluster.allow_commit_old_terms:
                continue
            if holders >= self.cluster.majority:
                old = self.commit_index
                self.commit_index = n
                self.apply_committed()
                self.cluster.log_event(
                    self.server_id,
                    "commit",
                    term=self.persist.current_term,
                    commit_index=self.commit_index,
                    previous_commit_index=old,
                    entry_term=entry.term,
                    holders=holders,
                    current_term_rule=current_term_ok,
                    allow_commit_old_terms=self.cluster.allow_commit_old_terms,
                    match_index=dict(self.match_index),
                )
                self.broadcast_append_entries()
                break

    def apply_committed(self) -> None:
        while self.last_applied < self.commit_index:
            self.last_applied += 1
            entry = self.entry_at(self.last_applied)
            if entry is None:
                raise RuntimeError(
                    f"{self.server_id} missing log index {self.last_applied}"
                )
            cmd = entry.command
            if cmd.get("op") == "SET":
                self.kv[str(cmd["key"])] = str(cmd["value"])
            self.cluster.log_event(
                self.server_id,
                "apply",
                term=self.persist.current_term,
                index=entry.index,
                entry_term=entry.term,
                command=dict(cmd),
                title=self.kv.get(KEY_TITLE),
            )

    def on_request_vote(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        candidate = str(body["candidate_id"])
        last_idx = int(body["last_log_index"])
        last_term = int(body["last_log_term"])
        self.maybe_step_down(term)
        granted = False
        reason = ""
        if term < self.persist.current_term:
            reason = "stale_term"
        elif self.persist.voted_for not in (None, candidate):
            reason = "already_voted"
        elif not self.log_is_up_to_date(last_term, last_idx):
            reason = "log_not_up_to_date"
        else:
            granted = True
            reason = "granted"
            self.persist.voted_for = candidate
            if self.persist_votes:
                self.flush_persist()
            self.reset_election_timer()
        if self.persist_votes:
            self.flush_persist()
        else:
            term_only = Persist(
                current_term=self.persist.current_term,
                voted_for=self.durable.voted_for if self.durable else None,
                log=[LogEntry(e.index, e.term, dict(e.command)) for e in self.persist.log],
            )
            self.durable = term_only
        self.cluster.log_event(
            self.server_id,
            "vote_granted" if granted else "vote_denied",
            term=self.persist.current_term,
            voted_for=self.persist.voted_for,
            candidate=candidate,
            granted=granted,
            reason=reason,
            durable_voted_for=self.durable.voted_for if self.durable else None,
        )
        self.cluster.send(
            self.server_id,
            src,
            "RequestVoteReply",
            {
                "term": self.persist.current_term,
                "vote_granted": granted,
                "voter": self.server_id,
                "reason": reason,
            },
        )

    def on_request_vote_reply(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        self.maybe_step_down(term)
        if self.state != "candidate":
            return
        if term != self.persist.current_term:
            return
        if body.get("vote_granted"):
            self.votes_got.add(src)
            self.cluster.log_event(
                self.server_id,
                "vote_received",
                term=self.persist.current_term,
                from_id=src,
                votes=sorted(self.votes_got),
                vote_count=len(self.votes_got),
            )
            if len(self.votes_got) >= self.cluster.majority:
                self.become_leader()

    def on_append_entries(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        if term < self.persist.current_term:
            self.cluster.send(
                self.server_id,
                src,
                "AppendEntriesReply",
                {
                    "term": self.persist.current_term,
                    "success": False,
                    "reason": "stale_term",
                    "match_index": self.last_log_index(),
                    "peer": self.server_id,
                },
            )
            return
        self.maybe_step_down(term)
        self.become_follower(leader_id=str(body["leader_id"]))
        self.reset_election_timer()
        prev_index = int(body["prev_log_index"])
        prev_term = int(body["prev_log_term"])
        success = True
        reason = "ok"
        truncated_from: Optional[int] = None
        overwritten: list[dict[str, Any]] = []
        if prev_index == 0:
            pass
        else:
            match = self.entry_at(prev_index)
            if match is None or match.term != prev_term:
                success = False
                reason = "log_inconsistency"
                self.cluster.log_event(
                    self.server_id,
                    "prev_log_reject",
                    term=self.persist.current_term,
                    from_id=src,
                    prev_log_index=prev_index,
                    prev_log_term=prev_term,
                    have_index=prev_index if match is not None else self.last_log_index(),
                    have_term=match.term if match is not None else (
                        self.last_log_term() if prev_index > self.last_log_index() else None
                    ),
                    last_log_index=self.last_log_index(),
                    last_log_term=self.last_log_term(),
                )
        if success:
            for raw in body.get("entries") or []:
                idx = int(raw["index"])
                term_e = int(raw["term"])
                existing = self.entry_at(idx)
                if existing is not None and existing.term != term_e:
                    overwritten = [e.short() for e in self.persist.log if e.index >= idx]
                    self.persist.log = [e for e in self.persist.log if e.index < idx]
                    truncated_from = idx
                    existing = None
                    self.cluster.log_event(
                        self.server_id,
                        "log_truncated",
                        term=self.persist.current_term,
                        from_id=src,
                        truncated_from=idx,
                        new_term=term_e,
                        overwritten=overwritten,
                    )
                if existing is None:
                    self.persist.log.append(
                        LogEntry(idx, term_e, dict(raw["command"]))
                    )
            self.flush_persist()
            if truncated_from is not None and truncated_from <= self.last_applied:
                # Teaching rollback after a commit-rule violation. Raft
                # itself never rolls back an applied entry, because the
                # current-term commit restriction makes this case
                # unreachable.
                self.cluster.log_event(
                    self.server_id,
                    "unsafe_applied_overwrite",
                    term=self.persist.current_term,
                    from_id=src,
                    truncated_from=truncated_from,
                    last_applied_before=self.last_applied,
                    commit_index_before=self.commit_index,
                    overwritten=overwritten,
                )
                self.kv.clear()
                self.last_applied = truncated_from - 1
                # Re-apply the prefix that is still in the log; any
                # already-applied suffix was overwritten.
                prefix_applied = 0
                self.last_applied = 0
                self.kv.clear()
                saved_commit = self.commit_index
                self.commit_index = min(self.commit_index, truncated_from - 1)
                self.apply_committed()
                self.commit_index = saved_commit
            leader_commit = int(body["leader_commit"])
            if leader_commit > self.commit_index:
                last = self.last_log_index()
                self.commit_index = min(leader_commit, last)
                self.apply_committed()
            elif truncated_from is not None and self.commit_index >= truncated_from:
                # The leader has not yet advertised a new commitIndex, but
                # the local log at a previously committed index changed.
                # Re-apply so the teaching KV reflects the new log.
                self.apply_committed()
        self.cluster.send(
            self.server_id,
            src,
            "AppendEntriesReply",
            {
                "term": self.persist.current_term,
                "success": success,
                "reason": reason,
                "match_index": self.last_log_index() if success else 0,
                "peer": self.server_id,
                "truncated_from": truncated_from,
                "prev_log_index": prev_index,
                "prev_log_term": prev_term,
            },
        )

    def on_append_entries_reply(self, src: str, body: dict[str, Any]) -> None:
        term = int(body["term"])
        self.maybe_step_down(term)
        self.inflight.discard(src)
        if self.state != "leader":
            return
        if term != self.persist.current_term:
            return
        if body.get("success"):
            ack = int(body.get("match_index") or 0)
            old_match = self.match_index.get(src, 0)
            if ack > old_match:
                self.match_index[src] = ack
            self.next_index[src] = self.match_index.get(src, 0) + 1
            self.cluster.log_event(
                self.server_id,
                "match_index_update",
                term=self.persist.current_term,
                peer=src,
                match_index=self.match_index.get(src, 0),
                next_index=self.next_index[src],
                all_match_index=dict(self.match_index),
            )
            self.try_commit()
            if self.last_log_index() >= self.next_index[src]:
                self.send_append_entries(src)
        else:
            if body.get("reason") == "log_inconsistency":
                old_ni = self.next_index.get(src, 1)
                self.next_index[src] = max(1, old_ni - 1)
                self.cluster.log_event(
                    self.server_id,
                    "next_index_decrement",
                    term=self.persist.current_term,
                    peer=src,
                    old_next_index=old_ni,
                    next_index=self.next_index[src],
                    prev_log_index=body.get("prev_log_index"),
                    prev_log_term=body.get("prev_log_term"),
                )
                self.send_append_entries(src)

    def on_election_timeout(self) -> None:
        if self.state == "leader":
            return
        self.cluster.log_event(
            self.server_id,
            "election_timeout",
            term=self.persist.current_term,
            state=self.state,
            last_log_index=self.last_log_index(),
            last_log_term=self.last_log_term(),
        )
        self.start_election()

    def on_heartbeat_due(self) -> None:
        if self.state != "leader":
            return
        self.broadcast_append_entries()
        self.heartbeat_deadline = ts(
            self.cluster.clock.now() + self.cluster.heartbeat_interval_s
        )


class RaftLogEngine:
    """A teaching cluster with an in-process mailbox and a virtual clock."""

    def __init__(
        self,
        n: int = 3,
        clock: Optional[Clock] = None,
        timeouts: Optional[dict[str, float]] = None,
        rpc_delay_s: float = RPC_DELAY_S,
        entry_delay_s: float = ENTRY_DELAY_S,
        heartbeat_interval_s: float = HEARTBEAT_INTERVAL_S,
        election_timeout_min_s: float = ELECTION_TIMEOUT_MIN_S,
        election_timeout_max_s: float = ELECTION_TIMEOUT_MAX_S,
        rng: Optional[Random] = None,
        persist_votes: Optional[dict[str, bool]] = None,
        batch_size: Optional[int] = None,
        allow_commit_old_terms: bool = False,
    ) -> None:
        self.clock = clock or Clock()
        self.rpc_delay_s = float(rpc_delay_s)
        self.entry_delay_s = float(entry_delay_s)
        self.heartbeat_interval_s = float(heartbeat_interval_s)
        self.election_timeout_min_s = float(election_timeout_min_s)
        self.election_timeout_max_s = float(election_timeout_max_s)
        self.rng = rng or Random(0)
        self.n = int(n)
        self.majority = self.n // 2 + 1
        self.batch_size = batch_size
        self.allow_commit_old_terms = bool(allow_commit_old_terms)
        self.servers: dict[str, Server] = {}
        self.messages: list[Message] = []
        self.events: list[dict[str, Any]] = []
        self.partitions: set[frozenset[str]] = set()
        ids = [f"s{i}" for i in range(1, self.n + 1)]
        for sid in ids:
            if timeouts and sid in timeouts:
                to = float(timeouts[sid])
            else:
                to = self._random_timeout()
            persist = True
            if persist_votes is not None:
                persist = persist_votes.get(sid, True)
            self.servers[sid] = Server(sid, self, to, persist_votes=persist)
        for sid, srv in self.servers.items():
            self.log_event(
                sid,
                "init",
                term=0,
                state="follower",
                election_deadline=ts(srv.election_deadline),
                election_timeout_s=srv.election_timeout_s,
            )

    def _random_timeout(self) -> float:
        lo = self.election_timeout_min_s
        hi = self.election_timeout_max_s
        return ts(lo + (hi - lo) * self.rng.random())

    def peer_ids(self, server_id: str) -> list[str]:
        return [s for s in self.servers if s != server_id]

    def log_event(self, server_id: str, event: str, **kwargs: Any) -> None:
        rec: dict[str, Any] = {
            "t": ts(self.clock.now()),
            "server": server_id,
            "event": event,
        }
        rec.update(kwargs)
        self.events.append(rec)

    def partitioned(self, a: str, b: str) -> bool:
        return frozenset({a, b}) in self.partitions

    def isolate(self, server_id: str) -> None:
        for other in self.peer_ids(server_id):
            self.partitions.add(frozenset({server_id, other}))
        self.log_event(server_id, "isolated")

    def heal(self, server_id: Optional[str] = None) -> None:
        if server_id is None:
            self.partitions.clear()
            self.log_event("cluster", "healed_all")
            for srv in self.servers.values():
                srv.inflight.clear()
        else:
            self.partitions = {p for p in self.partitions if server_id not in p}
            self.log_event(server_id, "healed")
            for srv in self.servers.values():
                srv.inflight.discard(server_id)

    def pause(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.paused = True
        self.log_event(server_id, "paused", term=srv.persist.current_term, state=srv.state)

    def unpause(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.paused = False
        now = ts(self.clock.now())
        for m in self.messages:
            if m.dst == server_id and not m.dropped:
                m.deliver_at = ts(max(m.deliver_at, now))
        # The server's timers were frozen with it. Restart them from now so
        # a stale deadline that expired during the pause does not fire
        # immediately and start a spurious election.
        srv.reset_election_timer()
        if srv.state == "leader":
            srv.heartbeat_deadline = ts(now + self.heartbeat_interval_s)
        self.log_event(server_id, "unpaused", term=srv.persist.current_term, state=srv.state)

    def crash(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.crashed = True
        srv.paused = True
        srv.inflight.clear()
        self.log_event(
            server_id,
            "crashed",
            term=srv.persist.current_term,
            durable_term=srv.durable.current_term if srv.durable else None,
            last_log_index=srv.last_log_index(),
            last_log_term=srv.last_log_term(),
            title=srv.kv.get(KEY_TITLE),
        )

    def restart(self, server_id: str) -> None:
        srv = self.servers[server_id]
        srv.load_persist()
        srv.state = "follower"
        srv.commit_index = 0
        srv.last_applied = 0
        srv.votes_got.clear()
        srv.leader_id = None
        srv.kv = {}
        srv.next_index.clear()
        srv.match_index.clear()
        srv.inflight.clear()
        srv.crashed = False
        srv.paused = False
        srv.reset_election_timer()
        self.log_event(
            server_id,
            "restarted",
            term=srv.persist.current_term,
            voted_for=srv.persist.voted_for,
            last_log_index=srv.last_log_index(),
            last_log_term=srv.last_log_term(),
        )

    def send(
        self,
        src: str,
        dst: str,
        typ: str,
        body: dict[str, Any],
        entry_count: int = 0,
    ) -> None:
        now = self.clock.now()
        delay = self.rpc_delay_s + self.entry_delay_s * max(0, int(entry_count))
        msg = Message(
            src=src,
            dst=dst,
            typ=typ,
            body=dict(body),
            send_at=ts(now),
            deliver_at=ts(now + delay),
        )
        if self.partitioned(src, dst):
            msg.dropped = True
            self.log_event(src, "message_dropped", typ=typ, dst=dst, term=body.get("term"))
            src_srv = self.servers.get(src)
            if src_srv is not None:
                src_srv.inflight.discard(dst)
        self.messages.append(msg)

    def leaders(self) -> list[str]:
        return [
            s.server_id
            for s in self.servers.values()
            if s.state == "leader" and not s.paused and not s.crashed
        ]

    def inspect(self) -> dict[str, Any]:
        return {
            "t": ts(self.clock.now()),
            "majority": self.majority,
            "n": self.n,
            "leaders": self.leaders(),
            "servers": {sid: s.snapshot() for sid, s in self.servers.items()},
        }

    def log_diagram(self) -> dict[str, Any]:
        servers = {}
        for sid, s in self.servers.items():
            servers[sid] = {
                "state": s.state,
                "term": s.persist.current_term,
                "commit_index": s.commit_index,
                "title": s.kv.get(KEY_TITLE),
                "paused": s.paused,
                "crashed": s.crashed,
                "log": [e.short() for e in s.persist.log],
                "boxes": [
                    f"{e.index}:t{e.term}:{e.command.get('value', e.command.get('op'))}"
                    for e in s.persist.log
                ],
            }
        return {"t": ts(self.clock.now()), "servers": servers}

    def plant_log(self, server_id: str, term: int, voted_for: Optional[str], entries: list[LogEntry]) -> None:
        """Place a durable log (used to set up the Figure 8 teaching configuration)."""
        srv = self.servers[server_id]
        srv.persist = Persist(current_term=term, voted_for=voted_for, log=list(entries))
        srv.flush_persist()
        srv.commit_index = 0
        srv.last_applied = 0
        srv.kv = {}

    def force_leader(self, server_id: str, term: int) -> None:
        """Start a server as leader of `term` after plant_log (teaching setup)."""
        srv = self.servers[server_id]
        srv.persist.current_term = term
        srv.persist.voted_for = server_id
        srv.flush_persist()
        srv.votes_got = {server_id}
        # Count a majority as already granted so become_leader is legal
        # for the teaching setup; we do not run an election here.
        for sid in list(self.servers):
            if len(srv.votes_got) >= self.majority:
                break
            if sid != server_id:
                srv.votes_got.add(sid)
        srv.become_leader()

    def _next_event_time(self) -> Optional[float]:
        times: list[float] = []
        for m in self.messages:
            if m.dropped:
                continue
            dst = self.servers[m.dst]
            if dst.paused or dst.crashed:
                continue
            if m.deliver_at >= self.clock.now() - 1e-12:
                times.append(m.deliver_at)
        for s in self.servers.values():
            if s.paused or s.crashed:
                continue
            if s.state != "leader":
                times.append(s.election_deadline)
            if s.state == "leader":
                times.append(s.heartbeat_deadline)
        pending = [t for t in times if t > self.clock.now() + 1e-12]
        return min(pending) if pending else None

    def _deliver_due(self) -> None:
        now = self.clock.now()
        due = [
            m
            for m in self.messages
            if (not m.dropped) and m.deliver_at <= now + 1e-12
        ]
        due.sort(key=lambda m: (m.deliver_at, m.typ, m.src, m.dst))
        for m in due:
            m.dropped = True
        for m in due:
            dst = self.servers[m.dst]
            if dst.paused or dst.crashed:
                if dst.crashed:
                    continue
                m.dropped = False
                m.deliver_at = ts(max(m.deliver_at, now))
                continue
            if self.partitioned(m.src, m.dst):
                continue
            self._dispatch(m)

    def _dispatch(self, m: Message) -> None:
        srv = self.servers[m.dst]
        if m.typ == "RequestVote":
            srv.on_request_vote(m.src, m.body)
        elif m.typ == "RequestVoteReply":
            srv.on_request_vote_reply(m.src, m.body)
        elif m.typ == "AppendEntries":
            srv.on_append_entries(m.src, m.body)
        elif m.typ == "AppendEntriesReply":
            srv.on_append_entries_reply(m.src, m.body)
        else:
            raise ValueError(f"unknown typ {m.typ}")

    def _fire_timeouts(self) -> None:
        now = self.clock.now()
        for sid in sorted(self.servers):
            s = self.servers[sid]
            if s.paused or s.crashed:
                continue
            if s.state != "leader" and s.election_deadline <= now + 1e-12:
                s.on_election_timeout()
            if s.state == "leader" and s.heartbeat_deadline <= now + 1e-12:
                s.on_heartbeat_due()

    def run_until(self, t_end: float) -> None:
        """Advance the virtual clock, delivering messages and firing timeouts."""
        t_end = float(t_end)
        while True:
            self._deliver_due()
            self._fire_timeouts()
            nxt = self._next_event_time()
            if nxt is None or nxt > t_end + 1e-12:
                self.clock.wait_until(t_end)
                self._deliver_due()
                self._fire_timeouts()
                return
            self.clock.wait_until(nxt)

    def run_for(self, seconds: float) -> None:
        self.run_until(ts(self.clock.now() + float(seconds)))

    def events_of(self, *kinds: str) -> list[dict[str, Any]]:
        return [e for e in self.events if e["event"] in kinds]
