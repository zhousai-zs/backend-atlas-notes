#!/usr/bin/env python3
"""Run the lesson 118 Raft log-replication experiments and record observations."""
from __future__ import annotations

from typing import Any, Optional

from engine import (
    ELECTION_TIMEOUT_MAX_S,
    ELECTION_TIMEOUT_MIN_S,
    ENTRY_DELAY_S,
    HEARTBEAT_INTERVAL_S,
    KEY_TITLE,
    LOCAL_STEP_S,
    RPC_DELAY_S,
    TITLE_DRAFT,
    TITLE_V1,
    TITLE_V2,
    Clock,
    LogEntry,
    RaftLogEngine,
    ts,
)

TITLE_HOTFIX = "Weekly digest (hotfix)"

THREE_TIMEOUTS = {"s1": 0.15, "s2": 0.22, "s3": 0.28}


def _set(value: str, key: str = KEY_TITLE) -> dict[str, str]:
    return {"op": "SET", "key": key, "value": value}


def _events(cluster: RaftLogEngine, *extra: str) -> list[dict[str, Any]]:
    kinds = {
        "init",
        "election_timeout",
        "become_candidate",
        "vote_granted",
        "vote_denied",
        "vote_received",
        "become_leader",
        "become_follower",
        "paused",
        "unpaused",
        "crashed",
        "restarted",
        "isolated",
        "healed",
        "healed_all",
        "append_local",
        "append_entries_send",
        "prev_log_reject",
        "next_index_decrement",
        "log_truncated",
        "match_index_update",
        "commit",
        "apply",
        "message_dropped",
    }
    kinds.update(extra)
    return [e for e in cluster.events if e["event"] in kinds]


def _first(cluster: RaftLogEngine, event: str, **cond: Any) -> Optional[dict[str, Any]]:
    for e in cluster.events:
        if e["event"] != event:
            continue
        if all(e.get(k) == v for k, v in cond.items()):
            return e
    return None


def _all(cluster: RaftLogEngine, event: str, **cond: Any) -> list[dict[str, Any]]:
    out = []
    for e in cluster.events:
        if e["event"] != event:
            continue
        if all(e.get(k) == v for k, v in cond.items()):
            out.append(e)
    return out


def _wait_leader(cluster: RaftLogEngine, t_end: float, prefer: Optional[str] = None) -> Optional[str]:
    cluster.run_until(t_end)
    leaders = cluster.leaders()
    if prefer and prefer in leaders:
        return prefer
    return leaders[0] if leaders else None


def run_overwrite_uncommitted_tail() -> dict[str, Any]:
    """Inject an old leader's uncommitted tail, heal the network, check overwrite."""
    c = RaftLogEngine(n=3, timeouts=dict(THREE_TIMEOUTS))
    # Elect s1.
    c.run_until(0.20)
    after_elect = c.log_diagram()
    s1_leader = _first(c, "become_leader", server="s1")
    # Isolate s3 so the first write commits on s1+s2 only; s3 stays empty.
    c.isolate("s3")
    appended = c.servers["s1"].append_and_replicate(_set(TITLE_V1))
    c.run_until(ts(c.clock.now() + 0.10))
    after_first_commit = c.log_diagram()
    first_commit = _first(c, "commit")
    # Isolate s2 as well: s1 alone appends an uncommitted draft at index 2.
    c.isolate("s2")
    drafted = c.servers["s1"].append_and_replicate(_set(TITLE_DRAFT))
    c.run_until(ts(c.clock.now() + 0.08))
    after_uncommitted_tail = c.log_diagram()
    # Pause the old leader and restore the network among s2 and s3.
    c.pause("s1")
    c.heal()
    # Wait just until a new leader is elected (s2's log is more up-to-date
    # than s3's empty log). Do not pad a long idle interval after that.
    t_cap = ts(c.clock.now() + 0.50)
    while c.clock.now() < t_cap - 1e-12:
        if any(
            s.state == "leader" and not s.paused and not s.crashed and s.server_id != "s1"
            for s in c.servers.values()
        ):
            break
        nxt = c._next_event_time()
        if nxt is None or nxt > t_cap + 1e-12:
            c.run_until(t_cap)
            break
        c.run_until(min(nxt, t_cap))
    after_new_leader = c.log_diagram()
    new_leader_ev = None
    for e in c.events:
        if e["event"] == "become_leader" and e["server"] != "s1":
            new_leader_ev = e
    new_id = new_leader_ev["server"] if new_leader_ev else (c.leaders()[0] if c.leaders() else None)
    revised = None
    if new_id:
        revised = c.servers[new_id].append_and_replicate(_set(TITLE_V2))
        # Wait until the current-term entry is committed, then a little more
        # so s3 also applies it.
        t_cap2 = ts(c.clock.now() + 0.30)
        while c.clock.now() < t_cap2 - 1e-12:
            ldr = c.servers[new_id]
            if ldr.commit_index >= int(revised.get("index") or 0) and c.servers["s3"].commit_index >= int(revised.get("index") or 0):
                break
            nxt = c._next_event_time()
            if nxt is None or nxt > t_cap2 + 1e-12:
                c.run_until(t_cap2)
                break
            c.run_until(min(nxt, t_cap2))
    after_revised_commit = c.log_diagram()
    second_commit = None
    for e in c.events:
        if e["event"] == "commit" and e.get("entry_term") == c.servers[new_id].persist.current_term if new_id else None:
            second_commit = e
    # Bring the old leader back; its uncommitted index-2 draft must be overwritten.
    c.unpause("s1")
    if new_id and c.servers[new_id].state == "leader":
        c.servers[new_id].broadcast_append_entries()
    c.run_until(ts(c.clock.now() + 0.30))
    after_overwrite = c.log_diagram()
    rejects = _all(c, "prev_log_reject")
    decrements = _all(c, "next_index_decrement")
    truncations = _all(c, "log_truncated")
    # Committed index 1 (Weekly digest) must still be on every log.
    committed_index1_survived = all(
        (len(s.persist.log) >= 1 and s.persist.log[0].term == 1 and s.persist.log[0].command.get("value") == TITLE_V1)
        for s in c.servers.values()
    )
    # The draft must be gone; index 2 is the new leader's current-term entry.
    draft_gone = all(
        not any(e.command.get("value") == TITLE_DRAFT for e in s.persist.log)
        for s in c.servers.values()
    )
    logs_identical = len({tuple((e.index, e.term, e.command.get("value")) for e in s.persist.log) for s in c.servers.values()}) == 1
    titles = {sid: s.kv.get(KEY_TITLE) for sid, s in c.servers.items()}
    all_revised = all(v == TITLE_V2 for v in titles.values())
    return {
        "timeouts": dict(THREE_TIMEOUTS),
        "rpc_delay_s": RPC_DELAY_S,
        "heartbeat_interval_s": HEARTBEAT_INTERVAL_S,
        "majority": c.majority,
        "n": 3,
        "first_leader": s1_leader,
        "appended_v1": appended,
        "first_commit": first_commit,
        "appended_draft": drafted,
        "new_leader": new_leader_ev,
        "appended_revised": revised,
        "second_commit": second_commit,
        "prev_log_rejects": rejects,
        "next_index_decrements": decrements,
        "log_truncations": truncations,
        "match_index_updates": _all(c, "match_index_update"),
        "after_elect": after_elect,
        "after_first_commit": after_first_commit,
        "after_uncommitted_tail": after_uncommitted_tail,
        "after_new_leader": after_new_leader,
        "after_revised_commit": after_revised_commit,
        "after_overwrite": after_overwrite,
        "titles_after_overwrite": titles,
        "committed_index1_survived": committed_index1_survived,
        "draft_gone": draft_gone,
        "logs_identical": logs_identical,
        "all_titles_revised": all_revised,
        "events": _events(c),
    }


def _plant_figure8(c: RaftLogEngine, apply_index1: bool = True) -> None:
    """Place logs in the configuration of Figure 8(c).

    Index 1 (term 1, Weekly digest) is on every server and already known
    committed. Index 2 differs: s1/s2/s3 hold the term-2 draft, s5 holds a
    conflicting term-3 hotfix, s4 has only index 1. s5 is down.
    """
    e1 = LogEntry(1, 1, _set(TITLE_V1))
    e2_t2 = LogEntry(2, 2, _set(TITLE_DRAFT))
    e2_t3 = LogEntry(2, 3, _set(TITLE_HOTFIX))
    c.plant_log("s1", term=2, voted_for="s1", entries=[e1, e2_t2])
    c.plant_log("s2", term=2, voted_for="s1", entries=[e1, e2_t2])
    c.plant_log("s3", term=2, voted_for="s1", entries=[e1, e2_t2])
    c.plant_log("s4", term=2, voted_for="s1", entries=[e1])
    c.plant_log("s5", term=3, voted_for="s5", entries=[e1, e2_t3])
    for sid in ("s1", "s2", "s3", "s4", "s5"):
        srv = c.servers[sid]
        if apply_index1:
            srv.commit_index = 1
            srv.apply_committed()
    c.crash("s5")


def run_current_term_commit_restriction() -> dict[str, Any]:
    """Figure 8(c) teaching setup: an old-term entry on a majority is not committed."""
    timeouts = {"s1": 0.30, "s2": 0.30, "s3": 0.30, "s4": 0.30, "s5": 0.15}
    c = RaftLogEngine(n=5, timeouts=timeouts, allow_commit_old_terms=False)
    _plant_figure8(c)
    planted = c.log_diagram()
    c.force_leader("s1", term=4)
    # Replicate existing prefix (index 1–2) to whoever already matches;
    # s4 is behind and will require a nextIndex decrement or just sending from 2.
    c.run_until(ts(c.clock.now() + 0.20))
    after_replicate_old = c.log_diagram()
    commits_before_noop = _all(c, "commit")
    match_before = dict(c.servers["s1"].match_index)
    holders_index2 = c.servers["s1"].holders_for(2)
    commit_before = c.servers["s1"].commit_index
    # Now append a current-term entry; once it is on a majority, index 2 is
    # committed indirectly.
    appended = c.servers["s1"].append_and_replicate(_set(TITLE_V2))
    c.run_until(ts(c.clock.now() + 0.20))
    after_current_term = c.log_diagram()
    commits_after = _all(c, "commit")
    commit_after = c.servers["s1"].commit_index
    titles = {sid: s.kv.get(KEY_TITLE) for sid, s in c.servers.items() if not s.crashed}
    # s5 is still down with the conflicting term-3 hotfix at index 2.
    s5_log = [e.short() for e in c.servers["s5"].persist.log]
    # Restart s5 and try an election against a majority that already has term 4.
    # It must lose the log-up-to-date check.
    c.restart("s5")
    # Pause the current leader so an election can happen, but the majority
    # logs are already newer than s5.
    c.pause("s1")
    c.run_until(ts(c.clock.now() + 0.50))
    after_s5_attempt = c.log_diagram()
    s5_denied = _all(c, "vote_denied")
    s5_elected = any(e["event"] == "become_leader" and e["server"] == "s5" for e in c.events)
    # The committed revised title must still be present on the majority.
    live_titles = {
        sid: s.kv.get(KEY_TITLE)
        for sid, s in c.servers.items()
        if not s.crashed and not s.paused
    }
    return {
        "n": 5,
        "majority": c.majority,
        "timeouts": timeouts,
        "allow_commit_old_terms": False,
        "planted": planted,
        "become_leader": _first(c, "become_leader", server="s1"),
        "after_replicate_old": after_replicate_old,
        "match_index_before_current_term": match_before,
        "holders_for_index2_before_current_term": holders_index2,
        "commit_index_before_current_term": commit_before,
        "commits_before_current_term": commits_before_noop,
        "appended_current_term": appended,
        "after_current_term": after_current_term,
        "commit_index_after_current_term": commit_after,
        "commits_after_current_term": commits_after,
        "titles_after_current_term": titles,
        "s5_log_while_down": s5_log,
        "s5_elected_after_majority_has_term4": s5_elected,
        "s5_vote_denied": s5_denied,
        "after_s5_attempt": after_s5_attempt,
        "live_titles_after_s5_attempt": live_titles,
        "old_term_not_committed_by_counting": commit_before == 1,
        "current_term_commit_also_commits_prior": commit_after >= 3,
        "events": _events(c),
    }


def run_pitfall_commit_old_term_by_counting() -> dict[str, Any]:
    """Buggy rule: commit an old-term entry by replica count, then watch it vanish."""
    timeouts = {"s1": 0.30, "s2": 0.30, "s3": 0.30, "s4": 0.30, "s5": 0.15}
    c = RaftLogEngine(n=5, timeouts=timeouts, allow_commit_old_terms=True)
    _plant_figure8(c)
    c.force_leader("s1", term=4)
    c.run_until(ts(c.clock.now() + 0.20))
    after_buggy_commit = c.log_diagram()
    buggy_commits = _all(c, "commit")
    commit_index = c.servers["s1"].commit_index
    titles_when_wrongly_committed = {
        sid: s.kv.get(KEY_TITLE) for sid, s in c.servers.items() if not s.crashed
    }
    # Crash s1 before it writes a current-term entry. Restart s5; its term-3
    # tail is more up-to-date than the term-2 majority, so it can win and
    # overwrite the entry the buggy rule already treated as committed.
    c.crash("s1")
    c.restart("s5")
    c.run_until(ts(c.clock.now() + 0.50))
    after_s5 = c.log_diagram()
    s5_leader = None
    for e in c.events:
        if e["event"] == "become_leader" and e["server"] == "s5":
            s5_leader = e
    if s5_leader and c.servers["s5"].state == "leader":
        c.servers["s5"].broadcast_append_entries()
        c.run_until(ts(c.clock.now() + 0.30))
    after_overwrite = c.log_diagram()
    titles_after = {sid: s.kv.get(KEY_TITLE) for sid, s in c.servers.items() if not s.crashed}
    truncations = _all(c, "log_truncated")
    draft_overwritten = any(
        any(item.get("value") == TITLE_DRAFT for item in e.get("overwritten") or [])
        for e in truncations
    )
    # Under the buggy rule, a majority had applied the draft, then a new
    # leader overwrote that index. That is the safety failure.
    applied_draft_then_lost = (
        commit_index >= 2
        and TITLE_DRAFT in titles_when_wrongly_committed.values()
        and TITLE_DRAFT not in titles_after.values()
    )
    return {
        "n": 5,
        "majority": c.majority,
        "allow_commit_old_terms": True,
        "after_buggy_commit": after_buggy_commit,
        "buggy_commits": buggy_commits,
        "commit_index_after_counting_old_term": commit_index,
        "titles_when_wrongly_committed": titles_when_wrongly_committed,
        "s5_leader": s5_leader,
        "after_s5_elected": after_s5,
        "after_overwrite": after_overwrite,
        "titles_after_overwrite": titles_after,
        "log_truncations": truncations,
        "draft_overwritten": draft_overwritten,
        "applied_draft_then_lost": applied_draft_then_lost,
        "events": _events(c),
    }


def _catch_up(
    batch_size: Optional[int],
    backlog: int,
    entry_delay_s: float,
) -> dict[str, Any]:
    c = RaftLogEngine(
        n=3,
        timeouts=dict(THREE_TIMEOUTS),
        batch_size=batch_size,
        entry_delay_s=entry_delay_s,
    )
    c.run_until(0.20)
    c.isolate("s3")
    # Freeze s3 so it does not run elections in the minority partition and
    # raise its term. This experiment measures log catch-up, not a new
    # election that would reset nextIndex to last+1.
    c.pause("s3")
    for i in range(backlog):
        # Distinct keys so we are measuring log catch-up, not title overwrites.
        c.servers["s1"].append_and_replicate(_set(f"v{i:03d}", key=f"k{i:03d}"))
        # Step far enough for s2 to ack and for the leader to send the next batch.
        c.run_until(ts(c.clock.now() + 0.03))
    # Make sure the backlog is committed on s1+s2 before we heal s3.
    c.run_until(ts(c.clock.now() + 0.20))
    committed_before = c.servers["s1"].commit_index
    s3_before = c.servers["s3"].last_log_index()
    t_heal = ts(c.clock.now())
    c.unpause("s3")
    c.heal("s3")
    if c.servers["s1"].state == "leader":
        c.servers["s1"].broadcast_append_entries()
    # Catch-up bound: worse case is one RTT per entry.
    deadline = ts(t_heal + max(2.0, backlog * 0.05 + 1.0))
    caught = False
    t_caught = None
    while c.clock.now() < deadline - 1e-12:
        nxt = c._next_event_time()
        if nxt is None or nxt > deadline + 1e-12:
            c.run_until(deadline)
            break
        c.run_until(nxt)
        if c.servers["s3"].last_log_index() >= committed_before and c.servers["s3"].commit_index >= committed_before:
            caught = True
            t_caught = ts(c.clock.now())
            break
    if not caught and c.servers["s3"].last_log_index() >= committed_before:
        caught = c.servers["s3"].commit_index >= committed_before
        t_caught = ts(c.clock.now())
    sends = [
        e
        for e in c.events
        if e["event"] == "append_entries_send"
        and e.get("dst") == "s3"
        and e["t"] >= t_heal - 1e-12
        and (e.get("entry_count") or 0) > 0
    ]
    rejects = [
        e
        for e in c.events
        if e["event"] == "prev_log_reject"
        and e["server"] == "s3"
        and e["t"] >= t_heal - 1e-12
    ]
    duration = ts((t_caught if t_caught is not None else c.clock.now()) - t_heal)
    entries_sent = sum(int(e.get("entry_count") or 0) for e in sends)
    return {
        "batch_size": batch_size if batch_size is not None else "all",
        "backlog": backlog,
        "entry_delay_s": entry_delay_s,
        "rpc_delay_s": RPC_DELAY_S,
        "committed_before_heal": committed_before,
        "s3_index_before_heal": s3_before,
        "t_heal": t_heal,
        "t_caught": t_caught,
        "caught": caught,
        "catch_up_s": duration if caught else None,
        "rpc_with_entries_to_s3": len(sends),
        "entries_sent_to_s3": entries_sent,
        "prev_log_rejects_after_heal": len(rejects),
        "s3_last_index": c.servers["s3"].last_log_index(),
        "s3_commit_index": c.servers["s3"].commit_index,
    }


def run_batch_tradeoff() -> dict[str, Any]:
    """Batching cuts RTTs; a larger backlog still takes longer to repair."""
    entry_delay_s = 0.001
    cases = [
        _catch_up(batch_size=1, backlog=20, entry_delay_s=entry_delay_s),
        _catch_up(batch_size=20, backlog=20, entry_delay_s=entry_delay_s),
        _catch_up(batch_size=1, backlog=200, entry_delay_s=entry_delay_s),
        _catch_up(batch_size=50, backlog=200, entry_delay_s=entry_delay_s),
        _catch_up(batch_size=200, backlog=200, entry_delay_s=entry_delay_s),
    ]
    by_key = {
        f"batch_{c['batch_size']}_backlog_{c['backlog']}": c for c in cases
    }
    b1_20 = by_key["batch_1_backlog_20"]
    ball_20 = by_key["batch_20_backlog_20"]
    b1_200 = by_key["batch_1_backlog_200"]
    b50_200 = by_key["batch_50_backlog_200"]
    b200_200 = by_key["batch_200_backlog_200"]
    batching_faster = (
        b1_200.get("catch_up_s") is not None
        and b200_200.get("catch_up_s") is not None
        and b200_200["catch_up_s"] < b1_200["catch_up_s"]
        and b200_200["rpc_with_entries_to_s3"] < b1_200["rpc_with_entries_to_s3"]
    )
    backlog_slower = (
        ball_20.get("catch_up_s") is not None
        and b200_200.get("catch_up_s") is not None
        and b200_200["catch_up_s"] > ball_20["catch_up_s"]
    )
    return {
        "entry_delay_s": entry_delay_s,
        "rpc_delay_s": RPC_DELAY_S,
        "note": (
            "entry_delay_s is a teaching bandwidth model: each log entry adds "
            "0.001 s to the one-way virtual delay of that AppendEntries RPC. "
            "It is not a measured disk, NIC, or production RTT."
        ),
        "cases": cases,
        "batch_1_backlog_20": b1_20,
        "batch_20_backlog_20": ball_20,
        "batch_1_backlog_200": b1_200,
        "batch_50_backlog_200": b50_200,
        "batch_200_backlog_200": b200_200,
        "batching_faster_for_same_backlog": batching_faster,
        "larger_backlog_slower_even_when_fully_batched": backlog_slower,
    }


def run() -> dict[str, Any]:
    overwrite = run_overwrite_uncommitted_tail()
    restriction = run_current_term_commit_restriction()
    pitfall = run_pitfall_commit_old_term_by_counting()
    tradeoff = run_batch_tradeoff()
    acceptance_explain_commit_with_log_diagram = (
        overwrite["after_uncommitted_tail"] is not None
        and overwrite["after_overwrite"] is not None
        and restriction["planted"] is not None
        and restriction["old_term_not_committed_by_counting"]
        and restriction["current_term_commit_also_commits_prior"]
    )
    acceptance_committed_command_survives_leader_change = (
        overwrite["committed_index1_survived"]
        and overwrite["draft_gone"]
        and overwrite["logs_identical"]
        and overwrite["all_titles_revised"]
        and restriction["current_term_commit_also_commits_prior"]
        and not restriction["s5_elected_after_majority_has_term4"]
    )
    pitfall_counting_old_term_is_unsafe = pitfall["applied_draft_then_lost"]
    tradeoff_batch_vs_backlog = (
        tradeoff["batching_faster_for_same_backlog"]
        and tradeoff["larger_backlog_slower_even_when_fully_batched"]
    )
    return {
        "engine": "RaftLogEngine",
        "not_redis": True,
        "not_a_network_service": True,
        "not_full_raft": True,
        "not_paxos": True,
        "not_jepsen": True,
        "key_title": KEY_TITLE,
        "title_v1": TITLE_V1,
        "title_draft": TITLE_DRAFT,
        "title_v2": TITLE_V2,
        "title_hotfix": TITLE_HOTFIX,
        "local_step_s": LOCAL_STEP_S,
        "rpc_delay_s": RPC_DELAY_S,
        "heartbeat_interval_s": HEARTBEAT_INTERVAL_S,
        "election_timeout_min_s": ELECTION_TIMEOUT_MIN_S,
        "election_timeout_max_s": ELECTION_TIMEOUT_MAX_S,
        "majority_of_three": 2,
        "majority_of_five": 3,
        "overwrite_uncommitted_tail": overwrite,
        "current_term_commit_restriction": restriction,
        "pitfall_commit_old_term_by_counting": pitfall,
        "batch_tradeoff": tradeoff,
        "acceptance_explain_commit_with_log_diagram": acceptance_explain_commit_with_log_diagram,
        "acceptance_committed_command_survives_leader_change": acceptance_committed_command_survives_leader_change,
        "pitfall_counting_old_term_is_unsafe": pitfall_counting_old_term_is_unsafe,
        "tradeoff_batch_vs_backlog": tradeoff_batch_vs_backlog,
    }


if __name__ == "__main__":
    import json
    from pathlib import Path

    result = run()
    Path(__file__).with_name("results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print("wrote results.json")
