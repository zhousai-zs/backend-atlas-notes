#!/usr/bin/env python3
"""Acceptance checks for the lesson 118 Raft log-replication experiments."""
from __future__ import annotations

import json
from pathlib import Path

from app import run
from engine import TITLE_DRAFT, TITLE_V1, TITLE_V2


def main() -> None:
    result = run()
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    ow = result["overwrite_uncommitted_tail"]
    rest = result["current_term_commit_restriction"]
    pit = result["pitfall_commit_old_term_by_counting"]
    tr = result["batch_tradeoff"]

    assert result["engine"] == "RaftLogEngine"
    assert result["not_redis"] and result["not_a_network_service"] and result["not_full_raft"]
    assert result["not_paxos"] and result["not_jepsen"]
    assert result["majority_of_three"] == 2 and result["majority_of_five"] == 3

    # Main practice: uncommitted tail is overwritten; committed index 1 survives.
    assert ow["first_leader"] and ow["first_leader"]["server"] == "s1"
    assert ow["first_commit"] and ow["first_commit"]["commit_index"] == 1
    tail = ow["after_uncommitted_tail"]["servers"]
    assert tail["s1"]["commit_index"] == 1
    assert any(e["value"] == TITLE_DRAFT for e in tail["s1"]["log"])
    assert not any(e["value"] == TITLE_DRAFT for e in tail["s2"]["log"])
    assert ow["committed_index1_survived"] is True
    assert ow["draft_gone"] is True
    assert ow["logs_identical"] is True
    assert ow["all_titles_revised"] is True
    final = ow["after_overwrite"]["servers"]
    for sid in ("s1", "s2", "s3"):
        log = final[sid]["log"]
        assert log[0]["value"] == TITLE_V1 and log[0]["term"] == 1
        assert log[1]["value"] == TITLE_V2
        assert final[sid]["title"] == TITLE_V2
        assert final[sid]["commit_index"] >= 2
    assert len(ow["prev_log_rejects"]) >= 1
    assert len(ow["next_index_decrements"]) >= 1
    assert len(ow["log_truncations"]) >= 1
    assert any(
        any(item.get("value") == TITLE_DRAFT for item in e.get("overwritten") or [])
        for e in ow["log_truncations"]
    )

    # Current-term commit restriction (Figure 8 teaching setup).
    assert rest["holders_for_index2_before_current_term"] >= 3
    assert rest["commit_index_before_current_term"] == 1
    assert rest["old_term_not_committed_by_counting"] is True
    assert rest["commit_index_after_current_term"] >= 3
    assert rest["current_term_commit_also_commits_prior"] is True
    assert rest["s5_elected_after_majority_has_term4"] is False
    for sid in ("s1", "s2", "s3"):
        srv = rest["after_current_term"]["servers"][sid]
        assert srv["commit_index"] >= 3
        assert srv["title"] == TITLE_V2
        assert srv["log"][0]["value"] == TITLE_V1
        assert srv["log"][1]["value"] == TITLE_DRAFT
        assert srv["log"][2]["value"] == TITLE_V2

    # Pitfall: counting old-term replicas commits a command that later vanishes.
    assert pit["commit_index_after_counting_old_term"] >= 2
    assert TITLE_DRAFT in pit["titles_when_wrongly_committed"].values()
    assert pit["applied_draft_then_lost"] is True
    assert pit["s5_leader"] is not None
    assert TITLE_DRAFT not in pit["titles_after_overwrite"].values()

    # Tradeoff: batching is faster; a larger backlog is still slower.
    assert tr["batching_faster_for_same_backlog"] is True
    assert tr["larger_backlog_slower_even_when_fully_batched"] is True
    for key in (
        "batch_1_backlog_20",
        "batch_20_backlog_20",
        "batch_1_backlog_200",
        "batch_50_backlog_200",
        "batch_200_backlog_200",
    ):
        case = tr[key]
        assert case["caught"] is True
        assert case["catch_up_s"] is not None

    assert result["acceptance_explain_commit_with_log_diagram"] is True
    assert result["acceptance_committed_command_survives_leader_change"] is True
    assert result["pitfall_counting_old_term_is_unsafe"] is True
    assert result["tradeoff_batch_vs_backlog"] is True

    print("ALL_CHECKS_PASSED")


if __name__ == "__main__":
    main()
