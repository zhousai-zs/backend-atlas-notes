#!/usr/bin/env python3
"""Acceptance checks for the g-kv teaching lab."""
from __future__ import annotations

import json
import os
import sys

from app import run_all_experiments, ROCKSDB_DOCS

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    data = run_all_experiments()
    data.update(
        {
            "python": sys.version.split()[0],
            "rocksdb_docs": ROCKSDB_DOCS,
            "docs_checked": "2026-11-12",
        }
    )

    _assert_crud(data["crud"])
    _assert_torn(data["torn_vs_safe"])
    _assert_lin(data["linearization"])
    _assert_lost(data["lost_update"])
    _assert_locks(data["sharded_vs_global"])
    _assert_ttl(data["ttl"])
    _assert_billing(data["billing"])
    _assert_reject(data["capacity_reject"])
    _assert_evict(data["capacity_evict"])
    _assert_work(data["workload"])
    _assert_persist(data["persist_cost"])

    out = os.path.join(HERE, "results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

    c = data["crud"]
    t = data["torn_vs_safe"]
    lin = data["linearization"]
    lost = data["lost_update"]
    lk = data["sharded_vs_global"]
    ttl = data["ttl"]
    bill = data["billing"]
    rej = data["capacity_reject"]
    ev = data["capacity_evict"]
    w = data["workload"]
    p = data["persist_cost"]

    print("ALL_CHECKS_PASSED")
    print(
        "SUMMARY "
        f"missing={c['missing_status']} del_missing={c['delete_missing_status']} "
        f"overwrite={c['after_overwrite']} after_del={c['after_delete_status']} "
        f"naive_torn={t['naive_torn_count']} safe_torn={t['safe_torn_count']} "
        f"safe_final_complete={t['safe_final_complete']} "
        f"lin_handoff={lin['handoff_sees_published']} "
        f"naive_cnt={lost['naive_final']} cas={lost['cas_final']} "
        f"incr={lost['incr_final']} cas_retries={lost['cas_retries']} "
        f"sharded_ops={lk['sharded']['ops_per_s']} global_ops={lk['global']['ops_per_s']} "
        f"lazy_after={ttl['lazy_after_status']} compact_stale={ttl['compact_get_after_ttl_value']} "
        f"compact_removed={ttl['compact_removed']} "
        f"bill={bill['memory_used']} vs_value={bill['value_only_total']} "
        f"fourth={rej['fourth_status']} evicted={ev['evicted']} "
        f"A={w['A']['ops_per_s']}/s hit={w['A']['observed_get_hit_rate']} "
        f"B={w['B']['ops_per_s']}/s C={w['C']['ops_per_s']}/s "
        f"D={w['D']['ops_per_s']}/s E={w['E']['ops_per_s']}/s "
        f"sharded_work={lk['sharded_with_work']['elapsed_s']}s "
        f"global_work={lk['global_with_work']['elapsed_s']}s "
        f"mem={p['memory_only']['per_op_us']}us "
        f"wal={p['wal_nosync']['per_op_us']}us "
        f"fsync={p['wal_fsync']['per_op_us']}us recovered={p['wal_fsync']['recovered']}"
    )
    return 0


def _assert_crud(c: dict) -> None:
    assert c["missing_status"] == "not_found" and c["missing_found"] is False
    assert c["exists_before"] is False
    assert c["delete_missing_status"] == "ok" and c["delete_missing_found"] is False
    assert c["create_created"] is True and c["create_version"] == 1
    assert c["hit_value"] == "Weekly digest" and c["exists_after_set"] is True
    assert c["overwrite_created"] is False and c["overwrite_version"] == 2
    assert c["after_overwrite"] == "Weekly digest (revised)"
    assert c["delete_found"] is True
    assert c["after_delete_status"] == "not_found"
    assert c["exists_after_delete"] is False
    assert c["delete_again_status"] == "ok" and c["delete_again_found"] is False


def _assert_torn(t: dict) -> None:
    assert t["naive_torn_count"] >= 1, t
    assert t["naive_final_complete"] is True
    assert t["safe_torn_count"] == 0, t
    assert t["safe_final_complete"] is True
    assert set(t["safe_values_seen"]).issubset({"A" * 80, "B" * 80})


def _assert_lin(lin: dict) -> None:
    assert lin["following_get_value"] == "draft"
    assert lin["seq_increases"] is True
    assert lin["handoff_sees_published"] is True
    assert lin["handoff_seq_order"] is True


def _assert_lost(lost: dict) -> None:
    expected = lost["expected"]
    assert expected == lost["threads"] * lost["adds_each"]
    assert lost["naive_final"] < expected, lost
    assert lost["cas_final"] == expected, lost
    assert lost["cas_retries"] >= 1, lost
    assert lost["incr_final"] == expected, lost


def _assert_locks(lk: dict) -> None:
    assert lk["sharded"]["key_count"] == lk["distinct_keys"]
    assert lk["global"]["key_count"] == lk["distinct_keys"]
    assert lk["same_key_16_shards"]["final_version"] == lk["same_key_16_shards"]["ops"]
    # sharded should not be dramatically slower; usually faster or close
    assert lk["sharded"]["ops_per_s"] > 0 and lk["global"]["ops_per_s"] > 0
    assert lk["sharded_with_work"]["elapsed_s"] < lk["global_with_work"]["elapsed_s"]
    assert lk["sharded_with_work"]["ops_per_s"] > lk["global_with_work"]["ops_per_s"]


def _assert_ttl(ttl: dict) -> None:
    assert ttl["lazy_before_value"] == "draft-token"
    assert ttl["lazy_mid_value"] == "draft-token"
    assert ttl["lazy_after_status"] == "not_found" and ttl["lazy_after_found"] is False
    assert ttl["lazy_exists_after"] is False
    assert ttl["lazy_memory_after"] == 0
    assert ttl["compact_get_after_ttl_status"] == "ok"
    assert ttl["compact_get_after_ttl_value"] == "draft-token"
    assert ttl["compact_exists_after_ttl"] is True
    assert ttl["compact_memory_before_compact"] > 0
    assert ttl["compact_removed"] == 1
    assert ttl["compact_get_after_compact"] == "not_found"
    assert ttl["compact_memory_after"] == 0


def _assert_billing(b: dict) -> None:
    expected = 100 * (b["key_bytes"] + b["value_bytes"] + b["entry_overhead"])
    assert b["memory_used"] == expected == b["billed_per_key"] * 100
    assert b["value_only_total"] == 1000
    assert b["memory_used"] > b["value_only_total"]


def _assert_reject(r: dict) -> None:
    assert r["first_three"] == ["ok", "ok", "ok"]
    assert r["fourth_status"] == "rejected"
    assert r["exists_1_to_4"] == [True, True, True, False]
    assert r["same_size_overwrite"] == "ok"
    assert r["grow_overwrite_status"] == "rejected"
    assert r["title_after_rejected_grow"] == "hello"
    assert r["used_when_full"] == r["budget"]


def _assert_evict(e: dict) -> None:
    assert e["fourth_status"] == "ok"
    assert e["evicted"] == ["article:02:title"], e
    assert e["exists"]["k1"] is True
    assert e["exists"]["k2"] is False
    assert e["exists"]["k3"] is True
    assert e["exists"]["k4"] is True
    assert e["huge_status"] == "rejected"
    assert e["huge_reason"] == "item_too_large"
    # rejecting a too-large item must not evict the working set
    assert e["exists_after_huge"]["k1"] is True
    assert e["exists_after_huge"]["k2"] is False
    assert e["exists_after_huge"]["k3"] is True
    assert e["exists_after_huge"]["k4"] is True
    assert e["used"] == e["used_after_huge"] == e["billed_per_key"] * 3


def _assert_work(w: dict) -> None:
    for name in ("A", "B", "C"):
        rec = w[name]
        assert rec["ops"] == 20000, rec
        assert rec["ops_per_s"] > 0
        # declared parameters must be present for the pitfall lesson
        assert rec["key_bytes"] >= 1 and rec["value_bytes"] >= 1
        assert 0 < rec["declared_hit_rate"] <= 1
    # A and C share value size; C writes more. Hit rate of A should be near 0.8
    assert abs(w["A"]["observed_get_hit_rate"] - 0.80) < 0.08, w["A"]
    assert w["A"]["declared_read_ratio"] == 0.9
    assert w["C"]["declared_read_ratio"] == 0.5
    assert w["B"]["value_bytes"] == 1024
    assert w["D"]["miss_penalty_s"] == w["E"]["miss_penalty_s"] == 0.0002
    assert w["E"]["declared_hit_rate"] == 0.20
    assert w["D"]["ops_per_s"] > w["E"]["ops_per_s"]


def _assert_persist(p: dict) -> None:
    assert p["memory_only"]["ops"] == p["n"] == 400
    assert p["wal_nosync"]["recovered"] == 400
    assert p["wal_fsync"]["recovered"] == 400
    assert p["wal_fsync"]["first_value_ok"] and p["wal_fsync"]["last_value_ok"]
    # fsync should not be faster than memory-only in this setup
    assert p["wal_fsync"]["elapsed_s"] >= p["memory_only"]["elapsed_s"] * 0.9


if __name__ == "__main__":
    raise SystemExit(main())
