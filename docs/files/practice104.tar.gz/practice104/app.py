#!/usr/bin/env python3
"""Runnable experiments for the g-kv teaching lab."""
from __future__ import annotations

import os
import random
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Optional

from engine import (
    ENTRY_OVERHEAD,
    KVEngine,
    NaiveTornKV,
    Clock,
    STATUS_CAS_FAILED,
    STATUS_NOT_FOUND,
    STATUS_OK,
    STATUS_REJECTED,
)


HERE = os.path.dirname(os.path.abspath(__file__))
ROCKSDB_DOCS = "https://rocksdb.org/docs/"
BASIC_OPS = "https://github.com/facebook/rocksdb/wiki/Basic-Operations"
MEMORY_DOC = "https://github.com/facebook/rocksdb/wiki/Memory-usage-in-RocksDB"
MEMTABLE_DOC = "https://github.com/facebook/rocksdb/wiki/MemTable"
STALL_DOC = "https://github.com/facebook/rocksdb/wiki/Write-Stalls"
FAQ_DOC = "https://github.com/facebook/rocksdb/wiki/RocksDB-FAQ"


def run_all_experiments() -> dict[str, Any]:
    return {
        "crud": _crud(),
        "torn_vs_safe": _torn_vs_safe(),
        "linearization": _linearization(),
        "lost_update": _lost_update(),
        "sharded_vs_global": _sharded_vs_global(),
        "ttl": _ttl(),
        "billing": _billing(),
        "capacity_reject": _capacity_reject(),
        "capacity_evict": _capacity_evict(),
        "workload": _workloads(),
        "persist_cost": _persist_cost(),
    }


def _crud() -> dict[str, Any]:
    kv = KVEngine(n_shards=8, clock=Clock(live=True))
    missing = kv.get("article:42:title")
    exists_before = kv.exists("article:42:title")
    deleted_missing = kv.delete("article:42:title")
    created = kv.set("article:42:title", "Weekly digest")
    hit = kv.get("article:42:title")
    exists_after = kv.exists("article:42:title")
    overwritten = kv.set("article:42:title", "Weekly digest (revised)")
    after_ow = kv.get("article:42:title")
    deleted = kv.delete("article:42:title")
    after_del = kv.get("article:42:title")
    exists_deleted = kv.exists("article:42:title")
    deleted_again = kv.delete("article:42:title")
    return {
        "missing_status": missing.status,
        "missing_found": missing.found,
        "exists_before": exists_before,
        "delete_missing_status": deleted_missing.status,
        "delete_missing_found": deleted_missing.found,
        "create_status": created.status,
        "create_created": created.created,
        "create_version": created.version,
        "hit_value": hit.value,
        "exists_after_set": exists_after,
        "overwrite_created": overwritten.created,
        "overwrite_version": overwritten.version,
        "after_overwrite": after_ow.value,
        "delete_found": deleted.found,
        "after_delete_status": after_del.status,
        "exists_after_delete": exists_deleted,
        "delete_again_status": deleted_again.status,
        "delete_again_found": deleted_again.found,
    }


def _torn_vs_safe() -> dict[str, Any]:
    a = "A" * 80
    b = "B" * 80
    naive = NaiveTornKV()
    torn_seen: list[str] = []
    stop = threading.Event()

    def naive_writer() -> None:
        for i in range(8):
            naive.set_slow("draft:42", a if i % 2 == 0 else b, pause_s=0.00025)
        stop.set()

    def naive_reader() -> None:
        while not stop.is_set():
            val = naive.get("draft:42")
            if val and val not in (a, b, "") and val not in torn_seen:
                torn_seen.append(val)
            time.sleep(0.00005)

    readers = [threading.Thread(target=naive_reader) for _ in range(4)]
    w = threading.Thread(target=naive_writer)
    for t in readers:
        t.start()
    w.start()
    w.join()
    stop.set()
    for t in readers:
        t.join()
    naive_final = naive.get("draft:42")

    kv = KVEngine(n_shards=8, clock=Clock(live=True))
    safe_seen: set[str] = set()
    barrier = threading.Barrier(17)

    def safe_writer(payload: str, n: int) -> None:
        barrier.wait()
        for _ in range(n):
            kv.set("draft:42", payload)

    def safe_reader() -> None:
        barrier.wait()
        for _ in range(400):
            got = kv.get("draft:42")
            if got.found and got.value is not None:
                safe_seen.add(got.value)

    threads = [threading.Thread(target=safe_writer, args=(a, 80)),
               threading.Thread(target=safe_writer, args=(b, 80))]
    threads += [threading.Thread(target=safe_reader) for _ in range(15)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    final = kv.get("draft:42")
    return {
        "payload_len": len(a),
        "naive_torn_count": len(torn_seen),
        "naive_torn_samples": torn_seen[:3],
        "naive_final_complete": naive_final in (a, b),
        "safe_values_seen": sorted(safe_seen),
        "safe_torn_count": sum(1 for v in safe_seen if v not in (a, b)),
        "safe_final": final.value,
        "safe_final_complete": final.value in (a, b),
        "safe_final_version": final.version,
    }


def _linearization() -> dict[str, Any]:
    kv = KVEngine(n_shards=8, clock=Clock(live=True))
    # After set returns, a get started afterwards must see it (or a later write).
    set_res = kv.set("article:1:state", "draft")
    get_res = kv.get("article:1:state")

    # Two threads: B waits until A's set has returned, then gets.
    flag = threading.Event()
    later_get: dict[str, Any] = {}

    def writer() -> None:
        res = kv.set("article:1:state", "published")
        later_get["set_seq"] = res.seq
        later_get["set_version"] = res.version
        flag.set()

    def reader() -> None:
        flag.wait(timeout=2)
        res = kv.get("article:1:state")
        later_get["get_seq"] = res.seq
        later_get["get_value"] = res.value
        later_get["get_version"] = res.version

    t1 = threading.Thread(target=writer)
    t2 = threading.Thread(target=reader)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    return {
        "first_set_seq": set_res.seq,
        "following_get_seq": get_res.seq,
        "following_get_value": get_res.value,
        "seq_increases": get_res.seq > set_res.seq,
        "handoff_set_seq": later_get["set_seq"],
        "handoff_get_seq": later_get["get_seq"],
        "handoff_value": later_get["get_value"],
        "handoff_sees_published": later_get["get_value"] == "published",
        "handoff_seq_order": later_get["get_seq"] > later_get["set_seq"],
    }



def _lost_update() -> dict[str, Any]:
    # naive: get + set are two linearized ops, so a concurrent add can be lost.
    threads = 4
    adds_each = 100
    expected = threads * adds_each

    kv_naive = KVEngine(n_shards=8, clock=Clock(live=True))
    kv_naive.set("article:7:reads", "0")
    barrier = threading.Barrier(threads)

    def naive_add(n: int) -> None:
        barrier.wait()
        for _ in range(n):
            cur = kv_naive.get("article:7:reads")
            # yield so another thread can sneak a set into the gap
            time.sleep(0)
            kv_naive.set("article:7:reads", str(int(cur.value) + 1))

    with ThreadPoolExecutor(max_workers=threads) as pool:
        futs = [pool.submit(naive_add, adds_each) for _ in range(threads)]
        for f in futs:
            f.result()
    naive_final = int(kv_naive.get("article:7:reads").value)

    kv_cas = KVEngine(n_shards=8, clock=Clock(live=True))
    kv_cas.set("article:7:reads", "0")
    barrier2 = threading.Barrier(threads)
    cas_retries = {"n": 0}
    lock = threading.Lock()

    def cas_add(n: int) -> None:
        barrier2.wait()
        done = 0
        while done < n:
            cur = kv_cas.get("article:7:reads")
            time.sleep(0)
            res = kv_cas.cas("article:7:reads", cur.version or 0, str(int(cur.value) + 1))
            if res.status == STATUS_OK:
                done += 1
            else:
                with lock:
                    cas_retries["n"] += 1

    with ThreadPoolExecutor(max_workers=threads) as pool:
        futs = [pool.submit(cas_add, adds_each) for _ in range(threads)]
        for f in futs:
            f.result()
    cas_final = int(kv_cas.get("article:7:reads").value)

    kv_incr = KVEngine(n_shards=8, clock=Clock(live=True))
    kv_incr.set("article:7:reads", "0")
    barrier3 = threading.Barrier(threads)

    def incr_add(n: int) -> None:
        barrier3.wait()
        for _ in range(n):
            kv_incr.incr("article:7:reads", 1)

    with ThreadPoolExecutor(max_workers=threads) as pool:
        futs = [pool.submit(incr_add, adds_each) for _ in range(threads)]
        for f in futs:
            f.result()
    incr_final = int(kv_incr.get("article:7:reads").value)

    return {
        "threads": threads,
        "adds_each": adds_each,
        "expected": expected,
        "naive_final": naive_final,
        "cas_final": cas_final,
        "cas_retries": cas_retries["n"],
        "incr_final": incr_final,
    }


def _sharded_vs_global() -> dict[str, Any]:
    keys = [f"article:{i}:title" for i in range(800)]
    value = "x" * 16
    threads = 8
    def bench(lock_mode: str, critical_work_s: float = 0.0) -> dict[str, Any]:
        kv = KVEngine(
            n_shards=16,
            lock_mode=lock_mode,
            clock=Clock(live=True),
            critical_work_s=critical_work_s,
        )
        chunk = len(keys) // threads
        barrier = threading.Barrier(threads)
        def worker(start: int, end: int) -> None:
            barrier.wait()
            for k in keys[start:end]:
                kv.set(k, value)
        ts = []
        t0 = time.perf_counter()
        for i in range(threads):
            s = i * chunk
            e = len(keys) if i == threads - 1 else (i + 1) * chunk
            t = threading.Thread(target=worker, args=(s, e))
            ts.append(t)
            t.start()
        for t in ts:
            t.join()
        elapsed = time.perf_counter() - t0
        return {
            "elapsed_s": round(elapsed, 4),
            "ops": len(keys),
            "ops_per_s": round(len(keys) / elapsed, 1),
            "key_count": kv.key_count(),
            "critical_work_s": critical_work_s,
        }

    # same-key contention on one shard vs many keys
    def same_key(n_shards: int) -> dict[str, Any]:
        kv = KVEngine(n_shards=n_shards, clock=Clock(live=True))
        barrier = threading.Barrier(threads)
        def worker() -> None:
            barrier.wait()
            for i in range(200):
                kv.set("hot:article:1", f"v{i}")
        t0 = time.perf_counter()
        ts = [threading.Thread(target=worker) for _ in range(threads)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        elapsed = time.perf_counter() - t0
        return {
            "elapsed_s": round(elapsed, 4),
            "ops": threads * 200,
            "ops_per_s": round(threads * 200 / elapsed, 1),
            "final_version": kv.get("hot:article:1").version,
        }

    work = 0.0002
    return {
        "threads": threads,
        "distinct_keys": len(keys),
        "key_bytes": len(keys[0].encode()),
        "value_bytes": len(value),
        "sharded": bench("sharded"),
        "global": bench("global"),
        "sharded_with_work": bench("sharded", work),
        "global_with_work": bench("global", work),
        "same_key_16_shards": same_key(16),
        "critical_work_s": work,
    }


def _ttl() -> dict[str, Any]:
    clock = Clock(start=0.0, live=False)
    lazy = KVEngine(n_shards=4, clock=clock, expire_mode="lazy_on_access")
    lazy.set("session:edit:1", "draft-token", ttl=2.0)
    before = lazy.get("session:edit:1")
    clock.advance(1.0)
    mid = lazy.get("session:edit:1")
    clock.advance(1.5)
    after = lazy.get("session:edit:1")
    exists_after = lazy.exists("session:edit:1")
    used_after = lazy.memory_used()

    clock2 = Clock(start=0.0, live=False)
    compact = KVEngine(n_shards=4, clock=clock2, expire_mode="compact_lazy")
    compact.set("session:edit:2", "draft-token", ttl=2.0)
    clock2.advance(3.0)
    stale = compact.get("session:edit:2")
    exists_stale = compact.exists("session:edit:2")
    used_stale = compact.memory_used()
    removed = compact.compact()
    gone = compact.get("session:edit:2")
    used_after_compact = compact.memory_used()
    return {
        "ttl_s": 2.0,
        "lazy_before_value": before.value,
        "lazy_mid_value": mid.value,
        "lazy_after_status": after.status,
        "lazy_after_found": after.found,
        "lazy_exists_after": exists_after,
        "lazy_memory_after": used_after,
        "compact_get_after_ttl_status": stale.status,
        "compact_get_after_ttl_value": stale.value,
        "compact_get_reason": stale.reason,
        "compact_exists_after_ttl": exists_stale,
        "compact_memory_before_compact": used_stale,
        "compact_removed": removed,
        "compact_get_after_compact": gone.status,
        "compact_memory_after": used_after_compact,
    }


def _billing() -> dict[str, Any]:
    kv = KVEngine(n_shards=4, clock=Clock(live=True), entry_overhead=ENTRY_OVERHEAD)
    # 100 tiny titles: people sometimes only count the 10-byte value
    items = []
    for i in range(100):
        key = f"t:{i:03d}"  # 5 bytes
        value = "abcdefghij"  # 10 bytes
        items.append((key, value))
        kv.set(key, value)
    per = kv.bill(items[0][0], items[0][1])
    return {
        "count": 100,
        "key_bytes": len(items[0][0].encode()),
        "value_bytes": len(items[0][1].encode()),
        "entry_overhead": ENTRY_OVERHEAD,
        "billed_per_key": per,
        "value_only_total": 100 * 10,
        "memory_used": kv.memory_used(),
        "ratio_vs_value_only": round(kv.memory_used() / (100 * 10), 2),
    }


def _capacity_reject() -> dict[str, Any]:
    # 3 titles fit; the 4th must be rejected and leave existing keys untouched
    overhead = ENTRY_OVERHEAD
    key = "article:1:title"
    value = "hello"  # 5
    # key varies in length; use fixed size keys
    def k(i: int) -> str:
        return f"article:{i:02d}:title"  # 16 bytes

    sample_bill = len(k(1).encode()) + len(value.encode()) + overhead
    budget = sample_bill * 3
    kv = KVEngine(
        n_shards=4,
        max_memory=budget,
        overflow="reject",
        entry_overhead=overhead,
        clock=Clock(live=True),
    )
    statuses = [kv.set(k(i), value).status for i in range(1, 4)]
    used_full = kv.memory_used()
    fourth = kv.set(k(4), value)
    still = [kv.exists(k(i)) for i in range(1, 5)]
    # overwrite that does not grow should still succeed
    ow = kv.set(k(1), value)
    # overwrite that grows beyond budget should reject
    grow = kv.set(k(1), value + " world!!!!")  # clearly larger
    after_grow = kv.get(k(1))
    return {
        "budget": budget,
        "billed_per_key": sample_bill,
        "first_three": statuses,
        "used_when_full": used_full,
        "fourth_status": fourth.status,
        "fourth_reason": fourth.reason,
        "exists_1_to_4": still,
        "same_size_overwrite": ow.status,
        "grow_overwrite_status": grow.status,
        "title_after_rejected_grow": after_grow.value,
    }


def _capacity_evict() -> dict[str, Any]:
    def k(i: int) -> str:
        return f"article:{i:02d}:title"

    value = "hello"
    bill = len(k(1).encode()) + len(value.encode()) + ENTRY_OVERHEAD
    kv = KVEngine(
        n_shards=4,
        max_memory=bill * 3,
        overflow="evict",
        clock=Clock(live=True),
    )
    for i in range(1, 4):
        kv.set(k(i), value)
        kv.get(k(i))  # LRU order: 1,2,3 with 3 most recent after loop? 
        # set already touches LRU, so order is 1,2,3 (3 is newest)
    # touch 1 so it becomes newest; victim should be 2
    kv.get(k(1))
    fourth = kv.set(k(4), value)
    exists = {f"k{i}": kv.exists(k(i)) for i in range(1, 5)}
    used_after_fourth = kv.memory_used()
    # one item larger than the whole budget is rejected and must not evict
    too_big = kv.set("article:huge", "x" * (bill * 4))
    exists_after_huge = {f"k{i}": kv.exists(k(i)) for i in range(1, 5)}
    return {
        "budget_keys": 3,
        "billed_per_key": bill,
        "evicted": fourth.evicted,
        "fourth_status": fourth.status,
        "exists": exists,
        "used": used_after_fourth,
        "huge_status": too_big.status,
        "huge_reason": too_big.reason,
        "exists_after_huge": exists_after_huge,
        "used_after_huge": kv.memory_used(),
    }


def _workloads() -> dict[str, Any]:
    def run(
        name: str,
        key_bytes: int,
        value_bytes: int,
        n_keys: int,
        hit_rate: float,
        read_ratio: float,
        n_ops: int,
        n_threads: int,
        miss_penalty_s: float = 0.0,
    ) -> dict[str, Any]:
        kv = KVEngine(n_shards=16, clock=Clock(live=True), miss_penalty_s=miss_penalty_s)
        key_fmt = f"k:{{:0{max(1, key_bytes - 2)}d}}"
        # pad keys to requested size
        def make_key(i: int) -> str:
            raw = f"k:{i}"
            if len(raw.encode()) >= key_bytes:
                return raw[:key_bytes]
            return (raw + ("p" * (key_bytes - len(raw.encode()))))

        value = "v" * value_bytes
        populated = [make_key(i) for i in range(n_keys)]
        for k in populated:
            kv.set(k, value)
        # miss keys are outside the populated set
        miss_keys = [make_key(n_keys + i) for i in range(n_keys)]
        barrier = threading.Barrier(n_threads)
        rng_seed = 104
        hits = [0]
        misses = [0]
        reads = [0]
        writes = [0]
        lock = threading.Lock()

        def worker(seed: int) -> None:
            rng = random.Random(seed)
            barrier.wait()
            local_h = local_m = local_r = local_w = 0
            for _ in range(n_ops // n_threads):
                is_read = rng.random() < read_ratio
                if rng.random() < hit_rate:
                    key = populated[rng.randrange(n_keys)]
                    target_hit = True
                else:
                    key = miss_keys[rng.randrange(n_keys)]
                    target_hit = False
                if is_read:
                    res = kv.get(key)
                    local_r += 1
                    if res.found:
                        local_h += 1
                    else:
                        local_m += 1
                else:
                    kv.set(key, value)
                    local_w += 1
                    if target_hit or True:
                        # write is a hit on populated or creates a miss key
                        pass
            with lock:
                hits[0] += local_h
                misses[0] += local_m
                reads[0] += local_r
                writes[0] += local_w

        t0 = time.perf_counter()
        ts = [threading.Thread(target=worker, args=(rng_seed + i,)) for i in range(n_threads)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        elapsed = time.perf_counter() - t0
        actual_ops = reads[0] + writes[0]
        observed_hit = (hits[0] / reads[0]) if reads[0] else 0.0
        return {
            "name": name,
            "key_bytes": key_bytes,
            "value_bytes": value_bytes,
            "n_keys": n_keys,
            "declared_hit_rate": hit_rate,
            "declared_read_ratio": read_ratio,
            "declared_write_ratio": round(1.0 - read_ratio, 2),
            "threads": n_threads,
            "ops": actual_ops,
            "reads": reads[0],
            "writes": writes[0],
            "elapsed_s": round(elapsed, 4),
            "ops_per_s": round(actual_ops / elapsed, 1),
            "observed_get_hit_rate": round(observed_hit, 3),
            "miss_penalty_s": miss_penalty_s,
        }

    # Workload A: small values, mostly reads, high hit rate — the numbers
    # that must be written next to any "ops/s" claim in the lesson.
    a = run("A_small_read_heavy", 16, 64, 2000, 0.80, 0.90, 20000, 4)
    b = run("B_1kib_values", 16, 1024, 2000, 0.80, 0.90, 20000, 4)
    c = run("C_balanced_rw", 16, 64, 2000, 0.80, 0.50, 20000, 4)
    # same as A but misses pay 0.2 ms, and a low-hit variant of that contract
    d = run("D_high_hit_with_miss_io", 16, 64, 2000, 0.80, 0.90, 8000, 4, miss_penalty_s=0.0002)
    e = run("E_low_hit_with_miss_io", 16, 64, 2000, 0.20, 0.90, 8000, 4, miss_penalty_s=0.0002)
    return {"A": a, "B": b, "C": c, "D": d, "E": e}


def _persist_cost() -> dict[str, Any]:
    n = 400
    key_bytes, value_bytes = 16, 64
    value = "v" * value_bytes

    def make_key(i: int) -> str:
        raw = f"k:{i}"
        return raw + "p" * (key_bytes - len(raw))

    def run_mem() -> dict[str, Any]:
        kv = KVEngine(n_shards=8, clock=Clock(live=True))
        t0 = time.perf_counter()
        for i in range(n):
            kv.set(make_key(i), value)
        elapsed = time.perf_counter() - t0
        return {"elapsed_s": round(elapsed, 4), "ops": n, "per_op_us": round(elapsed / n * 1e6, 1)}

    def run_wal(sync: bool) -> dict[str, Any]:
        fd, path = tempfile.mkstemp(prefix="kv-wal-", suffix=".log")
        os.close(fd)
        try:
            kv = KVEngine(n_shards=8, clock=Clock(live=True), wal_path=path, wal_sync=sync)
            t0 = time.perf_counter()
            for i in range(n):
                kv.set(make_key(i), value)
            elapsed = time.perf_counter() - t0
            kv.close()
            size = os.path.getsize(path)
            recovered = KVEngine(n_shards=8, clock=Clock(live=True))
            applied = recovered.recover_from_wal(path)
            sample = recovered.get(make_key(0))
            last = recovered.get(make_key(n - 1))
            recovered.close()
            return {
                "elapsed_s": round(elapsed, 4),
                "ops": n,
                "per_op_us": round(elapsed / n * 1e6, 1),
                "wal_bytes": size,
                "recovered": applied,
                "first_value_ok": sample.value == value,
                "last_value_ok": last.value == value,
            }
        finally:
            try:
                os.remove(path)
            except OSError:
                pass

    mem = run_mem()
    wal = run_wal(False)
    wal_sync = run_wal(True)
    return {
        "n": n,
        "key_bytes": key_bytes,
        "value_bytes": value_bytes,
        "memory_only": mem,
        "wal_nosync": wal,
        "wal_fsync": wal_sync,
        "fsync_vs_memory_x": round(wal_sync["elapsed_s"] / mem["elapsed_s"], 1) if mem["elapsed_s"] else None,
    }


if __name__ == "__main__":
    import json

    data = run_all_experiments()
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))
