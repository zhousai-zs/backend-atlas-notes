#!/usr/bin/env python3
"""In-process teaching KV kernel for g-kv (not RocksDB)."""
from __future__ import annotations

import hashlib
import os
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Optional


ENTRY_OVERHEAD = 32
STATUS_OK = "ok"
STATUS_NOT_FOUND = "not_found"
STATUS_REJECTED = "rejected"
STATUS_CAS_FAILED = "cas_failed"


class Clock:
    def __init__(self, start: float = 0.0, live: bool = False) -> None:
        self._start = start
        self._offset = 0.0
        self._live = live
        self._origin = time.monotonic() if live else 0.0

    def now(self) -> float:
        if self._live:
            return self._start + (time.monotonic() - self._origin) + self._offset
        return self._start + self._offset

    def advance(self, seconds: float) -> None:
        self._offset += seconds


@dataclass
class Entry:
    value: str
    version: int
    billed: int
    expire_at: Optional[float] = None
    # used only by compact_lazy expire mode: still readable until compact()
    expired_pending: bool = False


@dataclass
class OpResult:
    status: str
    value: Optional[str] = None
    found: bool = False
    version: Optional[int] = None
    seq: int = 0
    evicted: list[str] = field(default_factory=list)
    created: bool = False
    billed: int = 0
    reason: str = ""


class NaiveTornKV:
    """Unlocked store that writes a value one character at a time.

    Used only to show torn reads. It is not the teaching kernel.
    """

    def __init__(self) -> None:
        self._store: dict[str, str] = {}

    def set_slow(self, key: str, value: str, pause_s: float = 0.0004) -> None:
        buf: list[str] = []
        self._store[key] = ""
        for ch in value:
            buf.append(ch)
            self._store[key] = "".join(buf)
            time.sleep(pause_s)
        self._store[key] = value

    def get(self, key: str) -> Optional[str]:
        return self._store.get(key)


class KVEngine:
    """Single-process teaching KV with hashed shards and explicit contracts.

    Linearization point of every public op: while the key's shard lock is
    held, the engine assigns a monotonic sequence number and then either
    mutates or reads the hash slot. A later Get after a successful Set
    returns has a higher seq and sees that write (or a later one).

    Concurrent Sets on the same key are last-writer-wins by seq. The stored
    value is always a complete string, never a torn prefix.

    This is not RocksDB, not Redis, and not a network server.
    """

    def __init__(
        self,
        n_shards: int = 16,
        max_memory: Optional[int] = None,
        overflow: str = "reject",
        entry_overhead: int = ENTRY_OVERHEAD,
        clock: Optional[Clock] = None,
        expire_mode: str = "lazy_on_access",
        lock_mode: str = "sharded",
        wal_path: Optional[str] = None,
        wal_sync: bool = False,
        critical_work_s: float = 0.0,
        miss_penalty_s: float = 0.0,
    ) -> None:
        if n_shards < 1:
            raise ValueError("n_shards")
        if overflow not in ("reject", "evict"):
            raise ValueError("overflow")
        if expire_mode not in ("lazy_on_access", "compact_lazy"):
            raise ValueError("expire_mode")
        if lock_mode not in ("sharded", "global"):
            raise ValueError("lock_mode")
        self.n_shards = n_shards
        self.max_memory = max_memory
        self.overflow = overflow
        self.entry_overhead = entry_overhead
        self.clock = clock or Clock(live=True)
        self.expire_mode = expire_mode
        self.lock_mode = lock_mode
        self.wal_path = wal_path
        self.wal_sync = wal_sync
        self.critical_work_s = critical_work_s
        self.miss_penalty_s = miss_penalty_s
        self._shards: list[dict[str, Entry]] = [dict() for _ in range(n_shards)]
        self._locks = [threading.RLock() for _ in range(n_shards)]
        self._global = threading.RLock()
        self._lru_lock = threading.Lock()
        self._lru: OrderedDict[str, None] = OrderedDict()
        self._used = 0
        self._seq = 0
        self._seq_lock = threading.Lock()
        self._wal_lock = threading.Lock()
        self._wal_fp = None
        if wal_path:
            parent = os.path.dirname(wal_path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            self._wal_fp = open(wal_path, "a", encoding="utf-8")

    def close(self) -> None:
        if self._wal_fp is not None:
            self._wal_fp.close()
            self._wal_fp = None

    def bill(self, key: str, value: str) -> int:
        return len(key.encode("utf-8")) + len(value.encode("utf-8")) + self.entry_overhead

    def memory_used(self) -> int:
        return self._used

    def key_count(self, include_pending_expired: bool = False) -> int:
        n = 0
        for shard in self._shards:
            for entry in shard.values():
                if entry.expired_pending and not include_pending_expired:
                    continue
                n += 1
        return n

    def shard_of(self, key: str) -> int:
        digest = hashlib.blake2b(key.encode("utf-8"), digest_size=8).digest()
        return int.from_bytes(digest, "little") % self.n_shards

    def _next_seq(self) -> int:
        with self._seq_lock:
            self._seq += 1
            return self._seq

    def _acquire(self, shard: int):
        if self.lock_mode == "global":
            return self._global
        return self._locks[shard]

    def _is_due(self, entry: Entry, now: float) -> bool:
        return entry.expire_at is not None and now >= entry.expire_at

    def _touch_lru(self, key: str) -> None:
        with self._lru_lock:
            if key in self._lru:
                self._lru.move_to_end(key)
            else:
                self._lru[key] = None

    def _drop_lru(self, key: str) -> None:
        with self._lru_lock:
            self._lru.pop(key, None)

    def _append_wal(self, op: str, key: str, value: str = "") -> None:
        if self._wal_fp is None:
            return
        with self._wal_lock:
            # length-prefixed so values may contain spaces or newlines in theory
            line = f"{op} {len(key)} {key} {len(value)} {value}\n"
            self._wal_fp.write(line)
            self._wal_fp.flush()
            if self.wal_sync:
                os.fsync(self._wal_fp.fileno())

    def _purge_entry(self, shard: int, key: str) -> None:
        entry = self._shards[shard].pop(key, None)
        if entry is None:
            return
        self._used -= entry.billed
        self._drop_lru(key)

    def _maybe_expire_locked(self, shard: int, key: str, now: float) -> bool:
        entry = self._shards[shard].get(key)
        if entry is None or not self._is_due(entry, now):
            return False
        if self.expire_mode == "compact_lazy":
            entry.expired_pending = True
            return False
        self._purge_entry(shard, key)
        return True

    def compact(self) -> int:
        """Drop keys whose TTL has already elapsed (teaching stand-in for compaction)."""
        removed = 0
        now = self.clock.now()
        # lock shards in order to keep the teaching model deadlock-free
        for shard in range(self.n_shards):
            self._locks[shard].acquire()
        try:
            if self.lock_mode == "global":
                self._global.acquire()
            try:
                seq = self._next_seq()
                for shard, table in enumerate(self._shards):
                    for key in list(table.keys()):
                        entry = table[key]
                        if self._is_due(entry, now) or entry.expired_pending:
                            self._purge_entry(shard, key)
                            removed += 1
                del seq
            finally:
                if self.lock_mode == "global":
                    self._global.release()
        finally:
            for shard in range(self.n_shards - 1, -1, -1):
                self._locks[shard].release()
        return removed

    def get(self, key: str) -> OpResult:
        shard = self.shard_of(key)
        with self._acquire(shard):
            seq = self._next_seq()
            now = self.clock.now()
            self._maybe_expire_locked(shard, key, now)
            entry = self._shards[shard].get(key)
            if entry is None:
                if self.miss_penalty_s:
                    time.sleep(self.miss_penalty_s)
                return OpResult(status=STATUS_NOT_FOUND, found=False, seq=seq)
            if entry.expired_pending:
                # compact_lazy: still visible until compact()
                return OpResult(
                    status=STATUS_OK,
                    value=entry.value,
                    found=True,
                    version=entry.version,
                    seq=seq,
                    billed=entry.billed,
                    reason="expired_pending",
                )
            self._touch_lru(key)
            return OpResult(
                status=STATUS_OK,
                value=entry.value,
                found=True,
                version=entry.version,
                seq=seq,
                billed=entry.billed,
            )

    def exists(self, key: str) -> bool:
        result = self.get(key)
        if result.status == STATUS_OK and result.reason != "expired_pending":
            return True
        if result.status == STATUS_OK and result.reason == "expired_pending":
            # still present until compact, so exists is true in compact_lazy
            return True
        return False

    def delete(self, key: str) -> OpResult:
        shard = self.shard_of(key)
        with self._acquire(shard):
            seq = self._next_seq()
            now = self.clock.now()
            self._maybe_expire_locked(shard, key, now)
            entry = self._shards[shard].get(key)
            if entry is None:
                return OpResult(status=STATUS_OK, found=False, seq=seq, reason="absent")
            self._append_wal("DEL", key)
            self._purge_entry(shard, key)
            return OpResult(
                status=STATUS_OK,
                found=True,
                version=entry.version,
                seq=seq,
                billed=0,
            )

    def _evict_until(self, need: int, protected: str) -> list[str]:
        evicted: list[str] = []
        # caller must hold every shard lock (or the global lock)
        while self.max_memory is not None and self._used + need > self.max_memory:
            victim = None
            with self._lru_lock:
                for cand in self._lru:
                    if cand != protected:
                        victim = cand
                        break
            if victim is None:
                break
            vs = self.shard_of(victim)
            if victim not in self._shards[vs]:
                self._drop_lru(victim)
                continue
            self._purge_entry(vs, victim)
            evicted.append(victim)
        return evicted

    def set(
        self,
        key: str,
        value: str,
        ttl: Optional[float] = None,
        expected_version: Optional[int] = None,
    ) -> OpResult:
        shard = self.shard_of(key)
        new_bill = self.bill(key, value)

        def apply_locked() -> OpResult:
            if self.critical_work_s:
                time.sleep(self.critical_work_s)
            now = self.clock.now()
            expire_at = None if ttl is None else now + ttl
            seq = self._next_seq()
            self._maybe_expire_locked(shard, key, now)
            table = self._shards[shard]
            old = table.get(key)
            if old is not None and old.expired_pending:
                # treat pending-expired as still occupying memory until compact,
                # but a new Set replaces it.
                pass
            if expected_version is not None:
                current_ver = 0 if old is None else old.version
                if current_ver != expected_version:
                    return OpResult(
                        status=STATUS_CAS_FAILED,
                        found=old is not None,
                        version=old.version if old else None,
                        seq=seq,
                        value=old.value if old else None,
                    )
            old_bill = old.billed if old is not None else 0
            delta = new_bill - old_bill
            evicted: list[str] = []
            if self.max_memory is not None and new_bill > self.max_memory:
                # a single item larger than the budget must not evict anyone
                return OpResult(
                    status=STATUS_REJECTED,
                    found=old is not None,
                    version=old.version if old else None,
                    seq=seq,
                    billed=self._used,
                    reason="item_too_large",
                )
            if self.max_memory is not None and self._used + delta > self.max_memory:
                if self.overflow == "reject":
                    return OpResult(
                        status=STATUS_REJECTED,
                        found=old is not None,
                        version=old.version if old else None,
                        seq=seq,
                        billed=self._used,
                        reason="capacity",
                    )
                evicted = self._evict_until(delta, protected=key)
                if self._used + delta > self.max_memory:
                    return OpResult(
                        status=STATUS_REJECTED,
                        found=old is not None,
                        version=old.version if old else None,
                        seq=seq,
                        evicted=evicted,
                        billed=self._used,
                        reason="capacity",
                    )
            version = 1 if old is None else old.version + 1
            if old is not None:
                self._used -= old.billed
            table[key] = Entry(
                value=value,
                version=version,
                billed=new_bill,
                expire_at=expire_at,
                expired_pending=False,
            )
            self._used += new_bill
            self._touch_lru(key)
            self._append_wal("SET", key, value)
            return OpResult(
                status=STATUS_OK,
                value=value,
                found=old is not None,
                version=version,
                seq=seq,
                evicted=evicted,
                created=old is None,
                billed=self._used,
            )

        if self.overflow == "evict" and self.max_memory is not None:
            # evict may touch other shards; lock all shards in order
            for s in range(self.n_shards):
                self._locks[s].acquire()
            try:
                if self.lock_mode == "global":
                    with self._global:
                        return apply_locked()
                return apply_locked()
            finally:
                for s in range(self.n_shards - 1, -1, -1):
                    self._locks[s].release()
        else:
            with self._acquire(shard):
                return apply_locked()

    def cas(self, key: str, expected_version: int, value: str, ttl: Optional[float] = None) -> OpResult:
        return self.set(key, value, ttl=ttl, expected_version=expected_version)

    def incr(self, key: str, amount: int = 1) -> OpResult:
        shard = self.shard_of(key)
        with self._acquire(shard):
            seq = self._next_seq()
            now = self.clock.now()
            self._maybe_expire_locked(shard, key, now)
            table = self._shards[shard]
            old = table.get(key)
            current = 0
            if old is not None and not old.expired_pending:
                current = int(old.value)
            nxt = current + amount
            value = str(nxt)
            new_bill = self.bill(key, value)
            old_bill = old.billed if old is not None else 0
            if old is not None:
                self._used -= old.billed
            version = 1 if old is None else old.version + 1
            table[key] = Entry(value=value, version=version, billed=new_bill)
            self._used += new_bill
            self._touch_lru(key)
            self._append_wal("SET", key, value)
            return OpResult(
                status=STATUS_OK,
                value=value,
                found=old is not None,
                version=version,
                seq=seq,
                created=old is None,
                billed=self._used,
            )

    def recover_from_wal(self, path: str) -> int:
        applied = 0
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if not line:
                    continue
                # OP <klen> <key> [<vlen> <value>]
                parts = line.split(" ", 2)
                op = parts[0]
                rest = parts[2] if len(parts) == 3 else ""
                klen = int(parts[1])
                key = rest[:klen]
                if op == "DEL":
                    self.delete(key)
                    applied += 1
                    continue
                # skip the space after key
                after = rest[klen + 1 :]
                vlen_s, _, value_and = after.partition(" ")
                vlen = int(vlen_s)
                value = value_and[:vlen]
                self.set(key, value)
                applied += 1
        return applied
