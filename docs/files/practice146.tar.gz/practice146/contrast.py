import pytest
@pytest.fixture(scope='module')
def shared(tmp_path_factory):
    return tmp_path_factory.mktemp('shared') / 'data'
def test_shared_writer(shared):
    shared.write_text('dirty')
def test_shared_reader(shared):
    assert not shared.exists(), 'shared state polluted the reader'
def test_intentional_failure(kv):
    assert kv.directory.exists()
    assert kv.request('SET', key='x', value='y')['ok']
    assert False, 'intentional failure to verify teardown'
def test_stable_recovery_bug(kv):
    kv.request('SET', key='theme', value='dark')
    kv.stop()
    kv.start(buggy=True)
    assert kv.request('GET', key='theme') == {'value': 'dark'}
