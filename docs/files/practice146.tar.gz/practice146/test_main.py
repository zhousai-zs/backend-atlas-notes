import pytest

def test_restart_recovers(kv):
    assert kv.request('SET', key='theme', value='dark') == {'ok': True}
    assert kv.request('GET', key='theme') == {'value': 'dark'}
    kv.stop()
    kv.start()
    assert kv.request('GET', key='theme') == {'value': 'dark'}

def test_timeout_then_reconnect(kv):
    with pytest.raises(TimeoutError):
        kv.request('HANG', timeout=0.05)
    kv.stop()
    kv.start()
    assert kv.request('GET', key='missing') == {'value': None}

def test_crash_and_recover(kv):
    kv.request('SET', key='session', value='alive')
    with pytest.raises(ConnectionError): kv.request('CRASH')
    assert kv.proc.wait(timeout=2) == 23
    kv.stop()
    kv.start()
    assert kv.request('GET', key='session') == {'value': 'alive'}

def test_isolated_write(kv):
    assert kv.request('GET', key='shared') == {'value': None}
    kv.request('SET', key='shared', value='dirty')

def test_isolated_read(kv):
    assert kv.request('GET', key='shared') == {'value': None}
