import argparse, json, os, socket, time
from pathlib import Path
p = argparse.ArgumentParser()
p.add_argument('--dir', required=True)
p.add_argument('--buggy', action='store_true')
a = p.parse_args()
path = Path(a.dir) / 'data.json'
data = json.loads(path.read_text()) if path.exists() and not a.buggy else {}
with socket.socket() as server:
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('127.0.0.1', 0))
    server.listen()
    print(server.getsockname()[1], flush=True)
    while True:
        conn, _ = server.accept()
        with conn:
            request = json.loads(conn.makefile('rb').readline())
            if request['op'] == 'HANG':
                time.sleep(0.3)
                continue
            if request['op'] == 'CRASH':
                os._exit(23)
            if request['op'] == 'SET':
                data[request['key']] = request['value']
                path.write_text(json.dumps(data))
                reply = {'ok': True}
            else:
                reply = {'value': data.get(request['key'])}
            conn.sendall((json.dumps(reply) + '\n').encode())
