# practice146

需要 Python 3 和 pytest。运行 `bash test.sh`；脚本生成 `run.log` 与 `results.json`，故意失败的对照由驱动检查退出码。可以复制整个目录到临时目录独立运行。

教学假设：服务仅监听本机，使用每连接一条 JSON 请求、换行结束的 TCP 协议：`{"op":"SET","key":"theme","value":"dark"}` 返回 `{"ok":true}`；`{"op":"GET","key":"theme"}` 返回 `{"value":"dark"}`，缺失时 value 为 null。`HANG` 与 `CRASH` 是测试专用故障指令。数据写入独立临时目录的 JSON 文件；这不是生产级持久化或真实业务协议。`--buggy` 故意忽略已有数据，用于稳定缺陷对照。
