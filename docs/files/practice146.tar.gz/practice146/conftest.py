import json, os, select, shutil, socket, subprocess, sys, tempfile
from pathlib import Path
import pytest
ROOT = Path(__file__).resolve().parent
class KV:
    def __init__(self):
        self.directory = Path(tempfile.mkdtemp(prefix='practice146-'))
        self.proc = None
        try:
            self.start()
        except BaseException:
            self.stop()
            shutil.rmtree(self.directory)
            raise
    def start(self, buggy=False):
        cmd = [sys.executable, '-u', str(ROOT / 'kv.py'), '--dir', str(self.directory)]
        if buggy: cmd.append('--buggy')
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        ready, _, _ = select.select([self.proc.stdout], [], [], 3)
        if not ready: raise RuntimeError('server startup timeout')
        line = self.proc.stdout.readline()
        if not line: raise RuntimeError('server startup failed')
        self.port = int(line)
    def stop(self):
        if self.proc:
            if self.proc.poll() is None: self.proc.terminate()
            try: self.proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=2)
            self.proc.stdout.close()
            self.proc.stderr.close()
    def request(self, op, timeout=0.1, **kwargs):
        with socket.create_connection(('127.0.0.1', self.port), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall((json.dumps(dict(op=op, **kwargs)) + '\n').encode())
            with s.makefile('rb') as stream: line = stream.readline()
            if not line: raise ConnectionError('server closed connection')
            return json.loads(line)
@pytest.fixture
def kv():
    instance = KV()
    try:
        yield instance
    finally:
        pid, port, directory = instance.proc.pid, instance.port, instance.directory
        existed = directory.exists()
        instance.stop()
        shutil.rmtree(directory)
        if os.environ.get('AUDIT_FILE'):
            Path(os.environ['AUDIT_FILE']).write_text(json.dumps({'pid': pid, 'port': port, 'directory': str(directory), 'existed_before_teardown': existed, 'returncode': instance.proc.returncode}))
