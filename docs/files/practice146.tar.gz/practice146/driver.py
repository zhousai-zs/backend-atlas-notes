import json, os, socket, subprocess, sys, tempfile, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
results = {}
def run(label, args, expected, env=None):
    print(f'\n=== {label} ===', flush=True)
    start = time.monotonic()
    p = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', *args], cwd=ROOT, env=env)
    elapsed = time.monotonic() - start
    print(f'{label}: exit={p.returncode} elapsed={elapsed:.3f}s', flush=True)
    if p.returncode != expected: raise SystemExit(f'unexpected exit for {label}: {p.returncode}')
    results[label] = {'exit': p.returncode, 'elapsed_seconds': round(elapsed, 3)}
print('Python:', sys.version.split()[0], flush=True)
subprocess.run([sys.executable, '-m', 'pytest', '--version'], check=True)
print('client timeout=0.05s; injected HANG=0.3s', flush=True)
run('main', ['test_main.py'], 0)
run('isolated_reverse', ['test_main.py::test_isolated_read', 'test_main.py::test_isolated_write'], 0)
run('shared_writer_then_reader', ['contrast.py::test_shared_writer', 'contrast.py::test_shared_reader'], 1)
run('shared_reader_then_writer', ['contrast.py::test_shared_reader', 'contrast.py::test_shared_writer'], 0)
with tempfile.TemporaryDirectory(prefix='practice146-audit-') as tmp:
    audit = Path(tmp) / 'audit.json'
    env = os.environ.copy()
    env['AUDIT_FILE'] = str(audit)
    run('intentional_failure', ['contrast.py::test_intentional_failure'], 1, env)
    info = json.loads(audit.read_text())
    try: os.kill(info['pid'], 0)
    except ProcessLookupError: pid_gone = True
    else: pid_gone = False
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(('127.0.0.1', info['port']))
            port_free = True
        except OSError: port_free = False
    dir_gone = not Path(info['directory']).exists()
    print(f"cleanup: pid={info['pid']} pid_gone={pid_gone} port={info['port']} port_free={port_free} dir_existed={info['existed_before_teardown']} dir_gone={dir_gone}", flush=True)
    assert pid_gone and port_free and dir_gone and info['existed_before_teardown']
    results['cleanup'] = dict(info, pid_gone=pid_gone, port_free=port_free, dir_gone=dir_gone)
for i in range(1, 4): run(f'stable_bug_attempt_{i}', ['contrast.py::test_stable_recovery_bug'], 1)
(ROOT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print('ALL_CHECKS_PASSED', flush=True)
