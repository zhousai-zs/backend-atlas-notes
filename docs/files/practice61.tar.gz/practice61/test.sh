#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./run.sh | tee /tmp/practice61.out
grep -q 'expect 2002' /tmp/practice61.out
grep -q 'tls_ticket=2002' /tmp/practice61.out
# block mode elapsed should be >= 1800ms roughly
elapsed=$(grep -oP 'elapsed=\K[0-9]+' /tmp/practice61.out | tail -1)
test "${elapsed:-0}" -ge 1800
echo "practice61 OK"
