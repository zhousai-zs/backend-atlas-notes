#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
c++ -std=c++17 -O0 -Wall -o coop_sched coop_sched.cpp
echo "---- cooperative mode ----"
./coop_sched
echo
echo "---- unhooked block mode (peer should be delayed ~2s) ----"
./coop_sched block
