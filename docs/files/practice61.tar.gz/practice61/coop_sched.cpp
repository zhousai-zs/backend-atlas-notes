// 教学用：协作调度示意（状态机模拟有栈 yield）
// 验证 1：thread_local 同线程协程共享
// 验证 2：未 hook 的阻塞（::sleep）会卡住同线程其它「协程」步进
#include <chrono>
#include <cstdio>
#include <deque>
#include <functional>
#include <string>
#include <thread>
#include <unistd.h>

struct Sched;

struct Task {
    std::string name;
    std::function<void(Sched&, Task&)> body;
    int step = 0;
    bool done = false;
};

thread_local int tls_ticket = 0;

struct Sched {
    std::deque<Task*> rq;
    void spawn(Task* t) { rq.push_back(t); }
    void yield(Task* self) { rq.push_back(self); }
    void run() {
        while (!rq.empty()) {
            Task* t = rq.front();
            rq.pop_front();
            if (t->done) continue;
            t->body(*this, *t);
        }
    }
};

static double now_ms() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double, std::milli>(clock::now().time_since_epoch()).count();
}

int main(int argc, char** argv) {
    bool do_block = argc > 1 && std::string(argv[1]) == "block";

    Sched S;

    Task tls_a{"tls-A", [](Sched& S, Task& self) {
        if (self.step == 0) {
            tls_ticket = 1001;
            std::printf("[tls-A] set tls_ticket=%d then yield\n", tls_ticket);
            self.step = 1;
            S.yield(&self);
            return;
        }
        std::printf("[tls-A] resumed, tls_ticket=%d (expect 2002 if shared)\n", tls_ticket);
        self.done = true;
    }};

    Task tls_b{"tls-B", [](Sched& S, Task& self) {
        (void)S;
        tls_ticket = 2002;
        std::printf("[tls-B] set tls_ticket=%d\n", tls_ticket);
        self.done = true;
    }};

    Task blocker{"blocker", [do_block](Sched& S, Task& self) {
        (void)S;
        if (self.step == 0) {
            std::printf("[blocker] before %s\n", do_block ? "sleep(2) [UNHOOKED]" : "cooperative pause");
            self.step = 1;
            if (do_block) {
                // 模拟「未 hook 的阻塞」：整个 OS 线程睡死，调度器也跑不了
                ::sleep(2);
                self.done = true;
                std::printf("[blocker] after sleep\n");
                return;
            }
            // 协作：立刻把控制交还（本示意用 step 模拟；真实有栈会 coctx_swap）
            S.yield(&self);
            return;
        }
        std::printf("[blocker] resumed cooperatively\n");
        self.done = true;
    }};

    Task peer{"peer", [](Sched& S, Task& self) {
        (void)S;
        std::printf("[peer] ran at t=%.0fms\n", now_ms());
        self.done = true;
    }};

    std::printf("=== TLS sharing demo ===\n");
    S.spawn(&tls_a);
    S.spawn(&tls_b);
    S.run();

    std::printf("\n=== Blocking impact demo (mode=%s) ===\n", do_block ? "block" : "coop");
    // reset scheduler queue
    blocker.step = 0;
    blocker.done = false;
    peer.done = false;
    double t0 = now_ms();
    S.spawn(&blocker);
    S.spawn(&peer);
    S.run();
    std::printf("elapsed=%.0fms\n", now_ms() - t0);
    return 0;
}
