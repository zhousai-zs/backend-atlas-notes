// Teaching-only: short-read / bad-fd submit path / cancel+lifetime
#include <liburing.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>

static int init_ring(io_uring* ring) {
    return io_uring_queue_init(8, ring, 0);
}

static void case_short_read() {
    io_uring ring{};
    if (init_ring(&ring) < 0) { perror("queue_init"); return; }
    int fd = open("/tmp/atlas62_short.txt", O_RDONLY);
    if (fd < 0) { perror("open short"); io_uring_queue_exit(&ring); return; }
    std::vector<char> buf(64, 0);
    io_uring_sqe* sqe = io_uring_get_sqe(&ring);
    io_uring_prep_read(sqe, fd, buf.data(), buf.size(), 0);
    io_uring_sqe_set_data(sqe, buf.data());
    int s = io_uring_submit(&ring);
    if (s < 0) { fprintf(stderr, "[short] submit failed %d\n", s); }
    else {
        io_uring_cqe* cqe{};
        io_uring_wait_cqe(&ring, &cqe);
        fprintf(stderr, "[short] res=%d (file smaller => short read)\n", cqe->res);
        io_uring_cqe_seen(&ring, cqe);
    }
    close(fd);
    io_uring_queue_exit(&ring);
    // buf freed after CQE handled — OK
}

static void case_bad_fd() {
    io_uring ring{};
    if (init_ring(&ring) < 0) { perror("queue_init"); return; }
    char buf[16];
    io_uring_sqe* sqe = io_uring_get_sqe(&ring);
    io_uring_prep_read(sqe, /*bad*/-1, buf, sizeof(buf), 0);
    io_uring_sqe_set_data(sqe, (void*)0xBAD);
    int s = io_uring_submit(&ring);
    fprintf(stderr, "[badfd] submit=%d\n", s);
    if (s >= 0) {
        io_uring_cqe* cqe{};
        io_uring_wait_cqe(&ring, &cqe);
        fprintf(stderr, "[badfd] cqe res=%d (expect negative errno)\n", cqe->res);
        io_uring_cqe_seen(&ring, cqe);
    }
    io_uring_queue_exit(&ring);
}

static void case_cancel() {
    io_uring ring{};
    if (init_ring(&ring) < 0) { perror("queue_init"); return; }
    int fd = open("/tmp/atlas62_big.bin", O_RDONLY);
    if (fd < 0) { perror("open big"); io_uring_queue_exit(&ring); return; }
    const size_t n = 8 * 1024 * 1024;
    auto* buf = new char[n];
    auto* cookie = (void*)0xREAD;
    io_uring_sqe* sqe = io_uring_get_sqe(&ring);
    io_uring_prep_read(sqe, fd, buf, n, 0);
    io_uring_sqe_set_data(sqe, cookie);
    io_uring_submit(&ring);

    io_uring_sqe* csqe = io_uring_get_sqe(&ring);
    io_uring_prep_cancel(csqe, cookie, 0);
    io_uring_sqe_set_data(csqe, (void*)0xCACE);
    io_uring_submit(&ring);

    for (int i = 0; i < 2; ++i) {
        io_uring_cqe* cqe{};
        if (io_uring_wait_cqe(&ring, &cqe) < 0) break;
        fprintf(stderr, "[cancel] id=%p res=%d\n", io_uring_cqe_get_data(cqe), cqe->res);
        io_uring_cqe_seen(&ring, cqe);
    }
    // Only now recycle buffer
    delete[] buf;
    close(fd);
    io_uring_queue_exit(&ring);
    fprintf(stderr, "[cancel] buffer recycled after CQEs\n");
}

int main(int argc, char** argv) {
    std::string which = argc > 1 ? argv[1] : "all";
    if (which == "short" || which == "all") case_short_read();
    if (which == "badfd" || which == "all") case_bad_fd();
    if (which == "cancel" || which == "all") case_cancel();
    return 0;
}
