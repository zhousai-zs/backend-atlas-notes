#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
printf 'hello-proactor' > /tmp/atlas62_short.txt
if [[ ! -f /tmp/atlas62_big.bin ]]; then
  dd if=/dev/urandom of=/tmp/atlas62_big.bin bs=1M count=16 status=none
fi
if ! pkg-config --exists liburing 2>/dev/null && [[ ! -f /usr/include/liburing.h ]]; then
  echo "liburing-dev not installed; compile skipped (lesson still valid)"
  exit 0
fi
c++ -O2 -std=c++17 controlled_read.cpp -luring -o controlled_read
./controlled_read all
