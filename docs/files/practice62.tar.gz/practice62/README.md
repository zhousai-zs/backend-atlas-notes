# practice62 — liburing 受控文件读（教学）

对应课程：第 62 课 Proactor、完成通知与 io_uring

## 目标
1. 短读：请求长度 > 文件大小，观察 CQE.res
2. 提交失败：非法 fd，观察失败发生层
3. 取消：大文件读 + ASYNC_CANCEL，确认完成后才释放缓冲

## 依赖
```bash
sudo apt-get install -y liburing-dev
```

## 运行
```bash
./run.sh
```
