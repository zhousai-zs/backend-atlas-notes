#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
g++ -std=c++17 -O0 -fsanitize=address -o buf_ne buffer.cpp
g++ -std=c++17 -O0 -fsanitize=address -DMOVE_NOEXCEPT= -o buf_nx buffer.cpp
A=$(./buf_ne); B=$(./buf_nx)
echo "== noexcept 移动 =="; echo "$A"
echo "== 去掉 noexcept =="; echo "$B"
echo "$A" | grep -q "vector_grow copy=0 move=[1-9]" || { echo FAIL noexcept 应只移动; exit 1; }
echo "$B" | grep -q "vector_grow copy=[1-9][0-9]* move=0" || { echo FAIL 非noexcept 应退化为拷贝; exit 1; }
echo "$A" | grep -q "const_move copy=1 move=0" || { echo FAIL const move 应拷贝; exit 1; }
echo "$A" | grep -q "moved_from empty=1 size=0 b.size=8" || { echo FAIL 移动后状态; exit 1; }
echo ALL_TESTS_PASSED
