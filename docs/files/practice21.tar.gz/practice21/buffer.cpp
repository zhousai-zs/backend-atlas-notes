// 可移动字节缓冲区 + 统计 vector 扩容中的拷贝/移动次数
#include <cstdio>
#include <cstring>
#include <utility>
#include <vector>

#ifndef MOVE_NOEXCEPT
#define MOVE_NOEXCEPT noexcept
#endif

struct Stats { int copy = 0, move = 0; };
static Stats g;

class ByteBuffer {
public:
    explicit ByteBuffer(size_t n = 16) : data_(new char[n]), size_(n) { std::memset(data_, 0, n); }
    ~ByteBuffer() { delete[] data_; }                       // 移动后 data_==nullptr，delete nullptr 安全
    ByteBuffer(const ByteBuffer& o) : data_(new char[o.size_]), size_(o.size_) {
        std::memcpy(data_, o.data_, size_); ++g.copy;
    }
    ByteBuffer(ByteBuffer&& o) MOVE_NOEXCEPT
        : data_(std::exchange(o.data_, nullptr)), size_(std::exchange(o.size_, 0)) { ++g.move; }
    ByteBuffer& operator=(ByteBuffer o) noexcept {           // copy-and-swap，同时覆盖拷贝/移动赋值
        std::swap(data_, o.data_); std::swap(size_, o.size_); return *this;
    }
    size_t size() const { return size_; }
    bool empty() const { return data_ == nullptr; }
private:
    char* data_; size_t size_;
};

int main() {
    // 1) vector 扩容：noexcept 时走移动，否则走拷贝（强异常保证）
    g = {};
    std::vector<ByteBuffer> v;
    for (int i = 0; i < 100; ++i) v.emplace_back(64);
    std::printf("vector_grow copy=%d move=%d\n", g.copy, g.move);

    // 2) 对 const 对象 std::move：const ByteBuffer&& 只能绑定到拷贝构造
    g = {};
    const ByteBuffer c(32);
    ByteBuffer d = std::move(c);
    std::printf("const_move copy=%d move=%d\n", g.copy, g.move);

    // 3) 移动后源对象：有效但未指定状态，必须可析构、可重新赋值
    g = {};
    ByteBuffer a(8);
    ByteBuffer b = std::move(a);
    std::printf("moved_from empty=%d size=%zu b.size=%zu\n", a.empty(), a.size(), b.size());
    a = ByteBuffer(4);                                        // 可重新赋值后继续使用
    std::printf("reassigned size=%zu\n", a.size());
    return 0;                                                  // a、b 析构不会双重释放
}
