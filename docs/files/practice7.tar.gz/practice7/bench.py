import bisect, random, timeit

def linear_search(arr, target):
    for i, x in enumerate(arr):
        if x == target:
            return i
    return -1

def binary_search(arr, target):
    i = bisect.bisect_left(arr, target)
    return i if i < len(arr) and arr[i] == target else -1

def bench(fn, arr, targets, repeat=5):
    # 每轮查一批随机目标，取多轮中最快的一次，减少噪声
    best = min(timeit.repeat(lambda: [fn(arr, t) for t in targets],
                             number=1, repeat=repeat))
    return best / len(targets) * 1e6  # 微秒/次

print(f"{'n':>10} {'linear(us)':>12} {'binary(us)':>12} {'ratio':>8}")
for n in [10, 100, 1_000, 10_000, 100_000, 1_000_000]:
    arr = list(range(n))                      # 已有序，两种方法都能用
    targets = [random.randrange(n) for _ in range(200)]
    lin = bench(linear_search, arr, targets[:50] if n >= 100_000 else targets)
    bi = bench(binary_search, arr, targets)
    print(f"{n:>10} {lin:>12.2f} {bi:>12.3f} {lin/bi:>8.1f}")
